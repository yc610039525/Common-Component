package com.boco.transnms.common.dto;

import java.io.Serializable;

public class QueryTransPathDO
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  public static final int QUERY_PAGE_TYPE_BY_COMPLEX = 1;
  public static final int QUERY_PAGE_TYPE_BY_EQUIP = 2;
  private String queryEquipCuids;
  private Long queryPathType;
  private String queryPathState;
  private String queryEquipType;
  private Boolean isLdPath;
  private Boolean isCtPath;
  private Boolean countBeforQuery;
  private Boolean queryCountOnly;
  private String orderFieldString = "LABEL_CN";
  private String isSubDis;
  private String aEndStationCUID;
  private String zEndStationCUID;
  private String intendUse;
  private String rate;
  private String isFree;
  private String transPathCheckFlag;
  private String checkBeginTime;
  private String checkEndTime;
  private String transSysCuid;
  private String devTraphQuery;
  private String routeDescription;
  private String transPathChannelLevel;
  private String equalType;
  private String labelCn;
  private int queryPageType = 1;
  private String model;
  private String ALostType;
  private String ZLostType;
  private String isExcel;
  private String as_flag;

  public void setQueryEquipCuids(String queryEquipCuids)
  {
    this.queryEquipCuids = queryEquipCuids;
  }

  public void setQueryPathType(Long queryPathType) {
    this.queryPathType = queryPathType;
  }

  public void setQueryPathState(String queryPathState) {
    this.queryPathState = queryPathState;
  }

  public void setQueryEquipType(String queryEquipType) {
    this.queryEquipType = queryEquipType;
  }

  public void setIsLdPath(Boolean isLdPath) {
    this.isLdPath = isLdPath;
  }

  public void setIsCtPath(Boolean isCtPath) {
    this.isCtPath = isCtPath;
  }

  public Boolean getCountBeforQuery() {
    return this.countBeforQuery;
  }

  public void setCountBeforQuery(Boolean countBeforQuery) {
    this.countBeforQuery = countBeforQuery;
  }

  public Boolean getQueryCountOnly() {
    return this.queryCountOnly;
  }

  public void setQueryCountOnly(Boolean queryCountOnly) {
    this.queryCountOnly = queryCountOnly;
  }

  public void setOrderFieldString(String orderFieldString) {
    if ((orderFieldString != null) && (orderFieldString.equals("null")) && (orderFieldString.trim().length() > 0))
      this.orderFieldString = orderFieldString;
  }

  public void setIsSubDis(String isSubDis)
  {
    this.isSubDis = isSubDis;
  }

  public void setAendStationCUID(String aEndStationCUID) {
    this.aEndStationCUID = aEndStationCUID;
  }

  public void setZendStationCUID(String zEndStationCUID) {
    this.zEndStationCUID = zEndStationCUID;
  }

  public void setIntendUse(String intendUse) {
    this.intendUse = intendUse;
  }

  public void setRate(String rate) {
    this.rate = rate;
  }

  public void setIsFree(String isFree) {
    this.isFree = isFree;
  }

  public void setTransPathCheckFlag(String transPathCheckFlag) {
    this.transPathCheckFlag = transPathCheckFlag;
  }

  public void setCheckBeginTime(String checkBeginTime) {
    this.checkBeginTime = checkBeginTime;
  }

  public void setCheckEndTime(String checkEndTime) {
    this.checkEndTime = checkEndTime;
  }

  public void setTransSysCuid(String transSysCuid) {
    this.transSysCuid = transSysCuid;
  }

  public void setDevTraphQuery(String devTraphQuery) {
    this.devTraphQuery = devTraphQuery;
  }

  public void setRouteDescription(String routeDescription) {
    this.routeDescription = routeDescription;
  }

  public void setTransPathChannelLevel(String transPathChannelLevel) {
    this.transPathChannelLevel = transPathChannelLevel;
  }

  public void setQueryPageType(int queryPageType) {
    this.queryPageType = queryPageType;
  }

  public void setModel(String model) {
    this.model = model;
  }

  public void setALostType(String ALostType) {
    this.ALostType = ALostType;
  }

  public void setEqualType(String equalType) {
    this.equalType = equalType;
  }

  public void setZLostType(String ZLostType) {
    this.ZLostType = ZLostType;
  }

  public void setLabelCn(String labelCn) {
    this.labelCn = labelCn;
  }

  public void setIsExcel(String isExcel) {
    this.isExcel = isExcel;
  }

  public void setAs_flag(String as_flag) {
    this.as_flag = as_flag;
  }

  public String getQueryEquipCuids() {
    return this.queryEquipCuids;
  }

  public Long getQueryPathType() {
    return this.queryPathType;
  }

  public String getQueryPathState() {
    return this.queryPathState;
  }

  public String getQueryEquipType() {
    return this.queryEquipType;
  }

  public Boolean getIsLdPath() {
    return this.isLdPath;
  }

  public Boolean getIsCtPath() {
    return this.isCtPath;
  }

  public String getOrderFieldString() {
    return this.orderFieldString;
  }

  public String getIsSubDis() {
    return this.isSubDis;
  }

  public String getAendStationCUID() {
    return this.aEndStationCUID;
  }

  public String getZendStationCUID() {
    return this.zEndStationCUID;
  }

  public String getIntendUse() {
    return this.intendUse;
  }

  public String getRate() {
    return this.rate;
  }

  public String getIsFree() {
    return this.isFree;
  }

  public String getTransPathCheckFlag() {
    return this.transPathCheckFlag;
  }

  public String getCheckBeginTime() {
    return this.checkBeginTime;
  }

  public String getCheckEndTime() {
    return this.checkEndTime;
  }

  public String getTransSysCuid() {
    return this.transSysCuid;
  }

  public String getDevTraphQuery() {
    return this.devTraphQuery;
  }

  public String getRouteDescription() {
    return this.routeDescription;
  }

  public String getTransPathChannelLevel() {
    return this.transPathChannelLevel;
  }

  public int getQueryPageType() {
    return this.queryPageType;
  }

  public String getModel() {
    return this.model;
  }

  public String getALostType() {
    return this.ALostType;
  }

  public String getEqualType() {
    return this.equalType;
  }

  public String getZLostType() {
    return this.ZLostType;
  }

  public String getLabelCn() {
    return this.labelCn;
  }

  public String getIsExcel() {
    return this.isExcel;
  }

  public String getAs_flag() {
    return this.as_flag;
  }
}