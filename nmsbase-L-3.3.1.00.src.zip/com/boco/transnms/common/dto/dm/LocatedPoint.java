package com.boco.transnms.common.dto.dm;

import com.boco.transnms.common.dto.base.GenericDO;
import java.io.Serializable;

public class LocatedPoint
  implements Serializable
{
  private String cuid;
  private long objectNum;
  private String labelCn;
  private double longitude;
  private double latitude;
  private String RelatedDistrictCuid;
  private int pointType;
  private String relatedLocationCuid;

  public String getRelatedDistrictCuid()
  {
    return this.RelatedDistrictCuid;
  }

  public void setCuid(String cuid)
  {
    this.cuid = cuid;
  }

  public void setObjectNum(long objectNum) {
    this.objectNum = objectNum;
  }

  public void setLabelCn(String labelCn) {
    this.labelCn = labelCn;
  }

  public void setLongitude(double longitude) {
    this.longitude = longitude;
  }

  public void setLatitude(double latitude) {
    this.latitude = latitude;
  }

  public void setPointType(int pointType) {
    this.pointType = pointType;
  }

  public void setRelatedLocationCuid(String relatedLocationCuid) {
    this.relatedLocationCuid = relatedLocationCuid;
  }

  public void setRelatedDistrictCuid(String RelatedDistrictCuid) {
    this.RelatedDistrictCuid = RelatedDistrictCuid;
  }

  public String getCuid() {
    return this.cuid;
  }

  public long getObjectNum() {
    return this.objectNum;
  }

  public String getLabelCn() {
    return this.labelCn;
  }

  public double getLongitude() {
    return this.longitude;
  }

  public double getLatitude() {
    return this.latitude;
  }

  public int getPointType() {
    return this.pointType;
  }

  public String getRelatedLocationCuid() {
    return this.relatedLocationCuid;
  }

  public void copyTo(GenericDO dbo) {
    dbo.setCuid(getCuid());
    dbo.setObjectNum(getObjectNum());
    dbo.setAttrValue("LABEL_CN", getLabelCn());
    dbo.setAttrValue("LONGITUDE", getLongitude());
    dbo.setAttrValue("LATITUDE", getLatitude());
    if (dbo.getClassName().equals("SITE")) {
      dbo.setAttrValue("RELATED_SPACE_CUID", this.RelatedDistrictCuid);
    }
    else {
      if (dbo.getClassName().equals("FIBER_JOINT_BOX")) {
        dbo.setAttrValue("RELATED_LOCATION_CUID", getRelatedLocationCuid());
      }
      dbo.setAttrValue("RELATED_DISTRICT_CUID", this.RelatedDistrictCuid);
    }
  }
}