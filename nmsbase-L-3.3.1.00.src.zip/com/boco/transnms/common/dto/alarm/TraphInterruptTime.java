package com.boco.transnms.common.dto.alarm;

import com.boco.transnms.common.dto.base.GenericDO;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class TraphInterruptTime extends GenericDO
{
  public static final String CLASS_NAME = "TRAPH_INTERRUPT_TIME";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public TraphInterruptTime() {
    super("TRAPH_INTERRUPT_TIME");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes()
  {
    this.attrTypeMap.put("START_TIME", Timestamp.class);
    this.attrTypeMap.put("END_TIME", Timestamp.class);
    this.attrTypeMap.put("CUID", String.class);
  }

  public void setStartTime(Timestamp varStartTime) {
    setAttrValue("START_TIME", varStartTime);
  }

  public Timestamp getStartTime() {
    return getAttrDateTime("START_TIME");
  }

  public void setEndTime(Timestamp varEndTime) {
    setAttrValue("END_TIME", varEndTime);
  }

  public Timestamp getEndTime() {
    return getAttrDateTime("END_TIME");
  }

  public class AttrName
  {
    public static final String startTime = "START_TIME";
    public static final String endTime = "END_TIME";
    public static final String cuid = "CUID";

    public AttrName()
    {
    }
  }
}