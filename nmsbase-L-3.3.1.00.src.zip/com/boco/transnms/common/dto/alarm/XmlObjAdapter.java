package com.boco.transnms.common.dto.alarm;

import com.boco.common.util.xml.AbstractXmlModel;
import java.io.StringReader;
import java.io.StringWriter;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

public class XmlObjAdapter extends AbstractXmlModel
{
  public XmlObjAdapter()
    throws Exception
  {
    super("com.boco.transnms.xsdmap.emosadapter");
  }

  public XmlObjAdapter(String packagename) throws Exception {
    super(packagename);
  }

  public String getxmlData(Object data)
  {
    try {
      Marshaller m = this.jaxbContext.createMarshaller();
      m.setProperty("jaxb.formatted.output", Boolean.TRUE);
      m.setProperty("jaxb.encoding", "GB2312");
      StringWriter t = new StringWriter();
      m.marshal(data, t);
      return t.toString();
    } catch (JAXBException je) {
      je.printStackTrace();
    }return "";
  }

  public Object getObjData(String str)
  {
    try
    {
      Unmarshaller unmarsh = this.jaxbContext.createUnmarshaller();
      StringReader t = new StringReader(str);
      return unmarsh.unmarshal(t);
    } catch (JAXBException ex) {
    }
    return null;
  }
}