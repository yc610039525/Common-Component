package com.boco.transnms.common.dto.workflow;

import com.boco.transnms.common.dto.AttempSheet;
import com.boco.transnms.common.dto.base.GenericDO;

public class ShowDgn extends GenericDO
{
  private AttempSheet sheet;
  private String[] designers;
  private String[] dispatchers;
  private String[] approvers;
  private String[] attaches;
  private String[] detail;
  private String[] toSendDep;
  private String[] rplDetail;

  public AttempSheet getSheet()
  {
    return this.sheet;
  }

  public String[] getAttaches() {
    return this.attaches;
  }

  public void setApprovers(String[] approvers) {
    this.approvers = approvers;
  }

  public void setSheet(AttempSheet sheet) {
    this.sheet = sheet;
  }

  public void setAttaches(String[] attaches) {
    this.attaches = attaches;
  }

  public void setDispatchers(String[] dispatchers) {
    this.dispatchers = dispatchers;
  }

  public void setDesigners(String[] designers) {
    this.designers = designers;
  }

  public void setToSendDep(String[] toSendDep) {
    this.toSendDep = toSendDep;
  }

  public void setDetail(String[] detail) {
    this.detail = detail;
  }

  public void setRplDetail(String[] rplDetail) {
    this.rplDetail = rplDetail;
  }

  public String[] getApprovers()
  {
    return this.approvers;
  }

  public String[] getDispatchers() {
    return this.dispatchers;
  }

  public String[] getDesigners() {
    return this.designers;
  }

  public String[] getToSendDep() {
    return this.toSendDep;
  }

  public String[] getDetail() {
    return this.detail;
  }

  public String[] getRplDetail() {
    return this.rplDetail;
  }
}