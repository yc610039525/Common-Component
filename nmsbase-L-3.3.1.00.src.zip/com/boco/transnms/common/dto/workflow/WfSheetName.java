package com.boco.transnms.common.dto.workflow;

public class WfSheetName
{
  public static final String CES_FIBER_APP_SHEET = "cesFiberAppSheet";
  public static final String CES_FIBER_FB_SHEET = "cesFiberFBSheet";
  public static final String CES_EQUIP_APP_SHEET = "cesEquipAppSheet";
  public static final String CES_EQUIP_FB_SHEET = "cesEquipFBSheet";
}