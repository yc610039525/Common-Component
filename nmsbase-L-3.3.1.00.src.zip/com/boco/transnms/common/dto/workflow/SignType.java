package com.boco.transnms.common.dto.workflow;

public class SignType
{
  public static final int SIGN_CES_AUDIT = 0;
  public static final int SIGN_CES_APPROVE1 = 1;
  public static final int SIGN_CES_APPROVE2 = 2;
  public static final int SIGN_FAULT = 3;
}