package com.boco.transnms.common.dto.workflow;

import java.io.Serializable;

public class SharkUser
  implements Serializable
{
  private String userName = "";

  private String password = "";

  private String email = "";

  private String realName = "";

  private String groupName = "boco";

  private SharkRole[] roleArray = new SharkRole[0];

  private String mobileTel = "";
  private String cuid;

  public void setUserName(String userName)
  {
    this.userName = userName;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public void setRealName(String realName)
  {
    this.realName = realName;
  }

  public void setGroupName(String groupName)
  {
    this.groupName = groupName;
  }

  public void setRoleArray(SharkRole[] roleArray)
  {
    this.roleArray = roleArray;
  }

  public void setMobileTel(String mobileTel) {
    this.mobileTel = mobileTel;
  }

  public void setCuid(String cuid) {
    this.cuid = cuid;
  }

  public String getUserName() {
    return this.userName;
  }

  public String getPassword() {
    return this.password;
  }

  public String getEmail() {
    return this.email;
  }

  public String getRealName()
  {
    return this.realName;
  }

  public String getGroupName()
  {
    return this.groupName;
  }

  public SharkRole[] getRoleArray() {
    return this.roleArray;
  }

  public String getMobileTel() {
    return this.mobileTel;
  }

  public String getCuid() {
    return this.cuid;
  }
}