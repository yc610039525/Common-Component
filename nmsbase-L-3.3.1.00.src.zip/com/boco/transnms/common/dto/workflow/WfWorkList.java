package com.boco.transnms.common.dto.workflow;

import com.boco.transnms.common.dto.base.GenericDO;

public class WfWorkList extends GenericDO
{
  private String processId;
  private String packageId;
  private int processType;
  private String processKey;
  private String activityKey;
  private String activityId;
  private String actionName;
  private String activityName;
  private String userName;
  private String processName;
  private int workflowState;
  private String userCuid;
  private String sheetId;
  private String[] relatedUsers;
  private int isPass = 1;
  private String singMsg;
  private String operatorDep;
  private String sheetCUID;
  private int sheetType;
  private String nextActivityName;
  private String nextOperator;
  private int isSendSMSorEmail = 1;

  public WfWorkList() {
  }
  public WfWorkList(WfWorkList basiclist) {
    this.processKey = basiclist.getProcessKey();
    this.processName = basiclist.getProcessName();
    this.processType = basiclist.getProcessType();
    this.actionName = basiclist.getActionName();
    this.activityId = basiclist.getActivityId();
    this.activityKey = basiclist.getActivityKey();
    this.activityName = basiclist.getActivityName();
    this.userName = basiclist.getUserName();
    this.workflowState = basiclist.getWorkflowState();
    this.userCuid = basiclist.getUserCuid();
  }

  public void setUserCuid(String userCuid) {
    this.userCuid = userCuid;
  }

  public void setProcessKey(String processKey) {
    this.processKey = processKey;
  }

  public void setActivityKey(String activityKey) {
    this.activityKey = activityKey;
  }

  public void setActivityId(String activityId) {
    this.activityId = activityId;
  }

  public void setProcessType(int processType) {
    this.processType = processType;
  }

  public void setActionName(String actionName) {
    this.actionName = actionName;
  }

  public void setActivityName(String activityName) {
    this.activityName = activityName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public void setProcessName(String processName) {
    this.processName = processName;
  }

  public void setWorkflowState(int workflowState) {
    this.workflowState = workflowState;
  }

  public void setPackageId(String packageId) {
    this.packageId = packageId;
  }

  public void setProcessId(String processId) {
    this.processId = processId;
  }

  public void setSheetId(String sheetId) {
    this.sheetId = sheetId;
  }

  public void setRelatedUsers(String[] relatedUsers) {
    this.relatedUsers = relatedUsers;
  }

  public void setIsPass(int isPass)
  {
    this.isPass = isPass;
  }

  public void setIsSendSMSorEmail(int isSendSMSorEmail) {
    this.isSendSMSorEmail = isSendSMSorEmail;
  }

  public void setSingMsg(String singMsg) {
    this.singMsg = singMsg;
  }

  public void setOperatorDep(String operatorDep) {
    this.operatorDep = operatorDep;
  }

  public void setSheetCUID(String sheetCUID) {
    this.sheetCUID = sheetCUID;
  }

  public void setSheetType(int sheetType) {
    this.sheetType = sheetType;
  }

  public void setNextActivityName(String nextActivityName) {
    this.nextActivityName = nextActivityName;
  }

  public void setNextOperator(String nextOperator) {
    this.nextOperator = nextOperator;
  }

  public String getProcessKey() {
    return this.processKey;
  }

  public String getActivityKey() {
    return this.activityKey;
  }

  public String getActivityId() {
    return this.activityId;
  }

  public int getProcessType() {
    return this.processType;
  }

  public String getActionName() {
    return this.actionName;
  }

  public String getActivityName() {
    return this.activityName;
  }

  public String getUserName() {
    return this.userName;
  }

  public String getProcessName() {
    return this.processName;
  }

  public int getWorkflowState() {
    return this.workflowState;
  }

  public String getPackageId() {
    return this.packageId;
  }

  public String getProcessId() {
    return this.processId;
  }

  public String getUserCuid() {
    return this.userCuid;
  }

  public String getSheetId() {
    return this.sheetId;
  }

  public String[] getRelatedUsers() {
    return this.relatedUsers;
  }

  public int getIsPass()
  {
    return this.isPass;
  }

  public int getIsSendSMSorEmail() {
    return this.isSendSMSorEmail;
  }

  public String getSingMsg() {
    return this.singMsg;
  }

  public String getOperatorDep() {
    return this.operatorDep;
  }

  public String getSheetCUID() {
    return this.sheetCUID;
  }

  public int getSheetType() {
    return this.sheetType;
  }

  public String getNextOperator() {
    return this.nextOperator;
  }

  public String getNextActivityName() {
    return this.nextActivityName;
  }
}