package com.boco.transnms.common.dto.workflow;

public class WfIdHref
{
  private String cuid;
  private String href;
  private String name;
  private String extAttr;

  public WfIdHref(String cuid, String name, String href, String extAttr)
  {
    this.cuid = cuid;
    this.name = name;
    this.href = href;
    this.extAttr = extAttr;
  }

  public void setHref(String href) {
    this.href = href;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setCuid(String cuid) {
    this.cuid = cuid;
  }

  public void setExtAttr(String extAttr) {
    this.extAttr = extAttr;
  }

  public String getHref()
  {
    return this.href;
  }

  public String getName() {
    return this.name;
  }

  public String getCuid() {
    return this.cuid;
  }

  public String getExtAttr() {
    return this.extAttr;
  }

  public static String getNames(WfIdHref[] idRefs) {
    String names = "";
    for (int i = 0; i < idRefs.length; i++) {
      names = names + idRefs[i].getName();
      if (i < idRefs.length - 1) {
        names = names + ",";
      }
    }
    return names;
  }
  public static String getExtAttrs(WfIdHref[] idRefs) {
    String names = "";
    for (int i = 0; i < idRefs.length; i++) {
      names = names + idRefs[i].getExtAttr();
      if (i < idRefs.length - 1) {
        names = names + ",";
      }
    }
    return names;
  }
  public static String getHrefs(WfIdHref[] idRefs) {
    String hrefs = "";
    for (int i = 0; i < idRefs.length; i++) {
      hrefs = hrefs + idRefs[i].getHref();
      if (i < idRefs.length - 1) {
        hrefs = hrefs + ",";
      }
    }
    return hrefs;
  }
}