package com.boco.transnms.common.dto.workflow;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class WfProcessId
{
  private static List processIds = new ArrayList();
  private static HashMap codes = new HashMap();
  public static final String ATTEMP_APP_PROCESS_ID = "attempAppWF";
  public static final String ATTEMP_DGN_PROCESS_ID = "attempDgnWF";
  public static final String ATTEMP_RPL_PROCESS_ID = "attempRplWF";
  public static final String GL_ATTEMP_APP_PROCESS_ID = "glAttempAppWF";
  public static final String GL_ATTEMP_DGN_PROCESS_ID = "glAttempDgnWF";
  public static final String GL_ATTEMP_RPL_PROCESS_ID = "glAttempRplWF";
  public static final String NETCOM_APP_PROCESS_ID = "netcomAttempAppWF";
  public static final String NETCOM_DGN_PROCESS_ID = "netcomAttempDgnWF";
  public static final String NETCOM_RPL_PROCESS_ID = "netcomAttempRplWF";
  public static final String UNICOM_DGN_PROCESS_ID = "unicomdgnWF";
  public static final String SC_DGN_PROCESS_ID = "scWF";

  public static List getProcessIds()
  {
    return processIds;
  }
  public static HashMap getCodes() {
    return codes;
  }

  static
  {
    processIds.add("attempAppWF");
    processIds.add("attempDgnWF");
    processIds.add("attempRplWF");
    processIds.add("glAttempAppWF");
    processIds.add("glAttempDgnWF");
    processIds.add("glAttempRplWF");
    processIds.add("netcomAttempAppWF");
    processIds.add("netcomAttempDgnWF");
    processIds.add("netcomAttempRplWF");
    processIds.add("unicomdgnWF");
    processIds.add("scWF");

    codes.put("attempAppWF", "1");
    codes.put("attempDgnWF", "2");
    codes.put("attempRplWF", "3");
    codes.put("glAttempAppWF", "4");
    codes.put("glAttempDgnWF", "5");
    codes.put("glAttempRplWF", "6");
    codes.put("netcomAttempAppWF", "11");
    codes.put("netcomAttempDgnWF", "12");
    codes.put("netcomAttempRplWF", "13");
    codes.put("unicomdgnWF", "40");
    codes.put("scWF", "50");
  }
}