package com.boco.transnms.common.dto.workflow;

import java.util.ArrayList;
import java.util.List;

public class WfProcessType
{
  public static List getProcessTypes(String processId)
  {
    List processTypes = new ArrayList();
    if (processId.equals("attempAppWF"))
      processTypes.add(Integer.valueOf(11));
    else if (processId.equals("attempDgnWF"))
      processTypes.add(Integer.valueOf(12));
    else if (processId.equals("attempRplWF"))
      processTypes.add("attempRplWF");
    else if (processId.equals("glAttempAppWF"))
      processTypes.add(Integer.valueOf(14));
    else if (processId.equals("glAttempDgnWF"))
      processTypes.add(Integer.valueOf(15));
    else if (processId.equals("glAttempRplWF"))
      processTypes.add(Integer.valueOf(16));
    else if (processId.equals("netcomAttempAppWF"))
      processTypes.add(Integer.valueOf(21));
    else if (processId.equals("netcomAttempDgnWF"))
      processTypes.add(Integer.valueOf(22));
    else if (processId.equals("netcomAttempRplWF"))
      processTypes.add(Integer.valueOf(23));
    else if (processId.equals("unicomdgnWF"))
      processTypes.add(Integer.valueOf(40));
    else if (processId.equals("scWF")) {
      processTypes.add(Integer.valueOf(50));
    }

    return processTypes;
  }

  public static String getProcessTypeName(int processType) {
    switch (processType) { case 11:
      return "申请流程";
    case 12:
      return "调度流程";
    case 13:
      return "工单流程";
    case 14:
      return "光路申请流程";
    case 15:
      return "光路调度流程";
    case 16:
      return "光路工单流程";
    case 21:
      return "综合资源申请流程";
    case 22:
      return "综合资源调度流程";
    case 23:
      return "综合资源回执流程";
    case 40:
      return "联通调度流程";
    case 50:
      return "四川工单管理流程";
    case 17:
    case 18:
    case 19:
    case 20:
    case 24:
    case 25:
    case 26:
    case 27:
    case 28:
    case 29:
    case 30:
    case 31:
    case 32:
    case 33:
    case 34:
    case 35:
    case 36:
    case 37:
    case 38:
    case 39:
    case 41:
    case 42:
    case 43:
    case 44:
    case 45:
    case 46:
    case 47:
    case 48:
    case 49: } return "";
  }

  public static class WF_ATTEMP
  {
    public static final int APP = 11;
    public static final int DGN = 12;
    public static final int RPL = 13;
    public static final int GL_APP = 14;
    public static final int GL_DGN = 15;
    public static final int GL_RPL = 16;
    public static final int NETCOM_APP = 21;
    public static final int NETCOM_DGN = 22;
    public static final int NETCOM_RPL = 23;
    public static final int UNICOM_DGN = 40;
    public static final int SC_DGN = 50;
  }
}