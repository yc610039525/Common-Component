package com.boco.transnms.common.dto.workflow;

import com.boco.transnms.common.dto.ReplySheet;
import com.boco.transnms.common.dto.base.GenericDO;

public class ShowRpl extends GenericDO
{
  private String[] detail;
  private ReplySheet rplSheet;

  public void setDetail(String[] detail)
  {
    this.detail = detail;
  }

  public void setRplSheet(ReplySheet rplSheet) {
    this.rplSheet = rplSheet;
  }

  public String[] getDetail() {
    return this.detail;
  }

  public ReplySheet getRplSheet() {
    return this.rplSheet;
  }
}