package com.boco.transnms.common.dto.workflow;

import java.io.Serializable;

public class SharkRole
  implements Serializable
{
  private String roleId;
  private String roleDef;
  private String packageId;
  private String processId;
  private int rolePos;

  public SharkRole()
  {
    try
    {
      jbInit();
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public void setRoleId(String roleId) {
    this.roleId = roleId;
  }

  public void setRoleDef(String roleDef) {
    this.roleDef = roleDef;
  }

  public void setPackageId(String packageId) {
    this.packageId = packageId;
  }

  public void setProcessId(String processId) {
    this.processId = processId;
  }

  public void setRolePos(int rolePos) {
    this.rolePos = rolePos;
  }

  public String getRoleId() {
    return this.roleId;
  }

  public String getRoleDef() {
    return this.roleDef;
  }

  public String getPackageId() {
    return this.packageId;
  }

  public String getProcessId() {
    return this.processId;
  }

  public int getRolePos() {
    return this.rolePos;
  }

  private void jbInit()
    throws Exception
  {
  }
}