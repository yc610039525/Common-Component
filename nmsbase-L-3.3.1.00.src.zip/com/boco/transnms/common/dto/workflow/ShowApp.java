package com.boco.transnms.common.dto.workflow;

import com.boco.transnms.common.dto.ApplySheet;
import com.boco.transnms.common.dto.base.GenericDO;

public class ShowApp extends GenericDO
{
  private ApplySheet appSheet;
  private String[] approvers;
  private String[] attaches;
  private String[] resourceChecker;
  private String[] appReceivers;

  public void setAppSheet(ApplySheet appSheet)
  {
    this.appSheet = appSheet;
  }

  public void setApprovers(String[] approvers) {
    this.approvers = approvers;
  }

  public void setAttaches(String[] attaches) {
    this.attaches = attaches;
  }

  public void setResourceChecker(String[] resourceChecker) {
    this.resourceChecker = resourceChecker;
  }

  public void setAppReceivers(String[] appReceivers) {
    this.appReceivers = appReceivers;
  }

  public ApplySheet getAppSheet() {
    return this.appSheet;
  }

  public String[] getApprovers() {
    return this.approvers;
  }

  public String[] getAttaches() {
    return this.attaches;
  }

  public String[] getResourceChecker() {
    return this.resourceChecker;
  }

  public String[] getAppReceivers() {
    return this.appReceivers;
  }
}