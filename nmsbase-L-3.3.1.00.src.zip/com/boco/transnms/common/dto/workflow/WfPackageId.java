package com.boco.transnms.common.dto.workflow;

public class WfPackageId
{
  public static final String ATTEMP_APP_PKG_ID = "attempappworkflow";
  public static final String ATTEMP_DGN_PKG_ID = "attempdgnworkflow";
  public static final String ATTEMP_RPL_PKG_ID = "attemprplworkflow";
  public static final String GL_ATTEMP_APP_PKG_ID = "glattempappworkflow";
  public static final String GL_ATTEMP_DGN_PKG_ID = "glattempdgnworkflow";
  public static final String GL_ATTEMP_RPL_PKG_ID = "glattemprplworkflow";
  public static final String NETCOM_APP_PKG_ID = "netcomappworkflow";
  public static final String NETCOM_DGN_PKG_ID = "netcomdgnworkflow";
  public static final String NETCOM_RPL_PKG_ID = "netcomrplworkflow";
  public static final String UNICOM_DGN_PKG_ID = "unicomdgnworkflow";
  public static final String SC_DGN_PKG_ID = "scworkflow";

  public static String[] getAllWfPackages()
  {
    String[] pkgs = new String[9];
    pkgs[0] = "attempappworkflow";
    pkgs[1] = "attempdgnworkflow";
    pkgs[2] = "attemprplworkflow";
    pkgs[3] = "glattempappworkflow";
    pkgs[4] = "glattempdgnworkflow";
    pkgs[5] = "glattemprplworkflow";
    pkgs[6] = "netcomappworkflow";
    pkgs[7] = "netcomdgnworkflow";
    pkgs[8] = "netcomrplworkflow";
    pkgs[9] = "unicomdgnworkflow";
    pkgs[10] = "scworkflow";

    return pkgs;
  }
}