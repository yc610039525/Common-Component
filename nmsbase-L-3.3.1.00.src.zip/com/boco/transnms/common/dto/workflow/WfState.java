package com.boco.transnms.common.dto.workflow;

public class WfState
{
  public static String getAppSheetStateName(String activityId, int stateNo)
  {
    String rtn = "";
    if (activityId.equals("appCommitAct"))
      rtn = "编辑";
    else if (activityId.equals("appRecycleAct"))
      rtn = "审核未通过";
    else if (activityId.equals("appRecycleAct"))
      rtn = "核查未通过";
    else if (activityId.equals("appApproveAct"))
      rtn = "审核";
    else if (activityId.equals("appCheckAct")) {
      rtn = "资源核查";
    }
    return rtn;
  }

  public static String getCessionStateName(String activityId, int stateNo)
  {
    if (activityId.equals("createAppSheetAct"))
      return "创建申请单";
    if (activityId.equals("editAppSheetAct")) {
      switch (stateNo) { case 0:
        return "创建割接申请单，等待提交";
      case 2:
        return "审核未通过，驳回";
      case 4:
        return "一级审批未通过，驳回";
      case 1:
      case 3: } return "编辑申请单";
    }
    if (activityId.equals("auditAppSheetAct"))
      return "申请单创建完成，等待审核";
    if (activityId.equals("approveAppSheet1Act")) {
      switch (stateNo) { case 6:
        return "二级审批不通过，驳回"; }
      return "等待一级审批申请单";
    }
    if (activityId.equals("approveAppSheet2Act"))
      return "等待二级审批申请单";
    if (activityId.equals("commitAppSheetToCesAct"))
      return "审批通过，待提交割接申请单";
    if (activityId.equals("createFBSheetAct"))
      return "等待反馈割接申请单";
    if (activityId.equals("editFbSheetAct"))
      return "等待提交割接反馈单";
    if (activityId.equals("ackFbSheetAct")) {
      return "等待确认割接反馈";
    }
    return activityId + stateNo;
  }

  public static class RplSheet
  {
    public static final int CONSTANT = 0;
  }

  public static class DgnSheet
  {
    public static final int CONSTANT = 0;
    public static final int RECYCLEACT_APPROVE = 1;
    public static final int RECYCLEACT_CHECK = 2;
    public static final int APPROVEACT_APPROVE = 1;
    public static final int APPROVEACT_RE_APPROVE = 2;
  }

  public static class AppSheet
  {
    public static final int CONSTANT = 0;
    public static final int RECYCLEACT_APPROVE = 1;
    public static final int RECYCLEACT_CHECK = 2;
    public static final int APPROVEACT_APPROVE = 1;
    public static final int APPROVEACT_RE_APPROVE = 2;
    public static final int RECEIVEACT_RECEIVE = 1;
    public static final int RECEIVEACT_CHECK = 2;
  }
}