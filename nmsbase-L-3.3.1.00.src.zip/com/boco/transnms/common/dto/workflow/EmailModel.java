package com.boco.transnms.common.dto.workflow;

import com.boco.transnms.common.dto.base.GenericDO;
import javax.mail.Address;

public class EmailModel extends GenericDO
{
  private String serverIP;
  private String serverPort;
  private String userName;
  private String password;
  private Address fromUserAddress;
  private Address[] toUserAddress;
  private String content;
  private String subject;
  private String accessories;

  public void setServerIP(String serverIP)
  {
    this.serverIP = serverIP;
  }

  public void setServerPort(String serverPort) {
    this.serverPort = serverPort;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public void setFromUserAddress(Address fromUserAddress) {
    this.fromUserAddress = fromUserAddress;
  }

  public void setToUserAddress(Address[] toUserAddress) {
    this.toUserAddress = toUserAddress;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public void setSubject(String subject) {
    this.subject = subject;
  }

  public void setAccessories(String accessories) {
    this.accessories = accessories;
  }

  public String getServerIP() {
    return this.serverIP;
  }

  public String getServerPort() {
    return this.serverPort;
  }

  public String getUserName() {
    return this.userName;
  }

  public String getPassword() {
    return this.password;
  }

  public Address getFromUserAddress() {
    return this.fromUserAddress;
  }

  public Address[] getToUserAddress() {
    return this.toUserAddress;
  }

  public String getContent() {
    return this.content;
  }

  public String getSubject() {
    return this.subject;
  }

  public String getAccessories() {
    return this.accessories;
  }
}