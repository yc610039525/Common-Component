package com.boco.transnms.common.dto.workflow;

public class PackageInfo
{
  private String packageId;
  private String ver;
  private String packageName;

  public void setPackageId(String packageId)
  {
    this.packageId = packageId;
  }

  public void setVer(String ver) {
    this.ver = ver;
  }

  public void setPackageName(String packageName) {
    this.packageName = packageName;
  }

  public String getPackageId() {
    return this.packageId;
  }

  public String getVer() {
    return this.ver;
  }

  public String getPackageName() {
    return this.packageName;
  }
}