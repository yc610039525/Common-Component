package com.boco.transnms.common.dto;

import com.boco.transnms.common.dto.base.GenericDO;

public class TransPathRouteDescription extends GenericDO
{
  private String routeNum;
  private String zjSiteCuids;
  private String zjSiteNames;
  private String description;
  private String subType;

  public String getDescription()
  {
    return this.description;
  }

  public String getRouteNum() {
    return this.routeNum;
  }

  public String getSubType() {
    return this.subType;
  }

  public String getZjSiteCuids() {
    return this.zjSiteCuids;
  }

  public String getZjSiteNames() {
    return this.zjSiteNames;
  }

  public void setZjSiteNames(String zjSiteNames) {
    this.zjSiteNames = zjSiteNames;
  }

  public void setZjSiteCuids(String zjSiteCuids) {
    this.zjSiteCuids = zjSiteCuids;
  }

  public void setSubType(String subType) {
    this.subType = subType;
  }

  public void setRouteNum(String routeNum) {
    this.routeNum = routeNum;
  }

  public void setDescription(String description) {
    this.description = description;
  }
}