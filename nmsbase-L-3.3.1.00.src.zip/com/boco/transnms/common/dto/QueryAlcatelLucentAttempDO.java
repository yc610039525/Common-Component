package com.boco.transnms.common.dto;

import java.io.Serializable;

public class QueryAlcatelLucentAttempDO
  implements Serializable
{
  private String headingNum;
  private String relatedDesignerisCuid;
  private String title;
  private String startDate;
  private String endDate;
  private String urgent;
  private String orderFieldString = "HEADING_NUM";

  public String getHeadingNum()
  {
    return this.headingNum;
  }

  public String getRelatedDesignerisCuid() {
    return this.relatedDesignerisCuid;
  }

  public String getTitle() {
    return this.title;
  }

  public String getUrgent() {
    return this.urgent;
  }

  public String getOrderFieldString() {
    return this.orderFieldString;
  }

  public String getStartDate() {
    return this.startDate;
  }

  public String getEndDate() {
    return this.endDate;
  }

  public void setUrgent(String urgent) {
    this.urgent = urgent;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public void setRelatedDesignerisCuid(String relatedDesignerisCuid) {
    this.relatedDesignerisCuid = relatedDesignerisCuid;
  }

  public void setHeadingNum(String headingNum) {
    this.headingNum = headingNum;
  }

  public void setOrderFieldString(String orderFieldString) {
    if ((orderFieldString != null) && (!orderFieldString.equals("null")) && (orderFieldString.trim().length() > 0))
      this.orderFieldString = orderFieldString;
  }

  public void setStartDate(String startDate)
  {
    this.startDate = startDate;
  }

  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }
}