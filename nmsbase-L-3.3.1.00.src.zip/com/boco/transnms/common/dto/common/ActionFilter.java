package com.boco.transnms.common.dto.common;

import java.io.Serializable;

public class ActionFilter
  implements Serializable
{
  private String actionName;
  private String actionText;
  private boolean actionVisible = true;

  public void setActionName(String actionName)
  {
    this.actionName = actionName;
  }

  public void setActionText(String actionText) {
    this.actionText = actionText;
  }

  public void setActionVisible(boolean actionVisible) {
    this.actionVisible = actionVisible;
  }

  public String getActionName() {
    return this.actionName;
  }

  public String getActionText() {
    return this.actionText;
  }

  public boolean isActionVisible() {
    return this.actionVisible;
  }
}