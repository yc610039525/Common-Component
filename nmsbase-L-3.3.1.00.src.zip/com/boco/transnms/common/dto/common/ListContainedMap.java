package com.boco.transnms.common.dto.common;

import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class ListContainedMap
  implements Serializable
{
  private static final long serialVersionUID = 7623067504574112357L;
  private Map<String, DataObjectList> map;

  public ListContainedMap()
  {
    this.map = new HashMap();
  }

  public void put(String key, GenericDO gdo)
  {
    if (this.map.containsKey(key)) {
      ((DataObjectList)this.map.get(key)).add(gdo);
    } else {
      DataObjectList dataObjectList = new DataObjectList();
      dataObjectList.add(gdo);
      this.map.put(key, dataObjectList);
    }
  }

  public void putList(String key, DataObjectList gdos)
  {
    if (this.map.containsKey(key)) {
      ((DataObjectList)this.map.get(key)).addAll(gdos);
    } else {
      DataObjectList dataObjectList = new DataObjectList();
      dataObjectList.addAll(gdos);
      this.map.put(key, dataObjectList);
    }
  }

  public DataObjectList get(String key)
  {
    return (DataObjectList)this.map.get(key);
  }

  public Iterator<Map.Entry<String, DataObjectList>> iterator() {
    return this.map.entrySet().iterator();
  }
}