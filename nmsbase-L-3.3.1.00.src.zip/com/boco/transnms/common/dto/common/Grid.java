package com.boco.transnms.common.dto.common;

public class Grid
{
  private String header;
  private String headId;
  private String colWidth;
  private String align;
  private String sort;
  private String type;

  public void setHeader(String header)
  {
    this.header = header;
  }

  public void setHeadId(String headId) {
    this.headId = headId;
  }

  public void setColWidth(String colWidth) {
    this.colWidth = colWidth;
  }

  public void setAlign(String align) {
    this.align = align;
  }

  public void setSort(String sort) {
    this.sort = sort;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getHeader() {
    return this.header;
  }

  public String getHeadId() {
    return this.headId;
  }

  public String getColWidth() {
    return this.colWidth;
  }

  public String getAlign() {
    return this.align;
  }

  public String getSort() {
    return this.sort;
  }

  public String getType() {
    return this.type;
  }
}