package com.boco.transnms.common.dto.common;

public class OsComConstants
{
  public static final String WINDOWS = "Windows";
  public static final String SOLARIS = "SOLARIS";
  public static final String AIX = "AIX";
  public static final String HP_UX = "HP_UX";
  public static final String TOMCAT_PRO_COMM = "ps -eo user,ppid,pcpu,pmem,vsz,args,pid";
  public static final String[] TOMCAT_PRO_COMM_FILTER = { "java", "manager=org" };
  public static final String RTU_PRO_COMM = "ps -eo user,ppid,pcpu,pmem,vsz,args,pid";
  public static final String[] RTU_PRO_COMM_FILTER = { "java", "com.boco.rtu.Main" };
  public static final String SH_COMM_HP = "ps -ef";
  public static final String[] SH_COMM_FILTER_HP = { "java", "manager=org" };
  public static final String RTU_SH_COMM = "ps -eo pid,args";
  public static final String[] RTU_SH_COMM_FILTER = { "_[NP][TM].sh" };
  public static final String RTU_Window_COMM = "systeminfo";
  public static final String[] RTU_Window_COMM_FILTER = { "物理内存总量:" };

  public static final String[] RTU_Window_CMD_FILTER = { "Mhz" };
  public static final String SOLARIS_SUN4U_MEM_CMD = "/usr/sbin/prtconf";
  public static final String[] SOLARIS_SUN4U_MEM_CMD_FILTER = { "Memory size:" };

  public static final String[] WINDOWS_MEM_CMD = { "mem" };
  public static final String AIX_MEM_CMD = "/usr/sbin/prtconf";
  public static final String HP_MEM_CMD = "top -d 1";
  public static final String AIX_MEM_CMD_FILTER = "内存大小";
  public static final String AIX_CPU_COUNT = "处理器数";
  public static final String AIX_CPU_TIMECLOCK = "处理器时钟速度";
  public static final String AIX_CURRENTCPU_COM = "vmstat";
  public static final String AIX_JRTUCPU_COM = "ps -eo user,pcpu,pmem,args";
  public static final String AIX_STOPJRTU_COM = "ps -eo user,pid,args";
  public static final String HP_MEM_CMD_FILTER = "Memory";
  public static final String HP_UX_MEM_CMD = "machinfo";
  public static final String HP_UX_CPU_COUNT = "Number of CPUs";
  public static final String HP_UX_CPU_TIMECLOCK = "Clock speed";
  public static final String HP_UX_MEM_CMD_FILTER = "Memory =";
  public static final String HP_UX_CURRENTCPU_COM = "top -d 1";
  public static final String HP_UX_STOPJRTU_COM = "ps -ef|grep java";
  public static final String SOLARIS_SUN4U_CPU_CMD = "/usr/platform/sun4u/sbin/prtdiag";
  public static final String[] SOLARIS_SUN4U_CPU_CMD_FILTER = { "[0-9]+ MHz" };
  public static final String SOLARIS_MEM_CMD_FILTER = "Memory size";
  public static final String SOLARIS_CURRENTCUP_COM = "vmstat";
  public static final String SOLARIS_JRTUCPU_COM = "ps -eo user,pcpu,pmem,args,comm|grep java";
  public static final String SOLARIS_STOPJRTU_COM = "ps -ef|grep java";
  public static final String WINDOWS_CPU_CMD = "";
  public static final String AIX_CPU_CMD = "/usr/sbin/prtconf";
  public static final String[] AIX_CPU_CMD_FILTER = { "[0-9][0-9][0-9] MHz" };

  public static final String[] HP_UX_CPU_CMD_FILTER = { "[0-9]+ MHz" };
  public static final String SYSTEM_LOG_APPENDER = "org.apache.log4j.WriterAppender.SystemLog";
  public static final String SYSTEM_LOG_READER = "java.io.LineNumberReader.SystemLog";
}