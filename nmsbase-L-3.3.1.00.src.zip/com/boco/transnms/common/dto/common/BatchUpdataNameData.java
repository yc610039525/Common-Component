package com.boco.transnms.common.dto.common;

import java.io.Serializable;

public class BatchUpdataNameData
  implements Serializable
{
  String siteName;
  String siteCuid;
  String roomName;
  String roomCuid;
  String shelfType;
  String oldShelfName;
  String newShelfName;
  String shelfCuid;
  String seprator;
  String nameRule;
  String templateName;
  String templateCuid;
  public static final String ODF = "ODF";
  public static final String DDF = "DDF";
  public static final String MISCRACK = "综合机架";
  public static final String SHELF_MODULE_PORT = "机架名称+分隔符+模块编号+分隔符+端子编号";
  public static final String SHELF_PORT = "机架名称+分隔符+端子编号";

  public String getTemplateCuid()
  {
    return this.templateCuid;
  }

  public void setTemplateCuid(String templateCuid) {
    this.templateCuid = templateCuid;
  }

  public String getSiteName() {
    return this.siteName;
  }

  public void setSiteName(String siteName) {
    this.siteName = siteName;
  }

  public String getSiteCuid() {
    return this.siteCuid;
  }

  public void setSiteCuid(String siteCuid) {
    this.siteCuid = siteCuid;
  }

  public String getRoomName() {
    return this.roomName;
  }

  public void setRoomName(String roomName) {
    this.roomName = roomName;
  }

  public String getRoomCuid() {
    return this.roomCuid;
  }

  public void setRoomCuid(String roomCuid) {
    this.roomCuid = roomCuid;
  }

  public String getOldShelfName() {
    return this.oldShelfName;
  }

  public void setOldShelfName(String oldShelfName) {
    this.oldShelfName = oldShelfName;
  }

  public String getNewShelfName()
  {
    return this.newShelfName;
  }

  public void setNewShelfName(String newShelfName) {
    this.newShelfName = newShelfName;
  }

  public String getShelfCuid() {
    return this.shelfCuid;
  }

  public void setShelfCuid(String shelfCuid) {
    this.shelfCuid = shelfCuid;
  }

  public String getSeprator() {
    return this.seprator;
  }

  public void setSeprator(String seprator) {
    this.seprator = seprator;
  }

  public String getNameRule() {
    return this.nameRule;
  }

  public void setNameRule(String nameRule) {
    this.nameRule = nameRule;
  }

  public String getTemplateName() {
    return this.templateName;
  }

  public void setTemplateName(String templateName) {
    this.templateName = templateName;
  }

  public String getShelfType() {
    return this.shelfType;
  }

  public void setShelfType(String shelfType) {
    this.shelfType = shelfType;
  }
}