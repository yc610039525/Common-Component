package com.boco.transnms.common.dto.common;

import java.io.Serializable;

public class ClientState
  implements Serializable
{
  private String clientName;
  private String clientAddress;
  private String clientType;
  private static final long serialVersionUID = 1L;

  public ClientState(String clientName, String clientType, String clientAddress)
  {
    this.clientName = clientName;
    this.clientType = clientType;
    this.clientAddress = clientAddress;
  }

  public String getClientAddress() {
    return this.clientAddress;
  }

  public String getClientName() {
    return this.clientName;
  }

  public String getClientType() {
    return this.clientType;
  }

  public void setClientAddress(String clientAddress) {
    this.clientAddress = clientAddress;
  }

  public void setClientName(String clientName) {
    this.clientName = clientName;
  }

  public void setClientType(String clientType) {
    this.clientType = clientType;
  }

  public String toMessage() {
    return this.clientType + "," + this.clientName + "," + this.clientAddress;
  }
}