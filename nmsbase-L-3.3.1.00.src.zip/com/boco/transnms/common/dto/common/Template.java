package com.boco.transnms.common.dto.common;

import com.boco.transnms.common.dto.base.DboBlob;
import com.boco.transnms.common.dto.base.GenericDO;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Template extends GenericDO
{
  public static final String CLASS_NAME = "TEMPLATE";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public Template()
  {
    super("TEMPLATE");
    initAttrTypes();
  }

  protected void initAttrTypes()
  {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("NAME", String.class);
    this.attrTypeMap.put("TYPE", Long.TYPE);
    this.attrTypeMap.put("CREATEUSER", String.class);
    this.attrTypeMap.put("CREATETIME", Timestamp.class);
    this.attrTypeMap.put("PIC", DboBlob.class);
    this.attrTypeMap.put("DATAPIC", DboBlob.class);
    this.attrTypeMap.put("RELATED_TEMPLATEGROUP_CUID", String.class);
    this.attrTypeMap.put("RELATED_VENDOR_CUID", String.class);
    this.attrTypeMap.put("SIGNAL_TYPE", Long.TYPE);
    this.attrTypeMap.put("MODEL", String.class);
  }

  public void setCuid(String cuid)
  {
    setAttrValue("CUID", cuid);
  }

  public String getCuid() {
    return getAttrString("CUID");
  }

  public void setName(String name) {
    setAttrValue("NAME", name);
  }

  public String getName() {
    return getAttrString("NAME");
  }

  public void setType(long type) {
    setAttrValue("TYPE", type);
  }

  public long getType() {
    return getAttrLong("TYPE");
  }

  public void setCreateUser(String user) {
    setAttrValue("CREATEUSER", user);
  }

  public String getCreateUser() {
    return getAttrString("CREATEUSER");
  }

  public void setCreateTime(Timestamp stamp) {
    setAttrValue("CREATETIME", stamp);
  }

  public Timestamp getCreateTime() {
    return getAttrDateTime("CREATETIME");
  }

  public void setPic(DboBlob blob) {
    setAttrValue("PIC", blob);
  }

  public DboBlob getPic() {
    return getAttrBlob("PIC");
  }

  public void setDataPic(DboBlob blob) {
    setAttrValue("DATAPIC", blob);
  }

  public DboBlob getDataPic() {
    return getAttrBlob("DATAPIC");
  }

  public void setRelatedTemplategroupCuid(String RelatedTemplategroupCuid) {
    setAttrValue("RELATED_TEMPLATEGROUP_CUID", RelatedTemplategroupCuid);
  }

  public String getRelatedTemplategroupCuid() {
    return getAttrString("RELATED_TEMPLATEGROUP_CUID");
  }

  public void setRelatedVendorCuid(String RelatedVendorCuid) {
    setAttrValue("RELATED_VENDOR_CUID", RelatedVendorCuid);
  }

  public String getRelatedVendorCuid() {
    return getAttrString("RELATED_VENDOR_CUID");
  }

  public void setSignalType(long SignalType) {
    setAttrValue("SIGNAL_TYPE", SignalType);
  }

  public long getSignalType() {
    return getAttrLong("SIGNAL_TYPE");
  }

  public void setModel(String Model) {
    setAttrValue("MODEL", Model);
  }

  public String getModel() {
    return getAttrString("MODEL");
  }

  public String[] getAllAttrNames()
  {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public static class AttrName
  {
    public static final String Cuid = "CUID";
    public static final String Name = "NAME";
    public static final String Type = "TYPE";
    public static final String CreateUser = "CREATEUSER";
    public static final String CreateTime = "CREATETIME";
    public static final String Pic = "PIC";
    public static final String DataPic = "DATAPIC";
    public static final String RelatedTemplategroupCuid = "RELATED_TEMPLATEGROUP_CUID";
    public static final String RelatedVendorCuid = "RELATED_VENDOR_CUID";
    public static final String SignalType = "SIGNAL_TYPE";
    public static final String Model = "MODEL";
  }
}