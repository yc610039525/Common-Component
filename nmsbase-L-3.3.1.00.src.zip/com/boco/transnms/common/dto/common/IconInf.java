package com.boco.transnms.common.dto.common;

import com.boco.transnms.common.dto.base.DboBlob;
import com.boco.transnms.common.dto.base.GenericDO;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class IconInf extends GenericDO
{
  public static final String CLASS_NAME = "ICONINF";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public IconInf()
  {
    super("ICONINF");
    initAttrTypes();
  }

  protected void initAttrTypes()
  {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("LABEL_CN", String.class);
    this.attrTypeMap.put("TYPE", Long.TYPE);
    this.attrTypeMap.put("CREATEUSER", String.class);
    this.attrTypeMap.put("CREATETIME", Timestamp.class);
    this.attrTypeMap.put("PIC", DboBlob.class);
  }

  public void setCuid(String cuid)
  {
    setAttrValue("CUID", cuid);
  }

  public String getCuid() {
    return getAttrString("CUID");
  }

  public void setLabelCn(String labelCn) {
    setAttrValue("LABEL_CN", labelCn);
  }

  public String getLabelCn() {
    return getAttrString("LABEL_CN");
  }

  public void setType(long type) {
    setAttrValue("TYPE", type);
  }

  public long getType() {
    return getAttrLong("TYPE");
  }

  public void setCreateUser(String user) {
    setAttrValue("CREATEUSER", user);
  }

  public String getCreateUser() {
    return getAttrString("CREATEUSER");
  }

  public void setCreateTime(Timestamp stamp) {
    setAttrValue("CREATETIME", stamp);
  }

  public Timestamp getCreateTime() {
    return getAttrDateTime("CREATETIME");
  }

  public void setPic(DboBlob blob) {
    setAttrValue("PIC", blob);
  }

  public DboBlob getPic() {
    return getAttrBlob("PIC");
  }

  public String[] getAllAttrNames()
  {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public static class AttrName
  {
    public static final String Cuid = "CUID";
    public static final String labelCn = "LABEL_CN";
    public static final String Type = "TYPE";
    public static final String CreateUser = "CREATEUSER";
    public static final String CreateTime = "CREATETIME";
    public static final String Pic = "PIC";
  }
}