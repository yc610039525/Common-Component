package com.boco.transnms.common.dto.common;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class ReportNode extends GenericDO
{
  public static final String CLASS_NAME = "REPORT_NODE";
  private static Map<String, Class> attrTypeMap = new HashMap();

  public ReportNode()
  {
    super("REPORT_NODE");
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[attrTypeMap.size()];
    attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  public Class getAttrType(String attrName) {
    return (Class)attrTypeMap.get(attrName);
  }

  public void setArea(String area) {
    super.setAttrValue("AREA", area);
  }
  public void setFunctionNodeIDs(String functionNodeIDs) {
    super.setAttrValue("FUNCTION_NODE_IDS", functionNodeIDs);
  }
  public void setIsVisible(boolean isVisible) {
    super.setAttrValue("IS_VISIBLE", isVisible);
  }
  public void setOrder(long order) {
    super.setAttrValue("ORDER", order);
  }
  public void setParentNodeId(String parentNodeId) {
    super.setAttrValue("PARENT_NODE_ID", parentNodeId);
  }
  public void setProductSp(String productSp) {
    super.setAttrValue("PRODUCT_SP", productSp);
  }
  public void setReportId(String reportId) {
    super.setAttrValue("REPORT_ID", reportId);
  }
  public void setReportName(String reportName) {
    super.setAttrValue("REPORT_NAME", reportName);
  }
  public void setUrl(String url) {
    super.setAttrValue("URL", url);
  }
  public void setUrlType(String urlType) {
    super.setAttrValue("URL_TYPE", urlType);
  }
  public void setDownloadFileName(String downloadFileName) {
    super.setAttrValue("DOWNLOAD_FILE_NAME", downloadFileName);
  }

  public void setReportEnglishName(String reportEnglishName) {
    super.setAttrValue("REPORT_ENGLISH_NAME", reportEnglishName);
  }

  public String getArea()
  {
    return super.getAttrString("AREA");
  }
  public String getFunctionNodeIDs() {
    return super.getAttrString("FUNCTION_NODE_IDS");
  }
  public boolean getIsVisible() {
    return super.getAttrBool("IS_VISIBLE");
  }
  public long getoOrder() {
    return super.getAttrLong("ORDER");
  }
  public String getParentNodeId() {
    return super.getAttrString("PARENT_NODE_ID");
  }
  public String getProductSp() {
    return super.getAttrString("PRODUCT_SP");
  }
  public String getReportId() {
    return super.getAttrString("REPORT_ID");
  }

  public String getReportName() {
    return super.getAttrString("REPORT_NAME");
  }
  public String getUrl() {
    return super.getAttrString("URL");
  }
  public String getUrlType() {
    return super.getAttrString("URL_TYPE");
  }
  public String getDownloadFileName() {
    return super.getAttrString("DOWNLOAD_FILE_NAME");
  }

  public String getReportEnglishName() {
    return super.getAttrString("REPORT_ENGLISH_NAME");
  }

  static
  {
    attrTypeMap.put("REPORT_NAME", String.class);
    attrTypeMap.put("IS_VISIBLE", Boolean.TYPE);
    attrTypeMap.put("PRODUCT_SP", String.class);
    attrTypeMap.put("AREA", String.class);
    attrTypeMap.put("ORDER", Long.TYPE);

    attrTypeMap.put("REPORT_ID", String.class);
    attrTypeMap.put("PARENT_NODE_ID", String.class);
    attrTypeMap.put("URL_TYPE", String.class);
    attrTypeMap.put("URL", String.class);
    attrTypeMap.put("FUNCTION_NODE_IDS", String.class);
    attrTypeMap.put("DOWNLOAD_FILE_NAME", String.class);
    attrTypeMap.put("REPORT_ENGLISH_NAME", String.class);
  }

  public static class AttrName
  {
    public static final String reportName = "REPORT_NAME";
    public static final String isVisible = "IS_VISIBLE";
    public static final String productSp = "PRODUCT_SP";
    public static final String area = "AREA";
    public static final String order = "ORDER";
    public static final String reportId = "REPORT_ID";
    public static final String parentNodeId = "PARENT_NODE_ID";
    public static final String urlType = "URL_TYPE";
    public static final String url = "URL";
    public static final String functionNodeIDs = "FUNCTION_NODE_IDS";
    public static final String downloadFileName = "DOWNLOAD_FILE_NAME";
    public static final String reportEnglishName = "REPORT_ENGLISH_NAME";
  }
}