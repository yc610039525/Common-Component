package com.boco.transnms.common.dto.common;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class DtoCacheModel extends GenericDO
{
  public static final String CLASS_NAME = "DTO_CACHE_MODEL";
  private static Map<String, Class> attrTypeMap = new HashMap();

  public DtoCacheModel()
  {
    super("DTO_CACHE_MODEL");
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[attrTypeMap.size()];
    attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  public Class getAttrType(String attrName) {
    return (Class)attrTypeMap.get(attrName);
  }

  public void setClassId(String classId) {
    super.setAttrValue("CLASS_ID", classId);
  }

  public void setClassLabelCn(String classLabelCn) {
    super.setAttrValue("CLASS_LABEL_CN", classLabelCn);
  }

  public void setIsDynamic(boolean isDynamic) {
    super.setAttrValue("IS_DYNAMIC", isDynamic);
  }

  public String getClassId() {
    return super.getAttrString("CLASS_ID");
  }

  public String getClassLabelCn() {
    return super.getAttrString("CLASS_LABEL_CN");
  }

  public boolean getIsDynamic() {
    return super.getAttrBool("IS_DYNAMIC");
  }

  static
  {
    attrTypeMap.put("CLASS_ID", String.class);
    attrTypeMap.put("CLASS_LABEL_CN", String.class);
    attrTypeMap.put("IS_DYNAMIC", Boolean.TYPE);
  }

  public static class AttrName
  {
    public static final String classId = "CLASS_ID";
    public static final String classLabelCn = "CLASS_LABEL_CN";
    public static final String isDynamic = "IS_DYNAMIC";
  }
}