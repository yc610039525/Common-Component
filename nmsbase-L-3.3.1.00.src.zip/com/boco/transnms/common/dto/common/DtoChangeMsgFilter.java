package com.boco.transnms.common.dto.common;

import com.boco.raptor.common.message.IMessage;
import com.boco.raptor.common.message.IMessageFilter;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.dao.base.CachedDtoMessage;
import java.util.HashMap;

public class DtoChangeMsgFilter
  implements IMessageFilter
{
  private HashMap interestDtoMap = new HashMap();
  private String sessionId;

  public DtoChangeMsgFilter(HashMap interestDtoMap)
  {
    this.interestDtoMap = interestDtoMap;
  }

  public boolean isMsgPublish(IMessage msg) {
    boolean isMsgPublish = false;
    if ((msg instanceof CachedDtoMessage)) {
      DataObjectList msgDtos = ((CachedDtoMessage)msg).getMsgDtos();
      if ((msgDtos != null) && (msgDtos.size() > 0)) {
        GenericDO dbo = (GenericDO)msgDtos.get(0);
        if (this.interestDtoMap.containsKey(dbo.getClassName())) {
          isMsgPublish = true;
        }
      }
    }
    return isMsgPublish;
  }

  public void setFilterPara(Object filterPara) {
    if (filterPara != null)
      this.interestDtoMap = ((HashMap)filterPara);
  }

  public String getFilterName()
  {
    return "DTO_MSG_FILTER";
  }

  public IMessageFilter cloneFilter() {
    return new DtoChangeMsgFilter(this.interestDtoMap);
  }

  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }

  public String getSessionId() {
    return this.sessionId;
  }
}