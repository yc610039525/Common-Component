package com.boco.transnms.common.dto.common;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class DistrictTreeFilter extends GenericDO
{
  public static final String CLASS_NAME = "DISTRICT_TREE_FILTER";
  private static Map<String, Class> attrTypeMap = new HashMap();

  public DistrictTreeFilter()
  {
    super("DISTRICT_TREE_FILTER");
    setAllowLayerA(0);
    setAllowLayerZ(5);
    setHideLayer(0);
    setIsMultiple(false);
    setLimitDistrict("");
    setMaxOpenLayer(5);
    setPreOpenLayer(2);
    setSource("securityDis");
  }

  public String[] getAllAttrNames()
  {
    String[] attrNames = new String[attrTypeMap.size()];
    attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  public Class getAttrType(String attrName) {
    return (Class)attrTypeMap.get(attrName);
  }

  public void setIsMultiple(boolean isMultiple) {
    super.setAttrValue("IS_MULTIPLE", isMultiple);
  }

  public void setPreOpenLayer(int preOpenLayer) {
    super.setAttrValue("PRE_OPEN_LAYER", preOpenLayer);
  }

  public void setHideLayer(int hideLayer) {
    super.setAttrValue("HIDE_LAYER", hideLayer);
  }

  public void setMaxOpenLayer(int maxOpenLayer) {
    super.setAttrValue("MAX_OPEN_LAYER", maxOpenLayer);
  }

  public void setAllowLayerA(int allowLayerA) {
    super.setAttrValue("OPERATE_LAYER_A", allowLayerA);
  }

  public void setAllowLayerZ(int allowLayerZ) {
    super.setAttrValue("OPERATE_LAYER_Z", allowLayerZ);
  }

  public void setLimitDistrict(String limitDistrict) {
    super.setAttrValue("LIMIT_DISTRICT", limitDistrict);
  }

  public void setSource(String source) {
    super.setAttrValue("SOURCE", source);
  }

  public boolean getIsMultiple()
  {
    return super.getAttrBool("IS_MULTIPLE");
  }

  public int getPreOpenLayer() {
    return super.getAttrInt("PRE_OPEN_LAYER");
  }

  public int getHideLayer() {
    return super.getAttrInt("HIDE_LAYER");
  }

  public int getMaxOpenLayer() {
    return super.getAttrInt("MAX_OPEN_LAYER");
  }

  public int getAllowLayerA() {
    return super.getAttrInt("OPERATE_LAYER_A");
  }

  public int getAllowLayerZ() {
    return super.getAttrInt("OPERATE_LAYER_Z");
  }

  public String getLimitDistrict() {
    return super.getAttrString("LIMIT_DISTRICT");
  }

  public String getSorce() {
    return super.getAttrString("SOURCE");
  }

  static
  {
    attrTypeMap.put("IS_MULTIPLE", Boolean.TYPE);
    attrTypeMap.put("PRE_OPEN_LAYER", Integer.TYPE);
    attrTypeMap.put("HIDE_LAYER", Integer.TYPE);
    attrTypeMap.put("MAX_OPEN_LAYER", Integer.TYPE);
    attrTypeMap.put("OPERATE_LAYER_A", Integer.TYPE);
    attrTypeMap.put("OPERATE_LAYER_Z", Integer.TYPE);
    attrTypeMap.put("LIMIT_DISTRICT", String.class);
    attrTypeMap.put("SOURCE", String.class);
  }

  public static class AttrName
  {
    public static final String isMultiple = "IS_MULTIPLE";
    public static final String preOpenLayer = "PRE_OPEN_LAYER";
    public static final String hideLayer = "HIDE_LAYER";
    public static final String maxOpenLayer = "MAX_OPEN_LAYER";
    public static final String allowLayerA = "OPERATE_LAYER_A";
    public static final String allowLayerZ = "OPERATE_LAYER_Z";
    public static final String limitDistrict = "LIMIT_DISTRICT";
    public static final String source = "SOURCE";
  }
}