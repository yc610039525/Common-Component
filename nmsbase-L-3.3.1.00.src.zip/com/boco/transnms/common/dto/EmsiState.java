package com.boco.transnms.common.dto;

import java.io.Serializable;

public class EmsiState
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private String emsiName;
  private boolean emsiState;
  private boolean connectState;

  public String getEmsiName()
  {
    return this.emsiName;
  }
  public void setEmsiName(String emsiName) {
    this.emsiName = emsiName;
  }
  public boolean isEmsiState() {
    return this.emsiState;
  }
  public void setEmsiState(boolean emsiState) {
    this.emsiState = emsiState;
  }
  public boolean isConnectState() {
    return this.connectState;
  }
  public void setConnectState(boolean connectState) {
    this.connectState = connectState;
  }
}