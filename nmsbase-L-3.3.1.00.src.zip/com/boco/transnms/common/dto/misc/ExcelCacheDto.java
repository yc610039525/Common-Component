package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.AttrObject;

public class ExcelCacheDto extends AttrObject
{
  public Object getDataEnum()
  {
    return getAttrArray("DATA_ENUM");
  }

  public void setDataEnum(Object dataEnum) {
    setAttrValue("DATA_ENUM", dataEnum);
  }
  public String getTableName() {
    return getAttrString("TABLE_NAME");
  }

  public void setTableName(String tableName) {
    setAttrValue("TABLE_NAME", tableName);
  }

  public String getCacheId() {
    return getAttrString("CACHE_ID");
  }

  public void setCacheId(String cacheId) {
    setAttrValue("CACHE_ID", cacheId);
  }

  public String getKey() {
    return getAttrString("KEY");
  }

  public void setKey(String key) {
    setAttrValue("KEY", key);
  }

  public String getValue() {
    return getAttrString("VALUE");
  }

  public void setValue(String value) {
    setAttrValue("VALUE", value);
  }

  public static class AttrName
  {
    public static final String tableName = "TABLE_NAME";
    public static final String cacheId = "CACHE_ID";
    public static final String key = "KEY";
    public static final String value = "VALUE";
    public static final String dataEnum = "DATA_ENUM";
  }
}