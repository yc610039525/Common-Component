package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class EmsConversion extends GenericDO
{
  public static final String CLASS_NAME = "EMS_CONVERSION";
  private final Map<String, Class> attrTypeMap = new HashMap();
  private String quartzDate;
  private String useState;

  public EmsConversion()
  {
    super("EMS_CONVERSION");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("MASTER_EMS_CUID", String.class);
    this.attrTypeMap.put("SLAVE_EMS_CUID", String.class);
    this.attrTypeMap.put("CONVERSION_RESULT", Long.TYPE);
    this.attrTypeMap.put("FAILING_REASON", String.class);
    this.attrTypeMap.put("LAST_CONVERSION_TIME", Timestamp.class);
    this.attrTypeMap.put("PREPARATION_CONVERSION_TIME", Timestamp.class);
    this.attrTypeMap.put("SERVICE_MODE", Long.TYPE);
    this.attrTypeMap.put("USE_STATE", Long.TYPE);
    this.attrTypeMap.put("QUARTZ_DATE", String.class);
  }

  public void setMasterEmsCuid(String masterEmsCuid)
  {
    super.setAttrValue("MASTER_EMS_CUID", masterEmsCuid);
  }

  public void setSlaveEmsCuid(String slaveEmsCuid) {
    super.setAttrValue("SLAVE_EMS_CUID", slaveEmsCuid);
  }

  public void setConversionResult(long conversionResult) {
    super.setAttrValue("CONVERSION_RESULT", conversionResult);
  }

  public void setFailingReason(String failingReason) {
    super.setAttrValue("FAILING_REASON", failingReason);
  }

  public void setLastConversionTime(Timestamp lastConversionTime) {
    super.setAttrValue("LAST_CONVERSION_TIME", lastConversionTime);
  }

  public void setPreparationConversionTime(Timestamp preparationConversionTime) {
    super.setAttrValue("PREPARATION_CONVERSION_TIME", preparationConversionTime);
  }

  public void setServiceMode(long serviceMode) {
    super.setAttrValue("SERVICE_MODE", serviceMode);
  }

  public String getMasterEmsCuid() {
    return super.getAttrString("MASTER_EMS_CUID");
  }

  public String getSlaveEmsCuid() {
    return super.getAttrString("SLAVE_EMS_CUID");
  }

  public long getConversionResult() {
    return super.getAttrLong("CONVERSION_RESULT");
  }

  public String getFailingReason() {
    return super.getAttrString("FAILING_REASON");
  }

  public Timestamp getLastConversionTime() {
    return super.getAttrDateTime("LAST_CONVERSION_TIME");
  }

  public Timestamp getPreparationConversionTime() {
    return super.getAttrDateTime("PREPARATION_CONVERSION_TIME");
  }

  public long getServiceMode() {
    return super.getAttrLong("SERVICE_MODE");
  }

  public void setQuartzDate(String quartzDate) {
    super.setAttrValue("QUARTZ_DATE", quartzDate);
  }

  public void setUseState(long useState) {
    super.setAttrValue("USE_STATE", useState);
  }

  public String getQuartzDate() {
    return super.getAttrString("QUARTZ_DATE");
  }

  public long getUseState() {
    return super.getAttrLong("USE_STATE");
  }

  public static class AttrName
  {
    public static final String masterEmsCuid = "MASTER_EMS_CUID";
    public static final String slaveEmsCuid = "SLAVE_EMS_CUID";
    public static final String conversionResult = "CONVERSION_RESULT";
    public static final String failingReason = "FAILING_REASON";
    public static final String lastConversionTime = "LAST_CONVERSION_TIME";
    public static final String preparationConversionTime = "PREPARATION_CONVERSION_TIME";
    public static final String serviceMode = "SERVICE_MODE";
    public static final String useState = "USE_STATE";
    public static final String quartzDate = "QUARTZ_DATE";
  }
}