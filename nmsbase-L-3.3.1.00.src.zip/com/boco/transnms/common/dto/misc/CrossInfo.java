package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class CrossInfo extends GenericDO
{
  public static final String CLASS_NAME = "CROSS_CONNECT";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public CrossInfo()
  {
    super("CROSS_CONNECT");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("NUMBER", String.class);
    this.attrTypeMap.put("RELATED_EMS_NAME", String.class);
    this.attrTypeMap.put("RELATED_NE_NAME", String.class);
    this.attrTypeMap.put("LABEL_CN", String.class);
    this.attrTypeMap.put("ORIG_POINT_CUID", String.class);
    this.attrTypeMap.put("DEST_POINT_CUID", String.class);
    this.attrTypeMap.put("DIRECTION", String.class);
    this.attrTypeMap.put("CROSS_STATE", String.class);
    this.attrTypeMap.put("CROSS_TYPE", String.class);
    this.attrTypeMap.put("REMARK", String.class);
    this.attrTypeMap.put("LAYER_RATE", String.class);
  }

  public void setNumber(String number) {
    super.setAttrValue("NUMBER", number);
  }

  public void setRelatedEmsName(String relatedEmsName) {
    super.setAttrValue("RELATED_EMS_NAME", relatedEmsName);
  }

  public void setRelatedNeName(String relatedNeName) {
    super.setAttrValue("RELATED_NE_NAME", relatedNeName);
  }

  public void setLabelCn(String labelCn) {
    super.setAttrValue("LABEL_CN", labelCn);
  }

  public void setOrigPointCuid(String origPointCuid) {
    super.setAttrValue("ORIG_POINT_CUID", origPointCuid);
  }

  public void setDestPointCuid(String destPointCuid) {
    super.setAttrValue("DEST_POINT_CUID", destPointCuid);
  }

  public void setDirection(String direction) {
    super.setAttrValue("DIRECTION", direction);
  }

  public void setCrossState(String crossState) {
    super.setAttrValue("CROSS_STATE", crossState);
  }

  public void setCrossType(String crossType) {
    super.setAttrValue("CROSS_TYPE", crossType);
  }

  public void setRemark(String remark) {
    super.setAttrValue("REMARK", remark);
  }

  public void setLayerRate(String layerrate)
  {
    super.setAttrValue("LAYER_RATE", layerrate);
  }

  public String getNumber() {
    return super.getAttrString("NUMBER");
  }

  public String getRelatedEmsName() {
    return super.getAttrString("RELATED_EMS_NAME");
  }

  public String getRelatedNeName() {
    return super.getAttrString("RELATED_NE_NAME");
  }

  public String getLabelCn() {
    return super.getAttrString("LABEL_CN");
  }

  public String getOrigPointCuid() {
    return super.getAttrString("ORIG_POINT_CUID");
  }

  public String getDestPointCuid() {
    return super.getAttrString("DEST_POINT_CUID");
  }

  public String getDirection() {
    return super.getAttrString("DIRECTION");
  }

  public String getCrossState() {
    return super.getAttrString("CROSS_STATE");
  }

  public String getCrossType() {
    return super.getAttrString("CROSS_TYPE");
  }

  public String getRemark() {
    return super.getAttrString("REMARK");
  }

  public String getLayerRate()
  {
    return super.getAttrString("LAYER_RATE");
  }

  public static class AttrName
  {
    public static final String number = "NUMBER";
    public static final String relatedEmsName = "RELATED_EMS_NAME";
    public static final String relatedNeName = "RELATED_NE_NAME";
    public static final String labelCn = "LABEL_CN";
    public static final String origPointCuid = "ORIG_POINT_CUID";
    public static final String destPointCuid = "DEST_POINT_CUID";
    public static final String direction = "DIRECTION";
    public static final String crossState = "CROSS_STATE";
    public static final String crossType = "CROSS_TYPE";
    public static final String remark = "REMARK";
    public static final String layerrate = "LAYER_RATE";
  }
}