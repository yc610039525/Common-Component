package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class CallBoard extends GenericDO
{
  public static final String CLASS_NAME = "CALL_BOARD";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public CallBoard()
  {
    super("CALL_BOARD");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("AUTHOR", String.class);
    this.attrTypeMap.put("BEGINDATETIME", Date.class);
    this.attrTypeMap.put("ENDDATETIME", Date.class);
    this.attrTypeMap.put("INFOTITLE", String.class);
    this.attrTypeMap.put("INFOTEXT", String.class);
    this.attrTypeMap.put("CUID", String.class);
  }

  public void setAuthor(String author)
  {
    super.setAttrValue("AUTHOR", author);
  }

  public void setBeginDateTime(Timestamp beginDateTime)
  {
    super.setAttrValue("BEGINDATETIME", beginDateTime);
  }

  public void setEndDateTime(Timestamp endDateTime)
  {
    super.setAttrValue("ENDDATETIME", endDateTime);
  }

  public void setInfoTitle(String infoTitle)
  {
    super.setAttrValue("INFOTITLE", infoTitle);
  }

  public void setInfoText(String infoText)
  {
    super.setAttrValue("INFOTEXT", infoText);
  }

  public void setCuid(String cuid)
  {
    super.setAttrValue("CUID", cuid);
  }

  public String getAuthor()
  {
    return super.getAttrString("AUTHOR");
  }

  public Timestamp getBeginDateTime()
  {
    return super.getAttrDateTime("BEGINDATETIME");
  }

  public Timestamp getEndDateTime()
  {
    return super.getAttrDateTime("ENDDATETIME");
  }

  public String getInfoTitle()
  {
    return super.getAttrString("INFOTITLE");
  }

  public String getInfoText()
  {
    return super.getAttrString("INFOTEXT");
  }

  public String getCuid()
  {
    return super.getAttrString("CUID");
  }

  public static class AttrName
  {
    public static final String author = "AUTHOR";
    public static final String beginDateTime = "BEGINDATETIME";
    public static final String endDateTime = "ENDDATETIME";
    public static final String infoTitle = "INFOTITLE";
    public static final String infoText = "INFOTEXT";
    public static final String cuid = "CUID";
  }
}