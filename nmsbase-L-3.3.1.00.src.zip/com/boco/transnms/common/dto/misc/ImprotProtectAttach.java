package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.DboBlob;
import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class ImprotProtectAttach extends GenericDO
{
  public static final String CLASS_NAME = "IMPORTANT_PROTECT_ATTACH";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public ImprotProtectAttach()
  {
    super("IMPORTANT_PROTECT_ATTACH");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("ATTACH_NAME", String.class);
    this.attrTypeMap.put("ATTACH_DATA", DboBlob.class);
    this.attrTypeMap.put("RELATED_PROTECT_CUID", String.class);
  }

  public void setId(String cuid) {
    super.setAttrValue("CUID", cuid);
  }

  public String getId() {
    return super.getAttrString("CUID");
  }

  public void setAttachFileName(String attachFileName) {
    super.setAttrValue("ATTACH_NAME", attachFileName);
  }

  public String getAttachFileName() {
    return super.getAttrString("ATTACH_NAME");
  }

  public void setAttachData(DboBlob attachData) {
    super.setAttrValue("ATTACH_DATA", attachData);
  }

  public DboBlob getAttachData() {
    return super.getAttrBlob("ATTACH_DATA");
  }

  public void setRelatedProtectCuid(String relatedProtectCuid) {
    super.setAttrValue("RELATED_PROTECT_CUID", relatedProtectCuid);
  }

  public String getRelatedProtectCuid() {
    return super.getAttrString("RELATED_PROTECT_CUID");
  }

  public static class AttrName
  {
    public static final String cuid = "CUID";
    public static final String attachFileName = "ATTACH_NAME";
    public static final String attachData = "ATTACH_DATA";
    public static final String relatedProtectCuid = "RELATED_PROTECT_CUID";
  }
}