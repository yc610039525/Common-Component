package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericEnumDO;

public class SheetState extends GenericEnumDO
{
  public SheetState()
  {
    super("SHEET_STATE");
  }

  protected void initAttrTypes() {
    super.initAttrTypes();
    setAttrType("SHEET_TYPE", Long.TYPE);
  }

  public static class AttrName
  {
    public static final String sheetType = "SHEET_TYPE";
  }
}