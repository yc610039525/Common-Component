package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class SpecialLine extends GenericDO
{
  public static final String CLASS_NAME = "SPECIAL_LINE";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public SpecialLine() {
    super("SPECIAL_LINE");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes()
  {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("SPECIAL_LINE_NUM", String.class);
    this.attrTypeMap.put("SPECIAL_LINE_TYPE", Long.TYPE);
    this.attrTypeMap.put("CUSTOM_SLA", String.class);
    this.attrTypeMap.put("COMPANY_NAME", String.class);
    this.attrTypeMap.put("RELATED_CUSTOM_A_DISTRICT", String.class);
    this.attrTypeMap.put("RELATED_CUSTOM_Z_DISTRICT", String.class);
    this.attrTypeMap.put("SPECIAL_LINE_STATE", Long.TYPE);
    this.attrTypeMap.put("SPECIAL_LINE_USED_DATE", Timestamp.class);
    this.attrTypeMap.put("REVOCATION_DATE", Timestamp.class);
    this.attrTypeMap.put("UPDATE_DATE", Timestamp.class);
    this.attrTypeMap.put("UPDATE_USER", String.class);
    this.attrTypeMap.put("SPECIAL_LINE_NOTES", String.class);

    this.attrTypeMap.put("RELATED_COMPANY_NAME_CN", String.class);
    this.attrTypeMap.put("RELATED_COMPANY_NAME_EN", String.class);
    this.attrTypeMap.put("RELATED_COMPANY_KIND_ID", Long.TYPE);
    this.attrTypeMap.put("RELATED_COMPANY_INDUSTRY_ID", Long.TYPE);
    this.attrTypeMap.put("RELATED_COMPANY_PRIVICE", Long.TYPE);
    this.attrTypeMap.put("RELATED_COMPANY_CITY", Long.TYPE);
    this.attrTypeMap.put("RELATED_COMPANY_COUNTY", Long.TYPE);
    this.attrTypeMap.put("RELATED_COMPANY_ADDR", String.class);
    this.attrTypeMap.put("SPECIAL_LINE_ACCESS_ADDR", String.class);
    this.attrTypeMap.put("LINE_SERVICE_CONTACT", String.class);
    this.attrTypeMap.put("LINE_SERVICE_CONTACT_PHONE", String.class);
    this.attrTypeMap.put("LINE_SERVICE_CONTACT_EMAIL", String.class);
    this.attrTypeMap.put("LINE_TECN_CONTACT", String.class);
    this.attrTypeMap.put("LINE_TECN_CONTACT_PHONE", String.class);
    this.attrTypeMap.put("LINE_TECN_CONTACT_EMAIL", String.class);

    this.attrTypeMap.put("SALES_DEPARTMENT", String.class);
    this.attrTypeMap.put("ACCOUNT_MANAGER", String.class);
    this.attrTypeMap.put("ACCOUNT_MANAGER_PHONE", String.class);
    this.attrTypeMap.put("CHIEF_ACCOUNT_MANAGER", String.class);
    this.attrTypeMap.put("AGENTS", String.class);
    this.attrTypeMap.put("AGENTS_PHONE", String.class);

    this.attrTypeMap.put("BASIC_LINE_NO", String.class);
    this.attrTypeMap.put("BASIC_LINE_TYPE", Long.TYPE);
    this.attrTypeMap.put("BASIC_BAND_WIDTH", String.class);
    this.attrTypeMap.put("BASIC_CUSTOMER_PROPERTY", Long.TYPE);
    this.attrTypeMap.put("BASIC_APP_PROPERTY", String.class);
    this.attrTypeMap.put("BASIC_CUSTOM_SLA", String.class);
    this.attrTypeMap.put("CURRENT_NETWORK_LEVEL", String.class);
    this.attrTypeMap.put("DEMAND_NETWORK_LEVEL", String.class);
    this.attrTypeMap.put("TARGET_NETWORK_LEVEL", String.class);
    this.attrTypeMap.put("BASIC_DROP_OPEN", String.class);
    this.attrTypeMap.put("RECTIFICATION_PERIOD", String.class);
    this.attrTypeMap.put("BASIC_LINE_STATE", Long.TYPE);
    this.attrTypeMap.put("BASIC_USED_DATE", Timestamp.class);
    this.attrTypeMap.put("BASIC_REVOCATION_DATE", Timestamp.class);
    this.attrTypeMap.put("BASIC_CUSTOM_A_DISTRICT", String.class);
    this.attrTypeMap.put("BASIC_CUSTOM_Z_DISTRICT", String.class);
    this.attrTypeMap.put("BASIC_CUSTOM_ACCESS_A_EQUIP", String.class);
    this.attrTypeMap.put("BASIC_CUSTOM_ACCESS_Z_EQUIP", String.class);
    this.attrTypeMap.put("BASIC_CUSTOM_ACCESS_A_TYPE", String.class);
    this.attrTypeMap.put("BASIC_CUSTOM_ACCESS_Z_TYPE", String.class);

    this.attrTypeMap.put("SPECIAL_LINE_BUREAU_IP", String.class);
    this.attrTypeMap.put("SPECIAL_LINE_CUSTOM_IP", String.class);
    this.attrTypeMap.put("SPECIAL_LINE_CUSTOM_ORIG_IP", String.class);
    this.attrTypeMap.put("SPECIAL_LINE_CUSTOM_DEST_IP", String.class);
    this.attrTypeMap.put("USED_STATE", Long.TYPE);
    this.attrTypeMap.put("USED_TYPE", Long.TYPE);
    this.attrTypeMap.put("USED_TIME", Timestamp.class);
    this.attrTypeMap.put("DATA_VLAN", String.class);
    this.attrTypeMap.put("CMNET_ACCESS_POINT", String.class);
    this.attrTypeMap.put("CMNET_ACCESS_EQUIP", String.class);
    this.attrTypeMap.put("CMNET_PORT_TYPE", String.class);
    this.attrTypeMap.put("CMNET_PORT_NO", String.class);
    this.attrTypeMap.put("REVERSE_DNS", String.class);
    this.attrTypeMap.put("TCP_PORT", String.class);
    this.attrTypeMap.put("DATA_NOTES", String.class);

    this.attrTypeMap.put("SWITCH_ACCESS_POINT", String.class);
    this.attrTypeMap.put("SWITCH_ACCESS_EQUIP", String.class);
    this.attrTypeMap.put("SWITCH_ACCESS_MODULE", String.class);
    this.attrTypeMap.put("SWITCH_ODF_DDF", String.class);
    this.attrTypeMap.put("SWITCH_NOTES", String.class);

    this.attrTypeMap.put("TRANS_ACCESS_A_POINT", String.class);
    this.attrTypeMap.put("TRANS_ACCESS_Z_POINT", String.class);
    this.attrTypeMap.put("TRANS_ROUTE", String.class);
    this.attrTypeMap.put("TRANS_ROUTE_A", String.class);
    this.attrTypeMap.put("TRANS_ROUTE_B", String.class);
    this.attrTypeMap.put("TRANS_ROUTE_C", String.class);
    this.attrTypeMap.put("TRANS_ROUTE_D", String.class);
    this.attrTypeMap.put("TRANS_ROUTE_E", String.class);
    this.attrTypeMap.put("TRANS_THIRD_PARTY_DATA", String.class);
    this.attrTypeMap.put("TRANS_TOPO_LINK", String.class);
    this.attrTypeMap.put("TRANS_PHYSICS_LINK", String.class);
    this.attrTypeMap.put("TRANS_NOTES", String.class);

    this.attrTypeMap.put("USER_BUREAU_A_EQUIP", String.class);
    this.attrTypeMap.put("USER_BUREAU_Z_EQUIP", String.class);
    this.attrTypeMap.put("USER_BUREAU_A_EQUIP_ADDR", String.class);
    this.attrTypeMap.put("USER_BUREAU_Z_EQUIP_ADDR", String.class);
    this.attrTypeMap.put("USER_NOTES", String.class);
  }

  public String getAccountManager()
  {
    return getAttrString("ACCOUNT_MANAGER");
  }

  public String getAccountManagerPhone() {
    return getAttrString("ACCOUNT_MANAGER_PHONE");
  }

  public String getAgents() {
    return getAttrString("AGENTS");
  }

  public String getAgentsPhone() {
    return getAttrString("AGENTS_PHONE");
  }

  public String getBasicAppProperty() {
    return getAttrString("BASIC_APP_PROPERTY");
  }

  public String getBasicBandWidth() {
    return getAttrString("BASIC_BAND_WIDTH");
  }

  public String getBasicCustomAccessAEquip() {
    return getAttrString("BASIC_CUSTOM_ACCESS_A_EQUIP");
  }

  public String getBasicCustomAccessAType() {
    return getAttrString("BASIC_CUSTOM_ACCESS_A_TYPE");
  }

  public String getBasicCustomAccessZEquip() {
    return getAttrString("BASIC_CUSTOM_ACCESS_Z_EQUIP");
  }

  public String getBasicCustomAccessZType() {
    return getAttrString("BASIC_CUSTOM_ACCESS_Z_TYPE");
  }

  public long getBasicCustomerProperty() {
    return getAttrLong("BASIC_CUSTOMER_PROPERTY");
  }

  public String getBasicCustomSla() {
    return getAttrString("BASIC_CUSTOM_SLA");
  }

  public String getBasicDropOpen() {
    return getAttrString("BASIC_DROP_OPEN");
  }

  public String getBasicLineNo() {
    return getAttrString("BASIC_LINE_NO");
  }

  public long getBasicLineState() {
    return getAttrLong("BASIC_LINE_STATE", 0L);
  }

  public long getBasicLineType() {
    return getAttrLong("BASIC_LINE_TYPE");
  }

  public Timestamp getBasicRevocationDate() {
    return getAttrDateTime("BASIC_REVOCATION_DATE");
  }

  public Timestamp getBasicUsedDate() {
    return getAttrDateTime("BASIC_USED_DATE");
  }

  public String getChiefAccountManager() {
    return getAttrString("CHIEF_ACCOUNT_MANAGER");
  }

  public String getCmnetAccessEquip() {
    return getAttrString("CMNET_ACCESS_EQUIP");
  }

  public String getCmnetAccessPoint() {
    return getAttrString("CMNET_ACCESS_POINT");
  }

  public String getCmnetPortNo() {
    return getAttrString("CMNET_PORT_NO");
  }

  public String getCmnetPortType() {
    return getAttrString("CMNET_PORT_TYPE");
  }

  public String getCompanyName() {
    return getAttrString("COMPANY_NAME");
  }

  public String getCuid() {
    return getAttrString("CUID");
  }

  public String getCurrentNetworkLevel() {
    return getAttrString("CURRENT_NETWORK_LEVEL");
  }

  public String getCustomSLA() {
    return getAttrString("CUSTOM_SLA");
  }

  public String getDataNotes() {
    return getAttrString("DATA_NOTES");
  }

  public String getDataVlan() {
    return getAttrString("DATA_VLAN");
  }

  public String getDemandNetworkLevel() {
    return getAttrString("DEMAND_NETWORK_LEVEL");
  }

  public String getLineServiceContact() {
    return getAttrString("LINE_SERVICE_CONTACT");
  }

  public String getLineServiceContactEmail() {
    return getAttrString("LINE_SERVICE_CONTACT_EMAIL");
  }

  public String getLineServiceContactPhone() {
    return getAttrString("LINE_SERVICE_CONTACT_PHONE");
  }

  public String getLineTecnContact() {
    return getAttrString("LINE_TECN_CONTACT");
  }

  public String getLineTecnContactEmail() {
    return getAttrString("LINE_TECN_CONTACT_EMAIL");
  }

  public String getLineTecnContactPhone() {
    return getAttrString("LINE_TECN_CONTACT_PHONE");
  }

  public String getSpecialLineNum() {
    return getAttrString("SPECIAL_LINE_NUM");
  }

  public String getSpecialLineNotes() {
    return getAttrString("SPECIAL_LINE_NOTES");
  }

  public String getRectificationPeriod() {
    return getAttrString("RECTIFICATION_PERIOD");
  }

  public String getRelatedBasicCompanyNameCn() {
    return getAttrString("RELATED_COMPANY_NAME_CN");
  }

  public String getRelatedBasicCompanyNameEn() {
    return getAttrString("RELATED_COMPANY_NAME_EN");
  }

  public String getRelatedBasicCustomADistrict() {
    return getAttrString("BASIC_CUSTOM_A_DISTRICT");
  }

  public String getRelatedBasicCustomZDistrict() {
    return getAttrString("BASIC_CUSTOM_Z_DISTRICT");
  }

  public String getRelatedCompanyAddr() {
    return getAttrString("RELATED_COMPANY_ADDR");
  }

  public long getRelatedCompanyCity() {
    return getAttrLong("RELATED_COMPANY_CITY");
  }

  public long getRelatedCompanyCounty() {
    return getAttrLong("RELATED_COMPANY_COUNTY");
  }

  public long getSpecialLineState() {
    return getAttrLong("SPECIAL_LINE_STATE", 0L);
  }

  public long getSpecialLineType() {
    return getAttrLong("SPECIAL_LINE_TYPE", 0L);
  }

  public String getSwitchAccessEquip() {
    return getAttrString("SWITCH_ACCESS_EQUIP");
  }

  public String getSwitchAccessModule() {
    return getAttrString("SWITCH_ACCESS_MODULE");
  }

  public String getSwitchAccessPoint() {
    return getAttrString("SWITCH_ACCESS_POINT");
  }

  public String getSwitchNotes() {
    return getAttrString("SWITCH_NOTES");
  }

  public String getSwitchOdfDdf() {
    return getAttrString("SWITCH_ODF_DDF");
  }

  public String getTargetNetworkLevel() {
    return getAttrString("TARGET_NETWORK_LEVEL");
  }

  public String getTcpPort() {
    return getAttrString("TCP_PORT");
  }

  public String getTransAccessAPoint() {
    return getAttrString("TRANS_ACCESS_A_POINT");
  }

  public String getTransAccessZPoint() {
    return getAttrString("TRANS_ACCESS_Z_POINT");
  }

  public String getTransNotes() {
    return getAttrString("TRANS_NOTES");
  }

  public String getTransPhysicsLink() {
    return getAttrString("TRANS_PHYSICS_LINK");
  }

  public String getTransRoute() {
    return getAttrString("TRANS_ROUTE");
  }

  public String getTransRouteA() {
    return getAttrString("TRANS_ROUTE_A");
  }

  public String getTransRouteB() {
    return getAttrString("TRANS_ROUTE_B");
  }

  public String getTransRouteC() {
    return getAttrString("TRANS_ROUTE_C");
  }

  public String getTransRouteD() {
    return getAttrString("TRANS_ROUTE_D");
  }

  public String getTransRouteE() {
    return getAttrString("TRANS_ROUTE_E");
  }

  public String getTransThirdPartyData() {
    return getAttrString("TRANS_THIRD_PARTY_DATA");
  }

  public String getTransTopoLink() {
    return getAttrString("TRANS_TOPO_LINK");
  }

  public Timestamp getUpdateDate() {
    return getAttrDateTime("UPDATE_DATE");
  }

  public String getUpdateUser() {
    return getAttrString("UPDATE_USER");
  }

  public Timestamp getSpecialLineUsedDate() {
    return getAttrDateTime("SPECIAL_LINE_USED_DATE");
  }

  public long getUsedState() {
    return getAttrLong("USED_STATE", 0L);
  }

  public Timestamp getUsedTime() {
    return getAttrDateTime("USED_TIME");
  }

  public long getUsedType() {
    return getAttrLong("USED_TYPE", 1L);
  }

  public String getUserBureauAEquip() {
    return getAttrString("USER_BUREAU_A_EQUIP");
  }

  public String getUserBureauAEquipAddr() {
    return getAttrString("USER_BUREAU_A_EQUIP_ADDR");
  }

  public String getUserBureauZEquip() {
    return getAttrString("USER_BUREAU_Z_EQUIP");
  }

  public String getUserBureauZEquipAddr() {
    return getAttrString("USER_BUREAU_Z_EQUIP_ADDR");
  }

  public String getUserNotes() {
    return getAttrString("USER_NOTES");
  }

  public long getRelatedCompanyIndustryId() {
    return getAttrLong("RELATED_COMPANY_INDUSTRY_ID");
  }

  public long getRelatedCompanyKindId() {
    return getAttrLong("RELATED_COMPANY_KIND_ID");
  }

  public long getRelatedCompanyPrivice() {
    return getAttrLong("RELATED_COMPANY_PRIVICE");
  }

  public String getRelatedCustomADistrict() {
    return getAttrString("RELATED_CUSTOM_A_DISTRICT");
  }

  public String getRelatedCustomZDistrict() {
    return getAttrString("RELATED_CUSTOM_Z_DISTRICT");
  }

  public String getReverseDns() {
    return getAttrString("REVERSE_DNS");
  }

  public Timestamp getRevocationDate() {
    return getAttrDateTime("REVOCATION_DATE");
  }

  public String getSalesDepartment() {
    return getAttrString("SALES_DEPARTMENT");
  }

  public String getSpecialLineAccessAddr() {
    return getAttrString("SPECIAL_LINE_ACCESS_ADDR");
  }

  public String getSpecialLineBureauIp() {
    return getAttrString("SPECIAL_LINE_BUREAU_IP");
  }

  public String getSpecialLineCustomDestIp() {
    return getAttrString("SPECIAL_LINE_CUSTOM_DEST_IP");
  }

  public String getSpecialLineCustomIp() {
    return getAttrString("SPECIAL_LINE_CUSTOM_IP");
  }

  public String getSpecialLineCustomOrigIp() {
    return getAttrString("SPECIAL_LINE_CUSTOM_ORIG_IP");
  }

  public void setAccountManager(String accountManager) {
    setAttrValue("ACCOUNT_MANAGER", accountManager);
  }

  public void setAccountManagerPhone(String accountManagerPhone) {
    setAttrValue("ACCOUNT_MANAGER_PHONE", accountManagerPhone);
  }

  public void setAgents(String agents) {
    setAttrValue("AGENTS", agents);
  }

  public void setAgentsPhone(String agentsPhone) {
    setAttrValue("AGENTS_PHONE", agentsPhone);
  }

  public void setBasicAppProperty(String basicAppProperty) {
    setAttrValue("BASIC_APP_PROPERTY", basicAppProperty);
  }

  public void setBasicBandWidth(String basicBandWidth) {
    setAttrValue("BASIC_BAND_WIDTH", basicBandWidth);
  }

  public void setBasicCustomAccessAEquip(String basicCustomAccessAEquip) {
    setAttrValue("BASIC_CUSTOM_ACCESS_A_EQUIP", basicCustomAccessAEquip);
  }

  public void setBasicCustomAccessAType(String basicCustomAccessAType) {
    setAttrValue("BASIC_CUSTOM_ACCESS_A_TYPE", basicCustomAccessAType);
  }

  public void setBasicCustomAccessZEquip(String basicCustomAccessZEquip) {
    setAttrValue("BASIC_CUSTOM_ACCESS_Z_EQUIP", basicCustomAccessZEquip);
  }

  public void setBasicCustomAccessZType(String basicCustomAccessZType) {
    setAttrValue("BASIC_CUSTOM_ACCESS_Z_TYPE", basicCustomAccessZType);
  }

  public void setBasicCustomerProperty(long basicCustomerProperty) {
    setAttrValue("BASIC_CUSTOMER_PROPERTY", basicCustomerProperty);
  }

  public void setBasicCustomSla(String basicCustomSla) {
    setAttrValue("BASIC_CUSTOM_SLA", basicCustomSla);
  }

  public void setBasicDropOpen(String basicDropOpen) {
    setAttrValue("BASIC_DROP_OPEN", basicDropOpen);
  }

  public void setBasicLineNo(String basicLineNo) {
    setAttrValue("BASIC_LINE_NO", basicLineNo);
  }

  public void setBasicLineState(long basicLineState) {
    setAttrValue("BASIC_LINE_STATE", basicLineState);
  }

  public void setBasicLineType(long basicLineType) {
    setAttrValue("BASIC_LINE_TYPE", basicLineType);
  }

  public void setBasicRevocationDate(Timestamp basicRevocationDate) {
    setAttrValue("BASIC_REVOCATION_DATE", basicRevocationDate);
  }

  public void setBasicUsedDate(Timestamp basicUsedDate) {
    setAttrValue("BASIC_USED_DATE", basicUsedDate);
  }

  public void setChiefAccountManager(String chiefAccountManager) {
    setAttrValue("CHIEF_ACCOUNT_MANAGER", chiefAccountManager);
  }

  public void setCmnetAccessEquip(String cmnetAccessEquip) {
    setAttrValue("CMNET_ACCESS_EQUIP", cmnetAccessEquip);
  }

  public void setCmnetAccessPoint(String cmnetAccessPoint) {
    setAttrValue("CMNET_ACCESS_POINT", cmnetAccessPoint);
  }

  public void setCmnetPortNo(String cmnetPortNo) {
    setAttrValue("CMNET_PORT_NO", cmnetPortNo);
  }

  public void setCmnetPortType(String cmnetPortType) {
    setAttrValue("CMNET_PORT_TYPE", cmnetPortType);
  }

  public void setCompanyName(String companyName) {
    setAttrValue("COMPANY_NAME", companyName);
  }

  public void setCuid(String cuid) {
    setAttrValue("CUID", cuid);
  }

  public void setCurrentNetworkLevel(String currentNetworkLevel) {
    setAttrValue("CURRENT_NETWORK_LEVEL", currentNetworkLevel);
  }

  public void setCustomSLA(String customSLA) {
    setAttrValue("CUSTOM_SLA", customSLA);
  }

  public void setRelatedCompanyCounty(long relatedCompanyCounty) {
    setAttrValue("RELATED_COMPANY_COUNTY", relatedCompanyCounty);
  }

  public void setRelatedCompanyCity(long relatedCompanyCity) {
    setAttrValue("RELATED_COMPANY_CITY", relatedCompanyCity);
  }

  public void setRelatedCompanyAddr(String relatedCompanyAddr) {
    setAttrValue("RELATED_COMPANY_ADDR", relatedCompanyAddr);
  }

  public void setRelatedBasicCustomZDistrict(String relatedBasicCustomZDistrict) {
    setAttrValue("BASIC_CUSTOM_Z_DISTRICT", relatedBasicCustomZDistrict);
  }

  public void setRelatedBasicCustomADistrict(String relatedBasicCustomADistrict) {
    setAttrValue("BASIC_CUSTOM_A_DISTRICT", relatedBasicCustomADistrict);
  }

  public void setRelatedBasicCompanyNameEn(String relatedBasicCompanyNameEn) {
    setAttrValue("RELATED_COMPANY_NAME_EN", relatedBasicCompanyNameEn);
  }

  public void setRelatedBasicCompanyNameCn(String relatedBasicCompanyNameCn) {
    setAttrValue("RELATED_COMPANY_NAME_CN", relatedBasicCompanyNameCn);
  }

  public void setRectificationPeriod(String rectificationPeriod) {
    setAttrValue("RECTIFICATION_PERIOD", rectificationPeriod);
  }

  public void setSpecialLineNotes(String specialLineNotes) {
    setAttrValue("SPECIAL_LINE_NOTES", specialLineNotes);
  }

  public void setSpecialLineNum(String specialLineNum) {
    setAttrValue("SPECIAL_LINE_NUM", specialLineNum);
  }

  public void setLineTecnContactPhone(String lineTecnContactPhone) {
    setAttrValue("LINE_TECN_CONTACT_PHONE", lineTecnContactPhone);
  }

  public void setLineTecnContactEmail(String lineTecnContactEmail) {
    setAttrValue("LINE_TECN_CONTACT_EMAIL", lineTecnContactEmail);
  }

  public void setLineTecnContact(String lineTecnContact) {
    setAttrValue("LINE_TECN_CONTACT", lineTecnContact);
  }

  public void setLineServiceContactPhone(String lineServiceContactPhone) {
    setAttrValue("LINE_SERVICE_CONTACT_PHONE", lineServiceContactPhone);
  }

  public void setLineServiceContactEmail(String lineServiceContactEmail) {
    setAttrValue("LINE_SERVICE_CONTACT_EMAIL", lineServiceContactEmail);
  }

  public void setLineServiceContact(String lineServiceContact) {
    setAttrValue("LINE_SERVICE_CONTACT", lineServiceContact);
  }

  public void setDemandNetworkLevel(String demandNetworkLevel) {
    setAttrValue("DEMAND_NETWORK_LEVEL", demandNetworkLevel);
  }

  public void setDataVlan(String dataVlan) {
    setAttrValue("DATA_VLAN", dataVlan);
  }

  public void setDataNotes(String dataNotes) {
    setAttrValue("DATA_NOTES", dataNotes);
  }

  public void setSpecialLineState(long specialLineState) {
    setAttrValue("SPECIAL_LINE_STATE", specialLineState);
  }

  public void setSpecialLineType(long specialLineType) {
    setAttrValue("SPECIAL_LINE_TYPE", specialLineType);
  }

  public void setSwitchAccessEquip(String switchAccessEquip) {
    setAttrValue("SWITCH_ACCESS_EQUIP", switchAccessEquip);
  }

  public void setSwitchAccessModule(String switchAccessModule) {
    setAttrValue("SWITCH_ACCESS_MODULE", switchAccessModule);
  }

  public void setSwitchAccessPoint(String switchAccessPoint) {
    setAttrValue("SWITCH_ACCESS_POINT", switchAccessPoint);
  }

  public void setSwitchNotes(String switchNotes) {
    setAttrValue("SWITCH_NOTES", switchNotes);
  }

  public void setSwitchOdfDdf(String switchOdfDdf) {
    setAttrValue("SWITCH_ODF_DDF", switchOdfDdf);
  }

  public void setTargetNetworkLevel(String targetNetworkLevel) {
    setAttrValue("TARGET_NETWORK_LEVEL", targetNetworkLevel);
  }

  public void setTcpPort(String tcpPort) {
    setAttrValue("TCP_PORT", tcpPort);
  }

  public void setTransAccessAPoint(String transAccessAPoint) {
    setAttrValue("TRANS_ACCESS_A_POINT", transAccessAPoint);
  }

  public void setTransAccessZPoint(String transAccessZPoint) {
    setAttrValue("TRANS_ACCESS_Z_POINT", transAccessZPoint);
  }

  public void setTransNotes(String transNotes) {
    setAttrValue("TRANS_NOTES", transNotes);
  }

  public void setTransPhysicsLink(String transPhysicsLink) {
    setAttrValue("TRANS_PHYSICS_LINK", transPhysicsLink);
  }

  public void setTransRoute(String transRoute) {
    setAttrValue("TRANS_ROUTE", transRoute);
  }

  public void setTransRouteA(String transRoute) {
    setAttrValue("TRANS_ROUTE_A", transRoute);
  }

  public void setTransRouteB(String transRoute) {
    setAttrValue("TRANS_ROUTE_B", transRoute);
  }

  public void setTransRouteC(String transRoute) {
    setAttrValue("TRANS_ROUTE_C", transRoute);
  }

  public void setTransRouteD(String transRoute) {
    setAttrValue("TRANS_ROUTE_D", transRoute);
  }

  public void setTransRouteE(String transRoute) {
    setAttrValue("TRANS_ROUTE_E", transRoute);
  }

  public void setTransThirdPartyData(String transThirdPartyData) {
    setAttrValue("TRANS_THIRD_PARTY_DATA", transThirdPartyData);
  }

  public void setTransTopoLink(String transTopoLink) {
    setAttrValue("TRANS_TOPO_LINK", transTopoLink);
  }

  public void setUpdateDate(Timestamp updateDate) {
    setAttrValue("UPDATE_DATE", updateDate);
  }

  public void setUpdateUser(String updateUser) {
    setAttrValue("UPDATE_USER", updateUser);
  }

  public void setSpecialLineUsedDate(Timestamp specialLineUsedDate) {
    setAttrValue("SPECIAL_LINE_USED_DATE", specialLineUsedDate);
  }

  public void setUsedState(long usedState) {
    setAttrValue("USED_STATE", usedState);
  }

  public void setUsedTime(Timestamp usedTime) {
    setAttrValue("USED_TIME", usedTime);
  }

  public void setUsedType(long usedType) {
    setAttrValue("USED_TYPE", usedType);
  }

  public void setUserBureauAEquip(String userBureauAEquip) {
    setAttrValue("USER_BUREAU_A_EQUIP", userBureauAEquip);
  }

  public void setUserBureauAEquipAddr(String userBureauAEquipAddr) {
    setAttrValue("USER_BUREAU_A_EQUIP_ADDR", userBureauAEquipAddr);
  }

  public void setUserBureauZEquip(String userBureauZEquip) {
    setAttrValue("USER_BUREAU_Z_EQUIP", userBureauZEquip);
  }

  public void setUserBureauZEquipAddr(String userBureauZEquipAddr) {
    setAttrValue("USER_BUREAU_Z_EQUIP_ADDR", userBureauZEquipAddr);
  }

  public void setUserNotes(String userNotes) {
    setAttrValue("USER_NOTES", userNotes);
  }

  public void setSpecialLineCustomOrigIp(String specialLineCustomOrigIp) {
    setAttrValue("SPECIAL_LINE_CUSTOM_ORIG_IP", specialLineCustomOrigIp);
  }

  public void setSpecialLineCustomIp(String specialLineCustomIp) {
    setAttrValue("SPECIAL_LINE_CUSTOM_IP", specialLineCustomIp);
  }

  public void setSpecialLineCustomDestIp(String specialLineCustomDestIp) {
    setAttrValue("SPECIAL_LINE_CUSTOM_DEST_IP", specialLineCustomDestIp);
  }

  public void setSpecialLineBureauIp(String specialLineBureauIp) {
    setAttrValue("SPECIAL_LINE_BUREAU_IP", specialLineBureauIp);
  }

  public void setSpecialLineAccessAddr(String specialLineAccessAddr) {
    setAttrValue("SPECIAL_LINE_ACCESS_ADDR", specialLineAccessAddr);
  }

  public void setSalesDepartment(String salesDepartment) {
    setAttrValue("SALES_DEPARTMENT", salesDepartment);
  }

  public void setRevocationDate(Timestamp revocationDate) {
    setAttrValue("REVOCATION_DATE", revocationDate);
  }

  public void setReverseDns(String reverseDns) {
    setAttrValue("REVERSE_DNS", reverseDns);
  }

  public void setRelatedCustomZDistrict(String relatedCustomZDistrict) {
    setAttrValue("RELATED_CUSTOM_Z_DISTRICT", relatedCustomZDistrict);
  }

  public void setRelatedCustomADistrict(String relatedCustomADistrict) {
    setAttrValue("RELATED_CUSTOM_A_DISTRICT", relatedCustomADistrict);
  }

  public void setRelatedCompanyPrivice(long relatedCompanyPrivice) {
    setAttrValue("RELATED_COMPANY_PRIVICE", relatedCompanyPrivice);
  }

  public void setRelatedCompanyKindId(long relatedCompanyKindId) {
    setAttrValue("RELATED_COMPANY_KIND_ID", relatedCompanyKindId);
  }

  public void setRelatedCompanyIndustryId(long relatedCompanyIndustryId) {
    setAttrValue("RELATED_COMPANY_INDUSTRY_ID", relatedCompanyIndustryId);
  }

  public class AttrName
  {
    public static final String cuid = "CUID";
    public static final String specialLineNum = "SPECIAL_LINE_NUM";
    public static final String specialLineType = "SPECIAL_LINE_TYPE";
    public static final String customSLA = "CUSTOM_SLA";
    public static final String companyName = "COMPANY_NAME";
    public static final String relatedCustomADistrict = "RELATED_CUSTOM_A_DISTRICT";
    public static final String relatedCustomZDistrict = "RELATED_CUSTOM_Z_DISTRICT";
    public static final String specialLineState = "SPECIAL_LINE_STATE";
    public static final String specialLineUsedDate = "SPECIAL_LINE_USED_DATE";
    public static final String revocationDate = "REVOCATION_DATE";
    public static final String updateDate = "UPDATE_DATE";
    public static final String updateUser = "UPDATE_USER";
    public static final String specialLineNotes = "SPECIAL_LINE_NOTES";
    public static final String relatedBasicCompanyNameCn = "RELATED_COMPANY_NAME_CN";
    public static final String relatedBasicCompanyNameEn = "RELATED_COMPANY_NAME_EN";
    public static final String relatedCompanyKindId = "RELATED_COMPANY_KIND_ID";
    public static final String relatedCompanyIndustryId = "RELATED_COMPANY_INDUSTRY_ID";
    public static final String relatedCompanyPrivice = "RELATED_COMPANY_PRIVICE";
    public static final String relatedCompanyCity = "RELATED_COMPANY_CITY";
    public static final String relatedCompanyCounty = "RELATED_COMPANY_COUNTY";
    public static final String relatedCompanyAddr = "RELATED_COMPANY_ADDR";
    public static final String specialLineAccessAddr = "SPECIAL_LINE_ACCESS_ADDR";
    public static final String lineServiceContact = "LINE_SERVICE_CONTACT";
    public static final String lineServiceContactPhone = "LINE_SERVICE_CONTACT_PHONE";
    public static final String lineServiceContactEmail = "LINE_SERVICE_CONTACT_EMAIL";
    public static final String lineTecnContact = "LINE_TECN_CONTACT";
    public static final String lineTecnContactPhone = "LINE_TECN_CONTACT_PHONE";
    public static final String lineTecnContactEmail = "LINE_TECN_CONTACT_EMAIL";
    public static final String salesDepartment = "SALES_DEPARTMENT";
    public static final String accountManager = "ACCOUNT_MANAGER";
    public static final String accountManagerPhone = "ACCOUNT_MANAGER_PHONE";
    public static final String chiefAccountManager = "CHIEF_ACCOUNT_MANAGER";
    public static final String agents = "AGENTS";
    public static final String agentsPhone = "AGENTS_PHONE";
    public static final String basicLineNo = "BASIC_LINE_NO";
    public static final String basicLineType = "BASIC_LINE_TYPE";
    public static final String basicBandWidth = "BASIC_BAND_WIDTH";
    public static final String basicCustomerProperty = "BASIC_CUSTOMER_PROPERTY";
    public static final String basicAppProperty = "BASIC_APP_PROPERTY";
    public static final String basicCustomSla = "BASIC_CUSTOM_SLA";
    public static final String currentNetworkLevel = "CURRENT_NETWORK_LEVEL";
    public static final String demandNetworkLevel = "DEMAND_NETWORK_LEVEL";
    public static final String targetNetworkLevel = "TARGET_NETWORK_LEVEL";
    public static final String basicDropOpen = "BASIC_DROP_OPEN";
    public static final String rectificationPeriod = "RECTIFICATION_PERIOD";
    public static final String basicLineState = "BASIC_LINE_STATE";
    public static final String basicUsedDate = "BASIC_USED_DATE";
    public static final String basicRevocationDate = "BASIC_REVOCATION_DATE";
    public static final String relatedBasicCustomADistrict = "BASIC_CUSTOM_A_DISTRICT";
    public static final String relatedBasicCustomZDistrict = "BASIC_CUSTOM_Z_DISTRICT";
    public static final String basicCustomAccessAEquip = "BASIC_CUSTOM_ACCESS_A_EQUIP";
    public static final String basicCustomAccessZEquip = "BASIC_CUSTOM_ACCESS_Z_EQUIP";
    public static final String basicCustomAccessAType = "BASIC_CUSTOM_ACCESS_A_TYPE";
    public static final String basicCustomAccessZType = "BASIC_CUSTOM_ACCESS_Z_TYPE";
    public static final String specialLineBureauIp = "SPECIAL_LINE_BUREAU_IP";
    public static final String specialLineCustomIp = "SPECIAL_LINE_CUSTOM_IP";
    public static final String specialLineCustomOrigIp = "SPECIAL_LINE_CUSTOM_ORIG_IP";
    public static final String specialLineCustomDestIp = "SPECIAL_LINE_CUSTOM_DEST_IP";
    public static final String usedState = "USED_STATE";
    public static final String usedType = "USED_TYPE";
    public static final String usedTime = "USED_TIME";
    public static final String dataVlan = "DATA_VLAN";
    public static final String cmnetAccessPoint = "CMNET_ACCESS_POINT";
    public static final String cmnetAccessEquip = "CMNET_ACCESS_EQUIP";
    public static final String cmnetPortType = "CMNET_PORT_TYPE";
    public static final String cmnetPortNo = "CMNET_PORT_NO";
    public static final String reverseDns = "REVERSE_DNS";
    public static final String tcpPort = "TCP_PORT";
    public static final String dataNotes = "DATA_NOTES";
    public static final String switchAccessPoint = "SWITCH_ACCESS_POINT";
    public static final String switchAccessEquip = "SWITCH_ACCESS_EQUIP";
    public static final String switchAccessModule = "SWITCH_ACCESS_MODULE";
    public static final String switchOdfDdf = "SWITCH_ODF_DDF";
    public static final String switchNotes = "SWITCH_NOTES";
    public static final String transAccessAPoint = "TRANS_ACCESS_A_POINT";
    public static final String transAccessZPoint = "TRANS_ACCESS_Z_POINT";
    public static final String transRoute = "TRANS_ROUTE";
    public static final String transRouteA = "TRANS_ROUTE_A";
    public static final String transRouteB = "TRANS_ROUTE_B";
    public static final String transRouteC = "TRANS_ROUTE_C";
    public static final String transRouteD = "TRANS_ROUTE_D";
    public static final String transRouteE = "TRANS_ROUTE_E";
    public static final String transThirdPartyData = "TRANS_THIRD_PARTY_DATA";
    public static final String transTopoLink = "TRANS_TOPO_LINK";
    public static final String transPhysicsLink = "TRANS_PHYSICS_LINK";
    public static final String transNotes = "TRANS_NOTES";
    public static final String userBureauAEquip = "USER_BUREAU_A_EQUIP";
    public static final String userBureauZEquip = "USER_BUREAU_Z_EQUIP";
    public static final String userBureauAEquipAddr = "USER_BUREAU_A_EQUIP_ADDR";
    public static final String userBureauZEquipAddr = "USER_BUREAU_Z_EQUIP_ADDR";
    public static final String userNotes = "USER_NOTES";

    public AttrName()
    {
    }
  }
}