package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.AttrObject;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class ExcelSheet extends AttrObject
{
  public List<Integer> indexList = new ArrayList();
  private String sortKey = "sortCol";

  public List getTitle()
  {
    List titleList = null;
    Object attrValue = getAttrValue("TITLE");
    if (attrValue != null)
      titleList = (List)attrValue;
    else {
      titleList = new ArrayList();
    }
    return titleList;
  }

  public void setTitle(List title) {
    setAttrValue("TITLE", title);
  }

  public String getSheetName() {
    String sheetName = "";
    Object attrValue = getAttrValue("SHEET_NAME");
    if (attrValue != null) {
      sheetName = String.valueOf(attrValue);
    }
    return sheetName;
  }

  public void setSheetName(String sheetName) {
    setAttrValue("SHEET_NAME", sheetName);
  }

  public String[] getHeadId() {
    String[] headId = null;
    Object attrValue = getAttrValue("HEAD_ID");
    if (attrValue != null)
      headId = (String[])attrValue;
    else {
      headId = new String[0];
    }
    return headId;
  }

  public void setHeadId(String[] headid) {
    setAttrValue("HEAD_ID", headid);
  }

  public List getHead() {
    List head = null;
    Object attrValue = getAttrValue("HEAD");
    if (attrValue != null)
      head = (List)attrValue;
    else {
      head = new ArrayList();
    }
    return head;
  }

  public void setHead(List head) {
    setAttrValue("HEAD", head);
  }

  public void addHeadRow(String[] headRow) {
    List head = getHead();
    head.add(headRow);
    setAttrValue("HEAD", head);
  }

  public List getLeft()
  {
    List left = null;
    Object attrValue = getAttrValue("LEFT");
    if (attrValue != null)
      left = (List)attrValue;
    else {
      left = new ArrayList();
    }
    return left;
  }

  public void setLeft(List left) {
    setAttrValue("LEFT", left);
  }

  public List getFoot() {
    List foot = null;
    Object attrValue = getAttrValue("FOOT");
    if (attrValue != null)
      foot = (List)attrValue;
    else {
      foot = new ArrayList();
    }
    return foot;
  }

  public void setFoot(List foot) {
    setAttrValue("FOOT", foot);
  }

  public int[] getColType() {
    int[] colType = null;
    Object attrValue = getAttrValue("COL_TYPE");
    if (attrValue != null) {
      colType = (int[])attrValue;
    } else {
      colType = new int[getHeadId().length];
      for (int i = 0; i < colType.length; i++) {
        colType[i] = 1;
      }
    }
    return colType;
  }

  public void setColType(int[] colType) {
    setAttrValue("COL_TYPE", colType);
  }

  public int[] getColWidth() {
    int[] colWidth = null;
    Object attrValue = getAttrValue("COL_WIDTH");
    if (attrValue != null)
      colWidth = (int[])attrValue;
    else {
      colWidth = new int[0];
    }
    return colWidth;
  }

  public void setColWidth(int[] colWidth) {
    setAttrValue("COL_TYPE", colWidth);
  }

  public Object getData() {
    return getAttrArray("DATA");
  }

  public void setData(Object data) {
    setAttrValue("DATA", data);
  }

  public List getExcelCacheDto() {
    List excelCachelist = null;
    Object attrValue = getAttrValue("EXCEL_CACHE_DTO");
    if (attrValue != null)
      excelCachelist = (List)attrValue;
    else {
      excelCachelist = new ArrayList();
    }
    return excelCachelist;
  }

  public void setExcelCacheDto(List excelCacheList) {
    setAttrValue("EXCEL_CACHE_DTO", excelCacheList);
  }

  public List<Integer> getIndexList() {
    return this.indexList;
  }

  public void setIndexList(List<Integer> indexList) {
    this.indexList = indexList;
  }

  public void setSortKey(String sortKey)
  {
    if ((sortKey != null) && (!sortKey.trim().equals("null")) && (sortKey.trim().length() > 0))
      this.sortKey = sortKey;
  }

  public List<Integer> sort(String sortAttrName, boolean sortType)
  {
    String _sortType;
    String _sortType;
    if (sortType == true)
      _sortType = "desc";
    else {
      _sortType = "asc";
    }
    return sort(sortAttrName, _sortType);
  }

  public List<Integer> sort(String sortAttrName, String sortType)
  {
    Object sheetData = getData();
    if ((sheetData instanceof DataObjectList))
      return sort((DataObjectList)sheetData, sortAttrName, sortType);
    if ((sheetData instanceof DboCollection))
    {
      return this.indexList;
    }

    return this.indexList;
  }

  private List<Integer> sort(DataObjectList dbos, String sortAttrName, String sortType)
  {
    if ((dbos != null) && (dbos.size() > 0)) {
      GenericDO d = (GenericDO)dbos.get(0);
      if (!d.containsAttr(this.sortKey)) {
        for (int i = 0; i > 0; i++) {
          this.sortKey = ("sortKey" + getRandom());
          if (!d.containsAttr(this.sortKey))
          {
            break;
          }
        }
        for (int i = 0; i < dbos.size(); i++) {
          GenericDO dbo = (GenericDO)dbos.get(i);
          dbo.setAttrValue(this.sortKey, String.valueOf(i));
        }
      }
      return sort(dbos, sortAttrName, sortType, this.sortKey);
    }
    return this.indexList;
  }

  private String getRandom()
  {
    Random random = new Random();
    return String.valueOf(random.nextInt());
  }

  private List<Integer> sort(DataObjectList dbos, String sortAttrName, String sortType, String sortKey) {
    sortType = sortType.trim().toLowerCase();
    sortAttrName = sortAttrName.trim();
    DataObjectList dbosTemp = null;
    Map oldSortMap = new HashMap();
    if ((dbos != null) && (dbos.size() >= 0)) {
      this.indexList.clear();
      dbosTemp = (DataObjectList)dbos.clone();
      if ((sortAttrName != null) && (!sortAttrName.equals("")) && (!sortAttrName.equals("null")) && 
        (sortType != null) && (!sortType.equals("")) && (!sortType.equals("null"))) {
        if (sortType.equals("desc"))
          dbosTemp.sort(sortAttrName, true);
        else {
          dbosTemp.sort(sortAttrName, false);
        }
      }

      for (int i = 0; i < dbos.size(); i++) {
        GenericDO dbo = (GenericDO)dbos.get(i);
        oldSortMap.put(dbo.getAttrString(sortKey), Integer.valueOf(i));
      }
    }
    for (int j = 0; j < dbosTemp.size(); j++) {
      GenericDO dbo = (GenericDO)dbosTemp.get(j);
      Integer index = (Integer)oldSortMap.get(dbo.getAttrString(sortKey));
      this.indexList.add(index);
    }
    if ((dbosTemp != null) && (dbosTemp.size() > 0)) {
      dbosTemp.clear();
    }
    return this.indexList;
  }

  public Object getCellValue(int rowIndex, int colIndex)
  {
    Object data = getData();
    Object value = null;
    if (data != null) {
      if ((data instanceof DataObjectList)) {
        String[] headId = getHeadId();
        DataObjectList temp = (DataObjectList)data;
        if ((this.indexList == null) || (this.indexList.size() == 0)) {
          if ((temp.size() > rowIndex) && (headId.length > colIndex)) {
            GenericDO dbo = (GenericDO)temp.get(rowIndex);
            value = dbo.getAttrValue(headId[colIndex]);
          }
        }
        else if ((this.indexList.size() > rowIndex) && (headId.length > colIndex)) {
          int trueIndex = ((Integer)this.indexList.get(rowIndex)).intValue();
          if (temp.size() > trueIndex) {
            GenericDO dbo = (GenericDO)temp.get(trueIndex);
            value = dbo.getAttrValue(headId[colIndex]);
          }

        }

      }
      else if (!(data instanceof DboCollection));
    }

    return value;
  }

  public Object getFootValue(int rowIndex, int colIndex)
  {
    List foot = getFoot();
    Object value = null;
    if ((foot != null) && 
      (foot != null) && (foot.size() > rowIndex)) {
      Object oneFoot = foot.get(rowIndex);
      if ((oneFoot instanceof GenericDO)) {
        String[] headId = getHeadId();
        if ((headId != null) && (headId.length > colIndex)) {
          value = ((GenericDO)oneFoot).getAttrValue(headId[colIndex]);
        }

      }
      else if (!(oneFoot instanceof String[][]));
    }

    return value;
  }

  public static class AttrName
  {
    public static final String sheetName = "SHEET_NAME";
    public static final String title = "TITLE";
    public static final String head = "HEAD";
    public static final String colType = "COL_TYPE";
    public static final String colWidth = "COL_WIDTH";
    public static final String headId = "HEAD_ID";
    public static final String data = "DATA";
    public static final String type = "TYPE";
    public static final String left = "LEFT";
    public static final String foot = "FOOT";
    public static final String ExcelCacheDto = "EXCEL_CACHE_DTO";
  }
}