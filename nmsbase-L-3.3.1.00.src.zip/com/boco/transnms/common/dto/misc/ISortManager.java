package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.DataObjectList;

public abstract interface ISortManager
{
  public abstract DataObjectList sort(LinkRouteInfo paramLinkRouteInfo);
}