package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class ElementStatistic extends GenericDO
{
  public static final String CLASS_NAME = "ELEMENT_STATISTIC";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public ElementStatistic()
  {
    super("ELEMENT_STATISTIC");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("NUMBER", String.class);
    this.attrTypeMap.put("RELATED_EMS_NAME", String.class);
    this.attrTypeMap.put("CONFIG_TYPE", String.class);
    this.attrTypeMap.put("SIGNAL_TYPE", String.class);
    this.attrTypeMap.put("RELATED_VENDOR_CUID", String.class);
    this.attrTypeMap.put("MODEL", String.class);
    this.attrTypeMap.put("IS_USAGE_STATE", String.class);
    this.attrTypeMap.put("COUNT", String.class);
    this.attrTypeMap.put("LABEL_CN", String.class);
    this.attrTypeMap.put("MEDIUM", String.class);
    this.attrTypeMap.put("LOCATION", String.class);
    this.attrTypeMap.put("NATIVE_EMS_NAME", String.class);
    this.attrTypeMap.put("PRESERVER", String.class);
    this.attrTypeMap.put("PRESERVER_ADDR", String.class);
    this.attrTypeMap.put("PRESERVER_PHONE", String.class);
    this.attrTypeMap.put("USERLABEL", String.class);
    this.attrTypeMap.put("SUPPORT_RATE", String.class);
    this.attrTypeMap.put("NATIVE_EMS_NAME", String.class);
    this.attrTypeMap.put("HARD_VERSION", String.class);
    this.attrTypeMap.put("SOFT_VERSION", String.class);
    this.attrTypeMap.put("CAPACITY", String.class);
    this.attrTypeMap.put("REMARK", String.class);
    this.attrTypeMap.put("CREATTIME", String.class);
  }

  public void setLocation(String location) {
    super.setAttrValue("LOCATION", location);
  }

  public void setEmsName(String emsName) {
    super.setAttrValue("NATIVE_EMS_NAME", emsName);
  }

  public void setLabelCn(String labelcn) {
    super.setAttrValue("LABEL_CN", labelcn);
  }

  public void setMedium(String medium) {
    super.setAttrValue("MEDIUM", medium);
  }

  public void setNumber(String number) {
    super.setAttrValue("NUMBER", number);
  }

  public void setRelatedEmsName(String relatedEmsName) {
    super.setAttrValue("RELATED_EMS_NAME", relatedEmsName);
  }

  public void setConfigType(String configType) {
    super.setAttrValue("CONFIG_TYPE", configType);
  }

  public void setSignalType(String signalType) {
    super.setAttrValue("SIGNAL_TYPE", signalType);
  }

  public void setRelatedVendorCuid(String relatedVendorCuid) {
    super.setAttrValue("RELATED_VENDOR_CUID", relatedVendorCuid);
  }

  public void setModel(String model) {
    super.setAttrValue("MODEL", model);
  }

  public void setIsUsageState(String isUsageState) {
    super.setAttrValue("IS_USAGE_STATE", isUsageState);
  }

  public void setCount(String count) {
    super.setAttrValue("COUNT", count);
  }

  public void setCount1(String count1) {
    super.setAttrValue("COUNT1", count1);
  }

  public void setPreserver(String preserver) {
    super.setAttrValue("PRESERVER", preserver);
  }

  public void setPreserver_addr(String preserver_addr) {
    super.setAttrValue("PRESERVER_ADDR", preserver_addr);
  }

  public void setPreserver_phone(String preserver_phone) {
    super.setAttrValue("PRESERVER_PHONE", preserver_phone);
  }

  public void setUserlabel(String userlabel) {
    super.setAttrValue("USERLABEL", userlabel);
  }

  public void setSupport_rate(String support_rate) {
    super.setAttrValue("SUPPORT_RATE", support_rate);
  }

  public void setNative_ems_name(String native_ems_name) {
    super.setAttrValue("NATIVE_EMS_NAME", native_ems_name);
  }

  public void setHard_vesion(String hard_vesion) {
    super.setAttrValue("HARD_VERSION", hard_vesion);
  }

  public void setSoft_vesion(String soft_vesion) {
    super.setAttrValue("SOFT_VERSION", soft_vesion);
  }

  public void setCapacity(String capacity) {
    super.setAttrValue("CAPACITY", capacity);
  }

  public void setRemark(String remark) {
    super.setAttrValue("REMARK", remark);
  }

  public void setCreatime(Timestamp creatime) {
    super.setAttrValue("CREATTIME", creatime);
  }

  public void setTransSystem(String transSystem) {
    super.setAttrValue("TRANSSYSTEM_LABELCN", transSystem);
  }

  public void setSnNe(String snNe) {
    super.setAttrValue("SNNE_LABELCN", snNe);
  }

  public String getNumber() {
    return super.getAttrString("NUMBER");
  }

  public String getRelatedEmsName() {
    return super.getAttrString("RELATED_EMS_NAME");
  }

  public String getConfigType() {
    return super.getAttrString("CONFIG_TYPE");
  }

  public String getSignalType() {
    return super.getAttrString("SIGNAL_TYPE");
  }

  public String getRelatedVendorCuid() {
    return super.getAttrString("RELATED_VENDOR_CUID");
  }

  public String getModel() {
    return super.getAttrString("MODEL");
  }

  public String getIsUsageState() {
    return super.getAttrString("IS_USAGE_STATE");
  }

  public String getCount() {
    return super.getAttrString("COUNT");
  }

  public String getCount1() {
    return super.getAttrString("COUNT1");
  }

  public String getLabelCn() {
    return super.getAttrString("LABEL_CN");
  }

  public String getMedium() {
    return super.getAttrString("MEDIUM");
  }

  public String getLocation() {
    return super.getAttrString("LOCATION");
  }

  public String getEmsName() {
    return super.getAttrString("NATIVE_EMS_NAME");
  }
  public String getPreserver() {
    return super.getAttrString("PRESERVER");
  }
  public String getPreserver_addr() {
    return super.getAttrString("PRESERVER_ADDR");
  }
  public String getPreserver_phone() {
    return super.getAttrString("PRESERVER_PHONE");
  }

  public Timestamp getCreatime() {
    return super.getAttrDateTime("CREATTIME");
  }
  public String getUserlabel() {
    return super.getAttrString("USERLABEL");
  }

  public String getSupport_rate() {
    return super.getAttrString("SUPPORT_RATE");
  }

  public String getNative_ems_name() {
    return super.getAttrString("NATIVE_EMS_NAME");
  }

  public String getHard_vesion() {
    return super.getAttrString("HARD_VERSION");
  }

  public String getSoft_vesion() {
    return super.getAttrString("SOFT_VERSION");
  }

  public String getCapacity() {
    return super.getAttrString("CAPACITY");
  }

  public String getRemark() {
    return super.getAttrString("REMARK");
  }

  public String getTransSystem() {
    return super.getAttrString("TRANSSYSTEM_LABELCN");
  }

  public String getSnNe() {
    return super.getAttrString("SNNE_LABELCN");
  }

  public static class AttrName
  {
    public static final String number = "NUMBER";
    public static final String relatedEmsName = "RELATED_EMS_NAME";
    public static final String configType = "CONFIG_TYPE";
    public static final String signalType = "SIGNAL_TYPE";
    public static final String relatedVendorCuid = "RELATED_VENDOR_CUID";
    public static final String model = "MODEL";
    public static final String isUsageState = "IS_USAGE_STATE";
    public static final String count = "COUNT";
    public static final String count1 = "COUNT1";
    public static final String labelCn = "LABEL_CN";
    public static final String medium = "MEDIUM";
    public static final String location = "LOCATION";
    public static final String emsName = "NATIVE_EMS_NAME";
    public static final String preserver = "PRESERVER";
    public static final String preserver_addr = "PRESERVER_ADDR";
    public static final String preserver_phone = "PRESERVER_PHONE";
    public static final String creatime = "CREATTIME";
    public static final String userlabel = "USERLABEL";
    public static final String support_rate = "SUPPORT_RATE";
    public static final String native_ems_name = "NATIVE_EMS_NAME";
    public static final String hard_vesion = "HARD_VERSION";
    public static final String soft_vesion = "SOFT_VERSION";
    public static final String capacity = "CAPACITY";
    public static final String remark = "REMARK";
    public static final String transSystem = "TRANSSYSTEM_LABELCN";
    public static final String snNe = "SNNE_LABELCN";
  }
}