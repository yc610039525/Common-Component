package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MstpEthServiceInfo extends GenericDO
{
  public static final String CLASS_NAME = "MSTPETHSERVICE";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public MstpEthServiceInfo()
  {
    super("MSTPETHSERVICE");
    initAttrTypes();
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("NE_NAME", String.class);
    this.attrTypeMap.put("CARD_NAME", String.class);
    this.attrTypeMap.put("DIRECTION", String.class);
    this.attrTypeMap.put("ACTIVESTATE", String.class);
    this.attrTypeMap.put("ADDITIONALINFO", String.class);
    this.attrTypeMap.put("ETHSERVICE_FDN", String.class);
    this.attrTypeMap.put("ORIGPORT_PT", String.class);
    this.attrTypeMap.put("DESTPORT_PT", String.class);
  }

  public void setNeName(String neName) {
    super.setAttrValue("NE_NAME", neName);
  }

  public String getNeName() {
    return super.getAttrString("NE_NAME");
  }

  public void setCardName(String cardName) {
    super.setAttrValue("CARD_NAME", cardName);
  }

  public String getCardName() {
    return super.getAttrString("CARD_NAME");
  }

  public void setDirectionName(String direction) {
    super.setAttrValue("DIRECTION", direction);
  }

  public String getDirectionName() {
    return super.getAttrString("DIRECTION");
  }

  public void setActiveStateName(String activeState) {
    super.setAttrValue("ACTIVESTATE", activeState);
  }

  public String getActiveStateName() {
    return super.getAttrString("ACTIVESTATE");
  }

  public void setAdditionalInfo(String additionalInfo) {
    super.setAttrValue("ADDITIONALINFO", additionalInfo);
  }

  public String getAdditionalInfo() {
    return super.getAttrString("ADDITIONALINFO");
  }

  public void setEthserviceFdn(String ethserviceFdn) {
    super.setAttrValue("ETHSERVICE_FDN", ethserviceFdn);
  }

  public String getEthserviceFdn() {
    return super.getAttrString("ETHSERVICE_FDN");
  }

  public void setOrigportPt(String origportPt) {
    super.setAttrValue("ORIGPORT_PT", origportPt);
  }

  public String getOrigportPt() {
    return super.getAttrString("ORIGPORT_PT");
  }

  public void setDestportPt(String destportPt) {
    super.setAttrValue("DESTPORT_PT", destportPt);
  }

  public String getDestportPt() {
    return super.getAttrString("DESTPORT_PT");
  }

  public static class AttrName
  {
    public static final String neName = "NE_NAME";
    public static final String cardName = "CARD_NAME";
    public static final String direction = "DIRECTION";
    public static final String activeState = "ACTIVESTATE";
    public static final String additionalInfo = "ADDITIONALINFO";
    public static final String ethserviceFdn = "ETHSERVICE_FDN";
    public static final String origportPt = "ORIGPORT_PT";
    public static final String destportPt = "DESTPORT_PT";
  }
}