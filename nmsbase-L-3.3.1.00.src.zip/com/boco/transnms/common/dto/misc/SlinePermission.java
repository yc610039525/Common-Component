package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class SlinePermission extends GenericDO
{
  public static final String CLASS_NAME = "SLINE_PERMISSION";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public SlinePermission() {
    super("SLINE_PERMISSION");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("RELATED_SYSUSER_CUID", String.class);
    this.attrTypeMap.put("PERMISSION_NUM", String.class);
    this.attrTypeMap.put("IS_GRANT", Long.TYPE);
  }

  public void setCuid(String varCuid) {
    setAttrValue("CUID", varCuid);
  }

  public String getCuid() {
    return getAttrString("CUID");
  }

  public String getRelatedSysuserCuid()
  {
    return getAttrString("RELATED_SYSUSER_CUID");
  }

  public void setRelatedSysuserCuid(String RelatedSysuserCuid) {
    setAttrValue("RELATED_SYSUSER_CUID", RelatedSysuserCuid);
  }

  public void setIsGrant(long IsGrant) {
    setAttrValue("IS_GRANT", IsGrant);
  }

  public long getIsGrant() {
    return getAttrLong("IS_GRANT");
  }

  public String getPermissionNum() {
    return getAttrString("PERMISSION_NUM");
  }

  public void setPermissionNum(String PermissionNum) {
    setAttrValue("PERMISSION_NUM", PermissionNum);
  }

  public static class AttrName
  {
    public static final String Cuid = "CUID";
    public static final String RelatedSysuserCuid = "RELATED_SYSUSER_CUID";
    public static final String PermissionNum = "PERMISSION_NUM";
    public static final String IsGrant = "IS_GRANT";
  }
}