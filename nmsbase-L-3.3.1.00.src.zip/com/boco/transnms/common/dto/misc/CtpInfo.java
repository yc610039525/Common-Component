package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class CtpInfo extends GenericDO
{
  public static final String CLASS_NAME = "CTP";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public CtpInfo()
  {
    super("CTP");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("NUMBER", String.class);
    this.attrTypeMap.put("RELATED_NE_NAME", String.class);
    this.attrTypeMap.put("RELATED_CARD_NAME", String.class);
    this.attrTypeMap.put("PTP_LABEL_CN", String.class);
    this.attrTypeMap.put("RELATED_PTP_NAME", String.class);
    this.attrTypeMap.put("USERLABEL", String.class);
    this.attrTypeMap.put("CONNECT_STATE", String.class);
    this.attrTypeMap.put("DIRECTIONALITY", String.class);
    this.attrTypeMap.put("IS_PATHABLE", String.class);
    this.attrTypeMap.put("CTP_LAYER_RATE", String.class);
    this.attrTypeMap.put("IS_EDGEPOINT", String.class);
    this.attrTypeMap.put("PROTECT_MODE", String.class);
    this.attrTypeMap.put("FDN", String.class);
  }

  public void setFdn(String fdn) {
    super.setAttrValue("FDN", fdn);
  }

  public String getFdn() {
    return super.getAttrString("FDN");
  }

  public void setNumber(String number) {
    super.setAttrValue("NUMBER", number);
  }

  public void setRelatedNeName(String relatedNeName) {
    super.setAttrValue("RELATED_NE_NAME", relatedNeName);
  }

  public void setRelatedCardName(String relatedCardName) {
    super.setAttrValue("RELATED_CARD_NAME", relatedCardName);
  }

  public void setPtpLabelCn(String ptpLabelCn) {
    super.setAttrValue("PTP_LABEL_CN", ptpLabelCn);
  }

  public void setRelatedPtpCuid(String relatedPtpCuid) {
    super.setAttrValue("RELATED_PTP_NAME", relatedPtpCuid);
  }

  public void setUserLabel(String userLabel) {
    super.setAttrValue("USERLABEL", userLabel);
  }

  public void setConnectState(String connectState) {
    super.setAttrValue("CONNECT_STATE", connectState);
  }

  public void setDirectionality(String directionality) {
    super.setAttrValue("DIRECTIONALITY", directionality);
  }

  public void setIsPathable(String isPathable) {
    super.setAttrValue("IS_PATHABLE", isPathable);
  }

  public void setCtpLayerRate(String ctpLayerRate) {
    super.setAttrValue("CTP_LAYER_RATE", ctpLayerRate);
  }

  public String getNumber() {
    return super.getAttrString("NUMBER");
  }

  public String getRelatedNeName() {
    return super.getAttrString("RELATED_NE_NAME");
  }

  public String getRelatedCardName() {
    return super.getAttrString("RELATED_CARD_NAME");
  }

  public String getPtpLabelCn() {
    return super.getAttrString("PTP_LABEL_CN");
  }

  public String getRelatedPtpCuid() {
    return super.getAttrString("RELATED_PTP_NAME");
  }

  public String getUserLabel() {
    return super.getAttrString("USERLABEL");
  }

  public String getConnectState() {
    return super.getAttrString("CONNECT_STATE");
  }

  public String getDirectionality() {
    return super.getAttrString("DIRECTIONALITY");
  }

  public String getIsPathable() {
    return super.getAttrString("IS_PATHABLE");
  }

  public String getCtpLayerRate() {
    return super.getAttrString("CTP_LAYER_RATE");
  }

  public void setProtectMode(String protectMode) {
    super.setAttrValue("PROTECT_MODE", protectMode);
  }

  public void setIsEdgepoint(String isEdgepoint) {
    super.setAttrValue("IS_EDGEPOINT", isEdgepoint);
  }

  public String getProtectMode() {
    return super.getAttrString("PROTECT_MODE");
  }

  public String getIsEdgepoint() {
    return super.getAttrString("IS_EDGEPOINT");
  }

  public static class AttrName
  {
    public static final String number = "NUMBER";
    public static final String relatedNeName = "RELATED_NE_NAME";
    public static final String relatedCardName = "RELATED_CARD_NAME";
    public static final String ptpLabelCn = "PTP_LABEL_CN";
    public static final String relatedPtpCuid = "RELATED_PTP_NAME";
    public static final String userLabel = "USERLABEL";
    public static final String connectState = "CONNECT_STATE";
    public static final String directionality = "DIRECTIONALITY";
    public static final String isPathable = "IS_PATHABLE";
    public static final String ctpLayerRate = "CTP_LAYER_RATE";
    public static final String isEdgepoint = "IS_EDGEPOINT";
    public static final String protectMode = "PROTECT_MODE";
    public static final String fdn = "FDN";
  }
}