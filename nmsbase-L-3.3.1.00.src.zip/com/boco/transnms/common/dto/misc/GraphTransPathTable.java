package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;

public class GraphTransPathTable extends GenericDO
{
  public static final String CLASS_NAME = "GRAPH_TRANS_PATH_TABLE";

  public GraphTransPathTable()
  {
    super("GRAPH_TRANS_PATH_TABLE");
  }

  public void setNo(int varNo)
  {
    setAttrValue("NO", varNo);
  }

  public int getNo() {
    return getAttrInt("NO");
  }

  public void setVc4No(int varVc4No)
  {
    setAttrValue("VC4_NO", varVc4No);
  }

  public int getVc4No() {
    return getAttrInt("VC4_NO");
  }

  public void setVc4Count(int varVc4Count)
  {
    setAttrValue("VC4_COUNT", varVc4Count);
  }

  public int getVc4Count() {
    return getAttrInt("VC4_COUNT");
  }

  public void setLineCount(int varLineCount)
  {
    setAttrValue("LINE_COUNT", varLineCount);
  }

  public int getLineCount() {
    return getAttrInt("LINE_COUNT");
  }

  public static class AttrName
  {
    public static final String No = "NO";
    public static final String Vc4No = "VC4_NO";
    public static final String Vc4Count = "VC4_COUNT";
    public static final String LineCount = "LINE_COUNT";
  }
}