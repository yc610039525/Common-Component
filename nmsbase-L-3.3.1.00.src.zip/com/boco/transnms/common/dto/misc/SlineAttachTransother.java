package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.DboBlob;
import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class SlineAttachTransother extends GenericDO
{
  public static final String CLASS_NAME = "SLINE_ATTACH_TRANSOTHER";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public SlineAttachTransother() {
    super("SLINE_ATTACH_TRANSOTHER");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("RELATED_SPECIAL_LINE_CUID", String.class);
    this.attrTypeMap.put("ATTACH_TYPE", Long.TYPE);
    this.attrTypeMap.put("ATTACH_FILENAME", String.class);
    this.attrTypeMap.put("ATTACH_DATA", DboBlob.class);
  }

  public void setCuid(String varCuid) {
    setAttrValue("CUID", varCuid);
  }

  public String getCuid() {
    return getAttrString("CUID");
  }

  public String getRelatedSpecialLineCuid()
  {
    return getAttrString("RELATED_SPECIAL_LINE_CUID");
  }

  public void setRelatedSpecialLineCuid(String RelatedSpecialLineCuid) {
    setAttrValue("RELATED_SPECIAL_LINE_CUID", RelatedSpecialLineCuid);
  }

  public void setAttachType(long AttachType) {
    setAttrValue("ATTACH_TYPE", AttachType);
  }

  public long getAttachType() {
    return getAttrLong("ATTACH_TYPE");
  }

  public String getAttachFileName() {
    return getAttrString("ATTACH_FILENAME");
  }

  public void setAttachFileName(String AttachFileName) {
    setAttrValue("ATTACH_FILENAME", AttachFileName);
  }

  public void setAttachData(DboBlob AttachData) {
    setAttrValue("ATTACH_DATA", AttachData);
  }

  public DboBlob getAttachData() {
    return getAttrBlob("ATTACH_DATA");
  }

  public static class AttrName
  {
    public static final String Cuid = "CUID";
    public static final String RelatedSpecialLineCuid = "RELATED_SPECIAL_LINE_CUID";
    public static final String AttachType = "ATTACH_TYPE";
    public static final String AttachFileName = "ATTACH_FILENAME";
    public static final String AttachData = "ATTACH_DATA";
  }
}