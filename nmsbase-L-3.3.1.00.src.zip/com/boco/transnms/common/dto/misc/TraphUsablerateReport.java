package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;

public class TraphUsablerateReport extends GenericDO
{
  private String traphExt;
  private String traphLevel;
  private String traphLabel;
  private String clientName;
  private String rate;
  private float traphHaltTime;
  private String usableRate;
  private String traphCuid;
  private float traphUsedTimeCount;
  private float traphInterruptTimeCount;
  private float traphInterrCount;

  public void setTraphInterrCount(float traphInterrCount)
  {
    this.traphInterrCount = traphInterrCount;
  }
  public float getTraphInterrCount() {
    return this.traphInterrCount;
  }

  public void setTraphExt(String traphExt) {
    this.traphExt = traphExt;
  }

  public void setTraphLevel(String traphLevel) {
    this.traphLevel = traphLevel;
  }

  public void setTraphLabel(String traphLabel) {
    this.traphLabel = traphLabel;
  }

  public void setClientName(String clientName) {
    this.clientName = clientName;
  }

  public void setRate(String rate) {
    this.rate = rate;
  }

  public void setTraphHaltTime(float traphHaltTime) {
    this.traphHaltTime = traphHaltTime;
  }

  public void setUsableRate(String usableRate) {
    this.usableRate = usableRate;
  }

  public void setTraphUsedTimeCount(float traphUsedTimeCount) {
    this.traphUsedTimeCount = traphUsedTimeCount;
  }

  public void setTraphInterruptTimeCount(float traphInterruptTimeCount) {
    this.traphInterruptTimeCount = traphInterruptTimeCount;
  }

  public void setTraphCuid(String traphCuid)
  {
    this.traphCuid = traphCuid;
  }

  public String getTraphExt() {
    return this.traphExt;
  }

  public String getTraphLevel() {
    return this.traphLevel;
  }

  public String getTraphLabel() {
    return this.traphLabel;
  }

  public String getClientName() {
    return this.clientName;
  }

  public String getRate() {
    return this.rate;
  }

  public float getTraphHaltTime() {
    return this.traphHaltTime;
  }

  public String getUsableRate() {
    return this.usableRate;
  }

  public String getTraphCuid() {
    return this.traphCuid;
  }

  public float getTraphUsedTimeCount() {
    return this.traphUsedTimeCount;
  }

  public float getTraphInterruptTimeCount() {
    return this.traphInterruptTimeCount;
  }
}