package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;

public class GraphPathSeg extends GenericDO
{
  public static final String CLASS_NAME = "GRAPH_PATH_SEG";

  public GraphPathSeg()
  {
    super("GRAPH_PATH_SEG");
  }

  public void setCuid(String varCuid)
  {
    setAttrValue("CUID", varCuid);
  }

  public String getCuid() {
    return getAttrString("CUID");
  }

  public void setLabelCn(String varLabelCn)
  {
    setAttrValue("LABEL_CN", varLabelCn);
  }

  public String getLabelCn() {
    return getAttrString("LABEL_CN");
  }

  public void setRelatePathCuid(String varRelatePathCuid)
  {
    setAttrValue("RELATED_PATH_CUID", varRelatePathCuid);
  }

  public String getRelatePathCuid() {
    return getAttrString("RELATED_PATH_CUID");
  }

  public void setACtpCuid(String varACtpCuid)
  {
    setAttrValue("ACTPCUID", varACtpCuid);
  }

  public String getACtpCuid() {
    return getAttrString("ACTPCUID");
  }

  public void setANextCtpCuid(String varANextCtpCuid)
  {
    setAttrValue("ANextCTPCUID", varANextCtpCuid);
  }

  public String getANextCtpCuid() {
    return getAttrString("ANextCTPCUID");
  }

  public void setZNextCtpCuid(String varZNextCtpCuid)
  {
    setAttrValue("ZNextCTPCUID", varZNextCtpCuid);
  }

  public String getZNextCtpCuid() {
    return getAttrString("ZNextCTPCUID");
  }

  public void setZCtpCuid(String varZCtpCuid)
  {
    setAttrValue("ZCTPCUID", varZCtpCuid);
  }

  public String getZCtpCuid() {
    return getAttrString("ZCTPCUID");
  }

  public void setACtp2MNum(int varACtp2MNum)
  {
    setAttrValue("A_CTP_2M_NUM", varACtp2MNum);
  }

  public int getACtp2MNum() {
    return getAttrInt("A_CTP_2M_NUM");
  }

  public void setZCtp2MNum(int varZCtp2MNum)
  {
    setAttrValue("Z_CTP_2M_NUM", varZCtp2MNum);
  }

  public int getZCtp2MNum() {
    return getAttrInt("Z_CTP_2M_NUM");
  }

  public void setACtpVc4No(int varACtpVc4No)
  {
    setAttrValue("A_CTP_VC4_NO", varACtpVc4No);
  }

  public int getACtpVc4No() {
    return getAttrInt("A_CTP_VC4_NO");
  }

  public void setACtpVc12No(int varACtpVc12No)
  {
    setAttrValue("A_CTP_VC12_NO", varACtpVc12No);
  }

  public int getACtpVc12No() {
    return getAttrInt("A_CTP_VC12_NO");
  }

  public void setZCtpVc4No(int varZCtpVc4No)
  {
    setAttrValue("Z_CTP_VC4_NO", varZCtpVc4No);
  }

  public int getZCtpVc4No() {
    return getAttrInt("Z_CTP_VC4_NO");
  }

  public void setZCtpVc12No(int varZCtpVc12No)
  {
    setAttrValue("Z_CTP_VC12_NO", varZCtpVc12No);
  }

  public int getZCtpVc12No() {
    return getAttrInt("Z_CTP_VC12_NO");
  }

  public void setPathStatus(int varPathStatus)
  {
    setAttrValue("PATH_STATUS", varPathStatus);
  }

  public int getPathStatus() {
    return getAttrInt("PATH_STATUS");
  }

  public void setPosNum(int varPosNum)
  {
    setAttrValue("POS_NO", varPosNum);
  }

  public int getPosNum() {
    return getAttrInt("POS_NO");
  }

  public void setSeg2MNum(int varSeg2MNum)
  {
    setAttrValue("SEG_2M_NUM", varSeg2MNum);
  }

  public int getSeg2MNum() {
    return getAttrInt("SEG_2M_NUM");
  }

  public void setACtpRate(int varACtpRate)
  {
    setAttrValue("ACTPRATE", varACtpRate);
  }

  public int getACtpRate() {
    return getAttrInt("ACTPRATE");
  }

  public void setZCtpRate(int varZCtpRate)
  {
    setAttrValue("ZCTPRATE", varZCtpRate);
  }

  public int getZCtpRate() {
    return getAttrInt("ZCTPRATE");
  }

  public void setAElementCuid(String varAElementCuid)
  {
    setAttrValue("A_ELEMENT_CUID", varAElementCuid);
  }

  public String getAElementCuid() {
    return getAttrString("A_ELEMENT_CUID");
  }

  public void setZElementCuid(String varZElementCuid)
  {
    setAttrValue("Z_ELEMENT_CUID", varZElementCuid);
  }

  public String getZElementCuid() {
    return getAttrString("Z_ELEMENT_CUID");
  }

  public void setADirection(int varADirection)
  {
    setAttrValue("A_DIRECTION", varADirection);
  }

  public int getADirection() {
    return getAttrInt("A_DIRECTION");
  }

  public void setZDirection(int varZDirection)
  {
    setAttrValue("Z_DIRECTION", varZDirection);
  }

  public int getZDirection() {
    return getAttrInt("Z_DIRECTION");
  }

  public void setARelatedSysCuid(String varARelatedSysCuid) {
    setAttrValue("A_RELATED_SYS_CUID", varARelatedSysCuid);
  }

  public String getARelatedSysCuid() {
    return getAttrString("A_RELATED_SYS_CUID");
  }

  public void setZRelatedSysCuid(String varZRelatedSysCuid) {
    setAttrValue("Z_RELATED_SYS_CUID", varZRelatedSysCuid);
  }

  public String getZRelatedSysCuid() {
    return getAttrString("Z_RELATED_SYS_CUID");
  }

  public String getUserLabelBy2MNum(int iVc4No, int iVc12No, int iCount)
  {
    String userLabel = "";
    if (iVc12No != 0) {
      userLabel = userLabel + "2M" + iVc12No;
      if (iCount > 1) userLabel = userLabel + "-" + String.valueOf(iVc12No + iCount - 1);
    }
    return userLabel;
  }

  public static class AttrName
  {
    public static final String Cuid = "CUID";
    public static final String LabelCn = "LABEL_CN";
    public static final String RelatePathCuid = "RELATED_PATH_CUID";
    public static final String ACtpCuid = "ACTPCUID";
    public static final String ZCtpCuid = "ZCTPCUID";
    public static final String ANextCtpCuid = "ANextCTPCUID";
    public static final String ZNextCtpCuid = "ZNextCTPCUID";
    public static final String ACtp2MNum = "A_CTP_2M_NUM";
    public static final String ZCtp2MNum = "Z_CTP_2M_NUM";
    public static final String ACtpVc4No = "A_CTP_VC4_NO";
    public static final String ACtpVc12No = "A_CTP_VC12_NO";
    public static final String ZCtpVc4No = "Z_CTP_VC4_NO";
    public static final String ZCtpVc12No = "Z_CTP_VC12_NO";
    public static final String PathStatus = "PATH_STATUS";
    public static final String PosNum = "POS_NO";
    public static final String Seg2MNum = "SEG_2M_NUM";
    public static final String ACtpRate = "ACTPRATE";
    public static final String ZCtpRate = "ZCTPRATE";
    public static final String AElementCuid = "A_ELEMENT_CUID";
    public static final String ZElementCuid = "Z_ELEMENT_CUID";
    public static final String ADirection = "A_DIRECTION";
    public static final String ZDirection = "Z_DIRECTION";
    public static final String ARelatedSysCuid = "A_RELATED_SYS_CUID";
    public static final String ZRelatedSysCuid = "Z_RELATED_SYS_CUID";
  }
}