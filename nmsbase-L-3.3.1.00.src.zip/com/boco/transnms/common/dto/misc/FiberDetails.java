package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class FiberDetails extends GenericDO
{
  public static final String CLASS_NAME = "FiberDetails";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public FiberDetails()
  {
    super("FiberDetails");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("ORIG_POINT_CUID", String.class);
    this.attrTypeMap.put("DEST_POINT_CUID", String.class);
    this.attrTypeMap.put("FIBERCUID", String.class);
    this.attrTypeMap.put("BUSINESS_INFO", String.class);
  }

  public void setOrigpoint(String origpoint)
  {
    super.setAttrValue("ORIG_POINT_CUID", origpoint);
  }

  public void setDestpoint(String destpoint) {
    super.setAttrValue("DEST_POINT_CUID", destpoint);
  }

  public String getOrigpoint() {
    return super.getAttrString("ORIG_POINT_CUID");
  }

  public String getDestpoint() {
    return super.getAttrString("DEST_POINT_CUID");
  }

  public void setFibercuid(String fibercuid) {
    super.setAttrValue("FIBERCUID", fibercuid);
  }

  public String getFibercuid() {
    return super.getAttrString("FIBERCUID");
  }

  public void setBusinessinfo(String businessinfo) {
    super.setAttrValue("BUSINESS_INFO", businessinfo);
  }

  public String getBusinessinfo() {
    return super.getAttrString("BUSINESS_INFO");
  }

  public static class AttrName
  {
    public static final String origpoint = "ORIG_POINT_CUID";
    public static final String destpoint = "DEST_POINT_CUID";
    public static final String fibercuid = "FIBERCUID";
    public static final String businessinfo = "BUSINESS_INFO";
  }
}