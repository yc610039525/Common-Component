package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.PhysicalLineJoin;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class LinkRouteInfo
{
  private String startDtoCuid = null;
  private Map pointMap = new HashMap();
  private DataObjectList links = new DataObjectList();

  private DataObjectList sortedList = new DataObjectList();
  private Boolean isSorted = Boolean.valueOf(false);
  private ISortManager sortManager = new DefaultSortManager();

  public LinkRouteInfo(Map pointMap, DataObjectList links, String startDtoCuid)
  {
    this.pointMap = pointMap;
    this.links = links;
    this.startDtoCuid = startDtoCuid;
  }

  public DataObjectList getLinks()
  {
    return this.links;
  }

  public Map getPointMap() {
    return this.pointMap;
  }

  public ISortManager getSortManager() {
    return this.sortManager;
  }

  public void setSortManager(ISortManager sortManager) {
    this.isSorted = Boolean.valueOf(false);
    this.sortedList.clear();
    this.sortManager = sortManager;
  }

  public String getStartDtoCuid() {
    return this.startDtoCuid;
  }

  public DataObjectList getSortListOnlyLink()
  {
    if (!this.isSorted.booleanValue()) {
      this.sortedList.clear();
      this.sortManager.sort(this);
    }

    DataObjectList dataObjectList = new DataObjectList();
    if ((this.sortedList != null) && (this.sortedList.size() > 0)) {
      for (int i = 0; i < this.sortedList.size(); i++) {
        GenericDO dto = (GenericDO)this.sortedList.get(i);
        if ((dto instanceof PhysicalLineJoin)) {
          dataObjectList.add(dto);
        }
      }
    }
    return dataObjectList;
  }

  public DataObjectList getSortListOnlyPoint() {
    if (!this.isSorted.booleanValue()) {
      this.sortedList.clear();
      this.sortManager.sort(this);
    }

    DataObjectList dataObjectList = new DataObjectList();
    if ((this.sortedList != null) && (this.sortedList.size() > 0)) {
      for (int i = 0; i < this.sortedList.size(); i++) {
        GenericDO dto = (GenericDO)this.sortedList.get(i);
        if (!(dto instanceof PhysicalLineJoin)) {
          dataObjectList.add(dto);
        }
      }
    }

    return dataObjectList;
  }

  public DataObjectList getSortedList() {
    if (!this.isSorted.booleanValue()) {
      this.sortedList.clear();
      this.sortManager.sort(this);
    }

    return this.sortedList;
  }

  class DefaultSortManager
    implements ISortManager
  {
    Map uniqueLinkMap = new HashMap();
    DataObjectList origLinkList = new DataObjectList();
    DataObjectList destLinkList = new DataObjectList();

    DefaultSortManager() {  } 
    public DataObjectList sort(LinkRouteInfo linkRouteInfo) { if ((LinkRouteInfo.this.links == null) || (LinkRouteInfo.this.links.size() == 0)) {
        return new DataObjectList();
      }
      GenericDO selectFirstLink = (GenericDO)LinkRouteInfo.this.links.get(0);
      if ((LinkRouteInfo.this.startDtoCuid != null) && (LinkRouteInfo.this.startDtoCuid.trim().length() > 0)) {
        for (int i = 0; i < LinkRouteInfo.this.links.size(); i++) {
          GenericDO link = (GenericDO)LinkRouteInfo.this.links.get(i);
          if ((link.getAttrValue("ORIG_POINT_CUID") != null) && (link.getAttrValue("ORIG_POINT_CUID").equals(LinkRouteInfo.this.startDtoCuid)))
          {
            selectFirstLink = link;
            break;
          }if ((link.getAttrValue("DEST_POINT_CUID") != null) && (link.getAttrValue("DEST_POINT_CUID").equals(LinkRouteInfo.this.startDtoCuid)))
          {
            selectFirstLink = link;
            break;
          }
        }
      }

      sortSeg((String)selectFirstLink.getAttrValue("ORIG_POINT_CUID"), selectFirstLink, this.origLinkList);
      Collections.reverse(this.origLinkList);
      LinkRouteInfo.this.sortedList.addAll(this.origLinkList);
      if (!LinkRouteInfo.this.sortedList.contains(selectFirstLink)) {
        LinkRouteInfo.this.sortedList.add(selectFirstLink);
      }
      sortSeg((String)selectFirstLink.getAttrValue("DEST_POINT_CUID"), selectFirstLink, this.destLinkList);
      LinkRouteInfo.this.sortedList.addAll(this.destLinkList);

      return LinkRouteInfo.this.sortedList; }

    private void sortSeg(String startPointCuid, GenericDO prvLink, DataObjectList dataObjectList)
    {
      if (startPointCuid != null) {
        for (int i = 0; i < LinkRouteInfo.this.links.size(); i++) {
          GenericDO link = (GenericDO)LinkRouteInfo.this.links.get(i);
          if (((link.getAttrValue("ORIG_POINT_CUID") != null) && (link.getAttrValue("ORIG_POINT_CUID").equals(startPointCuid))) || ((link.getAttrValue("DEST_POINT_CUID") != null) && (link.getAttrValue("DEST_POINT_CUID").equals(startPointCuid))))
          {
            if ((!link.equals(prvLink)) && 
              (this.uniqueLinkMap.get(link.getCuid()) == null)) {
              GenericDO linkOrigPoint = (GenericDO)LinkRouteInfo.this.pointMap.get(startPointCuid);
              if ((linkOrigPoint != null) && (this.uniqueLinkMap.get(linkOrigPoint.getCuid()) == null)) {
                dataObjectList.add(linkOrigPoint);
                this.uniqueLinkMap.put(linkOrigPoint.getCuid(), linkOrigPoint);
              }

              dataObjectList.add(link);
              this.uniqueLinkMap.put(link.getCuid(), link);
              String linkDestPointCuid;
              String linkDestPointCuid;
              if ((link.getAttrValue("ORIG_POINT_CUID") != null) && (link.getAttrValue("ORIG_POINT_CUID").equals(startPointCuid)))
              {
                linkDestPointCuid = (String)link.getAttrValue("DEST_POINT_CUID");
              }
              else linkDestPointCuid = (String)link.getAttrValue("ORIG_POINT_CUID");

              GenericDO linkDestPoint = (GenericDO)LinkRouteInfo.this.pointMap.get(linkDestPointCuid);
              if ((linkDestPoint != null) && (this.uniqueLinkMap.get(linkDestPoint.getCuid()) == null)) {
                dataObjectList.add(linkDestPoint);
                this.uniqueLinkMap.put(linkDestPoint.getCuid(), linkDestPoint);
              }

              sortSeg(linkDestPointCuid, link, dataObjectList);
            }
          }
        }

        if (dataObjectList.size() == 0) {
          GenericDO point = (GenericDO)LinkRouteInfo.this.pointMap.get(startPointCuid);
          if ((point != null) && (this.uniqueLinkMap.get(point.getCuid()) == null)) {
            dataObjectList.add(point);
            this.uniqueLinkMap.put(point.getCuid(), point);
          }
        }
      }
    }
  }
}