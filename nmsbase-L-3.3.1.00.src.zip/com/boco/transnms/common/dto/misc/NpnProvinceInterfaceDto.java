package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;

public class NpnProvinceInterfaceDto extends GenericDO
{
  public String relatedDistrict;
  public boolean isSheetOpen;
  public boolean isAlarmOpen;
  public String ipAddress;
  public long portNumber;

  public String getRelatedDistrcit()
  {
    return this.relatedDistrict;
  }
  public void setRelatedDistrict(String relatedDistrict) {
    this.relatedDistrict = relatedDistrict;
  }

  public boolean getIsSheetOpen() {
    return this.isSheetOpen;
  }
  public void setIsSheetOpen(boolean isSheetOpen) {
    this.isSheetOpen = isSheetOpen;
  }

  public boolean getIsAlarmOpen() {
    return this.isAlarmOpen;
  }
  public void setIsAlarmOpen(boolean isAlarmOpen) {
    this.isAlarmOpen = isAlarmOpen;
  }

  public String getIpAddress() {
    return this.ipAddress;
  }
  public void setIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
  }
  public long getPortNumber() {
    return this.portNumber;
  }
  public void setPortNumber(long portNumber) {
    this.portNumber = portNumber;
  }
}