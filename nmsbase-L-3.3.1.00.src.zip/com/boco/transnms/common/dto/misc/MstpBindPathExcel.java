package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;

public class MstpBindPathExcel extends GenericDO
{
  public static final String CLASS_NAME = "MSTPBINDPATHEXCEL";

  public MstpBindPathExcel()
  {
    super("MSTPBINDPATHEXCEL");
  }

  public void setDownListName(String downListName) {
    super.setAttrValue("DOWN_NAME", downListName);
  }

  public void setUpperListName(String upperListName) {
    super.setAttrValue("UPPER_NAME", upperListName);
  }

  public String getDownListName() {
    return super.getAttrString("DOWN_NAME");
  }

  public String getUpperListName() {
    return super.getAttrString("UPPER_NAME");
  }

  public static class AttrName
  {
    public static final String down_name = "DOWN_NAME";
    public static final String upper_name = "UPPER_NAME";
  }
}