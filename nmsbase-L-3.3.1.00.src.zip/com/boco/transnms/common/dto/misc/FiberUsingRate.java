package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class FiberUsingRate extends GenericDO
{
  public static final String CLASS_NAME = "FiberUsingRate";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public FiberUsingRate()
  {
    super("FiberUsingRate");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("Duct_System_LABEL_CN", String.class);
    this.attrTypeMap.put("FIBER_LEVEL", String.class);
    this.attrTypeMap.put("FIBER_LEVEL_CN", String.class);
    this.attrTypeMap.put("ORIG_SITE_CUID", String.class);
    this.attrTypeMap.put("ORIG_SITE_CN", String.class);
    this.attrTypeMap.put("DEST_SITE_CUID", String.class);
    this.attrTypeMap.put("DEST_SITE_CN", String.class);
    this.attrTypeMap.put("OCCUPIED", String.class);
    this.attrTypeMap.put("FIBERNUM", String.class);
    this.attrTypeMap.put("WARNINGLIMIT1", String.class);
    this.attrTypeMap.put("WARNINGLIMIT2", String.class);
    this.attrTypeMap.put("segcuid", String.class);
    this.attrTypeMap.put("segcuids", List.class);
    this.attrTypeMap.put("OVERLIMIT", String.class);
    this.attrTypeMap.put("USINGRATE", String.class);
  }

  public void setDuctsystem(String ductsystem)
  {
    super.setAttrValue("Duct_System_LABEL_CN", ductsystem);
  }

  public void setFiberlevel(String fiberlevel) {
    super.setAttrValue("FIBER_LEVEL", fiberlevel);
  }

  public void setOrigsite(String origsite) {
    super.setAttrValue("ORIG_SITE_CUID", origsite);
  }

  public void setDestsite(String destsite) {
    super.setAttrValue("DEST_SITE_CUID", destsite);
  }

  public void setOccupied(String occupied) {
    super.setAttrValue("OCCUPIED", occupied);
  }

  public String getDuctsystem() {
    return super.getAttrString("Duct_System_LABEL_CN");
  }

  public String getFiberlevel() {
    return super.getAttrString("FIBER_LEVEL");
  }

  public String getOrigsite() {
    return super.getAttrString("ORIG_SITE_CUID");
  }

  public String getDestsite() {
    return super.getAttrString("DEST_SITE_CUID");
  }

  public String getOccupied() {
    return super.getAttrString("OCCUPIED");
  }

  public void setWarninglimit1(String warninglimit1) {
    super.setAttrValue("WARNINGLIMIT1", warninglimit1);
  }

  public void setWarninglimit2(String warninglimit2) {
    super.setAttrValue("WARNINGLIMIT2", warninglimit2);
  }

  public String getWarninglimit1() {
    return super.getAttrString("WARNINGLIMIT1");
  }

  public String getWarninglimit2() {
    return super.getAttrString("WARNINGLIMIT1");
  }

  public void setSegcuid(String segcuid) {
    super.setAttrValue("segcuid", segcuid);
  }

  public String getSegcuid() {
    return super.getAttrString("segcuid");
  }

  public void setSegcuids(List segcuids) {
    super.setAttrValue("segcuids", segcuids);
  }

  public List getSegcuids() {
    return super.getAttrList("segcuids");
  }

  public void setOverlimit(String overlimit) {
    super.setAttrValue("OVERLIMIT", overlimit);
  }

  public void setUsingrate(String usingrate) {
    super.setAttrValue("USINGRATE", usingrate);
  }

  public String getOverlimit() {
    return super.getAttrString("OVERLIMIT");
  }

  public String getUsingrate() {
    return super.getAttrString("USINGRATE");
  }

  public void setFibernum(String fibernum) {
    super.setAttrValue("FIBERNUM", fibernum);
  }

  public void setOrigsitecn(String origsitecn) {
    super.setAttrValue("ORIG_SITE_CN", origsitecn);
  }

  public void setDestsitecn(String destsitecn) {
    super.setAttrValue("DEST_SITE_CN", destsitecn);
  }

  public void setFiberlevelcn(String fiberlevelcn) {
    super.setAttrValue("FIBER_LEVEL_CN", fiberlevelcn);
  }

  public String getFibernum() {
    return super.getAttrString("FIBERNUM");
  }

  public String getOrigsitecn() {
    return super.getAttrString("ORIG_SITE_CN");
  }

  public String getDestsitecn() {
    return super.getAttrString("DEST_SITE_CN");
  }

  public String getFiberlevelcn() {
    return super.getAttrString("FIBER_LEVEL_CN");
  }

  public static class AttrName
  {
    public static final String ductsystem = "Duct_System_LABEL_CN";
    public static final String fiberlevel = "FIBER_LEVEL";
    public static final String fiberlevelcn = "FIBER_LEVEL_CN";
    public static final String origsite = "ORIG_SITE_CUID";
    public static final String origsitecn = "ORIG_SITE_CN";
    public static final String destsite = "DEST_SITE_CUID";
    public static final String destsitecn = "DEST_SITE_CN";
    public static final String occupied = "OCCUPIED";
    public static final String fibernum = "FIBERNUM";
    public static final String warninglimit1 = "WARNINGLIMIT1";
    public static final String warninglimit2 = "WARNINGLIMIT2";
    public static final String segcuid = "segcuid";
    public static final String segcuids = "segcuids";
    public static final String overlimit = "OVERLIMIT";
    public static final String usingrate = "USINGRATE";
  }
}