package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class TransPaths extends GenericDO
{
  public static final String CLASS_NAME = "TRANS_PATH";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public TransPaths()
  {
    super("TRANS_PATH");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("NUMBER", String.class);
    this.attrTypeMap.put("PATH_STATE", String.class);
    this.attrTypeMap.put("CH_RATE", String.class);
    this.attrTypeMap.put("ORIG_SITE_CUID", String.class);
    this.attrTypeMap.put("DEST_SITE_CUID", String.class);
    this.attrTypeMap.put("ORIG_EQU_CUID", String.class);
    this.attrTypeMap.put("DEST_EQU_CUID", String.class);
    this.attrTypeMap.put("RELATED_A_END_PTP", String.class);
    this.attrTypeMap.put("RELATED_Z_END_PTP", String.class);
    this.attrTypeMap.put("ROUTE_DESCIPTION_A", String.class);
    this.attrTypeMap.put("ROUTE_DESCIPTION_Z", String.class);
  }

  public void setPathState(String pathState) {
    super.setAttrValue("PATH_STATE", pathState);
  }

  public void setNumber(String number) {
    super.setAttrValue("NUMBER", number);
  }

  public void setCRate(String cRate) {
    super.setAttrValue("CH_RATE", cRate);
  }

  public void setOrigSiteCuid(String origSiteCuid) {
    super.setAttrValue("ORIG_SITE_CUID", origSiteCuid);
  }

  public void setDestSiteCuid(String destSiteCuid) {
    super.setAttrValue("DEST_SITE_CUID", destSiteCuid);
  }

  public void setOrigEquCuid(String origEquCuid) {
    super.setAttrValue("ORIG_EQU_CUID", origEquCuid);
  }

  public void setDestEquCuid(String destEquCuid) {
    super.setAttrValue("DEST_EQU_CUID", destEquCuid);
  }

  public void setRelatedAEndPtp(String relatedAEndPtp) {
    super.setAttrValue("RELATED_A_END_PTP", relatedAEndPtp);
  }

  public void setRelatedZEndPtp(String relatedZEndPtp) {
    super.setAttrValue("RELATED_Z_END_PTP", relatedZEndPtp);
  }

  public void setRouteDesciptionA(String routeDesciptionA) {
    super.setAttrValue("ROUTE_DESCIPTION_A", routeDesciptionA);
  }

  public void setRouteDesctptionZ(String routeDesctptionZ) {
    super.setAttrValue("ROUTE_DESCIPTION_Z", routeDesctptionZ);
  }

  public String getPathState()
  {
    return super.getAttrString("PATH_STATE");
  }

  public String getNumber() {
    return super.getAttrString("NUMBER");
  }

  public String getCRate() {
    return super.getAttrString("CH_RATE");
  }

  public String getOrigSiteCuid() {
    return super.getAttrString("ORIG_SITE_CUID");
  }

  public String getDestSiteCuid() {
    return super.getAttrString("DEST_SITE_CUID");
  }

  public String getOrigEquCuid() {
    return super.getAttrString("ORIG_EQU_CUID");
  }

  public String getDestEquCuid() {
    return super.getAttrString("DEST_EQU_CUID");
  }

  public String getRelatedAEndPtp() {
    return super.getAttrString("RELATED_A_END_PTP");
  }

  public String getRelatedZEndPtp() {
    return super.getAttrString("RELATED_Z_END_PTP");
  }

  public String getRouteDesciptionA() {
    return super.getAttrString("ROUTE_DESCIPTION_A");
  }

  public String getRouteDesctptionZ() {
    return super.getAttrString("ROUTE_DESCIPTION_Z");
  }

  public static class AttrName
  {
    public static final String number = "NUMBER";
    public static final String pathState = "PATH_STATE";
    public static final String cRate = "CH_RATE";
    public static final String origSiteCuid = "ORIG_SITE_CUID";
    public static final String destSiteCuid = "DEST_SITE_CUID";
    public static final String origEquCuid = "ORIG_EQU_CUID";
    public static final String destEquCuid = "DEST_EQU_CUID";
    public static final String relatedAEndPtp = "RELATED_A_END_PTP";
    public static final String relatedZEndPtp = "RELATED_Z_END_PTP";
    public static final String routeDesciptionA = "ROUTE_DESCIPTION_A";
    public static final String routeDesctptionZ = "ROUTE_DESCIPTION_Z";
  }
}