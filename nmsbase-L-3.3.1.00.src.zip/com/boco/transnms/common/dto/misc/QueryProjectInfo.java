package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class QueryProjectInfo extends GenericDO
{
  public static final String CLASS_NAME = "QUERY_PROJECT_INFO";
  private final Map<String, Class> attrTypeMap = new HashMap();
  public String type;
  public String roomName;
  public String siteName;
  public String district;
  public String name;
  public String projectName;

  public QueryProjectInfo()
  {
    super("QUERY_PROJECT_INFO");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("TYPE", String.class);
    this.attrTypeMap.put("ROOM_NAME", String.class);
    this.attrTypeMap.put("SITE_NAME", String.class);
    this.attrTypeMap.put("DISTRICT_NAME", String.class);
    this.attrTypeMap.put("NAME", String.class);
    this.attrTypeMap.put("PROJECT_NAME", String.class);
  }

  public String getDistrict() {
    return this.district;
  }

  public String getName() {
    return this.name;
  }

  public String getProjectName() {
    return this.projectName;
  }

  public String getRoomName() {
    return this.roomName;
  }

  public String getSiteName() {
    return this.siteName;
  }

  public String getType() {
    return this.type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public void setRoomName(String roomName) {
    this.roomName = roomName;
  }

  public void setProjectName(String projectName) {
    this.projectName = projectName;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setDistrict(String district) {
    this.district = district;
  }

  public static class AttrName
  {
    public static final String type = "TYPE";
    public static final String roomName = "ROOM_NAME";
    public static final String siteName = "SITE_NAME";
    public static final String district = "DISTRICT_NAME";
    public static final String name = "NAME";
    public static final String projectName = "PROJECT_NAME";
  }
}