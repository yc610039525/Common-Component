package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.DboBlob;
import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class NetworkAdjustAttach extends GenericDO
{
  public static final String CLASS_NAME = "NETWORK_ADJUST_PRJ_ATTACH";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public NetworkAdjustAttach()
  {
    super("NETWORK_ADJUST_PRJ_ATTACH");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("ID", Long.class);
    this.attrTypeMap.put("ATTACH_FILENAME", String.class);
    this.attrTypeMap.put("ATTACH_DATA", DboBlob.class);
    this.attrTypeMap.put("NETWORK_ADJUST_PRJ_CUID", String.class);
    this.attrTypeMap.put("ATTACH_TYPE", Long.class);
  }

  public void setId(long id) {
    super.setAttrValue("ID", id);
  }

  public long getId() {
    return super.getAttrLong("ID");
  }

  public void setAttachFileName(String attachFileName) {
    super.setAttrValue("ATTACH_FILENAME", attachFileName);
  }

  public String getAttachFileName() {
    return super.getAttrString("ATTACH_FILENAME");
  }

  public void setAttachData(DboBlob attachData) {
    super.setAttrValue("ATTACH_DATA", attachData);
  }

  public DboBlob getAttachData() {
    return super.getAttrBlob("ATTACH_DATA");
  }

  public void setNetworkAdjustPrjCuid(String networkAdjustPrjCuid) {
    super.setAttrValue("NETWORK_ADJUST_PRJ_CUID", networkAdjustPrjCuid);
  }

  public String getNetworkAdjustPrjCuid() {
    return super.getAttrString("NETWORK_ADJUST_PRJ_CUID");
  }
  public void setAttachType(long attachType) {
    super.setAttrValue("ATTACH_TYPE", attachType);
  }

  public long getAttachType() {
    return super.getAttrLong("ATTACH_TYPE");
  }

  public static class AttrName
  {
    public static final String id = "ID";
    public static final String attachFileName = "ATTACH_FILENAME";
    public static final String attachData = "ATTACH_DATA";
    public static final String networkAdjustPrjCuid = "NETWORK_ADJUST_PRJ_CUID";
    public static final String attachType = "ATTACH_TYPE";
  }
}