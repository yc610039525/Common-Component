package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class BitsPortInfo extends GenericDO
{
  public static final String CLASS_NAME = "BITSPORT";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public BitsPortInfo()
  {
    super("BITSPORT");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("NUMBER", String.class);
    this.attrTypeMap.put("LABEL_CN", String.class);
    this.attrTypeMap.put("RELATED_NE_CUID", String.class);
    this.attrTypeMap.put("FREQUENCY", String.class);
    this.attrTypeMap.put("IMPEDANCE", String.class);
    this.attrTypeMap.put("PORT_STATE", String.class);
    this.attrTypeMap.put("QL_LEVEL", String.class);
    this.attrTypeMap.put("CUID", String.class);
  }

  public void setNumber(String number)
  {
    super.setAttrValue("NUMBER", number);
  }

  public void setLabelCn(String labelCn)
  {
    super.setAttrValue("LABEL_CN", labelCn);
  }

  public void setRelatedNeCuid(String relatedNeCuid)
  {
    super.setAttrValue("RELATED_NE_CUID", relatedNeCuid);
  }

  public void setFrequency(String frequency)
  {
    super.setAttrValue("FREQUENCY", frequency);
  }

  public void setImpedance(String impedance)
  {
    super.setAttrValue("IMPEDANCE", impedance);
  }

  public void setPortState(String portState)
  {
    super.setAttrValue("PORT_STATE", portState);
  }

  public void setQlLevel(String qlLevel)
  {
    super.setAttrValue("QL_LEVEL", qlLevel);
  }

  public void setCuid(String cuid)
  {
    super.setAttrValue("CUID", cuid);
  }

  public String getNumber()
  {
    return super.getAttrString("NUMBER");
  }

  public String getLabelCn()
  {
    return super.getAttrString("LABEL_CN");
  }

  public String getRelatedNeCuid()
  {
    return super.getAttrString("RELATED_NE_CUID");
  }

  public String getFrequency()
  {
    return super.getAttrString("FREQUENCY");
  }

  public String getImpedance()
  {
    return super.getAttrString("IMPEDANCE");
  }

  public String getPortState()
  {
    return super.getAttrString("PORT_STATE");
  }

  public String getQlLevel()
  {
    return super.getAttrString("QL_LEVEL");
  }

  public String getCuid()
  {
    return super.getAttrString("CUID");
  }

  public static class AttrName
  {
    public static final String number = "NUMBER";
    public static final String labelCn = "LABEL_CN";
    public static final String relatedNeCuid = "RELATED_NE_CUID";
    public static final String frequency = "FREQUENCY";
    public static final String impedance = "IMPEDANCE";
    public static final String portState = "PORT_STATE";
    public static final String qlLevel = "QL_LEVEL";
    public static final String cuid = "CUID";
  }
}