package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.TransPath;
import com.boco.transnms.common.dto.TransSubPath;
import com.boco.transnms.common.dto.TransSubPathIndi;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;

public class TraphPathDO extends GenericDO
{
  private TransPath traphPath;
  private DataObjectList transSubPathIndis;
  private DataObjectList transSubPaths;
  private DataObjectList transSubPathPoints;
  private TraphRoutePoint startDO;
  private TraphRoutePoint endDO;
  private Map sortedSubPathIndis;
  private Map sortedSubPaths;

  public TraphRoutePoint getStartDO()
  {
    return this.startDO;
  }

  public void setStartDO(TraphRoutePoint startDO) {
    this.startDO = startDO;
  }

  public TraphRoutePoint getEndDO() {
    return this.endDO;
  }

  public void setEndDO(TraphRoutePoint endDO) {
    this.endDO = endDO;
  }

  public void setTraphPath(TransPath traphPath) {
    this.traphPath = traphPath;
  }

  public TransPath getTraphPath() {
    return this.traphPath;
  }

  public void setTransSubPathIndis(DataObjectList transSubPathIndis)
  {
    this.transSubPathIndis = transSubPathIndis;
  }

  public void setTransSubPaths(DataObjectList transSubPaths)
  {
    this.transSubPaths = transSubPaths;
  }

  public DataObjectList getTransSubPaths()
  {
    return this.transSubPaths;
  }

  public DataObjectList getTransSubPathIndis() {
    return this.transSubPathIndis;
  }

  public DataObjectList getTransSubPathPoints() {
    return this.transSubPathPoints;
  }

  public void setTransSubPathPoints(DataObjectList transSubPathPoints) {
    this.transSubPathPoints = transSubPathPoints;
  }

  public Map getSortedTransSubPathIndi() {
    if (this.sortedSubPathIndis != null) {
      return this.sortedSubPathIndis;
    }
    this.sortedSubPathIndis = new HashMap();
    Long curRouteNum;
    if (this.transSubPathIndis != null) {
      this.transSubPathIndis.sort("ROUTE_NUM", true);

      curRouteNum = Long.valueOf(-1L);
      for (GenericDO dto : this.transSubPathIndis) {
        TransSubPathIndi transSubPathIndi = (TransSubPathIndi)dto;
        DataObjectList eachRoutePathIndis = null;
        if (transSubPathIndi.getRouteNum() > curRouteNum.longValue()) {
          curRouteNum = Long.valueOf(transSubPathIndi.getRouteNum());
          eachRoutePathIndis = new DataObjectList();
          this.sortedSubPathIndis.put(curRouteNum, eachRoutePathIndis);
          eachRoutePathIndis.add(transSubPathIndi);
        } else {
          eachRoutePathIndis.add(transSubPathIndi);
        }
      }
    }
    return this.sortedSubPathIndis;
  }

  public Map getSortedSubPaths()
  {
    if (this.sortedSubPaths != null) {
      return this.sortedSubPaths;
    }
    this.sortedSubPaths = new HashMap();
    Long curRouteNum;
    DataObjectList eachRoutePaths;
    if (this.transSubPaths != null) {
      this.transSubPaths.sort("SEG_NUM", true);
      this.transSubPaths.sort("ROUTE_NUM", true);

      curRouteNum = Long.valueOf(-1L);
      eachRoutePaths = null;
      for (GenericDO dto : this.transSubPaths) {
        TransSubPath transSubPath = (TransSubPath)dto;
        if (transSubPath.getRouteNum() > curRouteNum.longValue()) {
          curRouteNum = Long.valueOf(transSubPath.getRouteNum());
          eachRoutePaths = new DataObjectList();
          this.sortedSubPaths.put(curRouteNum, eachRoutePaths);
          eachRoutePaths.add(transSubPath);
        } else {
          eachRoutePaths.add(transSubPath);
        }
      }
    }

    return this.sortedSubPaths;
  }
}