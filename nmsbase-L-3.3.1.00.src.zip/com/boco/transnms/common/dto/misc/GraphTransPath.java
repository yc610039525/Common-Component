package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;

public class GraphTransPath extends GenericDO
{
  public static final String CLASS_NAME = "GRAPH_TRANS_PATH";

  public GraphTransPath()
  {
    super("GRAPH_TRANS_PATH");
    setChildNum(0);
  }

  public void setCuid(String varCuid)
  {
    setAttrValue("CUID", varCuid);
  }

  public String getCuid() {
    return getAttrString("CUID");
  }

  public void setChildNum(int varChildNum)
  {
    setAttrValue("CHILD_NUM", varChildNum);
  }

  public int getChildNum() {
    return getAttrInt("CHILD_NUM");
  }

  public void setPathCount(int varPathCount)
  {
    setAttrValue("PATH_COUNT", varPathCount);
  }

  public int getPathCount() {
    return getAttrInt("PATH_COUNT");
  }

  public void setPathStatus(int varPathStatus)
  {
    setAttrValue("PATH_STATUS", varPathStatus);
  }

  public int getPathStatus() {
    return getAttrInt("PATH_STATUS");
  }

  public void addChild(GenericDO obj)
  {
    int i = getChildNum();
    setAttrValue("child" + String.valueOf(i), obj);
    setChildNum(i + 1);
  }

  public GenericDO getChild(int i)
  {
    return (GenericDO)getAttrObj("child" + String.valueOf(i));
  }

  public void clearChild()
  {
    int iCount = getChildNum();
    for (int i = 0; i < iCount; i++) {
      removeAttr("child" + String.valueOf(i));
    }
    setChildNum(0);
  }

  public static class AttrName
  {
    public static final String Cuid = "CUID";
    public static final String ChildNum = "CHILD_NUM";
    public static final String PathCount = "PATH_COUNT";
    public static final String PathStatus = "PATH_STATUS";
  }
}