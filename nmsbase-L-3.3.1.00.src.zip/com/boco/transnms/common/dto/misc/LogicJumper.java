package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.PhysicalLineJoin;
import java.io.Serializable;

public class LogicJumper
  implements Serializable, Cloneable
{
  private PhysicalLineJoin upJumper;
  private PhysicalLineJoin downJumper;
  private String upLeftPointCuid;
  private String upRightPointCuid;
  private String downLeftPointCuid;
  private String downRightPointCuid;

  public void setUpJumper(PhysicalLineJoin upJumper)
  {
    this.upJumper = upJumper;
  }

  public void setDownJumper(PhysicalLineJoin downJumper) {
    this.downJumper = downJumper;
  }

  public PhysicalLineJoin getUpJumper() {
    return this.upJumper;
  }

  public PhysicalLineJoin getDownJumper() {
    return this.downJumper;
  }

  public void upToDown() {
    PhysicalLineJoin tempJumper = this.upJumper;
    this.downJumper = this.upJumper;
    this.upJumper = tempJumper;
  }

  public String getLineClassName() {
    if (this.upJumper != null) {
      return this.upJumper.getClassName();
    }
    return null;
  }

  public String getUpLeftPointCuid()
  {
    return this.upLeftPointCuid;
  }

  public void setUpLeftPointCuid(String upLeftPointCuid) {
    this.upLeftPointCuid = upLeftPointCuid;
  }

  public String getUpRightPointCuid() {
    return this.upRightPointCuid;
  }

  public void setUpRightPointCuid(String upRightPointCuid) {
    this.upRightPointCuid = upRightPointCuid;
  }

  public String getDownLeftPointCuid() {
    return this.downLeftPointCuid;
  }

  public void setDownLeftPointCuid(String downLeftPointCuid) {
    this.downLeftPointCuid = downLeftPointCuid;
  }

  public String getDownRightPointCuid() {
    return this.downRightPointCuid;
  }

  public void setDownRightPointCuid(String downRightPointCuid) {
    this.downRightPointCuid = downRightPointCuid;
  }
}