package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.PtnPath;
import com.boco.transnms.common.dto.PtnTurnnel;
import com.boco.transnms.common.dto.PtnVirtualLine;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;

public class PtnPathDO extends GenericDO
{
  public static final String CLASS_NAME = "PtnPathDO";
  private GenericDO trathService;
  private PtnVirtualLine virtualLine;
  private PtnTurnnel ptnTurnnel;
  private DataObjectList ptnIpCrossconnect;
  private PtnPath ptnPath;

  public PtnPath getPtnPath()
  {
    return this.ptnPath;
  }

  public void setPtnPath(PtnPath ptnPath) {
    this.ptnPath = ptnPath;
  }

  public DataObjectList getPtnIpCrossconnect() {
    return this.ptnIpCrossconnect;
  }

  public void setPtnIpCrossconnect(DataObjectList ptnIpCrossconnect) {
    this.ptnIpCrossconnect = ptnIpCrossconnect;
  }

  public GenericDO getTrathService() {
    return this.trathService;
  }

  public void setTrathService(GenericDO trathService) {
    this.trathService = trathService;
  }

  public PtnVirtualLine getVirtualLine() {
    return this.virtualLine;
  }

  public void setVirtualLine(PtnVirtualLine virtualLine) {
    this.virtualLine = virtualLine;
  }

  public PtnTurnnel getPtnTurnnel() {
    return this.ptnTurnnel;
  }

  public void setPtnTurnnel(PtnTurnnel ptnTurnnel) {
    this.ptnTurnnel = ptnTurnnel;
  }
}