package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class FreeChildHoles extends GenericDO
{
  public static final String CLASS_NAME = "FreeChildHoles";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public FreeChildHoles()
  {
    super("FreeChildHoles");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("Duct_System_LABEL_CN", String.class);
    this.attrTypeMap.put("Duct_Branch_LABEL_CN", String.class);
    this.attrTypeMap.put("ORIG_POINT_CUID", String.class);
    this.attrTypeMap.put("DEST_POINT_CUID", String.class);
    this.attrTypeMap.put("FREECHILDHOLE", String.class);
    this.attrTypeMap.put("CHILDHOLENUM", String.class);
    this.attrTypeMap.put("WARNINGLIMIT1", String.class);
    this.attrTypeMap.put("WARNINGLIMIT2", String.class);
    this.attrTypeMap.put("segcuid", String.class);
    this.attrTypeMap.put("segcuids", List.class);
    this.attrTypeMap.put("overlimit", String.class);
  }

  public void setDuctsystem(String ductsystem)
  {
    super.setAttrValue("Duct_System_LABEL_CN", ductsystem);
  }

  public void setDuctbranch(String ductbranch) {
    super.setAttrValue("Duct_Branch_LABEL_CN", ductbranch);
  }

  public void setOrigpoint(String origpoint) {
    super.setAttrValue("ORIG_POINT_CUID", origpoint);
  }

  public void setDestpoint(String destpoint) {
    super.setAttrValue("DEST_POINT_CUID", destpoint);
  }

  public void setFreechildhole(String freechildhole) {
    super.setAttrValue("FREECHILDHOLE", freechildhole);
  }

  public String getDuctsystem() {
    return super.getAttrString("Duct_System_LABEL_CN");
  }

  public String getDuctbranch() {
    return super.getAttrString("Duct_Branch_LABEL_CN");
  }

  public String getOrigpoint() {
    return super.getAttrString("ORIG_POINT_CUID");
  }

  public String getDestpoint() {
    return super.getAttrString("DEST_POINT_CUID");
  }

  public String getFreechildhole() {
    return super.getAttrString("FREECHILDHOLE");
  }

  public void setWarninglimit1(String warninglimit1) {
    super.setAttrValue("WARNINGLIMIT1", warninglimit1);
  }

  public void setWarninglimit2(String warninglimit2) {
    super.setAttrValue("WARNINGLIMIT2", warninglimit2);
  }

  public String getWarninglimit1() {
    return super.getAttrString("WARNINGLIMIT1");
  }

  public String getWarninglimit2() {
    return super.getAttrString("WARNINGLIMIT1");
  }

  public void setSegcuid(String segcuid) {
    super.setAttrValue("segcuid", segcuid);
  }

  public String getSegcuid() {
    return super.getAttrString("segcuid");
  }

  public void setSegcuids(List segcuids) {
    super.setAttrValue("segcuids", segcuids);
  }

  public List getSegcuids() {
    return super.getAttrList("segcuids");
  }

  public void setOverlimit(String overlimit) {
    super.setAttrValue("overlimit", overlimit);
  }

  public void setChildholenum(String childholenum) {
    super.setAttrValue("CHILDHOLENUM", childholenum);
  }

  public String getOverlimit() {
    return super.getAttrString("overlimit");
  }

  public String getChildholenum() {
    return super.getAttrString("CHILDHOLENUM");
  }

  public static class AttrName
  {
    public static final String ductsystem = "Duct_System_LABEL_CN";
    public static final String ductbranch = "Duct_Branch_LABEL_CN";
    public static final String origpoint = "ORIG_POINT_CUID";
    public static final String destpoint = "DEST_POINT_CUID";
    public static final String freechildhole = "FREECHILDHOLE";
    public static final String childholenum = "CHILDHOLENUM";
    public static final String warninglimit1 = "WARNINGLIMIT1";
    public static final String warninglimit2 = "WARNINGLIMIT2";
    public static final String segcuid = "segcuid";
    public static final String segcuids = "segcuids";
    public static final String overlimit = "overlimit";
  }
}