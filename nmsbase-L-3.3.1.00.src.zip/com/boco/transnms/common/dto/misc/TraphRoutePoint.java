package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.Ptp;
import com.boco.transnms.common.dto.Room;
import com.boco.transnms.common.dto.Site;
import com.boco.transnms.common.dto.SwitchPort;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import java.util.List;
import java.util.Map;

public class TraphRoutePoint extends GenericDO
{
  private Site site;
  private Room room;
  private GenericDO Element;
  private GenericDO stwithElement;
  private Ptp ptp;
  private SwitchPort switchPort;
  private DataObjectList dfportlist;
  private Map dfportmap;
  private Map switchPortmap;
  private String pointClassName;
  private String ctp;
  private List dftodfCuid;
  private DataObjectList dflist;
  private Ptp macPtp;
  private Ptp mpPtp;

  public Ptp getMacPtp()
  {
    return this.macPtp;
  }

  public void setMacPtp(Ptp macPtp) {
    this.macPtp = macPtp;
  }

  public Ptp getMpPtp() {
    return this.mpPtp;
  }

  public void setMpPtp(Ptp mpPtp) {
    this.mpPtp = mpPtp;
  }

  public void setSite(Site site)
  {
    this.site = site;
  }

  public void setRoom(Room room) {
    this.room = room;
  }

  public void setElement(GenericDO Element) {
    this.Element = Element;
  }

  public void setPtp(Ptp ptp) {
    this.ptp = ptp;
  }

  public void setDfport(DataObjectList dfportlist) {
    this.dfportlist = dfportlist;
  }

  public void setPointClassName(String pointClassName) {
    this.pointClassName = pointClassName;
  }

  public void setDftodfCuid(List dftodfCuid) {
    this.dftodfCuid = dftodfCuid;
  }

  public void setCtp(String ctp) {
    this.ctp = ctp;
  }

  public Site getSite() {
    return this.site;
  }

  public Room getRoom() {
    return this.room;
  }

  public GenericDO getElement() {
    return this.Element;
  }

  public Ptp getPtp() {
    return this.ptp;
  }

  public DataObjectList getDfport() {
    return this.dfportlist;
  }

  public String getPointClassName() {
    return this.pointClassName;
  }

  public List getDftodfCuid() {
    return this.dftodfCuid;
  }

  public String getCtp() {
    return this.ctp;
  }

  public void setdflist(DataObjectList dflist) {
    this.dflist = dflist;
  }

  public DataObjectList getdflist() {
    return this.dflist;
  }

  public void setStwithElement(GenericDO stwithElement) {
    this.stwithElement = stwithElement;
  }

  public GenericDO getStwithElement() {
    return this.stwithElement;
  }

  public Map getdfPortMap() {
    return this.dfportmap;
  }

  public void setdfPortMap(Map dfportmap) {
    this.dfportmap = dfportmap;
  }

  public void setSwitchPort(SwitchPort switchPort)
  {
    this.switchPort = switchPort;
  }

  public SwitchPort getSwitchPort() {
    return this.switchPort;
  }

  public void setswitchPortmap(Map switchPortmap)
  {
    this.switchPortmap = switchPortmap;
  }

  public Map getswitchPortmap() {
    return this.switchPortmap;
  }
}