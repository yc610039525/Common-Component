package com.boco.transnms.common.dto.misc;

import java.awt.Dimension;

public class ElementPic
{
  private String cuid;
  private int x;
  private int y;
  private Dimension size;

  public void setCuid(String cuid)
  {
    this.cuid = cuid;
  }

  public void setX(int x) {
    this.x = x;
  }

  public void setY(int y) {
    this.y = y;
  }

  public void setSize(Dimension size) {
    this.size = size;
  }

  public String getCuid() {
    return this.cuid;
  }

  public int getX() {
    return this.x;
  }

  public int getY() {
    return this.y;
  }

  public Dimension getSize() {
    return this.size;
  }
}