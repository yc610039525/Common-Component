package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class EMSInfo extends GenericDO
{
  public static final String CLASS_NAME = "NMS_SYSTEM";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public EMSInfo()
  {
    super("NMS_SYSTEM");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("NUMBER", String.class);
    this.attrTypeMap.put("NM_TYPE", String.class);
    this.attrTypeMap.put("RELATED_EMS_NAME", String.class);
    this.attrTypeMap.put("VERSION", String.class);
    this.attrTypeMap.put("LOCATION", String.class);
    this.attrTypeMap.put("RELATED_VENDOR_NAME", String.class);
    this.attrTypeMap.put("HARD_VERSION", String.class);
    this.attrTypeMap.put("SOFT_VERSION", String.class);
    this.attrTypeMap.put("OWNERSHIP", String.class);
    this.attrTypeMap.put("BUILD_DATE", String.class);
    this.attrTypeMap.put("PRESERVER_ADDR", String.class);
    this.attrTypeMap.put("PRESERVER_PHONE", String.class);
    this.attrTypeMap.put("REMARK", String.class);
    this.attrTypeMap.put("FDN", String.class);
    this.attrTypeMap.put("IP_ADDR", String.class);
    this.attrTypeMap.put("CONNECT_STATE", String.class);
    this.attrTypeMap.put("MAX_NE_COUNT", String.class);
    this.attrTypeMap.put("CUR_NE_COUNT", String.class);
    this.attrTypeMap.put("CREATOR", String.class);
    this.attrTypeMap.put("INTERFACE_NORTH", String.class);
    this.attrTypeMap.put("SUPPORT_PORT", String.class);
    this.attrTypeMap.put("MANAGE_SCOPES", String.class);
    this.attrTypeMap.put("USER_LABEL", String.class);
    this.attrTypeMap.put("NI_VERSION", String.class);
    this.attrTypeMap.put("NI_PORT", String.class);
    this.attrTypeMap.put("USE_STATE", String.class);
    this.attrTypeMap.put("EMS_TYPES", String.class);
  }

  public void setNumber(String number)
  {
    super.setAttrValue("NUMBER", number);
  }

  public void setManage_scopes(String manage_scopes) {
    super.setAttrValue("MANAGE_SCOPES", manage_scopes);
  }

  public void setUser_label(String user_label) {
    super.setAttrValue("USER_LABEL", user_label);
  }

  public void setNi_version(String ni_version) {
    super.setAttrValue("NI_VERSION", ni_version);
  }

  public void setNi_port(String ni_port) {
    super.setAttrValue("NI_PORT", ni_port);
  }

  public void setUse_state(String use_state) {
    super.setAttrValue("USE_STATE", use_state);
  }

  public void setnNmType(String nmType)
  {
    super.setAttrValue("NM_TYPE", nmType);
  }

  public void setLabelCn(String labelCn) {
    super.setAttrValue("RELATED_EMS_NAME", labelCn);
  }

  public void setVersion(String version) {
    super.setAttrValue("VERSION", version);
  }

  public void setLocation(String location) {
    super.setAttrValue("LOCATION", location);
  }

  public void setRelatedVendorName(String relatedVendorName) {
    super.setAttrValue("RELATED_VENDOR_NAME", relatedVendorName);
  }

  public void setHardVersion(String hardVersion) {
    super.setAttrValue("HARD_VERSION", hardVersion);
  }

  public void setSoftVersion(String softVersion) {
    super.setAttrValue("SOFT_VERSION", softVersion);
  }

  public void setOwnerShip(String ownership) {
    super.setAttrValue("OWNERSHIP", ownership);
  }

  public void setBuildDate(String buildDate) {
    super.setAttrValue("BUILD_DATE", buildDate);
  }

  public void setPreserverAddr(String preserverAddr) {
    super.setAttrValue("PRESERVER_ADDR", preserverAddr);
  }

  public void setPreserverPhone(String preserverPhone) {
    super.setAttrValue("PRESERVER_PHONE", preserverPhone);
  }

  public void setRemark(String remark) {
    super.setAttrValue("REMARK", remark);
  }

  public void setFdn(String fdn) {
    super.setAttrValue("FDN", fdn);
  }

  public void setIpAddr(String ipAddr) {
    super.setAttrValue("IP_ADDR", ipAddr);
  }

  public void setConnectState(String connectState) {
    super.setAttrValue("CONNECT_STATE", connectState);
  }

  public void setMaxNeConut(String maxNeConut) {
    super.setAttrValue("MAX_NE_COUNT", maxNeConut);
  }

  public void setCurNeCount(String curNeCount) {
    super.setAttrValue("CUR_NE_COUNT", curNeCount);
  }

  public void setCreator(String creator) {
    super.setAttrValue("CREATOR", creator);
  }

  public void setInterface_north(String interface_north) {
    super.setAttrValue("INTERFACE_NORTH", interface_north);
  }

  public void setSupport_port(String support_port) {
    super.setAttrValue("SUPPORT_PORT", support_port);
  }

  public String getNumber() {
    return super.getAttrString("NUMBER");
  }

  public String getNmType() {
    return super.getAttrString("NM_TYPE");
  }

  public String getLabelCn() {
    return super.getAttrString("RELATED_EMS_NAME");
  }

  public String getVersion() {
    return super.getAttrString("VERSION");
  }

  public String getLocation() {
    return super.getAttrString("LOCATION");
  }

  public String getRelatedVendorName() {
    return super.getAttrString("RELATED_VENDOR_NAME");
  }

  public String getHardVersion() {
    return super.getAttrString("HARD_VERSION");
  }

  public String getSoftVersion() {
    return super.getAttrString("SOFT_VERSION");
  }

  public String getOwnership() {
    return super.getAttrString("OWNERSHIP");
  }

  public String getBuildDatek() {
    return super.getAttrString("BUILD_DATE");
  }

  public String getPreserverAddr()
  {
    return super.getAttrString("PRESERVER_ADDR");
  }

  public String getPreserverPhone() {
    return super.getAttrString("PRESERVER_PHONE");
  }

  public String getRemark() {
    return super.getAttrString("REMARK");
  }

  public String getFdn() {
    return super.getAttrString("FDN");
  }

  public String getIpAddr() {
    return super.getAttrString("IP_ADDR");
  }

  public String getConnectState() {
    return super.getAttrString("CONNECT_STATE");
  }

  public String getMaxNeConut() {
    return super.getAttrString("MAX_NE_COUNT");
  }

  public String getCurNeCount() {
    return super.getAttrString("CUR_NE_COUNT");
  }

  public String getCreator() {
    return super.getAttrString("CREATOR");
  }

  public String getSupport_port() {
    return super.getAttrString("SUPPORT_PORT");
  }

  public String getInterface_north() {
    return super.getAttrString("INTERFACE_NORTH");
  }

  public String getManage_scopes() {
    return super.getAttrString("MANAGE_SCOPES");
  }

  public String getUser_label() {
    return super.getAttrString("USER_LABEL");
  }

  public String getNi_version() {
    return super.getAttrString("NI_VERSION");
  }

  public String getNi_port() {
    return super.getAttrString("NI_PORT");
  }

  public String getUse_state() {
    return super.getAttrString("USE_STATE");
  }

  public void setPostion(String postion) {
    super.setAttrValue("POSITION", postion);
  }

  public String getPostion() {
    return super.getAttrString("POSITION");
  }

  public void setEmsTypes(String emsTypes) {
    super.setAttrValue("EMS_TYPES", emsTypes);
  }

  public String getEmsTypes() {
    return super.getAttrString("EMS_TYPES");
  }

  public static class AttrName
  {
    public static final String number = "NUMBER";
    public static final String nmType = "NM_TYPE";
    public static final String labelCn = "RELATED_EMS_NAME";
    public static final String version = "VERSION";
    public static final String location = "LOCATION";
    public static final String relatedVendorName = "RELATED_VENDOR_NAME";
    public static final String hardVersion = "HARD_VERSION";
    public static final String softVersion = "SOFT_VERSION";
    public static final String ownership = "OWNERSHIP";
    public static final String buildDate = "BUILD_DATE";
    public static final String preserverAddr = "PRESERVER_ADDR";
    public static final String preserverPhone = "PRESERVER_PHONE";
    public static final String remark = "REMARK";
    public static final String fdn = "FDN";
    public static final String ipAddr = "IP_ADDR";
    public static final String connectState = "CONNECT_STATE";
    public static final String maxNeConut = "MAX_NE_COUNT";
    public static final String curNeCount = "CUR_NE_COUNT";
    public static final String creator = "CREATOR";
    public static final String interface_north = "INTERFACE_NORTH";
    public static final String support_port = "SUPPORT_PORT";
    public static final String manage_scopes = "MANAGE_SCOPES";
    public static final String user_label = "USER_LABEL";
    public static final String ni_version = "NI_VERSION";
    public static final String ni_port = "NI_PORT";
    public static final String use_state = "USE_STATE";
    public static final String postion = "POSITION";
    public static final String emsTypes = "EMS_TYPES";
  }
}