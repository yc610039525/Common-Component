package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class TraphWorkflowInfo extends GenericDO
{
  public static final String CLASS_NAME = "TRAPHWORKFLOWINFO";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public TraphWorkflowInfo()
  {
    super("TRAPHWORKFLOWINFO");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("NUMBER", String.class);
    this.attrTypeMap.put("HEADING_NUM", String.class);
    this.attrTypeMap.put("TITLE", String.class);
    this.attrTypeMap.put("STATE", String.class);
    this.attrTypeMap.put("NO", String.class);
    this.attrTypeMap.put("LABEL_CN", String.class);
    this.attrTypeMap.put("ATTEMP_RESULT", String.class);
    this.attrTypeMap.put("REQUEST_DATE", String.class);
    this.attrTypeMap.put("USE_DATE", String.class);
    this.attrTypeMap.put("PATH_INFO", String.class);
    this.attrTypeMap.put("ZJSITES", String.class);
  }

  public void setNumber(String number) {
    super.setAttrValue("NUMBER", number);
  }

  public String getNumber() {
    return super.getAttrString("NUMBER");
  }

  public void setHeadingNum(String headingNum) {
    super.setAttrValue("HEADING_NUM", headingNum);
  }

  public String getHeadingNum() {
    return super.getAttrString("HEADING_NUM");
  }

  public void setTitle(String title) {
    super.setAttrValue("TITLE", title);
  }

  public String getTitle() {
    return super.getAttrString("TITLE");
  }

  public void setState(String state) {
    super.setAttrValue("STATE", state);
  }

  public String getState() {
    return super.getAttrString("STATE");
  }

  public void setNo(String no) {
    super.setAttrValue("NO", no);
  }

  public String getNo() {
    return super.getAttrString("NO");
  }

  public void setLabelCn(String labelCn) {
    super.setAttrValue("LABEL_CN", labelCn);
  }

  public String getLabelCn() {
    return super.getAttrString("LABEL_CN");
  }

  public void setAttempResult(String attempResult) {
    super.setAttrValue("ATTEMP_RESULT", attempResult);
  }

  public String getAttempResult() {
    return super.getAttrString("ATTEMP_RESULT");
  }

  public void setRequestDate(String requestDate) {
    super.setAttrValue("REQUEST_DATE", requestDate);
  }

  public String getRequestDate() {
    return super.getAttrString("REQUEST_DATE");
  }

  public void setUseDate(String useDate) {
    super.setAttrValue("USE_DATE", useDate);
  }

  public String getUseDate() {
    return super.getAttrString("USE_DATE");
  }

  public void setPathInfo(String pathInfo) {
    super.setAttrValue("PATH_INFO", pathInfo);
  }

  public String getPathInfo() {
    return super.getAttrString("PATH_INFO");
  }

  public void setZjSites(String zjSites) {
    super.setAttrValue("ZJSITES", zjSites);
  }

  public String getZjSites() {
    return super.getAttrString("ZJSITES");
  }

  public static class AttrName
  {
    public static final String number = "NUMBER";
    public static final String headingNum = "HEADING_NUM";
    public static final String title = "TITLE";
    public static final String state = "STATE";
    public static final String no = "NO";
    public static final String labelCn = "LABEL_CN";
    public static final String attempResult = "ATTEMP_RESULT";
    public static final String requestDate = "REQUEST_DATE";
    public static final String useDate = "USE_DATE";
    public static final String pathInfo = "PATH_INFO";
    public static final String zjSites = "ZJSITES";
  }
}