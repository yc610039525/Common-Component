package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class CardInfo extends GenericDO
{
  public static final String CLASS_NAME = "CARD";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public CardInfo()
  {
    super("CARD");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("RELATED_DEVICE_CUID", String.class);
    this.attrTypeMap.put("PHY_RACK", String.class);
    this.attrTypeMap.put("PHY_SUBRACK", String.class);
    this.attrTypeMap.put("PHY_SHELF", String.class);
    this.attrTypeMap.put("PHY_PILOT", String.class);
    this.attrTypeMap.put("RELATED_UPPER_COMPONENT_CUID", String.class);
    this.attrTypeMap.put("MODEL", String.class);
    this.attrTypeMap.put("SERIAL", String.class);
    this.attrTypeMap.put("CARD_KIND", String.class);
    this.attrTypeMap.put("VERSION", String.class);
    this.attrTypeMap.put("LABEL_CN", String.class);
    this.attrTypeMap.put("SERVICE_STATE", String.class);
    this.attrTypeMap.put("REMARK", String.class);
    this.attrTypeMap.put("NATIVE_NAME", String.class);
    this.attrTypeMap.put("USE_TYPE", String.class);
    this.attrTypeMap.put("PROTECT_TYPE", String.class);
    this.attrTypeMap.put("PROTECT_CARD", String.class);
    this.attrTypeMap.put("IS_REPLACE", String.class);
    this.attrTypeMap.put("IS_PROTECT", String.class);
    this.attrTypeMap.put("PORT_TYPE", String.class);
    this.attrTypeMap.put("PORT_NUM", String.class);
    this.attrTypeMap.put("USERLABEL", String.class);
  }

  public void setRelatedDeviceCuid(String relatedDeviceCuid) {
    super.setAttrValue("RELATED_DEVICE_CUID", relatedDeviceCuid);
  }

  public void setPhyRack(String phyRack) {
    super.setAttrValue("PHY_RACK", phyRack);
  }

  public void setPhySubRack(String phySubRack) {
    super.setAttrValue("PHY_SUBRACK", phySubRack);
  }

  public void setPhyShelf(String phyShelf) {
    super.setAttrValue("PHY_SHELF", phyShelf);
  }

  public void setPhyPilot(String phyPilot) {
    super.setAttrValue("PHY_PILOT", phyPilot);
  }

  public void setRelatedUpperComponentCuid(String relatedUpperComponentCuid) {
    super.setAttrValue("RELATED_UPPER_COMPONENT_CUID", relatedUpperComponentCuid);
  }
  public void setModel(String model) {
    super.setAttrValue("MODEL", model);
  }

  public void setSerial(String serial) {
    super.setAttrValue("SERIAL", serial);
  }

  public void setCardKind(String cardKind) {
    super.setAttrValue("CARD_KIND", cardKind);
  }

  public void setVersion(String version) {
    super.setAttrValue("VERSION", version);
  }

  public void setLabelCn(String labelCn) {
    super.setAttrValue("LABEL_CN", labelCn);
  }

  public void setServiceStete(String serviceStete) {
    super.setAttrValue("SERVICE_STATE", serviceStete);
  }

  public void setRemark(String remark) {
    super.setAttrValue("REMARK", remark);
  }

  public void setNativeName(String nativeName) {
    super.setAttrValue("NATIVE_NAME", nativeName);
  }

  public void setUseType(String useType) {
    super.setAttrValue("USE_TYPE", useType);
  }

  public void setProtectType(String protectType) {
    super.setAttrValue("PROTECT_TYPE", protectType);
  }

  public void setProtectCard(String protectCard) {
    super.setAttrValue("PROTECT_CARD", protectCard);
  }

  public void setIsReplace(String isReplace) {
    super.setAttrValue("IS_REPLACE", isReplace);
  }

  public void setIsProtect(String isProtect) {
    super.setAttrValue("IS_PROTECT", isProtect);
  }

  public void setPortType(String portType) {
    super.setAttrValue("PORT_TYPE", portType);
  }

  public void setPortNum(String portNum) {
    super.setAttrValue("PORT_NUM", portNum);
  }

  public void setUserLabel(String userLabel) {
    super.setAttrValue("USERLABEL", userLabel);
  }

  public String getRelatedDeviceCuid()
  {
    return super.getAttrString("RELATED_DEVICE_CUID");
  }

  public String getPhyRack() {
    return super.getAttrString("PHY_RACK");
  }

  public String getPhySubRack() {
    return super.getAttrString("PHY_SUBRACK");
  }

  public String getPhyShelf() {
    return super.getAttrString("PHY_SHELF");
  }

  public String getPhyPilot() {
    return super.getAttrString("PHY_PILOT");
  }
  public String getRelatedUpperComponentCuid() {
    return super.getAttrString("RELATED_UPPER_COMPONENT_CUID");
  }

  public String getModel()
  {
    return super.getAttrString("MODEL");
  }

  public String getSerial() {
    return super.getAttrString("SERIAL");
  }

  public String getCardKind() {
    return super.getAttrString("CARD_KIND");
  }

  public String getVersion() {
    return super.getAttrString("VERSION");
  }

  public String getLabelCn() {
    return super.getAttrString("LABEL_CN");
  }

  public String getServiceStete() {
    return super.getAttrString("SERVICE_STATE");
  }

  public String getRemark() {
    return super.getAttrString("REMARK");
  }

  public String getNativeName() {
    return super.getAttrString("NATIVE_NAME");
  }

  public String getUseType() {
    return super.getAttrString("USE_TYPE");
  }

  public String getProtectType() {
    return super.getAttrString("PROTECT_TYPE");
  }

  public String getProtectCard() {
    return super.getAttrString("PROTECT_CARD");
  }

  public String getIsReplace() {
    return super.getAttrString("IS_REPLACE");
  }

  public String getIsProtect() {
    return super.getAttrString("IS_PROTECT");
  }

  public String getPortType() {
    return super.getAttrString("PORT_TYPE");
  }

  public String getPortNum() {
    return super.getAttrString("PORT_NUM");
  }
  public String getUserLabel() {
    return super.getAttrString("USERLABEL");
  }

  public static class AttrName
  {
    public static final String relatedDeviceCuid = "RELATED_DEVICE_CUID";
    public static final String phyRack = "PHY_RACK";
    public static final String phySubRack = "PHY_SUBRACK";
    public static final String phyShelf = "PHY_SHELF";
    public static final String phyPilot = "PHY_PILOT";
    public static final String relatedUpperComponentCuid = "RELATED_UPPER_COMPONENT_CUID";
    public static final String model = "MODEL";
    public static final String serial = "SERIAL";
    public static final String cardKind = "CARD_KIND";
    public static final String version = "VERSION";
    public static final String serviceStete = "SERVICE_STATE";
    public static final String remark = "REMARK";
    public static final String labelCn = "LABEL_CN";
    public static final String nativeName = "NATIVE_NAME";
    public static final String useType = "USE_TYPE";
    public static final String protectType = "PROTECT_TYPE";
    public static final String protectCard = "PROTECT_CARD";
    public static final String isReplace = "IS_REPLACE";
    public static final String isProtect = "IS_PROTECT";
    public static final String portType = "PORT_TYPE";
    public static final String portNum = "PORT_NUM";
    public static final String userLabel = "USERLABEL";
  }
}