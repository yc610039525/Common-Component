package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class AlarmSoundRule extends GenericDO
{
  public static final String CLASS_NAME = "ALARM_SOUND_RULE";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public AlarmSoundRule() {
    super("ALARM_SOUND_RULE");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes()
  {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("RELATED_USER_CUID", String.class);
    this.attrTypeMap.put("RELATED_DISTRICT_CUID", String.class);
    this.attrTypeMap.put("RELATED_NET_CUID", String.class);
    this.attrTypeMap.put("RELATED_TRANSSYS_CUID", String.class);
    this.attrTypeMap.put("RELATED_NE_CUID", String.class);
    this.attrTypeMap.put("RELATED_CARD_CUID", String.class);
    this.attrTypeMap.put("RELATED_PTP_CUID", String.class);
    this.attrTypeMap.put("RELATED_VENDOR_CUID", String.class);
    this.attrTypeMap.put("ALARM_SEVERITY", Long.TYPE);
    this.attrTypeMap.put("VENDOR_ALARM_NAME_CUID", String.class);
    this.attrTypeMap.put("SOUND_PERIOD", Long.TYPE);
    this.attrTypeMap.put("SOUND_LEVEL", Long.TYPE);
    this.attrTypeMap.put("SOUND_FILE_NAME", String.class);
    this.attrTypeMap.put("ACTSTART_TIME", Timestamp.class);
    this.attrTypeMap.put("ACTEND_TIME", Timestamp.class);
  }

  public void setRelatedUserCuid(String userCuid) {
    setAttrValue("RELATED_USER_CUID", userCuid);
  }

  public String getRelatedUserCuid() {
    return getAttrString("RELATED_USER_CUID");
  }

  public void setRelatedDistrictCuid(String districtCuid)
  {
    setAttrValue("RELATED_DISTRICT_CUID", districtCuid);
  }

  public String getRelatedDistrictCuid() {
    return getAttrString("RELATED_DISTRICT_CUID");
  }

  public void setRelatedNetCuid(String netCuid) {
    setAttrValue("RELATED_NET_CUID", netCuid);
  }

  public String getRelatedNetCuid() {
    return getAttrString("RELATED_NET_CUID");
  }

  public void setRelatedTransSysCuid(String transSysCuid) {
    setAttrValue("RELATED_TRANSSYS_CUID", transSysCuid);
  }

  public String getRelatedTransSysCuid() {
    return getAttrString("RELATED_TRANSSYS_CUID");
  }

  public void setRelatedNeCuid(String Necuid) {
    setAttrValue("RELATED_NE_CUID", Necuid);
  }

  public String getRelatedNeCuid() {
    return getAttrString("RELATED_NE_CUID");
  }

  public void setRelatedCardCuid(String cardCuid) {
    setAttrValue("RELATED_CARD_CUID", cardCuid);
  }

  public String getRelatedCardCuid() {
    return getAttrString("RELATED_CARD_CUID");
  }

  public void setRelatedPtpCuid(String ptpCuid) {
    setAttrValue("RELATED_PTP_CUID", ptpCuid);
  }

  public String getRelatedPtpCuid() {
    return getAttrString("RELATED_PTP_CUID");
  }

  public void setRelatedVendorCuid(String vendorCuid) {
    setAttrValue("RELATED_VENDOR_CUID", vendorCuid);
  }

  public String getRelatedVendorCuid() {
    return getAttrString("RELATED_VENDOR_CUID");
  }

  public void setAlarmSeverity(long alarmSeverity) {
    setAttrValue("ALARM_SEVERITY", alarmSeverity);
  }

  public long getAlarmSeverity() {
    return getAttrLong("ALARM_SEVERITY", 0L);
  }

  public void setVendorAlarmNameCuid(String vendorAlarmNameCuid) {
    setAttrValue("VENDOR_ALARM_NAME_CUID", vendorAlarmNameCuid);
  }

  public String getRelatedVendorAlarmNameCuid() {
    return getAttrString("VENDOR_ALARM_NAME_CUID");
  }

  public void setSoundPeriod(long soundPeriod) {
    setAttrValue("SOUND_PERIOD", soundPeriod);
  }

  public long getSoundPeriod() {
    return getAttrLong("SOUND_PERIOD", 0L);
  }

  public void setSoundLevel(long soundLevel) {
    setAttrValue("SOUND_LEVEL", soundLevel);
  }

  public long getSoundLevel() {
    return getAttrLong("SOUND_LEVEL", 0L);
  }

  public void setSoundFileName(String soundFileName) {
    setAttrValue("SOUND_FILE_NAME", soundFileName);
  }

  public String getSoundFileName() {
    return getAttrString("SOUND_FILE_NAME");
  }
  public Timestamp getActStartTime() {
    return getAttrDateTime("ACTSTART_TIME");
  }
  public void setActStartTime(Timestamp actStartTime) {
    setAttrValue("ACTSTART_TIME", actStartTime);
  }
  public Timestamp getActEndTime() {
    return getAttrDateTime("ACTEND_TIME");
  }
  public void setActEndTime(Timestamp actEndTime) {
    setAttrValue("ACTEND_TIME", actEndTime);
  }

  public static class AttrName
  {
    public static final String cuid = "CUID";
    public static final String relatedUserCuid = "RELATED_USER_CUID";
    public static final String relatedDistrictCuid = "RELATED_DISTRICT_CUID";
    public static final String relatedNetCuid = "RELATED_NET_CUID";
    public static final String relatedTransSysCuid = "RELATED_TRANSSYS_CUID";
    public static final String relatedNeCuid = "RELATED_NE_CUID";
    public static final String relatedCardCuid = "RELATED_CARD_CUID";
    public static final String relatedPtpCuid = "RELATED_PTP_CUID";
    public static final String relatedVendorCuid = "RELATED_VENDOR_CUID";
    public static final String alarmSeverity = "ALARM_SEVERITY";
    public static final String vendorAlarmNameCuid = "VENDOR_ALARM_NAME_CUID";
    public static final String soundPeriod = "SOUND_PERIOD";
    public static final String soundLevel = "SOUND_LEVEL";
    public static final String soundFileName = "SOUND_FILE_NAME";
    public static final String actStartTime = "ACTSTART_TIME";
    public static final String actEndTime = "ACTEND_TIME";
  }
}