package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;

public class BaseStatModel extends GenericDO
{
  private int id;
  private String ltab;
  private String rtab;
  private int value;
  private String condition;

  public int getId()
  {
    return this.id;
  }

  public String getCondition() {
    return this.condition;
  }

  public void setValue(int value) {
    this.value = value;
  }

  public void setId(int id) {
    this.id = id;
  }

  public void setCondition(String condition) {
    this.condition = condition;
  }

  public void setLtab(String ltab) {
    this.ltab = ltab;
  }

  public void setRtab(String rtab) {
    this.rtab = rtab;
  }

  public int getValue() {
    return this.value;
  }

  public String getLtab() {
    return this.ltab;
  }

  public String getRtab() {
    return this.rtab;
  }
}