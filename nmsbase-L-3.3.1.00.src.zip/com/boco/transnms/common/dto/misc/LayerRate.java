package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericEnumDO;

public class LayerRate extends GenericEnumDO<Long>
{
  public static final String CLASS_NAME = "LAYER_RATE";
  public static final String LR_NOT_APPLICABLE = "LR_NOT_APPLICABLE";
  public static final String LR_T1_AND_DS1_1_5M = "LR_T1_AND_DS1_1_5M";
  public static final String LR_T2_AND_DS2_6M = "LR_T2_AND_DS2_6M";
  public static final String LR_T3_AND_DS3_45M = "LR_T3_AND_DS3_45M";
  public static final String LR_E1_2M = "LR_E1_2M";
  public static final String LR_E2_8M = "LR_E2_8M";
  public static final String LR_E3_34M = "LR_E3_34M";
  public static final String LR_E4_140M = "LR_E4_140M";
  public static final String LR_E5_565M = "LR_E5_565M";
  public static final String LR_VT1_5_AND_TU11_VC11 = "LR_VT1_5_AND_TU11_VC11";
  public static final String LR_VT2_AND_TU12_VC12 = "LR_VT2_AND_TU12_VC12";
  public static final String LR_VT6_AND_TU2_VC2 = "LR_VT6_AND_TU2_VC2";
  public static final String LR_LOW_ORDER_TU3_VC3 = "LR_LOW_ORDER_TU3_VC3";
  public static final String LR_STS1_AND_AU3_HIGH_ORDER_VC3 = "LR_STS1_AND_AU3_HIGH_ORDER_VC3";
  public static final String LR_STS3C_AND_AU4_VC4 = "LR_STS3C_AND_AU4_VC4";
  public static final String LR_STS12C_AND_VC4_4C = "LR_STS12C_AND_VC4_4C";
  public static final String LR_STS48C_AND_VC4_16C = "LR_STS48C_AND_VC4_16C";
  public static final String LR_STS192C_AND_VC4_64C = "LR_STS192C_AND_VC4_64C";
  public static final String LR_SECTION_OC1_STS1_AND_RS_STM0 = "LR_SECTION_OC1_STS1_AND_RS_STM0";
  public static final String LR_SECTION_OC3_STS3_AND_RS_STM1 = "LR_SECTION_OC3_STS3_AND_RS_STM1";
  public static final String LR_SECTION_OC12_STS12_AND_RS_STM4 = "LR_SECTION_OC12_STS12_AND_RS_STM4";
  public static final String LR_SECTION_OC48_STS48_AND_RS_STM16 = "LR_SECTION_OC48_STS48_AND_RS_STM16";
  public static final String LR_SECTION_OC192_STS192_AND_RS_STM64 = "LR_SECTION_OC192_STS192_AND_RS_STM64";
  public static final String LR_LINE_OC1_STS1_AND_MS_STM0 = "LR_LINE_OC1_STS1_AND_MS_STM0";
  public static final String LR_LINE_OC3_STS3_AND_MS_STM1 = "LR_LINE_OC3_STS3_AND_MS_STM1";
  public static final String LR_LINE_OC12_STS12_AND_MS_STM4 = "LR_LINE_OC12_STS12_AND_MS_STM4";
  public static final String LR_LINE_OC48_STS48_AND_MS_STM16 = "LR_LINE_OC48_STS48_AND_MS_STM16";
  public static final String LR_LINE_OC192_STS192_AND_MS_STM64 = "LR_LINE_OC192_STS192_AND_MS_STM64";
  public static final String LR_ELECTRICAL_EC1_STS1_AND_STM0 = "LR_ELECTRICAL_EC1_STS1_AND_STM0";
  public static final String LR_ELECTRICAL_STS3_AND_STM1 = "LR_ELECTRICAL_STS3_AND_STM1";
  public static final String LR_ELECTRICAL_STS12_AND_STM4 = "LR_ELECTRICAL_STS12_AND_STM4";
  public static final String LR_RADIO_STS1_AND_STM0 = "LR_RADIO_STS1_AND_STM0";
  public static final String LR_RADIO_STS3_AND_STM1 = "LR_RADIO_STS3_AND_STM1";
  public static final String LR_RADIO_STS12_AND_STM4 = "LR_RADIO_STS12_AND_STM4";
  public static final String LR_OPTICAL_OC1_AND_STM0 = "LR_OPTICAL_OC1_AND_STM0";
  public static final String LR_OPTICAL_OC3_AND_STM1 = "LR_OPTICAL_OC3_AND_STM1";
  public static final String LR_OPTICAL_OC12_AND_STM4 = "LR_OPTICAL_OC12_AND_STM4";
  public static final String LR_OPTICAL_OC48_AND_STM16 = "LR_OPTICAL_OC48_AND_STM16";
  public static final String LR_OPTICAL_OC192_AND_STM64 = "LR_OPTICAL_OC192_AND_STM64";
  public static final String LR_OPTICAL_CHANNEL = "LR_OPTICAL_CHANNEL";
  public static final String LR_OPTICAL_MULTIPLEX_SECTION = "LR_OPTICAL_MULTIPLEX_SECTION";
  public static final String LR_OPTICAL_TRANSMISSION_SECTION = "LR_OPTICAL_TRANSMISSION_SECTION";
  public static final String LR_ATM_NI = "LR_ATM_NI";
  public static final String LR_ATM_VP = "LR_ATM_VP";
  public static final String LR_ATM_VC = "LR_ATM_VC";
  public static final String LR_PHYSICAL_ELECTRICAL = "LR_PHYSICAL_ELECTRICAL";
  public static final String LR_PHYSICAL_OPTICAL = "LR_PHYSICAL_OPTICAL";
  public static final String LR_PHYSICAL_MEDIALESS = "LR_PHYSICAL_MEDIALESS";
  public static final String LR_OPTICAL_SECTION = "LR_OPTICAL_SECTION";
  public static final String LR_DIGITAL_SIGNAL_layer_rate = "LR_DIGITAL_SIGNAL_layer_rate";
  public static final String LR_ASYNC_FOTS_150M = "LR_ASYNC_FOTS_150M";
  public static final String LR_ASYNC_FOTS_417M = "LR_ASYNC_FOTS_417M";
  public static final String LR_ASYNC_FOTS_560M = "LR_ASYNC_FOTS_560M";
  public static final String LR_ASYNC_FOTS_565M = "LR_ASYNC_FOTS_565M";
  public static final String LR_ASYNC_FOTS_1130M = "LR_ASYNC_FOTS_1130M";
  public static final String LR_ASYNC_FOTS_1G7 = "LR_ASYNC_FOTS_1G7";
  public static final String LR_ASYNC_FOTS_1G8 = "LR_ASYNC_FOTS_1G8";
  public static final String LR_D1_VIDEO = "LR_D1_VIDEO";
  public static final String LR_ESCON = "LR_ESCON";
  public static final String LR_ETR = "LR_ETR";
  public static final String LR_FAST_ETHERNET = "LR_FAST_ETHERNET";
  public static final String LR_FC_12_133M = "LR_FC_12_133M";
  public static final String LR_FC_25_266M = "LR_FC_25_266M";
  public static final String LR_FC_50_531M = "LR_FC_50_531M";
  public static final String LR_FC_100_1063M = "LR_FC_100_1063M";
  public static final String LR_FDDI = "LR_FDDI";
  public static final String LR_FICON = "LR_FICON";
  public static final String LR_GIGABIT_ETHERNET = "LR_GIGABIT_ETHERNET";
  public static final String LR_DS0_64K = "LR_DS0_64K";
  public static final String LR_ISDN_BRI = "LR_ISDN_BRI";
  public static final String LR_POTS = "LR_POTS";
  public static final String LR_DSR_OC1_STM0 = "LR_DSR_OC1_STM0";
  public static final String LR_DSR_OC3_STM1 = "LR_DSR_OC3_STM1";
  public static final String LR_DSR_OC12_STM4 = "LR_DSR_OC12_STM4";
  public static final String LR_DSR_OC24_STM8 = "LR_DSR_OC24_STM8";
  public static final String LR_DSR_OC48_AND_STM16 = "LR_DSR_OC48_AND_STM16";
  public static final String LR_DSR_OC192_AND_STM64 = "LR_DSR_OC192_AND_STM64";
  public static final String LR_DSR_OC768_AND_STM256 = "LR_DSR_OC768_AND_STM256";
  public static final String LR_DSR_1_5M = "LR_DSR_1_5M";
  public static final String LR_DSR_2M = "LR_DSR_2M";
  public static final String LR_DSR_6M = "LR_DSR_6M";
  public static final String LR_DSR_8M = "LR_DSR_8M";
  public static final String LR_DSR_34M = "LR_DSR_34M";
  public static final String LR_DSR_45M = "LR_DSR_45M";
  public static final String LR_DSR_140M = "LR_DSR_140M";
  public static final String LR_DSR_565M = "LR_DSR_565M";
  public static final String LR_DSR_GIGABIT_ETHERNET = "LR_DSR_GIGABIT_ETHERNET";
  public static final String LR_SECTION_OC24_STS24_AND_RS_STM8 = "LR_SECTION_OC24_STS24_AND_RS_STM8";
  public static final String LR_LINE_OC24_STS24_AND_MS_STM8 = "LR_LINE_OC24_STS24_AND_MS_STM8";
  public static final String LR_SECTION_OC768_STS768_AND_RS_STM256 = "LR_SECTION_OC768_STS768_AND_RS_STM256";
  public static final String LR_LINE_OC768_STS768_AND_MS_STM256 = "LR_LINE_OC768_STS768_AND_MS_STM256";
  public static final String LR_E20_2 = "LR_E20_2";
  public static final String LR_E30_8 = "LR_E30_8";
  public static final String LR_Ethernet = "LR_Ethernet";
  public static final String LR_DSR_Fast_ethernet = "LR_DSR_Fast_ethernet";
  public static final String LR_Encapsulation = "LR_Encapsulation";
  public static final String LR_Fragment = "LR_Fragment";
  public static final String LR_STS6c_and_VC4_2c = "LR_STS6c_and_VC4_2c";
  public static final String LR_STS24c_and_VC4_8c = "LR_STS24c_and_VC4_8c";
  public static final String LR_OCH_Data_Unit_1 = "LR_OCH_Data_Unit_1";
  public static final String LR_OCH_Data_Unit_2 = "LR_OCH_Data_Unit_2";
  public static final String LR_OCH_Data_Unit_3 = "LR_OCH_Data_Unit_3";
  public static final String LR_OCH_Transport_Unit_1 = "LR_OCH_Transport_Unit_1";
  public static final String LR_OCH_Transport_Unit_2 = "LR_OCH_Transport_Unit_2";
  public static final String LR_OCH_Transport_Unit_3 = "LR_OCH_Transport_Unit_3";
  public static final String LR_DSR_OTU1 = "LR_DSR_OTU1";
  public static final String LR_DSR_OTU2 = "LR_DSR_OTU2";
  public static final String LR_DSR_OTU3 = "LR_DSR_OTU3";
  public static final String LR_DSR_10Gigabit_Ethernet = "LR_DSR_10Gigabit_Ethernet";
  public static final String LR_DSR_4M = "LR_DSR_4M";
  public static final String LR_DSR_16M = "LR_DSR_16M";
  public static final String LR_DSR_DVB = "LR_DSR_DVB";
  public static final String LR_DVB = "LR_DVB";
  public static final String LR_MSTP_Ethernet_10M = "LR_MSTP_Ethernet_10M";
  public static final String LR_MSTP_Ethernet_100M = "LR_MSTP_Ethernet_100M";
  public static final String LR_MSTP_Ethernet_1G = "LR_MSTP_Ethernet_1G";
  public static final String LR_MSTP_Ethernet_10G = "LR_MSTP_Ethernet_10G";
  public static final String LR_E13_3 = "LR_E13_3";
  public static final String LR_E16_6 = "LR_E16_6";
  public static final String LR_E32_2 = "LR_E32_2";
  public static final String LR_E42_2 = "LR_E42_2";
  public static final int LR_NOT_APPLICABLE_NUM = 1;
  public static final int LR_T1_AND_DS1_1_5M_NUM = 2;
  public static final int LR_T2_AND_DS2_6M_NUM = 3;
  public static final int LR_T3_AND_DS3_45M_NUM = 4;
  public static final int LR_E1_2M_NUM = 5;
  public static final int LR_E2_8M_NUM = 6;
  public static final int LR_E3_34M_NUM = 7;
  public static final int LR_E4_140M_NUM = 8;
  public static final int LR_E5_565M_NUM = 9;
  public static final int LR_VT1_5_AND_TU11_VC11_NUM = 10;
  public static final int LR_VT2_AND_TU12_VC12_NUM = 11;
  public static final int LR_VT6_AND_TU2_VC2_NUM = 12;
  public static final int LR_LOW_ORDER_TU3_VC3_NUM = 13;
  public static final int LR_STS1_AND_AU3_HIGH_ORDER_VC3_NUM = 14;
  public static final int LR_STS3C_AND_AU4_VC4_NUM = 15;
  public static final int LR_STS12C_AND_VC4_4C_NUM = 16;
  public static final int LR_STS48C_AND_VC4_16C_NUM = 17;
  public static final int LR_STS192C_AND_VC4_64C_NUM = 18;
  public static final int LR_SECTION_OC1_STS1_AND_RS_STM0_NUM = 19;
  public static final int LR_SECTION_OC3_STS3_AND_RS_STM1_NUM = 20;
  public static final int LR_SECTION_OC12_STS12_AND_RS_STM4_NUM = 21;
  public static final int LR_SECTION_OC48_STS48_AND_RS_STM16_NUM = 22;
  public static final int LR_SECTION_OC192_STS192_AND_RS_STM64_NUM = 23;
  public static final int LR_LINE_OC1_STS1_AND_MS_STM0_NUM = 24;
  public static final int LR_LINE_OC3_STS3_AND_MS_STM1_NUM = 25;
  public static final int LR_LINE_OC12_STS12_AND_MS_STM4_NUM = 26;
  public static final int LR_LINE_OC48_STS48_AND_MS_STM16_NUM = 27;
  public static final int LR_LINE_OC192_STS192_AND_MS_STM64_NUM = 28;
  public static final int LR_ELECTRICAL_EC1_STS1_AND_STM0_NUM = 29;
  public static final int LR_ELECTRICAL_STS3_AND_STM1_NUM = 30;
  public static final int LR_ELECTRICAL_STS12_AND_STM4_NUM = 31;
  public static final int LR_RADIO_STS1_AND_STM0_NUM = 32;
  public static final int LR_RADIO_STS3_AND_STM1_NUM = 33;
  public static final int LR_RADIO_STS12_AND_STM4_NUM = 34;
  public static final int LR_OPTICAL_OC1_AND_STM0_NUM = 35;
  public static final int LR_OPTICAL_OC3_AND_STM1_NUM = 36;
  public static final int LR_OPTICAL_OC12_AND_STM4_NUM = 37;
  public static final int LR_OPTICAL_OC48_AND_STM16_NUM = 38;
  public static final int LR_OPTICAL_OC192_AND_STM64_NUM = 39;
  public static final int LR_OPTICAL_CHANNEL_NUM = 40;
  public static final int LR_OPTICAL_MULTIPLEX_SECTION_NUM = 41;
  public static final int LR_OPTICAL_TRANSMISSION_SECTION_NUM = 42;
  public static final int LR_ATM_NI_NUM = 43;
  public static final int LR_ATM_VP_NUM = 44;
  public static final int LR_ATM_VC_NUM = 45;
  public static final int LR_PHYSICAL_ELECTRICAL_NUM = 46;
  public static final int LR_PHYSICAL_OPTICAL_NUM = 47;
  public static final int LR_PHYSICAL_MEDIALESS_NUM = 48;
  public static final int LR_OPTICAL_SECTION_NUM = 49;
  public static final int LR_DIGITAL_SIGNAL_layer_rate_NUM = 50;
  public static final int LR_ASYNC_FOTS_150M_NUM = 51;
  public static final int LR_ASYNC_FOTS_417M_NUM = 52;
  public static final int LR_ASYNC_FOTS_560M_NUM = 53;
  public static final int LR_ASYNC_FOTS_565M_NUM = 54;
  public static final int LR_ASYNC_FOTS_1130M_NUM = 55;
  public static final int LR_ASYNC_FOTS_1G7_NUM = 56;
  public static final int LR_ASYNC_FOTS_1G8_NUM = 57;
  public static final int LR_D1_VIDEO_NUM = 58;
  public static final int LR_ESCON_NUM = 59;
  public static final int LR_ETR_NUM = 60;
  public static final int LR_FAST_ETHERNET_NUM = 61;
  public static final int LR_FC_12_133M_NUM = 62;
  public static final int LR_FC_25_266M_NUM = 63;
  public static final int LR_FC_50_531M_NUM = 64;
  public static final int LR_FC_100_1063M_NUM = 65;
  public static final int LR_FDDI_NUM = 66;
  public static final int LR_FICON_NUM = 67;
  public static final int LR_GIGABIT_ETHERNET_NUM = 68;
  public static final int LR_DS0_64K_NUM = 69;
  public static final int LR_ISDN_BRI_NUM = 70;
  public static final int LR_POTS_NUM = 71;
  public static final int LR_DSR_OC1_STM0_NUM = 72;
  public static final int LR_DSR_OC3_STM1_NUM = 73;
  public static final int LR_DSR_OC12_STM4_NUM = 74;
  public static final int LR_DSR_OC24_STM8_NUM = 75;
  public static final int LR_DSR_OC48_AND_STM16_NUM = 76;
  public static final int LR_DSR_OC192_AND_STM64_NUM = 77;
  public static final int LR_DSR_OC768_AND_STM256_NUM = 78;
  public static final int LR_DSR_1_5M_NUM = 79;
  public static final int LR_DSR_2M_NUM = 80;
  public static final int LR_DSR_6M_NUM = 81;
  public static final int LR_DSR_8M_NUM = 82;
  public static final int LR_DSR_34M_NUM = 83;
  public static final int LR_DSR_45M_NUM = 84;
  public static final int LR_DSR_140M_NUM = 85;
  public static final int LR_DSR_565M_NUM = 86;
  public static final int LR_DSR_GIGABIT_ETHERNET_NUM = 87;
  public static final int LR_SECTION_OC24_STS24_AND_RS_STM8_NUM = 88;
  public static final int LR_LINE_OC24_STS24_AND_MS_STM8_NUM = 89;
  public static final int LR_SECTION_OC768_STS768_AND_RS_STM256_NUM = 90;
  public static final int LR_LINE_OC768_STS768_AND_MS_STM256_NUM = 91;
  public static final int LR_E20_2_NUM = 94;
  public static final int LR_E30_8_NUM = 95;
  public static final int LR_Ethernet_NUM = 96;
  public static final int LR_DSR_Fast_ethernet_NUM = 97;
  public static final int LR_Encapsulation_NUM = 98;
  public static final int LR_Fragment_NUM = 99;
  public static final int LR_STS6c_and_VC4_2c_NUM = 100;
  public static final int LR_STS24c_and_VC4_8c_NUM = 103;
  public static final int LR_OCH_Data_Unit_1_NUM = 104;
  public static final int LR_OCH_Data_Unit_2_NUM = 105;
  public static final int LR_OCH_Data_Unit_3_NUM = 106;
  public static final int LR_OCH_Transport_Unit_1_NUM = 107;
  public static final int LR_OCH_Transport_Unit_2_NUM = 108;
  public static final int LR_OCH_Transport_Unit_3_NUM = 109;
  public static final int LR_DSR_OTU1_NUM = 110;
  public static final int LR_DSR_OTU2_NUM = 111;
  public static final int LR_DSR_OTU3_NUM = 112;
  public static final int LR_DSR_10Gigabit_Ethernet_NUM = 113;
  public static final int LR_DSR_4M_NUM = 300;
  public static final int LR_DSR_16M_NUM = 301;
  public static final int LR_DSR_DVB_NUM = 302;
  public static final int LR_DVB_NUM = 303;
  public static final int LR_MSTP_Ethernet_10M_NUM = 692;
  public static final int LR_MSTP_Ethernet_100M_NUM = 693;
  public static final int LR_MSTP_Ethernet_1G_NUM = 694;
  public static final int LR_MSTP_Ethernet_10G_NUM = 695;
  public static final int LR_E13_3_NUM = 697;
  public static final int LR_E16_6_NUM = 698;
  public static final int LR_E32_2_NUM = 700;
  public static final int LR_E42_2_NUM = 701;

  public LayerRate()
  {
    super("LAYER_RATE");
  }

  public Long getLayerNum() {
    return Long.valueOf(getAttrLong("SEG_LAYER"));
  }

  public Long getRateNum() {
    return Long.valueOf(getAttrLong("RATE_NUM"));
  }

  public String getLayerRateName() {
    return getAttrString("KEY_VALUE");
  }

  public Long getLayerRateNum() {
    return Long.valueOf(getAttrLong("KEY_NUM"));
  }

  protected void initAttrTypes()
  {
    super.initAttrTypes();
    setAttrType("OBJECT_TYPE", Long.TYPE);
    setAttrType("SEG_LAYER", Long.TYPE);
    setAttrType("RATE_NUM", Long.TYPE);
    setAttrType("KEY_NUM", Long.TYPE);
    setAttrType("KEY_VALUE", String.class);
  }

  public static class AttrName
  {
    public static final String ojbectType = "OBJECT_TYPE";
    public static final String enumName = "KEY_VALUE";
    public static final String enumValue = "KEY_NUM";
    public static final String segLayer = "SEG_LAYER";
    public static final String rateNum = "RATE_NUM";
  }
}