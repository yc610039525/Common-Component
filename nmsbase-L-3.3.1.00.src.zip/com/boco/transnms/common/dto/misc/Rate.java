package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericEnumDO;

public class Rate extends GenericEnumDO
{
  public static final String CLASS_NAME = "RATE";

  public Rate()
  {
    super("RATE");
    initAttrTypes();
  }

  public String getCallName() {
    return getAttrString("CALL_NAME");
  }

  public String getKeyValue() {
    return getAttrString("KEY_VALUE");
  }

  public long getKeyNum() {
    return getAttrLong("KEY_NUM");
  }

  public long getConver2mCount() {
    return getAttrLong("CONVER2M_COUNT");
  }

  protected void initAttrTypes()
  {
    super.initAttrTypes();
    setAttrType("OBJECT_TYPE", Long.TYPE);
    setAttrType("CALL_NAME", String.class);
    setAttrType("KEY_VALUE", String.class);
    setAttrType("KEY_NUM", Long.TYPE);
    setAttrType("CONVER2M_COUNT", Long.TYPE);
  }

  public static class AttrName
  {
    public static final String ojbectType = "OBJECT_TYPE";
    public static final String callName = "CALL_NAME";
    public static final String keyValue = "KEY_VALUE";
    public static final String keyNum = "KEY_NUM";
    public static final String conver2mCount = "CONVER2M_COUNT";
  }
}