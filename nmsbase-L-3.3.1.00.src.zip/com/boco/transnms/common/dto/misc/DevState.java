package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class DevState extends GenericDO
{
  private static final long serialVersionUID = 1L;
  public static final String CLASS_NAME = "DevState";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public DevState()
  {
    super("DevState");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("DEV_NAME", String.class);
    this.attrTypeMap.put("DEV_TYPE", Long.TYPE);
    this.attrTypeMap.put("DEV_IP", String.class);
    this.attrTypeMap.put("DEV_PORT", Integer.TYPE);
    this.attrTypeMap.put("User_Name", String.class);
    this.attrTypeMap.put("DEV_STATE", Long.TYPE);
    this.attrTypeMap.put("LOG_TIME", Timestamp.class);
    this.attrTypeMap.put("INTERVAL_CYCLE", Long.TYPE);
    this.attrTypeMap.put("DEV_INFO", String.class);
    this.attrTypeMap.put("RELATED_RTU", String.class);
    this.attrTypeMap.put("ATTACH_DATA", Object.class);
    this.attrTypeMap.put("CURRENT_STATE", Long.TYPE);
  }

  public void setCuid(String varCuid) {
    setAttrValue("CUID", varCuid);
  }
  public String getCuid() {
    return getAttrString("CUID");
  }
  public void setDevName(String vardevName) {
    setAttrValue("DEV_NAME", vardevName);
  }
  public String getDevName() {
    return getAttrString("DEV_NAME");
  }
  public void setDevType(Long vardevType) {
    setAttrValue("DEV_TYPE", vardevType);
  }
  public long getDevType() {
    return getAttrLong("DEV_TYPE");
  }
  public void setDevIp(String vardevIp) {
    setAttrValue("DEV_IP", vardevIp);
  }
  public String getDevIp() {
    return getAttrString("DEV_IP");
  }
  public void setDevPort(String devPort) {
    setAttrValue("DEV_PORT", devPort);
  }
  public String getDevPort() {
    return getAttrString("DEV_PORT");
  }
  public void setUserName(String userName) {
    setAttrValue("User_Name", userName);
  }
  public String getUserName() {
    return getAttrString("User_Name");
  }
  public void setDevState(Long vardevState) {
    setAttrValue("DEV_STATE", vardevState);
  }
  public long getDevState() {
    return getAttrLong("DEV_STATE");
  }
  public void setLogTime(Timestamp varlogTime) {
    setAttrValue("LOG_TIME", varlogTime);
  }
  public Timestamp getLogTime() {
    return getAttrDateTime("LOG_TIME");
  }
  public void setIntervalCycle(Long varintervalCycle) {
    setAttrValue("INTERVAL_CYCLE", varintervalCycle);
  }
  public long getIntervalCycle() {
    return getAttrLong("INTERVAL_CYCLE");
  }
  public void setDevInfo(String vardevInfo) {
    setAttrValue("DEV_INFO", vardevInfo);
  }
  public String getDevInfo() {
    return getAttrString("DEV_INFO");
  }
  public void setRelatedTtu(String varRelatedRtu) {
    setAttrValue("RELATED_RTU", varRelatedRtu);
  }
  public String getRelatedTtu() {
    return getAttrString("RELATED_RTU");
  }

  public void setAttachData(Object attachData) {
    setAttrValue("ATTACH_DATA", attachData);
  }

  public Object getAttachData() {
    return getAttrValue("ATTACH_DATA");
  }

  public void setCurrentState(Long currentState) {
    setAttrValue("CURRENT_STATE", currentState);
  }
  public long getCurrentState() {
    return getAttrLong("CURRENT_STATE");
  }

  public static class AttrName
  {
    public static final String Cuid = "CUID";
    public static final String devName = "DEV_NAME";
    public static final String devType = "DEV_TYPE";
    public static final String devIp = "DEV_IP";
    public static final String devPort = "DEV_PORT";
    public static final String userName = "User_Name";
    public static final String devState = "DEV_STATE";
    public static final String logTime = "LOG_TIME";
    public static final String intervalCycle = "INTERVAL_CYCLE";
    public static final String devInfo = "DEV_INFO";
    public static final String relatedRtu = "RELATED_RTU";
    public static final String attachData = "ATTACH_DATA";
    public static final String currentState = "CURRENT_STATE";
  }
}