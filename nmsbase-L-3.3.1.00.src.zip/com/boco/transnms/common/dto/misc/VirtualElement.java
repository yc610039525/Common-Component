package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class VirtualElement extends GenericDO
{
  public static final String CLASS_NAME = "VIRTUAL_ELEMENT";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public VirtualElement()
  {
    super("VIRTUAL_ELEMENT");
    initAttrTypes();
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("LABEL_CN", String.class);
    this.attrTypeMap.put("LOCATION", String.class);
    this.attrTypeMap.put("RELATED_ELEMENT_CUID", String.class);
    this.attrTypeMap.put("LOCATION_X", Integer.class);
    this.attrTypeMap.put("LOCATION_Y", Integer.class);
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  public void setLabelCn(String varLabelCn) {
    setAttrValue("LABEL_CN", varLabelCn);
  }

  public String getLabelCn() {
    return getAttrString("LABEL_CN");
  }

  public void setLocation(String varLocation) {
    setAttrValue("LOCATION", varLocation);
  }

  public String getLocation() {
    return getAttrString("LOCATION");
  }

  public void setLocationX(int varLocationX) {
    setAttrValue("LOCATION_X", varLocationX);
  }

  public int getLocationX() {
    return getAttrInt("LOCATION_X", 0);
  }

  public void setLocationY(int varLocationY) {
    setAttrValue("LOCATION_Y", varLocationY);
  }

  public int getLocationY() {
    return getAttrInt("LOCATION_Y", 0);
  }

  public void setRelatedElementCuids(String varRelatedElementCuids) {
    setAttrValue("RELATED_ELEMENT_CUID", varRelatedElementCuids);
  }

  public String getRelatedElementCuids() {
    return getAttrString("RELATED_ELEMENT_CUID");
  }

  public static class AttrName
  {
    public static final String Cuid = "CUID";
    public static final String LabelCn = "LABEL_CN";
    public static final String Location = "LOCATION";
    public static final String RelatedElementCuids = "RELATED_ELEMENT_CUID";
    public static final String LocationX = "LOCATION_X";
    public static final String LocationY = "LOCATION_Y";
  }
}