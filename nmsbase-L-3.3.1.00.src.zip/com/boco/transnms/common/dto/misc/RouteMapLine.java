package com.boco.transnms.common.dto.misc;

public class RouteMapLine
{
  private String aCuid = "";
  private String zCuid = "";
  private String Cuid = "";

  public void setACuid(String varACuid) {
    this.aCuid = varACuid;
  }

  public String getACuid() {
    return this.aCuid;
  }

  public void setZCuid(String varZCuid) {
    this.zCuid = varZCuid;
  }

  public String getZCuid() {
    return this.zCuid;
  }

  public void setCuid(String varACuid, String varZCuid) {
    setACuid(varACuid);
    setZCuid(varZCuid);

    if (this.aCuid.compareTo(this.zCuid) < 0)
      this.Cuid = (this.aCuid + "_" + this.zCuid);
    else
      this.Cuid = (this.zCuid + "_" + this.aCuid);
  }

  public void setCuid(String varCuid)
  {
    this.zCuid = varCuid;
  }

  public String getCuid() {
    return this.Cuid;
  }
}