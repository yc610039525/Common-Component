package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;

public class AlarmToTraphDetail extends GenericDO
{
  private String alarmName;
  private String alarmDesc;
  private String alarmCriterionEnglish;
  private String alarmCriterionChinese;
  private String alarmReason;
  private String alarmLocation;
  private String layerRate;
  private String alarmLevel;
  private String alarmType;
  private String alarmStartTime;
  private String alarmEndTime;
  private String remark;
  private String alarmState;
  private String alarmToTraph;
  private String alarmToTransSystem;
  private String neModel;
  private String cardkind;
  private String alarmRelatedDistrictName;
  private String alarmRelatedSiteName;
  private String alarmRelatedRoomName;
  private String alarmRelatedRackName;
  private String alarmRelatedEms;
  private String alarmSubNetwork;
  private String ackTime;
  private String ackUser;
  private String alarmCuid;

  public void setAlarmName(String alarmName)
  {
    this.alarmName = alarmName;
  }

  public void setAlarmDesc(String alarmDesc) {
    this.alarmDesc = alarmDesc;
  }

  public void setAlarmCriterionEnglish(String alarmCriterionEnglish) {
    this.alarmCriterionEnglish = alarmCriterionEnglish;
  }

  public void setAlarmCriterionChinese(String alarmCriterionChinese) {
    this.alarmCriterionChinese = alarmCriterionChinese;
  }

  public void setAlarmReason(String alarmReason) {
    this.alarmReason = alarmReason;
  }

  public void setAlarmLocation(String alarmLocation) {
    this.alarmLocation = alarmLocation;
  }

  public void setLayerRate(String layerRate) {
    this.layerRate = layerRate;
  }

  public void setAlarmLevel(String alarmLevel) {
    this.alarmLevel = alarmLevel;
  }

  public void setAlarmType(String alarmType) {
    this.alarmType = alarmType;
  }

  public void setAlarmStartTime(String alarmStartTime) {
    this.alarmStartTime = alarmStartTime;
  }

  public void setAlarmEndTime(String alarmEndTime) {
    this.alarmEndTime = alarmEndTime;
  }

  public void setRemark(String remark) {
    this.remark = remark;
  }

  public void setAlarmState(String alarmState) {
    this.alarmState = alarmState;
  }

  public void setAlarmToTraph(String alarmToTraph) {
    this.alarmToTraph = alarmToTraph;
  }

  public void setAlarmToTransSystem(String alarmToTransSystem) {
    this.alarmToTransSystem = alarmToTransSystem;
  }

  public void setNeModel(String neModel) {
    this.neModel = neModel;
  }

  public void setCardkind(String cardkind) {
    this.cardkind = cardkind;
  }

  public void setAlarmRelatedDistrictName(String alarmRelatedDistrictName) {
    this.alarmRelatedDistrictName = alarmRelatedDistrictName;
  }

  public void setAlarmRelatedSiteName(String alarmRelatedSiteName) {
    this.alarmRelatedSiteName = alarmRelatedSiteName;
  }

  public void setAlarmRelatedRoomName(String alarmRelatedRoomName) {
    this.alarmRelatedRoomName = alarmRelatedRoomName;
  }

  public void setAlarmRelatedRackName(String alarmRelatedRackName) {
    this.alarmRelatedRackName = alarmRelatedRackName;
  }

  public void setAlarmRelatedEms(String alarmRelatedEms) {
    this.alarmRelatedEms = alarmRelatedEms;
  }

  public void setAlarmSubNetwork(String alarmSubNetwork) {
    this.alarmSubNetwork = alarmSubNetwork;
  }

  public void setAckTime(String ackTime) {
    this.ackTime = ackTime;
  }

  public void setAckUser(String ackUser) {
    this.ackUser = ackUser;
  }

  public void setAlarmCuid(String alarmCuid) {
    this.alarmCuid = alarmCuid;
  }

  public String getAlarmName() {
    return this.alarmName;
  }

  public String getAlarmDesc() {
    return this.alarmDesc;
  }

  public String getAlarmCriterionEnglish() {
    return this.alarmCriterionEnglish;
  }

  public String getAlarmCriterionChinese() {
    return this.alarmCriterionChinese;
  }

  public String getAlarmReason() {
    return this.alarmReason;
  }

  public String getAlarmLocation() {
    return this.alarmLocation;
  }

  public String getLayerRate() {
    return this.layerRate;
  }

  public String getAlarmLevel() {
    return this.alarmLevel;
  }

  public String getAlarmType() {
    return this.alarmType;
  }

  public String getAlarmStartTime() {
    return this.alarmStartTime;
  }

  public String getAlarmEndTime() {
    return this.alarmEndTime;
  }

  public String getRemark() {
    return this.remark;
  }

  public String getAlarmState() {
    return this.alarmState;
  }

  public String getAlarmToTraph() {
    return this.alarmToTraph;
  }

  public String getAlarmToTransSystem() {
    return this.alarmToTransSystem;
  }

  public String getNeModel() {
    return this.neModel;
  }

  public String getCardkind() {
    return this.cardkind;
  }

  public String getAlarmRelatedDistrictName() {
    return this.alarmRelatedDistrictName;
  }

  public String getAlarmRelatedSiteName() {
    return this.alarmRelatedSiteName;
  }

  public String getAlarmRelatedRoomName() {
    return this.alarmRelatedRoomName;
  }

  public String getAlarmRelatedRackName() {
    return this.alarmRelatedRackName;
  }

  public String getAlarmRelatedEms() {
    return this.alarmRelatedEms;
  }

  public String getAlarmSubNetwork() {
    return this.alarmSubNetwork;
  }

  public String getAckTime() {
    return this.ackTime;
  }

  public String getAckUser() {
    return this.ackUser;
  }

  public String getAlarmCuid() {
    return this.alarmCuid;
  }
}