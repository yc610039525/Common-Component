package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.DboBlob;
import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class CallboardAttach extends GenericDO
{
  public static final String CLASS_NAME = "CALLBOARD_ATTACH";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public CallboardAttach()
  {
    super("CALLBOARD_ATTACH");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("ID", Long.TYPE);
    this.attrTypeMap.put("ATTACH_FILENAME", String.class);
    this.attrTypeMap.put("ATTACH_DATA", DboBlob.class);
    this.attrTypeMap.put("RELATED_CALLBOARD_CUID", String.class);
  }

  public void setId(long id) {
    super.setAttrValue("ID", id);
  }

  public long getId() {
    return super.getAttrLong("ID");
  }

  public void setAttachFileName(String attachFileName) {
    super.setAttrValue("ATTACH_FILENAME", attachFileName);
  }

  public String getAttachFileName() {
    return super.getAttrString("ATTACH_FILENAME");
  }

  public void setAttachData(DboBlob attachData) {
    super.setAttrValue("ATTACH_DATA", attachData);
  }

  public DboBlob getAttachData() {
    return super.getAttrBlob("ATTACH_DATA");
  }

  public void setRelatedCallboardCuid(String relatedCallboardCuid) {
    super.setAttrValue("RELATED_CALLBOARD_CUID", relatedCallboardCuid);
  }

  public String getRelatedCallboardCuid() {
    return super.getAttrString("RELATED_CALLBOARD_CUID");
  }

  public static class AttrName
  {
    public static final String id = "ID";
    public static final String attachFileName = "ATTACH_FILENAME";
    public static final String attachData = "ATTACH_DATA";
    public static final String relatedCallboardCuid = "RELATED_CALLBOARD_CUID";
  }
}