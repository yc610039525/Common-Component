package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.DboBlob;
import com.boco.transnms.common.dto.base.GenericDO;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class WfAttach extends GenericDO
{
  public static final String CLASS_NAME = "WF_ATTACH";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public WfAttach() {
    super("WF_ATTACH");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("RELATED_SHEET_CUID", String.class);
    this.attrTypeMap.put("ATTACH_TYPE", Long.TYPE);
    this.attrTypeMap.put("ATTACH_FILENAME", String.class);
    this.attrTypeMap.put("ATTACH_DATA", DboBlob.class);
    this.attrTypeMap.put("EOMS_ID", String.class);
    this.attrTypeMap.put("ATTACH_URL", String.class);
    this.attrTypeMap.put("DISTRICT_CUID", String.class);
    this.attrTypeMap.put("REQUEST_DATE", Timestamp.class);
    this.attrTypeMap.put("DGN_DATE", Timestamp.class);
  }

  public void setCuid(String varCuid) {
    setAttrValue("CUID", varCuid);
  }

  public String getCuid() {
    return getAttrString("CUID");
  }

  public String getRelatedSheetCuid()
  {
    return getAttrString("RELATED_SHEET_CUID");
  }

  public void setRelatedSheetCuid(String RelatedSheetCuid) {
    setAttrValue("RELATED_SHEET_CUID", RelatedSheetCuid);
  }

  public void setAttachType(long AttachType) {
    setAttrValue("ATTACH_TYPE", AttachType);
  }

  public long getAttachType() {
    return getAttrLong("ATTACH_TYPE");
  }

  public String getAttachFileName() {
    return getAttrString("ATTACH_FILENAME");
  }

  public void setAttachFileName(String AttachFileName) {
    setAttrValue("ATTACH_FILENAME", AttachFileName);
  }

  public void setAttachData(DboBlob AttachData) {
    setAttrValue("ATTACH_DATA", AttachData);
  }

  public DboBlob getAttachData() {
    return getAttrBlob("ATTACH_DATA");
  }

  public void setEomsID(String eomsId) {
    setAttrValue("EOMS_ID", eomsId);
  }

  public String getEomsID() {
    return getAttrString("EOMS_ID");
  }

  public void setAttachUrl(String attachUrl) {
    setAttrValue("ATTACH_URL", attachUrl);
  }

  public String getAttachUrl() {
    return getAttrString("ATTACH_URL");
  }

  public void setRequestDate(Timestamp requestDate)
  {
    setAttrValue("REQUEST_DATE", requestDate);
  }

  public Timestamp getRequestDate() {
    return getAttrDateTime("REQUEST_DATE");
  }

  public void setDgnDate(Timestamp dgnDate) {
    setAttrValue("DGN_DATE", dgnDate);
  }

  public Timestamp getDgnDate() {
    return getAttrDateTime("DGN_DATE");
  }

  public void setDistrictCuid(String districtCuid) {
    setAttrValue("DISTRICT_CUID", districtCuid);
  }

  public Timestamp getDistrictCuid() {
    return getAttrDateTime("DISTRICT_CUID");
  }

  public static class AttrName
  {
    public static final String Cuid = "CUID";
    public static final String RelatedSheetCuid = "RELATED_SHEET_CUID";
    public static final String AttachType = "ATTACH_TYPE";
    public static final String AttachFileName = "ATTACH_FILENAME";
    public static final String AttachData = "ATTACH_DATA";
    public static final String EomsID = "EOMS_ID";
    public static final String AttachUrl = "ATTACH_URL";
    public static final String RequestDate = "REQUEST_DATE";
    public static final String DistrictCuid = "DISTRICT_CUID";
    public static final String DgnDate = "DGN_DATE";
  }
}