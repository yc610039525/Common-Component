package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class XdfPort extends GenericDO
{
  public static final String CLASS_NAME = "XDF_PORT";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public XdfPort()
  {
    super("XDF_PORT");
    initAttrTypes();
  }

  public Class getAttrType(String attrName)
  {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("DISTRICT_NAME", String.class);
    this.attrTypeMap.put("SITE_NAME", String.class);
    this.attrTypeMap.put("ROOM_NAME", String.class);
    this.attrTypeMap.put("XDF_NAME", String.class);
    this.attrTypeMap.put("PORT_NAME", String.class);
    this.attrTypeMap.put("IS_CONNECTED", String.class);
    this.attrTypeMap.put("CONN_PORT_NAME", String.class);
    this.attrTypeMap.put("TRAPH_NAME", String.class);
    this.attrTypeMap.put("TRANS_SYSTEM_NAME", String.class);
  }

  public void setDistrictName(String districtName)
  {
    super.setAttrValue("DISTRICT_NAME", districtName);
  }

  public void setSiteName(String siteName) {
    super.setAttrValue("SITE_NAME", siteName);
  }

  public void setRoomName(String roomName) {
    super.setAttrValue("ROOM_NAME", roomName);
  }

  public void setXdfName(String xdfName) {
    super.setAttrValue("XDF_NAME", xdfName);
  }

  public void setPortName(String portName) {
    super.setAttrValue("PORT_NAME", portName);
  }

  public void setIsConnected(String isConnected) {
    super.setAttrValue("IS_CONNECTED", isConnected);
  }

  public void setConnPortName(String connPortName) {
    super.setAttrValue("CONN_PORT_NAME", connPortName);
  }

  public void setTraphName(String traphName) {
    super.setAttrValue("TRAPH_NAME", traphName);
  }

  public void setTransSystemName(String transSystemName) {
    super.setAttrValue("TRANS_SYSTEM_NAME", transSystemName);
  }

  public String getDistrictName() {
    return super.getAttrString("DISTRICT_NAME");
  }

  public String getSiteName() {
    return super.getAttrString("SITE_NAME");
  }

  public String getRoomName() {
    return super.getAttrString("ROOM_NAME");
  }

  public String getXdfName() {
    return super.getAttrString("XDF_NAME");
  }

  public String getPortName() {
    return super.getAttrString("PORT_NAME");
  }

  public String getIsConnected() {
    return super.getAttrString("IS_CONNECTED");
  }

  public String getConnPortName() {
    return super.getAttrString("CONN_PORT_NAME");
  }

  public String getTraphName() {
    return super.getAttrString("TRAPH_NAME");
  }

  public String getTransSystemName() {
    return super.getAttrString("TRANS_SYSTEM_NAME");
  }

  public static class AttrName
  {
    public static final String districtName = "DISTRICT_NAME";
    public static final String siteName = "SITE_NAME";
    public static final String roomName = "ROOM_NAME";
    public static final String xdfName = "XDF_NAME";
    public static final String portName = "PORT_NAME";
    public static final String isConnected = "IS_CONNECTED";
    public static final String connPortName = "CONN_PORT_NAME";
    public static final String traphName = "TRAPH_NAME";
    public static final String transSystemName = "TRANS_SYSTEM_NAME";
  }
}