package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class FreeChildHoleDetails extends GenericDO
{
  public static final String CLASS_NAME = "FreeChildHoleDetails";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public FreeChildHoleDetails()
  {
    super("FreeChildHoleDetails");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("ORIG_POINT_CUID", String.class);
    this.attrTypeMap.put("DEST_POINT_CUID", String.class);
    this.attrTypeMap.put("HOLENO", String.class);
    this.attrTypeMap.put("CHILDHOLENO", String.class);
    this.attrTypeMap.put("segcuid", String.class);
    this.attrTypeMap.put("cable", String.class);
  }

  public void setOrigpoint(String origpoint)
  {
    super.setAttrValue("ORIG_POINT_CUID", origpoint);
  }

  public void setDestpoint(String destpoint) {
    super.setAttrValue("DEST_POINT_CUID", destpoint);
  }

  public void setHoleno(String holeno) {
    super.setAttrValue("HOLENO", holeno);
  }

  public String getOrigpoint() {
    return super.getAttrString("ORIG_POINT_CUID");
  }

  public String getDestpoint() {
    return super.getAttrString("DEST_POINT_CUID");
  }

  public String getHoleno() {
    return super.getAttrString("HOLENO");
  }

  public void setSegcuid(String segcuid) {
    super.setAttrValue("segcuid", segcuid);
  }

  public String getSegcuid() {
    return super.getAttrString("segcuid");
  }

  public void setChildholeno(String childholeno) {
    super.setAttrValue("CHILDHOLENO", childholeno);
  }

  public String getChildholeno() {
    return super.getAttrString("CHILDHOLENO");
  }

  public void setCable(String cable) {
    super.setAttrValue("cable", cable);
  }

  public String getCable() {
    return super.getAttrString("cable");
  }

  public static class AttrName
  {
    public static final String origpoint = "ORIG_POINT_CUID";
    public static final String destpoint = "DEST_POINT_CUID";
    public static final String holeno = "HOLENO";
    public static final String childholeno = "CHILDHOLENO";
    public static final String segcuid = "segcuid";
    public static final String cable = "cable";
  }
}