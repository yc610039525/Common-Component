package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericEnumDO;

public class TraphServiceType extends GenericEnumDO
{
  public static final String CLASS_NAME = "TRAPH_SERVICE_TYPE";

  public TraphServiceType()
  {
    super("TRAPH_SERVICE_TYPE");
  }

  protected void initAttrTypes() {
    super.initAttrTypes();
    setAttrType("EXT_DESC", String.class);
    setAttrType("COLOR", Long.TYPE);
    setAttrType("LABEL_COLOR", String.class);
    setAttrType("IMPORT_LEVEL", Long.TYPE);
    setAttrType("IMPORT_TRAPH", Boolean.TYPE);
    setAttrType("IS_TD", Long.TYPE);
  }

  public void setExtDesc(String extDesc) {
    super.setAttrValue("EXT_DESC", extDesc);
  }

  public String getExtDesc() {
    return super.getAttrString("EXT_DESC");
  }

  public void setKeyNum(long keyNum) {
    super.setAttrValue("KEY_NUM", keyNum);
  }
  public long getKeyNum() {
    return super.getAttrLong("KEY_NUM", 0L);
  }
  public void setKeyValue(String keyValue) {
    super.setAttrValue("KEY_VALUE", keyValue);
  }
  public String getKeyValue() {
    return super.getAttrString("KEY_VALUE");
  }
  public void setColor(long color) {
    super.setAttrValue("COLOR", color);
  }
  public long getColor() {
    return super.getAttrLong("COLOR", 0L);
  }
  public void setLabelColor(String labelColor) {
    super.setAttrValue("LABEL_COLOR", labelColor);
  }
  public String getLabelColor() {
    return super.getAttrString("LABEL_COLOR");
  }
  public void setImportLevel(long importLevel) {
    super.setAttrValue("IMPORT_LEVEL", importLevel);
  }
  public long getImportLevel() {
    return super.getAttrLong("IMPORT_LEVEL", 0L);
  }
  public void setImportTraph(boolean importTraph) {
    super.setAttrValue("IMPORT_TRAPH", importTraph);
  }
  public boolean getImportTraph() {
    return super.getAttrBool("IMPORT_TRAPH");
  }
  public void setIsTD(long isTD) {
    super.setAttrValue("IS_TD", isTD);
  }
  public long getIsTD() {
    return super.getAttrLong("IS_TD", 0L);
  }

  public static class AttrName
  {
    public static final String keyNum = "KEY_NUM";
    public static final String keyValue = "KEY_VALUE";
    public static final String extDesc = "EXT_DESC";
    public static final String color = "COLOR";
    public static final String labelColor = "LABEL_COLOR";
    public static final String importLevel = "IMPORT_LEVEL";
    public static final String importTraph = "IMPORT_TRAPH";
    public static final String isTD = "IS_TD";
  }
}