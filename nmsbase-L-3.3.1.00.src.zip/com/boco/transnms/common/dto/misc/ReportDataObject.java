package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;

public class ReportDataObject extends GenericDO
{
  private DataObjectList dataObjectList;
  private Boolean isOverLimit;
  private String warningPolicyChildHole;
  private String WarningLimit1Name;
  private String WarningLimit2Name;
  private String[][] dataGrid;
  private String averageUsableRate;

  public void setDataObjectList(DataObjectList dataObjectList)
  {
    this.dataObjectList = dataObjectList;
  }

  public void setIsOverLimit(Boolean isOverLimit) {
    this.isOverLimit = isOverLimit;
  }

  public void setWarningPolicyChildHole(String warningPolicyChildHole) {
    this.warningPolicyChildHole = warningPolicyChildHole;
  }

  public void setDataGrid(String[][] dataGrid) {
    this.dataGrid = dataGrid;
  }

  public void setWarningLimit2Name(String WarningLimit2Name) {
    this.WarningLimit2Name = WarningLimit2Name;
  }

  public void setWarningLimit1Name(String WarningLimit1Name) {
    this.WarningLimit1Name = WarningLimit1Name;
  }

  public void setAverageUsableRate(String averageUsableRate) {
    this.averageUsableRate = averageUsableRate;
  }

  public DataObjectList getDataObjectList()
  {
    return this.dataObjectList;
  }

  public Boolean getIsOverLimit() {
    return this.isOverLimit;
  }

  public String getWarningPolicyChildHole() {
    return this.warningPolicyChildHole;
  }

  public String[][] getDataGrid()
  {
    return this.dataGrid;
  }

  public String getWarningLimit2Name() {
    return this.WarningLimit2Name;
  }

  public String getWarningLimit1Name() {
    return this.WarningLimit1Name;
  }

  public String getAverageUsableRate() {
    return this.averageUsableRate;
  }
}