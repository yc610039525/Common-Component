package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class TopoLinks extends GenericDO
{
  public static final String CLASS_NAME = "TOPO_LINK";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public TopoLinks()
  {
    super("TOPO_LINK");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("NUMBER", String.class);
    this.attrTypeMap.put("RELATED_EMS_CUID", String.class);
    this.attrTypeMap.put("NATIVE_NAME", String.class);
    this.attrTypeMap.put("USERLABEL", String.class);
    this.attrTypeMap.put("DIRECTION", String.class);
    this.attrTypeMap.put("WORK_MODEL", String.class);
    this.attrTypeMap.put("ORIG_POINT_CUID", String.class);
    this.attrTypeMap.put("DESC_POINT_CUID", String.class);
    this.attrTypeMap.put("LAYER_RATE", String.class);
    this.attrTypeMap.put("RELATED_SYSTEM_CUID", String.class);
    this.attrTypeMap.put("LABEL_CN", String.class);
  }

  public void setRelatedEmsCuid(String relatedEmsCuid) {
    super.setAttrValue("RELATED_EMS_CUID", relatedEmsCuid);
  }

  public void setRelatedSystemCuid(String relatedSystemCuid) {
    super.setAttrValue("RELATED_SYSTEM_CUID", relatedSystemCuid);
  }

  public void setNumber(String number)
  {
    super.setAttrValue("NUMBER", number);
  }

  public void setNativeName(String nativeName) {
    super.setAttrValue("NATIVE_NAME", nativeName);
  }

  public void setUserLabel(String userLabel) {
    super.setAttrValue("USERLABEL", userLabel);
  }

  public void setDirection(String direction) {
    super.setAttrValue("DIRECTION", direction);
  }

  public void setWorkModel(String workModel) {
    super.setAttrValue("WORK_MODEL", workModel);
  }

  public void setOrigPointCuid(String origPointCuid) {
    super.setAttrValue("ORIG_POINT_CUID", origPointCuid);
  }

  public void setDescPointCuid(String descPointCuid) {
    super.setAttrValue("DESC_POINT_CUID", descPointCuid);
  }

  public void setLayerRate(String layerRate) {
    super.setAttrValue("LAYER_RATE", layerRate);
  }

  public void setLabelCn(String labelCn) {
    super.setAttrValue("LABEL_CN", labelCn);
  }

  public String getRelatedEmsCuid() {
    return super.getAttrString("RELATED_EMS_CUID");
  }

  public String getNumber() {
    return super.getAttrString("NUMBER");
  }

  public String getNativeName() {
    return super.getAttrString("NATIVE_NAME");
  }

  public String getUserLabel() {
    return super.getAttrString("USERLABEL");
  }

  public String getDirection() {
    return super.getAttrString("DIRECTION");
  }

  public String getOrigPointCuid() {
    return super.getAttrString("ORIG_POINT_CUID");
  }

  public String getDescPointCuid() {
    return super.getAttrString("DESC_POINT_CUID");
  }

  public String getLayerRate() {
    return super.getAttrString("LAYER_RATE");
  }

  public String getRelatedSystemCuid() {
    return super.getAttrString("RELATED_SYSTEM_CUID");
  }

  public String getLabelCn() {
    return super.getAttrString("LABEL_CN");
  }

  public String getWorkModel() {
    return super.getAttrString("WORK_MODEL");
  }

  public static class AttrName
  {
    public static final String number = "NUMBER";
    public static final String relatedEmsCuid = "RELATED_EMS_CUID";
    public static final String nativeName = "NATIVE_NAME";
    public static final String userLabel = "USERLABEL";
    public static final String direction = "DIRECTION";
    public static final String workModel = "WORK_MODEL";
    public static final String origPointCuid = "ORIG_POINT_CUID";
    public static final String descPointCuid = "DESC_POINT_CUID";
    public static final String layerRate = "LAYER_RATE";
    public static final String relatedSystemCuid = "RELATED_SYSTEM_CUID";
    public static final String labelCn = "LABEL_CN";
  }
}