package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.DboBlob;
import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class ExchangeAttach extends GenericDO
{
  public static final String CLASS_NAME = "EXCHANGE_ATTACH";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public ExchangeAttach()
  {
    super("EXCHANGE_ATTACH");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("ATTACH_FILENAME", String.class);
    this.attrTypeMap.put("ATTACH_DATA", DboBlob.class);
    this.attrTypeMap.put("RELATED_EXCHANGE_CUID", String.class);
  }

  public void setAttachFileName(String attachFileName) {
    super.setAttrValue("ATTACH_FILENAME", attachFileName);
  }

  public String getAttachFileName() {
    return super.getAttrString("ATTACH_FILENAME");
  }

  public void setAttachData(DboBlob attachData) {
    super.setAttrValue("ATTACH_DATA", attachData);
  }

  public DboBlob getAttachData() {
    return super.getAttrBlob("ATTACH_DATA");
  }

  public void setRelatedExchangeCuid(String relatedExchangeCuid) {
    super.setAttrValue("RELATED_EXCHANGE_CUID", relatedExchangeCuid);
  }

  public String getRelatedExchangeCuid() {
    return super.getAttrString("RELATED_EXCHANGE_CUID");
  }

  public static class AttrName
  {
    public static final String cuid = "CUID";
    public static final String attachFileName = "ATTACH_FILENAME";
    public static final String attachData = "ATTACH_DATA";
    public static final String relatedExchangeCuid = "RELATED_EXCHANGE_CUID";
  }
}