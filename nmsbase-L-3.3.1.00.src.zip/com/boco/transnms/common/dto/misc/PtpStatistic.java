package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class PtpStatistic extends GenericDO
{
  public static final String CLASS_NAME = "PTP_STATISTIC";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public PtpStatistic()
  {
    super("PTP_STATISTIC");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("ELEMENT_TYPE", String.class);
    this.attrTypeMap.put("ELEMENT_NAME", String.class);
    this.attrTypeMap.put("PORT_RATE", String.class);
    this.attrTypeMap.put("NUMBER", String.class);
    this.attrTypeMap.put("DIS_PORT_COUNT", String.class);
    this.attrTypeMap.put("ENB_PORT_COUNT", String.class);
    this.attrTypeMap.put("DIS_PORT_RATE", String.class);
    this.attrTypeMap.put("ENB_PORT_RATE", String.class);
    this.attrTypeMap.put("IS_CONN_STATE", String.class);
    this.attrTypeMap.put("PORT_COUNT", String.class);
  }

  public void setElementType(String elementType) {
    super.setAttrValue("ELEMENT_TYPE", elementType);
  }

  public void setElementName(String eName) {
    super.setAttrValue("ELEMENT_NAME", eName);
  }

  public void setLabelCn(String labelcn) {
    super.setAttrValue("LABEL_CN", labelcn);
  }

  public void setPortRate(String portRate) {
    super.setAttrValue("PORT_RATE", portRate);
  }

  public void setNumber(String number) {
    super.setAttrValue("NUMBER", number);
  }

  public void setPortCount(String portCount) {
    super.setAttrValue("PORT_COUNT", portCount);
  }

  public void setDisPortRate(String disPortRate) {
    super.setAttrValue("DIS_PORT_RATE", disPortRate);
  }

  public void setEnbPortRate(String enbPortRate) {
    super.setAttrValue("ENB_PORT_RATE", enbPortRate);
  }

  public void setDisPortCount(String disPortCount) {
    super.setAttrValue("DIS_PORT_COUNT", disPortCount);
  }

  public void setEnbPortCount(String enbPortCount) {
    super.setAttrValue("ENB_PORT_COUNT", enbPortCount);
  }

  public void setIsConnState(String isConnState) {
    super.setAttrValue("IS_CONN_STATE", isConnState);
  }

  public String getElementType() {
    return super.getAttrString("ELEMENT_TYPE");
  }

  public String getElementName() {
    return super.getAttrString("ELEMENT_NAME");
  }

  public String getPortRate() {
    return super.getAttrString("PORT_RATE");
  }

  public String getLabelCn() {
    return super.getAttrString("LABEL_CN");
  }

  public String getNumber() {
    return super.getAttrString("NUMBER");
  }

  public String getPortCount() {
    return super.getAttrString("PORT_COUNT");
  }

  public String getDisPortRate() {
    return super.getAttrString("DIS_PORT_RATE");
  }

  public String getEnbPortRate() {
    return super.getAttrString("ENB_PORT_RATE");
  }

  public String getDisPortCount() {
    return super.getAttrString("DIS_PORT_COUNT");
  }

  public String getEnbPortCount() {
    return super.getAttrString("ENB_PORT_COUNT");
  }

  public String getIsConnState() {
    return super.getAttrString("IS_CONN_STATE");
  }

  public static class AttrName
  {
    public static final String elementType = "ELEMENT_TYPE";
    public static final String eName = "ELEMENT_NAME";
    public static final String portRate = "PORT_RATE";
    public static final String labelCn = "LABEL_CN";
    public static final String number = "NUMBER";
    public static final String portCount = "PORT_COUNT";
    public static final String disPortCount = "DIS_PORT_COUNT";
    public static final String enbPortCount = "ENB_PORT_COUNT";
    public static final String disPortRate = "DIS_PORT_RATE";
    public static final String enbPortRate = "ENB_PORT_RATE";
    public static final String isConnState = "IS_CONN_STATE";
  }
}