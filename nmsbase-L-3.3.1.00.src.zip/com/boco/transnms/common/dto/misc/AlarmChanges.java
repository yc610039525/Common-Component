package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;

public class AlarmChanges extends GenericDO
{
  public void setAlarmChanges(DataObjectList alarmChanges)
  {
    super.setAttrValue("COLOR_NAME", alarmChanges);
  }

  public void setSyncChangeTime(long syncChangeTime) {
    super.setAttrValue("SYNC_CHANGE_TIME", syncChangeTime);
  }

  public DataObjectList getAlarmChanges() {
    return (DataObjectList)super.getAttrValue("COLOR_NAME");
  }

  public long getSyncChangeTime() {
    return super.getAttrLong("SYNC_CHANGE_TIME");
  }

  public static class AttrName
  {
    public static final String syncChangeTime = "SYNC_CHANGE_TIME";
    public static final String alarmChanges = "COLOR_NAME";
  }
}