package com.boco.transnms.common.dto.misc;

public class ChannelProcessSchedule
{
  private String processName;
  private int ctpTotle;
  private int ctpNowInProcess;

  public ChannelProcessSchedule(String aProcessName)
  {
    this.processName = aProcessName;
    this.ctpTotle = 0;
    this.ctpNowInProcess = 0;
  }

  public ChannelProcessSchedule() {
    this.processName = "";
    this.ctpTotle = 0;
    this.ctpNowInProcess = 0;
  }

  public String getProcessName()
  {
    return this.processName;
  }

  public int getCtpTotle() {
    return this.ctpTotle;
  }

  public int getCtpNowInProcess() {
    return this.ctpNowInProcess;
  }

  public void setCtpNowInProcess(int aCtpNowInProcess) {
    this.ctpNowInProcess = aCtpNowInProcess;
  }

  public void setCtpTotle(int aCtpTotle) {
    this.ctpTotle = aCtpTotle;
  }
}