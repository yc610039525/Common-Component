package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.DboBlob;
import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class AllPics extends GenericDO
{
  public static final String CLASS_NAME = "ALLPICS";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public AllPics() {
    super("ALLPICS");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("OBJECT_TYPE_CODE", Long.TYPE);
    this.attrTypeMap.put("ASSISCUID", String.class);
    this.attrTypeMap.put("FILE_TYPE", String.class);
    this.attrTypeMap.put("PIC", DboBlob.class);
  }

  public void setCuid(String varCuid) {
    setAttrValue("CUID", varCuid);
  }

  public String getCuid() {
    return getAttrString("CUID");
  }

  public void setObjectTypeCode(long varObjectTypeCode) {
    setAttrValue("OBJECT_TYPE_CODE", varObjectTypeCode);
  }

  public long getObjectTypeCode() {
    return getAttrLong("OBJECT_TYPE_CODE");
  }

  public String getAssisCuid() {
    return getAttrString("ASSISCUID");
  }

  public void setAssisCuid(String varAssisCuid) {
    setAttrValue("ASSISCUID", varAssisCuid);
  }

  public String getFileType() {
    return getAttrString("FILE_TYPE");
  }

  public void setFileType(String varFileType) {
    setAttrValue("FILE_TYPE", varFileType);
  }

  public void setPic(DboBlob varPic) {
    setAttrValue("PIC", varPic);
  }

  public DboBlob getPic() {
    return getAttrBlob("PIC");
  }

  public static class AttrName
  {
    public static final String Cuid = "CUID";
    public static final String ObjectTypeCode = "OBJECT_TYPE_CODE";
    public static final String AssisCuid = "ASSISCUID";
    public static final String FileType = "FILE_TYPE";
    public static final String Pic = "PIC";
  }
}