package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;

public class TopoSiteLink extends GenericDO
{
  public TopoSiteLink()
  {
    setClassName("TopoLink");
  }

  public void setASiteCuid(String varASiteCuid) {
    setAttrValue("ASiteCuid", varASiteCuid);
  }

  public String getASiteCuid() {
    return getAttrString("ASiteCuid");
  }

  public void setZSiteCuid(String varZSiteCuid) {
    setAttrValue("ZSiteCuid", varZSiteCuid);
  }

  public String getZSiteCuid() {
    return getAttrString("ZSiteCuid");
  }

  public void setSystemCuid(String varSystemCuid) {
    setAttrValue("SystemCuid", varSystemCuid);
  }

  public void appendSystemCuid(String varSystemCuid) {
    setAttrValue("SystemCuid", getSystemCuid() + "," + varSystemCuid);
  }

  public String getSystemCuid()
  {
    return getAttrString("SystemCuid");
  }

  public String getAZUnionId() {
    return getAttrString("AZUnionId");
  }

  public void setAZUnionId()
  {
    String aId = getAttrString("ASiteCuid");
    String zId = getAttrString("ZSiteCuid");

    if (aId.compareTo(zId) < 0) {
      setAttrValue("AZUnionId", aId + "-" + zId);
    }
    else
      setAttrValue("AZUnionId", zId + "-" + aId);
  }

  public void reversAZSite()
  {
    String tmpId = getASiteCuid();
    setASiteCuid(getZSiteCuid());
    setZSiteCuid(tmpId);
  }

  public Boolean AZUnionIdIsEqual(TopoSiteLink siteLink)
  {
    String Id = getAttrString("AZUnionId");

    return Boolean.valueOf(Id.compareTo(siteLink.getZSiteCuid()) == 0);
  }

  public String toString() {
    return getASiteCuid() + "," + getZSiteCuid() + "," + getSystemCuid() + "," + getAZUnionId();
  }

  public static class AttrName
  {
    public static final String ASiteCuid = "ASiteCuid";
    public static final String ZSiteCuid = "ZSiteCuid";
    public static final String SystemCuid = "SystemCuid";
    public static final String AZUnionId = "AZUnionId";
  }
}