package com.boco.transnms.common.dto.misc;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.excel.ExcelHelper;
import com.boco.common.util.except.UserException;
import com.boco.common.util.io.BufOutputStream;
import com.boco.transnms.common.dto.base.AttrObject;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.base.IQueryCollection;
import com.boco.transnms.common.dto.sheet.DataFormartManager;
import com.boco.transnms.common.dto.sheet.DataFormartManager.DoubleFromart;
import com.boco.transnms.common.dto.sheet.FontManager;
import com.boco.transnms.common.dto.sheet.MergerManager;
import com.boco.transnms.common.dto.sheet.Sheet;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import jxl.CellType;
import jxl.format.Alignment;
import jxl.format.VerticalAlignment;
import jxl.write.Label;
import jxl.write.Number;
import jxl.write.WritableCell;
import jxl.write.WritableCellFormat;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import org.apache.commons.logging.Log;

public class ExcelDto extends AttrObject
{
  public List<Integer> indexList = new ArrayList();
  private String sortKey = "sortCol";

  public String getExcelName()
  {
    return getAttrString("EXCEL_NAME");
  }

  public void setExcelName(String excelName) {
    setAttrValue("EXCEL_NAME", excelName);
  }

  public List getSheetList() {
    List sheetList = getAttrList("SHEET_LIST");
    if (sheetList == null) {
      sheetList = new ArrayList();
    }
    return sheetList;
  }

  public void setSheetList(List sheetList) {
    setAttrValue("SHEET_LIST", sheetList);
  }

  public void addSheet(ExcelSheet sheet) {
    List sheetList = getSheetList();
    sheetList.add(sheet);
    setAttrValue("SHEET_LIST", sheetList);
  }

  public String getExcelPath()
  {
    return getAttrString("EXCEL_PATH");
  }

  public void setExcelPath(String excelPath) {
    setAttrValue("EXCEL_PATH", excelPath);
  }

  public List<Integer> getIndexList()
  {
    return this.indexList;
  }

  public void setIndexList(List<Integer> indexList) {
    this.indexList = indexList;
  }

  public List<Integer> sort(int sheetIndex, String sortAttrName, String sortType)
  {
    List sheetList = getSheetList();
    if ((sheetList != null) && (sheetList.size() > sheetIndex)) {
      ExcelSheet sheet = (ExcelSheet)sheetList.get(sheetIndex);
      this.indexList = sheet.sort(sortAttrName, sortType);
      for (int i = 0; i < sheetList.size(); i++) {
        ExcelSheet _sheet = (ExcelSheet)sheetList.get(i);
        _sheet.setIndexList(this.indexList);
      }
    }
    return this.indexList;
  }

  public List<Integer> sort(String sheetName, String sortAttrName, String sortType)
  {
    List sheetList = getSheetList();
    if (sheetList != null) {
      for (int i = 0; i < sheetList.size(); i++) {
        ExcelSheet sheet = (ExcelSheet)sheetList.get(i);
        if (sheet.getSheetName().equals(sheetName)) {
          this.indexList = sort(i, sortAttrName, sortType);
          break;
        }
      }
    }
    return this.indexList;
  }

  public void writeExcel() throws Exception {
    BufOutputStream out = new BufOutputStream();
    writeToEmptyExcel(out);
    byte[] bytes = out.getBuf();
    FileOutputStream file = new FileOutputStream(getExcelPath() + File.separator + getExcelName() + ".xls");
    file.write(bytes);
    file.close();
  }

  private void writeToEmptyExcel(OutputStream out) throws Exception
  {
    WritableWorkbook wb = ExcelHelper.createEmptyWorkBook(out);
    List sheetList = getSheetList();
    if (sheetList != null) {
      for (int i = 0; i < sheetList.size(); i++) {
        Sheet sheet = (Sheet)sheetList.get(i);
        WritableSheet wSheet = wb.createSheet(sheet.getSheetName(), i + 1);
        writeSheet(wSheet, sheet);
      }
    }
    ExcelHelper.closeWritableWorkbook(wb);
  }

  private void writeSheet(WritableSheet wSheet, Sheet sheet) throws Exception {
    fillData(wSheet, sheet);
    makeMerger(wSheet, sheet);
  }

  private void fillData(WritableSheet wSheet, Sheet sheet) throws Exception
  {
    int headRowCount = 0;
    int heeaColCount = 0;

    int leftRowCount = 0;
    int leftColCount = 0;

    int dataRowCount = 0;
    int dataColCount = 0;

    int footRowCount = 0;
    int footColCount = 0;

    WritableCellFormat wcf = new WritableCellFormat();

    List left = sheet.getLeft();
    if (left != null) {
      leftColCount = left.size();
      if (leftColCount > 0) {
        leftRowCount = ((String[])left.get(0)).length;
        if (leftRowCount == 0) {
          leftRowCount = dataRowCount;
        }
      }
    }
    for (int j = 0; j < leftColCount; j++) {
      for (int i = 0; i < leftRowCount; i++) {
        if (((String[])left.get(j)).length == 0) {
          Label cell = new Label(j, i, String.valueOf(i + 1), wcf);
          wSheet.addCell(cell);
        } else {
          Label cell = new Label(j, i, ((String[])(String[])left.get(j))[i], wcf);
          wSheet.addCell(cell);
        }
      }

    }

    List head = sheet.getHead();
    if (head != null) {
      headRowCount = head.size();
      if (headRowCount > 0) {
        heeaColCount = ((String[])head.get(0)).length;
        for (int i = 0; i < headRowCount; i++) {
          for (int j = 0; j < heeaColCount; j++) {
            Label cell = new Label(j + leftColCount, i, ((String[])(String[])head.get(i))[j]);
            wSheet.addCell(cell);
          }
        }
      }

    }

    Object data = sheet.getData();
    if (data != null) {
      if ((data instanceof IQueryCollection)) {
        dataRowCount = ((IQueryCollection)data).size();
        String[] headId = sheet.getHeadId();
        if (headId != null)
          dataColCount = headId.length;
      }
      else if ((data instanceof Object[][])) {
        dataRowCount = ((Object[][])data).length;
        if (dataRowCount > 0) {
          dataColCount = ((Object[][])(Object[][])data)[0].length;
        }
      }
    }

    for (int i = 0; i < dataRowCount; i++) {
      for (int j = 0; j < dataColCount; j++) {
        WritableCell cell = null;
        if (sheet.getDataFormart().getUserCellSpecialFormat(i, j) != null) {
          cell = new Label(j + leftColCount, i + headRowCount, "", wcf);
        }
        else if ((sheet.getColType()[j] == 1) || (sheet.getColType()[j] == 3)) {
          cell = new Label(j + leftColCount, i + headRowCount, sheet.getCellFormartValue(i, j), wcf);
        } else if ((sheet.getColType()[j] == 4) || (sheet.getColType()[j] == 5)) {
          cell = new Number(j + leftColCount, i + headRowCount, Long.valueOf(sheet.getCellFormartValue(i, j)).longValue(), wcf);
        } else if (sheet.getColType()[j] == 2) {
          cell = new Number(j + leftColCount, i + headRowCount, Double.valueOf(sheet.getCellFormartValue(i, j)).doubleValue(), wcf);
        } else if (sheet.getColType()[j] == 6) {
          boolean isPercent = sheet.getDataFormart().getCellDecimalFormat(i, j).isPercent();
          if (isPercent)
            cell = new Label(j + leftColCount, i + headRowCount, sheet.getCellFormartValue(i, j), wcf);
          else {
            cell = new Number(j + leftColCount, i + headRowCount, Double.valueOf(sheet.getCellFormartValue(i, j)).doubleValue(), wcf);
          }
        }

        if (cell != null) {
          wSheet.addCell(cell);
        }
      }

    }

    List foot = sheet.getFoot();
    if (foot != null) {
      footRowCount = foot.size();
      if (footRowCount > 0) {
        if ((foot.get(0) instanceof Object[]))
          footColCount = ((Object[])foot.get(0)).length;
        else if ((foot.get(0) instanceof GenericDO)) {
          footColCount = dataColCount;
        }
      }
    }

    for (int i = 0; i < footRowCount; i++)
      for (int j = 0; j < footColCount; j++) {
        WritableCell cell = null;
        int _rowIndex = i + headRowCount + dataRowCount;
        int _colIndex = j + leftColCount;
        if (sheet.getDataFormart().getUserCellSpecialFormat(_rowIndex, j) != null) {
          cell = new Label(_colIndex, _rowIndex, "", wcf);
        }
        else if ((sheet.getColType()[j] == 1) || (sheet.getColType()[j] == 3)) {
          cell = new Label(_colIndex, _rowIndex, sheet.getFormartValue(sheet.getFootValue(i, j), _rowIndex, j), wcf);
        } else if (sheet.getColType()[j] == 2) {
          cell = new Number(_colIndex, _rowIndex, Double.valueOf(sheet.getFormartValue(sheet.getFootValue(i, j), _rowIndex, j)).doubleValue(), wcf);
        }
        else if (sheet.getDataFormart().getUserCellDecimalFormat(_rowIndex, j) == null) {
          if ((sheet.getColType()[j] == 4) || (sheet.getColType()[j] == 5)) {
            cell = new Number(_colIndex, _rowIndex, Long.valueOf(sheet.getFormartValue(sheet.getFootValue(i, j), _rowIndex, j)).longValue(), wcf);
          }
          else if (sheet.getColType()[j] == 6) {
            boolean isPercent = sheet.getDataFormart().getCellDecimalFormat(_rowIndex, j).isPercent();
            if (isPercent)
              cell = new Label(_colIndex, _rowIndex, sheet.getFormartValue(sheet.getFootValue(i, j), _rowIndex, j), wcf);
            else {
              cell = new Number(_colIndex, _rowIndex, Double.valueOf(sheet.getFormartValue(sheet.getFootValue(i, j), _rowIndex, j)).doubleValue(), wcf);
            }
          }
        }
        else
        {
          boolean isPercent = sheet.getDataFormart().getCellDecimalFormat(_rowIndex, j).isPercent();
          if (isPercent)
            cell = new Label(_colIndex, _rowIndex, sheet.getFormartValue(sheet.getFootValue(i, j), _rowIndex, j), wcf);
          else {
            cell = new Number(_colIndex, _rowIndex, Double.valueOf(sheet.getFormartValue(sheet.getFootValue(i, j), _rowIndex, j)).doubleValue(), wcf);
          }

        }

        if (cell != null)
          wSheet.addCell(cell);
      }
  }

  private void makeMerger(WritableSheet wSheet, Sheet sheet) throws Exception
  {
    try
    {
      List ml = sheet.getMerger().getMergeList();
      for (int i = 0; i < ml.size(); i++) {
        int[] m = (int[])ml.get(i);
        wSheet.mergeCells(m[1], m[0], m[1] + m[3] - 1, m[0] + m[2] - 1);

        WritableCell cell = (WritableCell)wSheet.getCell(m[1], m[0]);
        WritableCellFormat wcf = new WritableCellFormat();
        wcf.setAlignment(Alignment.CENTRE);
        wcf.setVerticalAlignment(VerticalAlignment.CENTRE);
        cell.setCellFormat(wcf);
      }
    }
    catch (WriteException ex)
    {
      LogHome.getLog().error("写入EXCEL合并单元格错误", ex);
      throw new UserException(ex);
    }
  }

  private void makeFont(WritableSheet wSheet, Sheet sheet) throws Exception {
    try {
      sheet.getFont().getCellFonts();
    }
    catch (Exception ex) {
      LogHome.getLog().error("写入EXCEL合并单元格错误", ex);
      throw new UserException(ex);
    }
  }

  public static void writeCell(WritableCell cell, String val)
  {
    if (val == null) {
      return;
    }
    if (cell.getType() == CellType.LABEL)
      ((Label)cell).setString(val.toString());
    else if (cell.getType() == CellType.NUMBER)
      ((Number)cell).setValue(Double.parseDouble(val));
    else if (cell.getType() == CellType.BOOLEAN)
      ((jxl.write.Boolean)cell).setValue(java.lang.Boolean.getBoolean(val));
    else if (cell.getType() != CellType.DATE)
    {
      LogHome.getLog().error("Excel未处理的单元类型写入[rowIndex=" + cell.getRow() + ", colIndex=" + cell.getColumn() + ", cellType=" + cell.getType() + "]");
    }
  }

  public static void writeCell(WritableSheet sheet, int rowIndex, int colIndex, String val) throws Exception
  {
    WritableCell cell = sheet.getWritableCell(colIndex, rowIndex);
    writeCell(cell, val);
  }

  public static class AttrName
  {
    public static final String excelName = "EXCEL_NAME";
    public static final String sheetList = "SHEET_LIST";
    public static final String excelPath = "EXCEL_PATH";
  }
}