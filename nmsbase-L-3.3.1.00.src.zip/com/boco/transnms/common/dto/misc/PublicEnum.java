package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericEnumDO;

public class PublicEnum extends GenericEnumDO
{
  public static final String CLASS_NAME = "PUBLIC_ENUM";

  public PublicEnum()
  {
    super("PUBLIC_ENUM");
    initAttrTypes();
  }

  protected void initAttrTypes() {
    super.initAttrTypes();
    setAttrType("ENUM_TYPE", String.class);
    setAttrType("KEY_NUM", Long.TYPE);
    setAttrType("KEY_VALUE", String.class);
  }

  public static class AttrName
  {
    public static final String enumType = "ENUM_TYPE";
    public static final String keyNum = "KEY_NUM";
    public static final String keyValue = "KEY_VALUE";
  }
}