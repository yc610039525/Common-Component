package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class RackPtpRelatedInfo extends GenericDO
{
  public static final String CLASS_NAME = "RACK_PTP_RELATED_INFO";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public RackPtpRelatedInfo()
  {
    super("RACK_PTP_RELATED_INFO");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("DISTRICT", String.class);
    this.attrTypeMap.put("SITE", String.class);
    this.attrTypeMap.put("ROOM", String.class);
    this.attrTypeMap.put("LABEL_CN", String.class);
    this.attrTypeMap.put("RACK", String.class);
    this.attrTypeMap.put("SUB_RACK", String.class);
    this.attrTypeMap.put("SHELF", String.class);
    this.attrTypeMap.put("SUB_SHELF", String.class);
    this.attrTypeMap.put("SLOT", String.class);
    this.attrTypeMap.put("SUB_SLOT", String.class);
    this.attrTypeMap.put("PORT_NO", String.class);
    this.attrTypeMap.put("RACK_TYPE", String.class);
    this.attrTypeMap.put("RACK_NAME", String.class);
    this.attrTypeMap.put("MODULE_NAME", String.class);
    this.attrTypeMap.put("ROW", String.class);
    this.attrTypeMap.put("COL", String.class);
  }

  public void setDistric(String district)
  {
    super.setAttrValue("DISTRICT", district);
  }

  public void setSite(String site) {
    super.setAttrValue("SITE", site);
  }

  public void setRoom(String room) {
    super.setAttrValue("ROOM", room);
  }

  public void setLabelCn(String labelCn) {
    super.setAttrValue("LABEL_CN", labelCn);
  }

  public void setRack(String rack) {
    super.setAttrValue("RACK", rack);
  }

  public void setSubRack(String subRack) {
    super.setAttrValue("SUB_RACK", subRack);
  }

  public void setShelf(String shelf) {
    super.setAttrValue("SHELF", shelf);
  }

  public void setSubShelf(String subShelf) {
    super.setAttrValue("SUB_SHELF", subShelf);
  }

  public void setSlot(String slot) {
    super.setAttrValue("SLOT", slot);
  }

  public void setSubSlot(String subSlot) {
    super.setAttrValue("SUB_SLOT", subSlot);
  }

  public void setPortNo(String portNo) {
    super.setAttrValue("PORT_NO", portNo);
  }

  public void setRackType(String rackType) {
    super.setAttrValue("RACK_TYPE", rackType);
  }

  public void setRackName(String rackName) {
    super.setAttrValue("RACK_NAME", rackName);
  }

  public void setModuleName(String moduleName) {
    super.setAttrValue("MODULE_NAME", moduleName);
  }

  public void setRow(String row) {
    super.setAttrValue("ROW", row);
  }

  public void setCol(String col) {
    super.setAttrValue("COL", col);
  }

  public String getDistric()
  {
    return super.getAttrString("DISTRICT");
  }

  public String getSite() {
    return super.getAttrString("SITE");
  }

  public String getRoom() {
    return super.getAttrString("ROOM");
  }

  public String getLabelCn() {
    return super.getAttrString("LABEL_CN");
  }

  public String getRack() {
    return super.getAttrString("RACK");
  }

  public String getSubRack() {
    return super.getAttrString("SUB_RACK");
  }

  public String getShelf() {
    return super.getAttrString("SHELF");
  }

  public String getSubShelf() {
    return super.getAttrString("SUB_SHELF");
  }

  public String getSlot() {
    return super.getAttrString("SLOT");
  }

  public String getSubSlot() {
    return super.getAttrString("SUB_SLOT");
  }

  public String getPortNo() {
    return super.getAttrString("PORT_NO");
  }

  public String getRackType() {
    return super.getAttrString("RACK_TYPE");
  }

  public String getRackName() {
    return super.getAttrString("RACK_NAME");
  }

  public String getModuleName() {
    return super.getAttrString("MODULE_NAME");
  }

  public String getRow() {
    return super.getAttrString("ROW");
  }

  public String getCol() {
    return super.getAttrString("COL");
  }

  public static class AttrName
  {
    public static final String district = "DISTRICT";
    public static final String site = "SITE";
    public static final String room = "ROOM";
    public static final String labelCn = "LABEL_CN";
    public static final String rack = "RACK";
    public static final String subRack = "SUB_RACK";
    public static final String shelf = "SHELF";
    public static final String subShelf = "SUB_SHELF";
    public static final String slot = "SLOT";
    public static final String subSlot = "SUB_SLOT";
    public static final String portNo = "PORT_NO";
    public static final String rackType = "RACK_TYPE";
    public static final String rackName = "RACK_NAME";
    public static final String moduleName = "MODULE_NAME";
    public static final String row = "ROW";
    public static final String col = "COL";
  }
}