package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class VirtualCtp extends GenericDO
{
  public static final String CLASS_NAME = "VIRTUAL_CTP";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public VirtualCtp()
  {
    super("VIRTUAL_CTP");
    initAttrTypes();
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("LABEL_CN", String.class);
    this.attrTypeMap.put("RELATED_PTP_CUID", String.class);
    this.attrTypeMap.put("INNER_NUM", Long.class);
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  public void setCuid(String varCuid) {
    setAttrValue("CUID", varCuid);
  }

  public String getCuid() {
    return getAttrString("CUID");
  }

  public void setLabelCn(String varLabelCn) {
    setAttrValue("LABEL_CN", varLabelCn);
  }

  public String getLabelCn() {
    return getAttrString("LABEL_CN");
  }

  public void setRelatedPtpCuids(String varRelatedElementCuids)
  {
    setAttrValue("RELATED_PTP_CUID", varRelatedElementCuids);
  }

  public String getRelatedPtpCuids() {
    return getAttrString("RELATED_PTP_CUID");
  }

  public void setInnerNum(long innerNum) {
    setAttrValue("INNER_NUM", innerNum);
  }

  public long getInnerNum() {
    return getAttrLong("INNER_NUM");
  }

  public static class AttrName
  {
    public static final String Cuid = "CUID";
    public static final String LabelCn = "LABEL_CN";
    public static final String RelatedPtpCuid = "RELATED_PTP_CUID";
    public static final String innerNum = "INNER_NUM";
  }
}