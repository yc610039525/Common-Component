package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class RackInfo extends GenericDO
{
  public static final String CLASS_NAME = "RACK_INFO";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public RackInfo()
  {
    super("RACK_INFO");
    initAttrTypes();
  }

  public Class getAttrType(String attrName)
  {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("DISTRICT_NAME", String.class);
    this.attrTypeMap.put("SITE_NAME", String.class);
    this.attrTypeMap.put("ROOM_NAME", String.class);
    this.attrTypeMap.put("RACK_NAME", String.class);
    this.attrTypeMap.put("LOCATION", String.class);
    this.attrTypeMap.put("MODEL", String.class);
  }

  public void setDistrictName(String districtName)
  {
    super.setAttrValue("DISTRICT_NAME", districtName);
  }

  public void setSiteName(String siteName) {
    super.setAttrValue("SITE_NAME", siteName);
  }

  public void setRoomName(String roomName) {
    super.setAttrValue("ROOM_NAME", roomName);
  }

  public void setRackName(String rackName) {
    super.setAttrValue("RACK_NAME", rackName);
  }

  public void setLocation(String location) {
    super.setAttrValue("LOCATION", location);
  }

  public void setModel(String model) {
    super.setAttrValue("MODEL", model);
  }

  public String getDistrictName() {
    return super.getAttrString("DISTRICT_NAME");
  }

  public String getSiteName() {
    return super.getAttrString("SITE_NAME");
  }

  public String getRoomName() {
    return super.getAttrString("ROOM_NAME");
  }

  public String getRackName() {
    return super.getAttrString("RACK_NAME");
  }

  public String getLocation() {
    return super.getAttrString("LOCATION");
  }

  public String getModel() {
    return super.getAttrString("MODEL");
  }

  public static class AttrName
  {
    public static final String districtName = "DISTRICT_NAME";
    public static final String siteName = "SITE_NAME";
    public static final String roomName = "ROOM_NAME";
    public static final String rackName = "RACK_NAME";
    public static final String location = "LOCATION";
    public static final String model = "MODEL";
  }
}