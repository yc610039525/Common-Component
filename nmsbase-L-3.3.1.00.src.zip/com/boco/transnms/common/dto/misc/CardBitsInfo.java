package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class CardBitsInfo extends GenericDO
{
  public static final String CLASS_NAME = "CARDBITS";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public CardBitsInfo()
  {
    super("CARDBITS");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("NUMBER", String.class);
    this.attrTypeMap.put("LABEL_CN", String.class);
    this.attrTypeMap.put("RELATED_DEVICE_CUID", String.class);
    this.attrTypeMap.put("RELATED_DEVICE_NAME", String.class);
    this.attrTypeMap.put("CARD_KIND", String.class);
    this.attrTypeMap.put("CUID", String.class);
  }

  public void setNumber(String number)
  {
    super.setAttrValue("NUMBER", number);
  }

  public void setLabelCn(String labelCn)
  {
    super.setAttrValue("LABEL_CN", labelCn);
  }

  public void setRelatedDeviceCuid(String relatedDeviceCuid)
  {
    super.setAttrValue("RELATED_DEVICE_CUID", relatedDeviceCuid);
  }

  public void setRelatedDeviceName(String relatedDeviceName)
  {
    super.setAttrValue("RELATED_DEVICE_NAME", relatedDeviceName);
  }

  public void setCardKind(String cardKind)
  {
    super.setAttrValue("CARD_KIND", cardKind);
  }

  public void setCuid(String cuid)
  {
    super.setAttrValue("CUID", cuid);
  }

  public String getNumber()
  {
    return super.getAttrString("NUMBER");
  }

  public String getLabelCn()
  {
    return super.getAttrString("LABEL_CN");
  }

  public String getRelatedDeviceCuid()
  {
    return super.getAttrString("RELATED_DEVICE_CUID");
  }

  public String getRelatedDeviceName()
  {
    return super.getAttrString("RELATED_DEVICE_NAME");
  }

  public String getCardKind()
  {
    return super.getAttrString("CARD_KIND");
  }

  public String getCuid()
  {
    return super.getAttrString("CUID");
  }

  public static class AttrName
  {
    public static final String number = "NUMBER";
    public static final String labelCn = "LABEL_CN";
    public static final String relatedDeviceCuid = "RELATED_DEVICE_CUID";
    public static final String relatedDeviceName = "RELATED_DEVICE_NAME";
    public static final String cardKind = "CARD_KIND";
    public static final String cuid = "CUID";
  }
}