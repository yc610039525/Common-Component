package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class PonDeviceLinkInfo extends GenericDO
{
  public static final String CLASS_NAME = "GPON_DEVICE_LINK_INFO";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public PonDeviceLinkInfo()
  {
    super("GPON_DEVICE_LINK_INFO");
    initAttrTypes();
  }

  public Class getAttrType(String attrName)
  {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("ROOM_NAME", String.class);
    this.attrTypeMap.put("EMS_NAME", String.class);
    this.attrTypeMap.put("LINKNAME", String.class);
    this.attrTypeMap.put("RATE", String.class);
    this.attrTypeMap.put("DIRECTION", String.class);
    this.attrTypeMap.put("LINKTYPE", String.class);
    this.attrTypeMap.put("A_SITE", String.class);
    this.attrTypeMap.put("A_DEVICE", String.class);
    this.attrTypeMap.put("A_PORT", String.class);
    this.attrTypeMap.put("Z_SITE", String.class);
    this.attrTypeMap.put("Z_DEVICE", String.class);
    this.attrTypeMap.put("Z_PORT", String.class);
    this.attrTypeMap.put("REMARK", String.class);
  }

  public void setRoomName(String roomName) {
    super.setAttrValue("ROOM_NAME", roomName);
  }

  public String getRoomName() {
    return super.getAttrString("ROOM_NAME");
  }

  public void setEmsName(String emsName) {
    super.setAttrValue("EMS_NAME", emsName);
  }

  public String getEmsName() {
    return super.getAttrString("EMS_NAME");
  }

  public void setLinkName(String linkName) {
    super.setAttrValue("LINKNAME", linkName);
  }

  public String getLinkName() {
    return super.getAttrString("LINKNAME");
  }

  public void setRate(String rate) {
    super.setAttrValue("RATE", rate);
  }

  public String getRate() {
    return super.getAttrString("RATE");
  }

  public void setDirection(String direction) {
    super.setAttrValue("DIRECTION", direction);
  }

  public String getDirection() {
    return super.getAttrString("DIRECTION");
  }

  public void setLinkType(String linkType) {
    super.setAttrValue("LINKTYPE", linkType);
  }

  public String getLinkType() {
    return super.getAttrString("LINKTYPE");
  }

  public void setASite(String aSite) {
    super.setAttrValue("A_SITE", aSite);
  }

  public String getASite() {
    return super.getAttrString("A_SITE");
  }

  public void setADevice(String aDevice) {
    super.setAttrValue("A_DEVICE", aDevice);
  }

  public String getADevice() {
    return super.getAttrString("A_DEVICE");
  }

  public void setAPort(String aPort) {
    super.setAttrValue("A_PORT", aPort);
  }

  public String getAPort() {
    return super.getAttrString("A_PORT");
  }

  public void setZSite(String zSite) {
    super.setAttrValue("Z_SITE", zSite);
  }

  public String getZSite() {
    return super.getAttrString("Z_SITE");
  }

  public void setZDevice(String zDevice) {
    super.setAttrValue("Z_DEVICE", zDevice);
  }

  public String getZDevice() {
    return super.getAttrString("Z_DEVICE");
  }

  public void setZPort(String zPort) {
    super.setAttrValue("Z_PORT", zPort);
  }

  public String getZPort() {
    return super.getAttrString("Z_PORT");
  }

  public void setRemark(String remark) {
    super.setAttrValue("REMARK", remark);
  }

  public String getRemark() {
    return super.getAttrString("REMARK");
  }

  public static class AttrName
  {
    public static final String roomname = "ROOM_NAME";
    public static final String emsname = "EMS_NAME";
    public static final String linkName = "LINKNAME";
    public static final String rate = "RATE";
    public static final String direction = "DIRECTION";
    public static final String linkType = "LINKTYPE";
    public static final String aSite = "A_SITE";
    public static final String aDevice = "A_DEVICE";
    public static final String aPort = "A_PORT";
    public static final String zSite = "Z_SITE";
    public static final String zDevice = "Z_DEVICE";
    public static final String zPort = "Z_PORT";
    public static final String remark = "REMARK";
  }
}