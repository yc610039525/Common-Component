package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.base.GenericEnumDO;

public class SegLayer<Long> extends GenericEnumDO
{
  public static final String CLASS_NAME = "SEG_LAYER";

  public SegLayer()
  {
    super("SEG_LAYER");
    initAttrTypes();
  }

  protected void initAttrTypes() {
    super.initAttrTypes();
    setAttrType("DEVICE_TYPE_NAME", String.class);
    setAttrType("LAYER_ENGLISH_NAME", String.class);
  }

  public void setLayerEnglishName(String varLayerEnglishName) {
    setAttrValue("LAYER_ENGLISH_NAME", varLayerEnglishName);
  }

  public String getLayerEnglishName() {
    return getAttrString("LAYER_ENGLISH_NAME");
  }

  public void setDeviceTypeName(String varDeviceTypeName) {
    setAttrValue("DEVICE_TYPE_NAME", varDeviceTypeName);
  }

  public String getDeviceTypeName() {
    return getAttrString("DEVICE_TYPE_NAME");
  }

  public static class AttrName
  {
    public static final String enumName = "KEY_VALUE";
    public static final String enumValue = "KEY_NUM";
    public static final String layerEnglishName = "LAYER_ENGLISH_NAME";
    public static final String deviceTypeName = "DEVICE_TYPE_NAME";
  }
}