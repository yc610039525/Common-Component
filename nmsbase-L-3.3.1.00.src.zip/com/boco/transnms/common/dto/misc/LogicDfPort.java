package com.boco.transnms.common.dto.misc;

import com.boco.transnms.common.dto.Ddfport;
import com.boco.transnms.common.dto.GeneralPtp;
import com.boco.transnms.common.dto.LinkPort;
import com.boco.transnms.common.dto.Odfport;
import com.boco.transnms.common.dto.Ptp;
import com.boco.transnms.common.dto.SwitchPort;
import com.boco.transnms.common.dto.base.GenericDO;
import java.io.Serializable;

public class LogicDfPort
  implements Serializable, Cloneable
{
  private LinkPort upLeftDdfPort;
  private LinkPort upRightDdfPort;
  private LinkPort downLeftDdfPort;
  private LinkPort downRightDdfPort;
  private GeneralPtp port;

  public LogicDfPort()
  {
  }

  public LogicDfPort(LinkPort upLeftDdfPort, LinkPort upRightDdfPort, LinkPort downLeftDdfPort, LinkPort downRightDdfPort)
  {
    this.upLeftDdfPort = upLeftDdfPort;
    this.upRightDdfPort = upRightDdfPort;
    this.downLeftDdfPort = downLeftDdfPort;
    this.downRightDdfPort = downRightDdfPort;
  }

  public void setUpLeftDdfPort(LinkPort upLeftDdfPort) {
    this.upLeftDdfPort = upLeftDdfPort;
  }

  public void setUpRightDdfPort(LinkPort upRightDdfPort) {
    this.upRightDdfPort = upRightDdfPort;
  }

  public void setDownLeftDdfPort(LinkPort downLeftDdfPort) {
    this.downLeftDdfPort = downLeftDdfPort;
  }

  public void setDownRightDdfPort(LinkPort downRightDdfPort) {
    this.downRightDdfPort = downRightDdfPort;
  }

  public void setPort(GeneralPtp port) {
    this.port = port;
  }

  public LinkPort getUpLeftDdfPort() {
    return this.upLeftDdfPort;
  }

  public LinkPort getUpRightDdfPort() {
    return this.upRightDdfPort;
  }

  public LinkPort getDownLeftDdfPort() {
    return this.downLeftDdfPort;
  }

  public LinkPort getDownRightDdfPort() {
    return this.downRightDdfPort;
  }

  public GeneralPtp getPort() {
    return this.port;
  }

  public void upToDown() {
    LinkPort tempDdfPort = this.downLeftDdfPort;
    this.downLeftDdfPort = this.upLeftDdfPort;
    this.upLeftDdfPort = tempDdfPort;
    tempDdfPort = this.downRightDdfPort;
    this.downRightDdfPort = this.upRightDdfPort;
    this.upRightDdfPort = tempDdfPort;
  }

  public void leftToRight() {
    LinkPort tempDdfPort = this.upLeftDdfPort;
    this.upLeftDdfPort = this.upRightDdfPort;
    this.upRightDdfPort = tempDdfPort;
    tempDdfPort = this.downLeftDdfPort;
    this.downLeftDdfPort = this.downRightDdfPort;
    this.downRightDdfPort = tempDdfPort;
  }

  public String getPortClassName() {
    if (this.port != null)
      return this.port.getClassName();
    if (this.upLeftDdfPort != null) {
      return this.upLeftDdfPort.getClassName();
    }
    return null;
  }

  public int getPortIndex(String cuid)
  {
    int inx = -1;
    if (cuid != null) {
      if (cuid.equals(this.upLeftDdfPort.getCuid())) {
        inx = 1;
      }
      if (cuid.equals(this.upRightDdfPort.getCuid())) {
        inx = 2;
      }
      if (cuid.equals(this.downLeftDdfPort.getCuid())) {
        inx = 3;
      }
      if (cuid.equals(this.downRightDdfPort.getCuid())) {
        inx = 4;
      }
    }
    return inx;
  }

  public static String getPortFullName(GenericDO port) {
    String portFullName = "";
    if (port.getObjectNum() > 0L) {
      if (((port instanceof Ddfport)) || ((port instanceof Odfport))) {
        portFullName = port.getAttrString("LABEL_CN") + "(" + port.getAttrValue("NUM_IN_MROW") + "-" + port.getAttrValue("NUM_IN_MCOL") + ")";
      }
      else if (port != null) {
        portFullName = port.getAttrString("LABEL_CN");
      }
    }
    return portFullName;
  }

  public static String getRelatedDeviceCuid(GenericDO port) {
    String relatedDeviceCuid = null;
    if (((port instanceof Ddfport)) || ((port instanceof Odfport)))
      relatedDeviceCuid = (String)port.getAttrValue("RELATED_DEVICE_CUID");
    else if (((port instanceof Ptp)) || ((port instanceof SwitchPort)))
      relatedDeviceCuid = (String)port.getAttrValue("RELATED_NE_CUID");
    return relatedDeviceCuid;
  }

  public String getPortName(String curPortCuid) {
    return getPortFullName(getPort(curPortCuid));
  }

  public GenericDO getPort(String curPortCuid) {
    if ((this.port != null) && (this.port.getCuid().equals(curPortCuid)))
      return this.port;
    if ((this.upLeftDdfPort != null) && (this.upLeftDdfPort.getCuid().equals(curPortCuid)))
      return this.upLeftDdfPort;
    if ((this.upRightDdfPort != null) && (this.upRightDdfPort.getCuid().equals(curPortCuid)))
      return this.upRightDdfPort;
    if ((this.downLeftDdfPort != null) && (this.downLeftDdfPort.getCuid().equals(curPortCuid)))
      return this.downLeftDdfPort;
    if ((this.downRightDdfPort != null) && (this.downRightDdfPort.getCuid().equals(curPortCuid))) {
      return this.downRightDdfPort;
    }
    return null;
  }

  public GenericDO getPlugInPort(String curPortCuid)
  {
    GenericDO dbo = getPort(curPortCuid);
    if ((dbo instanceof Ddfport)) {
      String cuid = ((Ddfport)dbo).getOppositeDdfportCuid();
      return getPort(cuid);
    }
    return null;
  }
}