package com.boco.transnms.common.dto;

import com.boco.transnms.common.dto.base.DboBlob;
import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class VersionAttach extends GenericDO
{
  public static final String CLASS_NAME = "VERSION_ATTACH";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public VersionAttach()
  {
    super("VERSION_ATTACH");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("ID", Long.TYPE);
    this.attrTypeMap.put("ATTACH_FILENAME", String.class);
    this.attrTypeMap.put("ATTACH_DATA", DboBlob.class);
    this.attrTypeMap.put("RELATED_VERSION_CUID", String.class);
  }

  public void setId(long id) {
    super.setAttrValue("ID", id);
  }

  public long getId() {
    return super.getAttrLong("ID");
  }

  public void setAttachFileName(String attachFileName) {
    super.setAttrValue("ATTACH_FILENAME", attachFileName);
  }

  public String getAttachFileName() {
    return super.getAttrString("ATTACH_FILENAME");
  }

  public void setAttachData(DboBlob attachData) {
    super.setAttrValue("ATTACH_DATA", attachData);
  }

  public DboBlob getAttachData() {
    return super.getAttrBlob("ATTACH_DATA");
  }

  public void setRelatedVersionCuid(String relatedVersionCuid) {
    super.setAttrValue("RELATED_VERSION_CUID", relatedVersionCuid);
  }

  public String getRelatedVersionCuid() {
    return super.getAttrString("RELATED_VERSION_CUID");
  }

  public static class AttrName
  {
    public static final String id = "ID";
    public static final String attachFileName = "ATTACH_FILENAME";
    public static final String attachData = "ATTACH_DATA";
    public static final String relatedVersionCuid = "RELATED_VERSION_CUID";
  }
}