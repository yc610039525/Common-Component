package com.boco.transnms.common.dto.nmc;

import com.boco.transnms.common.dto.base.GenericDO;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class ShortNmsAlarm extends GenericDO
{
  public static final String CLASS_NAME = "ShortNmsAlarm";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public ShortNmsAlarm() {
    super("ShortNmsAlarm");
    initAttrTypes();
  }

  public Class getAttrType(String attrName) {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames() {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes()
  {
    this.attrTypeMap.put("ackTime", Timestamp.class);
    this.attrTypeMap.put("ackUser", String.class);
    this.attrTypeMap.put("NeendTime", Timestamp.class);
    this.attrTypeMap.put("RtuRevendTime", Timestamp.class);
    this.attrTypeMap.put("RevendTime", Timestamp.class);
    this.attrTypeMap.put("EmsendTime", Timestamp.class);
    this.attrTypeMap.put("AlarmChangeStatus", Long.TYPE);
    this.attrTypeMap.put("ReportCount", Long.TYPE);
    this.attrTypeMap.put("oldAlarmStatus", Long.TYPE);
    this.attrTypeMap.put("alarmSeverity", Long.TYPE);
    this.attrTypeMap.put("masAlarmCuid", String.class);
    this.attrTypeMap.put("currentAlarm", GenericDO.class);
    this.attrTypeMap.put("changeAttrName", String.class);
  }

  public void setAcktime(Timestamp varAckTime)
  {
    setAttrValue("ackTime", varAckTime);
  }

  public Timestamp getAckTime() {
    return getAttrDateTime("ackTime");
  }

  public void setAckUser(String varAckUser) {
    setAttrValue("ackUser", varAckUser);
  }

  public String getAckUser() {
    return getAttrString("ackUser");
  }

  public void setNeendTime(Timestamp varNeendTime) {
    setAttrValue("NeendTime", varNeendTime);
  }

  public Timestamp getNeendTime() {
    return getAttrDateTime("NeendTime");
  }

  public void setRtuRevendTime(Timestamp varRtuRevendTime) {
    setAttrValue("RtuRevendTime", varRtuRevendTime);
  }

  public Timestamp getRtuRevendTime() {
    return getAttrDateTime("RtuRevendTime");
  }

  public void setRevendTime(Timestamp varRevendTime) {
    setAttrValue("RevendTime", varRevendTime);
  }

  public Timestamp getRevendTime() {
    return getAttrDateTime("RevendTime");
  }

  public void setEmsendTime(Timestamp varEmsendTime) {
    setAttrValue("EmsendTime", varEmsendTime);
  }

  public Timestamp getEmsendTime() {
    return getAttrDateTime("EmsendTime");
  }

  public void setAlarmChangeStatus(long varAlarmChangeStatus)
  {
    setAttrValue("AlarmChangeStatus", varAlarmChangeStatus);
  }

  public long getAlarmChangeStatus() {
    return getAttrLong("AlarmChangeStatus", 0L);
  }

  public void setReportCount(long varReportCount) {
    setAttrValue("ReportCount", varReportCount);
  }

  public long getReportCount() {
    return getAttrLong("ReportCount", 0L);
  }

  public void setOldAlarmStatus(long varOldAlarmStatus) {
    setAttrValue("oldAlarmStatus", varOldAlarmStatus);
  }

  public long getOldAlarmStatus() {
    return getAttrLong("oldAlarmStatus", 0L);
  }

  public void setAlarmSeverity(long varAlarmSeverity) {
    setAttrValue("alarmSeverity", varAlarmSeverity);
  }

  public long getAlarmSeverity() {
    return getAttrLong("alarmSeverity", 0L);
  }

  public void setCurrentAlarm(GenericDO varCurrentAlarm) {
    setAttrValue("currentAlarm", varCurrentAlarm);
  }

  public GenericDO getCurrentAlarm() {
    return (GenericDO)getAttrValue("currentAlarm");
  }

  public void setMasAlarmCuid(String varMasAlarmCuid) {
    setAttrValue("masAlarmCuid", varMasAlarmCuid);
  }

  public String getMasAlarmCuid() {
    return getAttrString("masAlarmCuid");
  }

  public void setChangeAttrName(String varChangeAttrName) {
    setAttrValue("changeAttrName", varChangeAttrName);
  }

  public String getChangeAttrName() {
    return getAttrString("changeAttrName");
  }

  public static class AttrName
  {
    public static final String ackTime = "ackTime";
    public static final String ackUser = "ackUser";
    public static final String NeendTime = "NeendTime";
    public static final String RtuRevendTime = "RtuRevendTime";
    public static final String RevendTime = "RevendTime";
    public static final String EmsendTime = "EmsendTime";
    public static final String alarmChangeStatus = "AlarmChangeStatus";
    public static final String reportCount = "ReportCount";
    public static final String oldAlarmStatus = "oldAlarmStatus";
    public static final String alarmSeverity = "alarmSeverity";
    public static final String masAlarmCuid = "masAlarmCuid";
    public static final String currentAlarm = "currentAlarm";
    public static final String changeAttrName = "changeAttrName";
  }
}