package com.boco.transnms.common.dto.nmc;

import com.boco.transnms.common.dto.StandardPmPara;
import java.io.Serializable;

public class PMSelect
  implements Serializable
{
  private static final long serialVersionUID = 7877026763732294458L;
  private String fdn;
  private String[] granularityList;
  private String[] pmParameters;
  private StandardPmPara[] standardPmParas;

  public PMSelect(String fdn, String[] granularityList, String[] pmParameters)
  {
    this.fdn = fdn;
    this.granularityList = granularityList;
    this.pmParameters = pmParameters;
  }

  public static long getSerialVersionUID()
  {
    return 7877026763732294458L;
  }

  public String getFdn()
  {
    return this.fdn;
  }

  public void setFdn(String fdn)
  {
    this.fdn = fdn;
  }

  public String[] getGranularityList()
  {
    return this.granularityList;
  }

  public void setGranularityList(String[] granularityList)
  {
    this.granularityList = granularityList;
  }

  public String[] getPmParameters()
  {
    return this.pmParameters;
  }

  public StandardPmPara[] getStandardPmParas() {
    return this.standardPmParas;
  }

  public void setPmParameters(String[] pmParameters)
  {
    this.pmParameters = pmParameters;
  }

  public void setStandardPmParas(StandardPmPara[] standardPmParas) {
    this.standardPmParas = standardPmParas;
  }
}