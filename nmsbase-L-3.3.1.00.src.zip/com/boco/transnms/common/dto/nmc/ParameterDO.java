package com.boco.transnms.common.dto.nmc;

import com.boco.transnms.common.dto.CollecttaskDetail;
import com.boco.transnms.common.dto.base.GenericDO;
import java.sql.Timestamp;

public class ParameterDO extends GenericDO
{
  private static final long serialVersionUID = -918876360010795124L;

  public String[] getFdns()
  {
    return (String[])getAttrArray("fdns");
  }

  public void setFdns(String[] fdns)
  {
    setAttrValue("fdns", fdns);
  }

  public CfgOperationType[] getOperationType()
  {
    return (CfgOperationType[])getAttrArray("operationType");
  }

  public void setOperationType(CfgOperationType[] operationType)
  {
    setAttrValue("operationType", operationType);
  }

  public String getTaskId()
  {
    return getAttrString("taskId");
  }

  public void setTaskId(String taskId)
  {
    setAttrValue("taskId", taskId);
  }

  public String getTaskName()
  {
    return getAttrString("taskName");
  }

  public void setTaskName(String taskName)
  {
    setAttrValue("taskName", taskName);
  }

  public String getUserId()
  {
    return getAttrString("userId");
  }

  public void setUserId(String userId)
  {
    setAttrValue("userId", userId);
  }

  public Timestamp getPmEndTime()
  {
    return getAttrDateTime("pmEndTime");
  }

  public void setPmEndTime(Timestamp pmEndTime)
  {
    setAttrValue("pmEndTime", pmEndTime);
  }

  public PMSelect[] getPMSelectList()
  {
    return (PMSelect[])getAttrArray("pMSelectList");
  }

  public void setPMSelectList(PMSelect[] selectList)
  {
    setAttrValue("pMSelectList", selectList);
  }

  public Timestamp getPmStartTime()
  {
    return getAttrDateTime("pmStartTime");
  }

  public void setPmStartTime(Timestamp pmStartTime)
  {
    setAttrValue("pmStartTime", pmStartTime);
  }

  public CollecttaskDetail getSubTask()
  {
    return (CollecttaskDetail)getAttrObj("subTask");
  }

  public void setSubTask(CollecttaskDetail subTask)
  {
    setAttrValue("subTask", subTask);
  }

  public String getCurFdn()
  {
    return getAttrString("curFdn");
  }

  public void setCurFdn(String curFdn)
  {
    setAttrValue("curFdn", curFdn);
  }

  public String getSubFdn()
  {
    return getAttrString("subFdn");
  }

  public void setSubFdn(String subFdn)
  {
    setAttrValue("subFdn", subFdn);
  }

  public void setCreateOrClear(Long isCreateOrClear) {
    setAttrValue("createOrClear", isCreateOrClear);
  }

  public long getCreateOrClear() {
    return getAttrLong("createOrClear");
  }

  public void setTaskStartWay(String taskStartWay)
  {
    setAttrValue("taskStartWay", taskStartWay);
  }

  public String getTaskStartWay() {
    return getAttrString("taskStartWay");
  }

  public void setTaskWorkStatue(String taskWorkStatue)
  {
    setAttrValue("taskWorkStatue", taskWorkStatue);
  }

  public String getTaskWorkStatue() {
    return getAttrString("taskWorkStatue");
  }

  public void setTaskWorkTime(String taskWorkTime)
  {
    setAttrValue("taskWorkTime", taskWorkTime);
  }

  public String getTaskWorkTime() {
    return getAttrString("taskWorkTime");
  }

  public void setTaskCircle(String taskCircle)
  {
    setAttrValue("taskCircle", taskCircle);
  }

  public String getTaskCircle() {
    return getAttrString("taskCircle");
  }

  public void setTaskCirclePoint(String taskCirclePoint)
  {
    setAttrValue("taskCirclePoint", taskCirclePoint);
  }

  public String getTaskCirclePoint() {
    return getAttrString("taskCirclePoint");
  }

  public void setTaskRemark(String taskRemark)
  {
    setAttrValue("taskRemark", taskRemark);
  }

  public String getTaskRemark() {
    return getAttrString("taskRemark");
  }

  public static enum CfgOperationType
  {
    getEms, 
    getEmsNe, 
    getNe, 
    getNeEquipment, 
    getNePtp, 
    getNeCtp, 
    getNeCc, 
    getEmsTopo, 
    getAllEthService, 
    getBindingPath, 
    getNeTopo, 
    getSubNet, 
    getTransSystem, 
    getTraph, 
    getProtectGroup, 
    getPtnAllService, 
    getPtnTurrnel, 
    getPtnPseudoWire, 
    getPtnService, 
    getPtnPortBanding, 
    getPtnTurrnelRoute, 
    getPtnServiceRoute;
  }

  public static class AttrName
  {
    public static final String operationType = "operationType";
    public static final String fdns = "fdns";
    public static final String curFdn = "curFdn";
    public static final String taskName = "taskName";
    public static final String taskId = "taskId";
    public static final String userId = "userId";
    public static final String pMSelectList = "pMSelectList";
    public static final String pmStartTime = "pmStartTime";
    public static final String pmEndTime = "pmEndTime";
    public static final String subTask = "subTask";
    public static final String subFdn = "subFdn";
    public static final String createOrClear = "createOrClear";
    public static final String taskStartWay = "taskStartWay";
    public static final String taskWorkStatue = "taskWorkStatue";
    public static final String taskWorkTime = "taskWorkTime";
    public static final String taskCircle = "taskCircle";
    public static final String taskCirclePoint = "taskCirclePoint";
    public static final String taskRemark = "taskRemark";
  }
}