package com.boco.transnms.common.dto.base;

import com.boco.transnms.xsdmap.querymodel.ModelColumnType;
import com.boco.transnms.xsdmap.querymodel.ModelHeadType;
import com.boco.transnms.xsdmap.querymodel.QueryModelListType;
import com.boco.transnms.xsdmap.querymodel.QueryModelType;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QueryXmlModelFactory
{
  private static QueryXmlModelFactory instance;
  private Map<String, QueryModelType> queryModelTable = new HashMap();

  public static QueryXmlModelFactory getInstance()
  {
    return instance;
  }

  public static QueryXmlModelFactory createInstance(String[] modelFileNames) throws Exception {
    if (instance == null) {
      QueryXmlModelFactory _instance = new QueryXmlModelFactory();
      try {
        for (int k = 0; k < modelFileNames.length; k++) {
          QueryXmlModel queryXmlModel = new QueryXmlModel(modelFileNames[k]);
          List queryModelList = queryXmlModel.getQueryRootModel().getQueryModelList();
          for (int i = 0; i < queryModelList.size(); i++) {
            QueryModelType queryModel = (QueryModelType)queryModelList.get(i);
            _instance.queryModelTable.put(queryModel.getModelId(), queryModel);
          }
        }
      } catch (Exception ex) {
        ex.printStackTrace();
      }
      instance = _instance;
    }
    return instance;
  }

  public QueryModelType getQueryModel(String modelId) {
    return (QueryModelType)this.queryModelTable.get(modelId);
  }

  public ModelColumnType getColumnModel(String modelId, String modelColId) {
    ModelColumnType _modelCol = null;
    QueryModelType queryModel = getQueryModel(modelId);
    if (queryModel != null) {
      List modelColList = queryModel.getModelHead().getModelColList();
      for (int i = 0; i < modelColList.size(); i++) {
        ModelColumnType modelCol = (ModelColumnType)modelColList.get(i);
        if (modelColId.equals(modelCol.getModelColId())) {
          _modelCol = modelCol;
          break;
        }
      }
    }
    return _modelCol;
  }
}