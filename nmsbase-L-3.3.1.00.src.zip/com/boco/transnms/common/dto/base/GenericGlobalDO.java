package com.boco.transnms.common.dto.base;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class GenericGlobalDO extends GenericDO
{
  private static Map<String, Map> dtoAttrTypes = new HashMap();

  public GenericGlobalDO() {
  }

  public GenericGlobalDO(String className) {
    setClassName(className);
  }

  public Class getAttrType(String attrName) {
    Map classAttrType = (Map)dtoAttrTypes.get(getClassName());
    return (Class)classAttrType.get(attrName);
  }

  public String[] getAllAttrNames() {
    Map classAttrType = (Map)dtoAttrTypes.get(getClassName());
    String[] attrNames = new String[classAttrType.size()];
    classAttrType.keySet().toArray(attrNames);
    return attrNames;
  }

  public static void putAttrType(String className, String attrName, Class attrType) {
    Map classAttrType = (Map)dtoAttrTypes.get(className);
    if (classAttrType == null) {
      classAttrType = new HashMap();
      dtoAttrTypes.put(className, classAttrType);
    }
    classAttrType.put(attrName, attrType);
  }
}