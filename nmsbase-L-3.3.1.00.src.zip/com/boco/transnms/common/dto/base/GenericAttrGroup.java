package com.boco.transnms.common.dto.base;

public class GenericAttrGroup extends GenericGlobalDO
{
  public static final String CLASS_NAME = "GENERIC_ATTR_GROUP";

  public GenericAttrGroup()
  {
    setClassName("GENERIC_ATTR_GROUP");
  }

  public GenericAttrGroup(String cuid) {
    setClassName("GENERIC_ATTR_GROUP");
    setCuid(cuid);
  }

  public void setGroupName(String groupName) {
    setAttrValue("GROUP_NAME", groupName);
  }

  public void setIsDefault(boolean isDefault) {
    setAttrValue("IS_DEFAULT", isDefault);
  }

  public void setIsInUse(boolean isInUse) {
    setAttrValue("IS_IN_USE", isInUse);
  }

  public String getGroupName() {
    return getAttrString("GROUP_NAME");
  }

  public boolean getIsDefault() {
    return getAttrBool("IS_DEFAULT");
  }

  public boolean getIsInUse() {
    return getAttrBool("IS_IN_USE");
  }

  static
  {
    putAttrType("GENERIC_ATTR_GROUP", "CUID", String.class);
    putAttrType("GENERIC_ATTR_GROUP", "GROUP_NAME", String.class);
    putAttrType("GENERIC_ATTR_GROUP", "IS_DEFAULT", Boolean.TYPE);
    putAttrType("GENERIC_ATTR_GROUP", "IS_IN_USE", Boolean.TYPE);
  }

  public static class AttrName
  {
    public static final String cuid = "CUID";
    public static final String groupName = "GROUP_NAME";
    public static final String isDefault = "IS_DEFAULT";
    public static final String isInUse = "IS_IN_USE";
  }
}