package com.boco.transnms.common.dto.base;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import java.io.FileOutputStream;
import org.apache.commons.logging.Log;

public class CSVCreator
{
  private FileOutputStream fos = null;
  private StringBuffer sb = null;
  private boolean convertFlag = false;
  public static final String DEL_CHAR = ",";
  public static final String AV_CHAR = "\"";

  public CSVCreator(String sFilename)
    throws Exception
  {
    this.fos = new FileOutputStream(sFilename, false);
    this.sb = new StringBuffer();
  }

  public CSVCreator() throws Exception {
    this.sb = new StringBuffer();
  }

  public void setData(String data) {
    if (this.convertFlag) {
      data = CSVEncode(data);
    }
    this.sb.append("\"");
    this.sb.append(data);
    this.sb.append("\"");
    this.sb.append(",");
  }

  public void setConvertFlag(boolean b) {
    this.convertFlag = b;
  }

  public void setsb(StringBuffer s) {
    this.sb = s;
  }

  public StringBuffer getsb() {
    return this.sb;
  }

  public void writeLine() {
    if (this.sb.charAt(this.sb.length() - 1) == ',') {
      this.sb.delete(this.sb.length() - 1, this.sb.length());
    }
    this.sb.append("\r\n");
  }

  public void writeDataByLine(String[] args) {
    for (int i = 0; i < args.length; i++) {
      setData(args[i]);
    }
    writeLine();
  }

  public void close() throws Exception {
    try {
      if ((this.sb != null) && (this.fos != null)) {
        this.fos.write(this.sb.toString().getBytes());
      }
    }
    catch (Exception e)
    {
      LogHome.getLog().info("写CVS文件出错," + e);
      throw new UserException("写CVS文件出错");
    } finally {
      if (this.fos != null)
        this.fos.close();
    }
  }

  public static void main(String[] args)
  {
    try {
      CSVCreator csvCre = new CSVCreator("D:\\test.csv");
      csvCre.setConvertFlag(true);
      csvCre.setData("aaa");
      csvCre.setData("aa,a");
      csvCre.writeLine();
      csvCre.setData("aa\"a");
      csvCre.setData("aa,a");
      csvCre.setData("aa,a");
      csvCre.writeLine();
      csvCre.setData("aa\"a");
      csvCre.setData("aa,\"a");
      csvCre.setData("aa,\"a");
      csvCre.setData("aa,\"a");
      csvCre.setData("aa,\"a");
      csvCre.writeLine();
      csvCre.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static String CSVEncode(String in) {
    if (in == null) {
      return "";
    }
    in.replaceAll("&", "&amp;");
    in.replaceAll("\"", "&quot;");
    return in;
  }

  public static String CSVDecode(String in) {
    if (in == null) {
      return "";
    }
    in.replaceAll("&quot;", "\"");
    in.replaceAll("&amp;", "&");
    return in;
  }
}