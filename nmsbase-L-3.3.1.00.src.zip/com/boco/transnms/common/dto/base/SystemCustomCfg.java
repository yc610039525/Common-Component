package com.boco.transnms.common.dto.base;

public class SystemCustomCfg extends AttrObject
{
  private static SystemCustomCfg instance = new SystemCustomCfg();

  public static SystemCustomCfg getInstance()
  {
    return instance;
  }

  public void setRetract(String retract)
  {
    super.setAttrValue("retract", retract);
  }
  public String getRetract() {
    return super.getAttrString("retract");
  }

  public static class AttrName
  {
    public static final String retract = "retract";
  }
}