package com.boco.transnms.common.dto.base;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import java.sql.Timestamp;
import org.apache.commons.logging.Log;

public class GenericObjectModel extends GenericGlobalDO
{
  public static final String CLASS_NAME = "GENERIC_OBJECT_MODEL";

  public GenericObjectModel()
  {
    setClassName("GENERIC_OBJECT_MODEL");
  }

  public GenericObjectModel(String cuid) {
    setClassName("GENERIC_OBJECT_MODEL");
    setCuid(cuid);
  }

  public void setDynClassName(String dynClassName) {
    setAttrValue("DYN_CLASS_NAME", dynClassName);
  }

  public void setClassLabelCn(String classLabelCn) {
    setAttrValue("CLASS_LABEL_CN", classLabelCn);
  }

  public void setAttrName(String attrName) {
    setAttrValue("ATTR_NAME", attrName);
  }

  public void setAttrLabelCn(String attrLabelCn) {
    setAttrValue("ATTR_LABEL_CN", attrLabelCn);
  }

  public void setAttrGroups(String attrGroups) {
    setAttrValue("ATTR_GROUPS", attrGroups);
  }

  public void setAttrLimit(String attrLimit) {
    setAttrValue("ATTR_LIMIT", attrLimit);
  }

  public void setAttrOrder(long attrOrder) {
    setAttrValue("ATTR_ORDER", attrOrder);
  }

  public void writeAttrType(String attrType) {
    setAttrValue("ATTR_TYPE", attrType);
  }

  public void setIsNotNull(boolean isNotNull) {
    setAttrValue("IS_NOT_NULL", isNotNull);
  }

  public void setIsVisible(boolean isVisible) {
    setAttrValue("IS_VISIABLE", isVisible);
  }

  public String getDynClassName() {
    return getAttrString("DYN_CLASS_NAME");
  }

  public String getClassLabelCn() {
    return getAttrString("CLASS_LABEL_CN");
  }

  public String getAttrName() {
    return getAttrString("ATTR_NAME");
  }

  public String getAttrLabelCn() {
    return getAttrString("ATTR_LABEL_CN");
  }

  public String getAttrGroups() {
    return getAttrString("ATTR_GROUPS");
  }

  public String getAttrLimit() {
    return getAttrString("ATTR_LIMIT");
  }

  public long getAttrOrder() {
    return getAttrLong("ATTR_ORDER");
  }

  public String readAttrType() {
    return getAttrString("ATTR_TYPE");
  }

  public boolean isIsNotNull() {
    return getAttrBool("IS_NOT_NULL");
  }

  public boolean isIsVisible() {
    return getAttrBool("IS_VISIABLE");
  }

  public void setIsDynamic(boolean isDynamic) {
    setAttrValue("IS_DYNAMIC", isDynamic);
  }

  public void setIsQuery(boolean isQuery) {
    setAttrValue("IS_QUERY", isQuery);
  }

  public boolean getIsDynamic() {
    return getAttrBool("IS_DYNAMIC");
  }
  public boolean getIsVisible() {
    return getAttrBool("IS_VISIABLE");
  }

  public boolean getIsNotNull() {
    return getAttrBool("IS_NOT_NULL");
  }

  public boolean getIsQuery() {
    return getAttrBool("IS_QUERY");
  }

  public void setIsDtoAttr(boolean isDtoAttr) {
    setAttrValue("IS_DTO_ATTR", isDtoAttr);
  }

  public boolean getIsDtoAttr() {
    return getAttrBool("IS_DTO_ATTR");
  }

  public DataObjectList getEnumList() throws UserException
  {
    DataObjectList enumDbos = new DataObjectList();
    String enumString = getAttrLimit();
    String HEAD = "枚举{";
    if ((isEnumType()) && 
      (enumString.length() > HEAD.length())) {
      enumString = enumString.substring(HEAD.length(), enumString.length() - 1);
      LogHome.getLog().info("枚举值：" + enumString);
      String[] enumStrs = enumString.split(",");
      for (int i = 0; i < enumStrs.length; i++) {
        String[] enumPair = enumStrs[i].split("::");
        GenericEnumDO enumDbo = new GenericEnumDO();
        enumDbo.setEnumName(enumPair[0]);
        enumDbo.setEnumValue(new Long(enumPair[1]));
        enumDbos.add(enumDbo);
      }
    }

    return enumDbos;
  }

  private boolean isEnumType() {
    String limit = getAttrLimit();
    String attrType = readAttrType();
    if ((Long.TYPE.getName().equals(attrType)) && (limit != null) && (limit.indexOf("枚举{") >= 0)) {
      return true;
    }
    return false;
  }

  private boolean isDateType() {
    String limit = getAttrLimit();
    if ((limit != null) && (limit.equals("yyyy-MM-dd"))) {
      return true;
    }
    return false;
  }

  public Class getAttrTypeClass() throws UserException {
    String attrType = readAttrType();
    Class attrTypeClass = String.class;
    if (String.class.getName().equals(attrType)) {
      attrTypeClass = String.class;
    } else if (Long.TYPE.getName().equals(attrType)) {
      attrTypeClass = Long.TYPE;
    } else if (Double.TYPE.getName().equals(attrType)) {
      attrTypeClass = Double.TYPE;
    } else if (Timestamp.class.getName().equals(attrType)) {
      attrTypeClass = Timestamp.class;
    } else if (Boolean.TYPE.getName().equals(attrType)) {
      attrTypeClass = Boolean.TYPE;
    } else {
      LogHome.getLog().error("未知的属性类型: " + attrTypeClass);
      writeAttrType(String.class.getName());
    }
    return attrTypeClass;
  }

  public void setAttrEnumType(long attrEnumType) throws UserException {
    if (attrEnumType == 0L) {
      writeAttrType(String.class.getName());
    } else if (attrEnumType == 1L) {
      writeAttrType(Long.TYPE.getName());
    } else if (attrEnumType == 3L) {
      writeAttrType(Long.TYPE.getName());
    }
    else if (attrEnumType == 2L) {
      writeAttrType(Double.TYPE.getName());
    } else if (attrEnumType == 4L) {
      writeAttrType(Timestamp.class.getName());
      setAttrLimit("yyyy-MM-dd");
    } else if (attrEnumType == 5L) {
      writeAttrType(Timestamp.class.getName());
      setAttrLimit("yyyy-MM-dd HH:mm:ss");
    }
    else if (attrEnumType == 6L) {
      setAttrValue("ATTR_TYPE", Boolean.TYPE.getName());
      writeAttrType(Boolean.TYPE.getName());
    }
    else {
      LogHome.getLog().error("未知的属性类型: " + attrEnumType);
      writeAttrType(String.class.getName());
    }
  }

  public long getAttrEnumType()
    throws UserException
  {
    String attrType = readAttrType();
    long attrEnumType = 0L;
    if (String.class.getName().equals(attrType)) {
      attrEnumType = 0L;
    } else if (Long.TYPE.getName().equals(attrType)) {
      if (isEnumType())
        attrEnumType = 3L;
      else
        attrEnumType = 1L;
    }
    else if (Double.TYPE.getName().equals(attrType)) {
      attrEnumType = 2L;
    } else if (Timestamp.class.getName().equals(attrType)) {
      if (isDateType())
        attrEnumType = 4L;
      else
        attrEnumType = 5L;
    }
    else if (Boolean.TYPE.getName().equals(attrType)) {
      attrEnumType = 6L;
    }
    else {
      LogHome.getLog().error("未知的属性类型: " + attrEnumType);
      writeAttrType(String.class.getName());
    }

    return attrEnumType;
  }

  static
  {
    putAttrType("GENERIC_OBJECT_MODEL", "CUID", String.class);
    putAttrType("GENERIC_OBJECT_MODEL", "DYN_CLASS_NAME", String.class);
    putAttrType("GENERIC_OBJECT_MODEL", "CLASS_LABEL_CN", String.class);
    putAttrType("GENERIC_OBJECT_MODEL", "ATTR_NAME", String.class);
    putAttrType("GENERIC_OBJECT_MODEL", "ATTR_LABEL_CN", String.class);
    putAttrType("GENERIC_OBJECT_MODEL", "ATTR_LIMIT", String.class);
    putAttrType("GENERIC_OBJECT_MODEL", "ATTR_GROUPS", String.class);
    putAttrType("GENERIC_OBJECT_MODEL", "ATTR_TYPE", String.class);
    putAttrType("GENERIC_OBJECT_MODEL", "ATTR_ORDER", Long.TYPE);
    putAttrType("GENERIC_OBJECT_MODEL", "IS_NOT_NULL", Boolean.TYPE);
    putAttrType("GENERIC_OBJECT_MODEL", "IS_VISIABLE", Boolean.TYPE);
    putAttrType("GENERIC_OBJECT_MODEL", "IS_QUERY", Boolean.TYPE);
    putAttrType("GENERIC_OBJECT_MODEL", "IS_DTO_ATTR", Boolean.TYPE);
    putAttrType("GENERIC_OBJECT_MODEL", "IS_DYNAMIC", Boolean.TYPE);
  }

  public static class AttrName
  {
    public static final String cuid = "CUID";
    public static final String dynClassName = "DYN_CLASS_NAME";
    public static final String classLabelCn = "CLASS_LABEL_CN";
    public static final String attrName = "ATTR_NAME";
    public static final String attrLabelCn = "ATTR_LABEL_CN";
    public static final String attrLimit = "ATTR_LIMIT";
    public static final String attrGroups = "ATTR_GROUPS";
    public static final String attrType = "ATTR_TYPE";
    public static final String attrOrder = "ATTR_ORDER";
    public static final String isNotNull = "IS_NOT_NULL";
    public static final String isVisible = "IS_VISIABLE";
    public static final String isDynamic = "IS_DYNAMIC";
    public static final String isQuery = "IS_QUERY";
    public static final String isDtoAttr = "IS_DTO_ATTR";
  }
}