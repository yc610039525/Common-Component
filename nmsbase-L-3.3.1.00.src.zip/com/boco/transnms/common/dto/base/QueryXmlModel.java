package com.boco.transnms.common.dto.base;

import com.boco.common.util.xml.AbstractXmlModel;
import com.boco.transnms.xsdmap.querymodel.QueryModelListType;

public class QueryXmlModel extends AbstractXmlModel
{
  protected QueryXmlModel(String modelFileName)
    throws Exception
  {
    super("com.boco.transnms.xsdmap.querymodel", modelFileName);
  }

  public QueryModelListType getQueryRootModel()
  {
    return (QueryModelListType)getRootModel();
  }
}