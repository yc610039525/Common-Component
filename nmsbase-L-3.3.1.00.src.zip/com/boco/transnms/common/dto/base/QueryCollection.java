package com.boco.transnms.common.dto.base;

import com.boco.common.util.excel.ExcelHelper;
import com.boco.common.util.io.BufOutputStream;
import com.boco.common.util.lang.GenericEnum;
import com.boco.common.util.lang.TimeFormatHelper;
import com.boco.transnms.xsdmap.querymodel.ModelColumnType;
import com.boco.transnms.xsdmap.querymodel.ModelHeadType;
import com.boco.transnms.xsdmap.querymodel.QueryModelType;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jxl.write.Label;
import jxl.write.WritableCell;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class QueryCollection
  implements IQueryCollection
{
  private IQueryCollection queryResult;
  private String modelId;
  private List<ModelColumnType> htmlModelCols = new ArrayList();
  private List<ModelColumnType> excelModelCols = new ArrayList();
  private Map<String, GenericEnum> enumTable = new HashMap();
  private DataObjectList megerDbos;

  public QueryCollection(String modelId)
  {
    this.modelId = modelId;
    prepareModelCol();
  }

  public QueryCollection(String modelId, IQueryCollection queryResult) {
    this.modelId = modelId;
    this.queryResult = queryResult;
    prepareModelCol();
  }

  private void prepareModelCol() {
    QueryModelType model = getQueryModel();
    List modelColList = model.getModelHead().getModelColList();
    for (int i = 0; i < modelColList.size(); i++) {
      ModelColumnType modelCol = (ModelColumnType)modelColList.get(i);
      if (modelCol.getModelColIndex().intValue() >= 0) {
        this.htmlModelCols.add(modelCol);
      }
      if (modelCol.getExcelColIndex().intValue() >= 0)
        this.excelModelCols.add(modelCol);
    }
  }

  public void setQueryResult(IQueryCollection queryResult)
  {
    this.queryResult = queryResult;
  }

  public void setMegerDbos(DataObjectList dbos) {
    this.megerDbos = dbos;
  }

  public IQueryCollection getQueryResult() {
    return this.queryResult;
  }

  public DataObjectList getMegerDbos() {
    return this.megerDbos;
  }

  public GenericDO getQueryDbo(int rowNo, String className) {
    return this.queryResult.getQueryDbo(rowNo, className);
  }

  public Object getQueryAttrValue(int rowNo, String className, String attrName) {
    return this.queryResult.getQueryAttrValue(rowNo, className, attrName);
  }

  public Object getQueryAttrValue(int rowNo, String modelColId) {
    String className = parseColClassName(modelColId);
    String attrName = parseColAttrName(modelColId);
    return getQueryAttrValue(rowNo, className, attrName);
  }

  public void setEnum(String className, String attrName, GenericEnum genum) {
    String modelId = composeModelId(className, attrName);
    this.enumTable.put(modelId, genum);
  }

  public String getQueryAttrString(int rowNo, String className, String attrName) {
    return this.queryResult.getQueryAttrString(rowNo, className, attrName);
  }

  public String getQueryAttrString(int rowNo, String modelColId) {
    String className = parseColClassName(modelColId);
    String attrName = parseColAttrName(modelColId);
    return getQueryAttrString(rowNo, className, attrName);
  }

  public int size() {
    return this.queryResult.size();
  }

  public List<ModelColumnType> getHtmlModelColList() {
    return this.htmlModelCols;
  }

  public ModelColumnType getColumnModel(String modelColId) {
    return QueryXmlModelFactory.getInstance().getColumnModel(this.modelId, modelColId);
  }

  public ModelColumnType getColumnModel(String dboClassName, String attrName) {
    return QueryXmlModelFactory.getInstance().getColumnModel(this.modelId, composeModelId(dboClassName, attrName));
  }

  public byte[] writeToExcel() throws Exception
  {
    BufOutputStream out = new BufOutputStream();
    QueryModelType model = getQueryModel();

    writeToEmptyExcel(model, out);

    return out.getBuf();
  }

  private void writeToExcelByTemplate(QueryModelType model, OutputStream out) throws Exception {
    WritableWorkbook wb = ExcelHelper.createWorkBookByTemplate("excel/" + model.getExcelFileName(), out);
    WritableSheet sheet = wb.getSheet(0);

    if (this.queryResult.size() > 0) {
      List cellTemplateList = getCellTemplateList(sheet, model.getModelHead().getHeadRowIndex().intValue());
      ExcelHelper.insertRowsByTemplate(sheet, 1 + model.getModelHead().getHeadRowIndex().intValue(), this.queryResult.size(), cellTemplateList);
    }

    writeQueryResult(wb);
    if ((this.megerDbos != null) && (this.megerDbos.size() > 0)) {
      for (int i = 0; i < this.megerDbos.size(); i++) {
        GenericDO dbo = (GenericDO)this.megerDbos.get(i);
        int beginColumn = dbo.getAttrInt("BEGIN_COLUMN");
        int beginRow = dbo.getAttrInt("BEGIN_ROW");
        int endColumn = dbo.getAttrInt("END_COLUMN");
        int endRow = dbo.getAttrInt("END_ROW");
        sheet.mergeCells(beginColumn, beginRow, endColumn, endRow);
      }
    }
    ExcelHelper.closeWritableWorkbook(wb);
  }

  private void writeToEmptyExcel(QueryModelType model, OutputStream out) throws Exception {
    WritableWorkbook wb = ExcelHelper.createEmptyWorkBook(out);

    writeQueryResult(wb);
    ExcelHelper.closeWritableWorkbook(wb);
  }

  private void createTitle(WritableSheet sheet) throws Exception {
    for (int i = 0; i < this.excelModelCols.size(); i++) {
      ModelColumnType modelCol = (ModelColumnType)this.excelModelCols.get(i);
      sheet.setColumnView(modelCol.getExcelColIndex().intValue(), modelCol.getExcelColWidth().intValue());
      ExcelHelper.writeTitle(sheet, 0, modelCol.getExcelColIndex().intValue(), modelCol.getModelColName());
    }
    sheet.setRowView(0, 300);
  }

  private void writeQueryResult(WritableSheet sheet, int headRowIndex) throws Exception {
    for (int i = 0; i < this.queryResult.size(); i++)
      for (int j = 0; j < this.excelModelCols.size(); j++) {
        ModelColumnType modelCol = (ModelColumnType)this.excelModelCols.get(j);
        String attrValue = getExcelAttrStr(modelCol, getExcelAttrValue(modelCol, i));
        ExcelHelper.writeCell(sheet, i + headRowIndex + 1, modelCol.getExcelColIndex().intValue(), attrValue);
      }
  }

  private void writeQueryResult(WritableWorkbook wb) throws Exception
  {
    int SIZE = 20000;
    int sheetSumNum = 1;
    int sheetNum = 0;
    int dataSumNum = this.queryResult.size();
    int lastRowNum = 0;
    if (dataSumNum > 20000) {
      int temp = dataSumNum / 20000;
      sheetSumNum = temp;
      lastRowNum = dataSumNum % 20000;
      if (lastRowNum != 0)
        sheetSumNum += 1;
    }
    while (sheetNum < sheetSumNum) {
      int num = 20000 * (sheetNum + 1);
      if (sheetNum == sheetSumNum - 1) {
        num = dataSumNum;
      }
      WritableSheet sheet = wb.createSheet(sheetNum * 20000 + 1 + "-" + num, sheetNum);
      List cellTemplateList;
      if (this.queryResult.size() > 0) {
        cellTemplateList = getCellTemplateList();
      }

      for (int i = 0; i < this.excelModelCols.size(); i++) {
        ModelColumnType modelCol = (ModelColumnType)this.excelModelCols.get(i);
        String head = modelCol.getModelColName();
        sheet.addCell(new Label(i, 0, head));
      }
      for (int i = sheetNum * 20000; i < num; i++) {
        for (int j = 0; j < this.excelModelCols.size(); j++) {
          ModelColumnType modelCol = (ModelColumnType)this.excelModelCols.get(j);
          String attrValue = getExcelAttrStr(modelCol, getExcelAttrValue(modelCol, i));
          sheet.addCell(new Label(j, i - sheetNum * 20000 + 1, attrValue));
        }
      }
      sheetNum++;
    }
  }

  private List<WritableCell> getCellTemplateList(WritableSheet sheet, int headIndex) {
    List cellTemplateList = new ArrayList();
    QueryModelType model = getQueryModel();
    List modelColList = model.getModelHead().getModelColList();

    for (int i = 0; i < modelColList.size(); i++) {
      ModelColumnType cellModel = (ModelColumnType)modelColList.get(i);
      if (cellModel.getExcelColIndex().intValue() >= 0) {
        WritableCell cell = sheet.getWritableCell(cellModel.getExcelColIndex().intValue(), headIndex + 1);
        cellTemplateList.add(cell);
      }
    }
    return cellTemplateList;
  }

  private List getCellTemplateList() {
    List cellTemplateList = new ArrayList();
    if (this.queryResult.size() > 0) {
      for (int i = 0; i < this.excelModelCols.size(); i++) {
        ModelColumnType modelCol = (ModelColumnType)this.excelModelCols.get(i);
        Object attrValue = getExcelAttrValue(modelCol, 0);
        cellTemplateList.add(getCellTemplate(modelCol, attrValue));
      }
    }
    return cellTemplateList;
  }

  private WritableCell getCellTemplate(ModelColumnType modelCol, Object attrValue) {
    WritableCell cellTemplate = null;
    if (attrValue != null) {
      GenericEnum genum = (GenericEnum)this.enumTable.get(modelCol.getModelColId());

      if ((((attrValue instanceof Long)) || ((attrValue instanceof Integer))) && (genum == null))
        cellTemplate = ExcelHelper.createIntegerCell(modelCol.getExcelColIndex().intValue(), 0);
      else if ((((attrValue instanceof Double)) || ((attrValue instanceof Float))) && (genum == null)) {
        cellTemplate = ExcelHelper.createDoubleCell(modelCol.getExcelColIndex().intValue(), 0);
      }
      else if ((attrValue instanceof AttrAddition))
        cellTemplate = getCellTemplate(modelCol, ((AttrAddition)attrValue).getAttrValue());
      else
        cellTemplate = ExcelHelper.createLabelCell(modelCol.getExcelColIndex().intValue(), 0, modelCol.isWrap().booleanValue());
    }
    else {
      cellTemplate = ExcelHelper.createLabelCell(modelCol.getExcelColIndex().intValue(), 0, modelCol.isWrap().booleanValue());
    }
    return cellTemplate;
  }

  private Object getExcelAttrValue(ModelColumnType modelCol, int rowNo) {
    return getQueryAttrValue(rowNo, modelCol.getModelColId());
  }

  private String getExcelAttrStr(ModelColumnType modelCol, Object attrValue) {
    if (attrValue == null) return "";

    String value = null;
    if ((attrValue instanceof Timestamp)) {
      if (modelCol.getDisplayFormat() != null)
        value = TimeFormatHelper.getFormatDate((Timestamp)attrValue, modelCol.getDisplayFormat());
      else
        value = ExcelHelper.convToCellDateStr((Timestamp)attrValue);
    }
    else if ((attrValue instanceof Boolean)) {
      boolean is = ((Boolean)attrValue).booleanValue();
      value = is ? "是" : "否";
    } else if ((attrValue instanceof AttrAddition)) {
      value = getExcelAttrStr(modelCol, ((AttrAddition)attrValue).getAttrValue());
    } else {
      GenericEnum genum = (GenericEnum)this.enumTable.get(modelCol.getModelColId());
      if (genum != null) {
        value = genum.getName(attrValue);
        value = value == null ? attrValue.toString() : value;
      } else {
        value = attrValue.toString();
      }
    }
    return value;
  }

  public static String parseColClassName(String modelColId) {
    modelColId = modelColId.replace('.', '-');
    String[] ids = modelColId.split("-");
    return ids[0];
  }

  public static String parseColAttrName(String modelColId) {
    modelColId = modelColId.replace('.', '-');
    String[] ids = modelColId.split("-");
    return ids[1];
  }

  public static String composeModelId(String className, String attrName) {
    return className + "." + attrName;
  }

  public QueryModelType getQueryModel() {
    return QueryXmlModelFactory.getInstance().getQueryModel(this.modelId);
  }

  public StringBuffer writeToCSV() throws Exception
  {
    CSVCreator cvsCre = new CSVCreator();
    cvsCre.setConvertFlag(true);
    for (int i = 0; i < this.excelModelCols.size(); i++) {
      ModelColumnType modelCol = (ModelColumnType)this.excelModelCols.get(i);
      cvsCre.setData(modelCol.getModelColName());
    }
    cvsCre.writeLine();

    for (int i = 0; i < this.queryResult.size(); i++) {
      for (int j = 0; j < this.excelModelCols.size(); j++) {
        ModelColumnType modelCol = (ModelColumnType)this.excelModelCols.get(j);
        String attrValue = getExcelAttrStr(modelCol, getExcelAttrValue(modelCol, i));
        cvsCre.setData(attrValue);
      }
      cvsCre.writeLine();
    }
    return cvsCre.getsb();
  }

  public List<ModelColumnType> getExcelModelCols() {
    return this.excelModelCols;
  }
}