package com.boco.transnms.common.dto.base;

public class GenericQueryModel extends GenericGlobalDO
{
  public static final String CLASS_NAME = "GENERIC_QUERY_MODEL";

  public GenericQueryModel()
  {
    setClassName("GENERIC_QUERY_MODEL");
  }
  public GenericQueryModel(String cuid) {
    setClassName("GENERIC_QUERY_MODEL");
    setCuid(cuid);
  }

  public void setQueryId(String queryId)
  {
    setAttrValue("QUERY_ID", queryId);
  }
  public void setQueryName(String queryName) {
    setAttrValue("QUERY_NAME", queryName);
  }
  public void setQuerySql(String querySql) {
    setAttrValue("QUERY_SQL", querySql);
  }
  public String getQueryId() {
    return getAttrString("QUERY_ID");
  }
  public String getQueryName() {
    return getAttrString("QUERY_NAME");
  }
  public String getQuerySql() {
    return getAttrString("QUERY_SQL");
  }

  static
  {
    putAttrType("GENERIC_QUERY_MODEL", "CUID", String.class);
    putAttrType("GENERIC_QUERY_MODEL", "QUERY_ID", String.class);
    putAttrType("GENERIC_QUERY_MODEL", "QUERY_NAME", String.class);
    putAttrType("GENERIC_QUERY_MODEL", "QUERY_SQL", String.class);
  }

  public static class AttrName
  {
    public static final String cuid = "CUID";
    public static final String queryId = "QUERY_ID";
    public static final String queryName = "QUERY_NAME";
    public static final String querySql = "QUERY_SQL";
  }
}