package com.boco.transnms.common.dto.transpathcheck;

import java.io.Serializable;

public class PageParam
  implements Serializable
{
  private int countValue;
  private int fetchSize;
  private int offset;

  public void setCountValue(int countValue)
  {
    this.countValue = countValue;
  }

  public void setFetchSize(int fetchSize) {
    this.fetchSize = fetchSize;
  }

  public void setOffset(int offset) {
    this.offset = offset;
  }
  public int getCountValue() {
    return this.countValue;
  }

  public int getFetchSize() {
    return this.fetchSize;
  }

  public int getOffset() {
    return this.offset;
  }
  public int getPageSize() {
    int pageSize = 1;
    if ((this.countValue > 0) && (this.fetchSize > 0)) {
      pageSize = this.countValue / this.fetchSize;
      if (this.countValue % this.fetchSize > 0) {
        pageSize++;
      }
    }
    return pageSize;
  }

  public int getStartPageNo() {
    int startPageNo = 1;
    if ((this.countValue > 0) && (this.fetchSize > 0)) {
      startPageNo = this.offset / this.fetchSize + 1;
    }
    return startPageNo;
  }
}