package com.boco.transnms.common.dto;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class WireSystemRelationInfo extends GenericDO
{
  public static final String CLASS_NAME = "WIRE_SYSTEM_RELATION_INFO";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public WireSystemRelationInfo()
  {
    super("WIRE_SYSTEM_RELATION_INFO");
    initAttrTypes();
  }

  public Class getAttrType(String attrName)
  {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames()
  {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("WIRESYSTEM_NAME", String.class);
    this.attrTypeMap.put("WIRESEG_NAME", String.class);
    this.attrTypeMap.put("ORIG_SITE", String.class);
    this.attrTypeMap.put("DEST_SITE", String.class);
  }

  public WireSystemRelationInfo(String cuid) {
    setClassName("WIRE_SYSTEM_RELATION_INFO");
    setCuid(cuid);
  }

  public String getWireSystemName() {
    return getAttrString("WIRESYSTEM_NAME");
  }
  public void setWireSystemName(String wiresystemName) {
    setAttrValue("WIRESYSTEM_NAME", wiresystemName);
  }
  public String getWireSegName() {
    return getAttrString("WIRESEG_NAME");
  }
  public void setWireSegName(String wiresegName) {
    setAttrValue("WIRESEG_NAME", wiresegName);
  }
  public void setOrigSite(String origSite) {
    setAttrValue("ORIG_SITE", origSite);
  }

  public String getOrigSite() {
    return getAttrString("ORIG_SITE");
  }
  public String getDestSite() {
    return getAttrString("DEST_SITE");
  }
  public void setDestSite(String destSite) {
    setAttrValue("DEST_SITE", destSite);
  }

  public static class AttrName
  {
    public static final String wiresystemName = "WIRESYSTEM_NAME";
    public static final String wiresegName = "WIRESEG_NAME";
    public static final String origSite = "ORIG_SITE";
    public static final String destSite = "DEST_SITE";
  }
}