package com.boco.transnms.common.dto.traph;

import java.io.Serializable;

public class TraphViewConfig
  implements Serializable
{
  private String traphName = "电路名称";
  private String traphAlias = "电路别名";
  private boolean showBatchAddBtn = true;

  public String getTraphName() {
    return this.traphName;
  }

  public String getTraphAlias() {
    return this.traphAlias;
  }

  public boolean isShowBatchAddBtn() {
    return this.showBatchAddBtn;
  }

  public void setTraphName(String traphName)
  {
    this.traphName = traphName;
  }

  public void setTraphAlias(String traphAlias) {
    this.traphAlias = traphAlias;
  }

  public void setShowBatchAddBtn(boolean showBatchAddBtn) {
    this.showBatchAddBtn = showBatchAddBtn;
  }
}