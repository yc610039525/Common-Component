package com.boco.transnms.common.dto;

import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.helper.AttempOuterIntfHelper;

public class AttempOuterIntf extends GenericDO
{
  public static final String CLASS_NAME = "ATTEMP_OUTER_INTF";

  public AttempOuterIntf()
  {
    setClassName("ATTEMP_OUTER_INTF");
  }

  public AttempOuterIntf(String cuid)
  {
    setClassName("ATTEMP_OUTER_INTF");
    setCuid(cuid);
  }

  public long getSendFlag() {
    return getAttrLong("SEND_FLAG", 0L);
  }

  public void setSendFlag(long sendFlag) {
    setAttrValue("SEND_FLAG", sendFlag);
  }

  public long getDelFlag() {
    return getAttrLong("DEL_FLAG", 0L);
  }

  public void setDelFlag(long delFlag) {
    setAttrValue("DEL_FLAG", delFlag);
  }

  public long getAttempType() {
    return getAttrLong("ATTEMP_TYPE", 0L);
  }

  public void setAttempType(long attempType) {
    setAttrValue("ATTEMP_TYPE", attempType);
  }

  public String getRelatedDetailCuid() {
    return getAttrString("RELATED_DETAIL_CUID");
  }

  public void setRelatedDetailCuid(String relatedDetailCuid) {
    setAttrValue("RELATED_DETAIL_CUID", relatedDetailCuid);
  }

  public String getRelatedSheetCuid() {
    return getAttrString("RELATED_SHEET_CUID");
  }

  public void setRelatedSheetCuid(String relatedSheetCuid) {
    setAttrValue("RELATED_SHEET_CUID", relatedSheetCuid);
  }

  public String getRelatedTraphCuid() {
    return getAttrString("RELATED_TRAPH_CUID");
  }

  public void setRelatedTraphCuid(String relatedTraphCuid) {
    setAttrValue("RELATED_TRAPH_CUID", relatedTraphCuid);
  }

  public String getAttTraphLabelCn() {
    return getAttrString("ATT_TRAPH_LABEL_CN");
  }

  public void setAttTraphLabelCn(String attTraphLabelCn) {
    setAttrValue("ATT_TRAPH_LABEL_CN", attTraphLabelCn);
  }

  public Class getAttrType(String attrName)
  {
    return AttempOuterIntfHelper.getInstance().getAttrType(attrName);
  }

  public String[] getAllAttrNames()
  {
    return AttempOuterIntfHelper.getInstance().getAllAttrNames();
  }

  public static class AttrName
  {
    public static final String cuid = "CUID";
    public static final String relatedSheetCuid = "RELATED_SHEET_CUID";
    public static final String relatedDetailCuid = "RELATED_DETAIL_CUID";
    public static final String relatedTraphCuid = "RELATED_TRAPH_CUID";
    public static final String attTraphLabelCn = "ATT_TRAPH_LABEL_CN";
    public static final String attempType = "ATTEMP_TYPE";
    public static final String sendFlag = "SEND_FLAG";
    public static final String delFlag = "DEL_FLAG";
  }
}