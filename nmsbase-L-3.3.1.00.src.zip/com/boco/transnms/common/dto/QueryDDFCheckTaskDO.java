package com.boco.transnms.common.dto;

import java.io.Serializable;

public class QueryDDFCheckTaskDO
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private String taskName;
  private String taskState;
  private String user;
  private String checkBeginTime;
  private String checkEndTime;
  private String orderFieldString = "TASK_NAME";

  public String getCheckBeginTime()
  {
    return this.checkBeginTime;
  }

  public String getCheckEndTime() {
    return this.checkEndTime;
  }

  public String getOrderFieldString() {
    return this.orderFieldString;
  }

  public String getTaskName() {
    return this.taskName;
  }

  public String getTaskState() {
    return this.taskState;
  }

  public String getUser() {
    return this.user;
  }

  public void setUser(String user) {
    this.user = user;
  }

  public void setTaskState(String taskState) {
    this.taskState = taskState;
  }

  public void setTaskName(String taskName) {
    this.taskName = taskName;
  }

  public void setCheckEndTime(String checkEndTime) {
    this.checkEndTime = checkEndTime;
  }

  public void setCheckBeginTime(String checkBeginTime) {
    this.checkBeginTime = checkBeginTime;
  }

  public void setOrderFieldString(String orderFieldString) {
    if ((orderFieldString != null) && (!orderFieldString.equals("null")) && (orderFieldString.trim().length() > 0))
      this.orderFieldString = orderFieldString;
  }
}