package com.boco.transnms.common.dto.sheet;

import com.boco.transnms.common.dto.base.AttrObject;
import java.util.ArrayList;
import java.util.List;

public class MergerManager extends AttrObject
{
  List<int[]> mergeList = new ArrayList();

  public void addMergeRange(int origRow, int origCol, int rowCount, int colCount)
  {
    this.mergeList.add(this.mergeList.size(), new int[] { origRow, origCol, rowCount, colCount });
  }

  public List<int[]> getMergeList() {
    return this.mergeList;
  }

  public int[] getMergerRange(int i) {
    if ((i >= 0) && (i < this.mergeList.size())) {
      return (int[])this.mergeList.get(i);
    }
    return new int[] { 0, 0, 0, 0 };
  }
}