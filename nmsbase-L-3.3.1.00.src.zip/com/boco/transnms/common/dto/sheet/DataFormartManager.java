package com.boco.transnms.common.dto.sheet;

import com.boco.transnms.common.dto.base.AttrObject;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

public class DataFormartManager extends AttrObject
{
  private DoubleFromart sheetDoubleFormart = null;
  private Map<Integer, DoubleFromart> colDoubleFormarts = new HashMap();
  private Map<Integer, DoubleFromart> rowDoubleFormarts = new HashMap();
  private Map<Integer, Map<Integer, DoubleFromart>> cellDoubleFormarts = new HashMap();

  private String sheetTimeFormart = null;
  private Map<Integer, String> colTimeFormarts = new HashMap();
  private Map<Integer, String> rowTimeFormarts = new HashMap();
  private Map<Integer, Map<Integer, String>> cellTimeFormarts = new HashMap();

  private Map<Integer, Map<Integer, String>> cellspeSialFormarts = new HashMap();
  public static final String TIME_FORMAT_A = "yyyy-MM-dd HH:mm:ss";
  public static final String TIME_FORMAT_B = "yyyyMMddHHmmss";
  public static final String TIME_FORMAT_C = "yyyy-MM-dd HH:mm:ss:SSS";
  public static final String DATE_FORMAT = "yyyy-MM-dd";
  public static final String YEAR_FORMAT = "yyyy";

  public void addRangeSpecialFromart(int origRowIndex, int origColIndex, int rowCount, int colCount, String special)
  {
    if (special != null)
      for (int i = 0; i < rowCount; i++)
        for (int j = 0; j < colCount; j++)
          addCellSpecialFormart(origRowIndex + i, origColIndex + j, special);
  }

  public void addCellSpecialFormart(int rowIndex, int colIndex, String special)
  {
    if (special == null) {
      special = "";
    }
    Map colSF = (Map)this.cellspeSialFormarts.get(Integer.valueOf(rowIndex));
    if (colSF != null) {
      colSF.put(Integer.valueOf(colIndex), special);
    } else {
      colSF = new HashMap();
      colSF.put(Integer.valueOf(colIndex), special);
      this.cellspeSialFormarts.put(Integer.valueOf(rowIndex), colSF);
    }
  }

  public String getUserCellSpecialFormat(int rowIndex, int colIndex)
  {
    String cellSF = null;
    Map colSF = (Map)this.cellspeSialFormarts.get(Integer.valueOf(rowIndex));
    if (colSF != null) {
      cellSF = (String)colSF.get(Integer.valueOf(colIndex));
    }
    return cellSF;
  }

  public void addSheetDoubleFormart(DecimalFormat df, boolean isPercent)
  {
    this.sheetDoubleFormart = new DoubleFromart(df, isPercent);
  }

  public void addColDoubleFormart(int colIndex, DecimalFormat df, boolean isPercent)
  {
    this.colDoubleFormarts.put(Integer.valueOf(colIndex), new DoubleFromart(df, isPercent));
  }

  public void addRowDoubleFormart(int rowIndex, DecimalFormat df, boolean isPercent)
  {
    this.rowDoubleFormarts.put(Integer.valueOf(rowIndex), new DoubleFromart(df, isPercent));
  }

  public void addRangeDoubleFormart(int origRowIndex, int origColIndex, int rowCount, int colCount, DecimalFormat df, boolean isPercent)
  {
    for (int i = 0; i < rowCount; i++)
      for (int j = 0; j < colCount; j++)
        addCellDoubleFormart(origRowIndex + i, origColIndex + j, df, isPercent);
  }

  public void addCellDoubleFormart(int rowIndex, int colIndex, DecimalFormat df, boolean isPercent)
  {
    Map colDF = (Map)this.cellDoubleFormarts.get(Integer.valueOf(rowIndex));
    if (colDF != null) {
      colDF.put(Integer.valueOf(colIndex), new DoubleFromart(df, isPercent));
    } else {
      colDF = new HashMap();
      colDF.put(Integer.valueOf(colIndex), new DoubleFromart(df, isPercent));
      this.cellDoubleFormarts.put(Integer.valueOf(rowIndex), colDF);
    }
  }

  public DoubleFromart getCellDecimalFormat(int rowIndex, int colIndex)
  {
    DoubleFromart cellDF = getUserCellDecimalFormat(rowIndex, colIndex);
    if (cellDF == null) {
      cellDF = new DoubleFromart(new DecimalFormat("#.##"), false);
    }
    return cellDF;
  }

  public DoubleFromart getUserCellDecimalFormat(int rowIndex, int colIndex) {
    DoubleFromart cellDF = null;

    Map colDF = (Map)this.cellDoubleFormarts.get(Integer.valueOf(rowIndex));
    if (colDF != null) {
      cellDF = (DoubleFromart)colDF.get(Integer.valueOf(colIndex));
    }

    if (cellDF == null) {
      cellDF = (DoubleFromart)this.rowDoubleFormarts.get(Integer.valueOf(rowIndex));
    }

    if (cellDF == null) {
      cellDF = (DoubleFromart)this.colDoubleFormarts.get(Integer.valueOf(colIndex));
    }

    if (cellDF == null) {
      cellDF = this.sheetDoubleFormart;
    }

    return cellDF;
  }

  public void addSheetTimeFormart(String tf)
  {
    this.sheetTimeFormart = tf;
  }

  public void addColTimeFormart(int colIndex, String tf) {
    this.colTimeFormarts.put(Integer.valueOf(colIndex), tf);
  }

  public void addRowDoubleFormart(int rowIndex, String tf) {
    this.rowTimeFormarts.put(Integer.valueOf(rowIndex), tf);
  }

  public void addRangeTimeFormart(int origRowIndex, int origColIndex, int rowCount, int colCount, String tf) {
    for (int i = 0; i < rowCount; i++)
      for (int j = 0; j < colCount; j++)
        addCellTimeFormart(origRowIndex + i, origColIndex + j, tf);
  }

  public void addCellTimeFormart(int rowIndex, int colIndex, String tf)
  {
    Map colTF = (Map)this.cellTimeFormarts.get(Integer.valueOf(rowIndex));
    if (colTF != null) {
      colTF.put(Integer.valueOf(colIndex), tf);
    } else {
      colTF = new HashMap();
      colTF.put(Integer.valueOf(colIndex), tf);
      this.cellTimeFormarts.put(Integer.valueOf(rowIndex), colTF);
    }
  }

  public String getCellTimeFormat(int rowIndex, int colIndex) {
    String cellTF = getUserCellTimeFormat(rowIndex, colIndex);

    if (cellTF == null) {
      cellTF = "yyyy-MM-dd HH:mm:ss";
    }

    return cellTF;
  }

  public String getUserCellTimeFormat(int rowIndex, int colIndex) {
    String cellTF = null;

    Map colTF = (Map)this.cellTimeFormarts.get(Integer.valueOf(rowIndex));
    if (colTF != null) {
      cellTF = (String)colTF.get(Integer.valueOf(colIndex));
    }

    if (cellTF == null) {
      cellTF = (String)this.rowTimeFormarts.get(Integer.valueOf(rowIndex));
    }

    if (cellTF == null) {
      cellTF = (String)this.colTimeFormarts.get(Integer.valueOf(colIndex));
    }

    if (cellTF == null) {
      cellTF = this.sheetTimeFormart;
    }

    return cellTF;
  }

  public class DoubleFromart
  {
    private DecimalFormat df = null;
    private boolean isPercent = false;

    DoubleFromart(DecimalFormat df, boolean isPercent) { if (df == null) {
        df = new DecimalFormat("#.##");
      }
      this.df = df;
      this.isPercent = isPercent; }

    public DecimalFormat getDecimalFormat()
    {
      return this.df;
    }

    public boolean isPercent() {
      return this.isPercent;
    }
  }
}