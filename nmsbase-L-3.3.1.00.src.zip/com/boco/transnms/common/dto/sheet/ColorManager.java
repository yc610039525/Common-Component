package com.boco.transnms.common.dto.sheet;

import java.util.HashMap;
import java.util.Map;
import jxl.format.Colour;

public class ColorManager
{
  private ColourManager BGColor = null;
  private ColourManager FGColor = null;

  private ColourManager getColourMananger(int colorType)
  {
    if (colorType == 1) {
      if (this.BGColor == null) {
        this.BGColor = new ColourManager(null);
      }
      return this.BGColor;
    }
    if (this.FGColor == null) {
      this.FGColor = new ColourManager(null);
    }
    return this.FGColor;
  }

  public void addRangeColor(int origRowIndex, int origColIndex, int rowCount, int colCount, int colorType, Colour colour)
  {
    getColourMananger(colorType).addRangeColour(origRowIndex, origColIndex, rowCount, colCount, colour);
  }

  public void addCellColour(int rowIndex, int colIndex, int colorType, Colour colour)
  {
    getColourMananger(colorType).addCellColour(rowIndex, colIndex, colour);
  }

  public void addColColour(int colIndex, int colorType, int colourEnum) {
    getColourMananger(colorType).addColColour(colIndex, colourEnum);
  }

  public void addRowDoubleFormart(int rowIndex, int colorType, int colourEnum) {
    getColourMananger(colorType).addRowColour(rowIndex, colourEnum);
  }

  public Colour getCellColour(int rowIndex, int colIndex, int colorType)
  {
    return getColourMananger(colorType).getCellColour(rowIndex, colIndex);
  }

  public Colour getUserCellColour(int rowIndex, int colIndex, int colorType)
  {
    return getColourMananger(colorType).getUserCellColour(rowIndex, colIndex);
  }

  private class ColourManager
  {
    private Map<Integer, Colour> colColour = new HashMap();
    private Map<Integer, Colour> rowColour = new HashMap();
    private Map<Integer, Map<Integer, Colour>> cellColour = new HashMap();

    private ColourManager() {  } 
    void addRangeColour(int origRowIndex, int origColIndex, int rowCount, int colCount, Colour colour) { for (int i = 0; i < rowCount; i++)
        for (int j = 0; j < colCount; j++)
          addCellColour(origRowIndex + i, origColIndex + j, colour);
    }

    void addCellColour(int rowIndex, int colIndex, Colour colour)
    {
      Map colC = (Map)this.cellColour.get(Integer.valueOf(rowIndex));
      if (colC != null) {
        colC.put(Integer.valueOf(colIndex), colour);
      } else {
        colC = new HashMap();
        colC.put(Integer.valueOf(colIndex), colour);
        this.cellColour.put(Integer.valueOf(rowIndex), colC);
      }
    }

    void addColColour(int colIndex, int colourType)
    {
      this.colColour.put(Integer.valueOf(colIndex), Colour.getInternalColour(colourType));
    }

    void addRowColour(int rowIndex, int colourType) {
      this.rowColour.put(Integer.valueOf(rowIndex), Colour.getInternalColour(colourType));
    }

    Colour getCellColour(int rowIndex, int colIndex) {
      Colour cellC = null;
      Map colDF = (Map)this.cellColour.get(Integer.valueOf(rowIndex));
      if (colDF != null) {
        cellC = (Colour)colDF.get(Integer.valueOf(colIndex));
      }
      return cellC;
    }

    Colour getUserCellColour(int rowIndex, int colIndex) {
      Colour cellC = null;

      Map colDF = (Map)this.cellColour.get(Integer.valueOf(rowIndex));
      if (colDF != null) {
        cellC = (Colour)colDF.get(Integer.valueOf(colIndex));
      }

      if (cellC == null) {
        cellC = (Colour)this.rowColour.get(Integer.valueOf(rowIndex));
      }

      if (cellC == null) {
        cellC = (Colour)this.colColour.get(Integer.valueOf(colIndex));
      }

      return cellC;
    }
  }

  public static class ColorType
  {
    public static final int BG = 1;
    public static final int FG = 2;
  }
}