package com.boco.transnms.common.dto.sheet;

import com.boco.transnms.common.dto.base.AttrObject;
import java.awt.Font;
import java.util.ArrayList;
import java.util.List;

public class FontManager extends AttrObject
{
  private List colFonts = new ArrayList();
  private List rowFonts = new ArrayList();
  private List cellFonts = new ArrayList();

  public List getRowFonts()
  {
    return this.rowFonts;
  }

  public List getColFonts() {
    return this.colFonts;
  }

  public List getCellFonts() {
    return this.cellFonts;
  }

  public void addColFont(int col, Font font) {
    Font oldFont = null;
    for (int i = 0; i < this.colFonts.size(); i++) {
      RangeFont r = (RangeFont)this.colFonts.get(i);
      if (r.getIndex() == col) {
        oldFont = r.getFont();
      }
    }
    if (oldFont == null) {
      RangeFont f = new RangeFont(col, font);
      this.colFonts.add(f);
    } else {
      oldFont = font;
    }
  }

  public void addRowFont(int row, Font font) {
    Font oldFont = null;
    for (int i = 0; i < this.rowFonts.size(); i++) {
      RangeFont r = (RangeFont)this.rowFonts.get(i);
      if (r.getIndex() == row) {
        oldFont = r.getFont();
      }
    }
    if (oldFont == null) {
      RangeFont f = new RangeFont(row, font);
      this.rowFonts.add(f);
    } else {
      oldFont = font;
    }
  }

  public void addCellFont(int row, int col, Font font) {
    Font oldFont = null;
    for (int i = 0; i < this.cellFonts.size(); i++) {
      CellFont r = (CellFont)this.cellFonts.get(i);
      if ((r.getRow() == row) && (r.getCol() == col)) {
        oldFont = r.getFont();
      }
    }
    if (oldFont == null) {
      CellFont f = new CellFont(row, col, font);
      this.cellFonts.add(f);
    } else {
      oldFont = font;
    }
  }

  public Font getRowFont(int row)
  {
    Font font = null;
    for (int i = 0; i < this.rowFonts.size(); i++) {
      RangeFont r = (RangeFont)this.rowFonts.get(i);
      if (r.getIndex() == row) {
        font = r.getFont();
      }
    }
    return font;
  }

  public Font getColFont(int col) {
    Font font = null;
    for (int i = 0; i < this.colFonts.size(); i++) {
      RangeFont r = (RangeFont)this.colFonts.get(i);
      if (r.getIndex() == col) {
        font = r.getFont();
      }
    }
    return font;
  }

  public Font getCellFont(int row, int col) {
    Font font = null;
    for (int i = 0; i < this.cellFonts.size(); i++) {
      CellFont f = (CellFont)this.cellFonts.get(i);
      if ((f.getRow() == row) && (f.getCol() == col)) {
        font = f.getFont();
      }
    }

    if (font == null) {
      for (int i = 0; i < this.rowFonts.size(); i++) {
        RangeFont r = (RangeFont)this.rowFonts.get(i);
        if (r.getIndex() == row) {
          font = r.getFont();
        }
      }
    }

    if (font == null) {
      for (int i = 0; i < this.colFonts.size(); i++) {
        RangeFont r = (RangeFont)this.colFonts.get(i);
        if (r.getIndex() == col) {
          font = r.getFont();
        }
      }
    }
    return font;
  }

  private class CellFont
  {
    private int row;
    private int col;
    private Font font;

    CellFont(int row, int col, Font font)
    {
      this.row = row;
      this.col = col;
      this.font = font;
    }

    int getRow() {
      return this.row;
    }

    int getCol() {
      return this.col;
    }

    Font getFont() {
      return this.font;
    }

    void setFont(Font font) {
      this.font = font;
    }
  }

  private class RangeFont
  {
    private int index;
    private Font font;

    RangeFont(int index, Font font)
    {
      this.index = index;
      this.font = font;
    }

    int getIndex() {
      return this.index;
    }

    Font getFont() {
      return this.font;
    }

    void setFont(Font font) {
      this.font = font;
    }
  }
}