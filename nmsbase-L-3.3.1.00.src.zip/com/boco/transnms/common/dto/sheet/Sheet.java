package com.boco.transnms.common.dto.sheet;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.lang.TimeFormatHelper;
import com.boco.transnms.common.dto.misc.ExcelSheet;
import java.text.DecimalFormat;
import java.util.Date;
import org.apache.commons.logging.Log;

public class Sheet extends ExcelSheet
{
  public void setMerge(MergerManager m)
  {
    setAttrValue("MERGE", m);
  }

  public MergerManager getMerger() {
    MergerManager _m = null;
    Object f = getAttrValue("MERGE");
    if (f == null) {
      _m = new MergerManager();
      setMerge(_m);
    } else {
      _m = (MergerManager)f;
    }
    return _m;
  }

  public void setColor(ColorManager cm) {
    setAttrValue("COLOR", cm);
  }

  public ColorManager getColor() {
    ColorManager _c = null;
    Object c = getAttrValue("COLOR");
    if (c == null) {
      _c = new ColorManager();
      setColor(_c);
    } else {
      _c = (ColorManager)c;
    }
    return _c;
  }

  public void setFont(FontManager f)
  {
    setAttrValue("FONT", f);
  }

  public FontManager getFont() {
    FontManager _f = null;
    Object f = getAttrValue("FONT");
    if (f == null) {
      _f = new FontManager();
      setFont(_f);
    } else {
      _f = (FontManager)f;
    }
    return _f;
  }

  public void setDataFormart(DataFormartManager df) {
    setAttrValue("DATA_FORMART", df);
  }

  public DataFormartManager getDataFormart() {
    DataFormartManager _df = null;
    Object df = getAttrValue("DATA_FORMART");
    if (df == null) {
      _df = new DataFormartManager();
      setDataFormart(_df);
    } else {
      _df = (DataFormartManager)df;
    }
    return _df;
  }

  public String getCellFormartValue(int rowIndex, int colIndex)
  {
    Object obj = getCellValue(rowIndex, colIndex);
    String value = getFormartValue(obj, rowIndex, colIndex);
    return value;
  }

  public String getFormartValue(Object obj, int rowIndex, int colIndex) {
    String value = "";
    int[] colType = getColType();
    if ((colType.length == 0) || (colType.length < colIndex))
    {
      value = obj.toString();
    } else {
      int dataType = colType[colIndex];
      if (getDataFormart().getUserCellSpecialFormat(rowIndex, colIndex) != null) {
        value = "";
      }
      else if (obj == null) {
        value = getDefaultValueByDataType(dataType);
      }
      else if (dataType == 1) {
        value = String.valueOf(obj);
      } else if (dataType == 2) {
        value = String.valueOf(obj);
      } else if (dataType == 3) {
        Date date = (Date)obj;
        value = TimeFormatHelper.getFormatDate(date, getDataFormart().getCellTimeFormat(rowIndex, colIndex));
      }
      else if (getDataFormart().getUserCellDecimalFormat(rowIndex, colIndex) == null) {
        if (dataType == 4)
          try {
            value = String.valueOf(Double.valueOf(obj.toString()).longValue());
          } catch (NumberFormatException ex) {
            LogHome.getLog().info("数据类型转换错误，使用默认值'0' : dataType=int;rowIndex=" + rowIndex + ";colIndex=" + colIndex + ";obj=" + obj);
            value = "0";
          }
        else if (dataType == 5)
          try {
            value = String.valueOf(Double.valueOf(obj.toString()).longValue());
          } catch (NumberFormatException ex) {
            LogHome.getLog().info("数据类型转换错误，使用默认值'0' : dataType=long;rowIndex=" + rowIndex + ";colIndex=" + colIndex + ";obj=" + obj);
            value = "0";
          }
        else if (dataType == 6)
          try {
            DataFormartManager.DoubleFromart df = getDataFormart().getCellDecimalFormat(rowIndex, colIndex);
            if (df.isPercent())
              value = df.getDecimalFormat().format(Double.valueOf(obj.toString()).doubleValue() * 100.0D) + "%";
            else
              value = df.getDecimalFormat().format(Double.valueOf(obj.toString()));
          }
          catch (NumberFormatException ex) {
            LogHome.getLog().info("数据类型转换错误，使用默认值'0.00' : dataType=double;rowIndex=" + rowIndex + ";colIndex=" + colIndex + ";obj=" + obj);

            value = "0.00";
          }
      }
      else {
        try {
          DataFormartManager.DoubleFromart df = getDataFormart().getCellDecimalFormat(rowIndex, colIndex);
          if (df.isPercent())
            value = df.getDecimalFormat().format(Double.valueOf(obj.toString()).doubleValue() * 100.0D) + "%";
          else
            value = df.getDecimalFormat().format(Double.valueOf(obj.toString()));
        }
        catch (NumberFormatException ex) {
          LogHome.getLog().info("数据类型转换错误，使用默认值'0.00' : dataType=double;rowIndex=" + rowIndex + ";colIndex=" + colIndex + ";obj=" + obj);
          value = "0.00";
        }

      }

    }

    return value;
  }

  private String getDefaultValueByDataType(int dataType)
  {
    if (dataType == 1)
      return "";
    if (dataType == 2)
      return "0";
    if (dataType == 3)
      return "";
    if (dataType == 4)
      return "0";
    if (dataType == 5)
      return "0";
    if (dataType == 6) {
      return "0.00";
    }
    return "";
  }

  public static class AttrName
  {
    public static final String color = "COLOR";
    public static final String font = "FONT";
    public static final String merge = "MERGE";
    public static final String dataFormart = "DATA_FORMART";
  }
}