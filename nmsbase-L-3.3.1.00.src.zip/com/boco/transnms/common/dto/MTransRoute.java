package com.boco.transnms.common.dto;

import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.dao.base.DaoHelper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MTransRoute extends GenericDO
{
  private ArrayList transPathIndis = new ArrayList();

  private HashMap<Integer, TransSubPathVector> transSubPathMap = new HashMap();

  public ArrayList getTransPathIndis()
  {
    return this.transPathIndis;
  }

  public HashMap getTransSubPathMap() {
    return this.transSubPathMap;
  }

  public void setTransPathIndis(ArrayList transPathIndis) {
    this.transPathIndis = transPathIndis;
  }

  public void setTransSubPathMap(HashMap transSubPathMap) {
    this.transSubPathMap = transSubPathMap;
  }

  public void makeNewCuids() {
    if ((null != this.transSubPathMap) && (this.transSubPathMap.size() > 0))
      for (int segNum = 0; segNum < this.transSubPathMap.size(); segNum++) {
        TransSubPathVector transSubPathVector = (TransSubPathVector)this.transSubPathMap.get(Integer.valueOf(segNum));
        if (null != transSubPathVector) {
          TransSubPath transSubPath = transSubPathVector.getTransSubPath();

          ArrayList segList = transSubPathVector.getPathSeg();
          if (segList != null) {
            for (int i = 0; i < segList.size(); i++) {
              PathRouteSeg pathRouteSeg = (PathRouteSeg)segList.get(i);
              pathRouteSeg.setObjectId("0");
              pathRouteSeg.setCuid();
            }
          }
          if (transSubPath != null) {
            transSubPath.setCuid();
            transSubPath.setObjectId("0");
          }
        }
      }
  }

  public DataObjectList getAllTransSubPathVector(String oldSegCuid, PathRouteSeg pathRouteSeg)
  {
    DataObjectList dbos = new DataObjectList();
    if ((null != this.transSubPathMap) && (this.transSubPathMap.size() > 0)) {
      for (int segNum = 0; segNum < this.transSubPathMap.size(); segNum++) {
        TransSubPathVector transSubPathVector = (TransSubPathVector)this.transSubPathMap.get(Integer.valueOf(segNum));
        if (null != transSubPathVector) {
          TransSubPathVector retTransSubPathVector = transSubPathVector.getAllTransSubPathVector(oldSegCuid, pathRouteSeg);
          if (retTransSubPathVector != null) {
            dbos.add(retTransSubPathVector);
          }
        }
      }
    }
    return dbos;
  }

  public void setTransSubPathVector(DataObjectList dbos) {
    if ((null != this.transSubPathMap) && (this.transSubPathMap.size() > 0))
      for (int segNum = 0; segNum < this.transSubPathMap.size(); segNum++) {
        TransSubPathVector transSubPathVector = (TransSubPathVector)this.transSubPathMap.get(Integer.valueOf(segNum));
        if (null != transSubPathVector)
          for (int i = 0; i < dbos.size(); i++) {
            TransSubPathVector transSubPathVectorNew = (TransSubPathVector)dbos.get(i);
            transSubPathVector.setTransSubPathVector(transSubPathVectorNew);
          }
      }
  }

  public String[] getMTransRouteDesciption()
  {
    String[] desc = new String[2];
    desc[0] = "";
    desc[1] = "";
    if ((null != this.transSubPathMap) && (this.transSubPathMap.size() > 0)) {
      for (int segNum = 0; segNum < this.transSubPathMap.size(); segNum++) {
        TransSubPathVector transSubPathVector = (TransSubPathVector)this.transSubPathMap.get(Integer.valueOf(segNum));
        if (null != transSubPathVector) {
          String[] descSub = transSubPathVector.getTransSubPathDesciption();
          if ((desc[0] != null) && (desc[0].trim().length() > 0)) {
            desc[0] = (desc[0] + " " + descSub[0]);
            desc[1] = (desc[1] + " " + descSub[1]);
          } else {
            desc[0] = descSub[0];
            desc[1] = descSub[1];
          }
        }
      }
    }
    return desc;
  }

  public String getZjName() {
    if ((null != this.transPathIndis) && (this.transPathIndis.size() > 0)) {
      StringBuffer sb = new StringBuffer();
      for (int i = 0; i < this.transPathIndis.size(); i++) {
        NameAndValue nameCuid = (NameAndValue)this.transPathIndis.get(i);
        if (null != nameCuid) {
          String name = nameCuid.getName();
          if ((null != name) && (name.trim().length() > 0)) {
            sb.append(name).append(",");
          }
        }
      }
      if (sb.length() > 0) {
        return sb.toString().substring(0, sb.length() - 1);
      }
    }
    return "";
  }

  public String getZjCuid() {
    if ((null != this.transPathIndis) && (this.transPathIndis.size() > 0)) {
      StringBuffer sb = new StringBuffer();
      for (int i = 0; i < this.transPathIndis.size(); i++) {
        NameAndValue nameCuid = (NameAndValue)this.transPathIndis.get(i);
        if (null != nameCuid) {
          String cuid = nameCuid.getValue();
          if ((null != cuid) && (cuid.trim().length() > 0)) {
            sb.append(cuid).append(",");
          }
        }
      }
      if (sb.length() > 0) {
        return sb.toString().substring(0, sb.length() - 1);
      }
    }
    return "";
  }

  public List getzjCuidList() {
    List list = new ArrayList();
    if ((null != this.transPathIndis) && (this.transPathIndis.size() > 0)) {
      for (int i = 0; i < this.transPathIndis.size(); i++) {
        NameAndValue nameCuid = (NameAndValue)this.transPathIndis.get(i);
        if (null != nameCuid) {
          String cuid = nameCuid.getValue();
          if ((null != cuid) && (cuid.trim().length() > 0)) {
            list.add(cuid);
          }
        }
      }
    }
    return list;
  }

  public String getRouteDesciption() {
    StringBuffer sb = new StringBuffer();

    if ((null != this.transSubPathMap) && (this.transSubPathMap.size() > 0)) {
      for (int segNum = 0; segNum < this.transSubPathMap.size(); segNum++) {
        TransSubPathVector transSubPathVector = (TransSubPathVector)this.transSubPathMap.get(Integer.valueOf(segNum));
        if (null != transSubPathVector) {
          TransSubPath transSubPath = transSubPathVector.getTransSubPath();
          if ((null != transSubPath) && (DaoHelper.isNotEmpty(transSubPath.getRouteDesciptionA()))) {
            sb.append(transSubPath.getRouteDesciptionA().replace(",", "，")).append("；");
          }
        }
      }
    }
    return sb.toString().length() > 0 ? sb.toString().substring(0, sb.toString().length() - 1) : "";
  }
}