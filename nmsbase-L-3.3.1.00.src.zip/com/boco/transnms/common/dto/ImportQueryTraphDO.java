package com.boco.transnms.common.dto;

import java.io.Serializable;

public class ImportQueryTraphDO
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private String lableCn;
  private String relatedAZdSite;
  private String relatedZZdSite;
  private String relatedANeCuid;
  private String relatedZNeCuid;
  private String endPortA;
  private String endPortZ;
  private boolean isLableCn;
  private boolean isEndPortA;
  private boolean isEndPortZ;

  public String getEndPortA()
  {
    return this.endPortA;
  }

  public String getEndPortZ() {
    return this.endPortZ;
  }

  public boolean isIsEndPortA() {
    return this.isEndPortA;
  }

  public boolean isIsEndPortZ() {
    return this.isEndPortZ;
  }

  public boolean isIsLableCn() {
    return this.isLableCn;
  }

  public String getLableCn() {
    return this.lableCn;
  }

  public String getRelatedANeCuid() {
    return this.relatedANeCuid;
  }

  public String getRelatedAZdSite() {
    return this.relatedAZdSite;
  }

  public String getRelatedZNeCuid() {
    return this.relatedZNeCuid;
  }

  public String getRelatedZZdSite() {
    return this.relatedZZdSite;
  }

  public void setEndPortA(String endPortA) {
    this.endPortA = endPortA;
  }

  public void setEndPortZ(String endPortZ) {
    this.endPortZ = endPortZ;
  }

  public void setIsEndPortA(boolean isEndPortA) {
    this.isEndPortA = isEndPortA;
  }

  public void setIsEndPortZ(boolean isEndPortZ) {
    this.isEndPortZ = isEndPortZ;
  }

  public void setIsLableCn(boolean isLableCn) {
    this.isLableCn = isLableCn;
  }

  public void setLableCn(String lableCn) {
    this.lableCn = lableCn;
  }

  public void setRelatedANeCuid(String relatedANeCuid) {
    this.relatedANeCuid = relatedANeCuid;
  }

  public void setRelatedAZdSite(String relatedAZdSite) {
    this.relatedAZdSite = relatedAZdSite;
  }

  public void setRelatedZNeCuid(String relatedZNeCuid) {
    this.relatedZNeCuid = relatedZNeCuid;
  }

  public void setRelatedZZdSite(String relatedZZdSite) {
    this.relatedZZdSite = relatedZZdSite;
  }
}