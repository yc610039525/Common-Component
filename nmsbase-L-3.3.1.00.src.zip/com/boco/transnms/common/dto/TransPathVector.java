package com.boco.transnms.common.dto;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.ArrayList;

public class TransPathVector extends GenericDO
{
  private TransPath transPath;
  private ArrayList pathSeg;

  public TransPath getTransPath()
  {
    return this.transPath;
  }
  public ArrayList getPathSeg() {
    return this.pathSeg;
  }

  public void setTransPath(TransPath transPath) {
    this.transPath = transPath;
  }

  public void setPathSeg(ArrayList pathSeg) {
    this.pathSeg = pathSeg;
  }
}