package com.boco.transnms.common.dto;

import com.boco.transnms.common.dto.base.GenericDO;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class WireTroubleRelation extends GenericDO
{
  public static final String CLASS_NAME = "WIRE_TROUBLE_RELATION";
  private final Map<String, Class> attrTypeMap = new HashMap();

  public WireTroubleRelation()
  {
    super("WIRE_TROUBLE_RELATION");
    initAttrTypes();
  }

  public Class getAttrType(String attrName)
  {
    return (Class)this.attrTypeMap.get(attrName);
  }

  public String[] getAllAttrNames()
  {
    String[] attrNames = new String[this.attrTypeMap.size()];
    this.attrTypeMap.keySet().toArray(attrNames);
    return attrNames;
  }

  protected void initAttrTypes() {
    this.attrTypeMap.put("CUID", String.class);
    this.attrTypeMap.put("LABEL_CN", String.class);
    this.attrTypeMap.put("SERIAL_NUMBER", Long.TYPE);
    this.attrTypeMap.put("RELATED_SPACE_CUID", String.class);
    this.attrTypeMap.put("BELONGCOM", String.class);
    this.attrTypeMap.put("FIND_TIME", Timestamp.class);
    this.attrTypeMap.put("STATE", Long.TYPE);
    this.attrTypeMap.put("LOCATION", String.class);
    this.attrTypeMap.put("DANGER_TYPE", String.class);
    this.attrTypeMap.put("DESCRIPTION", String.class);
    this.attrTypeMap.put("LENGTH", Double.TYPE);
    this.attrTypeMap.put("CONSTRUCT_PROJECT_NAME", String.class);
    this.attrTypeMap.put("SECURITY_PROTOCOL", String.class);
    this.attrTypeMap.put("CONTACTOR", String.class);
    this.attrTypeMap.put("MANAGER", String.class);
    this.attrTypeMap.put("MAINT_DEP", String.class);
    this.attrTypeMap.put("CARE_PERSON", String.class);
    this.attrTypeMap.put("TROUBLE_START_TIME", Timestamp.class);
    this.attrTypeMap.put("TROUBLE_END_TIME", Timestamp.class);
    this.attrTypeMap.put("REMARK", String.class);
    this.attrTypeMap.put("CONSTRUCTION_PERIOD", String.class);
    this.attrTypeMap.put("CREATE_TIME", Timestamp.class);
    this.attrTypeMap.put("TROUBLE_NUM", String.class);
    this.attrTypeMap.put("WIRE_SYSTEM_CUID", String.class);
    this.attrTypeMap.put("TROUBLE_LEVEL", String.class);
  }

  public WireTroubleRelation(String cuid) {
    setClassName("WIRE_TROUBLE_RELATION");
    setCuid(cuid);
  }

  public void setTroubleNum(long troubleNum) {
    setAttrValue("TROUBLE_NUM", troubleNum);
  }

  public long getTroubleNum() {
    return getAttrLong("TROUBLE_NUM");
  }
  public String getWireSystemCuid() {
    return getAttrString("WIRE_SYSTEM_CUID");
  }
  public void setWireSystemCuid(String wireSystemCuid) {
    setAttrValue("WIRE_SYSTEM_CUID", wireSystemCuid);
  }

  public String getTroubleLevel() {
    return getAttrString("TROUBLE_LEVEL");
  }
  public void setTroubleLevel(String troubleLevel) {
    setAttrValue("TROUBLE_LEVEL", troubleLevel);
  }

  public String getCuid() {
    return getAttrString("CUID");
  }
  public void setCuid(String cuid) {
    setAttrValue("CUID", cuid);
  }
  public String getLabelCn() {
    return getAttrString("LABEL_CN");
  }
  public void setLabelCn(String labelCn) {
    setAttrValue("LABEL_CN", labelCn);
  }
  public void setSerialNumber(long serialNumber) {
    setAttrValue("SERIAL_NUMBER", serialNumber);
  }

  public long getSerialNumber() {
    return getAttrLong("SERIAL_NUMBER", 0L);
  }

  public String getRelatedSpaceCuid()
  {
    return getAttrString("RELATED_SPACE_CUID");
  }
  public void setRelatedSpaceCuid(String RelatedSpaceCuid) {
    setAttrValue("RELATED_SPACE_CUID", RelatedSpaceCuid);
  }

  public void setBelongcom(String belongcom) {
    setAttrValue("BELONGCOM", belongcom);
  }

  public String getBelongcom() {
    return getAttrString("BELONGCOM");
  }

  public void setFindTime(Timestamp findTime) {
    setAttrValue("FIND_TIME", findTime);
  }

  public Timestamp getFindTime() {
    return getAttrDateTime("FIND_TIME");
  }

  public void setLocation(String location) {
    setAttrValue("LOCATION", location);
  }

  public String getLocation() {
    return getAttrString("LOCATION");
  }

  public void setDangerType(long dangerType) {
    setAttrValue("DANGER_TYPE", dangerType);
  }

  public long getDangerType() {
    return getAttrLong("DANGER_TYPE", 1L);
  }

  public void setDescription(String description) {
    setAttrValue("DESCRIPTION", description);
  }

  public String getDescription() {
    return getAttrString("DESCRIPTION");
  }

  public void setLength(double length) {
    setAttrValue("LENGTH", length);
  }

  public double getLength() {
    return getAttrDouble("LENGTH", 0.0D);
  }

  public void setConstructProjectName(String constructProjectName) {
    setAttrValue("CONSTRUCT_PROJECT_NAME", constructProjectName);
  }

  public String getConstructProjectName() {
    return getAttrString("CONSTRUCT_PROJECT_NAME");
  }

  public void setSecurityProtocol(String securityProtocol) {
    setAttrValue("SECURITY_PROTOCOL", securityProtocol);
  }

  public String getSecurityProtocol() {
    return getAttrString("SECURITY_PROTOCOL");
  }

  public void setContactor(String contactor) {
    setAttrValue("CONTACTOR", contactor);
  }

  public String getContactor() {
    return getAttrString("CONTACTOR");
  }

  public void setManager(String manager) {
    setAttrValue("MANAGER", manager);
  }

  public String getManager() {
    return getAttrString("MANAGER");
  }

  public void setMaintDep(String maintDep) {
    setAttrValue("MAINT_DEP", maintDep);
  }

  public String getMaintDep() {
    return getAttrString("MAINT_DEP");
  }

  public void setCarePerson(String carePerson) {
    setAttrValue("CARE_PERSON", carePerson);
  }

  public String getCarePerson() {
    return getAttrString("CARE_PERSON");
  }

  public void setRemark(String remark) {
    setAttrValue("REMARK", remark);
  }

  public String getRemark() {
    return getAttrString("REMARK");
  }

  public void setConstructionPeriod(String constructionPeriod) {
    setAttrValue("CONSTRUCTION_PERIOD", constructionPeriod);
  }

  public String getConstructionPeriod() {
    return getAttrString("CONSTRUCTION_PERIOD");
  }

  public void setTroubleStartTime(Timestamp troubleStartTime) {
    setAttrValue("TROUBLE_START_TIME", troubleStartTime);
  }

  public Timestamp getTroubleStartTime() {
    return getAttrDateTime("TROUBLE_START_TIME");
  }

  public void setTroubleEndTime(Timestamp troubleEndTime) {
    setAttrValue("TROUBLE_END_TIME", troubleEndTime);
  }

  public Timestamp getTroubleEndTime() {
    return getAttrDateTime("TROUBLE_END_TIME");
  }

  public void setState(long state) {
    setAttrValue("STATE", state);
  }

  public long getState() {
    return getAttrLong("STATE", 0L);
  }

  public void setCreateTime(Timestamp createTime) {
    setAttrValue("CREATE_TIME", createTime);
  }

  public Timestamp getCreateTime() {
    return getAttrDateTime("CREATE_TIME");
  }

  public static class AttrName
  {
    public static final String cuid = "CUID";
    public static final String labelCn = "LABEL_CN";
    public static final String serialNumber = "SERIAL_NUMBER";
    public static final String RelatedSpaceCuid = "RELATED_SPACE_CUID";
    public static final String belongcom = "BELONGCOM";
    public static final String findTime = "FIND_TIME";
    public static final String state = "STATE";
    public static final String location = "LOCATION";
    public static final String dangerType = "DANGER_TYPE";
    public static final String description = "DESCRIPTION";
    public static final String length = "LENGTH";
    public static final String constructProjectName = "CONSTRUCT_PROJECT_NAME";
    public static final String securityProtocol = "SECURITY_PROTOCOL";
    public static final String contactor = "CONTACTOR";
    public static final String manager = "MANAGER";
    public static final String maintDep = "MAINT_DEP";
    public static final String carePerson = "CARE_PERSON";
    public static final String troubleStartTime = "TROUBLE_START_TIME";
    public static final String troubleEndTime = "TROUBLE_END_TIME";
    public static final String remark = "REMARK";
    public static final String constructionPeriod = "CONSTRUCTION_PERIOD";
    public static final String createTime = "CREATE_TIME";
    public static final String troubleNum = "TROUBLE_NUM";
    public static final String wireSystemCuid = "WIRE_SYSTEM_CUID";
    public static final String troubleLevel = "TROUBLE_LEVEL";
  }
}