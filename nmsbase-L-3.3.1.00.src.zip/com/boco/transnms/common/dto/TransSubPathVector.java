package com.boco.transnms.common.dto;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.ArrayList;

public class TransSubPathVector extends GenericDO
{
  private TransSubPath transSubPath = new TransSubPath();

  private ArrayList<PathRouteSeg> pathSeg = new ArrayList();

  public ArrayList getPathSeg()
  {
    return this.pathSeg;
  }

  public TransSubPath getTransSubPath() {
    return this.transSubPath;
  }

  public void setPathSeg(ArrayList pathSeg) {
    this.pathSeg = pathSeg;
  }

  public void setTransSubPath(TransSubPath transSubPath) {
    this.transSubPath = transSubPath;
  }
  public TransSubPathVector getAllTransSubPathVector(String oldSegCuid, PathRouteSeg pathRouteSeg) {
    boolean flag = false;
    if (this.pathSeg != null) {
      for (int i = 0; i < this.pathSeg.size(); i++) {
        PathRouteSeg pathRouteSegOld = (PathRouteSeg)this.pathSeg.get(i);
        if (pathRouteSegOld.getCuid().equals(oldSegCuid)) {
          this.pathSeg.set(i, pathRouteSeg);
          flag = true;
        }
      }
    }
    if (flag) {
      return this;
    }
    return null;
  }

  public void setTransSubPathVector(TransSubPathVector transSubPathVector) {
    TransSubPath transSubPathNew = transSubPathVector.transSubPath;
    if (this.transSubPath.getCuid().equals(transSubPathNew.getCuid()))
      this.transSubPath = transSubPathNew;
  }

  public String[] getTransSubPathDesciption()
  {
    String[] desc = new String[2];
    desc[0] = this.transSubPath.getRouteDesciptionA();
    desc[1] = this.transSubPath.getRouteDesciptionZ();
    return desc;
  }
}