package com.boco.transnms.common.jms;

import com.boco.common.util.debug.LogHome;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;
import javax.naming.Context;
import org.apache.commons.logging.Log;

public abstract class AbstractJmsTopic
{
  private TopicConnection topicConnection;
  private TopicSession topicSession;
  private Topic topic;
  private Context context;
  private boolean transacted;
  private int acknowledgementMode;
  private String topicConnectionFactoryName;
  private String topicName;
  private String clientId;
  private boolean durable;

  protected AbstractJmsTopic(Context context, String topicConnectionFactoryName, String topicName, String clientId, boolean durable, boolean transacted, int acknowledgementMode)
  {
    try
    {
      this.context = context;
      if (this.context != null) {
        this.topicConnectionFactoryName = topicConnectionFactoryName;
        this.topicName = topicName;
        this.clientId = clientId;
        this.durable = durable;
        this.transacted = transacted;
        this.acknowledgementMode = acknowledgementMode;
        initTopic();
      } else {
        LogHome.getLog().error("TopicName=" + topicName + ", Context 为空不能注册 ！");
      }
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }

  protected void initTopic() throws Exception {
    LogHome.getLog().info("初始化JmsTopic(TopicName=" + this.topicName + ")开始");
    long loadstart = System.currentTimeMillis();
    TopicConnectionFactory topicConnectionFactory = (TopicConnectionFactory)this.context.lookup(this.topicConnectionFactoryName);
    this.topicConnection = topicConnectionFactory.createTopicConnection();
    this.topicConnection.start();
    if (isDurable()) {
      this.topicConnection.setClientID(this.clientId);
    }
    this.topicSession = this.topicConnection.createTopicSession(isTransacted(), getAcknowledgementMode());
    this.topic = ((Topic)this.context.lookup(this.topicName));
    LogHome.getLog().info("初始化JmsTopic(TopicName=" + this.topicName + ")结束，耗时：" + (System.currentTimeMillis() - loadstart));
  }

  protected Topic getTopic() {
    return this.topic;
  }

  protected TopicSession getTopicSession() {
    return this.topicSession;
  }

  protected int getAcknowledgementMode() {
    return this.acknowledgementMode;
  }

  protected boolean isTransacted() {
    return this.transacted;
  }

  protected boolean isDurable() {
    return this.durable;
  }

  protected void commit() throws Exception {
    if (isTransacted())
      getTopicSession().commit();
  }

  protected TopicConnection getTopicConnection()
  {
    return this.topicConnection;
  }

  public String getTopicName() {
    return this.topicName;
  }

  public void close() throws Exception {
    try {
      if (this.topicSession != null) {
        this.topicSession.close();
        LogHome.getLog().warn("JMS[" + getTopicName() + "]的session关闭 ！");
      }
      if (this.topicConnection != null) {
        this.topicConnection.close();
        LogHome.getLog().warn("JMS[" + getTopicName() + "]的connection关闭 ！");
      }
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }
}