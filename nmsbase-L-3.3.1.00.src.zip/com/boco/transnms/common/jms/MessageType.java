package com.boco.transnms.common.jms;

public class MessageType
{
  public static final String ALARM = "ALARM";
  public static final String EMS_EVENT = "EMS_EVENT";
  public static final String OBJECT_EVENT = "OBJECT_EVENT";
  public static final String OBJECT_UPDATE_EVENT = "OBJECT_UPDATE_EVENT";
  public static final String SYSTEM_EVENT = "SYSTEM_EVENT";
}