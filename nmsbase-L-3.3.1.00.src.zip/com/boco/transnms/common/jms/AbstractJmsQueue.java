package com.boco.transnms.common.jms;

import com.boco.common.util.debug.LogHome;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;
import javax.naming.Context;
import org.apache.commons.logging.Log;

public abstract class AbstractJmsQueue
{
  private boolean transacted;
  private int ackMode;
  private String queueConnFactoryName;
  private String queueName;
  private Context context;
  private QueueSession queueSession;
  private QueueConnection queueConnection;
  private Queue queue;

  protected AbstractJmsQueue(Context context, String queueConnFactoryName, String queueName, boolean transacted, int ackMode)
  {
    try
    {
      this.context = context;
      this.queueConnFactoryName = queueConnFactoryName;
      this.queueName = queueName;
      this.ackMode = ackMode;
      this.transacted = transacted;
      initQueue();
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }

  private void initQueue() throws Exception {
    QueueConnectionFactory queueConnectionFactory = (QueueConnectionFactory)this.context.lookup(this.queueConnFactoryName);
    this.queueConnection = queueConnectionFactory.createQueueConnection();
    this.queueConnection.start();
    this.queueSession = this.queueConnection.createQueueSession(isTransacted(), getAcknowledgementMode());
    this.queue = ((Queue)this.context.lookup(this.queueName));
  }

  protected int getAcknowledgementMode() {
    return this.ackMode;
  }

  protected boolean isTransacted() {
    return this.transacted;
  }

  protected QueueSession getQueueSession() {
    return this.queueSession;
  }

  protected Queue getQueue() {
    return this.queue;
  }

  protected void commit() throws Exception {
    if (isTransacted())
      getQueueSession().commit();
  }

  public void close()
  {
    try {
      if (this.queueSession != null) {
        this.queueSession.close();
      }
      if (this.queueConnection != null)
        this.queueConnection.close();
    }
    catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }
}