package com.boco.transnms.common.jms;

public class JmsTopicName
{
  public static final String ALARM_TOPIC = "topic/AlarmTopic";
  public static final String EVENT_TOPIC = "topic/EventTopic";
  public static final String SYSTEM_TOPIC = "topic/SystemTopic";
}