package com.boco.transnms.common.jms;

import com.boco.common.util.debug.LogHome;
import javax.jms.ExceptionListener;
import javax.jms.JMSException;
import javax.jms.TextMessage;
import javax.jms.TopicConnection;
import javax.jms.TopicPublisher;
import javax.jms.TopicSession;
import javax.naming.Context;
import org.apache.commons.logging.Log;

public class JmsTopicPublisher extends AbstractJmsTopic
{
  private TopicPublisher topicPublisher;
  private ConnectExceptListener connListener = new ConnectExceptListener(null);
  private boolean isResetConnecting = false;

  public JmsTopicPublisher(Context context, String topicConnectionFactoryName, String topicName) {
    this(context, topicConnectionFactoryName, topicName, "", false, false, 1);
  }

  protected JmsTopicPublisher(Context context, String topicConnectionFactoryName, String topicName, String clientId, boolean durable, boolean transacted, int acknowledgementMode)
  {
    super(context, topicConnectionFactoryName, topicName, clientId, durable, transacted, acknowledgementMode);
    initTopicPublisher();
  }

  private void initTopicPublisher() {
    try {
      this.topicPublisher = getTopicSession().createPublisher(getTopic());
      getTopicConnection().setExceptionListener(this.connListener);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }

  protected TopicPublisher getTopicPublisher() {
    return this.topicPublisher;
  }

  public void publishText(String message) throws Exception {
    TextMessage textMessage = getTopicSession().createTextMessage();
    textMessage.clearBody();
    textMessage.setText(message);
    getTopicPublisher().publish(textMessage);
    commit();
  }

  public void close()
    throws Exception
  {
    try
    {
      if (this.topicPublisher != null) {
        this.topicPublisher.close();
        LogHome.getLog().warn("JMS[" + getTopicName() + "]的publisher关闭 ！");
      }
      super.close();
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }
  private class ConnectExceptListener implements ExceptionListener {
    private ConnectExceptListener() {
    }
    public void onException(JMSException jMSException) { LogHome.getLog().error("", jMSException);
      if (!JmsTopicPublisher.this.isResetConnecting)
        synchronized (this) {
          try {
            JmsTopicPublisher.this.isResetConnecting = true;
            LogHome.getLog().warn("JMS[" + JmsTopicPublisher.this.getTopicName() + "]的消息连接中断， 开始重新连接 ！");
            JmsTopicPublisher.this.close();
            Thread.sleep(3000L);
            JmsTopicPublisher.this.initTopic();
            JmsTopicPublisher.this.initTopicPublisher();
          } catch (Exception ex) {
            LogHome.getLog().error("", ex);
          } finally {
            JmsTopicPublisher.this.isResetConnecting = false;
            LogHome.getLog().warn("JMS[" + JmsTopicPublisher.this.getTopicName() + "]的消息连接中断， 重新连接完毕 ！");
          }
        }
    }
  }
}