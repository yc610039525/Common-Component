package com.boco.transnms.common.jms;

import com.boco.common.util.debug.LogHome;
import javax.jms.BytesMessage;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.QueueReceiver;
import javax.jms.QueueSession;
import javax.jms.StreamMessage;
import javax.jms.TextMessage;
import javax.naming.Context;
import org.apache.commons.logging.Log;

public class JmsQueueReceiver extends AbstractJmsQueue
  implements MessageListener
{
  private QueueReceiver queueReceiver;

  public JmsQueueReceiver(Context context, String queueConnFactoryName, String recvQueueName)
  {
    this(context, queueConnFactoryName, recvQueueName, false, 1);
  }

  public JmsQueueReceiver(Context context, String queueConnFactoryName, String sendQueueName, boolean transacted, int ackMode)
  {
    super(context, queueConnFactoryName, sendQueueName, transacted, ackMode);
    initQueueSender();
  }

  private void initQueueSender() {
    try {
      this.queueReceiver = getQueueSession().createReceiver(getQueue());
      this.queueReceiver.setMessageListener(this);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }

  public void close() {
    try {
      if (this.queueReceiver != null) {
        this.queueReceiver.close();
      }
      super.close();
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }

  public void onMessage(Message message) {
    if ((message instanceof BytesMessage))
      doByteMessage((BytesMessage)message);
    else if ((message instanceof MapMessage))
      doMapMessage((MapMessage)message);
    else if ((message instanceof ObjectMessage))
      doObjectMessage((ObjectMessage)message);
    else if ((message instanceof StreamMessage))
      doStreamMessage((StreamMessage)message);
    else if ((message instanceof TextMessage)) {
      doTextMessage((TextMessage)message);
    }
    try
    {
      commit();
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  protected void doByteMessage(BytesMessage message)
  {
  }

  protected void doMapMessage(MapMessage message)
  {
  }

  protected void doObjectMessage(ObjectMessage message)
  {
  }

  protected void doStreamMessage(StreamMessage message)
  {
  }

  protected void doTextMessage(TextMessage message)
  {
  }
}