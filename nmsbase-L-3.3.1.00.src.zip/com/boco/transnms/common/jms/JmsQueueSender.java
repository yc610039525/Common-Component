package com.boco.transnms.common.jms;

import com.boco.common.util.debug.LogHome;
import java.io.Serializable;
import javax.jms.ObjectMessage;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.naming.Context;
import org.apache.commons.logging.Log;

public class JmsQueueSender extends AbstractJmsQueue
{
  private QueueSender queueSender;

  public JmsQueueSender(Context context, String queueConnFactoryName, String sendQueueName)
  {
    this(context, queueConnFactoryName, sendQueueName, false, 1);
  }

  public JmsQueueSender(Context context, String queueConnFactoryName, String sendQueueName, boolean transacted, int ackMode)
  {
    super(context, queueConnFactoryName, sendQueueName, transacted, ackMode);
    initQueueSender();
  }

  private void initQueueSender() {
    try {
      this.queueSender = getQueueSession().createSender(getQueue());
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }

  public void sendObject(Serializable message) throws Exception {
    ObjectMessage objectMessage = getQueueSession().createObjectMessage();
    objectMessage.clearBody();
    objectMessage.setObject(message);
    getQueueSender().send(objectMessage);
    commit();
  }

  public void sendText(String message) throws Exception {
    TextMessage textMessage = getQueueSession().createTextMessage();
    textMessage.clearBody();
    textMessage.setText(message);
    getQueueSender().send(textMessage);
    commit();
  }

  protected QueueSender getQueueSender() throws Exception {
    return this.queueSender;
  }

  public void close() {
    try {
      if (this.queueSender != null) {
        this.queueSender.close();
      }
      super.close();
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }
}