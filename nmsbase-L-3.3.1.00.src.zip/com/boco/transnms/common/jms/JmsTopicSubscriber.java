package com.boco.transnms.common.jms;

import com.boco.common.util.debug.LogHome;
import javax.jms.BytesMessage;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.StreamMessage;
import javax.jms.TextMessage;
import javax.jms.TopicConnection;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;
import javax.naming.Context;
import org.apache.commons.logging.Log;

public class JmsTopicSubscriber extends AbstractJmsTopic
  implements MessageListener
{
  private TopicSubscriber topicSubscriber;
  private String durableName;

  public JmsTopicSubscriber(Context context, String topicConnectionFactoryName, String topicName, String selector)
  {
    this(context, topicConnectionFactoryName, topicName, "", false, "", false, 1, selector, true);
  }

  public JmsTopicSubscriber(Context context, String topicConnectionFactoryName, String topicName, String selector, boolean isInitTopic) {
    this(context, topicConnectionFactoryName, topicName, "", false, "", false, 1, selector, isInitTopic);
  }

  protected JmsTopicSubscriber(Context context, String topicConnectionFactoryName, String topicName, String clientId, boolean durable, String durableName, boolean transacted, int acknowledgementMode, String selector, boolean isInitTopic)
  {
    super(context, topicConnectionFactoryName, topicName, clientId, durable, transacted, acknowledgementMode);
    this.durableName = durableName;
    if ((context != null) && (isInitTopic)) {
      initTopicSubscriber(selector);
      LogHome.getLog().info("TopicName=" + topicName + " 初始化注册成功 ！");
    }
  }

  public void initTopicSubscriber(String selector) {
    try {
      if (isDurable())
        this.topicSubscriber = getTopicSession().createDurableSubscriber(getTopic(), this.durableName, selector, false);
      else {
        this.topicSubscriber = getTopicSession().createSubscriber(getTopic(), selector, false);
      }
      this.topicSubscriber.setMessageListener(this);
      getTopicConnection().start();
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }

  protected TopicSubscriber getTopicSubscriber() {
    return this.topicSubscriber;
  }

  public void close() throws Exception {
    try {
      if (this.topicSubscriber != null) {
        this.topicSubscriber.close();
      }
      super.close();
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }

  public void onMessage(Message message) {
    if ((message instanceof BytesMessage))
      doByteMessage((BytesMessage)message);
    else if ((message instanceof MapMessage))
      doMapMessage((MapMessage)message);
    else if ((message instanceof ObjectMessage))
      doObjectMessage((ObjectMessage)message);
    else if ((message instanceof StreamMessage))
      doStreamMessage((StreamMessage)message);
    else if ((message instanceof TextMessage)) {
      doTextMessage((TextMessage)message);
    }
    try
    {
      commit();
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }

  protected void doByteMessage(BytesMessage message)
  {
  }

  protected void doMapMessage(MapMessage message)
  {
  }

  protected void doObjectMessage(ObjectMessage message)
  {
  }

  protected void doStreamMessage(StreamMessage message)
  {
  }

  protected void doTextMessage(TextMessage message)
  {
  }
}