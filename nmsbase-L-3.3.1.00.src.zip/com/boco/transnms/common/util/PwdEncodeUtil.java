package com.boco.transnms.common.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class PwdEncodeUtil
{
  private static final String SHA_1 = "SHA-1";

  public static byte[] sha1(String pwd)
  {
    MessageDigest sha1 = null;
    try {
      sha1 = MessageDigest.getInstance("SHA-1");
      return sha1.digest(pwd.getBytes());
    } catch (NoSuchAlgorithmException e) {
      e.printStackTrace();
    }
    return null;
  }

  public static String sha1Base64(String pwd)
  {
    byte[] bytes = sha1(pwd);
    return new String(Base64Util.encode(bytes));
  }

  public static void main(String[] args)
  {
    sha1Base64("123");
  }
}