package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class SystemManageEnum
{
  public static final DevType DEV_TYPE = new DevType(null);
  public static final DevState DEV_STATE = new DevState(null);
  public static final CurrentState CURRENT_STATE = new CurrentState(null);
  public static final long Interval_Cycle = 180L;

  public static class CurrentState extends GenericEnum
  {
    public static final long _starting = 1L;
    public static final long _run = 2L;
    public static final long _stoping = 3L;
    public static final long _stop = 4L;

    private CurrentState()
    {
      super.putEnum(Long.valueOf(1L), "STARTING");
      super.putEnum(Long.valueOf(2L), "RUNED");
      super.putEnum(Long.valueOf(3L), "STOPING");
      super.putEnum(Long.valueOf(4L), "STOPED");
    }
  }

  public static class DevState extends GenericEnum
  {
    public static final long _disConnect = 1L;
    public static final long _Connect = 2L;

    private DevState()
    {
      super.putEnum(Long.valueOf(1L), "DISCONNECT");
      super.putEnum(Long.valueOf(2L), "CONNECTING");
    }
  }

  public static class DevType extends GenericEnum
  {
    public static final long _TnmsServer = 49L;
    public static final long _WebServer = 100L;
    public static final long _DMServer = 101L;
    public static final long _RtuServer = 103L;
    public static final long _AppClient = 104L;
    public static final long _WebClient = 105L;
    public static final long _Ems = 106L;
    public static final long _AlarmServer = 107L;

    private DevType()
    {
      super.putEnum(Long.valueOf(101L), "DM_SERVER");
      super.putEnum(Long.valueOf(49L), "TNMS_SERVER");
      super.putEnum(Long.valueOf(100L), "WEB_SERVER");
      super.putEnum(Long.valueOf(103L), "RTU_SERVER");
      super.putEnum(Long.valueOf(104L), "APP_CLIENT");
      super.putEnum(Long.valueOf(105L), "WEB_CLIENT");
      super.putEnum(Long.valueOf(106L), "EMS");
    }
  }
}