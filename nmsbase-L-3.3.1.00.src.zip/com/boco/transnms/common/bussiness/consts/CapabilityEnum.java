package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class CapabilityEnum
{
  public static final CollectionType COLLECTION_TYPE = new CollectionType(null);
  public static final CollectionperiodsType COLLECTIONPERIODS_TYPE = new CollectionperiodsType(null);
  public static final ArgsRangeType ARGSRANGE_TYPE = new ArgsRangeType(null);

  public static class ArgsRangeType extends GenericEnum
  {
    public static final int STANDARD = 1;
    public static final int UN_STANDARD = 2;

    private ArgsRangeType()
    {
      super.putEnum(Integer.valueOf(1), "标准参数");
      super.putEnum(Integer.valueOf(2), "非标准参数");
    }
  }

  public static class CollectionperiodsType extends GenericEnum
  {
    public static final int _15MIN = 1;
    public static final int _24H = 2;

    private CollectionperiodsType()
    {
      super.putEnum(Integer.valueOf(1), "15分钟");
      super.putEnum(Integer.valueOf(2), "24小时");
    }
  }

  public static class CollectionType extends GenericEnum
  {
    public static final int CURRENT = 1;
    public static final int HISTORY = 2;

    private CollectionType()
    {
      super.putEnum(Integer.valueOf(1), "当前性能");
      super.putEnum(Integer.valueOf(2), "历史性能");
    }
  }
}