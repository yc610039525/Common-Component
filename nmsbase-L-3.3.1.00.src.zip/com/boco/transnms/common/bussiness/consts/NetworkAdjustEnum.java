package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class NetworkAdjustEnum
{
  public static final ProjectStatus projectStatus = new ProjectStatus(null);
  public static final Status status = new Status(null);
  public static final ObjectType objectType = new ObjectType(null);
  public static final IsExecTask isExecTask = new IsExecTask(null);
  public static final ObjectStatus objectStatus = new ObjectStatus(null);
  public static final AttachFileType attachType = new AttachFileType(null);
  public static final TaskType taskType = new TaskType(null);
  public static final TaskStatus taskStatus = new TaskStatus(null);
  public static final LogObjectStatus logObjectStatus = new LogObjectStatus(null);
  public static final LogType logType = new LogType(null);

  public static class LogType extends GenericEnum
  {
    public static final long _process = 1L;
    public static final long _success = 2L;
    public static final long _fail = 3L;

    private LogType()
    {
      super.putEnum(Long.valueOf(1L), "处理中");
      super.putEnum(Long.valueOf(2L), "成功");
      super.putEnum(Long.valueOf(3L), "失败");
    }
  }

  public static class TaskStatus extends GenericEnum
  {
    public static final long _unknown = 1L;
    public static final long _executting = 2L;
    public static final long _succ = 3L;
    public static final long _fail = 4L;
    public static final long _partsucc = 5L;

    private TaskStatus()
    {
      super.putEnum(Long.valueOf(1L), "未知");
      super.putEnum(Long.valueOf(2L), "处理中");
      super.putEnum(Long.valueOf(3L), "成功");
      super.putEnum(Long.valueOf(4L), "失败");
      super.putEnum(Long.valueOf(5L), "部分成功");
    }
  }

  public static class TaskType extends GenericEnum
  {
    public static final long _checkTask = 1L;
    public static final long _execTask = 2L;

    private TaskType()
    {
      super.putEnum(Long.valueOf(1L), "核查");
      super.putEnum(Long.valueOf(2L), "实施");
    }
  }

  public static class LogObjectStatus extends GenericEnum
  {
    public static final long _prjCheck = 1L;
    public static final long _setCollectTask = 2L;
    public static final long _preDel = 3L;
    public static final long _preEdit = 4L;
    public static final long _preAdd = 5L;
    public static final long _preCheck = 6L;
    public static final long _setCheckTask = 7L;

    private LogObjectStatus()
    {
      super.putEnum(Long.valueOf(1L), "预案核查");
      super.putEnum(Long.valueOf(2L), "采集任务");
      super.putEnum(Long.valueOf(3L), "预删除");
      super.putEnum(Long.valueOf(4L), "预调整");
      super.putEnum(Long.valueOf(5L), "预增加");
      super.putEnum(Long.valueOf(6L), "待核查");
      super.putEnum(Long.valueOf(7L), "核查任务");
    }
  }

  public static class AttachFileType extends GenericEnum
  {
    public static final long _preAddNe = 1L;
    public static final long _preAddCard = 2L;
    public static final long _preAddTopo = 3L;
    public static final long _preAddTransSys = 4L;
    public static final long _preEditTransSys = 5L;
    public static final long _preAddTranspath = 6L;
    public static final long _preAddTraph = 7L;
    public static final long _preEditTraph = 8L;
    public static final long _preAddJumpLink = 9L;

    private AttachFileType()
    {
      super.putEnum(Long.valueOf(1L), "预新增网元");
      super.putEnum(Long.valueOf(2L), "预新增机盘");
      super.putEnum(Long.valueOf(3L), "预新增拓扑");
      super.putEnum(Long.valueOf(4L), "预新增传输系统");
      super.putEnum(Long.valueOf(5L), "预调整传输系统");
      super.putEnum(Long.valueOf(6L), "预新增通道");
      super.putEnum(Long.valueOf(7L), "预新增电路");
      super.putEnum(Long.valueOf(8L), "预调整电路");
      super.putEnum(Long.valueOf(9L), "预新增连接关系");
    }
  }

  public static class ObjectStatus extends GenericEnum
  {
    public static final long _preDel = 1L;
    public static final long _preEdit = 2L;
    public static final long _preAdd = 3L;
    public static final long _preCheck = 4L;
    public static final long _collectTask = 5L;
    public static final long _transpathCheckTask = 6L;
    public static final long _traphCheckTask = 7L;

    private ObjectStatus()
    {
      super.putEnum(Long.valueOf(1L), "预删除");
      super.putEnum(Long.valueOf(2L), "预调整");
      super.putEnum(Long.valueOf(3L), "预增加");
      super.putEnum(Long.valueOf(4L), "待核查");
      super.putEnum(Long.valueOf(5L), "采集任务");
      super.putEnum(Long.valueOf(6L), "通道核查任务");
      super.putEnum(Long.valueOf(7L), "电路核查任务");
    }
  }

  public static class IsExecTask extends GenericEnum
  {
    public static final long _true = 1L;
    public static final long _false = 0L;

    private IsExecTask()
    {
      super.putEnum(Long.valueOf(1L), "是");
      super.putEnum(Long.valueOf(0L), "否");
    }
  }

  public static class ObjectType extends GenericEnum
  {
    public static final long _ne = 1L;
    public static final long _card = 2L;
    public static final long _topo = 3L;
    public static final long _transSys = 4L;
    public static final long _transpath = 5L;
    public static final long _traph = 6L;
    public static final long _jumpLink = 7L;

    private ObjectType()
    {
      super.putEnum(Long.valueOf(1L), "网元");
      super.putEnum(Long.valueOf(2L), "机盘");
      super.putEnum(Long.valueOf(3L), "拓扑");
      super.putEnum(Long.valueOf(4L), "传输系统");
      super.putEnum(Long.valueOf(5L), "通道");
      super.putEnum(Long.valueOf(6L), "电路");
      super.putEnum(Long.valueOf(7L), "连接关系");
    }
  }

  public static class Status extends GenericEnum
  {
    public static final long _none = 1L;
    public static final long _delNe = 2L;
    public static final long _addNe = 3L;
    public static final long _delCard = 4L;
    public static final long _addCard = 5L;
    public static final long _delTopo = 6L;
    public static final long _addTopo = 7L;
    public static final long _delTransSys = 8L;
    public static final long _modiTransSys = 9L;
    public static final long _addTransSys = 10L;
    public static final long _delTranspath = 11L;
    public static final long _addTranspath = 12L;
    public static final long _modiTraph = 13L;
    public static final long _addTraph = 14L;
    public static final long _addTranspathCheckTask = 15L;
    public static final long _addTraphCheckTask = 16L;

    private Status()
    {
      super.putEnum(Long.valueOf(1L), "未实施");
      super.putEnum(Long.valueOf(2L), "网元删除成功");
      super.putEnum(Long.valueOf(3L), "网元新增成功");
      super.putEnum(Long.valueOf(4L), "机盘删除成功");
      super.putEnum(Long.valueOf(5L), "机盘新增成功");
      super.putEnum(Long.valueOf(6L), "拓扑删除成功");
      super.putEnum(Long.valueOf(7L), "拓扑新增成功");
      super.putEnum(Long.valueOf(8L), "传输系统删除成功");
      super.putEnum(Long.valueOf(9L), "传输系统调整成功");
      super.putEnum(Long.valueOf(10L), "传输系统新增成功");
      super.putEnum(Long.valueOf(11L), "通道删除成功");
      super.putEnum(Long.valueOf(12L), "通道新增成功");
      super.putEnum(Long.valueOf(13L), "电路调整成功");
      super.putEnum(Long.valueOf(14L), "电路新增成功");
      super.putEnum(Long.valueOf(15L), "自动生成通道核查任务成功");
      super.putEnum(Long.valueOf(16L), "自动生成电路核查任务成功");
    }
  }

  public static class ProjectStatus extends GenericEnum
  {
    public static final long _designing = 1L;
    public static final long _checking = 2L;
    public static final long _checkBreak = 3L;
    public static final long _checkSucc = 4L;
    public static final long _executting = 5L;
    public static final long _executeBreak = 6L;
    public static final long _executeSucc = 7L;

    private ProjectStatus()
    {
      super.putEnum(Long.valueOf(1L), "设计中");
      super.putEnum(Long.valueOf(2L), "核查中");
      super.putEnum(Long.valueOf(3L), "核查中断");
      super.putEnum(Long.valueOf(4L), "核查成功");
      super.putEnum(Long.valueOf(5L), "实施中");
      super.putEnum(Long.valueOf(6L), "实施中断");
      super.putEnum(Long.valueOf(7L), "实施完毕");
    }
  }
}