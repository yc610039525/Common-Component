package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class NetAdjustEnum
{
  public static final NetAdjustType netAdjustType = new NetAdjustType(null);
  public static final ObjectType objectType = new ObjectType(null);
  public static final SheetState sheetState = new SheetState(null);
  public static final JobType jobType = new JobType(null);
  public static final JobState jobState = new JobState(null);

  public static class JobState extends GenericEnum
  {
    public static final long _unExec = 0L;
    public static final long _executed = 1L;

    private JobState()
    {
      super.putEnum(Long.valueOf(0L), "未执行");
      super.putEnum(Long.valueOf(1L), "已执行");
    }
  }

  public static class JobType extends GenericEnum
  {
    public static final long _natural2prj = 1L;
    public static final long _prj2natural = 2L;
    public static final long _collectTask = 3L;
    public static final long _checkTraphTask = 4L;

    private JobType()
    {
      super.putEnum(Long.valueOf(1L), "正常->工程");
      super.putEnum(Long.valueOf(2L), "工程->正常");
      super.putEnum(Long.valueOf(3L), "定时采集任务处理");
      super.putEnum(Long.valueOf(4L), "电路核查任务处理");
    }
  }

  public static class SheetState extends GenericEnum
  {
    public static final long _apply = 1L;
    public static final long _design = 2L;
    public static final long _audit = 3L;
    public static final long _reply = 4L;
    public static final long _update = 5L;
    public static final long _archive = 6L;
    public static final long _end = 7L;

    private SheetState()
    {
      super.putEnum(Long.valueOf(1L), "申请");
      super.putEnum(Long.valueOf(2L), "设计");
      super.putEnum(Long.valueOf(3L), "审核");
      super.putEnum(Long.valueOf(4L), "施工");
      super.putEnum(Long.valueOf(5L), "核查");
      super.putEnum(Long.valueOf(6L), "归档");
      super.putEnum(Long.valueOf(7L), "结束");
    }
  }

  public static class ObjectType extends GenericEnum
  {
    public static final long _ne = 1L;
    public static final long _card = 2L;
    public static final long _port = 3L;

    private ObjectType()
    {
      super.putEnum(Long.valueOf(1L), "网元");
      super.putEnum(Long.valueOf(2L), "机盘");
      super.putEnum(Long.valueOf(3L), "端口");
    }
  }

  public static class NetAdjustType extends GenericEnum
  {
    public static final long _adjustCard = 1L;
    public static final long _adjustPort = 2L;
    public static final long _accessSysExp = 3L;
    public static final long _addPoint = 4L;
    public static final long _delPoint = 5L;
    public static final long _beCircle = 6L;
    public static final long _adjustSys = 7L;
    public static final long _addSys = 8L;
    public static final long _delSys = 9L;
    public static final long _beLine = 10L;
    public static final long _laddPoint = 11L;
    public static final long _ldelPoint = 12L;

    private NetAdjustType()
    {
      super.putEnum(Long.valueOf(1L), "机盘调整");
      super.putEnum(Long.valueOf(2L), "端口调整");
      super.putEnum(Long.valueOf(3L), "接入环扩容");
      super.putEnum(Long.valueOf(4L), "环加点");
      super.putEnum(Long.valueOf(5L), "环减点");
      super.putEnum(Long.valueOf(6L), "链改环");
      super.putEnum(Long.valueOf(7L), "环调整");
      super.putEnum(Long.valueOf(8L), "新增传输系统");
      super.putEnum(Long.valueOf(9L), "环/链删除");
      super.putEnum(Long.valueOf(10L), "环改链");
      super.putEnum(Long.valueOf(11L), "链加点");
      super.putEnum(Long.valueOf(12L), "链减点");
    }
  }
}