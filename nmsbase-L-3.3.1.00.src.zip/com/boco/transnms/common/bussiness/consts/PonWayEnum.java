package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class PonWayEnum
{
  public static final IndirectPointType INDIRECT_POINT_TYPE = new IndirectPointType(null);
  public static final GponDeviceLinkType GPON_DEVICE_LINKE_TYPE = new GponDeviceLinkType(null);
  public static final ShareModel SHARE_MODEL = new ShareModel(null);
  public static final TargetLevel TARGET_LEVEL = new TargetLevel(null);
  public static final BusinessSlaLevel BUSINESS_SLA_LEVEL = new BusinessSlaLevel(null);
  public static final ClientServiceAlaLevel CLIENT_SERVICE_SLA_LEVEL = new ClientServiceAlaLevel(null);
  public static final NetLevel NET_LEVEL = new NetLevel(null);
  public static final AttempType ATTEMP_TYPE = new AttempType(null);
  public static final OnuChangeType ONU_CHANGE_TYPE = new OnuChangeType(null);
  public static final ClientPortModel CLIENT_PORT_MODEL = new ClientPortModel(null);
  public static final InputType INPUT_TYPE = new InputType(null);
  public static final BusinessType BUSINESS_TYPE = new BusinessType(null);

  public static class BusinessType extends GenericEnum
  {
    public static final long _WLAN_6506 = 1L;
    public static final long _GPON_WLAN_S_C = 2L;
    public static final long _FTTB_IMS_ZQ = 3L;
    public static final long _FTTH_IMS = 4L;
    public static final long _FTTH_PPPOE = 5L;
    public static final long _FTTB_KDT = 6L;
    public static final long _FTTB_PPPOE_NEW = 7L;
    public static final long _FTTB_IMS_NEW = 8L;
    public static final long _FTTO_IMS = 9L;
    public static final long _FTTO_KDT = 10L;

    private BusinessType()
    {
      super.putEnum(Long.valueOf(1L), "WLAN-6506");
      super.putEnum(Long.valueOf(2L), "GPON_WLAN_S+C’");
      super.putEnum(Long.valueOf(3L), "FTTB_IMS（政企）");
      super.putEnum(Long.valueOf(4L), "FTTH_IMS");
      super.putEnum(Long.valueOf(5L), "FTTH_PPPOE");
      super.putEnum(Long.valueOf(6L), "FTTB_KDT");
      super.putEnum(Long.valueOf(7L), "FTTB_PPPOE_NEW");
      super.putEnum(Long.valueOf(8L), "FTTB_IMS_NEW");
      super.putEnum(Long.valueOf(9L), "FTTO_IMS");
      super.putEnum(Long.valueOf(10L), "FTTO_KDT");
    }
  }

  public static class InputType extends GenericEnum
  {
    public static final long _onuOpticalAttemp = 1L;
    public static final long _onuAttemp = 2L;

    private InputType()
    {
      super.putEnum(Long.valueOf(1L), "PON光电混调");
      super.putEnum(Long.valueOf(2L), "PON光电分离");
    }
  }

  public static class OnuChangeType extends GenericEnum
  {
    public static final long _new = 1L;
    public static final long _reUse = 2L;
    public static final long _retain = 3L;
    public static final long _remove = 4L;

    private OnuChangeType()
    {
      super.putEnum(Long.valueOf(1L), "新增");
      super.putEnum(Long.valueOf(2L), "利旧");
      super.putEnum(Long.valueOf(3L), "保留");
      super.putEnum(Long.valueOf(4L), "拆除");
    }
  }

  public static class AttempType extends GenericEnum
  {
    public static final long _new = 1L;
    public static final long _stop = 2L;
    public static final long _adjust = 3L;
    public static final long _revoke = 4L;

    private AttempType()
    {
      super.putEnum(Long.valueOf(1L), "新增");
      super.putEnum(Long.valueOf(2L), "拆机");
      super.putEnum(Long.valueOf(3L), "调整");
      super.putEnum(Long.valueOf(4L), "撤销");
    }
  }

  public static class ClientPortModel extends GenericEnum
  {
    public static final long _1 = 1L;
    public static final long _2 = 2L;

    private ClientPortModel()
    {
      super.putEnum(Long.valueOf(1L), "TAG(用户VLAN)");
      super.putEnum(Long.valueOf(2L), "UNTAG");
    }
  }

  public static class ClientServiceAlaLevel extends GenericEnum
  {
    public static final long _1 = 1L;
    public static final long _2 = 2L;
    public static final long _3 = 3L;
    public static final long _4 = 4L;

    private ClientServiceAlaLevel()
    {
      super.putEnum(Long.valueOf(1L), "标准SLA1");
      super.putEnum(Long.valueOf(2L), "标准SLA2");
      super.putEnum(Long.valueOf(3L), "标准SLA3");
      super.putEnum(Long.valueOf(4L), "标准SLA4");
    }
  }

  public static class BusinessSlaLevel extends GenericEnum
  {
    public static final long _1 = 1L;
    public static final long _2 = 2L;
    public static final long _3 = 3L;
    public static final long _4 = 4L;

    private BusinessSlaLevel()
    {
      super.putEnum(Long.valueOf(1L), "标准SLA1");
      super.putEnum(Long.valueOf(2L), "标准SLA2");
      super.putEnum(Long.valueOf(3L), "标准SLA3");
      super.putEnum(Long.valueOf(4L), "标准SLA4");
    }
  }

  public static class NetLevel extends GenericEnum
  {
    public static final long _1 = 1L;
    public static final long _2 = 2L;
    public static final long _3 = 3L;
    public static final long _4 = 4L;

    private NetLevel()
    {
      super.putEnum(Long.valueOf(1L), "1");
      super.putEnum(Long.valueOf(2L), "2");
      super.putEnum(Long.valueOf(3L), "3");
      super.putEnum(Long.valueOf(4L), "4");
    }
  }

  public static class TargetLevel extends GenericEnum
  {
    public static final long _1 = 1L;
    public static final long _2 = 2L;
    public static final long _3 = 3L;
    public static final long _4 = 4L;

    private TargetLevel()
    {
      super.putEnum(Long.valueOf(1L), "1");
      super.putEnum(Long.valueOf(2L), "2");
      super.putEnum(Long.valueOf(3L), "3");
      super.putEnum(Long.valueOf(4L), "4");
    }
  }

  public static class ShareModel extends GenericEnum
  {
    public static final long _public = 1L;
    public static final long _single = 2L;

    private ShareModel()
    {
      super.putEnum(Long.valueOf(1L), "共享");
      super.putEnum(Long.valueOf(2L), "独享");
    }
  }

  public static class GponDeviceLinkType extends GenericEnum
  {
    public static final long _switchToOlt = 1L;
    public static final long _oltToLight = 2L;
    public static final long _lightToLight = 3L;
    public static final long _lightToOnt = 4L;
    public static final long _lightToOnu = 5L;

    private GponDeviceLinkType()
    {
      super.putEnum(Long.valueOf(1L), "交换机-OLT");
      super.putEnum(Long.valueOf(2L), "OLT-分光器");
      super.putEnum(Long.valueOf(3L), "分光器-分光器");
      super.putEnum(Long.valueOf(4L), "分光器-ONT");
      super.putEnum(Long.valueOf(5L), "分光器-ONU");
    }
  }

  public static class IndirectPointType extends GenericEnum
  {
    public static final long _light = 1L;
    public static final long _fiberCab = 2L;
    public static final long _accesspoint = 3L;
    public static final long _olt = 4L;

    private IndirectPointType()
    {
      super.putEnum(Long.valueOf(1L), "分光器");
      super.putEnum(Long.valueOf(2L), "光交箱");
      super.putEnum(Long.valueOf(3L), "接入点");
      super.putEnum(Long.valueOf(4L), "OLT");
    }
  }
}