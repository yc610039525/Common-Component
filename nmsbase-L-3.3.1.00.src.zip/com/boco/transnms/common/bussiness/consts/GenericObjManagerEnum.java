package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class GenericObjManagerEnum
{
  public static final AttrType ATTR_TYPE = new AttrType(null);

  public static class AttrType extends GenericEnum { public static final long _String = 0L;
    public static final long _Long = 1L;
    public static final long _Double = 2L;
    public static final long _Enum = 3L;
    public static final long _Date = 4L;
    public static final long _Time = 5L;
    public static final long _Boolean = 6L;

    private AttrType() { super.putEnum(Long.valueOf(0L), "字符");
      super.putEnum(Long.valueOf(1L), "数字");
      super.putEnum(Long.valueOf(2L), "浮点数");
      super.putEnum(Long.valueOf(3L), "枚举");
      super.putEnum(Long.valueOf(4L), "日期");
      super.putEnum(Long.valueOf(5L), "时间");
      super.putEnum(Long.valueOf(6L), "布尔值");
    }
  }
}