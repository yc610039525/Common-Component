package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class SynElementEnum extends GenericEnum
{
  public static final ClockLevel CLOCK_LEVEL = new ClockLevel(null);
  public static final TimePro TIMEPRO = new TimePro(null);
  public static final UseState USESTATE = new UseState(null);
  public static final EnableControl ENABLECONTROL = new EnableControl(null);

  public static class EnableControl extends GenericEnum
  {
    public static final long _CAN = 1L;
    public static final long _CANT = 2L;

    private EnableControl()
    {
      super.putEnum(Long.valueOf(1L), "能");
      super.putEnum(Long.valueOf(2L), "否");
    }
  }

  public static class UseState extends GenericEnum
  {
    public static final long _IDLESSE = 1L;
    public static final long _POSSESSIVE = 2L;
    public static final long _BAD = 3L;

    private UseState()
    {
      super.putEnum(Long.valueOf(1L), "空闲");
      super.putEnum(Long.valueOf(2L), "占用");
      super.putEnum(Long.valueOf(3L), "损坏");
    }
  }

  public static class TimePro extends GenericEnum
  {
    public static final long _SZ_G_G_G = 1L;
    public static final long _SZ_G_G = 2L;
    public static final long _RZ_G = 3L;
    public static final long _RZ = 4L;
    public static final long _JTZ = 5L;
    public static final long _RZ_G_G = 6L;

    private TimePro()
    {
      super.putEnum(Long.valueOf(1L), "铯钟/GPS/GPS+GLO");
      super.putEnum(Long.valueOf(2L), "铯钟/GPS/GLO");
      super.putEnum(Long.valueOf(3L), "铷钟/GPS");
      super.putEnum(Long.valueOf(4L), "铷钟");
      super.putEnum(Long.valueOf(5L), "晶体钟");
      super.putEnum(Long.valueOf(6L), "铷钟/GPS+GLO");
    }
  }

  public static class ClockLevel extends GenericEnum
  {
    public static final long _PRC = 1L;
    public static final long _LPR = 2L;
    public static final long _SSU_T = 3L;
    public static final long _SSU_L = 4L;

    private ClockLevel()
    {
      super.putEnum(Long.valueOf(1L), "PRC");
      super.putEnum(Long.valueOf(2L), "LPR");
      super.putEnum(Long.valueOf(3L), "二级");
      super.putEnum(Long.valueOf(4L), "三级");
    }
  }
}