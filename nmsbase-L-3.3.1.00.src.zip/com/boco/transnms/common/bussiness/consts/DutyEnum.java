package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class DutyEnum
{
  public static final RecordType RECORD_TYPE = new RecordType(null);
  public static final RecordSource RECORD_SOURCE = new RecordSource(null);

  public static final FaultReason FAULT_REASON = new FaultReason(null);

  public static class FaultReason extends GenericEnum
  {
    public static final long _longdistance = 1L;
    public static final long _oneself = 2L;
    public static final long _client = 3L;

    private FaultReason()
    {
      super.putEnum(Long.valueOf(1L), "长途原因");
      super.putEnum(Long.valueOf(2L), "本地原因");
      super.putEnum(Long.valueOf(3L), "客户自身原因");
    }
  }

  public static class RecordSource extends GenericEnum
  {
    public static final long _user = 1L;
    public static final long _alarm = 2L;
    public static final long _input = 4L;

    private RecordSource()
    {
      super.putEnum(Long.valueOf(1L), "用户申告");
      super.putEnum(Long.valueOf(2L), "告警流转");

      super.putEnum(Long.valueOf(4L), "手工输入");
    }
  }

  public static class RecordType extends GenericEnum
  {
    public static final long _fault = 1L;
    public static final long _cession = 2L;
    public static final long _app = 3L;
    public static final long _other = 4L;

    private RecordType()
    {
      super.putEnum(Long.valueOf(1L), "故障");
      super.putEnum(Long.valueOf(2L), "割接");
      super.putEnum(Long.valueOf(3L), "客户申告");
      super.putEnum(Long.valueOf(4L), "其它");
    }
  }
}