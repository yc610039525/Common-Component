package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class CardTypeEnum extends GenericEnum
{
  public static final TrType TR_TYPE = new TrType(null);

  public static class TrType extends GenericEnum
  {
    public static final long _PT1 = 1L;
    public static final long _PT2 = 2L;
    public static final long _PT3 = 3L;
    public static final long _PT4 = 4L;
    public static final long _unknow = 0L;

    private TrType()
    {
      super.putEnum(Long.valueOf(1L), "T-发盘");
      super.putEnum(Long.valueOf(2L), "R-收盘");
      super.putEnum(Long.valueOf(3L), "TR-收发同盘且同向");
      super.putEnum(Long.valueOf(4L), "ATR-收发同盘不同向");
      super.putEnum(Long.valueOf(0L), "未知");
    }
  }
}