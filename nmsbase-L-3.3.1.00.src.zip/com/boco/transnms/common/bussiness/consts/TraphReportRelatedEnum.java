package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class TraphReportRelatedEnum
{
  public static final RateRelated rateRelated = new RateRelated(null);
  public static final RateRelated45M rateRelated45M = new RateRelated45M(null);
  public static final OwnerShipRelated ownerShipRelated = new OwnerShipRelated(null);
  public static final TraphLevelRelated traphLevelRelated = new TraphLevelRelated(null);
  public static final RateTransformRelated rateTransformRelated = new RateTransformRelated(null);
  public static final RateTransformRelated45M rateTransformRelated45M = new RateTransformRelated45M(null);
  public static final ConverRate converRate = new ConverRate(null);
  public static final SwitchPortRate switchPortRate = new SwitchPortRate(null);
  public static final PortState portState = new PortState(null);

  public static class PortState extends GenericEnum
  {
    public static final long _DIS = 1L;
    public static final long _PRE = 2L;
    public static final long _SET = 3L;
    public static final long _BAD = 4L;
    public static final long _MA1 = 5L;
    public static final long _MA2 = 6L;
    public static final long _TEST = 7L;
    public static final long _BACK = 8L;

    private PortState()
    {
      super.putEnum(Long.valueOf(1L), "空闲");
      super.putEnum(Long.valueOf(2L), "已用");
      super.putEnum(Long.valueOf(3L), "其他");
      super.putEnum(Long.valueOf(4L), "其他");
      super.putEnum(Long.valueOf(5L), "其他");
      super.putEnum(Long.valueOf(6L), "其他");
      super.putEnum(Long.valueOf(7L), "其他");
      super.putEnum(Long.valueOf(8L), "其他");
    }
  }

  public static class SwitchPortRate extends GenericEnum
  {
    public static final long _2M = 1L;
    public static final long _8M = 2L;
    public static final long _10M = 3L;
    public static final long _34M = 4L;
    public static final long _45M = 5L;
    public static final long _68M = 6L;
    public static final long _100M = 7L;
    public static final long _140M = 8L;
    public static final long _155M = 9L;
    public static final long _280M = 10L;
    public static final long _310M = 11L;
    public static final long _565M = 12L;
    public static final long _622M = 13L;
    public static final long _1G = 14L;
    public static final long _1_25G = 15L;
    public static final long _2_5G = 16L;
    public static final long _10G = 17L;
    public static final long _20G = 18L;
    public static final long _40G = 19L;
    public static final long _80G = 20L;
    public static final long _120G = 21L;
    public static final long _6M = 22L;
    public static final long _12M = 23L;
    public static final long _16M = 24L;
    public static final long _4M = 25L;

    private SwitchPortRate()
    {
      super.putEnum(Long.valueOf(1L), "2M");
      super.putEnum(Long.valueOf(25L), "4M");
      super.putEnum(Long.valueOf(2L), "8M");
      super.putEnum(Long.valueOf(3L), "10M");
      super.putEnum(Long.valueOf(4L), "34M");
      super.putEnum(Long.valueOf(5L), "45M");
      super.putEnum(Long.valueOf(6L), "68M");
      super.putEnum(Long.valueOf(7L), "100M");
      super.putEnum(Long.valueOf(8L), "140M");
      super.putEnum(Long.valueOf(9L), "155M");
      super.putEnum(Long.valueOf(10L), "280M");
      super.putEnum(Long.valueOf(11L), "310M");
      super.putEnum(Long.valueOf(12L), "565M");
      super.putEnum(Long.valueOf(13L), "622M");
      super.putEnum(Long.valueOf(14L), "1G");
      super.putEnum(Long.valueOf(15L), "1.25G");
      super.putEnum(Long.valueOf(16L), "2.5G");
      super.putEnum(Long.valueOf(17L), "10G ");
      super.putEnum(Long.valueOf(18L), "20G ");
      super.putEnum(Long.valueOf(19L), "40G ");
      super.putEnum(Long.valueOf(20L), "80G ");
      super.putEnum(Long.valueOf(21L), "120G ");
      super.putEnum(Long.valueOf(22L), "6M ");
      super.putEnum(Long.valueOf(23L), "12M ");
      super.putEnum(Long.valueOf(24L), "16M ");
    }
  }

  public static class ConverRate extends GenericEnum
  {
    public static final long _2M = 1L;
    public static final long _8M = 2L;
    public static final long _10M = 3L;
    public static final long _34M = 4L;
    public static final long _45M = 5L;
    public static final long _68M = 6L;
    public static final long _100M = 7L;
    public static final long _140M = 8L;
    public static final long _155M = 9L;
    public static final long _280M = 10L;
    public static final long _310M = 11L;
    public static final long _565M = 12L;
    public static final long _622M = 13L;
    public static final long _1G = 14L;
    public static final long _1_25G = 15L;
    public static final long _2_5G = 16L;
    public static final long _10G = 17L;
    public static final long _20G = 18L;
    public static final long _40G = 19L;
    public static final long _80G = 20L;
    public static final long _120G = 21L;
    public static final long _6M = 22L;
    public static final long _12M = 23L;
    public static final long _16M = 24L;
    public static final long _4M = 25L;

    private ConverRate()
    {
      super.putEnum(Long.valueOf(1L), "1");
      super.putEnum(Long.valueOf(25L), "2");
      super.putEnum(Long.valueOf(2L), "4");
      super.putEnum(Long.valueOf(3L), "5");
      super.putEnum(Long.valueOf(4L), "16");
      super.putEnum(Long.valueOf(5L), "21");
      super.putEnum(Long.valueOf(6L), "32");
      super.putEnum(Long.valueOf(7L), "50");
      super.putEnum(Long.valueOf(8L), "64");
      super.putEnum(Long.valueOf(9L), "63");
      super.putEnum(Long.valueOf(10L), "128");
      super.putEnum(Long.valueOf(11L), "126");
      super.putEnum(Long.valueOf(12L), "256");
      super.putEnum(Long.valueOf(13L), "252");
      super.putEnum(Long.valueOf(14L), "500");
      super.putEnum(Long.valueOf(15L), "504");
      super.putEnum(Long.valueOf(16L), "1008");
      super.putEnum(Long.valueOf(17L), "4032");
      super.putEnum(Long.valueOf(18L), "8064");
      super.putEnum(Long.valueOf(19L), "16128");
      super.putEnum(Long.valueOf(20L), "32256");
      super.putEnum(Long.valueOf(21L), "48384");
      super.putEnum(Long.valueOf(22L), "3");
      super.putEnum(Long.valueOf(23L), "6");
      super.putEnum(Long.valueOf(24L), "8");
    }
  }

  public static class RateTransformRelated extends GenericEnum
  {
    public static final long _2M = 1L;
    public static final long _8M = 2L;
    public static final long _10M = 3L;
    public static final long _34M = 4L;
    public static final long _45M = 5L;
    public static final long _68M = 6L;
    public static final long _100M = 7L;
    public static final long _140M = 8L;
    public static final long _155M = 9L;
    public static final long _280M = 10L;
    public static final long _310M = 11L;
    public static final long _565M = 12L;
    public static final long _622M = 13L;
    public static final long _1G = 14L;
    public static final long _1_25G = 15L;
    public static final long _2_5G = 16L;
    public static final long _10G = 17L;
    public static final long _20G = 18L;
    public static final long _40G = 19L;
    public static final long _80G = 20L;

    private RateTransformRelated()
    {
      super.putEnum(Long.valueOf(1L), "1");
      super.putEnum(Long.valueOf(2L), "4");
      super.putEnum(Long.valueOf(3L), "5");
      super.putEnum(Long.valueOf(4L), "16");
      super.putEnum(Long.valueOf(5L), "21");
      super.putEnum(Long.valueOf(6L), "32");
      super.putEnum(Long.valueOf(7L), "50");
      super.putEnum(Long.valueOf(8L), "64");
      super.putEnum(Long.valueOf(9L), "1");
      super.putEnum(Long.valueOf(10L), "2");
      super.putEnum(Long.valueOf(11L), "2");
      super.putEnum(Long.valueOf(12L), "4");
      super.putEnum(Long.valueOf(13L), "4");
      super.putEnum(Long.valueOf(14L), "8");
      super.putEnum(Long.valueOf(15L), "8");
      super.putEnum(Long.valueOf(16L), "16");
      super.putEnum(Long.valueOf(17L), "64");
      super.putEnum(Long.valueOf(18L), "128");
      super.putEnum(Long.valueOf(19L), "256");
      super.putEnum(Long.valueOf(20L), "512");
    }
  }

  public static class RateTransformRelated45M extends GenericEnum
  {
    public static final long _2M = 1L;
    public static final long _8M = 2L;
    public static final long _10M = 3L;
    public static final long _34M = 4L;
    public static final long _45M = 5L;
    public static final long _68M = 6L;
    public static final long _100M = 7L;
    public static final long _140M = 8L;
    public static final long _155M = 9L;
    public static final long _280M = 10L;
    public static final long _310M = 11L;
    public static final long _565M = 12L;
    public static final long _622M = 13L;
    public static final long _1G = 14L;
    public static final long _1_25G = 15L;
    public static final long _2_5G = 16L;
    public static final long _10G = 17L;
    public static final long _20G = 18L;
    public static final long _40G = 19L;
    public static final long _80G = 20L;

    private RateTransformRelated45M()
    {
      super.putEnum(Long.valueOf(1L), "1");
      super.putEnum(Long.valueOf(2L), "4");
      super.putEnum(Long.valueOf(3L), "5");
      super.putEnum(Long.valueOf(4L), "16");
      super.putEnum(Long.valueOf(5L), "1");
      super.putEnum(Long.valueOf(6L), "2");
      super.putEnum(Long.valueOf(7L), "2");
      super.putEnum(Long.valueOf(8L), "3");
      super.putEnum(Long.valueOf(9L), "1");
      super.putEnum(Long.valueOf(10L), "2");
      super.putEnum(Long.valueOf(11L), "2");
      super.putEnum(Long.valueOf(12L), "4");
      super.putEnum(Long.valueOf(13L), "4");
      super.putEnum(Long.valueOf(14L), "8");
      super.putEnum(Long.valueOf(15L), "8");
      super.putEnum(Long.valueOf(16L), "16");
      super.putEnum(Long.valueOf(17L), "64");
      super.putEnum(Long.valueOf(18L), "128");
      super.putEnum(Long.valueOf(19L), "256");
      super.putEnum(Long.valueOf(20L), "512");
    }
  }

  public static class TraphLevelRelated extends GenericEnum
  {
    public static final long _L1 = 1L;
    public static final long _L2 = 2L;
    public static final long _L3 = 3L;
    public static final long _L4 = 4L;
    public static final long _L5 = 5L;
    public static final long _L6 = 6L;
    public static final long _L7 = 7L;
    public static final long _L8 = 8L;
    public static final long _L9 = 9L;
    public static final long _L10 = 10L;

    private TraphLevelRelated()
    {
      super.putEnum(Long.valueOf(1L), "国际电路");
      super.putEnum(Long.valueOf(2L), "国际电路");
      super.putEnum(Long.valueOf(3L), "国际电路");
      super.putEnum(Long.valueOf(4L), "省际一干电路");
      super.putEnum(Long.valueOf(5L), "省际一干电路");
      super.putEnum(Long.valueOf(6L), "省内二干电路");
      super.putEnum(Long.valueOf(7L), "省内城域电路");
      super.putEnum(Long.valueOf(8L), "省内城域电路");
      super.putEnum(Long.valueOf(9L), "省内城域电路");
      super.putEnum(Long.valueOf(10L), "省内城域电路");
    }
  }

  public static class OwnerShipRelated extends GenericEnum
  {
    public static final long _SELF = 1L;
    public static final long _RENT = 2L;
    public static final long _MIX = 3L;
    public static final long _SHARE = 4L;

    private OwnerShipRelated()
    {
      super.putEnum(Long.valueOf(1L), "自建");
      super.putEnum(Long.valueOf(2L), "租用");
      super.putEnum(Long.valueOf(3L), "其他");
      super.putEnum(Long.valueOf(4L), "其他");
    }
  }

  public static class RateRelated extends GenericEnum
  {
    public static final long _2M = 1L;
    public static final long _8M = 2L;
    public static final long _10M = 3L;
    public static final long _34M = 4L;
    public static final long _45M = 5L;
    public static final long _68M = 6L;
    public static final long _100M = 7L;
    public static final long _140M = 8L;
    public static final long _155M = 9L;
    public static final long _280M = 10L;
    public static final long _310M = 11L;
    public static final long _565M = 12L;
    public static final long _622M = 13L;
    public static final long _1G = 14L;
    public static final long _1_25G = 15L;
    public static final long _2_5G = 16L;
    public static final long _10G = 17L;
    public static final long _20G = 18L;
    public static final long _40G = 19L;
    public static final long _80G = 20L;

    private RateRelated()
    {
      super.putEnum(Long.valueOf(1L), "2M");
      super.putEnum(Long.valueOf(2L), "2M");
      super.putEnum(Long.valueOf(3L), "2M");
      super.putEnum(Long.valueOf(4L), "2M");
      super.putEnum(Long.valueOf(5L), "2M");
      super.putEnum(Long.valueOf(6L), "2M");
      super.putEnum(Long.valueOf(7L), "2M");
      super.putEnum(Long.valueOf(8L), "2M");
      super.putEnum(Long.valueOf(9L), "155M");
      super.putEnum(Long.valueOf(10L), "155M");
      super.putEnum(Long.valueOf(11L), "155M");
      super.putEnum(Long.valueOf(12L), "155M");
      super.putEnum(Long.valueOf(13L), "155M");
      super.putEnum(Long.valueOf(14L), "155M");
      super.putEnum(Long.valueOf(15L), "155M");
      super.putEnum(Long.valueOf(16L), "155M");
      super.putEnum(Long.valueOf(17L), "155M");
      super.putEnum(Long.valueOf(18L), "155M");
      super.putEnum(Long.valueOf(19L), "155M");
      super.putEnum(Long.valueOf(20L), "155M");
    }
  }

  public static class RateRelated45M extends GenericEnum
  {
    public static final long _2M = 1L;
    public static final long _8M = 2L;
    public static final long _10M = 3L;
    public static final long _34M = 4L;
    public static final long _45M = 5L;
    public static final long _68M = 6L;
    public static final long _100M = 7L;
    public static final long _140M = 8L;
    public static final long _155M = 9L;
    public static final long _280M = 10L;
    public static final long _310M = 11L;
    public static final long _565M = 12L;
    public static final long _622M = 13L;
    public static final long _1G = 14L;
    public static final long _1_25G = 15L;
    public static final long _2_5G = 16L;
    public static final long _10G = 17L;
    public static final long _20G = 18L;
    public static final long _40G = 19L;
    public static final long _80G = 20L;

    private RateRelated45M()
    {
      super.putEnum(Long.valueOf(1L), "2M");
      super.putEnum(Long.valueOf(2L), "2M");
      super.putEnum(Long.valueOf(3L), "2M");
      super.putEnum(Long.valueOf(4L), "2M");
      super.putEnum(Long.valueOf(5L), "45M");
      super.putEnum(Long.valueOf(6L), "45M");
      super.putEnum(Long.valueOf(7L), "45M");
      super.putEnum(Long.valueOf(8L), "45M");
      super.putEnum(Long.valueOf(9L), "155M");
      super.putEnum(Long.valueOf(10L), "155M");
      super.putEnum(Long.valueOf(11L), "155M");
      super.putEnum(Long.valueOf(12L), "155M");
      super.putEnum(Long.valueOf(13L), "155M");
      super.putEnum(Long.valueOf(14L), "155M");
      super.putEnum(Long.valueOf(15L), "155M");
      super.putEnum(Long.valueOf(16L), "155M");
      super.putEnum(Long.valueOf(17L), "155M");
      super.putEnum(Long.valueOf(18L), "155M");
      super.putEnum(Long.valueOf(19L), "155M");
      super.putEnum(Long.valueOf(20L), "155M");
    }
  }
}