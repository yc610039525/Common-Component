package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class GeneralLinkEnum
{
  public static final TrunkgroupRate TRUNKGROUP_RATE = new TrunkgroupRate(null);
  public static final TrunkgroupOfficeDire TRUNKGROUP_OFFICE_DIRE = new TrunkgroupOfficeDire(null);
  public static final TrunkgroupApplicationMode TRUNKGROUP_APPLICATION_MODE = new TrunkgroupApplicationMode(null);
  public static final LinksetOfficeDire LINKSET_OFFICE_DIRE = new LinksetOfficeDire(null);
  public static final DataLinkType DATA_LINK_TYPE = new DataLinkType(null);

  public static class DataLinkType extends GenericEnum
  {
    public static final long _ether = 1L;
    public static final long _atm = 2L;
    public static final long _ppp = 3L;
    public static final long _e1 = 4L;

    private DataLinkType()
    {
      super.putEnum(Long.valueOf(1L), "ETHER");
      super.putEnum(Long.valueOf(2L), "ATM");
      super.putEnum(Long.valueOf(3L), "PPP");
      super.putEnum(Long.valueOf(4L), "E1");
    }
  }

  public static class LinksetOfficeDire extends GenericEnum
  {
    public static final long _hstp = 1L;
    public static final long _lstp = 2L;
    public static final long _gk = 3L;
    public static final long _msc = 4L;
    public static final long _hlr = 5L;
    public static final long _smc = 6L;
    public static final long _scp = 7L;
    public static final long _bsc = 8L;
    public static final long _wtpstn = 9L;
    public static final long _dxpstn = 10L;
    public static final long _cmcc = 11L;
    public static final long _tt = 12L;
    public static final long _yy = 13L;
    public static final long _xl = 14L;
    public static final long _cdma = 15L;
    public static final long _gsm = 16L;
    public static final long _other = 17L;

    private LinksetOfficeDire()
    {
      super.putEnum(Long.valueOf(1L), "去向HSTP");
      super.putEnum(Long.valueOf(2L), "去向LSTP");
      super.putEnum(Long.valueOf(3L), "去向关口局");
      super.putEnum(Long.valueOf(4L), "去向省内各MSC");
      super.putEnum(Long.valueOf(5L), "去向HLR");
      super.putEnum(Long.valueOf(6L), "去向短信中心");
      super.putEnum(Long.valueOf(7L), "去向SCP");
      super.putEnum(Long.valueOf(8L), "去向BSC");
      super.putEnum(Long.valueOf(9L), "去向网通PSTN");
      super.putEnum(Long.valueOf(10L), "去向电信PSTN");
      super.putEnum(Long.valueOf(11L), "去向中国移动");
      super.putEnum(Long.valueOf(12L), "去向铁通");
      super.putEnum(Long.valueOf(13L), "去向语音信箱");
      super.putEnum(Long.valueOf(14L), "去向炫铃");
      super.putEnum(Long.valueOf(15L), "去向CDMA网");
      super.putEnum(Long.valueOf(16L), "去向GSM网");
      super.putEnum(Long.valueOf(17L), "去向其它");
    }
  }

  public static class TrunkgroupApplicationMode extends GenericEnum
  {
    public static final long _ld = 1L;
    public static final long _zh = 2L;
    public static final long _lz = 3L;

    private TrunkgroupApplicationMode()
    {
      super.putEnum(Long.valueOf(1L), "落地");
      super.putEnum(Long.valueOf(2L), "转话");
      super.putEnum(Long.valueOf(3L), "落转");
    }
  }

  public static class TrunkgroupOfficeDire extends GenericEnum
  {
    public static final long _tmsc1 = 1L;
    public static final long _tmsc2 = 2L;
    public static final long _gk = 3L;
    public static final long _msc = 4L;
    public static final long _193 = 5L;
    public static final long _ip = 6L;
    public static final long _wtpstn = 7L;
    public static final long _dxpstn = 8L;
    public static final long _cmcc = 9L;
    public static final long _tt = 10L;
    public static final long _bsc = 11L;
    public static final long _cdma = 12L;
    public static final long _gsm = 13L;
    public static final long _other = 14L;

    private TrunkgroupOfficeDire()
    {
      super.putEnum(Long.valueOf(1L), "去向TMSC1");
      super.putEnum(Long.valueOf(2L), "去向TMSC2");
      super.putEnum(Long.valueOf(3L), "去向关口局");
      super.putEnum(Long.valueOf(4L), "去向省内各MSC");
      super.putEnum(Long.valueOf(5L), "去向193长途");
      super.putEnum(Long.valueOf(6L), "去向IP网");
      super.putEnum(Long.valueOf(7L), "去向网通PSTN");
      super.putEnum(Long.valueOf(8L), "去向电信PSTN");
      super.putEnum(Long.valueOf(9L), "去向中国移动");
      super.putEnum(Long.valueOf(10L), "去向铁通");
      super.putEnum(Long.valueOf(11L), "去向BSC");
      super.putEnum(Long.valueOf(12L), "去向CDMA网");
      super.putEnum(Long.valueOf(13L), "去向GSM网");
      super.putEnum(Long.valueOf(14L), "去向其它");
    }
  }

  public static class TrunkgroupRate extends GenericEnum
  {
    public static final long _E1 = 1L;
    public static final long _T1 = 2L;
    public static final long _STM1 = 3L;

    private TrunkgroupRate()
    {
      super.putEnum(Long.valueOf(1L), "E1");
      super.putEnum(Long.valueOf(2L), "T1");
      super.putEnum(Long.valueOf(3L), "STM1");
    }
  }
}