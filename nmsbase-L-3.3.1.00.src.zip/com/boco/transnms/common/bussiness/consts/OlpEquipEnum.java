package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class OlpEquipEnum
{
  public static final WorkingState WORKING_STATE = new WorkingState(null);
  public static final ProtectMode PROTECT_MODE = new ProtectMode(null);
  public static final WorkMode WORK_MODE = new WorkMode(null);
  public static final ResumeMode RESUME_MODE = new ResumeMode(null);

  public static final WorkChannel WORK_CHANNEL = new WorkChannel(null);
  public static final WorkModeSelect WORK_MODE_SELECT = new WorkModeSelect(null);

  public static class WorkChannel extends GenericEnum
  {
    public static final long _mianAndMa = 1L;
    public static final long _mainAndBack = 2L;
    public static final long _bothAndMa = 3L;
    public static final long _bothAndBack = 4L;
    public static final long _other = 5L;

    private WorkChannel()
    {
      super.putEnum(Long.valueOf(1L), "主发主收");
      super.putEnum(Long.valueOf(2L), "主发备收");
      super.putEnum(Long.valueOf(3L), "双发主收");
      super.putEnum(Long.valueOf(4L), "双发备收");
      super.putEnum(Long.valueOf(5L), "其他");
    }
  }

  public static class WorkModeSelect extends GenericEnum
  {
    public static final long _autoNoBack = 1L;
    public static final long _autoback = 2L;
    public static final long _byhand = 3L;

    private WorkModeSelect()
    {
      super.putEnum(Long.valueOf(1L), "自动切换不返回");
      super.putEnum(Long.valueOf(2L), "自动切换返回");
      super.putEnum(Long.valueOf(3L), "手动切换");
    }
  }

  public static class ResumeMode extends GenericEnum
  {
    public static final long _auto = 1L;
    public static final long _byhand = 2L;

    private ResumeMode()
    {
      super.putEnum(Long.valueOf(1L), "自动");
      super.putEnum(Long.valueOf(2L), "手动");
    }
  }

  public static class WorkMode extends GenericEnum
  {
    public static final long _auto = 1L;
    public static final long _byhand = 2L;

    private WorkMode()
    {
      super.putEnum(Long.valueOf(1L), "自动");
      super.putEnum(Long.valueOf(2L), "手动");
    }
  }

  public static class ProtectMode extends GenericEnum
  {
    public static final long _mian = 1L;
    public static final long _both = 2L;
    public static final long _other = 3L;

    private ProtectMode()
    {
      super.putEnum(Long.valueOf(1L), "1:1");
      super.putEnum(Long.valueOf(2L), "1+1");
      super.putEnum(Long.valueOf(3L), "其他");
    }
  }

  public static class WorkingState extends GenericEnum
  {
    public static final long _ma = 1L;
    public static final long _back = 2L;

    private WorkingState()
    {
      super.putEnum(Long.valueOf(1L), "主用");
      super.putEnum(Long.valueOf(2L), "备用");
    }
  }
}