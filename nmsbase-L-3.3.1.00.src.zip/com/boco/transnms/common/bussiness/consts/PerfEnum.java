package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class PerfEnum
{
  public static final FarOrNear FARORNEAR = new FarOrNear(null);
  public static final MonitorCycle MONITOR_CYCLE = new MonitorCycle(null);
  public static final CollectFlag COLLECT_FLAG = new CollectFlag(null);
  public static final ActiveFlagType ACTIVEFLAG_TYPE = new ActiveFlagType(null);
  public static final PlanType PLAN_TYPE = new PlanType(null);
  public static final AutotestCycle AUTOTEST_CYCLE = new AutotestCycle(null);
  public static final AutotestStyle AUTOTEST_STYLE = new AutotestStyle(null);
  public static final ScopeType SCOPE_TYPE = new ScopeType(null);
  public static final TaskStatus TASK_STATUS = new TaskStatus(null);
  public static final ColResultFlag COLRESULT_FLAG = new ColResultFlag(null);
  public static final ObjectType OBJECT_TYPE = new ObjectType(null);
  public static final ObjectTypeNew OBJECT_TYPE_NEW = new ObjectTypeNew(null);
  public static final LimitType LIMIT_TYPE = new LimitType(null);
  public static final VendorOrStander VENDOR_OR_STANDER = new VendorOrStander(null);
  public static final DayEnum DAY_ENUM = new DayEnum(null);
  public static final GmccInspReportEnum GMCC_INSP_REPORTENUM = new GmccInspReportEnum(null);
  public static final GmccScopeType GMCC_SCOPE_TYPE = new GmccScopeType(null);
  public static final GmccPortType GMCC_PORT_TYPE = new GmccPortType(null);
  public static final GmccPortProp GMCC_PORT_PROP = new GmccPortProp(null);
  public static final GmccOperateTask GMCC_OPERATE_TASK = new GmccOperateTask(null);
  public static final GmccParamtype GMCC_PARAM_TYPE = new GmccParamtype(null);
  public static final GmccHealthyDataState GMCC_HEALTHY_DATA_STATE = new GmccHealthyDataState(null);
  public static final GmccRestrain GMCC_RESTRAIN = new GmccRestrain(null);
  public static final GmccIsNormal GMCC_ISNORMAL = new GmccIsNormal(null);
  public static final GmccBusinesstypeOne GMCC_BTYPE_ONE = new GmccBusinesstypeOne(null);
  public static final GmccBusinessTypeTwo GMCC_BTYPE_TWO = new GmccBusinessTypeTwo(null);

  public static final GmccParaLogType GMCC_PARALOG_TYPE = new GmccParaLogType(null);
  public static final PmMonitorTaskLogType PM_MONITORTASK_LOGTYPE = new PmMonitorTaskLogType(null);
  public static final PmMonitorTaskObjType PM_MONITORTASK_OBJTYPE = new PmMonitorTaskObjType(null);
  public static final ColPathTraphType COL_PATHTRAPH_TYPE = new ColPathTraphType(null);
  public static final PerfColType PERF_COL_TYPE = new PerfColType(null);
  public static final ColType COL_TYPE = new ColType(null);
  public static final GmccTopoDirection GMCC_TOPO_DIRECTION = new GmccTopoDirection(null);
  public static final PerformanceUser PERFORMANCE_USER = new PerformanceUser(null);

  public static class VendorOrStander extends GenericEnum
  {
    public static final long _all = 0L;
    public static final long _vendor = 1L;
    public static final long _stander = 2L;

    private VendorOrStander()
    {
      super.putEnum(Long.valueOf(0L), "全部");
      super.putEnum(Long.valueOf(1L), "厂家");
      super.putEnum(Long.valueOf(2L), "标准");
    }
  }

  public static class LimitType extends GenericEnum
  {
    public static final long _all = 0L;
    public static final long _upperlimit = 1L;
    public static final long _lowerlimit = 2L;

    private LimitType()
    {
      super.putEnum(Long.valueOf(0L), "全部");
      super.putEnum(Long.valueOf(1L), "高于门限");
      super.putEnum(Long.valueOf(2L), "低于门限");
    }
  }

  public static class ObjectTypeNew extends GenericEnum
  {
    public static final long _sdh = 1L;
    public static final long _wdm = 2L;

    private ObjectTypeNew()
    {
      super.putEnum(Long.valueOf(1L), "SDH");
      super.putEnum(Long.valueOf(2L), "WDM");
    }
  }

  public static class ObjectType extends GenericEnum
  {
    public static final long _sdhne = 1L;
    public static final long _routeway = 2L;
    public static final long _traph = 3L;
    public static final long _oatmne = 4L;
    public static final long _wdmne = 5L;
    public static final long _sdhneptp = 6L;

    private ObjectType()
    {
      super.putEnum(Long.valueOf(1L), "SDH网元");
      super.putEnum(Long.valueOf(2L), "通道");
      super.putEnum(Long.valueOf(3L), "电路");
      super.putEnum(Long.valueOf(4L), "OADM/OTM网元/OA网元");
      super.putEnum(Long.valueOf(5L), "WDM网元光监控通道");
      super.putEnum(Long.valueOf(6L), "SDH网元端口");
    }
  }

  public static class ColResultFlag extends GenericEnum
  {
    public static final long _success = 1L;
    public static final long _fail = 2L;

    private ColResultFlag()
    {
      super.putEnum(Long.valueOf(1L), "成功");
      super.putEnum(Long.valueOf(2L), "失败");
    }
  }

  public static class TaskStatus extends GenericEnum
  {
    public static final long _notbusy = 1L;
    public static final long _run = 2L;
    public static final long _stop = 3L;
    public static final long _hangup = 4L;

    private TaskStatus()
    {
      super.putEnum(Long.valueOf(1L), "空闲");
      super.putEnum(Long.valueOf(2L), "巡检中");
      super.putEnum(Long.valueOf(3L), "停止");
      super.putEnum(Long.valueOf(4L), "挂起");
    }
  }

  public static class ScopeType extends GenericEnum
  {
    public static final long _site = 1L;
    public static final long _net = 2L;
    public static final long _trans = 3L;
    public static final long _ne = 4L;
    public static final long _ptp = 5L;

    private ScopeType()
    {
      super.putEnum(Long.valueOf(1L), "站点");
      super.putEnum(Long.valueOf(2L), "子网");
      super.putEnum(Long.valueOf(3L), "传输系统");
      super.putEnum(Long.valueOf(4L), "网元");
      super.putEnum(Long.valueOf(5L), "具体对象(端口)");
    }
  }

  public static class AutotestStyle extends GenericEnum
  {
    public static final long _manual = 1L;
    public static final long _auto = 2L;

    private AutotestStyle()
    {
      super.putEnum(Long.valueOf(1L), "手工执行");
      super.putEnum(Long.valueOf(2L), "自动周期执行");
    }
  }

  public static class DayEnum extends GenericEnum
  {
    public static final long _monday = 1L;
    public static final long _tuesday = 2L;
    public static final long _wednesday = 3L;
    public static final long _thursday = 4L;
    public static final long _friday = 5L;
    public static final long _saturday = 6L;
    public static final long _sunday = 7L;

    private DayEnum()
    {
      super.putEnum(Long.valueOf(1L), "星期一");
      super.putEnum(Long.valueOf(2L), "星期二");
      super.putEnum(Long.valueOf(3L), "星期三");
      super.putEnum(Long.valueOf(4L), "星期四");
      super.putEnum(Long.valueOf(5L), "星期五");
      super.putEnum(Long.valueOf(6L), "星期六");
      super.putEnum(Long.valueOf(7L), "星期日");
    }
  }

  public static class AutotestCycle extends GenericEnum
  {
    public static final long _day = 1L;
    public static final long _week = 2L;
    public static final long _month = 3L;
    public static final long _quarter = 4L;
    public static final long _halfyear = 5L;
    public static final long _year = 6L;

    private AutotestCycle()
    {
      super.putEnum(Long.valueOf(1L), "日");
      super.putEnum(Long.valueOf(2L), "周");
      super.putEnum(Long.valueOf(3L), "月");
      super.putEnum(Long.valueOf(4L), "季");
      super.putEnum(Long.valueOf(5L), "半年");
      super.putEnum(Long.valueOf(6L), "年");
    }
  }

  public static class PlanType extends GenericEnum
  {
    public static final long _week = 1L;
    public static final long _month = 2L;

    private PlanType()
    {
      super.putEnum(Long.valueOf(1L), "周计划");
      super.putEnum(Long.valueOf(2L), "月计划");
    }
  }

  public static class ActiveFlagType extends GenericEnum
  {
    public static final long _active = 1L;
    public static final long _passivate = 2L;

    private ActiveFlagType()
    {
      super.putEnum(Long.valueOf(1L), "激活");
      super.putEnum(Long.valueOf(2L), "挂起");
    }
  }

  public static class CollectFlag extends GenericEnum
  {
    public static final long _equipnaturalcoll = 1L;
    public static final long _dquipcomplecoll = 2L;
    public static final long _cirnaturalcoll = 3L;
    public static final long _circomplecoll = 4L;

    private CollectFlag()
    {
      super.putEnum(Long.valueOf(1L), "设备点正常采集");
      super.putEnum(Long.valueOf(2L), "设备点补采");
      super.putEnum(Long.valueOf(3L), "电路正常采集");
      super.putEnum(Long.valueOf(4L), "电路补采");
    }
  }

  public static class MonitorCycle extends GenericEnum
  {
    public static final long _15mi = 1L;
    public static final long _24hh = 2L;

    private MonitorCycle()
    {
      super.putEnum(Long.valueOf(1L), "15分钟");
      super.putEnum(Long.valueOf(2L), "24小时");
    }
  }

  public static class FarOrNear extends GenericEnum
  {
    public static final long _nearget = 1L;
    public static final long _farget = 2L;
    public static final long _nearsend = 3L;
    public static final long _farsend = 4L;
    public static final long _inout = 5L;

    private FarOrNear()
    {
      super.putEnum(Long.valueOf(1L), "近端收");
      super.putEnum(Long.valueOf(2L), "远端收");
      super.putEnum(Long.valueOf(3L), "近端发");
      super.putEnum(Long.valueOf(4L), "远端发");
      super.putEnum(Long.valueOf(5L), "双向");
    }
  }

  public static class GmccPortProp extends GenericEnum
  {
    public static final long ELEC_PORT = 1L;
    public static final long LIGHT_PORT = 2L;
    public static final long MSTP_PORT = 3L;

    private GmccPortProp()
    {
      super.putEnum(Long.valueOf(1L), "电口");
      super.putEnum(Long.valueOf(2L), "光口");
      super.putEnum(Long.valueOf(3L), "MSTP口");
    }
  }

  public static class GmccPortType extends GenericEnum
  {
    public static final long _line = 1L;
    public static final long _brunch = 2L;

    private GmccPortType()
    {
      super.putEnum(Long.valueOf(1L), "群路口");
      super.putEnum(Long.valueOf(2L), "支路口");
    }
  }

  public static class GmccScopeType extends GenericEnum
  {
    public static final long _ems = 6L;
    public static final long _net = 2L;
    public static final long _trans = 3L;
    public static final long _ne = 4L;
    public static final long _traph = 7L;
    public static final long _ptp = 5L;

    private GmccScopeType()
    {
      super.putEnum(Long.valueOf(6L), "EMS");
      super.putEnum(Long.valueOf(2L), "子网");
      super.putEnum(Long.valueOf(3L), "传输系统");
      super.putEnum(Long.valueOf(4L), "网元");
      super.putEnum(Long.valueOf(7L), "电路");
      super.putEnum(Long.valueOf(5L), "端口");
    }
  }

  public static class GmccInspReportEnum extends GenericEnum
  {
    public static final long _day = 1L;
    public static final long _week = 2L;
    public static final long _month = 3L;
    public static final long _season = 4L;
    public static final long _halfyear = 5L;

    private GmccInspReportEnum()
    {
      super.putEnum(Long.valueOf(1L), "日");
      super.putEnum(Long.valueOf(2L), "周");
      super.putEnum(Long.valueOf(3L), "月");
      super.putEnum(Long.valueOf(4L), "季度");
      super.putEnum(Long.valueOf(5L), "半年");
    }
  }

  public static class GmccOperateTask extends GenericEnum
  {
    public static final long _active = 1L;
    public static final long _hangup = 2L;
    public static final long _modify = 3L;

    private GmccOperateTask()
    {
      super.putEnum(Long.valueOf(1L), "激活");
      super.putEnum(Long.valueOf(2L), "挂起");
      super.putEnum(Long.valueOf(1L), "更新");
    }
  }

  public static class GmccParamtype extends GenericEnum
  {
    public static final long _ggl = 1L;
    public static final long _wm = 2L;
    public static final long _plz = 3L;

    private GmccParamtype()
    {
      super.putEnum(Long.valueOf(1L), "光功率");
      super.putEnum(Long.valueOf(2L), "误码");
      super.putEnum(Long.valueOf(3L), "偏流值");
    }
  }

  public static class GmccHealthyDataState extends GenericEnum
  {
    public static final long _notexec = 1L;
    public static final long _notcommit = 2L;
    public static final long _commited = 3L;
    public static final long _controlled = 4L;
    public static final long _closed = 5L;
    public static final long _normal = 6L;

    private GmccHealthyDataState()
    {
      super.putEnum(Long.valueOf(1L), "未执行");
      super.putEnum(Long.valueOf(2L), "未确认");
      super.putEnum(Long.valueOf(3L), "已确认");
      super.putEnum(Long.valueOf(4L), "已处理");
      super.putEnum(Long.valueOf(5L), "已关闭");
    }
  }

  public static class GmccIsNormal extends GenericEnum
  {
    public static final long _isNormal = 1L;
    public static final long _abNormal = 2L;

    private GmccIsNormal()
    {
      super.putEnum(Long.valueOf(1L), "正常");
      super.putEnum(Long.valueOf(2L), "异常");
    }
  }

  public static class GmccRestrain extends GenericEnum
  {
    public static final long _notRestrained = 1L;
    public static final long _isRestrained = 2L;

    private GmccRestrain()
    {
      super.putEnum(Long.valueOf(1L), "不抑制");
      super.putEnum(Long.valueOf(2L), "抑制");
    }
  }

  public static class GmccBusinessTypeTwo extends GenericEnum
  {
    public static final long _State = 1L;
    public static final long _Province = 2L;
    public static final long _LocalBone = 4L;
    public static final long _LocalAggregate = 5L;
    public static final long _LocalAccess = 6L;
    public static final long _StateTraph = 7L;
    public static final long _ProTraph = 8L;
    public static final long _LocalTraph = 9L;

    private GmccBusinessTypeTwo()
    {
      super.putEnum(Long.valueOf(1L), "一干传输设备");
      super.putEnum(Long.valueOf(2L), "二干传输设备");

      super.putEnum(Long.valueOf(4L), "本地骨干层传输设备");
      super.putEnum(Long.valueOf(5L), "本地汇聚层传输设备");
      super.putEnum(Long.valueOf(6L), "本地接入层传输设备");
      super.putEnum(Long.valueOf(7L), "一干传输电路");
      super.putEnum(Long.valueOf(8L), "二干传输电路");
      super.putEnum(Long.valueOf(9L), "本地传输电路");
    }
  }

  public static class GmccBusinesstypeOne extends GenericEnum
  {
    public static final long _tnms = 1L;

    private GmccBusinesstypeOne()
    {
      super.putEnum(Long.valueOf(1L), "传输网");
    }
  }

  public static class GmccParaLogType extends GenericEnum
  {
    public static final long _cardParam = 1L;
    public static final long _benchMark = 2L;
    public static final long _inspLimit = 3L;
    public static final long _restrain = 4L;

    private GmccParaLogType()
    {
      super.putEnum(Long.valueOf(1L), "单板光功率");
      super.putEnum(Long.valueOf(2L), "巡检基准值");
      super.putEnum(Long.valueOf(3L), "基准值门限");
      super.putEnum(Long.valueOf(4L), "抑制机制");
    }
  }

  public static class PmMonitorTaskLogType extends GenericEnum
  {
    public static final long _success = 1L;
    public static final long _fail = 2L;
    public static final long _recol = 3L;

    private PmMonitorTaskLogType()
    {
      super.putEnum(Long.valueOf(1L), "成功");
      super.putEnum(Long.valueOf(2L), "失败");
      super.putEnum(Long.valueOf(3L), "补采成功");
    }
  }

  public static class PmMonitorTaskObjType extends GenericEnum
  {
    public static final long _ne = 1L;
    public static final long _card = 2L;
    public static final long _ptp = 3L;
    public static final long _ctp = 4L;
    public static final long _path = 5L;
    public static final long _traph = 6L;
    public static final long _route = 7L;

    private PmMonitorTaskObjType()
    {
      super.putEnum(Long.valueOf(1L), "网元");
      super.putEnum(Long.valueOf(2L), "盘");
      super.putEnum(Long.valueOf(3L), "端口");
      super.putEnum(Long.valueOf(4L), "时隙");
      super.putEnum(Long.valueOf(5L), "通道");
      super.putEnum(Long.valueOf(6L), "电路");
      super.putEnum(Long.valueOf(7L), "路由");
    }
  }

  public static class ColPathTraphType extends GenericEnum
  {
    public static final long _samerate = 1L;
    public static final long _all = 2L;

    private ColPathTraphType()
    {
      super.putEnum(Long.valueOf(1L), "同速率端口");
      super.putEnum(Long.valueOf(2L), "全程路由端口");
    }
  }

  public static class ColType extends GenericEnum
  {
    public static final long _cur = 1L;
    public static final long _his = 2L;
    public static final long _recol = 3L;
    public static final long _other = 4L;

    private ColType()
    {
      super.putEnum(Long.valueOf(1L), "当前性能");
      super.putEnum(Long.valueOf(2L), "历史性能");
      super.putEnum(Long.valueOf(3L), "补采");
      super.putEnum(Long.valueOf(4L), "其他模块");
    }
  }

  public static class PerfColType extends GenericEnum
  {
    public static final long _cur = 1L;
    public static final long _his = 2L;

    private PerfColType()
    {
      super.putEnum(Long.valueOf(1L), "当前性能");
      super.putEnum(Long.valueOf(2L), "历史性能");
    }
  }

  public static class GmccTopoDirection extends GenericEnum
  {
    public static final long _in = 1L;
    public static final long _out = 2L;

    private GmccTopoDirection()
    {
      super.putEnum(Long.valueOf(1L), "IN");
      super.putEnum(Long.valueOf(2L), "OUT");
    }
  }

  public static class PerformanceUser extends GenericEnum
  {
    public static final long _normal = 1L;
    public static final long _super = 2L;

    private PerformanceUser()
    {
      super.putEnum(Long.valueOf(1L), "NORMAL");
      super.putEnum(Long.valueOf(2L), "SUPER");
    }
  }
}