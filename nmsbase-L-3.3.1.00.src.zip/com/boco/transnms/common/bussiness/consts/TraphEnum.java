package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class TraphEnum
{
  public static final SwitchPortRate SWITCHPORT_RATE = new SwitchPortRate(null);
  public static final TraphRate TRAPH_RATE = new TraphRate(null);
  public static final TraphExt TRAPH_EXT = new TraphExt(null);
  public static final TraphOwnership TRAPH_OWNERSHIP = new TraphOwnership(null);
  public static final UseType USETYPE = new UseType(null);
  public static final TraphLevel TRAPH_LEVEL = new TraphLevel(null);
  public static final SelfTraphType SELF_TRAPH_TYPE = new SelfTraphType(null);
  public static final protectMode PROTECT_MODE = new protectMode(null);
  public static final TraphType TRAPH_TYPE = new TraphType(null);

  public static final LoadType LOAD_TYPE = new LoadType(null);
  public static final endStationType END_STATION_TYPE = new endStationType();
  public static final TraphLeaseType TRAPH_LEASE_TYPE = new TraphLeaseType(null);
  public static final TraphImportLevelForSH TRAPH_IMPORT_LEVEL = new TraphImportLevelForSH(null);

  public static final TraphNameRule TRAPH_NAME_RULE = new TraphNameRule(null);
  public static final TraphKind TRAPH_KIND = new TraphKind(null);
  public static final TraphTerm TRAPH_TERM = new TraphTerm();
  public static final pathMatchState PATHMATCH_STATE = new pathMatchState();
  public static final scheduleState SCHEDULE_STATE = new scheduleState();
  public static final importantPortect IMPORTANT_PROTECT = new importantPortect();
  public static final ModifyType MODIFY_TYPE = new ModifyType();
  public static final TraphState TRAPH_STATE = new TraphState(null);
  public static final JumpType JUMP_TYPE = new JumpType();
  public static final JumpPairState JUMP_PAIR_STATE = new JumpPairState();

  public static final TraphServiceTypeLabelColor TRAPH_SERVICE_TYPE_LABEL_COLOR = new TraphServiceTypeLabelColor();

  public static final TraphSwitchImportCol TRAPH_SWITCH_IMPORT_COL = new TraphSwitchImportCol();

  public static final TraphRelatedSiteRule TRAPH_RELATED_SITE_RULE = new TraphRelatedSiteRule();
  public static final TraphThread TRAPH_THREAD = new TraphThread();
  public static final DfOperatorType DF_OPERATOR_TYPE = new DfOperatorType();

  public static final SystemType SYSTEM_TYPE = new SystemType();
  public static final ExcelImportType EXCEL_IMPORT_TYPE = new ExcelImportType(null);
  public static final ExcelImportErrorType EXCEL_IMPORT_ERROR_TYPE = new ExcelImportErrorType(null);
  public static final UrgentType URGENT_TYPE = new UrgentType(null);
  public static final QueryType QUERY_TYPE = new QueryType(null);
  public static final BackUpTaskState BACKUP_TASK_STATE = new BackUpTaskState(null);
  public static final UsedState USED_STATE = new UsedState(null);
  public static final UsedType USED_TYPE = new UsedType(null);

  public static final SpecialLineType SPECIAL_LINE_TYPE = new SpecialLineType(null);
  public static final SpecialLineState SPECIAL_LINE_STATE = new SpecialLineState(null);
  public static final CustomerProperty CUSTOMER_PROPERTY = new CustomerProperty(null);
  public static final GlInterState GL_INF_STATE = new GlInterState();
  public static final SdhMstpTraphType SDH_MSTP_TRAPH_TYPE = new SdhMstpTraphType(null);
  public static final CMSdhMstpTraphType CM_SDH_MSTP_TRAPH_TYPE = new CMSdhMstpTraphType(null);
  public static final NetWorkTraphType NET_WORK_TRAPH_TYPE = new NetWorkTraphType(null);
  public static final InputType INPUT_TYPE = new InputType(null);
  public static final UseTypeSH USE_TYPE_SH = new UseTypeSH(null);
  public static final OwnershipSH OWNERSHIP_SH = new OwnershipSH(null);
  public static final AttempSheetTraphType ATTEMP_SHEET_TRAPH_TYPE = new AttempSheetTraphType(null);

  public static class SpecialLineType extends GenericEnum
  {
    public static final long _CMNET = 1L;
    public static final long _CL = 2L;
    public static final long _VOICE = 3L;

    private SpecialLineType()
    {
      super.putEnum(Long.valueOf(1L), "CMNET（CMNET专线）");
      super.putEnum(Long.valueOf(2L), "CL（电路出租专线）");
      super.putEnum(Long.valueOf(3L), "VOICE（语音专线）");
    }
  }

  public static class CustomerProperty extends GenericEnum
  {
    public static final long _army = 1L;
    public static final long _across = 2L;
    public static final long _live = 3L;
    public static final long _partner = 4L;
    public static final long _custom = 5L;

    private CustomerProperty()
    {
      super.putEnum(Long.valueOf(1L), "党政军");
      super.putEnum(Long.valueOf(2L), "跨国跨省");
      super.putEnum(Long.valueOf(3L), "国计民生");
      super.putEnum(Long.valueOf(4L), "业务合作方");
      super.putEnum(Long.valueOf(5L), "普通客户");
    }
  }

  public static class SpecialLineState extends GenericEnum
  {
    public static final long _open = 1L;
    public static final long _pause = 2L;
    public static final long _close = 3L;

    private SpecialLineState()
    {
      super.putEnum(Long.valueOf(1L), "开启");
      super.putEnum(Long.valueOf(2L), "暂停");
      super.putEnum(Long.valueOf(3L), "关闭");
    }
  }

  public static class UsedType extends GenericEnum
  {
    public static final long L1 = 1L;
    public static final long L2 = 2L;

    private UsedType()
    {
      super.putEnum(Long.valueOf(1L), "静态");
      super.putEnum(Long.valueOf(2L), "动态");
    }
  }

  public static class UsedState extends GenericEnum
  {
    public static final long L1 = 1L;
    public static final long L2 = 2L;
    public static final long L3 = 3L;
    public static final long L4 = 4L;

    private UsedState()
    {
      super.putEnum(Long.valueOf(1L), "已分配且使用");
      super.putEnum(Long.valueOf(2L), "再次分配");
      super.putEnum(Long.valueOf(3L), "预留");
      super.putEnum(Long.valueOf(4L), "自带IP");
    }
  }

  public static class BackUpTaskState extends GenericEnum
  {
    public static final long _PRE = 1L;
    public static final long _BACKUP = 2L;
    public static final long _FINISH = 3L;
    public static final long _EXCEPTION = 4L;

    private BackUpTaskState()
    {
      super.putEnum(Long.valueOf(1L), "准备");
      super.putEnum(Long.valueOf(2L), "同步中");
      super.putEnum(Long.valueOf(3L), "结束");
      super.putEnum(Long.valueOf(4L), "异常");
    }
  }

  public static class QueryType extends GenericEnum
  {
    public static final long _Q1 = 1L;
    public static final long _Q2 = 2L;
    public static final long _Q3 = 3L;
    public static final long _Q4 = 4L;
    public static final long _ALL_TRAPH_QUERY = 5L;
    public static final long _GZ_QUERY = 6L;
    public static final long _TOPO_QUERY = 7L;
    public static final long _ONEKEY_MONITOR = 8L;

    private QueryType()
    {
      super.putEnum(Long.valueOf(1L), "电路复杂查询");
      super.putEnum(Long.valueOf(2L), "通道复杂查询");
      super.putEnum(Long.valueOf(3L), "调度系统电路复杂查询");
      super.putEnum(Long.valueOf(4L), "电路统计");
      super.putEnum(Long.valueOf(5L), "全网电路查询");
      super.putEnum(Long.valueOf(6L), "高转查询");
      super.putEnum(Long.valueOf(7L), "拓扑查询");
      super.putEnum(Long.valueOf(8L), "一键监控");
    }
  }

  public static class UrgentType extends GenericEnum
  {
    public static final long _L1 = 1L;
    public static final long _L2 = 2L;
    public static final long _L3 = 3L;

    private UrgentType()
    {
      super.putEnum(Long.valueOf(1L), "特急");
      super.putEnum(Long.valueOf(2L), "紧急");
      super.putEnum(Long.valueOf(3L), "一般");
    }
  }

  public static class ExcelImportErrorType extends GenericEnum
  {
    public static final int _labelCnError = 1;
    public static final int _noError = 2;
    public static final int _endStationTypeAError = 3;
    public static final int _relatedAEndStationCuidError = 4;
    public static final int _relatedASiteError = 5;
    public static final int _endStationTypeZError = 6;
    public static final int _relatedZEndStationCuidError = 7;
    public static final int _relatedZSiteError = 8;
    public static final int _aliasError = 9;
    public static final int _notesError = 10;
    public static final int _extIdsError = 11;
    public static final int _traphRateError = 12;
    public static final int _relatedUserError = 13;
    public static final int _jhroomAError = 14;
    public static final int _relatedAEndSwitchdevError = 15;
    public static final int _relatedAEndSwitchPortError = 16;
    public static final int _endSwitchDfPortAError = 17;
    public static final int _zjdfAError = 18;
    public static final int _sdxc1AError = 19;
    public static final int _sdxc2AError = 20;
    public static final int _extpath1AError = 21;
    public static final int _jhroomZError = 22;
    public static final int _relatedZEndSwitchdevError = 23;
    public static final int _relatedZEndSwitchPortError = 24;
    public static final int _endSwitchDfPortZError = 25;
    public static final int _zjdfZError = 26;
    public static final int _sdxc1ZError = 27;
    public static final int _sdxc2ZError = 28;
    public static final int _extpath1ZError = 29;
    public static final int _traphTypeError = 30;
    public static final int _traphLevelError = 31;
    public static final int _importLevelError = 32;
    public static final int _ownershipError = 33;
    public static final int _usedDateError = 34;
    public static final int _requestDateError = 35;
    public static final int _useTypeError = 36;
    public static final int _dispatchNameError = 37;
    public static final int _longDistanceTraphNameError = 38;
    public static final int _customerNameError = 39;
    public static final int _businessDiscussedTraphNameError = 40;
    public static final int _isPriorityMonitorsTraphError = 41;
    public static final int _remarkError = 42;
    public static final int _routeSegTypeError = 43;
    public static final int _routeSegNameError = 44;
    public static final int _rentNameError = 45;
    public static final int _zdSiteTypeAError = 46;
    public static final int _relatedAZdSiteCuidError = 47;
    public static final int _relatedAZdSiteError = 48;
    public static final int _relatedNeAError = 49;
    public static final int _endPortAError = 50;
    public static final int _endCtpAError = 51;
    public static final int _zdSiteTypeZError = 52;
    public static final int _relatedZZdSiteCuidError = 53;
    public static final int _relatedZZdSiteError = 54;
    public static final int _relatedNeZError = 55;
    public static final int _endPortZError = 56;
    public static final int _endCtpZError = 57;
    public static final int _traphNameAdjustError = 58;
    public static final int _dcmeError = 59;
    public static final int _leaseTypeError = 60;
    public static final int _yuanError = 61;
    public static final int _dollarsError = 62;
    public static final int _termError = 63;
    public static final int _endOperatorError = 64;
    public static final int _cableError = 65;
    public static final int _zjTypeError = 66;
    public static final int _labelCnExistError = 67;
    public static final int _labelCnNotExistError = 68;
    public static final int _saveError = 69;
    public static final int _saveExceptionError = 70;
    public static final int _calTraphBasicAndRouteError = 71;
    public static final int _mstpTraphRateError = 72;
    public static final int _relatedAEndStationCuidNotExistError = 73;
    public static final int _relatedZEndStationCuidNotExistError = 74;
    public static final int _noExistError = 75;
    public static final int _termIsNullError = 76;
    public static final int _calTraphBasicError = 77;
    public static final int _relatedUserNotExistError = 78;
    public static final int _relatedAEndSwitchdevNotFoundError = 79;
    public static final int _relatedZEndSwitchdevNotFoundError = 80;
    public static final int _relatedAEndSwitchdevNotFoundRoomError = 81;
    public static final int _relatedZEndSwitchdevNotFoundRoomError = 82;
    public static final int _routeIsNotFullError = 83;
    public static final int _zjSiteNotExistError = 84;
    public static final int _endPortANotExistError = 85;
    public static final int _endPortZNotExistError = 86;
    public static final int _endPortAIsBadError = 87;
    public static final int _endPortZIsBadError = 88;
    public static final int _calTraphRouteError = 89;
    public static final int _rentNameAndOperatorIsNullError = 90;
    public static final int _endPortAAndEndPortZIsNullError = 91;
    public static final int _haveCtpNotPtpError = 92;
    public static final int _endCtpAAndEndCtpZIsNullError = 93;
    public static final int _haveMoreTransPathError = 94;
    public static final int _useByLowRateTraphError = 95;
    public static final int _useByTraphError = 96;
    public static final int _transPathRateLowError = 97;
    public static final int _endPortAUsedError = 98;
    public static final int _endPortZUsedError = 99;
    public static final int _transPathCtpRateError = 100;
    public static final int _roomAIsNotExistError = 101;
    public static final int _roomZIsNotExistError = 102;
    public static final int _roomASiteIsNotExistError = 103;
    public static final int _roomZSiteIsNotExistError = 104;
    public static final int _neASiteIsNotExistError = 105;
    public static final int _neZSiteIsNotExistError = 106;
    public static final int _roomIsNotExistError = 107;
    public static final int _roomSiteIsNotExistError = 108;
    public static final int _neSiteIsNotExistError = 109;
    public static final int _neIsNotExistError = 110;
    public static final int _zdSiteTypeError = 111;
    public static final int _importantProtectNotModifyError = 112;
    public static final int _modifyError = 113;
    public static final int _bandWidthNotExistError = 114;
    public static final int _macIndexNotExistError = 115;
    public static final int _macRouteIndexNotExistError = 116;
    public static final int _macANotExistError = 117;
    public static final int _macZNotExistError = 118;
    public static final int _mpANotExistError = 119;
    public static final int _mpZNotExistError = 120;
    public static final int _macMpANotSameNeError = 121;
    public static final int _macMpZNotSameNeError = 122;
    public static final int _mstpChannelNotExistError = 123;
    public static final int _zjSiteNotSameError = 124;
    public static final int _macARelatedNeNotExistError = 125;
    public static final int _macZRelatedNeNotExistError = 126;
    public static final int _mpARelatedNeNotExistError = 127;
    public static final int _mpZRelatedNeNotExistError = 128;
    public static final int _macMpASiteNotExistError = 129;
    public static final int _macMpZSiteNotExistError = 130;
    public static final int _macMpVlanidAZSameError = 131;
    public static final int _macMpVlanidAUsedError = 132;
    public static final int _macMpVlanidZUsedError = 133;
    public static final int _switchSameError = 134;
    public static final int _noCtpANotExistError = 135;
    public static final int _noCtpZNotExistError = 136;
    public static final int _rentUserMoreOne = 137;
    public static final int _noTransPath = 138;
    public static final int _noExtTypeExist = 139;
    public static final int _ExtTypeError = 140;

    private ExcelImportErrorType()
    {
      super.putEnum(Integer.valueOf(1), "电路名称错误");
      super.putEnum(Integer.valueOf(2), "电路编号错误");
      super.putEnum(Integer.valueOf(3), "A端通达地点类型错误");
      super.putEnum(Integer.valueOf(4), "A端通达地点错误");
      super.putEnum(Integer.valueOf(5), "A端通达地点所属站点错误");
      super.putEnum(Integer.valueOf(6), "Z端通达地点类型错误");
      super.putEnum(Integer.valueOf(7), "Z端通达地点错误");
      super.putEnum(Integer.valueOf(8), "Z端通达地点所属站点错误");
      super.putEnum(Integer.valueOf(9), "电路别名错误");
      super.putEnum(Integer.valueOf(10), "电路名称备注错误");
      super.putEnum(Integer.valueOf(11), "业务类型错误");
      super.putEnum(Integer.valueOf(12), "速率错误");
      super.putEnum(Integer.valueOf(13), "用户错误");
      super.putEnum(Integer.valueOf(14), "A端业务机房错误");
      super.putEnum(Integer.valueOf(15), "A端业务设备错误");
      super.putEnum(Integer.valueOf(16), "A端业务设备端口已被使用或预占错误");
      super.putEnum(Integer.valueOf(17), "A端业务配线架错误");
      super.putEnum(Integer.valueOf(18), "A端转接配线架错误");
      super.putEnum(Integer.valueOf(19), "A端SDXC1错误");
      super.putEnum(Integer.valueOf(20), "A端SDXC2错误");
      super.putEnum(Integer.valueOf(21), "A端延伸路由错误");
      super.putEnum(Integer.valueOf(22), "Z端业务机房错误");
      super.putEnum(Integer.valueOf(23), "Z端业务设备错误");
      super.putEnum(Integer.valueOf(24), "Z端业务设备端口已被使用或预占错误");
      super.putEnum(Integer.valueOf(25), "Z端业务配线架端子错误");
      super.putEnum(Integer.valueOf(26), "Z端转接配线架端子错误");
      super.putEnum(Integer.valueOf(27), "Z端SDXC1错误");
      super.putEnum(Integer.valueOf(28), "Z端SDXC2错误");
      super.putEnum(Integer.valueOf(29), "Z端延伸路由错误");
      super.putEnum(Integer.valueOf(30), "电路类型错误");
      super.putEnum(Integer.valueOf(31), "电路级别错误");
      super.putEnum(Integer.valueOf(32), "重要性级别错误");
      super.putEnum(Integer.valueOf(33), "产权错误");
      super.putEnum(Integer.valueOf(34), "开通日期时间格式或Excel该列单元格格式没有设置成文本格式");
      super.putEnum(Integer.valueOf(35), "要求开通时间格式或Excel该列单元格格式没有设置成文本格式");
      super.putEnum(Integer.valueOf(36), "电路用途错误");
      super.putEnum(Integer.valueOf(37), "调单号错误");
      super.putEnum(Integer.valueOf(38), "长途电路名称错误");
      super.putEnum(Integer.valueOf(39), "客户电路名称错误");
      super.putEnum(Integer.valueOf(40), "运营商电路命名称错误");
      super.putEnum(Integer.valueOf(41), "是否为重点监控电路错误");
      super.putEnum(Integer.valueOf(42), "备注错误");
      super.putEnum(Integer.valueOf(43), "路由段类型错误");
      super.putEnum(Integer.valueOf(44), "路由段名称错误");
      super.putEnum(Integer.valueOf(45), "出租方错误");
      super.putEnum(Integer.valueOf(46), "A端终端点类型错误");
      super.putEnum(Integer.valueOf(47), "A端终端点错误");
      super.putEnum(Integer.valueOf(48), "A端终端点所属站点错误");
      super.putEnum(Integer.valueOf(49), "A端传输设备错误");
      super.putEnum(Integer.valueOf(50), "A端传输设备端口错误");
      super.putEnum(Integer.valueOf(51), "A端时隙错误");
      super.putEnum(Integer.valueOf(52), "Z端终端点类型错误");
      super.putEnum(Integer.valueOf(53), "Z端终端点错误");
      super.putEnum(Integer.valueOf(54), "Z端终端点所属站点错误");
      super.putEnum(Integer.valueOf(55), "Z端传输设备错误");
      super.putEnum(Integer.valueOf(56), "Z端传输设备端口错误");
      super.putEnum(Integer.valueOf(57), "Z端时隙错误");
      super.putEnum(Integer.valueOf(58), "调后电路名称错误");
      super.putEnum(Integer.valueOf(59), "DCME压缩比率错误");
      super.putEnum(Integer.valueOf(60), "租用类型错误");
      super.putEnum(Integer.valueOf(61), "人民币错误");
      super.putEnum(Integer.valueOf(62), "美元错误");
      super.putEnum(Integer.valueOf(63), "租期错误");
      super.putEnum(Integer.valueOf(64), "对端运营商错误");
      super.putEnum(Integer.valueOf(65), "光缆国际段错误");
      super.putEnum(Integer.valueOf(66), "转接类型错误");

      super.putEnum(Integer.valueOf(67), "电路名称已经存在");
      super.putEnum(Integer.valueOf(68), "电路名称不存在");
      super.putEnum(Integer.valueOf(69), "保存电路出错");
      super.putEnum(Integer.valueOf(70), "保存电路异常");
      super.putEnum(Integer.valueOf(71), "计算电路基本信息，电路路由出错");
      super.putEnum(Integer.valueOf(72), "MSTP电路速率错误");
      super.putEnum(Integer.valueOf(73), "A端通达地点不存在");
      super.putEnum(Integer.valueOf(74), "Z端通达地点不存在");
      super.putEnum(Integer.valueOf(75), "电路编号已经存在");
      super.putEnum(Integer.valueOf(76), "租期为空");
      super.putEnum(Integer.valueOf(77), "计算电路基本信息出错");
      super.putEnum(Integer.valueOf(78), "用户不存在");
      super.putEnum(Integer.valueOf(79), "A端业务设备没有找到");
      super.putEnum(Integer.valueOf(80), "Z端业务设备没有找到");
      super.putEnum(Integer.valueOf(81), "A端业务设备找不到业务机房");
      super.putEnum(Integer.valueOf(82), "Z端业务设备找不到业务机房");
      super.putEnum(Integer.valueOf(83), "A电路终端信息只填了一端，路由信息不完整");
      super.putEnum(Integer.valueOf(84), "转接站点不存在");
      super.putEnum(Integer.valueOf(85), "A端传输端口不存在");
      super.putEnum(Integer.valueOf(86), "Z端传输端口不存在");
      super.putEnum(Integer.valueOf(87), "A端传输端口损坏");
      super.putEnum(Integer.valueOf(88), "Z端传输端口损坏");
      super.putEnum(Integer.valueOf(89), "计算电路路由出错");
      super.putEnum(Integer.valueOf(90), "国际电路的出租方或对端运营商必须有一个填写");
      super.putEnum(Integer.valueOf(91), "至少录入通道一端的传输设备端口信息");
      super.putEnum(Integer.valueOf(92), "有时隙信息而没有相应的端口信息");
      super.putEnum(Integer.valueOf(93), "至少录入通道一端时隙的信息");
      super.putEnum(Integer.valueOf(94), "查询的得到的通道存在多条");
      super.putEnum(Integer.valueOf(95), "查询得到的通道已经被低速率电路占满");
      super.putEnum(Integer.valueOf(96), "查询得到的通道已经被占用");
      super.putEnum(Integer.valueOf(97), "通道的速率低于电路速率");
      super.putEnum(Integer.valueOf(98), "A时隙已经被占用");
      super.putEnum(Integer.valueOf(99), "Z时隙已经被占用");
      super.putEnum(Integer.valueOf(100), "通道不能正确占用资源，请将一端CTP选择到与电路等速率或高于电路速率");
      super.putEnum(Integer.valueOf(101), "A端机房不存在");
      super.putEnum(Integer.valueOf(102), "Z端机房不存在");
      super.putEnum(Integer.valueOf(103), "A端机房所属站点不存在");
      super.putEnum(Integer.valueOf(105), "Z端网元所属站点不存在");
      super.putEnum(Integer.valueOf(106), "A端网元所属站点不存在");
      super.putEnum(Integer.valueOf(107), "机房不存在");
      super.putEnum(Integer.valueOf(108), "机房所属站点不存在");
      super.putEnum(Integer.valueOf(109), "网元所属站点不存在");
      super.putEnum(Integer.valueOf(110), "网元不存在");
      super.putEnum(Integer.valueOf(111), "终端类型没有选择或类型不正确");
      super.putEnum(Integer.valueOf(112), "重保电路不能修改");
      super.putEnum(Integer.valueOf(113), "更新失败");

      super.putEnum(Integer.valueOf(114), "带宽不存在");
      super.putEnum(Integer.valueOf(115), "MAC段号不存在");
      super.putEnum(Integer.valueOf(116), "路由编号不存在");
      super.putEnum(Integer.valueOf(117), "A端MAC口不存在");
      super.putEnum(Integer.valueOf(118), "Z端MAC口不存在");
      super.putEnum(Integer.valueOf(119), "A端VCTRUNK口不存在");
      super.putEnum(Integer.valueOf(120), "Z端VCTRUNK口不存在");
      super.putEnum(Integer.valueOf(121), "A端MAC口和A端VCTRUNK口不属于同一个网元");
      super.putEnum(Integer.valueOf(122), "Z端MAC口和Z端VCTRUNK口不属于同一个网元");
      super.putEnum(Integer.valueOf(123), "MSTP通道不存在");
      super.putEnum(Integer.valueOf(124), "转接站点与前面一段不一致");
      super.putEnum(Integer.valueOf(125), "A端MAC口所在网元不存在");
      super.putEnum(Integer.valueOf(126), "Z端MAC口所在网元不存在");
      super.putEnum(Integer.valueOf(127), "A端Vctrunk口所在网元不存在");
      super.putEnum(Integer.valueOf(128), "Z端Vctrunk口所在网元不存在");
      super.putEnum(Integer.valueOf(129), "A端MAC口和Vctrunk口不属于A端终端站点");
      super.putEnum(Integer.valueOf(130), "Z端MAC口和Vctrunk口不属于Z端终端站点");
      super.putEnum(Integer.valueOf(131), "A、Z端MAC口、Vctrunk口、VLANID相同");
      super.putEnum(Integer.valueOf(132), "A端MAC口,Vctrunk口,VLANID已经被占用");
      super.putEnum(Integer.valueOf(133), "Z端MAC口,Vctrunk口,VLANID已经被占用");
      super.putEnum(Integer.valueOf(134), "业务设备端口不能相同");
      super.putEnum(Integer.valueOf(135), "A端口下没有对应的该时隙信息");
      super.putEnum(Integer.valueOf(136), "Z端口下没有对应的该时隙信息");
      super.putEnum(Integer.valueOf(137), "出租电路，用户只能有一个");
      super.putEnum(Integer.valueOf(138), "没有找到对应的通道");
      super.putEnum(Integer.valueOf(139), "承载方式必填，不能为空");
      super.putEnum(Integer.valueOf(140), "承载方式必须是SDH、MSTP、WDM、OTN、PTN，请检查承载方式内容");
    }
  }

  public static class ExcelImportType extends GenericEnum
  {
    public static final int _In = 1;
    public static final int _Out = 2;

    private ExcelImportType()
    {
      super.putEnum(Integer.valueOf(1), "内部接口");
      super.putEnum(Integer.valueOf(2), "外部接口");
    }
  }

  public static class TraphLeaseType extends GenericEnum
  {
    public static final long _L1 = 1L;
    public static final long _L2 = 2L;

    private TraphLeaseType()
    {
      super.putEnum(Long.valueOf(1L), "全电路");
      super.putEnum(Long.valueOf(2L), "半电路");
    }
  }

  public static class TraphTerm extends GenericEnum
  {
    public static final long _6months = 6L;
    public static final long _7months = 7L;
    public static final long _8months = 8L;
    public static final long _9months = 9L;
    public static final long _10months = 10L;
    public static final long _11months = 11L;
    public static final long _12months = 12L;
    public static final long _13months = 13L;
    public static final long _14months = 14L;
    public static final long _15months = 15L;
    public static final long _16months = 16L;
    public static final long _17months = 17L;
    public static final long _18months = 18L;
    public static final long _19months = 19L;
    public static final long _20months = 20L;
    public static final long _21months = 21L;
    public static final long _22months = 22L;
    public static final long _23months = 23L;
    public static final long _24months = 24L;
    public static final long _forever = 25L;

    public TraphTerm()
    {
      super.putEnum(Long.valueOf(6L), "6个月");
      super.putEnum(Long.valueOf(7L), "7个月");
      super.putEnum(Long.valueOf(8L), "8个月");
      super.putEnum(Long.valueOf(9L), "9个月");
      super.putEnum(Long.valueOf(10L), "10个月");
      super.putEnum(Long.valueOf(11L), "11个月");
      super.putEnum(Long.valueOf(12L), "12个月");
      super.putEnum(Long.valueOf(13L), "13个月");
      super.putEnum(Long.valueOf(14L), "14个月");
      super.putEnum(Long.valueOf(15L), "15个月");
      super.putEnum(Long.valueOf(16L), "16个月");
      super.putEnum(Long.valueOf(17L), "17个月");
      super.putEnum(Long.valueOf(18L), "18个月");
      super.putEnum(Long.valueOf(19L), "19个月");
      super.putEnum(Long.valueOf(20L), "20个月");
      super.putEnum(Long.valueOf(21L), "21个月");
      super.putEnum(Long.valueOf(22L), "22个月");
      super.putEnum(Long.valueOf(23L), "23个月");
      super.putEnum(Long.valueOf(24L), "24个月");
      super.putEnum(Long.valueOf(25L), "长期");
    }
  }

  public static class DfOperatorType extends GenericEnum
  {
    public static final long _replaceOne = 1L;
    public static final long _splitMiddle = 2L;
    public static final long _extendASide = 3L;
    public static final long _extendZSide = 4L;

    public DfOperatorType()
    {
      super.putEnum(Long.valueOf(1L), "替换一侧");
      super.putEnum(Long.valueOf(2L), "中间拆分");
      super.putEnum(Long.valueOf(3L), "A侧延长");
      super.putEnum(Long.valueOf(4L), "Z侧延长");
    }
  }

  public static class GlInterState extends GenericEnum
  {
    public static final long _noSend = 1L;
    public static final long _sendNoBack = 2L;
    public static final long _sendAndBack = 3L;
    public static final long _sendAndReceive = 4L;

    public GlInterState()
    {
      super.putEnum(Long.valueOf(1L), "未发送");
      super.putEnum(Long.valueOf(2L), "发送成功未收到反馈");
      super.putEnum(Long.valueOf(3L), "发送成功并收到反馈");
      super.putEnum(Long.valueOf(4L), "收到路由信息");
    }
  }

  public static class SystemType extends GenericEnum
  {
    public static final int _tnms = 1;
    public static final int _circuitAttemp = 2;
    public static final int _optAttemp = 3;
    public static final int _queryAttemp = 4;

    public SystemType()
    {
      super.putEnum(Integer.valueOf(1), "传输网管");
      super.putEnum(Integer.valueOf(2), "电路调度");
      super.putEnum(Integer.valueOf(3), "光路调度");
      super.putEnum(Integer.valueOf(4), "电路查询");
    }
  }

  public static class TraphThread extends GenericEnum
  {
    public static final long _mulAdd = 1L;
    public static final long _mulModify = 2L;
    public static final long _mulDel = 3L;
    public static final long _mulAttAdd = 4L;
    public static final long _mulAttModify = 5L;
    public static final long _mulAttDel = 6L;
    public static final long _mulAttWriteAdd = 7L;
    public static final long _mulAttWriteModify = 8L;
    public static final long _mulAttWriteDel = 9L;

    public TraphThread()
    {
      super.putEnum(Long.valueOf(1L), "电路编辑批量新增");
      super.putEnum(Long.valueOf(2L), "电路编辑批量修改");
      super.putEnum(Long.valueOf(3L), "电路编辑批量删除");
      super.putEnum(Long.valueOf(4L), "电路调度批量新增");
      super.putEnum(Long.valueOf(5L), "电路调度批量修改");
      super.putEnum(Long.valueOf(6L), "电路调度批量删除");
      super.putEnum(Long.valueOf(7L), "电路新增回写");
      super.putEnum(Long.valueOf(8L), "电路调整回写");
      super.putEnum(Long.valueOf(9L), "电路删除回写");
    }
  }

  public static class TraphRelatedSiteRule extends GenericEnum
  {
    public static final long _site = 1L;
    public static final long _room = 2L;
    public static final long _transNE = 3L;
    public static final long _switchNE = 4L;

    public TraphRelatedSiteRule()
    {
      super.putEnum(Long.valueOf(1L), "站点");
      super.putEnum(Long.valueOf(2L), "机房");
      super.putEnum(Long.valueOf(3L), "网元");
      super.putEnum(Long.valueOf(4L), "业务网元");
    }
  }

  public static class TraphSwitchImportCol extends GenericEnum
  {
    public static final int _roomA = 0;
    public static final int _devA = 1;
    public static final int _portA = 2;
    public static final int _sdxc1A = 3;
    public static final int _sdxc2A = 4;
    public static final int _dfPortA = 5;
    public static final int _extPathA = 6;
    public static final int _zjPortA = 7;
    public static final int _linkManA = 8;
    public static final int _roomZ = 9;
    public static final int _devZ = 10;
    public static final int _portZ = 11;
    public static final int _sdxc1Z = 12;
    public static final int _sdxc2Z = 13;
    public static final int _dfPortZ = 14;
    public static final int _extPathZ = 15;
    public static final int _zjPortZ = 16;
    public static final int _linkManZ = 17;

    public TraphSwitchImportCol()
    {
      super.putEnum(Integer.valueOf(0), "A端业务机房");
      super.putEnum(Integer.valueOf(1), "A端业务设备");
      super.putEnum(Integer.valueOf(2), "A端业务设备端口");
      super.putEnum(Integer.valueOf(3), "A端SDXC1");
      super.putEnum(Integer.valueOf(4), "A端SDXC2");
      super.putEnum(Integer.valueOf(5), "A端业务配线架");
      super.putEnum(Integer.valueOf(6), "A端延伸段路由");
      super.putEnum(Integer.valueOf(7), "A端转接配线架");
      super.putEnum(Integer.valueOf(8), "A端客户经理信息");
      super.putEnum(Integer.valueOf(9), "Z端业务机房");
      super.putEnum(Integer.valueOf(10), "Z端业务设备");
      super.putEnum(Integer.valueOf(11), "Z端业务设备端口");
      super.putEnum(Integer.valueOf(12), "Z端SDXC1");
      super.putEnum(Integer.valueOf(13), "Z端SDXC2");
      super.putEnum(Integer.valueOf(14), "Z端业务配线架");
      super.putEnum(Integer.valueOf(15), "Z端延伸段路由");
      super.putEnum(Integer.valueOf(16), "Z端转接配线架");
      super.putEnum(Integer.valueOf(17), "Z端客户经理信息");
    }
  }

  public static class JumpPairState extends GenericEnum
  {
    public static final long _unlink = 1L;
    public static final long _undel = 2L;

    public JumpPairState()
    {
      super.putEnum(Long.valueOf(1L), "预连接");
      super.putEnum(Long.valueOf(2L), "预拆除");
    }
  }

  public static class TraphServiceTypeLabelColor extends GenericEnum
  {
    public static final String _red = "red";
    public static final String _black = "black";
    public static final String _yellow = "yellow";
    public static final String _blue = "blue";
    public static final String _green = "green";
    public static final String _teal = "teal";
    public static final String _white = "white";
    public static final String _brown = "brown";
    public static final String _orange = "orange";
    public static final String _pink = "pink";
    public static final String _gold = "gold";

    public TraphServiceTypeLabelColor()
    {
      super.putEnum("red", "红色");
      super.putEnum("black", "黑色");
      super.putEnum("yellow", "黄色");
      super.putEnum("blue", "蓝色");
      super.putEnum("green", "绿色");
      super.putEnum("teal", "深绿色");
      super.putEnum("white", "白色");
      super.putEnum("brown", "棕色");
      super.putEnum("orange", "橙色");
      super.putEnum("pink", "粉色");
      super.putEnum("gold", "金色");
    }
  }

  public static class JumpType extends GenericEnum
  {
    public static final long _jumped = 0L;
    public static final long _unjump = 1L;
    public static final long _linked = 2L;
    public static final long _jumpPair = 3L;
    public static final long _noPair = 4L;

    public JumpType()
    {
      super.putEnum(Long.valueOf(0L), "已配跳线");
      super.putEnum(Long.valueOf(1L), "待配跳线");
      super.putEnum(Long.valueOf(2L), "固定连接");
      super.putEnum(Long.valueOf(3L), "中继线对");
      super.putEnum(Long.valueOf(4L), "未做连接");
    }
  }

  public static class ModifyType extends GenericEnum
  {
    public static final long _add = 1L;
    public static final long _modify = 2L;
    public static final long _delete = 3L;

    public ModifyType()
    {
      super.putEnum(Long.valueOf(1L), "新增");
      super.putEnum(Long.valueOf(2L), "修改");
      super.putEnum(Long.valueOf(3L), "删除");
    }
  }

  public static class importantPortect extends GenericEnum
  {
    public static final long _notImportantProtect = 1L;
    public static final long _preImportantProtect = 2L;
    public static final long _importantProtect = 3L;

    public importantPortect()
    {
      super.putEnum(Long.valueOf(1L), "非重保");
      super.putEnum(Long.valueOf(2L), "预重保");
      super.putEnum(Long.valueOf(3L), "重保");
    }
  }

  public static class scheduleState extends GenericEnum
  {
    public static final long IN_SCHEDULE = 1L;
    public static final long OVER_SCHEDULE = 2L;

    public scheduleState()
    {
      super.putEnum(Long.valueOf(1L), "调度中");
      super.putEnum(Long.valueOf(2L), "已完成");
    }
  }

  public static class pathMatchState extends GenericEnum
  {
    public static final long MATCH = 1L;
    public static final long NOT_MATCH = 2L;

    public pathMatchState()
    {
      super.putEnum(Long.valueOf(1L), "1");
      super.putEnum(Long.valueOf(2L), "2");
    }
  }

  public static class endStationType extends GenericEnum
  {
    public static final int DISTRICT = 1;
    public static final int SITE = 2;
    public static final int ROOM = 3;
    public static final int ELEMENT = 4;

    public endStationType()
    {
      super.putEnum(Integer.valueOf(1), "区域");
      super.putEnum(Integer.valueOf(2), "站点");
      super.putEnum(Integer.valueOf(3), "机房");
      super.putEnum(Integer.valueOf(4), "网元");
    }
  }

  public static class ConverRate extends GenericEnum
  {
    public static final int _2M = 1;
    public static final int _4M = 2;
    public static final int _8M = 3;
    public static final int _10M = 4;
    public static final int _34M = 5;
    public static final int _45M = 6;
    public static final int _100M = 7;
    public static final int _155M = 8;
    public static final int _622M = 9;
    public static final int _1_25G = 10;
    public static final int _2_5G = 11;

    private ConverRate()
    {
      super.putEnum(Integer.valueOf(1), "1");
      super.putEnum(Integer.valueOf(2), "2");
      super.putEnum(Integer.valueOf(3), "4");
      super.putEnum(Integer.valueOf(4), "5");
      super.putEnum(Integer.valueOf(5), "16");
      super.putEnum(Integer.valueOf(6), "21");
      super.putEnum(Integer.valueOf(7), "50");
      super.putEnum(Integer.valueOf(8), "63");
      super.putEnum(Integer.valueOf(9), "252");
      super.putEnum(Integer.valueOf(10), "504");
      super.putEnum(Integer.valueOf(11), "1008");
    }
  }

  public static class SwitchPortRate extends GenericEnum
  {
    public static final int _2M = 1;
    public static final int _8M = 2;
    public static final int _10M = 3;
    public static final int _34M = 4;
    public static final int _45M = 5;
    public static final int _68M = 6;
    public static final int _100M = 7;
    public static final int _140M = 8;
    public static final int _155M = 9;
    public static final int _280M = 10;
    public static final int _310M = 11;
    public static final int _565M = 12;
    public static final int _622M = 13;
    public static final int _1G = 14;
    public static final int _1_25G = 15;
    public static final int _2_5G = 16;
    public static final int _10G = 17;
    public static final int _20G = 18;
    public static final int _40G = 19;
    public static final int _80G = 20;
    public static final int _FE = 34;
    public static final int _GE = 35;

    private SwitchPortRate()
    {
      super.putEnum(Integer.valueOf(1), "2M");
      super.putEnum(Integer.valueOf(2), "8M");
      super.putEnum(Integer.valueOf(3), "10M");
      super.putEnum(Integer.valueOf(4), "34M");
      super.putEnum(Integer.valueOf(5), "45M");
      super.putEnum(Integer.valueOf(6), "68M");
      super.putEnum(Integer.valueOf(7), "100M");
      super.putEnum(Integer.valueOf(8), "140M");
      super.putEnum(Integer.valueOf(9), "155M");
      super.putEnum(Integer.valueOf(10), "280M");
      super.putEnum(Integer.valueOf(11), "310M");
      super.putEnum(Integer.valueOf(12), "565M");
      super.putEnum(Integer.valueOf(13), "622M");
      super.putEnum(Integer.valueOf(14), "1G");
      super.putEnum(Integer.valueOf(15), "1.25G");
      super.putEnum(Integer.valueOf(16), "2.5G");
      super.putEnum(Integer.valueOf(17), "10G");
      super.putEnum(Integer.valueOf(18), "20G");
      super.putEnum(Integer.valueOf(19), "40G");
      super.putEnum(Integer.valueOf(20), "80G");
      super.putEnum(Integer.valueOf(34), "FE");
      super.putEnum(Integer.valueOf(35), "GE");
    }
  }

  public static class protectMode extends GenericEnum
  {
    public static final int _L1 = 1;
    public static final int _L2 = 2;
    public static final int _L3 = 3;
    public static final int _L4 = 4;
    public static final int _L5 = 5;
    public static final int _L6 = 6;

    private protectMode()
    {
      super.putEnum(Integer.valueOf(1), "无保护无恢复");
      super.putEnum(Integer.valueOf(2), "MS-SPRING");
      super.putEnum(Integer.valueOf(3), "子网连接保护");
      super.putEnum(Integer.valueOf(4), "DXC保护");
      super.putEnum(Integer.valueOf(5), "有保护无恢复");
      super.putEnum(Integer.valueOf(6), "无保护有恢复");
    }
  }

  public static class SelfTraphType extends GenericEnum
  {
    public static final long _L1 = 1L;
    public static final long _L2 = 2L;

    private SelfTraphType()
    {
      super.putEnum(Long.valueOf(1L), "省内自建");
      super.putEnum(Long.valueOf(2L), "市内自建");
    }
  }

  public static class TraphImportLevelForSH extends GenericEnum
  {
    public static final long _level0 = 0L;
    public static final long _level1 = 1L;
    public static final long _level2 = 2L;
    public static final long _level3 = 3L;
    public static final long _level4 = 4L;
    public static final long _level5 = 5L;
    public static final long _level6 = 6L;
    public static final long _level_SLA = 7L;

    private TraphImportLevelForSH()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "一级");
      super.putEnum(Long.valueOf(2L), "二级");
      super.putEnum(Long.valueOf(3L), "三级");
      super.putEnum(Long.valueOf(4L), "四级");
      super.putEnum(Long.valueOf(5L), "五级");
      super.putEnum(Long.valueOf(6L), "六级");
      super.putEnum(Long.valueOf(7L), "SLA级");
    }
  }

  public static class TraphLevel extends GenericEnum
  {
    public static final long _L1 = 1L;
    public static final long _L2 = 2L;
    public static final long _L3 = 3L;
    public static final long _L4 = 4L;
    public static final long _L5 = 5L;
    public static final long _L6 = 6L;
    public static final long _L7 = 7L;
    public static final long _L8 = 8L;
    public static final long _L9 = 9L;

    private TraphLevel()
    {
      super.putEnum(Long.valueOf(1L), "国际");
      super.putEnum(Long.valueOf(2L), "港澳");
      super.putEnum(Long.valueOf(3L), "际专");
      super.putEnum(Long.valueOf(4L), "省际一级");
      super.putEnum(Long.valueOf(5L), "省际二级");
      super.putEnum(Long.valueOf(6L), "省内二级");
      super.putEnum(Long.valueOf(7L), "本地区间");
      super.putEnum(Long.valueOf(8L), "本地区内");
      super.putEnum(Long.valueOf(9L), "楼内");
    }
  }

  public static class UseType extends GenericEnum
  {
    public static final int _SELF = 1;
    public static final int _RENT = 2;

    private UseType()
    {
      super.putEnum(Integer.valueOf(1), "自用");
      super.putEnum(Integer.valueOf(2), "出租");
    }
  }

  public static class TraphState extends GenericEnum
  {
    public static final long _NEW = 1L;
    public static final long _TEST = 2L;
    public static final long _OPEN = 3L;
    public static final long _STOP = 4L;

    private TraphState()
    {
      super.putEnum(Long.valueOf(1L), "新建");
      super.putEnum(Long.valueOf(2L), "测试");
      super.putEnum(Long.valueOf(3L), "开通");
      super.putEnum(Long.valueOf(4L), "停用");
    }
  }

  public static class TraphOwnership extends GenericEnum
  {
    public static final long _SELF = 1L;
    public static final long _RENT = 2L;
    public static final long _MIX = 3L;
    public static final long _SHARE = 4L;

    private TraphOwnership()
    {
      super.putEnum(Long.valueOf(1L), "自建");
      super.putEnum(Long.valueOf(2L), "租用");
      super.putEnum(Long.valueOf(3L), "混合");
      super.putEnum(Long.valueOf(4L), "合建");
    }
  }

  public static class TraphExt extends GenericEnum
  {
    public static final int _NULL = 1;
    public static final int _IA = 2;
    public static final int _CL = 3;
    public static final int _LB = 4;
    public static final int _LC = 5;
    public static final int _LD = 6;
    public static final int _LA = 7;
    public static final int _SL = 8;
    public static final int _V = 9;
    public static final int _DDN = 10;
    public static final int _DCN = 11;
    public static final int _IPGSM = 12;
    public static final int _OA = 13;
    public static final int _NM = 14;
    public static final int _GC = 15;
    public static final int _NP = 16;
    public static final int _H = 17;
    public static final int _HLR = 18;
    public static final int _SM = 19;
    public static final int _VM = 20;
    public static final int _CS = 21;
    public static final int _GP = 22;
    public static final int _SSP = 23;
    public static final int _CT = 24;
    public static final int _CU = 25;
    public static final int _CR = 26;
    public static final int _BS = 27;
    public static final int _ATM = 28;
    public static final int _IPBB = 29;
    public static final int _BSC = 30;
    public static final int _IPCLI = 31;
    public static final int _IPICP = 32;
    public static final int _IPGSN = 33;
    public static final int _WA = 34;
    public static final int _SS = 35;
    public static final int _IS = 36;
    public static final int _VC = 37;
    public static final int _MG = 38;
    public static final int _MD = 39;
    public static final int _IPSS = 40;
    public static final int _TS = 41;

    private TraphExt()
    {
      super.putEnum(Integer.valueOf(1), "");
      super.putEnum(Integer.valueOf(2), "IA");
      super.putEnum(Integer.valueOf(3), "CL");
      super.putEnum(Integer.valueOf(4), "LB");
      super.putEnum(Integer.valueOf(5), "LC");
      super.putEnum(Integer.valueOf(6), "LD");
      super.putEnum(Integer.valueOf(7), "LA");
      super.putEnum(Integer.valueOf(8), "SL");
      super.putEnum(Integer.valueOf(9), "V");
      super.putEnum(Integer.valueOf(10), "DDN");
      super.putEnum(Integer.valueOf(11), "DCN");
      super.putEnum(Integer.valueOf(12), "IPGSM");
      super.putEnum(Integer.valueOf(13), "OA");
      super.putEnum(Integer.valueOf(14), "NM");
      super.putEnum(Integer.valueOf(15), "GC");
      super.putEnum(Integer.valueOf(16), "NP");
      super.putEnum(Integer.valueOf(17), "H");
      super.putEnum(Integer.valueOf(18), "HLR");
      super.putEnum(Integer.valueOf(19), "SM");
      super.putEnum(Integer.valueOf(20), "VM");
      super.putEnum(Integer.valueOf(21), "CS");
      super.putEnum(Integer.valueOf(22), "GP");
      super.putEnum(Integer.valueOf(23), "SSP");
      super.putEnum(Integer.valueOf(24), "CT");
      super.putEnum(Integer.valueOf(25), "CU");
      super.putEnum(Integer.valueOf(26), "CR");
      super.putEnum(Integer.valueOf(27), "BS");
      super.putEnum(Integer.valueOf(28), "ATM");
      super.putEnum(Integer.valueOf(29), "IPBB");
      super.putEnum(Integer.valueOf(30), "BSC");
      super.putEnum(Integer.valueOf(31), "IPCLI");
      super.putEnum(Integer.valueOf(32), "IPICP");
      super.putEnum(Integer.valueOf(33), "IPGSN");
      super.putEnum(Integer.valueOf(34), "WA");
      super.putEnum(Integer.valueOf(35), "SS");
      super.putEnum(Integer.valueOf(36), "IS");
      super.putEnum(Integer.valueOf(37), "VC");
      super.putEnum(Integer.valueOf(38), "MG");
      super.putEnum(Integer.valueOf(39), "MD");
      super.putEnum(Integer.valueOf(40), "IPSS");
      super.putEnum(Integer.valueOf(41), "TS");
    }
  }

  public static class TopoTraphRate extends GenericEnum
  {
    public static final int _2M = 1;
    public static final int _8M = 2;
    public static final int _10M = 3;
    public static final int _34M = 4;
    public static final int _45M = 5;
    public static final int _68M = 6;
    public static final int _100M = 7;
    public static final int _140M = 8;
    public static final int _155M = 9;
    public static final int _280M = 10;
    public static final int _310M = 11;
    public static final int _565M = 12;
    public static final int _622M = 13;
    public static final int _1G = 14;
    public static final int _1_25G = 15;
    public static final int _2_5G = 16;
    public static final int _10G = 17;
    public static final int _20G = 18;
    public static final int _40G = 19;
    public static final int _80G = 20;
    public static final int _64K = 26;
    public static final int _FE = 34;
    public static final int _GE = 35;

    private TopoTraphRate()
    {
      super.putEnum(Integer.valueOf(1), "2M");
      super.putEnum(Integer.valueOf(2), "8M");
      super.putEnum(Integer.valueOf(3), "10M");
      super.putEnum(Integer.valueOf(4), "34M");
      super.putEnum(Integer.valueOf(5), "45M");
      super.putEnum(Integer.valueOf(6), "68M");
      super.putEnum(Integer.valueOf(7), "100M");
      super.putEnum(Integer.valueOf(8), "140M");
      super.putEnum(Integer.valueOf(9), "155M");
      super.putEnum(Integer.valueOf(10), "280M");
      super.putEnum(Integer.valueOf(11), "310M");
      super.putEnum(Integer.valueOf(12), "565M");
      super.putEnum(Integer.valueOf(13), "622M");
      super.putEnum(Integer.valueOf(14), "1G");
      super.putEnum(Integer.valueOf(15), "1.25G");
      super.putEnum(Integer.valueOf(16), "2.5G");
      super.putEnum(Integer.valueOf(17), "10G");
      super.putEnum(Integer.valueOf(18), "20G");
      super.putEnum(Integer.valueOf(19), "40G");
      super.putEnum(Integer.valueOf(20), "80G");
      super.putEnum(Integer.valueOf(26), "64K");
      super.putEnum(Integer.valueOf(34), "FE");
      super.putEnum(Integer.valueOf(35), "GE");
    }
  }

  public static class TraphRate extends GenericEnum
  {
    public static final int _2M = 1;
    public static final int _8M = 2;
    public static final int _10M = 3;
    public static final int _34M = 4;
    public static final int _45M = 5;
    public static final int _68M = 6;
    public static final int _100M = 7;
    public static final int _140M = 8;
    public static final int _155M = 9;
    public static final int _280M = 10;
    public static final int _310M = 11;
    public static final int _565M = 12;
    public static final int _622M = 13;
    public static final int _1G = 14;
    public static final int _1_25G = 15;
    public static final int _2_5G = 16;
    public static final int _10G = 17;
    public static final int _20G = 18;
    public static final int _40G = 19;
    public static final int _80G = 20;
    public static final int _64K = 26;
    public static final int _FE = 34;
    public static final int _GE = 35;

    private TraphRate()
    {
      super.putEnum(Integer.valueOf(1), "2M");
      super.putEnum(Integer.valueOf(2), "8M");
      super.putEnum(Integer.valueOf(3), "10M");
      super.putEnum(Integer.valueOf(4), "34M");
      super.putEnum(Integer.valueOf(5), "45M");
      super.putEnum(Integer.valueOf(6), "68M");
      super.putEnum(Integer.valueOf(7), "100M");
      super.putEnum(Integer.valueOf(8), "140M");
      super.putEnum(Integer.valueOf(9), "155M");
      super.putEnum(Integer.valueOf(10), "280M");
      super.putEnum(Integer.valueOf(11), "310M");
      super.putEnum(Integer.valueOf(12), "565M");
      super.putEnum(Integer.valueOf(13), "622M");
      super.putEnum(Integer.valueOf(14), "1G");
      super.putEnum(Integer.valueOf(15), "1_25G");
      super.putEnum(Integer.valueOf(16), "2_5G");
      super.putEnum(Integer.valueOf(17), "10G");
      super.putEnum(Integer.valueOf(18), "20G");
      super.putEnum(Integer.valueOf(19), "40G");
      super.putEnum(Integer.valueOf(20), "80G");
      super.putEnum(Integer.valueOf(26), "64K");
      super.putEnum(Integer.valueOf(34), "FE");
      super.putEnum(Integer.valueOf(35), "GE");
    }
  }

  public static class LoadType extends GenericEnum
  {
    public static final long _sdh = 1L;
    public static final long _mstp = 2L;
    public static final long _wdm = 3L;
    public static final long _otn = 4L;
    public static final long _ptn = 5L;

    private LoadType()
    {
      super.putEnum(Long.valueOf(1L), "SDH");
      super.putEnum(Long.valueOf(2L), "MSTP");
      super.putEnum(Long.valueOf(3L), "WDM");
      super.putEnum(Long.valueOf(4L), "OTN");
      super.putEnum(Long.valueOf(5L), "PTN");
    }
  }

  public static class TraphType extends GenericEnum
  {
    public static final long _TransTraph = 1L;
    public static final long _SelfTraph = 2L;
    public static final long _MstpTraph = 3L;

    private TraphType()
    {
      super.putEnum(Long.valueOf(1L), "传输电路");
      super.putEnum(Long.valueOf(2L), "直连电路");
      super.putEnum(Long.valueOf(3L), "MSTP电路");
    }
  }

  public static class NetWorkTraphType extends GenericEnum
  {
    public static final long _CMNET = 161L;
    public static final long _RENT = 162L;
    public static final long _WLAN = 163L;
    public static final long _IMS = 164L;
    public static final long _SDH_NETWORK = 165L;

    private NetWorkTraphType()
    {
      super.putEnum(Long.valueOf(161L), "CMNET");
      super.putEnum(Long.valueOf(162L), "出租专线");
      super.putEnum(Long.valueOf(163L), "WLAN");
      super.putEnum(Long.valueOf(164L), "IMS");
      super.putEnum(Long.valueOf(165L), "联网电路");
    }
  }

  public static class InputType extends GenericEnum
  {
    public static final long _SDH_TD = 111L;
    public static final long _SDH_2G = 112L;
    public static final long _SDH_2G_CM = 113L;
    public static final long _SDH_TD_RENT = 114L;
    public static final long _SDH_2G_RENT = 115L;
    public static final long _SDH_NETWORK = 116L;
    public static final long _PTN_TD = 121L;
    public static final long _PTN_LTE = 122L;
    public static final long _PTN_LTE_4 = 127L;
    public static final long _PTN_WLAN = 123L;
    public static final long _PTN_SDH_PTN = 124L;
    public static final long _PTN_HJ = 125L;
    public static final long _PTN_IP_HJ = 126L;
    public static final long _SDH_MSTP_CM = 130L;
    public static final long _PTN_MSTP_PTN_PTN = 141L;
    public static final long _PTN_MSTP_SDH_PTN = 142L;
    public static final long _PTN_MSTP_CMNET = 143L;
    public static final long _PTN_MSTP_IMS = 144L;
    public static final long _PTN_MSTP_PTN_PTN_DV = 145L;
    public static final long _SDH_MSTP = 150L;
    public static final long[] SDH = { 111L, 112L, 113L, 114L, 115L, 130L, 150L, 116L };

    public static final long[] PTN = { 121L, 122L, 123L, 124L, 125L, 126L, 141L, 145L, 142L, 143L, 127L, 144L };

    public static final long[] NOT_MSTP = { 111L, 112L, 113L, 114L, 115L, 116L, 121L, 122L, 127L, 124L, 125L, 126L };

    public static final long[] MSTP = { 141L, 145L, 142L, 143L, 123L, 144L, 150L };

    public static final long[] MSTP_CM = { 130L };

    private InputType() { super.putEnum(Long.valueOf(111L), "SDH_TD");
      super.putEnum(Long.valueOf(112L), "SDH_2G");
      super.putEnum(Long.valueOf(113L), "SDH_2G_CM");
      super.putEnum(Long.valueOf(114L), "SDH_TD_RENT");
      super.putEnum(Long.valueOf(115L), "SDH_2G_RENT");
      super.putEnum(Long.valueOf(116L), "SDH_NETWORK");

      super.putEnum(Long.valueOf(121L), "PTN_TD");
      super.putEnum(Long.valueOf(122L), "PTN_LTE");
      super.putEnum(Long.valueOf(127L), "PTN_LTE_4");
      super.putEnum(Long.valueOf(123L), "PTN_WLAN");
      super.putEnum(Long.valueOf(124L), "PTN_SDH_PTN");
      super.putEnum(Long.valueOf(125L), "PTN_HJ");
      super.putEnum(Long.valueOf(126L), "PTN_IP_HJ");

      super.putEnum(Long.valueOf(130L), "SDH_MSTP_CM");

      super.putEnum(Long.valueOf(141L), "PTN_MSTP_PTN_PTN");
      super.putEnum(Long.valueOf(145L), "PTN_MSTP_PTN_PTN_DV");
      super.putEnum(Long.valueOf(142L), "PTN_MSTP_SDH_PTN");
      super.putEnum(Long.valueOf(143L), "PTN_MSTP_CMNET");
      super.putEnum(Long.valueOf(144L), "PTN_MSTP_IMS");

      super.putEnum(Long.valueOf(150L), "SDH_MSTP"); }

    public static String getAllPtnInputType()
    {
      String ptnInputType = "";
      for (int i = 0; i < PTN.length; i++) {
        if (i == 0)
          ptnInputType = "" + PTN[i];
        else {
          ptnInputType = ptnInputType + "," + PTN[i];
        }
      }
      return ptnInputType;
    }

    public static String getAllSdhInputType() {
      String sdhInputType = "";
      for (int i = 0; i < SDH.length; i++) {
        if (i == 0)
          sdhInputType = "" + SDH[i];
        else {
          sdhInputType = sdhInputType + "," + SDH[i];
        }
      }
      return sdhInputType;
    }

    public static String getAllMstpInputType()
    {
      String mstpInputType = "";
      for (int i = 0; i < MSTP.length; i++) {
        if (i == 0)
          mstpInputType = "" + MSTP[i];
        else {
          mstpInputType = mstpInputType + "," + MSTP[i];
        }
      }
      for (int i = 0; i < MSTP_CM.length; i++) {
        mstpInputType = mstpInputType + "," + MSTP_CM[i];
      }
      return mstpInputType;
    }

    public static String getNotMstpTraphInputType()
    {
      String inputType = "";
      for (int i = 0; i < NOT_MSTP.length; i++) {
        if (i == 0)
          inputType = "" + NOT_MSTP[i];
        else {
          inputType = inputType + "," + NOT_MSTP[i];
        }
      }
      return inputType;
    }

    public static boolean isSdh(String inputType) {
      String sdhInputType = getAllSdhInputType();
      return sdhInputType.indexOf(inputType) != -1;
    }
    public static boolean isPtn(String inputType) {
      String ptnInputType = getAllPtnInputType();
      return ptnInputType.indexOf(inputType) != -1;
    }
    public static boolean isMstp(String inputType) {
      String mstpInputType = getAllMstpInputType();
      return mstpInputType.indexOf(inputType) != -1;
    }
  }

  public static class SdhMstpTraphType extends GenericEnum
  {
    public static final long _CMNET = 151L;
    public static final long _RENT = 152L;
    public static final long _WLAN = 153L;
    public static final long _IMS = 154L;
    public static final long _SDH_MSTP_INTERPROVINCIAL = 155L;

    private SdhMstpTraphType()
    {
      super.putEnum(Long.valueOf(151L), "CMNET");
      super.putEnum(Long.valueOf(152L), "出租专线");
      super.putEnum(Long.valueOf(153L), "WLAN");
      super.putEnum(Long.valueOf(154L), "IMS");
      super.putEnum(Long.valueOf(155L), "省际专线");
    }
  }

  public static class CMSdhMstpTraphType extends GenericEnum
  {
    public static final long _CMNET = 131L;
    public static final long _RENT = 132L;
    public static final long _WLAN = 133L;
    public static final long _IMS = 134L;

    private CMSdhMstpTraphType()
    {
      super.putEnum(Long.valueOf(131L), "CMNET");
      super.putEnum(Long.valueOf(132L), "出租专线");
      super.putEnum(Long.valueOf(133L), "WLAN");
      super.putEnum(Long.valueOf(134L), "IMS");
    }
  }

  public static class TraphKind extends GenericEnum
  {
    public static final long _ExchangeTraph = 1L;
    public static final long _ComposeNetRelayTraph = 2L;

    private TraphKind()
    {
      super.putEnum(Long.valueOf(1L), "业务电路");
      super.putEnum(Long.valueOf(2L), "组网中继电路");
    }
  }

  public static class TraphNameRule extends GenericEnum
  {
    public static final long _SDHNameRule = 1L;
    public static final long _ATMNameRule = 2L;

    private TraphNameRule()
    {
      super.putEnum(Long.valueOf(1L), "SDH命名方式");
      super.putEnum(Long.valueOf(2L), "ATM命名方式");
    }
  }

  public static class OwnershipSH extends GenericEnum
  {
    public static final long _ZJ = 1L;
    public static final long _FFZY = 2L;
    public static final long _BFFZY = 3L;
    public static final long _HJ = 4L;

    private OwnershipSH()
    {
      super.putEnum(Long.valueOf(1L), "自建");
      super.putEnum(Long.valueOf(2L), "付费租用");
      super.putEnum(Long.valueOf(3L), "不付费租用");
      super.putEnum(Long.valueOf(4L), "合建");
    }
  }

  public static class UseTypeSH extends GenericEnum
  {
    public static final long _GJ = 1L;
    public static final long _GAT = 2L;
    public static final long _YG = 3L;
    public static final long _CYHX = 4L;
    public static final long _CYJR = 5L;
    public static final long _WJ = 6L;
    public static final long _WN = 7L;

    private UseTypeSH()
    {
      super.putEnum(Long.valueOf(1L), "国际");
      super.putEnum(Long.valueOf(2L), "港澳台");
      super.putEnum(Long.valueOf(3L), "一干");
      super.putEnum(Long.valueOf(4L), "城域核心");
      super.putEnum(Long.valueOf(5L), "城域接入");
      super.putEnum(Long.valueOf(6L), "网间");
      super.putEnum(Long.valueOf(7L), "网内");
    }
  }

  public static class AttempSheetTraphType extends GenericEnum
  {
    public static final long _PTN = 1L;
    public static final long _SDH = 2L;
    public static final long _MIX = 3L;

    private AttempSheetTraphType()
    {
      super.putEnum(Long.valueOf(1L), "PTN电路");
      super.putEnum(Long.valueOf(2L), "SDH电路");
      super.putEnum(Long.valueOf(3L), "混合电路");
    }
  }
}