package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class OpticalWayEnum extends GenericEnum
{
  public static final ISSDH issdh = new ISSDH(null);
  public static final ISOptimize iso = new ISOptimize(null);
  public static final OpticalWayState oState = new OpticalWayState(null);
  public static final OpticalWayType oType = new OpticalWayType(null);
  public static final OpticalWayRes oRes = new OpticalWayRes(null);
  public static final OpticalPortType portType = new OpticalPortType(null);
  public static final OpticalPathType pathType = new OpticalPathType(null);
  public static final OpticalTaskState taskState = new OpticalTaskState(null);
  public static final OpticalTaskCelue taskCelue = new OpticalTaskCelue(null);
  public static final SubDistrictType subDistrictType = new SubDistrictType(null);
  public static final OpticalTaskExeType exeType = new OpticalTaskExeType(null);
  public static final HourType hourType = new HourType(null);
  public static final OpticalWeekTime weekTime = new OpticalWeekTime(null);
  public static final ExtType extType = new ExtType(null);
  public static final CheckTaskType checkTaskType = new CheckTaskType(null);
  public static final OpticalWayMakeFlag opticalWayMakeFlag = new OpticalWayMakeFlag(null);
  public static final RouteType routeType = new RouteType(null);
  public static final PortAzType portAzType = new PortAzType(null);

  public static class PortAzType extends GenericEnum
  {
    public static long sideA = 1L;
    public static long sideZ = 2L;
    public static long pon = 3L;

    private PortAzType() {
      super.putEnum(Long.valueOf(sideA), "A侧端口");
      super.putEnum(Long.valueOf(sideZ), "Z侧端口");
      super.putEnum(Long.valueOf(pon), "PON业务端口");
    }
  }

  public static class RouteType extends GenericEnum
  {
    public static long opticalRoute = 1L;
    public static long jumpFiberRoute = 2L;

    private RouteType() {
      super.putEnum(Long.valueOf(opticalRoute), "光纤路由");
      super.putEnum(Long.valueOf(jumpFiberRoute), "跳纤路由");
    }
  }

  public static class OpticalWayMakeFlag extends GenericEnum
  {
    public static final long waitcheck = 1L;
    public static final long seccess = 2L;
    public static final long failure = 3L;

    private OpticalWayMakeFlag()
    {
      super.putEnum(Long.valueOf(1L), "待核查");
      super.putEnum(Long.valueOf(2L), "成功");
      super.putEnum(Long.valueOf(3L), "失败");
    }
  }

  public static class CheckTaskType extends GenericEnum
  {
    public static long opticalCheck = 1L;
    public static long opticalWayCheck = 2L;
    public static long allCheck = 3L;

    private CheckTaskType() {
      super.putEnum(Long.valueOf(opticalCheck), "光纤核查");
      super.putEnum(Long.valueOf(opticalWayCheck), "光路核查");
      super.putEnum(Long.valueOf(allCheck), "全部核查");
    }
  }

  public static class ExtType extends GenericEnum
  {
    public static long simpleService = 1L;
    public static long transSystem = 2L;
    public static long opticalwireHire = 3L;

    private ExtType() {
      super.putEnum(Long.valueOf(simpleService), "普通业务");
      super.putEnum(Long.valueOf(transSystem), "传输系统");
      super.putEnum(Long.valueOf(opticalwireHire), "光纤出租");
    }
  }

  public static class OpticalPathType extends GenericEnum
  {
    public static String optical = "OPTICAL";
    public static String wave = "WAVE";

    private OpticalPathType() { super.putEnum(optical, "光纤");
      super.putEnum(wave, "光波道");
    }
  }

  public static class OpticalPortType extends GenericEnum
  {
    public static int portA = 1;
    public static int portZ = 2;

    private OpticalPortType() { super.putEnum(Integer.valueOf(portA), "A端");
      super.putEnum(Integer.valueOf(portZ), "Z端");
    }
  }

  public static class ISOptimize extends GenericEnum
  {
    public static String is = "1";
    public static String notis = "0";

    private ISOptimize() { super.putEnum(is, "正常");
      super.putEnum(notis, "不正常");
    }
  }

  public static class ISSDH extends GenericEnum
  {
    public static String right = "1";
    public static String wrong = "0";

    private ISSDH() {
      super.putEnum(right, "正常");
      super.putEnum(wrong, "不正常");
    }
  }

  public static class OpticalWayState extends GenericEnum
  {
    public static long FREE = 1L;
    public static long ORDER = 2L;
    public static long INUSE = 3L;

    private OpticalWayState() {
      super.putEnum(Long.valueOf(FREE), "空闲");
      super.putEnum(Long.valueOf(ORDER), "预占");
      super.putEnum(Long.valueOf(INUSE), "占用");
    }
  }

  public static class OpticalWayRes extends GenericEnum
  {
    public static long _fiber = 1L;
    public static long _trans = 2L;

    private OpticalWayRes() { super.putEnum(Long.valueOf(_fiber), "光纤");
      super.putEnum(Long.valueOf(_trans), "光波");
    }
  }

  public static class OpticalWayType extends GenericEnum
  {
    public static int USEING = 0;
    public static int ATTR = 1;
    public static int HISTORY = 2;

    private OpticalWayType() {
      super.putEnum(Integer.valueOf(USEING), "使用中");
      super.putEnum(Integer.valueOf(ATTR), "调度中");
      super.putEnum(Integer.valueOf(HISTORY), "历史");
    }
  }

  public static class OpticalTaskState extends GenericEnum
  {
    public static int JIHUO = 1;
    public static int GUAQI = 2;

    private OpticalTaskState() {
      super.putEnum(Integer.valueOf(JIHUO), "激活");
      super.putEnum(Integer.valueOf(GUAQI), "挂起");
    }
  }

  public static class OpticalTaskCelue extends GenericEnum
  {
    public static int NOTCYCLE = 0;
    public static int DAY = 1;
    public static int MONTH = 2;
    public static int WEEK = 3;

    private OpticalTaskCelue()
    {
      super.putEnum(Integer.valueOf(NOTCYCLE), "非周期");
      super.putEnum(Integer.valueOf(DAY), "每日");
      super.putEnum(Integer.valueOf(WEEK), "每周");
      super.putEnum(Integer.valueOf(MONTH), "每月");
    }
  }

  public static class SubDistrictType extends GenericEnum
  {
    public static long NO = 0L;
    public static long YES = 1L;

    private SubDistrictType() {
      super.putEnum(Long.valueOf(NO), "否");
      super.putEnum(Long.valueOf(YES), "是");
    }
  }

  public static class OpticalTaskExeType extends GenericEnum
  {
    public static int NOW = 0;
    public static int DINGSHI = 1;
    public static int CYCLE = 2;

    private OpticalTaskExeType() {
      super.putEnum(Integer.valueOf(NOW), "立即执行");
      super.putEnum(Integer.valueOf(DINGSHI), "定时执行");
      super.putEnum(Integer.valueOf(CYCLE), "周期执行");
    }
  }

  public static class HourType extends GenericEnum
  {
    public static long A = 0L;
    public static long B = 1L;
    public static long C = 2L;
    public static long D = 3L;
    public static long E = 4L;
    public static long F = 5L;
    public static long G = 6L;
    public static long H = 7L;
    public static long I = 8L;
    public static long J = 9L;
    public static long K = 10L;
    public static long L = 11L;
    public static long M = 12L;
    public static long N = 13L;
    public static long O = 14L;
    public static long P = 15L;
    public static long Q = 16L;
    public static long R = 17L;
    public static long S = 18L;
    public static long T = 19L;
    public static long U = 20L;
    public static long V = 21L;
    public static long W = 22L;
    public static long X = 23L;

    private HourType() {
      super.putEnum(Long.valueOf(A), "0:00");
      super.putEnum(Long.valueOf(B), "1:00");
      super.putEnum(Long.valueOf(C), "2:00");
      super.putEnum(Long.valueOf(D), "3:00");
      super.putEnum(Long.valueOf(E), "4:00");
      super.putEnum(Long.valueOf(F), "5:00");
      super.putEnum(Long.valueOf(G), "6:00");
      super.putEnum(Long.valueOf(H), "7:00");
      super.putEnum(Long.valueOf(I), "8:00");
      super.putEnum(Long.valueOf(J), "9:00");
      super.putEnum(Long.valueOf(K), "10:00");
      super.putEnum(Long.valueOf(L), "11:00");
      super.putEnum(Long.valueOf(M), "12:00");
      super.putEnum(Long.valueOf(N), "13:00");
      super.putEnum(Long.valueOf(O), "14:00");
      super.putEnum(Long.valueOf(P), "15:00");
      super.putEnum(Long.valueOf(Q), "16:00");
      super.putEnum(Long.valueOf(R), "17:00");
      super.putEnum(Long.valueOf(S), "18:00");
      super.putEnum(Long.valueOf(T), "19:00");
      super.putEnum(Long.valueOf(U), "20:00");
      super.putEnum(Long.valueOf(V), "21:00");
      super.putEnum(Long.valueOf(W), "22:00");
      super.putEnum(Long.valueOf(X), "23:00");
    }
  }

  public static class OpticalWeekTime extends GenericEnum
  {
    public static int SUN = 1;
    public static int MON = 2;
    public static int THU = 3;
    public static int WEN = 4;
    public static int TRU = 5;
    public static int FRI = 6;
    public static int SAT = 7;

    private OpticalWeekTime() {
      super.putEnum(Integer.valueOf(SUN), "星期日");
      super.putEnum(Integer.valueOf(MON), "星期一");
      super.putEnum(Integer.valueOf(THU), "星期二");
      super.putEnum(Integer.valueOf(WEN), "星期三");
      super.putEnum(Integer.valueOf(TRU), "星期四");
      super.putEnum(Integer.valueOf(FRI), "星期五");
      super.putEnum(Integer.valueOf(SAT), "星期六");
    }
  }
}