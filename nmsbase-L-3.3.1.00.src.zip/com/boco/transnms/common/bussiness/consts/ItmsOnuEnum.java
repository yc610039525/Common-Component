package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class ItmsOnuEnum
{
  public static final AccessMode ACCESS_MODE = new AccessMode(null);

  public static final BroadbandStatus BROADBAND_STATUS = new BroadbandStatus(null);

  public static final Rgmode RGMODE = new Rgmode(null);

  public static class Rgmode extends GenericEnum
  {
    public static final long _rout = 1L;
    public static final long _bridge = 2L;

    private Rgmode()
    {
      super.putEnum(Long.valueOf(1L), "路由模式");
      super.putEnum(Long.valueOf(2L), "桥接模式");
    }
  }

  public static class BroadbandStatus extends GenericEnum
  {
    public static final long _close = 0L;
    public static final long _unopen = 1L;
    public static final long _open = 2L;
    public static final long _disabled = 3L;
    public static final long _dowm = 4L;

    private BroadbandStatus()
    {
      super.putEnum(Long.valueOf(0L), "未开通");
      super.putEnum(Long.valueOf(1L), "待开通");
      super.putEnum(Long.valueOf(2L), "已开通");
      super.putEnum(Long.valueOf(3L), "已禁用");
      super.putEnum(Long.valueOf(4L), "已停机");
    }
  }

  public static class AccessMode extends GenericEnum
  {
    public static final long _default = 0L;
    public static final long _adsl = 1L;
    public static final long _lan = 2L;
    public static final long _epon = 3L;
    public static final long _gpon = 4L;

    private AccessMode()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "ADSL");
      super.putEnum(Long.valueOf(2L), "LAN");
      super.putEnum(Long.valueOf(3L), "EPON");
      super.putEnum(Long.valueOf(4L), "GPON");
    }
  }
}