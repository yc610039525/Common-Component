package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class BitsPortEnum extends GenericEnum
{
  public static final PortType PROT_TYPE = new PortType(null);
  public static final Impedance IMPEDANCE = new Impedance(null);
  public static final Frequency FREQUENCY = new Frequency(null);
  public static final CorrelativeDev CORRELATIVE_DEV = new CorrelativeDev(null);
  public static final OutPortState OUT_PORT_STATE = new OutPortState(null);
  public static final InputPortState INPUT_PORT_STATE = new InputPortState(null);
  public static final PortState PORT_STATE = new PortState(null);
  public static final PriorityLevel PRIORITY_LEVEL = new PriorityLevel(null);
  public static final QlLevel QL_LEVEL = new QlLevel(null);
  public static final IsSsm IS_SSM = new IsSsm(null);
  public static final signKind SIGNKIND = new signKind(null);

  public static class signKind extends GenericEnum
  {
    public static final long _T1 = 1L;
    public static final long _T2 = 2L;

    private signKind()
    {
      super.putEnum(Long.valueOf(1L), "T1");
      super.putEnum(Long.valueOf(2L), "T2");
    }
  }

  public static class IsSsm extends GenericEnum
  {
    public static final long _T = 1L;
    public static final long _F = 2L;

    private IsSsm()
    {
      super.putEnum(Long.valueOf(1L), "是");
      super.putEnum(Long.valueOf(2L), "否");
    }
  }

  public static class QlLevel extends GenericEnum
  {
    public static final long _PRC = 1L;
    public static final long _SSUT = 2L;
    public static final long _SSUL = 3L;

    private QlLevel()
    {
      super.putEnum(Long.valueOf(1L), "QL_PRC");
      super.putEnum(Long.valueOf(2L), "QL_SSU-T");
      super.putEnum(Long.valueOf(3L), "QL_SSU-L");
    }
  }

  public static class PriorityLevel extends GenericEnum
  {
    public static final long _USE1 = 1L;
    public static final long _USE2 = 2L;
    public static final long _USE3 = 3L;

    private PriorityLevel()
    {
      super.putEnum(Long.valueOf(1L), "主用1");
      super.putEnum(Long.valueOf(2L), "主用2");
      super.putEnum(Long.valueOf(3L), "主用3");
    }
  }

  public static class PortState extends GenericEnum
  {
    public static final long _DIS = 1L;
    public static final long _PRE = 2L;
    public static final long _SET = 3L;
    public static final long _BAD = 4L;
    public static final long _MA1 = 5L;
    public static final long _MA2 = 6L;
    public static final long _TEST = 7L;
    public static final long _BACK = 8L;

    private PortState()
    {
      super.putEnum(Long.valueOf(1L), "空闲");
      super.putEnum(Long.valueOf(2L), "占用");
      super.putEnum(Long.valueOf(3L), "预占");
      super.putEnum(Long.valueOf(4L), "损坏");
      super.putEnum(Long.valueOf(5L), "主用1");
      super.putEnum(Long.valueOf(6L), "主用2");
      super.putEnum(Long.valueOf(7L), "检测");
      super.putEnum(Long.valueOf(8L), "备用");
    }
  }

  public static class InputPortState extends GenericEnum
  {
    public static final long _MA1 = 5L;
    public static final long _MA2 = 6L;
    public static final long _TEST = 7L;
    public static final long _BACK = 8L;

    private InputPortState()
    {
      super.putEnum(Long.valueOf(5L), "主用1");
      super.putEnum(Long.valueOf(6L), "主用2");
      super.putEnum(Long.valueOf(7L), "检测");
      super.putEnum(Long.valueOf(8L), "备用");
    }
  }

  public static class OutPortState extends GenericEnum
  {
    public static final long _DIS = 1L;
    public static final long _PRE = 2L;
    public static final long _SET = 3L;
    public static final long _BAD = 4L;

    private OutPortState()
    {
      super.putEnum(Long.valueOf(1L), "空闲");
      super.putEnum(Long.valueOf(2L), "占用");
      super.putEnum(Long.valueOf(3L), "预占");
      super.putEnum(Long.valueOf(4L), "损坏");
    }
  }

  public static class CorrelativeDev extends GenericEnum
  {
    public static final long _INPUTPORT = 1L;
    public static final long _OUTPUTPORT = 2L;

    private CorrelativeDev()
    {
      super.putEnum(Long.valueOf(1L), "输入口:上游设备");
      super.putEnum(Long.valueOf(2L), "输出口:下游设备");
    }
  }

  public static class Frequency extends GenericEnum
  {
    public static final long _2MB = 1L;
    public static final long _2MH = 2L;

    private Frequency()
    {
      super.putEnum(Long.valueOf(1L), "2MBITS");
      super.putEnum(Long.valueOf(2L), "2MHZ");
    }
  }

  public static class Impedance extends GenericEnum
  {
    public static final long _75 = 1L;
    public static final long _120 = 2L;

    private Impedance()
    {
      super.putEnum(Long.valueOf(1L), "75Ω");
      super.putEnum(Long.valueOf(2L), "120Ω");
    }
  }

  public static class PortType extends GenericEnum
  {
    public static final long _INPUT = 1L;
    public static final long _OUTPUT = 2L;

    private PortType()
    {
      super.putEnum(Long.valueOf(1L), "输入");
      super.putEnum(Long.valueOf(2L), "输出");
    }
  }
}