package com.boco.transnms.common.bussiness.consts;

public class ConfdataChangeLogEnum
{
}