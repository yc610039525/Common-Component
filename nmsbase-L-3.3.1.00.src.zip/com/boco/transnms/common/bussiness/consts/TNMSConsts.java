package com.boco.transnms.common.bussiness.consts;

public class TNMSConsts
{
  public static final String ADMIN_USER_CUID = "SYS_USER-0";
  public static final String ACTION_TYPE = "ACTION_TYPE";
  public static final String ORIG_ALARM_CUID = "ORIG_ALARM_CUID";
  public static long AlarmEffectRoute = 1L;
  public static long AlarmBreakRoute = 2L;
  public static final String ALARM_ALL_IN_USE = "ALL_IN_USE";
  public static final String ALARM_NOTALL_IN_USE = "NOTALL_IN_USE";
  public static final String TRAPH_CHANGE = "traphChange";
  public static final String PTN_IP_CROSSCONNECT_CHANGE = "ptnIpccChange";
  public static final String DELETE_EQUIP = "deleteEquip";
  public static final String USER_CHANGE = "UserChange";
  public static final String RELATED_EMS_CUID = "RELATED_EMS_CUID";
  public static final String FDN = "FDN";
  public static final String RELATED_NE_CUID = "RELATED_NE_CUID";
  public static final String PROJECT_CHANGE = "PROJECT_CHANGE";
  public static final String RelatedSpaceCuid = "RELATED_SPACE_CUID";
  public static final String DevSyncCommonBO = "DevSyncCommonBO";
  public static final String PTP_CLASS_NAME = "PTP";
  public static final String CARD_CLASS_NAME = "CARD";
  public static final String TRANS_PATH_CLASS_NAME = "TRANS_PATH";
  public static final String CTP_CLASS_NAME = "CTP";
  public static final long TYPE_OF_CARD = 3L;
  public static final long TYPE_OF_PTP = 4L;
  public static final String OLD_TRAPH_CUID = "OLD_TRAPH_CUID";
}