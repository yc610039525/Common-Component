package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class ServiceEnum
{
  public static final ServiceType serviceType = new ServiceType(null);

  public static class ServiceType extends GenericEnum {
    public static final long _appServerLocaltion = 1L;
    public static final long _boServiceLocation = 2L;
    public static final long _webServieLocation = 3L;
    public static final long _mapServiceLocation = 4L;
    public static final long _infServiceLocation = 5L;

    private ServiceType() { super.putEnum(Long.valueOf(1L), "应用服务器位置描述");
      super.putEnum(Long.valueOf(2L), "BO服务描述");
      super.putEnum(Long.valueOf(3L), "web服务描述");
      super.putEnum(Long.valueOf(4L), "地图服务描述");
      super.putEnum(Long.valueOf(5L), "接口服务描述");
    }
  }
}