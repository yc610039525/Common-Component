package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;
import com.boco.transnms.common.dto.base.GenericDO;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TransPathEnum
{
  public static final TransPathStateType TRANSPATH_STATE_TYPE = new TransPathStateType(null);
  public static final TransPathType TRANS_PATH_TYPE = new TransPathType(null);
  public static final TransSubPathType TRANS_SUB_PATH_TYPE = new TransSubPathType(null);
  public static final Direction DIRECTION = new Direction(null);
  public static final CreateType CREATE_TYPE = new CreateType(null);
  public static final PathMakeFlag PATH_MAKE_FLAG = new PathMakeFlag(null);
  public static final SysDirection SYS_DIRECTION = new SysDirection(null);
  public static final OwnerShip OWNER_SHIP = new OwnerShip(null);
  public static final LostPathType LOST_PATH_TYPE = new LostPathType(null);
  public static final EqualType EQUAL_TYPE = new EqualType(null);
  public static final GzUseState GZ_USE_STATE = new GzUseState(null);
  public static final GzPathCheckFlag GZ_PATH_CHECK_FLAG = new GzPathCheckFlag(null);
  public static final GzPathEndType GZ_PATH_END_TYPE = new GzPathEndType(null);
  public static final ActionType ACTION_TYPE = new ActionType(null);
  public static final EndAttempType END_ATTEMP_TYPE = new EndAttempType(null);
  public static final GzInputType GZ_INPUT_TYPE = new GzInputType(null);

  public static final GzLowerDivideRule GZ_LOWER_DIVIDE_RULE = new GzLowerDivideRule(null);

  public static final GzEndType GZ_END_TYPE = new GzEndType(null);

  public static class EqualType extends GenericEnum
  {
    public static final long _portEqual = 0L;
    public static final long _ctpEqual = 1L;
    public static final long _ctpNotEqual = 2L;
    public static final long _no = 3L;

    private EqualType()
    {
      super.putEnum(Long.valueOf(0L), "端口同速");
      super.putEnum(Long.valueOf(1L), "时隙同速");
      super.putEnum(Long.valueOf(2L), "时隙不同速");
      super.putEnum(Long.valueOf(3L), "不确定");
    }
  }

  public static class LostPathType extends GenericEnum
  {
    public static final long _notLost = 0L;
    public static final long _topoLost = 1L;
    public static final long _crossLost = 2L;

    private LostPathType()
    {
      super.putEnum(Long.valueOf(0L), "不残缺");
      super.putEnum(Long.valueOf(1L), "拓扑残缺");
      super.putEnum(Long.valueOf(2L), "交叉残缺");
    }
  }

  public static class OwnerShip extends GenericEnum
  {
    public static final long _self = 1L;
    public static final long _hj = 2L;
    public static final long _leasehold = 3L;
    public static final long _hh = 4L;

    private OwnerShip()
    {
      super.putEnum(Long.valueOf(1L), "自建");
      super.putEnum(Long.valueOf(2L), "合建");
      super.putEnum(Long.valueOf(3L), "租用");
      super.putEnum(Long.valueOf(4L), "混合");
    }
  }

  public static class SysDirection extends GenericEnum
  {
    public static final long a = 1L;
    public static final long b = 2L;

    private SysDirection()
    {
      super.putEnum(Long.valueOf(1L), "A向");
      super.putEnum(Long.valueOf(2L), "B向");
    }
  }

  public static class PathMakeFlag extends GenericEnum
  {
    public static final long waitcheck = 1L;
    public static final long seccess = 2L;
    public static final long failure = 3L;
    public static final long partSuccess = 4L;

    private PathMakeFlag()
    {
      super.putEnum(Long.valueOf(1L), "待核查");
      super.putEnum(Long.valueOf(2L), "成功");
      super.putEnum(Long.valueOf(3L), "失败");
      super.putEnum(Long.valueOf(4L), "部分成功");
    }
  }

  public static class CreateType extends GenericEnum
  {
    public static final long preconf = 1L;
    public static final long nopreconf = 2L;

    private CreateType()
    {
      super.putEnum(Long.valueOf(1L), "预配");
      super.putEnum(Long.valueOf(2L), "非预配");
    }
  }

  public static class Direction extends GenericEnum
  {
    public static final long twoway = 1L;
    public static final long oneway = 2L;

    private Direction()
    {
      super.putEnum(Long.valueOf(1L), "双向");
      super.putEnum(Long.valueOf(2L), "单向");
    }
  }

  public static class TransSubPathType extends GenericEnum
  {
    public static final long text = 1L;
    public static final long notext = 2L;

    private TransSubPathType()
    {
      super.putEnum(Long.valueOf(1L), "文本");
      super.putEnum(Long.valueOf(2L), "非文本");
    }
  }

  public static class TransPathType extends GenericEnum
  {
    public static final long sdh = 1L;
    public static final long optical = 2L;
    public static final long mstp = 3L;

    private TransPathType()
    {
      super.putEnum(Long.valueOf(1L), "通道");
      super.putEnum(Long.valueOf(2L), "光波道");
      super.putEnum(Long.valueOf(3L), "mstp通道");
    }
  }

  public static class TransPathStateType extends GenericEnum
  {
    public static final long _idle = 1L;
    public static final long _inuse = 2L;
    public static final long _preuse = 3L;
    public static final long _prerelease = 4L;
    public static final long _precreate = 5L;
    public static final long _bad = 6L;
    public static final long _prereleaseop = 7L;

    private TransPathStateType()
    {
      super.putEnum(Long.valueOf(1L), "空闲");
      super.putEnum(Long.valueOf(2L), "已用");
      super.putEnum(Long.valueOf(3L), "预占");
      super.putEnum(Long.valueOf(4L), "冗余");
      super.putEnum(Long.valueOf(5L), "预创建");
      super.putEnum(Long.valueOf(6L), "损坏");
      super.putEnum(Long.valueOf(7L), "冗余(备波)");
    }
  }

  public static class GzPathCheckFlag extends GenericEnum
  {
    public static final long _check = 1L;
    public static final long _success = 2L;
    public static final long _failed = 3L;
    public static final long _subsuccess = 4L;
    public static final long _checking = 5L;

    private GzPathCheckFlag()
    {
      super.putEnum(Long.valueOf(1L), "待核查");
      super.putEnum(Long.valueOf(2L), "成功");
      super.putEnum(Long.valueOf(3L), "失败");
      super.putEnum(Long.valueOf(4L), "部分成功");
      super.putEnum(Long.valueOf(5L), "正在核查");
    }
  }

  public static class ActionType extends GenericEnum
  {
    public static final long _install = 1L;
    public static final long _uninstall = 2L;

    private ActionType()
    {
      super.putEnum(Long.valueOf(1L), "安装");
      super.putEnum(Long.valueOf(2L), "拆除");
    }
  }

  public static class GzPathEndType extends GenericEnum
  {
    public static final long _no_ld = 0L;
    public static final long _card = 1L;
    public static final long _ctp = 2L;

    private GzPathEndType()
    {
      super.putEnum(Long.valueOf(0L), "未落地");
      super.putEnum(Long.valueOf(1L), "机盘");
      super.putEnum(Long.valueOf(2L), "光口时隙");
    }
  }

  public static class EndAttempType extends GenericEnum
  {
    public static final long _pre = 0L;
    public static final long _attemp = 1L;

    private EndAttempType()
    {
      super.putEnum(Long.valueOf(0L), "端口预配");
      super.putEnum(Long.valueOf(1L), "调度增加");
    }
  }

  public static class GzUseState extends GenericEnum
  {
    public static final long _free = 1L;
    public static final long _used = 2L;
    public static final long _subused = 3L;

    private GzUseState()
    {
      super.putEnum(Long.valueOf(1L), "空闲");
      super.putEnum(Long.valueOf(2L), "占用");
      super.putEnum(Long.valueOf(3L), "部分占用");
    }
  }

  public static class GzInputType extends GenericEnum
  {
    public static final long _import = 0L;
    public static final long _edit = 1L;
    public static final long _sheet = 2L;

    private GzInputType()
    {
      super.putEnum(Long.valueOf(0L), "导入");
      super.putEnum(Long.valueOf(1L), "编辑");
      super.putEnum(Long.valueOf(2L), "调度");
    }
  }

  public static class GzEndType extends GenericEnum
  {
    public static final int _NORMAL = 0;
    public static final int _CARDTYPE = 1;
    public static final int _OPTYPE = 2;

    private GzEndType()
    {
      super.putEnum(Integer.valueOf(0), "0");
      super.putEnum(Integer.valueOf(1), "1");
      super.putEnum(Integer.valueOf(2), "2");
    }
  }

  public static class GzLowerDivideRule extends GenericEnum
  {
    public static final int _VC12 = 111;
    public static final int _VC4 = 155;
    public static final int _VC333 = 333;
    public static final int _VC331 = 331;
    public static final int _VC313 = 313;
    public static final int _VC133 = 133;
    public static final int _VC311 = 311;
    public static final int _VC131 = 131;
    public static final int _VC113 = 113;
    public static final int _VC444 = 444;
    public static final int _VC441 = 441;
    public static final int _VC414 = 414;
    public static final int _VC144 = 144;
    public static final int _VC411 = 411;
    public static final int _VC141 = 141;
    public static final int _VC114 = 114;

    private GzLowerDivideRule()
    {
      super.putEnum(Integer.valueOf(111), "TU12 TU12 TU12");
      super.putEnum(Integer.valueOf(155), "VC4(155M)");
      super.putEnum(Integer.valueOf(333), "TU3 TU3 TU3");
      super.putEnum(Integer.valueOf(331), "TU3 TU3 TU12");
      super.putEnum(Integer.valueOf(313), "TU3 TU12 TU3");
      super.putEnum(Integer.valueOf(133), "TU12 TU3 TU3");
      super.putEnum(Integer.valueOf(311), "TU3 TU12 TU12");
      super.putEnum(Integer.valueOf(131), "TU12 TU3 TU12");
      super.putEnum(Integer.valueOf(113), "TU12 TU12 TU3");
      super.putEnum(Integer.valueOf(444), "TU3(45M)_TU3(45M)_TU3(45M)");
      super.putEnum(Integer.valueOf(441), "TU3(45M)_TU3(45M)_TU12");
      super.putEnum(Integer.valueOf(414), "TU3(45M)_TU12_TU3(45M)");
      super.putEnum(Integer.valueOf(144), "TU12_TU3(45M)_TU3(45M)");
      super.putEnum(Integer.valueOf(411), "TU3(45M)_TU12_TU12");
      super.putEnum(Integer.valueOf(141), "TU12_TU3(45M)_TU12");
      super.putEnum(Integer.valueOf(114), "TU12_TU12_TU3(45M)");
    }

    public static List<GenericDO> getRuleList(String rule) {
      List ruleList = new ArrayList();
      int ruleInt = Integer.parseInt(rule);
      if (111 == ruleInt) {
        for (int i = 0; i < 63; i++) {
          GenericDO gdo = new GenericDO();
          gdo.setAttrValue("num", i + 1);
          gdo.setAttrValue("tug3", i % 3 + 1);
          gdo.setAttrValue("tug2", Math.round(i / 3) % 7 + 1);
          gdo.setAttrValue("tu12", Math.round(i / 21) + 1);
          gdo.setAttrValue("capacity", "2M");
          gdo.setAttrValue("name", "2M" + (i + 1));
          gdo.setAttrValue("state", "空闲");
          ruleList.add(gdo);
        }
      } else if (155 == ruleInt) {
        GenericDO gdo = new GenericDO();
        gdo.setAttrValue("num", "-");
        gdo.setAttrValue("tug3", "-");
        gdo.setAttrValue("tug2", "-");
        gdo.setAttrValue("tu12", "-");
        gdo.setAttrValue("capacity", "155M");
        gdo.setAttrValue("name", "155M1");
        gdo.setAttrValue("state", "空闲");
        ruleList.add(gdo);
      } else if ((333 == ruleInt) || (444 == ruleInt)) {
        for (int i = 0; i < 3; i++) {
          GenericDO gdo = new GenericDO();
          gdo.setAttrValue("num", "-");
          gdo.setAttrValue("tug3", i + 1);
          gdo.setAttrValue("tug2", "-");
          gdo.setAttrValue("tu12", "-");
          gdo.setAttrValue("capacity", "34M");
          gdo.setAttrValue("name", "34M" + (i + 1));
          gdo.setAttrValue("state", "空闲");
          ruleList.add(gdo);
        }
      } else if ((331 == ruleInt) || (313 == ruleInt) || (133 == ruleInt) || (441 == ruleInt) || (414 == ruleInt) || (144 == ruleInt))
      {
        for (int i = 0; i < 2; i++) {
          GenericDO gdo = new GenericDO();
          gdo.setAttrValue("num", "-");
          gdo.setAttrValue("tug3", i + 1);
          gdo.setAttrValue("tug2", "-");
          gdo.setAttrValue("tu12", "-");
          gdo.setAttrValue("capacity", "34M");
          gdo.setAttrValue("name", "34M" + (i + 1));
          gdo.setAttrValue("state", "空闲");
          ruleList.add(gdo);
        }
        for (int i = 0; i < 63; i++)
          if ((i + 1) % 3 == 0)
          {
            GenericDO gdo = new GenericDO();
            gdo.setAttrValue("num", i + 1);
            gdo.setAttrValue("tug3", i % 3 + 1);
            gdo.setAttrValue("tug2", Math.round(i / 3) % 7 + 1);
            gdo.setAttrValue("tu12", Math.round(i / 21) + 1);
            gdo.setAttrValue("capacity", "2M");
            gdo.setAttrValue("name", "2M" + (i + 1));
            gdo.setAttrValue("state", "空闲");
            ruleList.add(gdo);
          }
      } else if ((311 == ruleInt) || (131 == ruleInt) || (113 == ruleInt) || (411 == ruleInt) || (141 == ruleInt) || (114 == ruleInt))
      {
        GenericDO gdo = new GenericDO();
        gdo.setAttrValue("num", "-");
        gdo.setAttrValue("tug3", 1);
        gdo.setAttrValue("tug2", "-");
        gdo.setAttrValue("tu12", "-");
        gdo.setAttrValue("capacity", "34M");
        gdo.setAttrValue("name", "34M1");
        gdo.setAttrValue("state", "空闲");
        ruleList.add(gdo);
        for (int i = 0; i < 63; i++) {
          if (i % 3 != 0)
          {
            GenericDO gdo2 = new GenericDO();
            gdo2.setAttrValue("num", i + 1);
            gdo2.setAttrValue("tug3", i % 3 + 1);
            gdo2.setAttrValue("tug2", Math.round(i / 3) % 7 + 1);
            gdo2.setAttrValue("tu12", Math.round(i / 21) + 1);
            gdo2.setAttrValue("capacity", "2M");
            gdo2.setAttrValue("name", "2M" + (i + 1));
            gdo2.setAttrValue("state", "空闲");
            ruleList.add(gdo2);
          }
        }
      }
      return ruleList;
    }

    public static Map<String, GenericDO> getRuleMap(String rule) {
      Map ruleMap = new HashMap();
      int ruleInt = Integer.parseInt(rule);
      if (111 == ruleInt) {
        for (int i = 0; i < 63; i++) {
          GenericDO gdo = new GenericDO();
          gdo.setAttrValue("num", i + 1);
          gdo.setAttrValue("tug3", i % 3 + 1);
          gdo.setAttrValue("tug2", Math.round(i / 3) % 7 + 1);
          gdo.setAttrValue("tu12", Math.round(i / 21) + 1);
          gdo.setAttrValue("capacity", "2M");
          gdo.setAttrValue("name", "2M" + (i + 1));
          gdo.setAttrValue("state", "空闲");
          ruleMap.put("2M" + (i + 1), gdo);
        }
      } else if (155 == ruleInt) {
        GenericDO gdo = new GenericDO();
        gdo.setAttrValue("num", "-");
        gdo.setAttrValue("tug3", "-");
        gdo.setAttrValue("tug2", "-");
        gdo.setAttrValue("tu12", "-");
        gdo.setAttrValue("capacity", "155M");
        gdo.setAttrValue("name", "155M1");
        gdo.setAttrValue("state", "空闲");
        ruleMap.put("155M1", gdo);
      } else if ((333 == ruleInt) || (444 == ruleInt)) {
        for (int i = 0; i < 3; i++) {
          GenericDO gdo = new GenericDO();
          gdo.setAttrValue("num", "-");
          gdo.setAttrValue("tug3", i + 1);
          gdo.setAttrValue("tug2", "-");
          gdo.setAttrValue("tu12", "-");
          gdo.setAttrValue("capacity", "34M");
          gdo.setAttrValue("name", "34M" + (i + 1));
          gdo.setAttrValue("state", "空闲");
          ruleMap.put("34M" + (i + 1), gdo);
        }
      } else if ((331 == ruleInt) || (313 == ruleInt) || (133 == ruleInt) || (441 == ruleInt) || (414 == ruleInt) || (144 == ruleInt))
      {
        for (int i = 0; i < 2; i++) {
          GenericDO gdo = new GenericDO();
          gdo.setAttrValue("num", "-");
          gdo.setAttrValue("tug3", i + 1);
          gdo.setAttrValue("tug2", "-");
          gdo.setAttrValue("tu12", "-");
          gdo.setAttrValue("capacity", "34M");
          gdo.setAttrValue("name", "34M" + (i + 1));
          gdo.setAttrValue("state", "空闲");
          ruleMap.put("34M" + (i + 1), gdo);
        }
        for (int i = 0; i < 63; i++)
          if ((i + 1) % 3 == 0)
          {
            GenericDO gdo = new GenericDO();
            gdo.setAttrValue("num", i + 1);
            gdo.setAttrValue("tug3", i % 3 + 1);
            gdo.setAttrValue("tug2", Math.round(i / 3) % 7 + 1);
            gdo.setAttrValue("tu12", Math.round(i / 21) + 1);
            gdo.setAttrValue("capacity", "2M");
            gdo.setAttrValue("name", "2M" + (i + 1));
            gdo.setAttrValue("state", "空闲");
            ruleMap.put("2M" + (i + 1), gdo);
          }
      } else if ((311 == ruleInt) || (131 == ruleInt) || (113 == ruleInt) || (411 == ruleInt) || (141 == ruleInt) || (114 == ruleInt))
      {
        GenericDO gdo = new GenericDO();
        gdo.setAttrValue("num", "-");
        gdo.setAttrValue("tug3", 1);
        gdo.setAttrValue("tug2", "-");
        gdo.setAttrValue("tu12", "-");
        gdo.setAttrValue("capacity", "34M");
        gdo.setAttrValue("name", "34M1");
        gdo.setAttrValue("state", "空闲");
        ruleMap.put("34M1", gdo);
        for (int i = 0; i < 63; i++) {
          if (i % 3 != 0)
          {
            GenericDO gdo2 = new GenericDO();
            gdo2.setAttrValue("num", i + 1);
            gdo2.setAttrValue("tug3", i % 3 + 1);
            gdo2.setAttrValue("tug2", Math.round(i / 3) % 7 + 1);
            gdo2.setAttrValue("tu12", Math.round(i / 21) + 1);
            gdo2.setAttrValue("capacity", "2M");
            gdo2.setAttrValue("name", "2M" + (i + 1));
            gdo2.setAttrValue("state", "空闲");
            ruleMap.put("2M" + (i + 1), gdo);
          }
        }
      }
      return ruleMap;
    }
  }
}