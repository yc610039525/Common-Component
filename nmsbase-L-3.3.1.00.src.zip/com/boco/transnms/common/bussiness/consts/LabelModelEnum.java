package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class LabelModelEnum
{
  public static final LabelType LABEL_TYPE = new LabelType(null);

  public static class LabelType extends GenericEnum { public static final long _devrack = 1L;
    public static final long _subrack = 2L;
    public static final long _ddfrack = 3L;
    public static final long _ddfmodule = 4L;
    public static final long _odfrack = 5L;
    public static final long _np = 6L;
    public static final long _other = 7L;

    private LabelType() { super.putEnum(Long.valueOf(1L), "传输设备机架标签");
      super.putEnum(Long.valueOf(2L), "传输子架标签");
      super.putEnum(Long.valueOf(3L), "DDF机架标签");
      super.putEnum(Long.valueOf(4L), "DDF架端子标签");
      super.putEnum(Long.valueOf(5L), "ODF机架标签");
      super.putEnum(Long.valueOf(6L), "备品备件标签");
      super.putEnum(Long.valueOf(7L), "其它标签");
    }
  }
}