package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class AttempStateEnum
{
  public static final AppState ATTEMP_APP_STAT = new AppState(null);
  public static final DgnState ATTEMP_DGN_STAT = new DgnState(null);
  public static final GlDgnState ATTEMP_GL_DGN_STAT = new GlDgnState(null);
  public static final RplState ATTEMP_RPL_STAT = new RplState(null);
  public static final RplStateQuery ATTEMP_RPL_STAT_QUERY = new RplStateQuery(null);
  public static final SheetDirection SHEET_DIRECTION = new SheetDirection(null);
  public static final UnicomDgnState UNI_DGN_STAT = new UnicomDgnState(null);

  public static final PtnCheckState PTN_CHECK_STATE = new PtnCheckState(null);

  public static class SheetDirection extends GenericEnum
  {
    public static final long _directionUp = 1L;
    public static final long _directionDown = 2L;
    public static final long _sendOtherPepole = -1L;
    public static final long _cancelApprove = 3L;
    public static final long _delete = 4L;
    public static final long _designCommit = 5L;
    public static final long _archive = 6L;
    public static final long _re_reply = 7L;
    public static final long _sendBackPeople = 8L;

    private SheetDirection()
    {
      super.putEnum(Long.valueOf(1L), "向上");
      super.putEnum(Long.valueOf(2L), "向下");
      super.putEnum(Long.valueOf(-1L), "转发其他人/部门");
      super.putEnum(Long.valueOf(3L), "取消审核");
      super.putEnum(Long.valueOf(4L), "删除");
      super.putEnum(Long.valueOf(5L), "设计提交");
      super.putEnum(Long.valueOf(6L), "直接归档");
      super.putEnum(Long.valueOf(7L), "再次回单");
      super.putEnum(Long.valueOf(8L), "转发到主审");
    }
  }

  public static class RplStateQuery extends GenericEnum
  {
    public static final long _reply = 2L;
    public static final long _re_reply = 3L;
    public static final long _archive = 10L;

    private RplStateQuery()
    {
      super.putEnum(Long.valueOf(2L), "填写回单");
      super.putEnum(Long.valueOf(3L), "再次回单");
      super.putEnum(Long.valueOf(10L), "归档");
    }
  }

  public static class RplState extends GenericEnum
  {
    public static final long _edit = 1L;
    public static final long _reply = 2L;
    public static final long _re_reply = 3L;
    public static final long _pre_archive = 4L;
    public static final long _archive = 10L;

    private RplState()
    {
      super.putEnum(Long.valueOf(1L), "收单");
      super.putEnum(Long.valueOf(2L), "填写回单");
      super.putEnum(Long.valueOf(3L), "再次回单");
      super.putEnum(Long.valueOf(4L), "待归档");
      super.putEnum(Long.valueOf(10L), "归档");
    }
  }

  public static class DgnState extends GenericEnum
  {
    public static final long _edit = 1L;
    public static final long _approve = 3L;
    public static final long _dispatch = 4L;
    public static final long _trans_complete = 5L;
    public static final long _service_complete = 6L;
    public static final long _re_approve = 7L;
    public static final long _recycle_approve = 8L;
    public static final long _archive = 10L;

    private DgnState()
    {
      super.putEnum(Long.valueOf(1L), "新建");

      super.putEnum(Long.valueOf(3L), "审核");
      super.putEnum(Long.valueOf(4L), "派发");
      super.putEnum(Long.valueOf(5L), "传输竣工");
      super.putEnum(Long.valueOf(6L), "业务竣工");
      super.putEnum(Long.valueOf(10L), "归档");
      super.putEnum(Long.valueOf(7L), "重新审核");
      super.putEnum(Long.valueOf(8L), "审核未通过");
    }
  }

  public static class GlDgnState extends GenericEnum
  {
    public static final long _edit = 1L;
    public static final long _approve = 3L;
    public static final long _dispatch = 4L;
    public static final long _trans_complete = 5L;
    public static final long _re_approve = 7L;
    public static final long _recycle_approve = 8L;
    public static final long _archive = 10L;

    private GlDgnState()
    {
      super.putEnum(Long.valueOf(1L), "新建");

      super.putEnum(Long.valueOf(3L), "审核");
      super.putEnum(Long.valueOf(4L), "派发");
      super.putEnum(Long.valueOf(5L), "传输竣工");

      super.putEnum(Long.valueOf(10L), "归档");
      super.putEnum(Long.valueOf(7L), "重新审核");
      super.putEnum(Long.valueOf(8L), "审核未通过");
    }
  }

  public static class AppState extends GenericEnum
  {
    public static final long _edit = 1L;
    public static final long _recycle_approve = 2L;
    public static final long _recycle_check = 3L;
    public static final long _approve = 4L;
    public static final long _confirm = 5L;
    public static final long _receive = 6L;
    public static final long _resource_check = 7L;
    public static final long _recycle_receive = 8L;
    public static final long _archive = 10L;

    private AppState()
    {
      super.putEnum(Long.valueOf(1L), "新建");
      super.putEnum(Long.valueOf(2L), "审核不通过回收");
      super.putEnum(Long.valueOf(3L), "核查不通过回收");
      super.putEnum(Long.valueOf(8L), "签收不通过回收");
      super.putEnum(Long.valueOf(5L), "确认");
      super.putEnum(Long.valueOf(4L), "审核");
      super.putEnum(Long.valueOf(6L), "签收");
      super.putEnum(Long.valueOf(7L), "资源核查");
      super.putEnum(Long.valueOf(10L), "归档");
    }
  }

  public static class UnicomDgnState extends GenericEnum
  {
    public static final long _prepare = 1L;
    public static final long _edit = 2L;
    public static final long _reject = 3L;
    public static final long _designCommit = 4L;
    public static final long _archive = 10L;

    private UnicomDgnState()
    {
      super.putEnum(Long.valueOf(1L), "待收单");
      super.putEnum(Long.valueOf(2L), "编辑");
      super.putEnum(Long.valueOf(3L), "拒收");
      super.putEnum(Long.valueOf(4L), "设计提交");
      super.putEnum(Long.valueOf(10L), "归档");
    }
  }

  public static class PtnCheckState extends GenericEnum
  {
    public static final long _no_check = 1L;
    public static final long _checked_same = 2L;
    public static final long _checked_not_same = 3L;
    public static final long _gather_field = 4L;
    public static final long _checking = 5L;

    private PtnCheckState()
    {
      super.putEnum(Long.valueOf(1L), "未核查");
      super.putEnum(Long.valueOf(2L), "核查一致");
      super.putEnum(Long.valueOf(3L), "核查不一致");
      super.putEnum(Long.valueOf(4L), "采集失败");
      super.putEnum(Long.valueOf(5L), "正在核查");
    }
  }
}