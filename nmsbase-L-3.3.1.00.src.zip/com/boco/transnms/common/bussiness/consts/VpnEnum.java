package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class VpnEnum
{
  public static final VpAppClass VP_APP_CLASS = new VpAppClass(null);

  public static final SvcClass SVC_CLASS = new SvcClass(null);
  public static final AppClass APP_CLASS = new AppClass(null);
  public static final SendWay SEND_WAY = new SendWay(null);
  public static final VpnAppClas VPNAPP_CLAS = new VpnAppClas(null);

  public static class SendWay extends GenericEnum
  {
    public static final int _mail = 1;
    public static final int _fax = 2;

    private SendWay()
    {
      super.putEnum(Integer.valueOf(1), "邮件");
      super.putEnum(Integer.valueOf(2), "传真");
    }
  }

  public static class AppClass extends GenericEnum
  {
    public static final int _stream = 1;
    public static final int _txt = 2;
    public static final int _dat = 3;
    public static final int _voip = 4;
    public static final int _oth = 5;
    public static final int _unk = 6;

    private AppClass()
    {
      super.putEnum(Integer.valueOf(1), "流媒体");
      super.putEnum(Integer.valueOf(2), "简单文本传送");
      super.putEnum(Integer.valueOf(3), "数据库访问");
      super.putEnum(Integer.valueOf(4), "VOIP");
      super.putEnum(Integer.valueOf(5), "其它");
      super.putEnum(Integer.valueOf(6), "未知");
    }
  }

  public static class SvcClass extends GenericEnum
  {
    public static final int _trans = 1;
    public static final int _ip = 2;
    public static final int _atm = 3;
    public static final int _ddn = 4;
    public static final int _acc = 5;

    private SvcClass()
    {
      super.putEnum(Integer.valueOf(1), "传输");
      super.putEnum(Integer.valueOf(2), "IP");
      super.putEnum(Integer.valueOf(3), "ATM");
      super.putEnum(Integer.valueOf(4), "DDN");
      super.putEnum(Integer.valueOf(5), "接入网");
    }
  }

  public static class VpnAppClas extends GenericEnum
  {
    public static final String _stream = "1";
    public static final String _txt = "2";
    public static final String _dat = "3";
    public static final String _voip = "4";
    public static final String _oth = "5";
    public static final String _unk = "6";

    private VpnAppClas()
    {
      super.putEnum("1", "流媒体");
      super.putEnum("2", "简单文本传送");
      super.putEnum("3", "数据库访问");
      super.putEnum("4", "VOIP");
      super.putEnum("5", "其它");
      super.putEnum("6", "未知");
    }
  }

  public static class VpAppClass extends GenericEnum
  {
    public static final int _stream = 1;
    public static final int _txt = 2;
    public static final int _dat = 3;
    public static final int _voip = 4;
    public static final int _oth = 5;
    public static final int _unk = 6;

    private VpAppClass()
    {
      super.putEnum(Integer.valueOf(1), "流媒体");
      super.putEnum(Integer.valueOf(2), "简单文本传送");
      super.putEnum(Integer.valueOf(3), "数据库访问");
      super.putEnum(Integer.valueOf(4), "VOIP");
      super.putEnum(Integer.valueOf(5), "其它");
      super.putEnum(Integer.valueOf(6), "未知");
    }
  }
}