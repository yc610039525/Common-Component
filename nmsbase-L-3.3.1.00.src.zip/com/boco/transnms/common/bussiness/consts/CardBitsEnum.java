package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class CardBitsEnum extends GenericEnum
{
  public static final CardType CARD_KIND = new CardType(null);
  public static final OwnerShip OWNERSHIP = new OwnerShip(null);

  public static class OwnerShip extends GenericEnum
  {
    public static final long _self = 1L;
    public static final long _rent = 2L;

    private OwnerShip()
    {
      super.putEnum(Long.valueOf(1L), "自建");
      super.putEnum(Long.valueOf(2L), "租用");
    }
  }

  public static class CardType extends GenericEnum
  {
    public static final long _input = 1L;
    public static final long _output = 2L;

    private CardType()
    {
      super.putEnum(Long.valueOf(1L), "输入");
      super.putEnum(Long.valueOf(2L), "输出");
    }
  }
}