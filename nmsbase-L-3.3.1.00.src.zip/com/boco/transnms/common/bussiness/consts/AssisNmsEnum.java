package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class AssisNmsEnum extends GenericEnum
{
  public static final SystemType SYSTEM_TYPE = new SystemType(null);
  public static final ManageDevType MANAGE_DEV_TYPE = new ManageDevType(null);
  public static final UseState USE_STATE = new UseState(null);

  public static class UseState extends GenericEnum
  {
    public static final long _IN = 1L;
    public static final long _NO = 2L;

    private UseState()
    {
      super.putEnum(Long.valueOf(1L), "使用");
      super.putEnum(Long.valueOf(2L), "不使用");
    }
  }

  public static class ManageDevType extends GenericEnum
  {
    public static final long _NO = 1L;
    public static final long _SDH = 2L;
    public static final long _WDM = 3L;
    public static final long _MIX = 4L;

    private ManageDevType()
    {
      super.putEnum(Long.valueOf(1L), "无");
      super.putEnum(Long.valueOf(2L), "SDH");
      super.putEnum(Long.valueOf(3L), "WDM");
      super.putEnum(Long.valueOf(4L), "混合");
    }
  }

  public static class SystemType extends GenericEnum
  {
    public static final long _NKW = 1L;

    private SystemType()
    {
      super.putEnum(Long.valueOf(1L), "LCT");
    }
  }
}