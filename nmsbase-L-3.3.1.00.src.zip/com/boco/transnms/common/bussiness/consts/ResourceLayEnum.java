package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class ResourceLayEnum
{
  public static Rate RATE = new Rate(null);
  public static UseState USE_STATE = new UseState(null);
  public static CheckFlag CHECK_FLAG = new CheckFlag(null);
  public static CrossLevel CROSS_LEVEL = new CrossLevel(null);

  public static class CrossLevel extends GenericEnum
  {
    public static final long _vc4 = 1L;
    public static final long _vc3 = 2L;
    public static final long _vc12 = 3L;

    private CrossLevel()
    {
      super.putEnum(Long.valueOf(1L), "VC4");
      super.putEnum(Long.valueOf(2L), "VC3");
      super.putEnum(Long.valueOf(3L), "VC12");
    }
  }

  public static class CheckFlag extends GenericEnum
  {
    public static final long _not_check = 1L;
    public static final long _success = 2L;
    public static final long _failed = 3L;
    public static final long _part_success = 4L;

    private CheckFlag()
    {
      super.putEnum(Long.valueOf(1L), "待核查");
      super.putEnum(Long.valueOf(2L), "成功");
      super.putEnum(Long.valueOf(3L), "失败");
      super.putEnum(Long.valueOf(4L), "部分成功");
    }
  }

  public static class UseState extends GenericEnum
  {
    public static final long _free = 1L;
    public static final long _used = 2L;

    private UseState()
    {
      super.putEnum(Long.valueOf(1L), "空闲");
      super.putEnum(Long.valueOf(2L), "占用");
    }
  }

  public static class Rate extends GenericEnum
  {
    public static final long _2M = 1L;
    public static final long _155M = 9L;

    private Rate()
    {
      super.putEnum(Long.valueOf(1L), "2M");
      super.putEnum(Long.valueOf(9L), "155M");
    }
  }
}