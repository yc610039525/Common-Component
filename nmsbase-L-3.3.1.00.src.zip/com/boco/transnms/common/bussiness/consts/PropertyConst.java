package com.boco.transnms.common.bussiness.consts;

public class PropertyConst
{
  public static final String RelatedSpaceCuid = "RELATED_SPACE_CUID";
  public static final String longitude = "LONGITUDE";
  public static final String latitude = "LATITUDE";
  public static final String RelatedDistrictCuid = "RELATED_DISTRICT_CUID";
  public static final String TEMPLATE_DATA_PIC_FLAG = "DATA_PIC";
  public static final String TEMPLATE_CHILD_ELEMENT = "ELEMENT_CHILD_OBJECT";
  public static final String TEMPLATE_SYSTEM_NUMBER = "SYSTEM_NUMBER";
  public static final String TEMPLATE_SLOT_PAIR_FLAG = "SLOT_PAIR";
}