package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class SchedulerEnum
{
  public static final JobGroupName JOB_GROUP_NAME = new JobGroupName(null);
  public static final JobGropuNameLable JOB_GROUP_NAME_LABEL = new JobGropuNameLable(null);
  public static final Frequency FREQUENCY = new Frequency(null);
  public static final JobState JOBSTATE = new JobState(null);

  public static class JobState extends GenericEnum
  {
    public static final long _activation = 1L;
    public static final long _hang = 2L;

    private JobState()
    {
      super.putEnum(Long.valueOf(1L), "激活");
      super.putEnum(Long.valueOf(2L), "挂起");
    }
  }

  public static class Frequency extends GenericEnum
  {
    public static final long _day = 1L;
    public static final long _week = 2L;
    public static final long _month = 3L;

    private Frequency()
    {
      super.putEnum(Long.valueOf(1L), "每日");
      super.putEnum(Long.valueOf(2L), "每周");
      super.putEnum(Long.valueOf(3L), "每月");
    }
  }

  public static class JobGropuNameLable extends GenericEnum
  {
    public static final long _updateOMSLength = 1L;
    public static final long _updateElementVol = 2L;
    public static final long _networkAdjustExecGroup = 3L;
    public static final long _netAdjustShieldAlarm = 4L;
    public static final long _netAdjustCheckCollectTask = 5L;
    public static final long _netAdjustCheckTraphTask = 6L;

    private JobGropuNameLable()
    {
      super.putEnum(Long.valueOf(1L), "光复用段长度维护");
      super.putEnum(Long.valueOf(2L), "传输网元容量维护");
      super.putEnum(Long.valueOf(3L), "网络调整定时任务");
      super.putEnum(Long.valueOf(4L), "网络调整屏蔽告警定时任务");
      super.putEnum(Long.valueOf(5L), "网络调整采集任务核查");
      super.putEnum(Long.valueOf(6L), "网络调整电路核查");
    }
  }

  public static class JobGroupName extends GenericEnum
  {
    public static final long _updateOMSLength = 1L;
    public static final long _updateElementVol = 2L;
    public static final long _networkAdjustExecGroup = 3L;
    public static final long _netAdjustShieldAlarm = 4L;
    public static final long _netAdjustCheckCollectTask = 5L;
    public static final long _netAdjustCheckTraphTask = 6L;
    public static final long _opticalMakeCheckTaskTiming = 7L;

    private JobGroupName()
    {
      super.putEnum(Long.valueOf(1L), "updateOMSLength");
      super.putEnum(Long.valueOf(2L), "updateElementVol");
      super.putEnum(Long.valueOf(3L), "networkAdjustExecGroup");
      super.putEnum(Long.valueOf(4L), "netAdjustShieldAlarm");
      super.putEnum(Long.valueOf(5L), "netAdjustCheckCollectTask");
      super.putEnum(Long.valueOf(6L), "netAdjustCheckTraphTask");
      super.putEnum(Long.valueOf(7L), "opticalMakeCheckTaskTiming");
    }
  }
}