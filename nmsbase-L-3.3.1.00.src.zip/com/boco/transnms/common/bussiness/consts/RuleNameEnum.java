package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class RuleNameEnum
{
  public static final RuleLevel RULE_LEVEL = new RuleLevel(null);

  public static class RuleLevel extends GenericEnum {
    public static final long _k = 1L;
    public static final long _n = 2L;
    public static final long _m = 3L;
    public static final long _p = 4L;

    private RuleLevel() {
      super.putEnum(Long.valueOf(1L), "一级(k)");
      super.putEnum(Long.valueOf(2L), "二级(n-k)");
      super.putEnum(Long.valueOf(3L), "三级(m-n-k)");
      super.putEnum(Long.valueOf(4L), "四级(p-m-n-k)");
    }
  }
}