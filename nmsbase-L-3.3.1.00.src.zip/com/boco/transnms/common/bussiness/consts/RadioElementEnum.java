package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class RadioElementEnum
{
  public static final SystemTypeFlag SYSTME_TYPE_FLAG = new SystemTypeFlag(null);
  public static final MaintMode MAINT_MODE = new MaintMode(null);

  public static class MaintMode extends GenericEnum
  {
    public static final long _self = 1L;
    public static final long _other = 2L;

    private MaintMode()
    {
      super.putEnum(Long.valueOf(1L), "自维");
      super.putEnum(Long.valueOf(2L), "代维");
    }
  }

  public static class SystemTypeFlag extends GenericEnum
  {
    public static final long _gsm900 = 1L;
    public static final long _gsm1800 = 2L;
    public static final long _gsm900to1800 = 3L;

    private SystemTypeFlag()
    {
      super.putEnum(Long.valueOf(1L), "GSM900系统");
      super.putEnum(Long.valueOf(2L), "GSM1800系统");
      super.putEnum(Long.valueOf(3L), "GSM900/1800系统");
    }
  }
}