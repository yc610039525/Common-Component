package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class AreaEnum
{
  public static final DistrictDataType DISTRICT_DATA_TYPE = new DistrictDataType(null);
  public static final DistrictSeviceLevelch DISTRICT_SEVICElEVEL_CH = new DistrictSeviceLevelch(null);
  public static final OLevel OLEVEL = new OLevel(null);
  public static final OwnerShip OWNER_SHIP = new OwnerShip(null);
  public static final RoomKeyType ROOM_KEY_TYPE = new RoomKeyType(null);
  public static final MaintMode MAINT_MODE = new MaintMode(null);
  public static final EquipState EQUIP_STATE = new EquipState(null);
  public static final OwnerShips OWNER_SHIPS = new OwnerShips(null);
  public static final VendorIcon VENDOR_ICON = new VendorIcon(null);
  public static final ServiceState SERVICE_STATE = new ServiceState(null);
  public static final DeviceType DEVICE_TYPE = new DeviceType(null);
  public static final ImportLLType IMPORTLL_TYPE = new ImportLLType(null);
  public static final LinePointType LINE_POINT_TYPE = new LinePointType(null);
  public static final OfficeType OFFICE_TYPE = new OfficeType(null);
  public static final StationDeviceType BASESTA_DEVICE_TYPE = new StationDeviceType(null);
  public static final TransMainDeviceType TRANS_MAIN_DEVICE_TYPE = new TransMainDeviceType(null);
  public static final ReceiveRoomType RECEIVE_ROOM_TYPE = new ReceiveRoomType(null);
  public static final SpecialLineLevel SPECIAL_LINE_LEVEL = new SpecialLineLevel(null);

  public static class SpecialLineLevel extends GenericEnum
  {
    public static final long _gold = 1L;
    public static final long _silver = 2L;
    public static final long _general = 3L;

    private SpecialLineLevel()
    {
      super.putEnum(Long.valueOf(1L), "金牌");
      super.putEnum(Long.valueOf(2L), "银牌");
      super.putEnum(Long.valueOf(3L), "普通");
    }
  }

  public static class ReceiveRoomType extends GenericEnum
  {
    public static final long _cpn = 1L;
    public static final long _sppl = 2L;

    private ReceiveRoomType()
    {
      super.putEnum(Long.valueOf(1L), "驻地网");
      super.putEnum(Long.valueOf(2L), "专线");
    }
  }

  public static class TransMainDeviceType extends GenericEnum
  {
    public static final long _sdh = 1L;
    public static final long _pdh = 2L;
    public static final long _wdm = 3L;
    public static final long _wave = 4L;
    public static final long _mix = 5L;
    public static final long _hdsl = 6L;
    public static final long _lightcat = 7L;
    public static final long _association = 8L;
    public static final long _2Mdirconnect = 9L;
    public static final long _unknow = 10L;

    private TransMainDeviceType()
    {
      super.putEnum(Long.valueOf(1L), "SDH");
      super.putEnum(Long.valueOf(2L), "PDH");
      super.putEnum(Long.valueOf(3L), "WDM");
      super.putEnum(Long.valueOf(4L), "微波");
      super.putEnum(Long.valueOf(5L), "混合");
      super.putEnum(Long.valueOf(6L), "HDSL");
      super.putEnum(Long.valueOf(7L), "光猫");
      super.putEnum(Long.valueOf(8L), "协转");
      super.putEnum(Long.valueOf(9L), "2M直连");
      super.putEnum(Long.valueOf(10L), "未知");
    }
  }

  public static class StationDeviceType extends GenericEnum
  {
    public static final long _900site = 1L;
    public static final long _1800site = 2L;
    public static final long _tdsite = 3L;

    private StationDeviceType()
    {
      super.putEnum(Long.valueOf(1L), "900");
      super.putEnum(Long.valueOf(2L), "1800");
      super.putEnum(Long.valueOf(3L), "TD");
    }
  }

  public static class OfficeType extends GenericEnum
  {
    public static final long _directly = 1L;
    public static final long _cooperation = 2L;

    private OfficeType()
    {
      super.putEnum(Long.valueOf(1L), "直属");
      super.putEnum(Long.valueOf(2L), "合作");
    }
  }

  public static class LinePointType extends GenericEnum
  {
    public static final long _optjoinbox = 1L;
    public static final long _optstraight = 2L;

    private LinePointType()
    {
      super.putEnum(Long.valueOf(1L), "光交接箱");
      super.putEnum(Long.valueOf(2L), "光纤直放站");
    }
  }

  public static class DeviceType extends GenericEnum
  {
    public static final String _ems = "INmsSystemBO";
    public static final String _element = "ITransElementBO";
    public static final String _bits = "ISynElementBO";
    public static final String _switchne = "ISwitchElementBO";
    public static final String _ddf = "IPhyDdfBO";
    public static final String _odf = "IPhyOdfBO";
    public static final String _phyrack = "IRackBO";
    public static final String _misrack = "IMiscRackBO";

    private DeviceType()
    {
      super.putEnum("INmsSystemBO", "NMS_SYSTEM");
      super.putEnum("ITransElementBO", "TRANS_ELEMENT");
      super.putEnum("ISynElementBO", "BITS");
      super.putEnum("ISwitchElementBO", "SWITCH_ELEMENT");
      super.putEnum("IPhyDdfBO", "DDF");
      super.putEnum("IPhyOdfBO", "ODF");
      super.putEnum("IRackBO", "RACK");
      super.putEnum("IMiscRackBO", "MISCRACK");
    }
  }

  public static class AreaSiteType extends GenericEnum
  {
    public static final long _GuGan = 1L;
    public static final long _HuiJu = 2L;
    public static final long _JieRu = 3L;
    public static final long _JiZhan = 4L;
    public static final long _FuWuTing = 5L;

    private static String getEnum(long id)
    {
      String value = "";
      if (id == 1L)
        value = "骨干";
      else if (id == 2L)
        value = "汇聚";
      else if (id == 3L)
        value = "接入";
      else if (id == 4L)
        value = "基站";
      else if (id == 5L) {
        value = "服务厅";
      }

      return value;
    }

    public static String getTypeName(String SiteType) {
      if ((SiteType == null) || (SiteType.trim().length() <= 0)) {
        return "";
      }
      String typeName = "";
      String[] typeCuids = SiteType.split(",");

      for (int i = 0; i < typeCuids.length; i++) {
        String typeCuid = typeCuids[i];
        if (typeName.length() != 0) {
          typeName = typeName + ",";
        }
        typeName = typeName + getEnum(Long.parseLong(typeCuid));
      }
      return typeName;
    }
  }

  public static class VendorIcon extends GenericEnum
  {
    public static final String _knowVendor = "/images/area/UnkownVendor.png";
    public static final String _huawei = "/images/area/huawei.png";
    public static final String _zhongxing = "/images/area/zhongxing.png";
    public static final String _langxun = "/images/area/langxun.png";

    private VendorIcon()
    {
      super.putEnum("/images/area/UnkownVendor.png", "未知");
      super.putEnum("/images/area/huawei.png", "华为");
      super.putEnum("/images/area/zhongxing.png", "中兴");
      super.putEnum("/images/area/langxun.png", "朗讯");
    }
  }

  public static class OLevel extends GenericEnum
  {
    public static final long _first = 1L;
    public static final long _second = 2L;
    public static final long _third = 3L;

    private OLevel()
    {
      super.putEnum(Long.valueOf(1L), "一级");
      super.putEnum(Long.valueOf(2L), "二级");
      super.putEnum(Long.valueOf(3L), "三级");
    }
  }

  public static class DistrictSeviceLevelch extends GenericEnum
  {
    public static final long _country = 0L;
    public static final long _province = 1L;
    public static final long _city = 2L;
    public static final long _county = 3L;
    public static final long _towns = 4L;
    public static final long _other = 5L;

    private DistrictSeviceLevelch()
    {
      super.putEnum(Long.valueOf(0L), "全国");
      super.putEnum(Long.valueOf(1L), "省级");
      super.putEnum(Long.valueOf(2L), "市级");
      super.putEnum(Long.valueOf(3L), "县级");
      super.putEnum(Long.valueOf(4L), "乡镇");
      super.putEnum(Long.valueOf(5L), "其他");
    }
  }

  public static class ImportLLType extends GenericEnum
  {
    public static final long _display = 1L;
    public static final long _real = 2L;
    public static final long _all = 3L;

    private ImportLLType()
    {
      super.putEnum(Long.valueOf(1L), "导入显示经纬度");
      super.putEnum(Long.valueOf(2L), "导入实际经纬度");
      super.putEnum(Long.valueOf(3L), "导入显示经纬度和实际经纬度");
    }
  }

  public static class DistrictDataType extends GenericEnum
  {
    public static final long _country = 1L;
    public static final long _province = 2L;
    public static final long _city = 3L;
    public static final long _county = 4L;
    public static final long _towns = 5L;

    private DistrictDataType()
    {
      super.putEnum(Long.valueOf(1L), "全国");
      super.putEnum(Long.valueOf(2L), "省");
      super.putEnum(Long.valueOf(3L), "市");
      super.putEnum(Long.valueOf(4L), "县");
      super.putEnum(Long.valueOf(5L), "乡镇");
    }
  }

  public static class EquipState extends GenericEnum
  {
    public static final long _design = 1L;
    public static final long _build = 2L;
    public static final long _completed = 3L;
    public static final long _abandoned = 4L;
    public static final long _maintenance = 5L;

    private EquipState()
    {
      super.putEnum(Long.valueOf(1L), "设计");
      super.putEnum(Long.valueOf(2L), "在建");
      super.putEnum(Long.valueOf(3L), "竣工");
      super.putEnum(Long.valueOf(4L), "废弃");
      super.putEnum(Long.valueOf(5L), "维护");
    }
  }

  public static class ServiceState extends GenericEnum
  {
    public static final long _service = 1L;
    public static final long _nonservice = 2L;
    public static final long _maintmode = 3L;
    public static final long _test = 4L;
    public static final long _distory = 5L;

    private ServiceState()
    {
      super.putEnum(Long.valueOf(1L), "服务");
      super.putEnum(Long.valueOf(2L), "未服务");
      super.putEnum(Long.valueOf(3L), "维护");
      super.putEnum(Long.valueOf(4L), "测试");
      super.putEnum(Long.valueOf(5L), "损坏");
    }
  }

  public static class MaintMode extends GenericEnum
  {
    public static final long _self = 1L;
    public static final long _other = 2L;

    private MaintMode()
    {
      super.putEnum(Long.valueOf(1L), "自维");
      super.putEnum(Long.valueOf(2L), "代维");
    }
  }

  public static class RoomKeyType extends GenericEnum
  {
    public static final long _gkey = 1L;
    public static final long _ekey = 2L;

    private RoomKeyType()
    {
      super.putEnum(Long.valueOf(1L), "普通钥匙");
      super.putEnum(Long.valueOf(2L), "电子钥匙");
    }
  }

  public static class OwnerShip extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _self = 1L;
    public static final long _gj = 2L;
    public static final long _hj = 3L;
    public static final long _leasehold = 4L;
    public static final long _gm = 5L;
    public static final long _zh = 6L;

    private OwnerShip()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "自建");
      super.putEnum(Long.valueOf(2L), "共建");
      super.putEnum(Long.valueOf(3L), "合建");
      super.putEnum(Long.valueOf(4L), "租用");
      super.putEnum(Long.valueOf(5L), "购买");
      super.putEnum(Long.valueOf(6L), "置换");
    }
  }

  public static class OwnerShips extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _self = 1L;
    public static final long _leasehold = 2L;

    private OwnerShips()
    {
      super.putEnum(Long.valueOf(1L), "自建");
      super.putEnum(Long.valueOf(2L), "租用");
      super.putEnum(Long.valueOf(0L), "未知");
    }
  }
}