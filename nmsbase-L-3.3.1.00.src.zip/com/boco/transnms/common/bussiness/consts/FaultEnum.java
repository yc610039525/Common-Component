package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class FaultEnum extends GenericEnum
{
  public static final FaultType FAULT_TYPE = new FaultType(null);
  public static final LineFaultType LINE_FAULT_TYPE = new LineFaultType(null);
  public static final FaultPositionFlag FAULT_POSTION_FALG = new FaultPositionFlag(null);
  public static final FaultObjectTypeCode FAULT_OBJECT_TYPR_CODE = new FaultObjectTypeCode(null);
  public static final FaultLocationType FAULT_LOCATION_TYPE = new FaultLocationType(null);
  public static final FaultReasonType FAULT_REASON_TYPE = new FaultReasonType(null);
  public static final FaultFiberType FAULT_FIBER_TYPE = new FaultFiberType(null);
  public static final FaultObjectType FAULT_OBJECT_TYPE = new FaultObjectType(null);
  public static final FaultLevel FAULT_LEVEL = new FaultLevel(null);
  public static final FaultDiagnoseType faultDiagnoseType = new FaultDiagnoseType(null);
  public static final FaultSendState FAULT_SEND_STATE = new FaultSendState(null);

  public static final FaultBreakState FAULT_BREAK_STATE = new FaultBreakState(null);
  public static final FaultCessionEnum FAULT_CESSION_ENUM = new FaultCessionEnum(null);
  public static final FaultRuleDevType FAULT_RULE_DEV_TYPE = new FaultRuleDevType(null);

  public static class FaultRuleDevType extends GenericEnum
  {
    public static final long _holder = 2L;
    public static final long _card = 3L;
    public static final long _port = 4L;

    private FaultRuleDevType()
    {
      super.putEnum(Long.valueOf(2L), "设备容器");
      super.putEnum(Long.valueOf(3L), "板卡");
      super.putEnum(Long.valueOf(4L), "端口");
    }
  }

  public static class FaultSendState extends GenericEnum
  {
    public static final long _success = 1L;
    public static final long _fail = 2L;

    private FaultSendState()
    {
      super.putEnum(Long.valueOf(1L), "成功");
      super.putEnum(Long.valueOf(2L), "失败");
    }
  }

  public static class FaultDiagnoseType extends GenericEnum
  {
    public static final long _deviceFault = 1L;
    public static final long _singleFiberFault = 2L;
    public static final long _FiberFault = 3L;

    private FaultDiagnoseType()
    {
      super.putEnum(Long.valueOf(1L), "设备故障");
      super.putEnum(Long.valueOf(2L), "单纤故障");
      super.putEnum(Long.valueOf(3L), "光缆故障");
    }
  }

  public static class FaultLevel extends GenericEnum
  {
    public static final long _severity = 1L;
    public static final long _light = 2L;

    private FaultLevel()
    {
      super.putEnum(Long.valueOf(1L), "严重故障");
      super.putEnum(Long.valueOf(2L), "轻微故障");
    }
  }

  public static class FaultBreakState extends GenericEnum
  {
    public static final long _fullbreak = 1L;
    public static final long _partbreak = 2L;
    public static final long _nobreak = 3L;

    private FaultBreakState()
    {
      super.putEnum(Long.valueOf(1L), "完全中断");
      super.putEnum(Long.valueOf(2L), "部分中断");
      super.putEnum(Long.valueOf(3L), "未中断");
    }
  }

  public static class FaultObjectType extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _ne = 1L;
    public static final long _pack = 2L;
    public static final long _ptp = 3L;
    public static final long _point = 4L;

    private FaultObjectType()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "网元");
      super.putEnum(Long.valueOf(2L), "机盘");
      super.putEnum(Long.valueOf(3L), "端口");
      super.putEnum(Long.valueOf(4L), "连接终端点");
    }
  }

  public static class FaultFiberType extends GenericEnum
  {
    public static final long _leve1 = 1L;
    public static final long _leve2 = 2L;
    public static final long _leve3 = 3L;

    private FaultFiberType()
    {
      super.putEnum(Long.valueOf(1L), "一干光缆");
      super.putEnum(Long.valueOf(2L), "二干光缆");
      super.putEnum(Long.valueOf(3L), "城域网光缆");
    }
  }

  public static class FaultReasonType extends GenericEnum
  {
    public static final long _engineering = 1L;
    public static final long _outsideForce = 2L;
    public static final long _general = 3L;
    public static final long _manMade = 4L;

    private FaultReasonType()
    {
      super.putEnum(Long.valueOf(1L), "工程");
      super.putEnum(Long.valueOf(2L), "外力");
      super.putEnum(Long.valueOf(3L), "常规");
      super.putEnum(Long.valueOf(4L), "人为");
    }
  }

  public static class FaultLocationType extends GenericEnum
  {
    public static final long _inside = 1L;
    public static final long _outside = 2L;

    private FaultLocationType()
    {
      super.putEnum(Long.valueOf(1L), "区域内");
      super.putEnum(Long.valueOf(2L), "区域外");
    }
  }

  public static class FaultObjectTypeCode extends GenericEnum
  {
    public static final long _fiber = 18201L;
    public static final long _cond = 18202L;
    public static final long _info = 18203L;
    public static final long _expert = 18204L;
    public static final long _faultAlarm = 18205L;

    private FaultObjectTypeCode()
    {
      super.putEnum(Long.valueOf(18201L), "FAULT_RULES_FIBER");
      super.putEnum(Long.valueOf(18202L), "AULT_R_F_SDHCONDDETAIL");
      super.putEnum(Long.valueOf(18203L), "FAULT_INFO");
      super.putEnum(Long.valueOf(18204L), "FAULT_EXPERT");
      super.putEnum(Long.valueOf(18205L), "FAULT_ALARM");
    }
  }

  public static class FaultPositionFlag extends GenericEnum
  {
    public static final long _this = 1L;
    public static final long _that = 2L;

    private FaultPositionFlag()
    {
      super.putEnum(Long.valueOf(1L), "本端");
      super.putEnum(Long.valueOf(2L), "对端");
    }
  }

  public static class LineFaultType extends GenericEnum
  {
    public static final long _single = 1L;
    public static final long _double = 2L;

    private LineFaultType()
    {
      super.putEnum(Long.valueOf(1L), "单纤");
      super.putEnum(Long.valueOf(2L), "双纤");
    }
  }

  public static class FaultCessionEnum extends GenericEnum
  {
    public static final long _ceding = 1L;
    public static final long _notcede = 0L;

    private FaultCessionEnum()
    {
      super.putEnum(Long.valueOf(1L), "正在割接");
      super.putEnum(Long.valueOf(0L), "没有割接");
    }
  }

  public static class FaultType extends GenericEnum
  {
    public static final long _line = 1L;
    public static final long _equip = 2L;
    public static final long _layout = 3L;
    public static final long _traph = 4L;
    public static final long _people = 5L;
    public static final long _NMS = 6L;
    public static final long _traphBreak = 7L;

    private FaultType()
    {
      super.putEnum(Long.valueOf(1L), "线路故障");
      super.putEnum(Long.valueOf(2L), "传输设备故障");
      super.putEnum(Long.valueOf(3L), "传输配套故障");
      super.putEnum(Long.valueOf(4L), "电源故障");
      super.putEnum(Long.valueOf(5L), "人为故障");
      super.putEnum(Long.valueOf(6L), "网管系统故障");

      super.putEnum(Long.valueOf(7L), "电路中断故障");
    }
  }
}