package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class PtnEnum
{
  public static final ChannelType CHANNEL_TYPE = new ChannelType(null);
  public static final Disrction DIRECTION = new Disrction(null);
  public static final EthType ETH_TYPE = new EthType(null);
  public static final TdmType TDM_TYPE = new TdmType(null);
  public static final PackageType PACKAGE_TYPE = new PackageType(null);
  public static final AtmType ATM_TYPE = new AtmType(null);
  public static final EmulationType EMULATION_TYPE = new EmulationType(null);
  public static final ActiveFlag ACTIVE_FLAG = new ActiveFlag(null);
  public static final ServiceType SERVICE_TYPE = new ServiceType(null);
  public static final PtnTurrnelType PTN_TURRNEL_TYPE = new PtnTurrnelType(null);
  public static final PtnActiveFlag PTN_ACTIVE_FALG = new PtnActiveFlag(null);
  public static final PtnTransparam PTN_TRANS_PARAM = new PtnTransparam(null);
  public static final PtnTDMType PTN_TDM_TYPE = new PtnTDMType(null);
  public static final PtnTDMPkgType PTN_TDM_PKG_TYPE = new PtnTDMPkgType(null);
  public static final PtnETHType PTN_ETH_TYPE = new PtnETHType(null);
  public static final PtnATMType PTN_ATM_TYPE = new PtnATMType(null);
  public static final BindingServiceType BANDING_SERVICE_TYPE = new BindingServiceType(null);
  public static final PWEType PWE_TYPE = new PWEType(null);
  public static final LtePwType LTE_PW_TYPE = new LtePwType(null);

  public static class PtnTransparam extends GenericEnum
  {
    public static final String _PWID = "PWID";
    public static final String _SignalType = "SignalType";
    public static final String _ControlWord = "ControlWord";
    public static final String _VCCV = "VCCV";
    public static final String _ControlChannelType = "ControlChannelType";
    public static final String _PeerIP = "PeerIP";
    public static final String _AdminStatus = "AdminStatus";
    public static final String _PacketLoadingTime = "PacketLoadingTime";
    public static final String _ClockMode = "ClockMode";

    private PtnTransparam()
    {
      super.putEnum("PWID", "伪线标示");
      super.putEnum("SignalType", "信号类型");
      super.putEnum("ControlWord", "控制字");
      super.putEnum("VCCV", "VCCV");
      super.putEnum("PeerIP", "PeerIP");
      super.putEnum("AdminStatus", "管理状态");
      super.putEnum("ClockMode", "时钟模式");
      super.putEnum("PacketLoadingTime", "包获取频率");
    }
  }

  public static class ServiceType extends GenericEnum
  {
    public static final long _ptn_eth = 1L;
    public static final long _ptn_tdm = 2L;
    public static final long _ptn_atm = 3L;

    private ServiceType()
    {
      super.putEnum(Long.valueOf(1L), "以太网业务");
      super.putEnum(Long.valueOf(2L), "TDM仿真业务");
      super.putEnum(Long.valueOf(3L), "ATM仿真业务");
    }
  }

  public static class ActiveFlag extends GenericEnum
  {
    public static final long _na = 1L;
    public static final long _sncs_active = 2L;
    public static final long _sncs_nonexistent = 3L;
    public static final long _sncs_partial = 4L;
    public static final long _sncs_pending = 5L;

    private ActiveFlag()
    {
      super.putEnum(Long.valueOf(1L), "NA");
      super.putEnum(Long.valueOf(2L), "SNCS_ACTIVE");
      super.putEnum(Long.valueOf(3L), "SNCS_NONEXISTENT");
      super.putEnum(Long.valueOf(4L), "SNCS_PARTIAL");
      super.putEnum(Long.valueOf(5L), "SNCS_PENDING");
    }
  }

  public static class EmulationType extends GenericEnum
  {
    public static final long _1_1vcc_vpc = 1L;
    public static final long _n_1vcc_vpc = 2L;
    public static final long _unknown = 3L;

    private EmulationType()
    {
      super.putEnum(Long.valueOf(1L), "1：1VCC/VPC");
      super.putEnum(Long.valueOf(2L), "N：1VCC/VPC");
      super.putEnum(Long.valueOf(3L), "未知");
    }
  }

  public static class AtmType extends GenericEnum
  {
    public static final long _atm = 1L;
    public static final long _ima = 2L;
    public static final long _e1 = 3L;
    public static final long _atm_stm_1 = 4L;
    public static final long _unknown = 5L;

    private AtmType()
    {
      super.putEnum(Long.valueOf(3L), "ATM");
      super.putEnum(Long.valueOf(2L), "IMA");
      super.putEnum(Long.valueOf(3L), "E1电路仿真");
      super.putEnum(Long.valueOf(4L), "ATM STM-1电路仿真");
      super.putEnum(Long.valueOf(5L), "未知");
    }
  }

  public static class PackageType extends GenericEnum
  {
    public static final long _SAToP = 1L;
    public static final long _CESoPSN = 2L;
    public static final long _unknown = 3L;

    private PackageType()
    {
      super.putEnum(Long.valueOf(1L), "SAToP");
      super.putEnum(Long.valueOf(2L), "CESoPSN");
      super.putEnum(Long.valueOf(3L), "未知");
    }
  }

  public static class TdmType extends GenericEnum
  {
    public static final long _e1 = 1L;
    public static final long _stm_1 = 2L;
    public static final long _unknown = 3L;

    private TdmType()
    {
      super.putEnum(Long.valueOf(1L), "E1电路仿真");
      super.putEnum(Long.valueOf(2L), "通道化STM-1电路仿真");
      super.putEnum(Long.valueOf(3L), "未知");
    }
  }

  public static class EthType extends GenericEnum
  {
    public static final long _e_line = 1L;
    public static final long _e_lan = 2L;
    public static final long _e_tree = 3L;

    private EthType()
    {
      super.putEnum(Long.valueOf(1L), "E_LINE");
      super.putEnum(Long.valueOf(2L), "E_LAN");
      super.putEnum(Long.valueOf(3L), "E_Tree");
    }
  }

  public static class PtnATMEmulationType extends GenericEnum
  {
    public static final long _ONE_TO_ONE = 1L;
    public static final long _N_TO_ONE = 2L;
    public static final long _NA = 3L;

    private PtnATMEmulationType()
    {
      super.putEnum(Long.valueOf(1L), "1：1VCC/VPC");
      super.putEnum(Long.valueOf(2L), "N：1VCC/VPC");
      super.putEnum(Long.valueOf(3L), "NA");
    }
  }

  public static class PtnATMType extends GenericEnum
  {
    public static final long _ATM_E1 = 1L;
    public static final long _ATM_STM_1 = 2L;
    public static final long _NA = 3L;

    private PtnATMType()
    {
      super.putEnum(Long.valueOf(1L), "ATM IAM E1电路仿真");
      super.putEnum(Long.valueOf(2L), "ATM STM-1电路仿真");
      super.putEnum(Long.valueOf(3L), "NA");
    }
  }

  public static class PtnETHType extends GenericEnum
  {
    public static final long _E_LINE = 1L;
    public static final long _E_LAN = 2L;
    public static final long _E_Tree = 3L;

    private PtnETHType()
    {
      super.putEnum(Long.valueOf(1L), "E_LINE");
      super.putEnum(Long.valueOf(2L), "E_LAN");
      super.putEnum(Long.valueOf(3L), "E_Tree");
    }
  }

  public static class PtnTDMPkgType extends GenericEnum
  {
    public static final long _SAToP = 1L;
    public static final long _CESoPSN = 2L;
    public static final long _NA = 3L;

    private PtnTDMPkgType()
    {
      super.putEnum(Long.valueOf(3L), "NA");
      super.putEnum(Long.valueOf(1L), "SAToP");
      super.putEnum(Long.valueOf(2L), "CESoPSN");
    }
  }

  public static class PtnTDMType extends GenericEnum
  {
    public static final long _E1 = 1L;
    public static final long _STM1 = 2L;
    public static final long _STRUCT_STM1 = 2L;
    public static final long _NA = 3L;

    private PtnTDMType()
    {
      super.putEnum(Long.valueOf(3L), "NA");
      super.putEnum(Long.valueOf(1L), "E1电路仿真");
      super.putEnum(Long.valueOf(2L), "通道化STM-1电路仿真");
      super.putEnum(Long.valueOf(2L), "结构化STM-1电路仿真");
    }
  }

  public static class PtnActiveFlag extends GenericEnum
  {
    public static final long _NA = 1L;
    public static final long _SNCS_ACTIVE = 2L;
    public static final long _SNCS_NONEXISTENT = 3L;
    public static final long _SNCS_PARTIAL = 4L;
    public static final long _SNCS_PENDING = 5L;

    private PtnActiveFlag()
    {
      super.putEnum(Long.valueOf(1L), "NA");
      super.putEnum(Long.valueOf(2L), "SNCS_ACTIVE");
      super.putEnum(Long.valueOf(3L), "SNCS_NONEXISTENT");
      super.putEnum(Long.valueOf(4L), "SNCS_PARTIAL");
      super.putEnum(Long.valueOf(5L), "SNCS_PENDING");
    }
  }

  public static class Disrction extends GenericEnum
  {
    public static final long _single = 1L;
    public static final long _double = 2L;

    private Disrction()
    {
      super.putEnum(Long.valueOf(1L), "单向");
      super.putEnum(Long.valueOf(2L), "双向");
    }
  }

  public static class PtnTurrnelType extends GenericEnum
  {
    public static final long _NA = 1L;
    public static final long _E_LSP = 2L;
    public static final long _L_LSP = 3L;

    private PtnTurrnelType()
    {
      super.putEnum(Long.valueOf(1L), "NA");
      super.putEnum(Long.valueOf(2L), "E_LSP");
      super.putEnum(Long.valueOf(3L), "L_LSP");
    }
  }

  public static class ChannelType extends GenericEnum
  {
    public static final long _undefined = 1L;
    public static final long _e_lsp = 2L;
    public static final long _l_lsp = 3L;

    private ChannelType()
    {
      super.putEnum(Long.valueOf(1L), "未定义");
      super.putEnum(Long.valueOf(2L), "E_LSP");
      super.putEnum(Long.valueOf(3L), "L_LSP");
    }
  }

  public static class PWEType extends GenericEnum
  {
    public static final long _ethernet = 1L;
    public static final long _ethernet_vlan = 2L;

    private PWEType()
    {
      super.putEnum(Long.valueOf(1L), "Ethernet");
      super.putEnum(Long.valueOf(2L), "Ethernet VLAN");
    }
  }

  public static class BindingServiceType extends GenericEnum
  {
    public static final long _eth = 1L;
    public static final long _tdm = 2L;
    public static final long _atm = 3L;
    public static final long _epl = 4L;
    public static final long _evpl = 5L;
    public static final long _ces = 6L;

    private BindingServiceType()
    {
      super.putEnum(Long.valueOf(1L), "Eth");
      super.putEnum(Long.valueOf(2L), "TDM");
      super.putEnum(Long.valueOf(3L), "ATM");
      super.putEnum(Long.valueOf(4L), "EPL");
      super.putEnum(Long.valueOf(5L), "EVPL");
      super.putEnum(Long.valueOf(6L), "CES");
    }
  }

  public static class LtePwType extends GenericEnum
  {
    public static final long _default = 0L;
    public static final long _service_main = 1L;
    public static final long _monitor_main = 2L;
    public static final long _service_backup = 3L;
    public static final long _monitor_backup = 4L;
    public static final long _service = 5L;
    public static final long _nms = 6L;
    public static final long _tnms = 7L;

    private LtePwType()
    {
      super.putEnum(Long.valueOf(0L), "非LTE电路伪线");
      super.putEnum(Long.valueOf(1L), "业务主用伪线");
      super.putEnum(Long.valueOf(3L), "业务备用伪线");
      super.putEnum(Long.valueOf(2L), "监控主用伪线");
      super.putEnum(Long.valueOf(4L), "监控备用伪线");
      super.putEnum(Long.valueOf(5L), "业务伪线");
      super.putEnum(Long.valueOf(6L), "网管伪线");
      super.putEnum(Long.valueOf(7L), "传输网管伪线");
    }
  }
}