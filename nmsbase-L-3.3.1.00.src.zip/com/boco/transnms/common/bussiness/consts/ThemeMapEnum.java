package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class ThemeMapEnum
{
  public static final ThemeMapType THEMEMAP_TYPE = new ThemeMapType(null);

  public static class ThemeMapType extends GenericEnum
  {
    public static final long _subnet = 1L;
    public static final long _site = 3L;

    private ThemeMapType() {
      super.putEnum(Long.valueOf(1L), "子网传输系统及网元");

      super.putEnum(Long.valueOf(3L), "站点");
    }
  }
}