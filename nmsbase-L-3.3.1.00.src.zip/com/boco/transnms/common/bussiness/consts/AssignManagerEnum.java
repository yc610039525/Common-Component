package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class AssignManagerEnum extends GenericEnum
{
  public static final DutyState DUTYSTATE = new DutyState(null);
  public static final RecordType RECORDTYPE = new RecordType(null);
  public static final ReportType REPORTTYPE = new ReportType(null);
  public static final FaultReason FAULTREASON = new FaultReason(null);

  public static class FaultReason extends GenericEnum
  {
    public static final long _LONGDISTANCE = 1L;
    public static final long _CITYEDITION = 0L;

    private FaultReason()
    {
      super.putEnum(Long.valueOf(1L), "传输故障");
      super.putEnum(Long.valueOf(0L), "非传输故障");
    }
  }

  public static class ReportType extends GenericEnum
  {
    public static final long _REPORT = 1L;
    public static final long _NOREPORT = 0L;

    private ReportType()
    {
      super.putEnum(Long.valueOf(1L), "上报");
      super.putEnum(Long.valueOf(0L), "不上报");
    }
  }

  public static class RecordType extends GenericEnum
  {
    public static final long _MALFUNCTION = 1L;
    public static final long _INCISE = 2L;
    public static final long _CLIENTAPPEAL = 3L;
    public static final long _OTHER = 4L;

    private RecordType()
    {
      super.putEnum(Long.valueOf(1L), "故障");
      super.putEnum(Long.valueOf(2L), "割接");
      super.putEnum(Long.valueOf(3L), "客户申告");
      super.putEnum(Long.valueOf(4L), "其它");
    }
  }

  public static class DutyState extends GenericEnum
  {
    public static final long _NKW = 1L;
    public static final long _HKW = 2L;
    public static final long _OKW = 3L;

    private DutyState()
    {
      super.putEnum(Long.valueOf(1L), "未值班");
      super.putEnum(Long.valueOf(2L), "正在值班");
      super.putEnum(Long.valueOf(3L), "值班结束");
    }
  }
}