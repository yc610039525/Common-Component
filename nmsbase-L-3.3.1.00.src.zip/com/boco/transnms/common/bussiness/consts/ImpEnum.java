package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class ImpEnum
{
  public static final protectType PROTECT_TYPE = new protectType(null);
  public static final protectState PROTECT_STATE = new protectState(null);
  public static final privacyLevel PRIVACY_LEVEL = new privacyLevel(null);
  public static final exigenceLevel EXIGENCE_LEVEL = new exigenceLevel(null);

  public static class exigenceLevel extends GenericEnum
  {
    public static final long _LOW = 1L;
    public static final long _MID = 2L;
    public static final long _HIG = 3L;

    private exigenceLevel()
    {
      super.putEnum(Long.valueOf(1L), "急");
      super.putEnum(Long.valueOf(2L), "缓急");
      super.putEnum(Long.valueOf(3L), "特急");
    }
  }

  public static class privacyLevel extends GenericEnum
  {
    public static final long _LOW = 1L;
    public static final long _MID = 2L;
    public static final long _HIG = 3L;

    private privacyLevel()
    {
      super.putEnum(Long.valueOf(1L), "秘密");
      super.putEnum(Long.valueOf(2L), "机密");
      super.putEnum(Long.valueOf(3L), "绝密");
    }
  }

  public static class protectState extends GenericEnum
  {
    public static final long _UNBEGIN = 1L;
    public static final long _PRO = 2L;
    public static final long _BEGIN = 3L;
    public static final long _END = 4L;

    private protectState()
    {
      super.putEnum(Long.valueOf(1L), "重保未开始");
      super.putEnum(Long.valueOf(2L), "预重保");
      super.putEnum(Long.valueOf(3L), "重保中");
      super.putEnum(Long.valueOf(4L), "重保结束");
    }
  }

  public static class protectType extends GenericEnum
  {
    public static final long _A = 1L;
    public static final long _B = 2L;
    public static final long _C = 3L;

    private protectType()
    {
      super.putEnum(Long.valueOf(1L), "A");
      super.putEnum(Long.valueOf(2L), "B");
      super.putEnum(Long.valueOf(3L), "C");
    }
  }
}