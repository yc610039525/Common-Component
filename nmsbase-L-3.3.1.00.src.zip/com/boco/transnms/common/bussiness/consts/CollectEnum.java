package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class CollectEnum
{
  public static final CollectTaskResult collectTaskResult = new CollectTaskResult(null);
  public static final CollectTaskState collectTaskState = new CollectTaskState(null);
  public static final DataChangeType dataChangeType = new DataChangeType(null);
  public static final DataType dataType = new DataType(null);
  public static final DisposeState disposeState = new DisposeState(null);
  public static final ObjectType objectType = new ObjectType(null);
  public static final SubTaskResult subTaskResult = new SubTaskResult(null);
  public static final SubTaskState subTaskState = new SubTaskState(null);
  public static final TransSystemType transSystemType = new TransSystemType(null);
  public static final NeEventType neEventType = new NeEventType(null);
  public static final NeEventProcessResult neEventProcessResult = new NeEventProcessResult(null);
  public static final NeEventProcessType neEventProcessType = new NeEventProcessType(null);
  public static final CollectTaskStartWay collectTaskStartWay = new CollectTaskStartWay(null);
  public static final CollectTaskWorkStatue collectTaskWorkStatue = new CollectTaskWorkStatue(null);

  public static class ColConfDataType extends GenericEnum
  {
    public static final long NE = 1L;
    public static final long PORT = 2L;
    public static final long TOPO = 3L;

    private ColConfDataType()
    {
      super.putEnum(Long.valueOf(1L), "网元");
      super.putEnum(Long.valueOf(2L), "端口");
      super.putEnum(Long.valueOf(3L), "拓扑");
    }
  }

  public static class ColEffectObjType extends GenericEnum
  {
    public static final long DEV = 1L;
    public static final long DDFPORT = 2L;
    public static final long ODFPORT = 3L;

    private ColEffectObjType()
    {
      super.putEnum(Long.valueOf(1L), "设备");
      super.putEnum(Long.valueOf(2L), "DDF端子");
      super.putEnum(Long.valueOf(3L), "ODF端子");
    }
  }

  public static class ColEffectServiceType extends GenericEnum
  {
    public static final long ATTEMP = 1L;
    public static final long USED = 2L;

    private ColEffectServiceType()
    {
      super.putEnum(Long.valueOf(1L), "调度中");
      super.putEnum(Long.valueOf(2L), "现网中");
    }
  }

  public static class ColEffectTraphType extends GenericEnum
  {
    public static final long CIRCUIT = 1L;
    public static final long OPTICAL = 2L;

    private ColEffectTraphType()
    {
      super.putEnum(Long.valueOf(1L), "电路");
      super.putEnum(Long.valueOf(2L), "光路");
    }
  }

  public static class ColEffectPonChangePlace extends GenericEnum
  {
    public static final long OLT = 1L;
    public static final long POS1 = 2L;
    public static final long POS2 = 3L;
    public static final long ONU = 4L;

    private ColEffectPonChangePlace()
    {
      super.putEnum(Long.valueOf(1L), "OLT");
      super.putEnum(Long.valueOf(2L), "一级分光器");
      super.putEnum(Long.valueOf(3L), "二级分光器");
      super.putEnum(Long.valueOf(4L), "ONU");
    }
  }

  public static class CollectTaskWorkStatue extends GenericEnum
  {
    public static final long NO = 0L;
    public static final long INACTIVE = 1L;
    public static final long ACTIVE = 2L;

    private CollectTaskWorkStatue()
    {
      super.putEnum(Long.valueOf(0L), "无意义");
      super.putEnum(Long.valueOf(1L), "挂起");
      super.putEnum(Long.valueOf(2L), "激活");
    }
  }

  public static class CollectTaskStartWay extends GenericEnum
  {
    public static final long MANNAL_TASK = 1L;
    public static final long TIMER_TASK = 2L;
    public static final long AUTO_TASK = 3L;

    private CollectTaskStartWay()
    {
      super.putEnum(Long.valueOf(1L), "手工采集");
      super.putEnum(Long.valueOf(2L), "定时周期采集");
      super.putEnum(Long.valueOf(3L), "自动采集");
    }
  }

  public static class NeEventProcessResult extends GenericEnum
  {
    public static final long SUCCESS = 1L;
    public static final long FAULT = 2L;
    public static final long NOT_DO = 3L;

    private NeEventProcessResult()
    {
      super.putEnum(Long.valueOf(1L), "成功");
      super.putEnum(Long.valueOf(2L), "失败");
      super.putEnum(Long.valueOf(3L), "未处理");
    }
  }

  public static class NeEventProcessType extends GenericEnum
  {
    public static final long CREATE = 1L;
    public static final long REPLACE = 2L;
    public static final long DELETE = 3L;
    public static final long NOCHANGE = 4L;

    private NeEventProcessType()
    {
      super.putEnum(Long.valueOf(1L), "新增");
      super.putEnum(Long.valueOf(2L), "替换");
      super.putEnum(Long.valueOf(3L), "删除");
      super.putEnum(Long.valueOf(4L), "不变更");
    }
  }

  public static class NeEventType extends GenericEnum
  {
    public static final long CREATE = 1L;
    public static final long DELETE = 2L;

    private NeEventType()
    {
      super.putEnum(Long.valueOf(1L), "新增");
      super.putEnum(Long.valueOf(2L), "删除");
    }
  }

  public static class PMTaskState extends GenericEnum
  {
    public static final int CREATE = 1;
    public static final int MODIFY = 2;
    public static final int DELETE = 3;
    public static final int ACTIVATE = 4;
    public static final int SUSPEND = 5;

    private PMTaskState()
    {
      super.putEnum(Integer.valueOf(1), "创建");
      super.putEnum(Integer.valueOf(2), "修改");
      super.putEnum(Integer.valueOf(3), "删除");
      super.putEnum(Integer.valueOf(4), "激活");
      super.putEnum(Integer.valueOf(5), "挂起");
    }
  }

  public static class SubTaskState extends GenericEnum
  {
    public static final int NMC_DISPOSING = 1;
    public static final int NMC_FINISH = 2;
    public static final int NMC_PART = 3;
    public static final int CLIENT_DISPOSING = 4;
    public static final int CLIENT_FINISH = 5;
    public static final int NMC_FORCE = 6;

    private SubTaskState()
    {
      super.putEnum(Integer.valueOf(1), "服务器正在处理");
      super.putEnum(Integer.valueOf(2), "服务器处理结束");
      super.putEnum(Integer.valueOf(3), "服务器部分处理");
      super.putEnum(Integer.valueOf(4), "NMC没有处理");
      super.putEnum(Integer.valueOf(5), "客户端处理结束");
      super.putEnum(Integer.valueOf(6), "客户端强制处理");
    }
  }

  public static class SubTaskResult extends GenericEnum
  {
    public static final int INANITION = 1;
    public static final int SUCCESS = 2;
    public static final int FAIL = 3;
    public static final int PART_SUCCESS = 4;

    private SubTaskResult()
    {
      super.putEnum(Integer.valueOf(1), "无意义");
      super.putEnum(Integer.valueOf(2), "成功");
      super.putEnum(Integer.valueOf(3), "失败");
      super.putEnum(Integer.valueOf(4), "部分成功");
    }
  }

  public static class ObjectType extends GenericEnum
  {
    public static final int COLLECT = 1;
    public static final int MESSAGE = 2;

    private ObjectType()
    {
      super.putEnum(Integer.valueOf(1), "采集");
      super.putEnum(Integer.valueOf(2), "消息");
    }
  }

  public static class DisposeState extends GenericEnum
  {
    public static final int NO_DISPOSE = 1;
    public static final int SERVER_DISPOSE = 2;
    public static final int CLIENT_DISPOSE = 3;

    private DisposeState()
    {
      super.putEnum(Integer.valueOf(1), "未处理");
      super.putEnum(Integer.valueOf(2), "NMC处理");
      super.putEnum(Integer.valueOf(3), "客户端处理");
    }
  }

  public static class DataType extends GenericEnum
  {
    public static final int EMS = 1;
    public static final int NE = 2;
    public static final int PLATE = 3;
    public static final int PORT = 4;
    public static final int CROSS = 5;
    public static final int CTP = 6;
    public static final int TOPO = 7;
    public static final int MSTP = 8;
    public static final int BIND = 9;
    public static final int ETH = 10;
    public static final int VBRIDGE = 11;
    public static final int VLAN = 12;
    public static final int SUB_NETWORK = 13;
    public static final int TRANS_SYSTEM = 14;
    public static final int PROTECT_GROUP = 15;
    public static final int PTN_ALLSERVICE = 16;
    public static final int PTN_TURNNEL = 17;
    public static final int PTN_VIRTUAL_LINE = 18;
    public static final int PTN_SERVICE = 19;
    public static final int OLP_SWITCH_UNIT = 20;
    public static final int OLP = 21;
    public static final int OLP_ROUTE_GROUP = 22;
    public static final int OLP_ROUTE_UNIT = 23;
    public static final int OLP_TOPO_LINK = 24;

    private DataType()
    {
      super.putEnum(Integer.valueOf(1), "EMS");
      super.putEnum(Integer.valueOf(2), "网元");
      super.putEnum(Integer.valueOf(3), "盘");
      super.putEnum(Integer.valueOf(4), "端口");
      super.putEnum(Integer.valueOf(6), "CTP");
      super.putEnum(Integer.valueOf(5), "交叉");
      super.putEnum(Integer.valueOf(7), "拓扑");
      super.putEnum(Integer.valueOf(8), "MSTP端口");
      super.putEnum(Integer.valueOf(9), "绑定通道");
      super.putEnum(Integer.valueOf(10), "以太网");
      super.putEnum(Integer.valueOf(11), "虚拟网桥");
      super.putEnum(Integer.valueOf(12), "VLAN");
      super.putEnum(Integer.valueOf(13), "子网");
      super.putEnum(Integer.valueOf(14), "传输系统");
      super.putEnum(Integer.valueOf(15), "保护组");
      super.putEnum(Integer.valueOf(16), "PTN隧道/伪线/业务");
      super.putEnum(Integer.valueOf(17), "PTN隧道");
      super.putEnum(Integer.valueOf(18), "PTN伪线");
      super.putEnum(Integer.valueOf(19), "PTN业务");
      super.putEnum(Integer.valueOf(20), "OLP倒换单元");
      super.putEnum(Integer.valueOf(21), "OLP路由段");
      super.putEnum(Integer.valueOf(22), "OLP路由组");
      super.putEnum(Integer.valueOf(23), "OLP路由单元");
      super.putEnum(Integer.valueOf(24), "OLP拓扑");
    }
  }

  public static class DataChangeType extends GenericEnum
  {
    public static final int ADD = 1;
    public static final int DELETE = 2;
    public static final int Change = 3;

    private DataChangeType()
    {
      super.putEnum(Integer.valueOf(1), "新增");
      super.putEnum(Integer.valueOf(2), "删除");
      super.putEnum(Integer.valueOf(3), "属性变更");
    }
  }

  public static class CollectTaskState extends GenericEnum
  {
    public static final int NMC_DISPOSING = 1;
    public static final int NMC_FINISH = 2;
    public static final int NMC_PART = 3;
    public static final int NMC_NOTDISPOSING = 4;
    public static final int CLIENT_FINISH = 5;

    private CollectTaskState()
    {
      super.putEnum(Integer.valueOf(1), "服务器正在处理");
      super.putEnum(Integer.valueOf(2), "服务器处理结束");
      super.putEnum(Integer.valueOf(3), "服务器部分处理");
      super.putEnum(Integer.valueOf(4), "服务器未处理");
      super.putEnum(Integer.valueOf(5), "客户端处理结束");
    }
  }

  public static class TransSystemType extends GenericEnum
  {
    public static final int MSP_1_PLUS_1 = 1;
    public static final int MSP_1_FOR_N = 2;
    public static final int FIBER_BLSR_2 = 3;
    public static final int FIBER_BLSR_4 = 4;

    private TransSystemType()
    {
      super.putEnum(Integer.valueOf(1), "MSP_1_PLUS_1");
      super.putEnum(Integer.valueOf(2), "MSP_1_FOR_N");
      super.putEnum(Integer.valueOf(3), "2_FIBER_BLSR");
      super.putEnum(Integer.valueOf(4), "4_FIBER_BLSR");
    }
  }

  public static class CollectTaskResult extends GenericEnum
  {
    public static final int INANITION = 1;
    public static final int SUCCESS = 2;
    public static final int FAIL = 3;
    public static final int PART_SUCCESS = 4;

    private CollectTaskResult()
    {
      super.putEnum(Integer.valueOf(1), "无意义");
      super.putEnum(Integer.valueOf(2), "成功");
      super.putEnum(Integer.valueOf(3), "失败");
      super.putEnum(Integer.valueOf(4), "部分成功");
    }
  }
}