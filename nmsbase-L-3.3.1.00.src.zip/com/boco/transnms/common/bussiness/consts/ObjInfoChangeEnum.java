package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class ObjInfoChangeEnum
{
  public static final GetFlag GET_FLAG = new GetFlag(null);
  public static final ChangeObjType CHANGE_OBJ_TYPE = new ChangeObjType(null);

  public static final class ChangeObjType extends GenericEnum
  {
    public static final long _ADD = 1L;
    public static final long _UPDATE = 2L;
    public static final long _DELETE = 3L;

    private ChangeObjType()
    {
      super.putEnum(Long.valueOf(1L), "增加");
      super.putEnum(Long.valueOf(2L), "修改");
      super.putEnum(Long.valueOf(3L), "删除");
    }
  }

  public static final class GetFlag extends GenericEnum
  {
    public static final long _Capture = 0L;
    public static final long _NotCapture = 1L;

    private GetFlag()
    {
      super.putEnum(Long.valueOf(0L), "获取");
      super.putEnum(Long.valueOf(1L), "未获取");
    }
  }
}