package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class PathEnum
{
  public static class BranchTaskStatus extends GenericEnum
  {
    public static final long _not_check = 1L;
    public static final long _in_check = 2L;
    public static final long _end_check = 3L;
    public static final long _fail_check = 4L;
    public static final long _pause_check = 5L;

    private BranchTaskStatus()
    {
      super.putEnum(Long.valueOf(1L), "未核查");
      super.putEnum(Long.valueOf(2L), "正在核查");
      super.putEnum(Long.valueOf(3L), "核查结束");
      super.putEnum(Long.valueOf(4L), "核查异常中止");
      super.putEnum(Long.valueOf(5L), "核查暂停");
    }
  }

  public static class BranchCheckResult extends GenericEnum
  {
    public static final long _unkonw = 1L;
    public static final long _all_success = 2L;
    public static final long _part_success = 3L;
    public static final long _all_fail = 4L;

    private BranchCheckResult()
    {
      super.putEnum(Long.valueOf(1L), "未知");
      super.putEnum(Long.valueOf(2L), "全部成功");
      super.putEnum(Long.valueOf(3L), "部分成功");
      super.putEnum(Long.valueOf(4L), "全部失败");
    }
  }

  public static class CheckStatus extends GenericEnum
  {
    public static final long _not_check = 1L;
    public static final long _in_check = 2L;
    public static final long _end_check = 3L;

    private CheckStatus()
    {
      super.putEnum(Long.valueOf(1L), "未核查");
      super.putEnum(Long.valueOf(2L), "正在核查");
      super.putEnum(Long.valueOf(3L), "核查结束");
    }
  }
}