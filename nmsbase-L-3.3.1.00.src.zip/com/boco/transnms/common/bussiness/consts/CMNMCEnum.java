package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class CMNMCEnum
{
  public static final TpMappingMode tpMappingMode = new TpMappingMode(null);
  public static final DirectionModel directionModel = new DirectionModel(null);
  public static final ConnectionState connectionState = new ConnectionState(null);
  public static final SubNetWorkType subNetWorkType = new SubNetWorkType(null);

  public static class SubNetWorkType extends GenericEnum<Integer>
  {
    public static final int SINGLETON = 1;
    public static final int CHAIN = 2;
    public static final int PSR = 3;
    public static final int SPRING = 4;
    public static final int OPEN_PSR = 5;
    public static final int OPEN_SPRING = 6;
    public static final int MESH = 7;

    private SubNetWorkType()
    {
      putEnum(Integer.valueOf(1), "SINGLETON");
      putEnum(Integer.valueOf(2), "CHAIN");
      putEnum(Integer.valueOf(3), "PSR");
      putEnum(Integer.valueOf(4), "SPRING");
      putEnum(Integer.valueOf(5), "OPEN_PSR");
      putEnum(Integer.valueOf(6), "OPEN_SPRING");
      putEnum(Integer.valueOf(7), "MESH");
    }
  }

  public static class ConnectionState extends GenericEnum<Integer>
  {
    public static final int NA = 1;
    public static final int SOURCE_CONNECTED = 2;
    public static final int SINK_CONNECTED = 3;
    public static final int BI_CONNECTED = 4;
    public static final int NOT_CONNECTED = 5;

    private ConnectionState()
    {
      putEnum(Integer.valueOf(1), "NA");
      putEnum(Integer.valueOf(2), "SOURCE_CONNECTED");
      putEnum(Integer.valueOf(3), "SINK_CONNECTED");
      putEnum(Integer.valueOf(4), "BI_CONNECTED");
      putEnum(Integer.valueOf(5), "NOT_CONNECTED");
    }
  }

  public static class DirectionModel extends GenericEnum<Integer>
  {
    public static final int NA = 1;
    public static final int BI = 2;
    public static final int SOURCE = 3;
    public static final int SINK = 4;

    private DirectionModel()
    {
      putEnum(Integer.valueOf(1), "NA");
      putEnum(Integer.valueOf(2), "BI");
      putEnum(Integer.valueOf(3), "SOURCE");
      putEnum(Integer.valueOf(4), "SINK");
    }
  }

  public static class TpMappingMode extends GenericEnum<Integer>
  {
    public static final int TM_NA = 1;
    public static final int TM_NEITHER_TERMINATED_NOR_AVAILABLE_FOR_MAPPING = 2;
    public static final int TM_TERMINATED_AND_AVAILABLE_FOR_MAPPING = 3;

    private TpMappingMode()
    {
      putEnum(Integer.valueOf(1), "TM_NA");
      putEnum(Integer.valueOf(2), "TM_NEITHER_TERMINATED_NOR_AVAILABLE_FOR_MAPPING");
      putEnum(Integer.valueOf(3), "TM_TERMINATED_AND_AVAILABLE_FOR_MAPPING");
    }
  }
}