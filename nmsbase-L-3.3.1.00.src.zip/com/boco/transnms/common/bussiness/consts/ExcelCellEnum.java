package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class ExcelCellEnum
{
  public static class ExcelCellType extends GenericEnum
  {
    public static final int _string = 1;
    public static final int _number = 2;
    public static final int _date = 3;
    public static final int _int = 4;
    public static final int _long = 5;
    public static final int _double = 6;

    private ExcelCellType()
    {
      super.putEnum(Integer.valueOf(1), "String");
      super.putEnum(Integer.valueOf(2), "number");
      super.putEnum(Integer.valueOf(3), "date");
      super.putEnum(Integer.valueOf(4), "int");
      super.putEnum(Integer.valueOf(5), "long");
      super.putEnum(Integer.valueOf(6), "double");
    }
  }
}