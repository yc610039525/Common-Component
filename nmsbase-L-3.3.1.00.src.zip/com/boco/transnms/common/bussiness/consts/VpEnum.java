package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class VpEnum extends GenericEnum
{
  public static final VpIndustry VP_INDUSTRY = new VpIndustry(null);
  public static final VpProperty VP_PROPERTY = new VpProperty(null);
  public static final VpSvcClass VP_SVCCLASS = new VpSvcClass(null);
  public static final VpServiceLevel VP_SERVICE_LEVEL = new VpServiceLevel(null);
  public static final VpType VP_TYPE = new VpType(null);
  public static final VpCompanyKind VP_COMPANY_KIND = new VpCompanyKind(null);

  public static class VpCompanyKind extends GenericEnum
  {
    public static final int _arm = 1;
    public static final int _con = 2;
    public static final int _pep = 3;
    public static final int _sev = 4;
    public static final int _per = 5;
    public static final int _roo = 6;
    public static final int _sel = 7;
    public static final int _bot = 8;

    private VpCompanyKind()
    {
      super.putEnum(Integer.valueOf(1), "党政军");
      super.putEnum(Integer.valueOf(2), "跨国跨省");
      super.putEnum(Integer.valueOf(3), "国计民生");
      super.putEnum(Integer.valueOf(4), "业务合作方");
      super.putEnum(Integer.valueOf(5), "普通客户");
      super.putEnum(Integer.valueOf(6), "营业厅");
      super.putEnum(Integer.valueOf(7), "自有业务");
      super.putEnum(Integer.valueOf(8), "国计民生/跨国跨省");
    }
  }

  public static class VpServiceLevel extends GenericEnum
  {
    public static final int _jtkh = 1;
    public static final int _sjkh = 2;
    public static final int _zykh = 3;

    private VpServiceLevel()
    {
      super.putEnum(Integer.valueOf(1), "集团客户");
      super.putEnum(Integer.valueOf(2), "省级客户");
      super.putEnum(Integer.valueOf(3), "重要客户");
    }
  }

  public static class VpType extends GenericEnum
  {
    public static final int _vpn = 1;
    public static final int _net = 2;
    public static final int _voi = 3;
    public static final int _com = 4;
    public static final int _oth = 5;

    private VpType()
    {
      super.putEnum(Integer.valueOf(1), "VPN业务");
      super.putEnum(Integer.valueOf(2), "互联网业务");
      super.putEnum(Integer.valueOf(3), "语音业务");
      super.putEnum(Integer.valueOf(4), "综合业务");
      super.putEnum(Integer.valueOf(5), "其它");
    }
  }

  public static class VpSvcClass extends GenericEnum
  {
    public static final int _vpn = 1;
    public static final int _net = 2;
    public static final int _voi = 3;
    public static final int _com = 4;
    public static final int _oth = 5;

    private VpSvcClass()
    {
      super.putEnum(Integer.valueOf(1), "VPN业务");
      super.putEnum(Integer.valueOf(2), "互联网业务");
      super.putEnum(Integer.valueOf(3), "语音业务");
      super.putEnum(Integer.valueOf(4), "综合业务");
      super.putEnum(Integer.valueOf(5), "其它");
    }
  }

  public static class VpProperty extends GenericEnum
  {
    public static final int _cou = 1;
    public static final int _peo = 2;
    public static final int _per = 3;
    public static final int _pub = 4;

    private VpProperty()
    {
      super.putEnum(Integer.valueOf(1), "国营企业");
      super.putEnum(Integer.valueOf(2), "民营企业");
      super.putEnum(Integer.valueOf(3), "私营企业");
      super.putEnum(Integer.valueOf(4), "事业单位");
    }
  }

  public static class VpIndustry extends GenericEnum
  {
    public static final int _finance = 1;
    public static final int _gov = 2;
    public static final int _post = 3;
    public static final int _power = 4;
    public static final int _science = 5;
    public static final int _edu = 6;
    public static final int _estate = 7;
    public static final int _transportation = 8;
    public static final int _manufacture = 9;
    public static final int _itservice = 10;
    public static final int _socialservice = 11;

    private VpIndustry()
    {
      super.putEnum(Integer.valueOf(1), "金融保险");
      super.putEnum(Integer.valueOf(2), "政府机构");
      super.putEnum(Integer.valueOf(3), "邮政通信");
      super.putEnum(Integer.valueOf(4), "能源电力");
      super.putEnum(Integer.valueOf(5), "科学技术");
      super.putEnum(Integer.valueOf(6), "教育文化");
      super.putEnum(Integer.valueOf(7), "房地产");
      super.putEnum(Integer.valueOf(8), "交通运输");
      super.putEnum(Integer.valueOf(9), "制造业");
      super.putEnum(Integer.valueOf(10), "IT服务业");
      super.putEnum(Integer.valueOf(11), "社会服务");
    }
  }
}