package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class CessionEnum
{
  public static final CessionScope CESSION_SCOPE = new CessionScope(null);
  public static final CessionType CESSION_TYPE = new CessionType(null);
  public static final CessionReason CESSION_REASON = new CessionReason(null);
  public static final CessionOpt CESSION_OPT = new CessionOpt(null);
  public static final CessionHistory CESSION_HISTORY = new CessionHistory(null);

  public static class CessionOpt extends GenericEnum
  {
    public static final long _Null = 0L;
    public static final long _total = 1L;
    public static final long _part = 2L;
    public static final long _never = 3L;

    private CessionOpt()
    {
      super.putEnum(Long.valueOf(0L), "");
      super.putEnum(Long.valueOf(1L), "完全中断");
      super.putEnum(Long.valueOf(2L), "部分中断");
      super.putEnum(Long.valueOf(3L), "未中断");
    }
  }

  public static class CessionReason extends GenericEnum
  {
    public static final long _cityctrl = 1L;
    public static final long _cable = 2L;
    public static final long _localroute = 3L;
    public static final long _changecable = 4L;
    public static final long _samecession = 5L;
    public static final long _fault = 6L;
    public static final long _changecase = 7L;
    public static final long _nature = 8L;
    public static final long _otherroute = 9L;
    public static final long _localdepart = 10L;
    public static final long _odfddf = 11L;
    public static final long _changedisc = 12L;
    public static final long _power = 13L;
    public static final long _jump = 14L;
    public static final long _otherdepart = 15L;
    public static final long _other = 16L;

    private CessionReason()
    {
      super.putEnum(Long.valueOf(1L), "市政工程");
      super.putEnum(Long.valueOf(2L), "纤芯整治");
      super.putEnum(Long.valueOf(3L), "本地线路割接");
      super.putEnum(Long.valueOf(4L), "改纤");
      super.putEnum(Long.valueOf(5L), "合作方割接");
      super.putEnum(Long.valueOf(6L), "故障恢复");
      super.putEnum(Long.valueOf(7L), "方案调整");
      super.putEnum(Long.valueOf(8L), "自然灾害");
      super.putEnum(Long.valueOf(9L), "其他线路割接");
      super.putEnum(Long.valueOf(10L), "本地设备割接");
      super.putEnum(Long.valueOf(11L), "ODF、DDF架整改");
      super.putEnum(Long.valueOf(12L), "换盘");
      super.putEnum(Long.valueOf(13L), "电源");
      super.putEnum(Long.valueOf(14L), "跳波");
      super.putEnum(Long.valueOf(15L), "其他设备割接");
      super.putEnum(Long.valueOf(16L), "其他割接");
    }
  }

  public static class CessionType extends GenericEnum
  {
    public static final long _route = 1L;
    public static final long _depart = 2L;
    public static final long _other = 3L;

    private CessionType()
    {
      super.putEnum(Long.valueOf(1L), "线路割接");
      super.putEnum(Long.valueOf(2L), "设备割接");
      super.putEnum(Long.valueOf(3L), "其它割接");
    }
  }

  public static class CessionScope extends GenericEnum
  {
    public static final long _prov = 1L;
    public static final long _city = 2L;
    public static final long _local = 3L;
    public static final long _center = 4L;
    public static final long _conn = 5L;

    private CessionScope()
    {
      super.putEnum(Long.valueOf(1L), "省际");
      super.putEnum(Long.valueOf(2L), "省内");
      super.putEnum(Long.valueOf(3L), "本地骨干");
      super.putEnum(Long.valueOf(4L), "本地汇聚");
      super.putEnum(Long.valueOf(5L), "本地接入");
    }
  }

  public static class CessionHistory extends GenericEnum
  {
    public static final long _all = 2L;
    public static final long _now = 0L;
    public static final long _old = 1L;

    private CessionHistory()
    {
      super.putEnum(Long.valueOf(2L), "全部");
      super.putEnum(Long.valueOf(0L), "当前割接");
      super.putEnum(Long.valueOf(1L), "历史割接");
    }
  }
}