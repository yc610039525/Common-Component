package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class ProtectEnum
{
  public static final ProtectType PROTECT_TYPE = new ProtectType(null);
  public static final ProtectGroupType PROTECT_GROUP_TYPE = new ProtectGroupType();
  public static final SwitchReason SWITCH_REASON = new SwitchReason(null);
  public static final ProtectObjType OBJECT_TYPE = new ProtectObjType(null);
  public static final ProtectSchemeState PROTECT_SCHEME_STATE = new ProtectSchemeState(null);
  public static final ReversionMode REVERSION_MODE = new ReversionMode(null);
  public static final SwitchType SWITCH_TYPE = new SwitchType();

  public static class ReversionMode extends GenericEnum
  {
    public static final long RM_UNKNOWN = 1L;
    public static final long RM_NON_REVERTIVE = 2L;
    public static final long RM_REVERTIVE = 2L;

    private ReversionMode()
    {
      super.putEnum(Long.valueOf(1L), "未知");
      super.putEnum(Long.valueOf(2L), "不恢复");
      super.putEnum(Long.valueOf(2L), "恢复");
    }
  }

  public static class ProtectSchemeState extends GenericEnum
  {
    public static final long PSS_UNKNOWN = 1L;
    public static final long PSS_AUTOMATIC = 2L;
    public static final long PSS_FORCED_OR_LOCKED_OUT = 2L;

    private ProtectSchemeState()
    {
      super.putEnum(Long.valueOf(1L), "未知");
      super.putEnum(Long.valueOf(2L), "自动保护倒换");
      super.putEnum(Long.valueOf(2L), "强制倒换或保护闭锁");
    }
  }

  public static class ProtectObjType extends GenericEnum
  {
    public static final long _ptp = 1L;
    public static final long _ctp = 2L;

    private ProtectObjType()
    {
      super.putEnum(Long.valueOf(1L), "端口");
      super.putEnum(Long.valueOf(2L), "时隙");
    }
  }

  public static class SwitchReason extends GenericEnum
  {
    public static final long _na = 1L;
    public static final long _restored = 2L;
    public static final long _signal_fail = 3L;
    public static final long _signal_mismatch = 4L;
    public static final long _signal_degrade = 5L;
    public static final long _automatic_switch = 6L;
    public static final long _manual = 7L;

    private SwitchReason()
    {
      super.putEnum(Long.valueOf(1L), "未知");
      super.putEnum(Long.valueOf(2L), "倒换恢复到原状态");
      super.putEnum(Long.valueOf(3L), "收到信号错误");
      super.putEnum(Long.valueOf(4L), "收信号正确，但信号源错误");
      super.putEnum(Long.valueOf(5L), "收到信号劣化");
      super.putEnum(Long.valueOf(6L), "自动倒换,原因未知");
      super.putEnum(Long.valueOf(7L), "手工倒换");
    }
  }

  public static class ProtectGroupType extends GenericEnum
  {
    public static final long _REUSE = 1L;
    public static final long _SNCP = 2L;
    public static final long _DEV = 3L;

    public ProtectGroupType()
    {
      super.putEnum(Long.valueOf(1L), "复用段保护");
      super.putEnum(Long.valueOf(2L), "SNCP保护");
      super.putEnum(Long.valueOf(3L), "设备保护");
    }
  }

  public static class ProtectReason extends GenericEnum
  {
    public static final long _unKnow = 1L;
    public static final long _manual = 2L;
    public static final long _DEV = 3L;

    public ProtectReason()
    {
      super.putEnum(Long.valueOf(1L), "未知");
      super.putEnum(Long.valueOf(2L), "人工倒换");
      super.putEnum(Long.valueOf(3L), "设备倒换");
    }
  }

  public static class SwitchType extends GenericEnum
  {
    public static final long _REUSE = 1L;
    public static final long _SNCP = 2L;
    public static final long _DEV = 3L;

    public SwitchType()
    {
      super.putEnum(Long.valueOf(1L), "复用段保护");
      super.putEnum(Long.valueOf(2L), "SNCP保护");
      super.putEnum(Long.valueOf(3L), "设备保护");
    }
  }

  public static class ProtectType extends GenericEnum
  {
    public static final long _msp_aps = 1L;
    public static final long _sncp = 2L;
    public static final long _x_2_fiber_blsr = 3L;
    public static final long _x_4_fiber_blsr = 4L;

    private ProtectType()
    {
      super.putEnum(Long.valueOf(1L), "复用段1+1");
      super.putEnum(Long.valueOf(2L), "复用段1：N");
      super.putEnum(Long.valueOf(3L), "2纤共享环");
      super.putEnum(Long.valueOf(4L), "4纤共享环");
    }
  }
}