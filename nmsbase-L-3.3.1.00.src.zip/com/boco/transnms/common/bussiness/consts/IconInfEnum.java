package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class IconInfEnum
{
  public static final IconInfType ICONINF_TYPE = new IconInfType(null);

  public static class IconInfType extends GenericEnum { public static final long _dis = 1L;
    public static final long _tools = 2L;
    public static final long _topo = 3L;
    public static final long _draw = 4L;
    public static final long _line = 5L;

    private IconInfType() { super.putEnum(Long.valueOf(1L), "区域");
      super.putEnum(Long.valueOf(2L), "工具箱");
      super.putEnum(Long.valueOf(3L), "拓扑");
      super.putEnum(Long.valueOf(4L), "画图");
      super.putEnum(Long.valueOf(5L), "管线");
    }
  }
}