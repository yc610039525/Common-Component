package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class TemplateEnum
{
  public static final TemplateType TEMPLATE_TYPE = new TemplateType(null);

  public static class TemplateType extends GenericEnum { public static final long _ne = 1L;
    public static final long _hole = 2L;
    public static final long _odf = 3L;
    public static final long _ddf = 4L;
    public static final long _odm = 5L;
    public static final long _ddm = 6L;
    public static final long _wire = 7L;
    public static final long _rack = 8L;
    public static final long _irms = 10L;
    public static final long _miscrack = 11L;
    public static final long _fibercab = 12L;
    public static final long _fiberdp = 13L;
    public static final long _fiberjointbox = 14L;
    public static final long _edmi = 15L;
    public static final long _edm = 16L;
    public static final long _card = 20L;

    private TemplateType() { super.putEnum(Long.valueOf(1L), "网元模板");
      super.putEnum(Long.valueOf(2L), "管道模板");
      super.putEnum(Long.valueOf(3L), "ODF模板");
      super.putEnum(Long.valueOf(4L), "DDF模板");
      super.putEnum(Long.valueOf(5L), "ODM模板");
      super.putEnum(Long.valueOf(6L), "DDM模板");
      super.putEnum(Long.valueOf(7L), "纤芯色谱");
      super.putEnum(Long.valueOf(8L), "机架模版");
      super.putEnum(Long.valueOf(11L), "综合机架模版");
      super.putEnum(Long.valueOf(12L), "光交接箱模版");
      super.putEnum(Long.valueOf(10L), "模版");
      super.putEnum(Long.valueOf(13L), "光分纤箱模板");
      super.putEnum(Long.valueOf(14L), "光接头盒模板");
      super.putEnum(Long.valueOf(15L), "EDMI模板");
      super.putEnum(Long.valueOf(16L), "EDM模板");
      super.putEnum(Long.valueOf(20L), "机盘模板");
    }
  }
}