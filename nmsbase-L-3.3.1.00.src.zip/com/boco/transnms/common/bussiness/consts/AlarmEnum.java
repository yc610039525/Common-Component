package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class AlarmEnum
{
  public static AlarmSeverity ALARM_SEVERITY = new AlarmSeverity(null);
  public static AlarmMarkType ALARM_MARK_TYPE = new AlarmMarkType(null);
  public static final OldAlarmSeverity oldAlarmSeverity = new OldAlarmSeverity(null);
  public static final ZTEAlarmSeverity zteAlarmSeverity = new ZTEAlarmSeverity(null);
  public static final NormarlAlarmSeverity normalAlarmSeverity = new NormarlAlarmSeverity(null);
  public static final FHAlarmSeverity fhAlarmSeverity = new FHAlarmSeverity(null);
  public static final TaskType taskType = new TaskType(null);
  public static AlarmSeverityNormal ALARM_SEVERITY_NORMAL = new AlarmSeverityNormal(null);
  public static final AlarmStandSeverity ALARM_STAND_SEVERITY = new AlarmStandSeverity(null);
  public static AlarmSheetDealTime Alarm_Sheet_Deal_Time = new AlarmSheetDealTime(null);
  public static final AlarmStandSeverityNormal ALARM_STAND_SEVERITY_NORMAL = new AlarmStandSeverityNormal(null);
  public static final SpeacialType SPEACIAL_TYPE = new SpeacialType(null);
  public static final RawVendorAlarmSeverity RAW_VENDOR_ALARM_SEVERITY = new RawVendorAlarmSeverity(null);
  public static final AlarmSeverityNormalNochoose ALARM_SEVERITY_NORMAL_NOCHOOSE = new AlarmSeverityNormalNochoose(null);
  public static final AlarmState ALARM_STATE = new AlarmState(null);
  public static final AlarmType ALARM_TYPE = new AlarmType(null);
  public static final AlarmTypeNochoose ALARM_TYPE_NOCHOOSE = new AlarmTypeNochoose(null);
  public static final AlarmCond ALARM_COND = new AlarmCond(null);
  public static final AlarmAnalyseType ALARMANAL_TYPE = new AlarmAnalyseType(null);
  public static final AnalyseObjectType ALARMOBJ_TYPE = new AnalyseObjectType(null);
  public static final AnalyseRdiFlag RDI_FLAG = new AnalyseRdiFlag(null);
  public static final AlarmAnalyseResult ANALYSE_RESULT = new AlarmAnalyseResult(null);
  public static final AlarmSyncState ALARM_SYNC_STATE = new AlarmSyncState(null);
  public static final HistoryQueryType HISTORY_QUERY_TYPE = new HistoryQueryType(null);

  public static final ActiveFlag ACTIVE_FLAG = new ActiveFlag(null);
  public static final FilterType FILTER_TYPE = new FilterType(null);
  public static final FilterContent FILTER_CONTENT = new FilterContent(null);
  public static final BatchAlarmStatus BATCH_ALARM_STATUS = new BatchAlarmStatus(null);
  public static final ProjectState PROJECT_STATE = new ProjectState(null);
  public static final ProjectStateNochoose PROJECT_STATE_NOCHOOSE = new ProjectStateNochoose(null);

  public static final AnalyseObjectTypeCode ANALYSE_OBJECTTYPECODE = new AnalyseObjectTypeCode(null);
  public static final AnalyseType ANALYSE_TYPE = new AnalyseType(null);
  public static final AlarmParaCode ALARM_PARA_CODE = new AlarmParaCode(null);
  public static final AlarmVoice ALARM_VOICE = new AlarmVoice(null);

  public static final SmsType SMS_TYPE = new SmsType(null);
  public static final SmsStatus SMS_STATUS = new SmsStatus(null);
  public static final MailType MAIL_TYPE = new MailType(null);
  public static final MailStatus MAIL_STATUS = new MailStatus(null);

  public static final AlarmNoteType ALARM_NOTE_TYPE = new AlarmNoteType(null);
  public static final MatchTime MATCH_TIME = new MatchTime(null);

  public static final Flag FLAG = new Flag(null);

  public static final AlarmSoundLevel ALARM_SOUND_LEVEL = new AlarmSoundLevel(null);
  public static final AlarmSoundPeriod ALARM_SOUND_PERIOD = new AlarmSoundPeriod(null);

  public static final AlarmImportance ALARM_IMPORTANCE = new AlarmImportance(null);
  public static final AlarmDisplayFilterImportance ALARM_DISPLAY_FILTER_IMPORTANCE = new AlarmDisplayFilterImportance(null);
  public static final AlarmDisplayFilterRate ALARM_DISPLAY_FILTER_RATE = new AlarmDisplayFilterRate(null);
  public static final AlarmDisplayFilterConfirm ALARM_DISPLAY_FILTER_CONFIRM = new AlarmDisplayFilterConfirm(null);
  public static final AlarmDisplayFilterNoteType ALARM_DISPLAY_FILTER_NOTE_TYPE = new AlarmDisplayFilterNoteType(null);
  public static final CommonFlag COMMON_FLAG = new CommonFlag(null);
  public static final CommonTraphGroupFlag Common_TraphGroupFlag = new CommonTraphGroupFlag(null);
  public static final AlarmScaleType scalePropType = new AlarmScaleType(null);
  public static final AlarmToEmosMsgType ALARM_TO_EMOS_MSGTYPE = new AlarmToEmosMsgType(null);
  public static final AlarmToEmosSendFlag ALARM_TO_EMOS_SENDFLAG = new AlarmToEmosSendFlag(null);
  public static final AlarmEffectTraphType Alarm_EFFECT_TRAPH_TYPE = new AlarmEffectTraphType(null);
  public static final AlarmScreenFilterRate ALARM_SCREEN_FILTER_RATE = new AlarmScreenFilterRate(null);
  public static final AlarmDisplayFilterObjectType ALARM_DISPLAY_FILTER_OBJECT_TYPE = new AlarmDisplayFilterObjectType(null);
  public static final EmosSheetState emosSheetState = new EmosSheetState(null);
  public static final emosMonitorControl EMOS_MONITOR_CONTROL = new emosMonitorControl(null);
  public static final SystemFilterTaskType systemFilterTaskType = new SystemFilterTaskType(null);
  public static final SystemFilterType systemFilterType = new SystemFilterType(null);
  public static final SystemAlarmFilterObjectType systemAlarmFilterObjectType = new SystemAlarmFilterObjectType(null);
  public static final SystemFilterPeriodType systemFilterPeriodType = new SystemFilterPeriodType(null);

  public static final SystemSheetFilterState systemSheetFilterState = new SystemSheetFilterState(null);
  public static final AlarmValidFlag alarmValidFlag = new AlarmValidFlag(null);
  public static AlarmEomsState alarmEomsState = new AlarmEomsState(null);
  public static final AlarmEomsMode alarmEomsMode = new AlarmEomsMode(null);
  public static final SendEomsIsAuto sendEomsIsAuto = new SendEomsIsAuto(null);
  public static final EmsAlarmSyncStat EmsAlarmSyncStat = new EmsAlarmSyncStat(null);
  public static final AlarmFilterObjectType ALARM_FILTER_OBJECT_TYPE = new AlarmFilterObjectType(null);
  public static final Month_select Month_Select = new Month_select(null);
  public static final RuleType ruleType = new RuleType(null);
  public static final RuleFlag ruleFlag = new RuleFlag(null);
  public static final TraphServiceType TraphServiceType = new TraphServiceType(null);
  public static final AlarmDisplayRuleRate alarmDisplayRuleRate = new AlarmDisplayRuleRate(null);
  public static final NeSingeType neSingeType = new NeSingeType(null);
  public static final NpnAlarmSyncType npnAlarmSyncType = new NpnAlarmSyncType(null);
  public static final NpnAlarmSyncStatus npnAlarmSyncStatus = new NpnAlarmSyncStatus(null);
  public static final NpnAlarmSyncTimeType npnAlarmSyncTimeType = new NpnAlarmSyncTimeType(null);
  public static final NpnAlarmSyncMode npnAlarmSyncMode = new NpnAlarmSyncMode(null);
  public static final AlarmSendToEOMSFlag alarmSendToEOMSFlag = new AlarmSendToEOMSFlag(null);
  public static final AlarmProcessFlag alarmProcessFlag = new AlarmProcessFlag(null);
  public static final ProtectIsHistory protectIsHistory = new ProtectIsHistory(null);
  public static final ProtectType protectType = new ProtectType(null);
  public static final AlarmBackupCfgType alarmBackupCfgType = new AlarmBackupCfgType(null);
  public static final AlarmBackupType alarmBackupType = new AlarmBackupType(null);
  public static final AlarmStandDevType alarmStandDevType = new AlarmStandDevType(null);
  public static final AlarmStandType ALARM_STAND_TYPE = new AlarmStandType(null);
  public static final AlarmStandRateRela RATE_RELA = new AlarmStandRateRela(null);
  public static final AlarmSendRuleType ALARM_SEND_RULE_TYPE = new AlarmSendRuleType(null);
  public static final IsTurnHisAlarm isTurnHisAlarm = new IsTurnHisAlarm(null);
  public static final AlarmSendRulePropType ALARM_SEND_RULE_PROPTYPE = new AlarmSendRulePropType(null);
  public static final IsServiceAlarm IS_SERVICE_ALARM = new IsServiceAlarm(null);
  public static final AlarmStatus ALARM_STATUS = new AlarmStatus(null);
  public static final PathSwitchType PATH_SWITCH_TYPE = new PathSwitchType(null);
  public static final AlarmSyncDetailState DETAIL_ALARM_STATE = new AlarmSyncDetailState(null);
  public static final TraphGroupVoiceRemind TRAPH_GROUP_VOICE_REMIND = new TraphGroupVoiceRemind(null);
  public static final FaultalarmType Fault_alarmType = new FaultalarmType(null);

  public static final EmsAlarmType EMS_ALARM_TYPE = new EmsAlarmType(null);
  public static final AlarmTypeSimpleEquip ALARM_TYPE_SIMPLE_EQUIP = new AlarmTypeSimpleEquip(null);
  public static final AlarmTypeSimpleComm ALARM_TYPE_SIMPLE_COMM = new AlarmTypeSimpleComm(null);
  public static final AlarmTypeSimpleMaintenance ALARM_TYPE_SIMPLE_MAINTENANCE = new AlarmTypeSimpleMaintenance(null);
  public static final AlarmTypeSimpleEnv ALARM_TYPE_SIMPLE_ENV = new AlarmTypeSimpleEnv(null);
  public static final LogicalClass LOGICAL_CLASS = new LogicalClass(null);
  public static final LogicalSubClass LOGICAL_SUBCLASS = new LogicalSubClass(null);

  public static final MasterSlaveType MASTER_SLAVE_TYPE = new MasterSlaveType(null);

  public static class MasterSlaveType extends GenericEnum
  {
    public static final long _Not_Connect = 1L;
    public static final long _Deri = 2L;
    public static final long _Sour_deri = 3L;
    public static final long _No_deri_main = 4L;
    public static final long _slave = 5L;

    private MasterSlaveType()
    {
      super.putEnum(Long.valueOf(1L), "无关联");
      super.putEnum(Long.valueOf(2L), "衍生告警");
      super.putEnum(Long.valueOf(3L), "衍生告警根源告警");
      super.putEnum(Long.valueOf(4L), "无衍生的主告警");
      super.putEnum(Long.valueOf(5L), "非根源的从告警");
    }
  }

  public static class TraphGroupVoiceRemind extends GenericEnum
  {
    public static final long _unRemind = 0L;
    public static final long _remind = 1L;

    private TraphGroupVoiceRemind()
    {
      super.putEnum(Long.valueOf(0L), "提示声音关闭");
      super.putEnum(Long.valueOf(1L), "提示声音开启");
    }
  }

  public static class AlarmSyncDetailState extends GenericEnum
  {
    public static final long _add = 1L;
    public static final long _delete = 2L;

    private AlarmSyncDetailState()
    {
      super.putEnum(Long.valueOf(1L), "新增");
      super.putEnum(Long.valueOf(2L), "删除");
    }
  }

  public static class PathSwitchType extends GenericEnum
  {
    public static final long _0 = 0L;
    public static final long _1 = 1L;
    public static final long _2 = 2L;
    public static final long _3 = 3L;

    private PathSwitchType()
    {
      super.putEnum(Long.valueOf(0L), "正常");
      super.putEnum(Long.valueOf(1L), "单边断");
      super.putEnum(Long.valueOf(2L), "双边断");
      super.putEnum(Long.valueOf(3L), "无保护中断");
    }
  }

  public static class FaultalarmType extends GenericEnum
  {
    public static final long _no = 1L;
    public static final long _child = 2L;
    public static final long _parent = 3L;

    private FaultalarmType()
    {
      super.putEnum(Long.valueOf(1L), "无衍生");
      super.putEnum(Long.valueOf(2L), "衍生子告警");
      super.putEnum(Long.valueOf(3L), "衍生主告警");
    }
  }

  public static class AlarmStatus extends GenericEnum
  {
    public static final long _1 = 1L;
    public static final long _2 = 2L;

    private AlarmStatus()
    {
      super.putEnum(Long.valueOf(1L), "已确认");
      super.putEnum(Long.valueOf(2L), "未确认");
    }
  }

  public static class AlarmSheetDealTime extends GenericEnum
  {
    public static final long _1 = 1L;
    public static final long _2 = 2L;

    private AlarmSheetDealTime()
    {
      super.putEnum(Long.valueOf(1L), "已超时");
      super.putEnum(Long.valueOf(2L), "未超时");
    }
  }

  public static class IsTurnHisAlarm extends GenericEnum
  {
    public static final long _1 = 1L;
    public static final long _2 = 2L;

    private IsTurnHisAlarm()
    {
      super.putEnum(Long.valueOf(1L), "清除转历史");
      super.putEnum(Long.valueOf(2L), "清除不转历史");
    }
  }

  public static class AlarmStandRateRela extends GenericEnum
  {
    public static final long _1 = 0L;
    public static final long _2 = 1L;

    private AlarmStandRateRela()
    {
      super.putEnum(Long.valueOf(0L), "不相关");
      super.putEnum(Long.valueOf(1L), "相关");
    }
  }

  public static class AlarmStandType extends GenericEnum
  {
    public static final long _device = 1L;
    public static final long _perform = 2L;
    public static final long _failure = 3L;
    public static final long _service = 4L;
    public static final long _enviralarm = 5L;
    public static final long _communication = 6L;
    public static final long _running = 7L;
    public static final long _environment = 8L;
    public static final long _dealmistake = 9L;
    public static final long _devicefault = 10L;
    public static final long _commquality = 11L;
    public static final long _servicequality = 12L;
    public static final long _safealarm = 13L;

    private AlarmStandType()
    {
      super.putEnum(Long.valueOf(1L), "设备告警");
      super.putEnum(Long.valueOf(2L), "性能告警");
      super.putEnum(Long.valueOf(3L), "处理失败告警");
      super.putEnum(Long.valueOf(4L), "服务质量告警");
      super.putEnum(Long.valueOf(5L), "环境告警");
      super.putEnum(Long.valueOf(6L), "通信告警");
      super.putEnum(Long.valueOf(7L), "运行告警");
      super.putEnum(Long.valueOf(8L), "环境");
      super.putEnum(Long.valueOf(9L), "处理出错");
      super.putEnum(Long.valueOf(10L), "设备故障");
      super.putEnum(Long.valueOf(11L), "通信质量");
      super.putEnum(Long.valueOf(12L), "业务质量");
      super.putEnum(Long.valueOf(13L), "安全告警");
    }
  }

  public static class AlarmStandDevType extends GenericEnum
  {
    public static final long _na = 0L;
    public static final long _sdh = 1L;
    public static final long _wdm = 2L;
    public static final long _ems = 3L;
    public static final long _ptn = 4L;
    public static final long _pon = 5L;
    public static final long _olp = 6L;
    public static final long _otn = 7L;

    private AlarmStandDevType()
    {
      super.putEnum(Long.valueOf(0L), "");
      super.putEnum(Long.valueOf(1L), "SDH");
      super.putEnum(Long.valueOf(2L), "WDM");
      super.putEnum(Long.valueOf(3L), "网管");
      super.putEnum(Long.valueOf(4L), "PTN");
      super.putEnum(Long.valueOf(5L), "PON");
      super.putEnum(Long.valueOf(6L), "OLP");
      super.putEnum(Long.valueOf(7L), "OTN");
    }
  }

  public static class AlarmBackupType extends GenericEnum
  {
    public static final long _CURRENT = 1L;
    public static final long _NEXT = 2L;

    private AlarmBackupType()
    {
      super.putEnum(Long.valueOf(1L), "当月配置");
      super.putEnum(Long.valueOf(2L), "下月配置");
    }
  }

  public static class AlarmBackupCfgType extends GenericEnum
  {
    public static final long _COL = 1L;
    public static final long _ALARMNAME = 2L;

    private AlarmBackupCfgType()
    {
      super.putEnum(Long.valueOf(1L), "告警导出列");
      super.putEnum(Long.valueOf(2L), "告警名称");
    }
  }

  public static class ProtectType extends GenericEnum
  {
    public static final long _A = 1L;
    public static final long _B = 2L;
    public static final long _C = 3L;

    private ProtectType()
    {
      super.putEnum(Long.valueOf(1L), "A");
      super.putEnum(Long.valueOf(2L), "B");
      super.putEnum(Long.valueOf(3L), "C");
    }
  }

  public static class ProtectIsHistory extends GenericEnum
  {
    public static final long _curr = 1L;
    public static final long _his = 2L;

    private ProtectIsHistory()
    {
      super.putEnum(Long.valueOf(1L), "未归档");
      super.putEnum(Long.valueOf(2L), "已归档");
    }
  }

  public static class AlarmSendToEOMSFlag extends GenericEnum
  {
    public static final long _curr = 1L;
    public static final long _his = 2L;

    private AlarmSendToEOMSFlag()
    {
      super.putEnum(Long.valueOf(1L), "未派单");
      super.putEnum(Long.valueOf(2L), "已派单");
    }
  }

  public static class AlarmProcessFlag extends GenericEnum
  {
    public static final long _curr = 2L;
    public static final long _his = 1L;

    private AlarmProcessFlag()
    {
      super.putEnum(Long.valueOf(2L), "已确认");
      super.putEnum(Long.valueOf(1L), "未确认");
    }
  }

  public static class NpnAlarmSyncTimeType extends GenericEnum
  {
    public static final long _netime = 1L;
    public static final long _endtime = 2L;

    private NpnAlarmSyncTimeType()
    {
      super.putEnum(Long.valueOf(1L), "产生时间");
      super.putEnum(Long.valueOf(2L), "消失时间");
    }
  }

  public static class NpnAlarmSyncStatus extends GenericEnum
  {
    public static final long _noSync = 1L;
    public static final long _syncing = 2L;
    public static final long _succ = 3L;
    public static final long _fail = 4L;

    private NpnAlarmSyncStatus()
    {
      super.putEnum(Long.valueOf(1L), "未同步");
      super.putEnum(Long.valueOf(2L), "正在同步");
      super.putEnum(Long.valueOf(3L), "同步成功");
      super.putEnum(Long.valueOf(4L), "同步失败");
    }
  }

  public static class NpnAlarmSyncType extends GenericEnum
  {
    public static final long _curr = 1L;
    public static final long _his = 2L;

    private NpnAlarmSyncType()
    {
      super.putEnum(Long.valueOf(1L), "当前告警");
      super.putEnum(Long.valueOf(2L), "历史告警");
    }
  }

  public static class NpnAlarmSyncMode extends GenericEnum
  {
    public static final long _manual = 1L;
    public static final long _auto = 2L;

    private NpnAlarmSyncMode()
    {
      super.putEnum(Long.valueOf(1L), "手工同步");
      super.putEnum(Long.valueOf(2L), "自动同步");
    }
  }

  public static class TraphServiceType extends GenericEnum
  {
    public static final long _IA = 2L;
    public static final long _CL = 3L;
    public static final long _LB = 4L;
    public static final long _LC = 5L;
    public static final long _LD = 6L;
    public static final long _LA = 7L;
    public static final long _SL = 8L;
    public static final long _V = 9L;
    public static final long _DDN = 10L;
    public static final long _DCN = 11L;
    public static final long _IPGSM = 12L;
    public static final long _OA = 13L;
    public static final long _NM = 14L;
    public static final long _GC = 15L;
    public static final long _NP = 16L;
    public static final long _H = 17L;
    public static final long _HLR = 18L;
    public static final long _SM = 19L;
    public static final long _VM = 20L;
    public static final long _CS = 21L;
    public static final long _GP = 22L;
    public static final long _SSP = 23L;
    public static final long _CT = 24L;
    public static final long _CU = 25L;
    public static final long _CR = 26L;
    public static final long _BS = 27L;
    public static final long _ATM = 28L;
    public static final long _IPBB = 29L;
    public static final long _BSC = 30L;
    public static final long _IPCLI = 31L;
    public static final long _IPICP = 32L;
    public static final long _IPGSN = 33L;
    public static final long _WA = 34L;
    public static final long _SS = 35L;
    public static final long _IS = 36L;
    public static final long _VC = 37L;
    public static final long _MG = 38L;
    public static final long _MD = 39L;
    public static final long _IPSS = 40L;
    public static final long _TS = 41L;

    private TraphServiceType()
    {
      super.putEnum(Long.valueOf(2L), "IAPHH1");
      super.putEnum(Long.valueOf(3L), "CL");
      super.putEnum(Long.valueOf(4L), "LB");
      super.putEnum(Long.valueOf(5L), "LC");
      super.putEnum(Long.valueOf(6L), "LD");
      super.putEnum(Long.valueOf(7L), "LA");
      super.putEnum(Long.valueOf(8L), "SL");
      super.putEnum(Long.valueOf(9L), "V");
      super.putEnum(Long.valueOf(10L), "DDN");
      super.putEnum(Long.valueOf(11L), "DCN");
      super.putEnum(Long.valueOf(12L), "IPGSM");
      super.putEnum(Long.valueOf(13L), "OA");
      super.putEnum(Long.valueOf(14L), "NM");
      super.putEnum(Long.valueOf(15L), "GC");
      super.putEnum(Long.valueOf(16L), "NP");
      super.putEnum(Long.valueOf(17L), "H");
      super.putEnum(Long.valueOf(18L), "HLR");
      super.putEnum(Long.valueOf(19L), "SM");
      super.putEnum(Long.valueOf(20L), "VM");
      super.putEnum(Long.valueOf(21L), "CS");
      super.putEnum(Long.valueOf(22L), "GP");
      super.putEnum(Long.valueOf(23L), "SSP");
      super.putEnum(Long.valueOf(24L), "CT");
      super.putEnum(Long.valueOf(25L), "CU");
      super.putEnum(Long.valueOf(26L), "CR");
      super.putEnum(Long.valueOf(27L), "BS");
      super.putEnum(Long.valueOf(28L), "ATM");
      super.putEnum(Long.valueOf(29L), "IPBB");
      super.putEnum(Long.valueOf(30L), "BSC");
      super.putEnum(Long.valueOf(31L), "IPCLI");
      super.putEnum(Long.valueOf(32L), "IPICP");
      super.putEnum(Long.valueOf(33L), "IPGSN");
      super.putEnum(Long.valueOf(34L), "WA");
      super.putEnum(Long.valueOf(35L), "SS");
      super.putEnum(Long.valueOf(36L), "IS");
      super.putEnum(Long.valueOf(37L), "VC");
      super.putEnum(Long.valueOf(38L), "MG");
      super.putEnum(Long.valueOf(39L), "MD");
      super.putEnum(Long.valueOf(40L), "IPSS");
      super.putEnum(Long.valueOf(41L), "TS");
    }
  }

  public static class AlarmNeConfigType extends GenericEnum
  {
    public static final long _unknown = 0L;
    public static final long _fttb = 1L;
    public static final long _ftth = 2L;
    public static final long _fttc = 3L;
    public static final long _ftto = 4L;
    public static final long _olt = 5L;
    public static final long _sdh = 6L;
    public static final long _pdh = 7L;
    public static final long _wdm = 8L;
    public static final long _sdhwave = 9L;
    public static final long _mix = 10L;
    public static final long _unknown2 = 11L;
    public static final long _pdhwave = 12L;
    public static final long _ptn = 13L;
    public static final long _pon = 14L;
    public static final long _olp = 15L;
    public static final long _otn = 16L;

    private AlarmNeConfigType()
    {
      super.putEnum(Long.valueOf(0L), "UNKNOWN");
      super.putEnum(Long.valueOf(1L), "FTTB");
      super.putEnum(Long.valueOf(2L), "FTTH");
      super.putEnum(Long.valueOf(3L), "FTTC");
      super.putEnum(Long.valueOf(4L), "FTTO");
      super.putEnum(Long.valueOf(5L), "OLT");
      super.putEnum(Long.valueOf(6L), "SDH");
      super.putEnum(Long.valueOf(7L), "PDH");
      super.putEnum(Long.valueOf(8L), "WDM");
      super.putEnum(Long.valueOf(9L), "Sdh微波");
      super.putEnum(Long.valueOf(10L), "混合");
      super.putEnum(Long.valueOf(11L), "未知2");
      super.putEnum(Long.valueOf(12L), "Pdh微波");
      super.putEnum(Long.valueOf(13L), "PTN");
      super.putEnum(Long.valueOf(14L), "PON");
      super.putEnum(Long.valueOf(15L), "OLP");
      super.putEnum(Long.valueOf(16L), "OTN");
    }
  }

  public static class NeSingeType extends GenericEnum
  {
    public static final long _sdh = 1L;
    public static final long _pdh = 2L;
    public static final long _wdm = 3L;
    public static final long _ptn = 8L;
    public static final long _pon = 9L;
    public static final long _olp = 10L;

    private NeSingeType()
    {
      super.putEnum(Long.valueOf(1L), "SDH");
      super.putEnum(Long.valueOf(2L), "PDH");
      super.putEnum(Long.valueOf(3L), "WDM");
      super.putEnum(Long.valueOf(8L), "PTN");
      super.putEnum(Long.valueOf(9L), "PON");
      super.putEnum(Long.valueOf(10L), "OLP");
    }
  }

  public static class RuleFlag extends GenericEnum
  {
    public static final long _new = 1L;
    public static final long _delete = 2L;

    private RuleFlag()
    {
      super.putEnum(Long.valueOf(1L), "创建");
      super.putEnum(Long.valueOf(2L), "删除");
    }
  }

  public static class RuleType extends GenericEnum
  {
    public static final long _send = 1L;
    public static final long _notsend = 2L;

    private RuleType()
    {
      super.putEnum(Long.valueOf(1L), "提取");
      super.putEnum(Long.valueOf(2L), "不提取");
    }
  }

  public static class Month_select extends GenericEnum
  {
    public static final long _one = 1L;
    public static final long _two = 2L;
    public static final long _three = 3L;
    public static final long _four = 4L;
    public static final long _five = 5L;
    public static final long _six = 6L;

    private Month_select()
    {
      super.putEnum(Long.valueOf(1L), "一个月");
      super.putEnum(Long.valueOf(2L), "两个月");
      super.putEnum(Long.valueOf(3L), "三个月");
      super.putEnum(Long.valueOf(4L), "四个月");
      super.putEnum(Long.valueOf(5L), "五个月");
      super.putEnum(Long.valueOf(6L), "六个月");
    }
  }

  public static class EmsAlarmSyncStat extends GenericEnum
  {
    public static final long _no_sync = 0L;
    public static final long _sync_fault = 1L;
    public static final long _sync_success = 2L;
    public static final long _in_sync = 3L;
    public static final long _sync_drop = 4L;
    public static final long _sync_repeat = 5L;

    private EmsAlarmSyncStat()
    {
      super.putEnum(Long.valueOf(0L), "");
      super.putEnum(Long.valueOf(1L), "同步失败");
      super.putEnum(Long.valueOf(2L), "同步成功");
      super.putEnum(Long.valueOf(3L), "正在同步");
      super.putEnum(Long.valueOf(4L), "同步丢弃");
      super.putEnum(Long.valueOf(5L), "同步重复");
    }
  }

  public static class SendEomsIsAuto extends GenericEnum
  {
    public static final long _send = 1L;
    public static final long _notsend = 2L;

    private SendEomsIsAuto()
    {
      super.putEnum(Long.valueOf(1L), "是");
      super.putEnum(Long.valueOf(2L), "否");
    }
  }

  public static class AlarmEomsMode extends GenericEnum
  {
    public static final long _manual = 1L;
    public static final long _auto = 2L;
    public static final long _taskmanual = 3L;
    public static final long _taskauto = 4L;
    public static final long _autohand = 5L;

    private AlarmEomsMode()
    {
      super.putEnum(Long.valueOf(1L), "手工故障派单");
      super.putEnum(Long.valueOf(2L), "自动故障派单");
      super.putEnum(Long.valueOf(3L), "手工业务派单");
      super.putEnum(Long.valueOf(4L), "自动业务派单");
      super.putEnum(Long.valueOf(5L), "手工自动故障派单");
    }
  }

  public static class AlarmEomsState extends GenericEnum
  {
    public static final long _notsend = 1L;
    public static final long _notdeal = 2L;
    public static final long _dealed = 3L;
    public static final long _isover = 4L;
    public static final long _deposed = 5L;
    public static final long _userstop = 6L;
    public static final long _waitsend = 7L;
    public static final long _sendfailed = 8L;
    public static final long _addmore = 9L;
    public static final long _addmorefailed = 10L;
    public static final long _useradd = 11L;
    public static final long _useraddfailed = 12L;

    private AlarmEomsState()
    {
      super.putEnum(Long.valueOf(1L), "未派单");
      super.putEnum(Long.valueOf(2L), "已派单");
      super.putEnum(Long.valueOf(3L), "已派单已处理");
      super.putEnum(Long.valueOf(4L), "已归档");
      super.putEnum(Long.valueOf(5L), "废单");
      super.putEnum(Long.valueOf(6L), "人工中止派单");
      super.putEnum(Long.valueOf(7L), "等待派单");
      super.putEnum(Long.valueOf(8L), "派单失败");
      super.putEnum(Long.valueOf(9L), "自动追加成功");
      super.putEnum(Long.valueOf(10L), "自动追加失败");
      super.putEnum(Long.valueOf(11L), "手动追加成功");
      super.putEnum(Long.valueOf(12L), "手动追加失败");
    }
  }

  public static class AlarmValidFlag extends GenericEnum
  {
    public static final long _normal = 1L;
    public static final long _project = 2L;
    public static final long _maintenance = 3L;

    private AlarmValidFlag()
    {
      super.putEnum(Long.valueOf(1L), "正常");
      super.putEnum(Long.valueOf(2L), "工程");
      super.putEnum(Long.valueOf(3L), "维护");
    }
  }

  public static class SystemSheetFilterState extends GenericEnum
  {
    public static final long _unprocess = 3L;
    public static final long _processing = 4L;
    public static final long _processed = 5L;
    public static final long _cancel = 7L;

    private SystemSheetFilterState()
    {
      super.putEnum(Long.valueOf(3L), "待执行");
      super.putEnum(Long.valueOf(4L), "执行中");
      super.putEnum(Long.valueOf(5L), "执行完毕");
      super.putEnum(Long.valueOf(7L), "取消执行");
    }
  }

  public static class SystemFilterPeriodType extends GenericEnum
  {
    public static final long _period = 1L;
    public static final long _notperiod = 2L;

    private SystemFilterPeriodType()
    {
      super.putEnum(Long.valueOf(1L), "周期");
      super.putEnum(Long.valueOf(2L), "非周期");
    }
  }

  public static class SystemFilterType extends GenericEnum
  {
    public static final long _cession = 1L;
    public static final long _project = 2L;
    public static final long _traph = 3L;
    public static final long _service = 4L;
    public static final long _dispatch = 5L;

    private SystemFilterType()
    {
      super.putEnum(Long.valueOf(1L), "割接任务");
      super.putEnum(Long.valueOf(2L), "工程状态任务");
      super.putEnum(Long.valueOf(3L), "业务电路任务");
      super.putEnum(Long.valueOf(4L), "维护任务");
      super.putEnum(Long.valueOf(5L), "调单电路任务");
    }
  }

  public static class SystemFilterTaskType extends GenericEnum
  {
    public static final long _auto = 1L;
    public static final long _manul = 2L;

    private SystemFilterTaskType()
    {
      super.putEnum(Long.valueOf(1L), "自动");
      super.putEnum(Long.valueOf(2L), "手工");
    }
  }

  public static class emosMonitorControl extends GenericEnum
  {
    public static final long _true = 1L;
    public static final long _false = 0L;

    private emosMonitorControl()
    {
      super.putEnum(Long.valueOf(1L), "是");
      super.putEnum(Long.valueOf(0L), "否");
    }
  }

  public static class EmosSheetState extends GenericEnum
  {
    public static final long _SheetSend = 1L;
    public static final long _SheetClearNot = 2L;
    public static final long _SheetClear = 3L;
    public static final long _SheetTemp = 4L;
    public static final long _SheetMain = 5L;

    private EmosSheetState()
    {
      super.putEnum(Long.valueOf(1L), "派单，草稿生成工单");
      super.putEnum(Long.valueOf(2L), "销单，工单处理完毕，告警未修复");
      super.putEnum(Long.valueOf(3L), "销单，工单处理完毕，告警已修复");
      super.putEnum(Long.valueOf(4L), "派单，生成草稿单");
      super.putEnum(Long.valueOf(5L), "派单");
    }
  }

  public static class AlarmEffectTraphType extends GenericEnum
  {
    public static final long _na = 0L;
    public static final long _noeffect = 1L;
    public static final long _effecttraph = 2L;
    public static final long _effectimportant = 3L;

    private AlarmEffectTraphType()
    {
      super.putEnum(Long.valueOf(0L), "不关心");
      super.putEnum(Long.valueOf(1L), "不影响");
      super.putEnum(Long.valueOf(2L), "影响电路");
      super.putEnum(Long.valueOf(3L), "影响重要电路");
    }
  }

  public static class AlarmToEmosSendFlag extends GenericEnum
  {
    public static final long _notSend = 1L;
    public static final long _SendSuccess = 2L;
    public static final long _SendFail = 3L;
    public static final long _noSend = 4L;

    private AlarmToEmosSendFlag()
    {
      super.putEnum(Long.valueOf(1L), "未发送");
      super.putEnum(Long.valueOf(2L), "发送成功");
      super.putEnum(Long.valueOf(3L), "发送失败");
      super.putEnum(Long.valueOf(4L), "不发送");
    }
  }

  public static class AlarmToEmosMsgType extends GenericEnum
  {
    public static final long _alarmCreateAuto = 1L;
    public static final long _alarmClearAuto = 2L;
    public static final long _alarmForceClear = 3L;
    public static final long _alarmCreateManual = 4L;
    public static final long _alarmCreateEdit = 5L;
    public static final long _taskManual = 6L;
    public static final long _taskAuto = 7L;
    public static final long _alarmAutoHand = 8L;

    private AlarmToEmosMsgType()
    {
      super.putEnum(Long.valueOf(1L), "自动派发告警产生");
      super.putEnum(Long.valueOf(2L), "派发告警消失");
      super.putEnum(Long.valueOf(3L), "手动强制告警删除");
      super.putEnum(Long.valueOf(4L), "手动派发告警产生");
      super.putEnum(Long.valueOf(5L), "手动派发告警产生");
      super.putEnum(Long.valueOf(6L), "手动派发业务工单产生");
      super.putEnum(Long.valueOf(7L), "自动派发业务工单产生");
      super.putEnum(Long.valueOf(8L), "手工自动派发告警产生");
    }
  }

  public static class HistoryQueryType extends GenericEnum
  {
    public static final long sAlarmTimePicker = 0L;
    public static final long districtT = 1L;
    public static final long severityList = 2L;
    public static final long alarmdescList = 3L;
    public static final long capacityList = 4L;
    public static final long deviceTypeCombo = 5L;
    public static final long logicalClassCombo = 6L;
    public static final long logicalSubclassCombo = 7L;
    public static final long isStandCombo = 8L;
    public static final long eAlarmTimePicker = 9L;
    public static final long vendorList = 10L;
    public static final long alarmStateList = 11L;
    public static final long startDuringTimeText = 12L;
    public static final long endDuringTimeText = 13L;
    public static final long comfirmFlag = 14L;
    public static final long ackUserText = 15L;
    public static final long sAckTimePicker = 16L;
    public static final long eAckTimePicker = 17L;
    public static final long sEndTimePicker = 18L;
    public static final long emsList = 19L;
    public static final long alarmTypeList = 20L;
    public static final long alarmphyTree = 21L;
    public static final long SiteSelectWindow = 22L;
    public static final long netandsysTree = 23L;
    public static final long rateList = 24L;
    public static final long dispatchNameText = 25L;
    public static final long stateList = 26L;
    public static final long eEndTimePicker = 27L;
    public static final long neSelectWindow = 28L;
    public static final long traphSelectWindow = 29L;
    public static final long vpCombo = 30L;
    public static final long eomsSheetNumText = 31L;
    public static final long cuidText = 32L;
    public static final long markTypeList = 33L;
    public static final long slaLevelCombo = 34L;
    public static final long alarmnameList = 35L;
    public static final long concernFlag = 36L;

    private HistoryQueryType()
    {
      super.putEnum(Long.valueOf(0L), "产生时间<");
      super.putEnum(Long.valueOf(1L), "地区");
      super.putEnum(Long.valueOf(2L), "告警级别");
      super.putEnum(Long.valueOf(3L), "告警描述");
      super.putEnum(Long.valueOf(4L), "告警速率");
      super.putEnum(Long.valueOf(5L), "设备类型");
      super.putEnum(Long.valueOf(6L), "逻辑类");
      super.putEnum(Long.valueOf(7L), "逻辑子类");
      super.putEnum(Long.valueOf(8L), "是否标准化");
      super.putEnum(Long.valueOf(9L), "结束时间");
      super.putEnum(Long.valueOf(10L), "厂家");
      super.putEnum(Long.valueOf(11L), "告警状态");
      super.putEnum(Long.valueOf(12L), "告警历时<");
      super.putEnum(Long.valueOf(13L), "告警历时>");
      super.putEnum(Long.valueOf(14L), "是否确认");
      super.putEnum(Long.valueOf(15L), "确认用户");
      super.putEnum(Long.valueOf(16L), "确认时间<");
      super.putEnum(Long.valueOf(17L), "确认时间>");
      super.putEnum(Long.valueOf(18L), "结束时间");
      super.putEnum(Long.valueOf(19L), "Ems");
      super.putEnum(Long.valueOf(20L), "告警类型");
      super.putEnum(Long.valueOf(21L), "告警位置");
      super.putEnum(Long.valueOf(22L), "站点");
      super.putEnum(Long.valueOf(23L), "子网传输系统");
      super.putEnum(Long.valueOf(24L), "告警速率");
      super.putEnum(Long.valueOf(25L), "工单号");
      super.putEnum(Long.valueOf(26L), "状态");
      super.putEnum(Long.valueOf(27L), "结束时间");
      super.putEnum(Long.valueOf(28L), "网元");
      super.putEnum(Long.valueOf(29L), "电路选择");
      super.putEnum(Long.valueOf(30L), "客户");
      super.putEnum(Long.valueOf(31L), "派单号");
      super.putEnum(Long.valueOf(32L), "Cuid");
      super.putEnum(Long.valueOf(33L), "标注类型");
      super.putEnum(Long.valueOf(34L), "Sla级别");
      super.putEnum(Long.valueOf(35L), "告警名称");
      super.putEnum(Long.valueOf(36L), "是否关注");
    }
  }

  public static class AlarmSyncState extends GenericEnum
  {
    public static final long _unsync = 0L;
    public static final long _syncFail = 1L;
    public static final long _syncSucc = 2L;
    public static final long _syncing = 3L;
    public static final long _syncdrop = 4L;
    public static final long _syncrepeat = 5L;

    private AlarmSyncState()
    {
      super.putEnum(Long.valueOf(0L), "未同步");
      super.putEnum(Long.valueOf(1L), "同步失败");
      super.putEnum(Long.valueOf(2L), "同步成功");
      super.putEnum(Long.valueOf(3L), "同步中");
      super.putEnum(Long.valueOf(4L), "同步放弃");
      super.putEnum(Long.valueOf(5L), "同步重复");
    }
  }

  public static class AlarmScaleType extends GenericEnum
  {
    public static final long _alarmName = 1L;
    public static final long _alarmType = 2L;
    public static final long _alarmLevel = 3L;

    private AlarmScaleType()
    {
      super.putEnum(Long.valueOf(1L), "告警名称");
      super.putEnum(Long.valueOf(2L), "告警类型");
      super.putEnum(Long.valueOf(3L), "告警级别");
    }
  }

  public static class AlarmDisplayFilterNoteType extends GenericEnum
  {
    public static final long _cur = 1L;
    public static final long _his = 2L;

    private AlarmDisplayFilterNoteType()
    {
      super.putEnum(Long.valueOf(1L), "告警产生");
      super.putEnum(Long.valueOf(2L), "告警消失");
    }
  }

  public static class CommonTraphGroupFlag extends GenericEnum
  {
    public static final long _flag = 0L;
    public static final long _yesFlag = 1L;
    public static final long _noFlag = 2L;

    private CommonTraphGroupFlag()
    {
      super.putEnum(Long.valueOf(0L), "");
      super.putEnum(Long.valueOf(1L), "是");
      super.putEnum(Long.valueOf(2L), "否");
    }
  }

  public static class CommonFlag extends GenericEnum
  {
    public static final long _yesFlag = 1L;
    public static final long _noFlag = 2L;

    private CommonFlag()
    {
      super.putEnum(Long.valueOf(1L), "是");
      super.putEnum(Long.valueOf(2L), "否");
    }
  }

  public static class AlarmDisplayFilterConfirm extends GenericEnum
  {
    public static final long _none = 0L;
    public static final long _confirmed = 1L;
    public static final long _unconfirmed = 2L;

    private AlarmDisplayFilterConfirm()
    {
      super.putEnum(Long.valueOf(0L), "");
      super.putEnum(Long.valueOf(1L), "已确认");
      super.putEnum(Long.valueOf(2L), "未确认");
    }
  }

  public static class SystemAlarmFilterObjectType extends GenericEnum
  {
    public static final long _net = 1L;
    public static final long _sys = 2L;
    public static final long _ems = 3L;
    public static final long _ne = 4L;
    public static final long _card = 5L;
    public static final long _ptp = 6L;
    public static final long _ctp = 7L;
    public static final long _traph = 8L;
    public static final long _vendorAlarm = 9L;
    public static final long _equipmentHolder = 10L;

    private SystemAlarmFilterObjectType()
    {
      super.putEnum(Long.valueOf(1L), "子网");
      super.putEnum(Long.valueOf(2L), "系统");
      super.putEnum(Long.valueOf(3L), "网元");
      super.putEnum(Long.valueOf(4L), "网元");
      super.putEnum(Long.valueOf(5L), "盘");
      super.putEnum(Long.valueOf(6L), "端口");
      super.putEnum(Long.valueOf(7L), "CTP");
      super.putEnum(Long.valueOf(8L), "电路");
      super.putEnum(Long.valueOf(9L), "告警名称");
      super.putEnum(Long.valueOf(10L), "子框网元");
    }
  }

  public static class AlarmFilterObjectType extends GenericEnum
  {
  }

  public static class AlarmDisplayFilterObjectType extends GenericEnum
  {
    public static final long _district = 1L;
    public static final long _ems = 2L;
    public static final long _net = 3L;
    public static final long _site = 4L;
    public static final long _ne = 11L;
    public static final long _card = 12L;
    public static final long _ptp = 13L;
    public static final long _shelfElement = 15L;
    public static final long _devInfo = 21L;
    public static final long _vendor = 100L;
    public static final long _alarmName = 101L;
    public static final long _explain = 102L;
    public static final long _neModel = 200L;
    public static final long _cardkind = 201L;
    public static final long _alarmMan = 300L;
    public static final long _transSystem = 310L;
    public static final long _traphgroup = 400L;
    public static final long _traph = 401L;

    private AlarmDisplayFilterObjectType()
    {
      super.putEnum(Long.valueOf(1L), "区域");
      super.putEnum(Long.valueOf(2L), "EMS");
      super.putEnum(Long.valueOf(3L), "子网");
      super.putEnum(Long.valueOf(4L), "站点");
      super.putEnum(Long.valueOf(11L), "网元");
      super.putEnum(Long.valueOf(12L), "盘");
      super.putEnum(Long.valueOf(13L), "端口");
      super.putEnum(Long.valueOf(15L), "子框网元");
      super.putEnum(Long.valueOf(21L), "告警位置对应的网元");
      super.putEnum(Long.valueOf(100L), "厂家");
      super.putEnum(Long.valueOf(101L), "告警名称");
      super.putEnum(Long.valueOf(102L), "告警位置解释");
      super.putEnum(Long.valueOf(200L), "网元型号");
      super.putEnum(Long.valueOf(201L), "盘类型");
      super.putEnum(Long.valueOf(300L), "告警维护任务名称");

      super.putEnum(Long.valueOf(310L), "传输系统");
      super.putEnum(Long.valueOf(400L), "影响电路分组");
      super.putEnum(Long.valueOf(401L), "影响电路");
    }
  }

  public static class AlarmScreenFilterRate extends GenericEnum
  {
    public static final long _NA = 0L;
    public static final long _2M = 1L;
    public static final long _8M = 2L;
    public static final long _10M = 3L;
    public static final long _34M = 4L;
    public static final long _45M = 5L;
    public static final long _68M = 6L;
    public static final long _100M = 7L;
    public static final long _140M = 8L;
    public static final long _6M = 22L;
    public static final long _12M = 23L;
    public static final long _16M = 24L;
    public static final long _4M = 25L;
    public static final long _64k = 26L;
    public static final long _32M = 33L;
    public static final long _155M = 9L;
    public static final long _280M = 10L;
    public static final long _310M = 11L;
    public static final long _565M = 12L;
    public static final long _622M = 13L;
    public static final long _1G = 14L;
    public static final long _1D25G = 15L;
    public static final long _2D5G = 16L;
    public static final long _10G = 17L;
    public static final long _20G = 18L;
    public static final long _40G = 19L;
    public static final long _80G = 20L;
    public static final long _120G = 21L;
    public static final long _3D5G = 28L;
    public static final long _320G = 29L;
    public static final long _400G = 30L;
    public static final long _800G = 31L;
    public static final long _1600G = 32L;
    public static final long _beyond155M = 100L;
    public static final long _beyond622M = 200L;
    public static final long _beyond2D5G = 300L;
    public static final long _sdh_no = 400L;
    public static final long _wdm_no = 500L;

    private AlarmScreenFilterRate()
    {
      super.putEnum(Long.valueOf(0L), "无速率");
      super.putEnum(Long.valueOf(1L), "2M");
      super.putEnum(Long.valueOf(2L), "8M");
      super.putEnum(Long.valueOf(3L), "10M");
      super.putEnum(Long.valueOf(4L), "34M");
      super.putEnum(Long.valueOf(5L), "45M");
      super.putEnum(Long.valueOf(6L), "68M");
      super.putEnum(Long.valueOf(7L), "100M");
      super.putEnum(Long.valueOf(8L), "140M");
      super.putEnum(Long.valueOf(22L), "6M");
      super.putEnum(Long.valueOf(23L), "12M");
      super.putEnum(Long.valueOf(24L), "16M");
      super.putEnum(Long.valueOf(25L), "4M");
      super.putEnum(Long.valueOf(26L), "64k");
      super.putEnum(Long.valueOf(33L), "32M");
      super.putEnum(Long.valueOf(10L), "280M");
      super.putEnum(Long.valueOf(11L), "310M");
      super.putEnum(Long.valueOf(12L), "565M");
      super.putEnum(Long.valueOf(13L), "622M");
      super.putEnum(Long.valueOf(14L), "1G");
      super.putEnum(Long.valueOf(15L), "1.25G");
      super.putEnum(Long.valueOf(16L), "2.5G");
      super.putEnum(Long.valueOf(17L), "10G");
      super.putEnum(Long.valueOf(18L), "20G");
      super.putEnum(Long.valueOf(19L), "40G");
      super.putEnum(Long.valueOf(20L), "80G");
      super.putEnum(Long.valueOf(21L), "120G");
      super.putEnum(Long.valueOf(28L), "3.5G");
      super.putEnum(Long.valueOf(29L), "320G");
      super.putEnum(Long.valueOf(30L), "400G");
      super.putEnum(Long.valueOf(31L), "800G");
      super.putEnum(Long.valueOf(32L), "1600G");
      super.putEnum(Long.valueOf(100L), ">=155M");
      super.putEnum(Long.valueOf(200L), ">=622M");
      super.putEnum(Long.valueOf(300L), ">=2.5G");
      super.putEnum(Long.valueOf(400L), "SDH无速率");
      super.putEnum(Long.valueOf(500L), "波分");
    }
  }

  public static class AlarmDisplayRuleRate extends GenericEnum
  {
    public static final long _2M = 1L;
    public static final long _155M = 9L;
    public static final long _622M = 13L;
    public static final long _2D5G = 16L;
    public static final long _10G = 17L;
    public static final long _20G = 18L;
    public static final long _40G = 19L;
    public static final long _80G = 20L;
    public static final long _120G = 21L;
    public static final long _beyond2M = 90L;
    public static final long _below155M = 100L;
    public static final long _beyond120G = 200L;
    public static final long _noRate = 300L;

    private AlarmDisplayRuleRate()
    {
      super.putEnum(Long.valueOf(1L), "2M");
      super.putEnum(Long.valueOf(9L), "155M");
      super.putEnum(Long.valueOf(13L), "622M");
      super.putEnum(Long.valueOf(16L), "2.5G");
      super.putEnum(Long.valueOf(17L), "10G");
      super.putEnum(Long.valueOf(18L), "20G");
      super.putEnum(Long.valueOf(19L), "40G");
      super.putEnum(Long.valueOf(20L), "80G");
      super.putEnum(Long.valueOf(21L), "120G");
      super.putEnum(Long.valueOf(90L), ">2M");
      super.putEnum(Long.valueOf(100L), "<155M");
      super.putEnum(Long.valueOf(200L), ">120G");
      super.putEnum(Long.valueOf(300L), "无速率");
    }
  }

  public static class AlarmDisplayFilterRate extends GenericEnum
  {
    public static final long _2M = 1L;
    public static final long _155M = 9L;
    public static final long _280M = 10L;
    public static final long _310M = 11L;
    public static final long _565M = 12L;
    public static final long _622M = 13L;
    public static final long _1G = 14L;
    public static final long _1D25G = 15L;
    public static final long _2D5G = 16L;
    public static final long _10G = 17L;
    public static final long _20G = 18L;
    public static final long _40G = 19L;
    public static final long _80G = 20L;
    public static final long _120G = 21L;
    public static final long _3D5G = 28L;
    public static final long _FE = 34L;
    public static final long _GE = 35L;
    public static final long _10GE = 36L;
    public static final long _beyond2M = 90L;
    public static final long _below155M = 100L;
    public static final long _beyond120G = 200L;
    public static final long _noRate = 300L;

    private AlarmDisplayFilterRate()
    {
      super.putEnum(Long.valueOf(1L), "2M");
      super.putEnum(Long.valueOf(9L), "155M");
      super.putEnum(Long.valueOf(10L), "280M");
      super.putEnum(Long.valueOf(11L), "310M");
      super.putEnum(Long.valueOf(12L), "565M");
      super.putEnum(Long.valueOf(13L), "622M");
      super.putEnum(Long.valueOf(14L), "1G");
      super.putEnum(Long.valueOf(15L), "1.25G");
      super.putEnum(Long.valueOf(16L), "2.5G");
      super.putEnum(Long.valueOf(28L), "3.5G");
      super.putEnum(Long.valueOf(34L), "FE");
      super.putEnum(Long.valueOf(35L), "GE");
      super.putEnum(Long.valueOf(36L), "10GE");
      super.putEnum(Long.valueOf(17L), "10G");
      super.putEnum(Long.valueOf(18L), "20G");
      super.putEnum(Long.valueOf(19L), "40G");
      super.putEnum(Long.valueOf(20L), "80G");
      super.putEnum(Long.valueOf(21L), "120G");
      super.putEnum(Long.valueOf(90L), ">2M");
      super.putEnum(Long.valueOf(100L), "<155M");
      super.putEnum(Long.valueOf(200L), ">120G");
      super.putEnum(Long.valueOf(300L), "无速率");
    }
  }

  public static class AlarmDisplayFilterImportance extends GenericEnum
  {
    public static final long _optical = 1L;
    public static final long _terminal = 2L;
    public static final long _oterminal = 3L;
    public static final long _other = 4L;

    private AlarmDisplayFilterImportance()
    {
      super.putEnum(Long.valueOf(1L), "光告警");
      super.putEnum(Long.valueOf(2L), "支路告警");
      super.putEnum(Long.valueOf(3L), "光支路告警");
      super.putEnum(Long.valueOf(4L), "其他告警");
    }
  }

  public static class AlarmImportance extends GenericEnum
  {
    public static final long _optical = 1L;
    public static final long _terminal = 2L;
    public static final long _oterminal = 3L;
    public static final long _other = 4L;

    private AlarmImportance()
    {
      super.putEnum(Long.valueOf(1L), "光告警");
      super.putEnum(Long.valueOf(2L), "支路告警");
      super.putEnum(Long.valueOf(3L), "光支路告警");
      super.putEnum(Long.valueOf(4L), "其他告警");
    }
  }

  public static class AlarmSoundPeriod extends GenericEnum
  {
    public static final long _sound0s = 0L;
    public static final long _sound10s = 1L;
    public static final long _sound30s = 2L;
    public static final long _sound1min = 3L;
    public static final long _soundforever = 4L;

    private AlarmSoundPeriod()
    {
      super.putEnum(Long.valueOf(0L), "0秒");
      super.putEnum(Long.valueOf(1L), "10秒");
      super.putEnum(Long.valueOf(2L), "30秒");
      super.putEnum(Long.valueOf(3L), "1分钟");
      super.putEnum(Long.valueOf(4L), "一直提醒");
    }
  }

  public static class AlarmSoundLevel extends GenericEnum
  {
    public static final long _soundfirst = 1L;
    public static final long _soundsecond = 2L;
    public static final long _soundthird = 3L;
    public static final long _soundforth = 4L;
    public static final long _soundfifth = 5L;

    private AlarmSoundLevel()
    {
      super.putEnum(Long.valueOf(1L), "1级");
      super.putEnum(Long.valueOf(2L), "2级");
      super.putEnum(Long.valueOf(3L), "3级");
      super.putEnum(Long.valueOf(4L), "4级");
      super.putEnum(Long.valueOf(5L), "5级");
    }
  }

  public static class MatchTime extends GenericEnum
  {
    public static final long _create = 0L;
    public static final long _clear = 1L;
    public static final long _createorClear = 2L;

    private MatchTime()
    {
      super.putEnum(Long.valueOf(0L), "产生时间");
      super.putEnum(Long.valueOf(1L), "消失时间");
      super.putEnum(Long.valueOf(2L), "产生或消失时间");
    }
  }

  public static class AlarmNoteType extends GenericEnum
  {
    public static final long _cur = 1L;
    public static final long _his = 2L;
    public static final long _all = 3L;

    private AlarmNoteType()
    {
      super.putEnum(Long.valueOf(1L), "告警产生");
      super.putEnum(Long.valueOf(2L), "告警消失");
      super.putEnum(Long.valueOf(3L), "全部");
    }
  }

  public static class IsServiceAlarm extends GenericEnum
  {
    public static final long _true = 1L;
    public static final long _false = 2L;
    public static final long _ALL = 0L;

    private IsServiceAlarm()
    {
      super.putEnum(Long.valueOf(1L), "是");
      super.putEnum(Long.valueOf(2L), "否");
      super.putEnum(Long.valueOf(0L), "全部");
    }
  }

  public static class Flag extends GenericEnum
  {
    public static final long _true = 1L;
    public static final long _false = 2L;
    public static final long _NA = 3L;

    private Flag()
    {
      super.putEnum(Long.valueOf(1L), "是");
      super.putEnum(Long.valueOf(2L), "否");
      super.putEnum(Long.valueOf(3L), "不关心");
    }
  }

  public static class ProjectState extends GenericEnum
  {
    public static final long _normal = 1L;
    public static final long _project = 2L;
    public static final long _fault = 3L;

    private ProjectState()
    {
      super.putEnum(Long.valueOf(1L), "正常");
      super.putEnum(Long.valueOf(2L), "工程");
      super.putEnum(Long.valueOf(3L), "损坏");
    }
  }

  public static class ProjectStateNochoose extends GenericEnum
  {
    public static final long _noChoose = 0L;
    public static final long _normal = 1L;
    public static final long _project = 2L;
    public static final long _fault = 3L;

    private ProjectStateNochoose()
    {
      super.putEnum(Long.valueOf(0L), "");
      super.putEnum(Long.valueOf(1L), "正常");
      super.putEnum(Long.valueOf(2L), "工程");
      super.putEnum(Long.valueOf(3L), "损坏");
    }
  }

  public static class BatchAlarmStatus extends GenericEnum
  {
    public static final long _clear = 1L;
    public static final long _modify = 2L;

    private BatchAlarmStatus()
    {
      super.putEnum(Long.valueOf(1L), "清除");
      super.putEnum(Long.valueOf(2L), "修改");
    }
  }

  public static class FilterContent extends GenericEnum
  {
    public static final long _postion = 1L;
    public static final long _alarmInfo = 2L;
    public static final long _both = 3L;

    private FilterContent()
    {
      super.putEnum(Long.valueOf(1L), "只有位置信息");
      super.putEnum(Long.valueOf(2L), "只有告警信息");
      super.putEnum(Long.valueOf(3L), "全部都有");
    }
  }

  public static class FilterType extends GenericEnum
  {
    public static final long _filterOut = 1L;
    public static final long _filterIn = 2L;

    private FilterType()
    {
      super.putEnum(Long.valueOf(1L), "过滤掉");
      super.putEnum(Long.valueOf(2L), "过滤出");
    }
  }

  public static class ActiveFlag extends GenericEnum
  {
    public static final long _lock = 1L;
    public static final long _unlock = 2L;

    private ActiveFlag()
    {
      super.putEnum(Long.valueOf(1L), "挂起");
      super.putEnum(Long.valueOf(2L), "激活");
    }
  }

  public static class MailStatus extends GenericEnum
  {
    public static final long _needSend = 1L;
    public static final long _sendFauil = 2L;
    public static final long _sendSuccess = 3L;
    public static final long _deadMail = 4L;

    private MailStatus()
    {
      super.putEnum(Long.valueOf(1L), "待发送");
      super.putEnum(Long.valueOf(2L), "发送失败");
      super.putEnum(Long.valueOf(3L), "发送成功");
      super.putEnum(Long.valueOf(4L), "死邮件");
    }
  }

  public static class MailType extends GenericEnum
  {
    public static final long _typeAlarm = 1L;
    public static final long _typeDesign = 2L;
    public static final long _userTrigger = 3L;
    public static final long _typeFault = 4L;

    private MailType()
    {
      super.putEnum(Long.valueOf(1L), "告警");
      super.putEnum(Long.valueOf(2L), "调度");
      super.putEnum(Long.valueOf(3L), "用户变更通知");
      super.putEnum(Long.valueOf(4L), "故障");
    }
  }

  public static class SmsStatus extends GenericEnum
  {
    public static final long _needSend = 1L;
    public static final long _sendFauil = 2L;
    public static final long _sendSuccess = 3L;
    public static final long _deadSms = 4L;

    private SmsStatus()
    {
      super.putEnum(Long.valueOf(1L), "待发送");
      super.putEnum(Long.valueOf(2L), "发送失败");
      super.putEnum(Long.valueOf(3L), "发送成功");
      super.putEnum(Long.valueOf(4L), "死短信");
    }
  }

  public static class SmsType extends GenericEnum
  {
    public static final long _typeAlarm = 1L;
    public static final long _typeDesign = 2L;
    public static final long _userTrigger = 3L;
    public static final long _typeFault = 4L;
    public static final long _attempAutoSms = 21L;
    public static final long _preAlarm = 5L;
    public static final long _fill = 6L;
    public static final long _confirm = 7L;
    public static final long _applyconfirm = 8L;
    public static final long _refer = 9L;
    public static final long _applyrefer = 10L;
    public static final long _workflow = 11L;

    private SmsType()
    {
      super.putEnum(Long.valueOf(1L), "告警");
      super.putEnum(Long.valueOf(2L), "调度");
      super.putEnum(Long.valueOf(3L), "用户变更通知");
      super.putEnum(Long.valueOf(4L), "故障");
      super.putEnum(Long.valueOf(21L), "调度自动催单");

      super.putEnum(Long.valueOf(5L), "预警");

      super.putEnum(Long.valueOf(6L), "报表填报");
      super.putEnum(Long.valueOf(7L), "报表确认");
      super.putEnum(Long.valueOf(8L), "修改申请单批复");
      super.putEnum(Long.valueOf(9L), "报表提交");
      super.putEnum(Long.valueOf(10L), "修改申请单提交");
      super.putEnum(Long.valueOf(11L), "工程割接");
    }
  }

  public static class AlarmVoice extends GenericEnum
  {
    public static final String _dingVoice = "ding";
    public static final String _whistleVoice = "whistle";
    public static final String _announcingVoice = "announcing";
    public static final String _buzzVoice = "buzz";
    public static final String _larumVoice = "larum";
    public static final String _alertVoice = "alert";
    public static final String _mailVoice = "mail";
    public static final String _nudgeVoice = "nudge";
    public static final String _onlineVoice = "online";
    public static final String _ringVoice = "ring";
    public static final String _typeVoice = "type";
    public static final String _vimdoneVoice = "vimdone";
    public static final String _faultSound = "faultSound";
    public static final String _configSound = "configSound";
    public static final String _rotateSound = "rotateSound";

    private AlarmVoice()
    {
      super.putEnum("ding", "Alarm.wav");
      super.putEnum("whistle", "CAlm.wav");
      super.putEnum("announcing", "IAlm.wav");
      super.putEnum("buzz", "UAlm.wav");
      super.putEnum("larum", "SAlm.wav");
      super.putEnum("alert", "newalert.wav");
      super.putEnum("mail", "newemail.wav");
      super.putEnum("nudge", "nudge.wav");
      super.putEnum("online", "online.wav");
      super.putEnum("ring", "ring.wav");
      super.putEnum("type", "type.wav");
      super.putEnum("vimdone", "vimdone.wav");
      super.putEnum("faultSound", "faultSound.wav");
      super.putEnum("configSound", "configSound.wav");
      super.putEnum("rotateSound", "rotateSound.wav");
    }
  }

  public static class AlarmParaCode extends GenericEnum
  {
    public static final long _urgentSound = 8061L;
    public static final long _majorSound = 8062L;
    public static final long _minorSound = 8063L;
    public static final long _commonSound = 8064L;
    public static final long _unknowSound = 8065L;
    public static final long _alarmWindowHint = 8066L;
    public static final long _faultSoundHint = 8067L;
    public static final long _faultWindowHint = 8068L;
    public static final long _configSoundHint = 8069L;
    public static final long _configWindowHint = 8070L;
    public static final long _rotateSoundHint = 8071L;
    public static final long _rotateWindowHint = 8072L;
    public static final long _alarmSoundHint = 8073L;
    public static final long _soundOrder = 8074L;
    public static final long _traphWindowHint = 8085L;
    public static final long _EMSConnetWindowHint = 8086L;
    public static final long _groupUrgentSound = 8087L;
    public static final long __groupMajorSound = 8088L;
    public static final long _groupMinorSound = 8089L;
    public static final long _groupCommonSound = 8090L;
    public static final long _groupUnknowSound = 8091L;
    public static final long _manualStop = 9998L;
    public static final long _protectSwitchToAlarm = 9999L;

    private AlarmParaCode()
    {
      super.putEnum(Long.valueOf(8061L), "紧急告警声音");
      super.putEnum(Long.valueOf(8062L), "主要告警声音");
      super.putEnum(Long.valueOf(8063L), "次要告警声音");
      super.putEnum(Long.valueOf(8064L), "一般告警声音");
      super.putEnum(Long.valueOf(8065L), "未知告警声音");

      super.putEnum(Long.valueOf(8087L), "电路分组紧急告警声音");
      super.putEnum(Long.valueOf(8088L), "电路分组主要告警声音");
      super.putEnum(Long.valueOf(8089L), "电路分组次要告警声音");
      super.putEnum(Long.valueOf(8090L), "电路分组一般告警声音");
      super.putEnum(Long.valueOf(8091L), "电路分组未知告警声音");

      super.putEnum(Long.valueOf(8073L), "告警声音");
      super.putEnum(Long.valueOf(8066L), "告警");
      super.putEnum(Long.valueOf(8067L), "故障声音");
      super.putEnum(Long.valueOf(8068L), "故障");
      super.putEnum(Long.valueOf(8069L), "配置变更通知声音");
      super.putEnum(Long.valueOf(8070L), "配置变更通知");
      super.putEnum(Long.valueOf(8071L), "保护倒换事件声音");
      super.putEnum(Long.valueOf(8072L), "保护倒换事件");
      super.putEnum(Long.valueOf(8074L), "声音优先级");
      super.putEnum(Long.valueOf(8085L), "电路分组提示");
      super.putEnum(Long.valueOf(8086L), "EMS连接中断告警提示");
      super.putEnum(Long.valueOf(9999L), "倒换事件生成告警厂家");
      super.putEnum(Long.valueOf(9998L), "南方基地告警抑制菜单开关");
    }
  }

  public static class AnalyseObjectTypeCode extends GenericEnum
  {
    public static final long _result = 18001L;
    public static final long _rule = 18002L;
    public static final long _orig = 18003L;

    private AnalyseObjectTypeCode()
    {
      super.putEnum(Long.valueOf(18001L), "ALARM_ANALYSE_RESULT");
      super.putEnum(Long.valueOf(18002L), "SDHALARM_ARULE");
      super.putEnum(Long.valueOf(18003L), "SDHALARM_ARULE_ORIG");
    }
  }

  public static class AlarmAnalyseResult extends GenericEnum
  {
    public static final long _root = 1L;
    public static final long _leaf = 2L;

    private AlarmAnalyseResult()
    {
      super.putEnum(Long.valueOf(1L), "根源告警");
      super.putEnum(Long.valueOf(2L), "被抑制告警");
    }
  }

  public static class AnalyseRdiFlag extends GenericEnum
  {
    public static final long _opp = 1L;
    public static final long _unopp = 2L;

    private AnalyseRdiFlag()
    {
      super.putEnum(Long.valueOf(1L), "对告");
      super.putEnum(Long.valueOf(2L), "非对告");
    }
  }

  public static class AnalyseObjectType extends GenericEnum
  {
    public static final long _port = 1L;
    public static final long _ctp = 2L;

    private AnalyseObjectType()
    {
      super.putEnum(Long.valueOf(1L), "端口");
      super.putEnum(Long.valueOf(2L), "CTP");
    }
  }

  public static class AlarmAnalyseType extends GenericEnum
  {
    public static final long _port_sameposition = 1L;
    public static final long _port_topo = 2L;
    public static final long _ctp_sameposition = 3L;
    public static final long _ctp_port = 4L;
    public static final long _ctp_ctp = 5L;
    public static final long _ctp_portTopo = 6L;
    public static final long _ctp_ctpTopo = 7L;

    private AlarmAnalyseType()
    {
      super.putEnum(Long.valueOf(1L), "端口同源关系");
      super.putEnum(Long.valueOf(2L), "端口拓扑关系");
      super.putEnum(Long.valueOf(3L), "ctp同源关系");
      super.putEnum(Long.valueOf(4L), "端口-ctp上下级关系");
      super.putEnum(Long.valueOf(5L), "ctp-ctp上下级关系");
      super.putEnum(Long.valueOf(6L), "端口-ctp拓扑关系");
      super.putEnum(Long.valueOf(7L), "ctp-ctp拓扑关系");
    }
  }

  public static class AnalyseType extends GenericEnum
  {
    public static final long _samePosition = 1L;
    public static final long _levelRelation = 2L;
    public static final long _topoRelation = 3L;

    private AnalyseType()
    {
      super.putEnum(Long.valueOf(1L), "同源关系");
      super.putEnum(Long.valueOf(2L), "上下级关系");
      super.putEnum(Long.valueOf(3L), "拓扑关系");
    }
  }

  public static class AlarmCond extends GenericEnum
  {
    public static final int _all = 1;
    public static final int _net = 2;
    public static final int _transsys = 3;
    public static final int _ems = 4;
    public static final int _ne = 5;
    public static final int _site = 6;
    public static final int _room = 7;
    public static final int _rack = 8;
    public static final int _shelf = 9;
    public static final int _slot = 10;
    public static final int _card = 11;
    public static final int _port = 12;

    private AlarmCond()
    {
      super.putEnum(Integer.valueOf(1), "所有");
      super.putEnum(Integer.valueOf(2), "子网");
      super.putEnum(Integer.valueOf(3), "传输系统");
      super.putEnum(Integer.valueOf(4), "EMS");
      super.putEnum(Integer.valueOf(5), "网元");
      super.putEnum(Integer.valueOf(6), "站点");
      super.putEnum(Integer.valueOf(7), "机房");
      super.putEnum(Integer.valueOf(8), "机架");
      super.putEnum(Integer.valueOf(9), "机框");
      super.putEnum(Integer.valueOf(10), "槽位");
      super.putEnum(Integer.valueOf(11), "盘");
      super.putEnum(Integer.valueOf(12), "端口");
    }
  }

  public static class AlarmState extends GenericEnum
  {
    public static final long _newalarm = 1L;
    public static final long _ackedalarm = 2L;
    public static final long _lockedalarm = 3L;

    private AlarmState()
    {
      super.putEnum(Long.valueOf(1L), "新产生");
      super.putEnum(Long.valueOf(2L), "已确认");
      super.putEnum(Long.valueOf(3L), "锁定");
    }
  }

  public static class AlarmTypeNochoose extends GenericEnum
  {
    public static final long _communication = 1L;
    public static final long _qos = 2L;
    public static final long _processerror = 3L;
    public static final long _equipment = 4L;
    public static final long _environment = 5L;
    public static final long _ems = 6L;
    public static final long _nochoose = 0L;

    private AlarmTypeNochoose()
    {
      super.putEnum(Long.valueOf(0L), "");
      super.putEnum(Long.valueOf(1L), "通信告警");
      super.putEnum(Long.valueOf(2L), "服务质量告警");
      super.putEnum(Long.valueOf(3L), "处理出错告警");
      super.putEnum(Long.valueOf(4L), "设备告警");
      super.putEnum(Long.valueOf(5L), "环境告警");
      super.putEnum(Long.valueOf(6L), "EMS连接告警");
    }
  }

  public static class LogicalSubClass extends GenericEnum
  {
    public static final String _na = "";
    public static final String _software = "软件";
    public static final String _hardware = "硬件";
    public static final String _power = "电源";
    public static final String _port = "端口";
    public static final String _path = "通道";
    public static final String _performance = "性能";
    public static final String _switch = "倒换";
    public static final String _dataconfig = "数据配置";
    public static final String _maintenancealarm = "操作告警";
    public static final String _outsidealarm = "外告";
    public static final String _operatemaintenance = "操作维护";
    public static final String _operatealarm = "操作告警";
    public static final String _clock = "时钟";
    public static final String _surface = "外部";
    public static final String _service = "业务";
    public static final String _section = "段阅";
    public static final String _operate = "操作";
    public static final String _commproblem = "通信问题";
    public static final String _tnmssoftware = "网管软件";
    public static final String _tnmshardware = "网管硬件";

    private LogicalSubClass()
    {
      super.putEnum("", "");
      super.putEnum("软件", "软件");
      super.putEnum("硬件", "硬件");
      super.putEnum("电源", "电源");

      super.putEnum("端口", "端口");
      super.putEnum("通道", "通道");
      super.putEnum("性能", "性能");
      super.putEnum("倒换", "倒换");

      super.putEnum("数据配置", "数据配置");
      super.putEnum("操作告警", "操作告警");

      super.putEnum("外告", "外告");
      super.putEnum("操作维护", "操作维护");
      super.putEnum("操作告警", "操作告警");
      super.putEnum("时钟", "时钟");
      super.putEnum("外部", "外部");
      super.putEnum("业务", "业务");
      super.putEnum("段阅", "段阅");
      super.putEnum("操作", "操作");
      super.putEnum("通信问题", "通信问题");
      super.putEnum("网管软件", "网管软件");
      super.putEnum("网管硬件", "网管硬件");
    }
  }

  public static class LogicalClass extends GenericEnum
  {
    public static final String _no = "";
    public static final String _communication = "通信";
    public static final String _maintenance = "维护";
    public static final String _environment = "环境";
    public static final String _equipment = "设备";
    public static final String _tnmssoftware = "网管软件";
    public static final String _service = "服务质量";
    public static final String _tnmscommuication = "网管软件通信问题";
    public static final String _performance = "性能";
    public static final String _tnmshardware = "网管硬件";
    public static final String _dealfault = "处理故障";
    public static final String _servicealarm = "服务质量告警";
    public static final String _enviralarm = "环境告警";
    public static final String _devicealarm = "设备告警";
    public static final String _commalarm = "通信告警";
    public static final String _commmessage = "通讯";

    private LogicalClass()
    {
      super.putEnum("", "");
      super.putEnum("通信", "通信");
      super.putEnum("维护", "维护");
      super.putEnum("环境", "环境");
      super.putEnum("设备", "设备");
      super.putEnum("网管软件", "网管软件");
      super.putEnum("服务质量", "服务质量");
      super.putEnum("网管软件通信问题", "网管软件通信问题");
      super.putEnum("性能", "性能");
      super.putEnum("网管硬件", "网管硬件");
      super.putEnum("处理故障", "处理故障");
      super.putEnum("服务质量告警", "服务质量告警");
      super.putEnum("环境告警", "环境告警");
      super.putEnum("设备告警", "设备告警");
      super.putEnum("通信告警", "通信告警");
      super.putEnum("通讯", "通讯");
    }
  }

  public static class EmsAlarmType extends GenericEnum
  {
    public static final String _emssoftware = "网管软件";
    public static final String _emshardware = "网管硬件";
    public static final String _emscommunication = "通信问题";

    private EmsAlarmType()
    {
      super.putEnum("网管软件", "网管软件");
      super.putEnum("网管硬件", "网管硬件");
      super.putEnum("通信问题", "通信问题");
    }
  }

  public static class AlarmTypeSimpleEnv extends GenericEnum
  {
    public static final String _power = "电源";
    public static final String _outsidealarm = "外告";
    public static final String _na = "";

    private AlarmTypeSimpleEnv()
    {
      super.putEnum("电源", "电源");
      super.putEnum("外告", "外告");
      super.putEnum("", "");
    }
  }

  public static class AlarmTypeSimpleMaintenance extends GenericEnum
  {
    public static final String _dataconfig = "数据配置";
    public static final String _maintenancealarm = "操作告警";
    public static final String _na = "";

    private AlarmTypeSimpleMaintenance()
    {
      super.putEnum("数据配置", "数据配置");
      super.putEnum("操作告警", "操作告警");
      super.putEnum("", "");
    }
  }

  public static class AlarmTypeSimpleComm extends GenericEnum
  {
    public static final String _clock = "时钟";
    public static final String _service = "业务";
    public static final String _port = "端口";
    public static final String _path = "通道";
    public static final String _performance = "性能";
    public static final String _switch = "倒换";
    public static final String _na = "";

    private AlarmTypeSimpleComm()
    {
      super.putEnum("时钟", "时钟");
      super.putEnum("业务", "业务");
      super.putEnum("端口", "端口");
      super.putEnum("通道", "通道");
      super.putEnum("性能", "性能");
      super.putEnum("倒换", "倒换");
      super.putEnum("", "");
    }
  }

  public static class AlarmTypeSimpleEquip extends GenericEnum
  {
    public static final String _software = "软件";
    public static final String _hardware = "硬件";
    public static final String _power = "电源";
    public static final String _na = "";

    private AlarmTypeSimpleEquip()
    {
      super.putEnum("软件", "软件");
      super.putEnum("硬件", "硬件");
      super.putEnum("电源", "电源");
      super.putEnum("", "");
    }
  }

  public static class AlarmType extends GenericEnum
  {
    public static final long _communication = 1L;
    public static final long _qos = 2L;
    public static final long _processerror = 3L;
    public static final long _equipment = 4L;
    public static final long _environment = 5L;
    public static final long _ems = 6L;
    public static final long _na = 7L;

    private AlarmType()
    {
      super.putEnum(Long.valueOf(1L), "通信告警");
      super.putEnum(Long.valueOf(2L), "服务质量告警");
      super.putEnum(Long.valueOf(3L), "处理出错告警");
      super.putEnum(Long.valueOf(4L), "设备告警");
      super.putEnum(Long.valueOf(5L), "环境告警");
      super.putEnum(Long.valueOf(6L), "EMS连接告警");
      super.putEnum(Long.valueOf(7L), "NA");
    }
  }

  public static class RawVendorAlarmSeverity extends GenericEnum
  {
    public static final long _urgentalarm = 1L;
    public static final long _majoralarm = 2L;
    public static final long _minoralarm = 3L;
    public static final long _commonalarm = 4L;
    public static final long _unknowalarm = 5L;

    private RawVendorAlarmSeverity()
    {
      super.putEnum(Long.valueOf(1L), "紧急告警");
      super.putEnum(Long.valueOf(2L), "主要告警");
      super.putEnum(Long.valueOf(3L), "次要告警");
      super.putEnum(Long.valueOf(4L), "一般告警");
      super.putEnum(Long.valueOf(5L), "未确定告警");
    }
  }

  public static class AlarmSeverityNormalNochoose extends GenericEnum
  {
    public static final long _urgentalarm = 1L;
    public static final long _majoralarm = 2L;
    public static final long _minoralarm = 3L;
    public static final long _commonalarm = 4L;
    public static final long _unknowalarm = 5L;
    public static final long _noChoose = 0L;

    private AlarmSeverityNormalNochoose()
    {
      super.putEnum(Long.valueOf(0L), "");
      super.putEnum(Long.valueOf(1L), "紧急告警");
      super.putEnum(Long.valueOf(2L), "主要告警");
      super.putEnum(Long.valueOf(3L), "次要告警");
      super.putEnum(Long.valueOf(4L), "一般告警");
      super.putEnum(Long.valueOf(5L), "未确定告警");
    }
  }

  public static class SpeacialType extends GenericEnum
  {
    public static final long _noChoose = 0L;
    public static final long _switch = 1L;
    public static final long _eoms = 2L;

    private SpeacialType()
    {
      super.putEnum(Long.valueOf(0L), "");
      super.putEnum(Long.valueOf(1L), "倒换告警");
      super.putEnum(Long.valueOf(2L), "关联派单告警");
    }
  }

  public static class AlarmStandSeverityNormal extends GenericEnum
  {
    public static final long _noalarm = 0L;
    public static final long _first = 1L;
    public static final long _second = 2L;
    public static final long _third = 3L;
    public static final long _forth = 4L;

    private AlarmStandSeverityNormal()
    {
      super.putEnum(Long.valueOf(1L), "一级告警");
      super.putEnum(Long.valueOf(2L), "二级告警");
      super.putEnum(Long.valueOf(3L), "三级告警");
      super.putEnum(Long.valueOf(4L), "四级告警");
    }
  }

  public static class AlarmSeverityNormal extends GenericEnum
  {
    public static final long _urgentalarm = 1L;
    public static final long _majoralarm = 2L;
    public static final long _minoralarm = 3L;
    public static final long _commonalarm = 4L;
    public static final long _unknowalarm = 5L;

    private AlarmSeverityNormal()
    {
      super.putEnum(Long.valueOf(1L), "紧急告警");
      super.putEnum(Long.valueOf(2L), "主要告警");
      super.putEnum(Long.valueOf(3L), "次要告警");
      super.putEnum(Long.valueOf(4L), "一般告警");
      super.putEnum(Long.valueOf(5L), "未确定告警");
    }
  }

  public static class AlarmMarkType extends GenericEnum
  {
    public static final long _prjectalarm = 1L;
    public static final long _repeatalarm = 2L;
    public static final long _falsealarm = 3L;
    public static final long _emergencyalarm = 4L;

    private AlarmMarkType()
    {
      super.putEnum(Long.valueOf(1L), "工程告警");
      super.putEnum(Long.valueOf(2L), "重复告警");
      super.putEnum(Long.valueOf(3L), "误告告警");
      super.putEnum(Long.valueOf(4L), "紧急处理告警");
    }
  }

  public static class AlarmStandSeverity extends GenericEnum
  {
    public static final long _noalarm = 0L;
    public static final long _first = 1L;
    public static final long _second = 2L;
    public static final long _third = 3L;
    public static final long _forth = 4L;

    private AlarmStandSeverity()
    {
      super.putEnum(Long.valueOf(0L), "正常");
      super.putEnum(Long.valueOf(1L), "一级告警");
      super.putEnum(Long.valueOf(2L), "二级告警");
      super.putEnum(Long.valueOf(3L), "三级告警");
      super.putEnum(Long.valueOf(4L), "四级告警");
    }
  }

  public static class FHAlarmSeverity extends GenericEnum
  {
    public static final long _urgentalarm = 1L;
    public static final long _majoralarm = 2L;
    public static final long _minoralarm = 3L;
    public static final long _normalalarm = 4L;
    public static final long _commonalarm = 5L;
    public static final long _unknowalarm = 6L;
    public static final long _communicate = 7L;

    private FHAlarmSeverity()
    {
      super.putEnum(Long.valueOf(1L), "紧急告警");
      super.putEnum(Long.valueOf(2L), "主要告警");
      super.putEnum(Long.valueOf(3L), "次要告警");
      super.putEnum(Long.valueOf(4L), "一般告警");
      super.putEnum(Long.valueOf(5L), "提示告警");
      super.putEnum(Long.valueOf(6L), "未确定告警");
      super.putEnum(Long.valueOf(7L), "通信中断");
    }
  }

  public static class NormarlAlarmSeverity extends GenericEnum
  {
    public static final long _crialarm = 1L;
    public static final long _mainalarm = 2L;
    public static final long _lessalarm = 3L;
    public static final long _normalalarm = 4L;
    public static final long _cuealarm = 5L;
    public static final long _criornoralarm = 6L;
    public static final long _criorminalarm = 7L;
    public static final long _majalarm = 8L;
    public static final long _majorminalarm = 9L;
    public static final long _majorcuealarm = 10L;
    public static final long _maincrialarm = 11L;
    public static final long _mainnoralarm = 12L;
    public static final long _warnalarm = 13L;
    public static final long _lessmainalarm = 14L;
    public static final long _lesswarnalarm = 15L;
    public static final long _norlessalarm = 16L;
    public static final long _normainalarm = 17L;
    public static final long _normajalarm = 18L;

    private NormarlAlarmSeverity()
    {
      super.putEnum(Long.valueOf(1L), "紧急告警");
      super.putEnum(Long.valueOf(2L), "主要告警");
      super.putEnum(Long.valueOf(3L), "次要告警");
      super.putEnum(Long.valueOf(4L), "一般告警");
      super.putEnum(Long.valueOf(5L), "提示告警");
      super.putEnum(Long.valueOf(6L), "紧急告警/一般告警");
      super.putEnum(Long.valueOf(7L), "紧急告警/次要告警");
      super.putEnum(Long.valueOf(8L), "重要告警");
      super.putEnum(Long.valueOf(9L), "重要告警/次要告警");
      super.putEnum(Long.valueOf(10L), "重要告警/提示告警");
      super.putEnum(Long.valueOf(11L), "主要告警/紧急告警");
      super.putEnum(Long.valueOf(12L), "主要告警/一般告警");
      super.putEnum(Long.valueOf(13L), "警告告警");
      super.putEnum(Long.valueOf(14L), "次要告警/主要告警");
      super.putEnum(Long.valueOf(15L), "次要告警/警告告警");
      super.putEnum(Long.valueOf(16L), "一般告警/次要告警");
      super.putEnum(Long.valueOf(17L), "一般告警/主要告警");
      super.putEnum(Long.valueOf(18L), "提示告警/重要告警");
    }
  }

  public static class ZTEAlarmSeverity extends GenericEnum
  {
    public static final long _criticalalarm = 1L;
    public static final long _majoralarm = 2L;
    public static final long _minoralarm = 3L;
    public static final long _warningalarm = 4L;

    private ZTEAlarmSeverity()
    {
      super.putEnum(Long.valueOf(1L), "critical");
      super.putEnum(Long.valueOf(2L), "major");
      super.putEnum(Long.valueOf(3L), "minor");
      super.putEnum(Long.valueOf(4L), "warning");
    }
  }

  public static class OldAlarmSeverity extends GenericEnum
  {
    public static final long _urgentalarm = 1L;
    public static final long _majoralarm = 2L;
    public static final long _minoralarm = 3L;
    public static final long _commonalarm = 4L;
    public static final long _unknowalarm = 5L;
    public static final long _communicate = 6L;

    private OldAlarmSeverity()
    {
      super.putEnum(Long.valueOf(1L), "紧急告警");
      super.putEnum(Long.valueOf(2L), "主要告警");
      super.putEnum(Long.valueOf(3L), "次要告警");
      super.putEnum(Long.valueOf(4L), "一般告警");
      super.putEnum(Long.valueOf(5L), "未确定告警");
      super.putEnum(Long.valueOf(6L), "通信中断");
    }
  }

  public static class AlarmSeverity extends GenericEnum
  {
    public static final long _noalarm = 0L;
    public static final long _urgentalarm = 1L;
    public static final long _majoralarm = 2L;
    public static final long _minoralarm = 3L;
    public static final long _commonalarm = 4L;
    public static final long _unknowalarm = 5L;

    private AlarmSeverity()
    {
      super.putEnum(Long.valueOf(0L), "正常");
      super.putEnum(Long.valueOf(1L), "紧急告警");
      super.putEnum(Long.valueOf(2L), "主要告警");
      super.putEnum(Long.valueOf(3L), "次要告警");
      super.putEnum(Long.valueOf(4L), "一般告警");
      super.putEnum(Long.valueOf(5L), "未确定告警");
    }
  }

  public static class TaskType extends GenericEnum
  {
    public static final long _dispType = 1L;
    public static final long _filterType = 2L;
    public static final long _traphType = 3L;

    private TaskType()
    {
      super.putEnum(Long.valueOf(1L), "用户告警过滤");
      super.putEnum(Long.valueOf(2L), "实时告警过滤");
      super.putEnum(Long.valueOf(3L), "电路分组过滤");
    }
  }

  public static class AlarmSendRulePropType extends GenericEnum
  {
    public static final long _alarmname = 1L;
    public static final long _neModel = 2L;
    public static final long _smsUser = 3L;
    public static final long _smsStyle = 4L;
    public static final long _cardType = 5L;

    private AlarmSendRulePropType()
    {
      super.putEnum(Long.valueOf(1L), "告警名称");
      super.putEnum(Long.valueOf(2L), "网元型号");
      super.putEnum(Long.valueOf(3L), "短信用户");
      super.putEnum(Long.valueOf(4L), "短信模版");
      super.putEnum(Long.valueOf(5L), "盘类型");
    }
  }

  public static class AlarmSendRuleType extends GenericEnum
  {
    public static final long _toEoms = 1L;
    public static final long _toAlarmBoard = 2L;
    public static final long _toSms = 4L;

    private AlarmSendRuleType()
    {
      super.putEnum(Long.valueOf(1L), "派发至EOMS");
      super.putEnum(Long.valueOf(2L), "派发至告警牌");
      super.putEnum(Long.valueOf(4L), "派发至短信");
    }
  }
}