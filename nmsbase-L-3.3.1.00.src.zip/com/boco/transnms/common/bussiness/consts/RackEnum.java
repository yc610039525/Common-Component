package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class RackEnum
{
  public static final RackOwnerShip RACK_OWNER_SHIP = new RackOwnerShip(null);
  public static final ServiceType SERVICE_TYPE = new ServiceType(null);
  public static final SwitchPortStateType SWITCHPORTSTATE_TYPE = new SwitchPortStateType(null);
  public static final SwitchPortType SWITCHPORT_TYPE = new SwitchPortType(null);
  public static final ResistanceType RESISTANCE_TYPE = new ResistanceType(null);
  public static final ServiceState SERVICE_STATE = new ServiceState(null);
  public static final TransPortStateType PORT_STATE = new TransPortStateType(null);
  public static final TransPortType PORT_TYPE = new TransPortType(null);
  public static final TransPortSubType PORT_SUB_TYPE = new TransPortSubType(null);
  public static final TransPortType1 PORT_TYPE1 = new TransPortType1(null);
  public static final TerminationMode TERMINATION_MODE = new TerminationMode(null);
  public static final Directionality DIRECTIONALITY = new Directionality(null);
  public static final IsConnState IS_CONN_STATE = new IsConnState(null);
  public static final Domain DOMAIN = new Domain(null);
  public static final EthType ETH_TYPE = new EthType(null);
  public static final AtmType ATM_TYPE = new AtmType(null);
  public static final Rate RATR_TYPE = new Rate(null);
  public static final PathState PATH_STATE = new PathState(null);
  public static final AlarmImportance ALARMIMPORTANCE = new AlarmImportance(null);
  public static final String STRREFUSEDEL = "strRefuseDel";
  public static final mstpPortType MSTP_PORT_TYPE = new mstpPortType(null);
  public static final mstpTagFlag MSTP_TAG_FLAG = new mstpTagFlag(null);
  public static final msptFlowCtrl MSTP_FLOWCTRL = new msptFlowCtrl(null);
  public static final mstpPortEnable MSTP_PORTENABLE = new mstpPortEnable(null);
  public static final mstpPtpEnable MSTP_PPTENABLE = new mstpPtpEnable(null);
  public static final mstpWorkMode MSTP_WORKMODE = new mstpWorkMode(null);
  public static final mstpPortType2 MSTP_PORT_TYPE2 = new mstpPortType2(null);
  public static final mstpPortServiceType MSTP_PORT_SERVICETYPE = new mstpPortServiceType(null);
  public static final mstpNanfcMode MSTP_NANFCMODE = new mstpNanfcMode(null);
  public static final mstpAnfcMode MSTP_ANFCMODE = new mstpAnfcMode(null);
  public static final mstpBmsgsuppress MSTP_BMSGSUPPRESS = new mstpBmsgsuppress(null);
  public static final mstpEdetect MSTP_EDETECT = new mstpEdetect(null);
  public static final mstpENCAPPROTOCOL MSTP_ENCAPPROTOCOL = new mstpENCAPPROTOCOL(null);
  public static final mstpENCAPFORMAT MSTP_ENCAPFORMAT = new mstpENCAPFORMAT(null);
  public static final mstpLcasFlag MSTP_LCAS_FLAG = new mstpLcasFlag(null);
  public static final mstpSCRAMBEL MSTP_SCRAMBEL = new mstpSCRAMBEL(null);
  public static final mstpEXTENDEADER MSTP_EXTENDEADER = new mstpEXTENDEADER(null);
  public static final mstpCFLEN MSTP_CFLEN = new mstpCFLEN(null);
  public static final mstpFCSCALSEQ MSTP_FCSCALSEQ = new mstpFCSCALSEQ(null);
  public static final mstpBindPathLevel MSTP_BINDPATHLEVEL = new mstpBindPathLevel(null);
  public static final mstpBindPathDir MSTP_BINDPATHDIR = new mstpBindPathDir(null);
  public static final mstpEthServiceType MSTP_ETHSERVICETYPE = new mstpEthServiceType(null);
  public static final mstpEthServiceDirection MSTP_ETHSERVICEDIRECTION = new mstpEthServiceDirection(null);
  public static final CheckState checkState = new CheckState(null);
  public static final CheckResult checkResult = new CheckResult(null);
  public static final BranchCheckResult branchCheckResult = new BranchCheckResult(null);
  public static final CheckTaskState checkTaskstate = new CheckTaskState(null);
  public static final GuideLine guideLine = new GuideLine(null);
  public static final SwitchElementType SWITCHELEMENT_TYPE = new SwitchElementType(null);
  public static final Position positiion = new Position(null);
  public static final SuppressType SUPPRESS_TYPE = new SuppressType(null);
  public static final SuppressTypeSdh SUPPRESS_TYPE_SDH = new SuppressTypeSdh(null);
  public static final SuppressTypeWdm SUPPRESS_TYPE_WDM = new SuppressTypeWdm(null);
  public static final RootAlarmType ROOT_ALARM_TYPE = new RootAlarmType(null);
  public static final AlarmDetectDirection ALARM_DETECT_DIRECTION = new AlarmDetectDirection(null);
  public static final AlarmDetectDirectionNo ALARM_DETECT_DIRECTION_NO = new AlarmDetectDirectionNo(null);
  public static final DeviceColorCfgEnum DEVICE_COLOR_CFG_ENUM = new DeviceColorCfgEnum(null);
  public static final DetectBoxid DETECT_BOXID = new DetectBoxid(null);
  public static final DfPortCheckEnum DF_PORT_CHECK_ENUM = new DfPortCheckEnum(null);

  public static final SncState SNC_STATE = new SncState(null);
  public static final SncType SNC_TYPE = new SncType(null);
  public static final SncASFlag SNC_AS_FLAG = new SncASFlag(null);
  public static final SncProtectLevel SNS_PROTECT_LEVEL = new SncProtectLevel(null);
  public static final SncReRouteAllow SNC_REROUTE_ALLOW = new SncReRouteAllow(null);
  public static final SncNetWorkRoute SNC_NETWORK_ROUTE = new SncNetWorkRoute(null);
  public static final ImpedanceType IMPEDANCE = new ImpedanceType(null);

  public static final ApplyType APPLY_TYPE = new ApplyType(null);
  public static final LinePairType LINE_PAIR_TYPE = new LinePairType(null);
  public static final ExtendType EXTEND_TYPE = new ExtendType(null);
  public static final InterFaceType INTERFACE_TYPE = new InterFaceType(null);
  public static final LinePairUseState LINE_PAIR_USE_STATE = new LinePairUseState(null);
  public static final LinePairPhyAble LINE_PAIR_PHY_ABLE = new LinePairPhyAble(null);
  public static final ResourceType RESOURCE_TYPE = new ResourceType(null);
  public static final PreWriteResState writeRes_State = new PreWriteResState(null);

  public static final LoginLog LOGIN_LOG = new LoginLog(null);

  public static class ApplyType extends GenericEnum
  {
    public static final long _ims = 1L;
    public static final long _wlan = 2L;
    public static final long _per = 3L;

    private ApplyType()
    {
      super.putEnum(Long.valueOf(1L), "IMS");
      super.putEnum(Long.valueOf(2L), "WLAN");
      super.putEnum(Long.valueOf(3L), "个人/政企");
    }
  }

  public static class ImpedanceType extends GenericEnum
  {
    public static final long _unknown = 1L;
    public static final long _75 = 2L;
    public static final long _120 = 3L;

    private ImpedanceType()
    {
      super.putEnum(Long.valueOf(1L), "未知");
      super.putEnum(Long.valueOf(2L), "75欧姆");
      super.putEnum(Long.valueOf(3L), "120欧姆");
    }
  }

  public static class SncNetWorkRoute extends GenericEnum
  {
    public static final long _NA = 1L;
    public static final long _NO = 2L;
    public static final long _YES = 3L;

    private SncNetWorkRoute()
    {
      super.putEnum(Long.valueOf(1L), "未知");
      super.putEnum(Long.valueOf(2L), "不能");
      super.putEnum(Long.valueOf(3L), "能");
    }
  }

  public static class SncReRouteAllow extends GenericEnum
  {
    public static final long _emsDo = 1L;
    public static final long _allow = 2L;
    public static final long _notAllow = 3L;

    private SncReRouteAllow()
    {
      super.putEnum(Long.valueOf(1L), "让EMS自己决定");
      super.putEnum(Long.valueOf(2L), "允许");
      super.putEnum(Long.valueOf(3L), "不允许");
    }
  }

  public static class SncProtectLevel extends GenericEnum
  {
    public static final long _PREEMPTIBLE = 1L;
    public static final long _UNPROTECTED = 2L;
    public static final long _PARTIALLY_PROTECTED = 3L;
    public static final long _FULLY_PROTECTED = 4L;
    public static final long _HIGHLY_PROTECTED = 5L;

    private SncProtectLevel()
    {
      super.putEnum(Long.valueOf(1L), "可预占的");
      super.putEnum(Long.valueOf(2L), "没有保护的");
      super.putEnum(Long.valueOf(3L), "部分被保护");
      super.putEnum(Long.valueOf(4L), "被完整的保护");
      super.putEnum(Long.valueOf(5L), "被高度保护");
    }
  }

  public static class SncASFlag extends GenericEnum
  {
    public static final long _notAs = 1L;
    public static final long _partAs = 2L;
    public static final long _fullAs = 3L;

    private SncASFlag()
    {
      super.putEnum(Long.valueOf(1L), "非智能");
      super.putEnum(Long.valueOf(2L), "智能融合");
      super.putEnum(Long.valueOf(3L), "纯智能");
    }
  }

  public static class SncType extends GenericEnum
  {
    public static final long _ST_SIMPLE = 1L;
    public static final long _ST_ADD_DROP_A = 2L;
    public static final long _ST_ADD_DROP_Z = 3L;

    private SncType()
    {
      super.putEnum(Long.valueOf(1L), "ST_SIMPLE");
      super.putEnum(Long.valueOf(2L), "ST_ADD_DROP_A");
      super.putEnum(Long.valueOf(3L), "ST_ADD_DROP_Z");
    }
  }

  public static class SncState extends GenericEnum
  {
    public static final long _active = 1L;
    public static final long _pending = 2L;
    public static final long _partial = 3L;
    public static final long _notexistent = 4L;

    private SncState()
    {
      super.putEnum(Long.valueOf(1L), "active");
      super.putEnum(Long.valueOf(2L), "pending");
      super.putEnum(Long.valueOf(3L), "partial");
      super.putEnum(Long.valueOf(4L), "notexistent");
    }
  }

  public static class DfPortCheckEnum extends GenericEnum
  {
    public static final long _Success = 0L;
    public static final long _NoConnect = 1L;
    public static final long _LostConnect = 2L;
    public static final long _ExceptionPort = 3L;
    public static final long _ExceptionEndPTPPort = 4L;
    public static final long _UnKnowError = 5L;

    private DfPortCheckEnum()
    {
      super.putEnum(Long.valueOf(0L), "核查成功");
      super.putEnum(Long.valueOf(1L), "无连接信息");
      super.putEnum(Long.valueOf(2L), "缺少连接信息");
      super.putEnum(Long.valueOf(3L), "连接关系异常");
      super.putEnum(Long.valueOf(4L), "电路路由信息与配线架连接信息不一致");
      super.putEnum(Long.valueOf(5L), "未知错误");
    }
  }

  public static class DetectBoxid extends GenericEnum
  {
    public static final long _1 = 1L;
    public static final long _2 = 2L;
    public static final long _3 = 3L;
    public static final long _4 = 4L;
    public static final long _5 = 5L;

    private DetectBoxid()
    {
      super.putEnum(Long.valueOf(1L), "1");
      super.putEnum(Long.valueOf(2L), "2");
      super.putEnum(Long.valueOf(3L), "3");
      super.putEnum(Long.valueOf(4L), "4");
      super.putEnum(Long.valueOf(5L), "5");
    }
  }

  public static class DeviceColorCfgEnum extends GenericEnum
  {
    public static String RACK = "RACK";
    public static String SUBRACK = "SUBRACK";
    public static String SHELF = "SHELF";
    public static String SUBSHELF = "SUBSHELF";
    public static String SLOT = "SLOT";
    public static String SUBSLOT = "SUBSLOT";
    public static String CARD = "CARD";
    public static String ODFMODULE = "ODFMODULE";
    public static String DDFMODULE = "DDFMODULE";

    private DeviceColorCfgEnum() {
      super.putEnum(RACK, "机架");
      super.putEnum(SUBRACK, "子架");
      super.putEnum(SHELF, "机框");
      super.putEnum(SUBSHELF, "子框");
      super.putEnum(SLOT, "机槽");
      super.putEnum(SUBSLOT, "子槽");
      super.putEnum(CARD, "机盘");
      super.putEnum(ODFMODULE, "ODM模块");
      super.putEnum(DDFMODULE, "DDF模块");
    }
  }

  public static class AlarmDetectDirectionNo extends GenericEnum
  {
    public static final int _NA = 3;

    private AlarmDetectDirectionNo()
    {
      super.putEnum(Integer.valueOf(3), "无");
    }
  }

  public static class AlarmDetectDirection extends GenericEnum
  {
    public static final int _inner = 1;
    public static final int _outer = 2;
    public static final int _NA = 3;

    private AlarmDetectDirection()
    {
      super.putEnum(Integer.valueOf(3), "无");
      super.putEnum(Integer.valueOf(1), "内部");
      super.putEnum(Integer.valueOf(2), "外部");
    }
  }

  public static class RootAlarmType extends GenericEnum
  {
    public static final int _NA = 1;
    public static final int _NotRoot = 2;
    public static final int _SimpleRoot = 3;
    public static final int _RealRoot = 4;

    private RootAlarmType()
    {
      super.putEnum(Integer.valueOf(1), "未处理");
      super.putEnum(Integer.valueOf(2), "衍生告警");
      super.putEnum(Integer.valueOf(3), "单根告警");
      super.putEnum(Integer.valueOf(4), "根告警");
    }
  }

  public static class SuppressTypeWdm extends GenericEnum
  {
    public static final int _UpServ = 1;
    public static final int _DownServ = 2;
    public static final int _SamePort = 3;
    public static final int _ServiceEnd = 4;
    public static final int _TopoEnd = 7;
    public static final int _ServiceSide = 8;
    public static final int _WaveSide = 9;

    private SuppressTypeWdm()
    {
      super.putEnum(Integer.valueOf(1), "业务上游");
      super.putEnum(Integer.valueOf(2), "业务下游");
      super.putEnum(Integer.valueOf(3), "同端口");
      super.putEnum(Integer.valueOf(4), "业务对端");
      super.putEnum(Integer.valueOf(7), "拓扑对端");
      super.putEnum(Integer.valueOf(8), "业务侧");
      super.putEnum(Integer.valueOf(9), "波分侧");
    }
  }

  public static class SuppressTypeSdh extends GenericEnum
  {
    public static final int _UpServ = 1;
    public static final int _DownServ = 2;
    public static final int _SamePort = 3;
    public static final int _ServiceEnd = 4;
    public static final int _MSEnd = 5;
    public static final int _RSEnd = 6;
    public static final int _TopoEnd = 7;

    private SuppressTypeSdh()
    {
      super.putEnum(Integer.valueOf(1), "业务上游");
      super.putEnum(Integer.valueOf(2), "业务下游");
      super.putEnum(Integer.valueOf(3), "同端口");
      super.putEnum(Integer.valueOf(4), "业务对端");
      super.putEnum(Integer.valueOf(5), "复用段对端");
      super.putEnum(Integer.valueOf(6), "再生段对端");
      super.putEnum(Integer.valueOf(7), "拓扑对端");
    }
  }

  public static class SuppressType extends GenericEnum
  {
    public static final int _UpServ = 1;
    public static final int _DownServ = 2;
    public static final int _SamePort = 3;
    public static final int _ServiceEnd = 4;
    public static final int _MSEnd = 5;
    public static final int _RSEnd = 6;
    public static final int _TopoEnd = 7;
    public static final int _ServiceSide = 8;
    public static final int _WaveSide = 9;

    private SuppressType()
    {
      super.putEnum(Integer.valueOf(1), "业务上游");
      super.putEnum(Integer.valueOf(2), "业务下游");
      super.putEnum(Integer.valueOf(3), "同端口");
      super.putEnum(Integer.valueOf(4), "业务对端");
      super.putEnum(Integer.valueOf(5), "复用段对端");
      super.putEnum(Integer.valueOf(6), "再生段对端");
      super.putEnum(Integer.valueOf(7), "拓扑对端");
      super.putEnum(Integer.valueOf(8), "业务侧");
      super.putEnum(Integer.valueOf(9), "波分侧");
    }
  }

  public static class SwitchElementType extends GenericEnum
  {
    public static final long _nul = 1L;
    public static final long _insert = 2L;
    public static final long _order = 3L;

    private SwitchElementType()
    {
      super.putEnum(Long.valueOf(1L), "未知");
      super.putEnum(Long.valueOf(2L), "间插方式");
      super.putEnum(Long.valueOf(3L), "顺序方式");
    }
  }

  public static class GuideLine extends GenericEnum
  {
    public static final long _AU4 = 1L;
    public static final long _2M = 2L;
    public static final long _transPath = 3L;
    public static final long _2MPtp = 4L;
    public static final long _idleChildHole = 5L;
    public static final long _fiberUsingRate = 6L;

    private GuideLine()
    {
      super.putEnum(Long.valueOf(1L), "AU4Spare");
      super.putEnum(Long.valueOf(2L), "2MUseRate");
      super.putEnum(Long.valueOf(3L), "TransPathUseRate");
      super.putEnum(Long.valueOf(4L), "2MPortUseRate");
      super.putEnum(Long.valueOf(5L), "IdleChildHole");
      super.putEnum(Long.valueOf(6L), "FiberUsingRate");
    }
  }

  public static class CheckTaskState extends GenericEnum
  {
    public static final long _notcheck = 1L;
    public static final long _checking = 2L;
    public static final long _checkend = 3L;
    public static final long _checkExceptionend = 4L;
    public static final long _checkPaused = 5L;

    private CheckTaskState()
    {
      super.putEnum(Long.valueOf(1L), "未核查");
      super.putEnum(Long.valueOf(2L), "正在核查");
      super.putEnum(Long.valueOf(3L), "核查结束");
      super.putEnum(Long.valueOf(4L), "核查异常终止");
      super.putEnum(Long.valueOf(5L), "核查暂停");
    }
  }

  public static class AlarmImportance extends GenericEnum
  {
    public static final long _all = 0L;
    public static final long _opticalAlarm = 1L;
    public static final long _branckOpticalAlarm = 2L;
    public static final long _other = 3L;
  }

  public static class BranchCheckResult extends GenericEnum
  {
    public static final long _unknow = 1L;
    public static final long _allsucess = 2L;
    public static final long _partsucess = 3L;
    public static final long _allfail = 4L;

    private BranchCheckResult()
    {
      super.putEnum(Long.valueOf(1L), "未知");
      super.putEnum(Long.valueOf(2L), "全部成功");
      super.putEnum(Long.valueOf(3L), "部分成功");
      super.putEnum(Long.valueOf(4L), "全部失败");
    }
  }

  public static class CheckResult extends GenericEnum
  {
    public static final long _unknow = 1L;
    public static final long _sucess = 2L;
    public static final long _fail = 3L;

    private CheckResult()
    {
      super.putEnum(Long.valueOf(1L), "未知");
      super.putEnum(Long.valueOf(2L), "成功");
      super.putEnum(Long.valueOf(3L), "失败");
    }
  }

  public static class CheckState extends GenericEnum
  {
    public static final long _notcheck = 1L;
    public static final long _checking = 2L;
    public static final long _checkend = 3L;

    private CheckState()
    {
      super.putEnum(Long.valueOf(1L), "未核查");
      super.putEnum(Long.valueOf(2L), "正在核查");
      super.putEnum(Long.valueOf(3L), "核查结束");
    }
  }

  public static class PathState extends GenericEnum
  {
    public static final long _idle = 1L;
    public static final long _inuse = 2L;
    public static final long _preuse = 3L;
    public static final long _rddc = 4L;
    public static final long _resKeep = 5L;

    private PathState()
    {
      super.putEnum(Long.valueOf(1L), "空闲");
      super.putEnum(Long.valueOf(2L), "已用");
      super.putEnum(Long.valueOf(3L), "预占");
      super.putEnum(Long.valueOf(4L), "冗余");
      super.putEnum(Long.valueOf(5L), "保留");
    }
  }

  public static class ProtectMode extends GenericEnum
  {
    public static final long _idle = 1L;
    public static final long _inuse = 2L;

    private ProtectMode()
    {
      super.putEnum(Long.valueOf(1L), "PA_NA");
      super.putEnum(Long.valueOf(2L), "PA_PSR_RELATED");
    }
  }

  public static class Rate extends GenericEnum
  {
    public static final long _2M = 1L;
    public static final long _8M = 2L;
    public static final long _10M = 3L;
    public static final long _34M = 4L;
    public static final long _45M = 5L;
    public static final long _68M = 6L;
    public static final long _100M = 7L;
    public static final long _140M = 8L;
    public static final long _155M = 9L;
    public static final long _280M = 10L;
    public static final long _310M = 11L;
    public static final long _565M = 12L;
    public static final long _622M = 13L;
    public static final long _1G = 14L;
    public static final long _1D25G = 15L;
    public static final long _2D5G = 16L;
    public static final long _10G = 17L;
    public static final long _20G = 18L;
    public static final long _40G = 19L;
    public static final long _80G = 20L;
    public static final long _120G = 21L;
    public static final long _6M = 22L;
    public static final long _12M = 23L;
    public static final long _16M = 24L;
    public static final long _4M = 25L;
    public static final long _64k = 26L;
    public static final long _NA = 27L;
    public static final long _3D5G = 28L;
    public static final long _320G = 29L;
    public static final long _400G = 30L;
    public static final long _800G = 31L;
    public static final long _1600G = 32L;
    public static final long _32M = 33L;
    public static final long _FE = 34L;
    public static final long _GE = 35L;
    public static final long _10GE = 36L;
    public static final long _FC100 = 37L;
    public static final long _FC200 = 38L;
    public static final long _FC400 = 39L;
    public static final long _FC800 = 40L;

    private Rate()
    {
      super.putEnum(Long.valueOf(1L), "2M");
      super.putEnum(Long.valueOf(2L), "8M");
      super.putEnum(Long.valueOf(3L), "10M");
      super.putEnum(Long.valueOf(4L), "34M");
      super.putEnum(Long.valueOf(5L), "45M");
      super.putEnum(Long.valueOf(6L), "68M");
      super.putEnum(Long.valueOf(7L), "100M");
      super.putEnum(Long.valueOf(8L), "140M");
      super.putEnum(Long.valueOf(9L), "155M");
      super.putEnum(Long.valueOf(10L), "280M");
      super.putEnum(Long.valueOf(11L), "310M");
      super.putEnum(Long.valueOf(12L), "565M");
      super.putEnum(Long.valueOf(13L), "622M");
      super.putEnum(Long.valueOf(14L), "1G");
      super.putEnum(Long.valueOf(15L), "1.25G");
      super.putEnum(Long.valueOf(16L), "2.5G");
      super.putEnum(Long.valueOf(17L), "10G");
      super.putEnum(Long.valueOf(18L), "20G");
      super.putEnum(Long.valueOf(19L), "40G");
      super.putEnum(Long.valueOf(20L), "80G");
      super.putEnum(Long.valueOf(21L), "120G");
      super.putEnum(Long.valueOf(22L), "6M");
      super.putEnum(Long.valueOf(23L), "12M");
      super.putEnum(Long.valueOf(24L), "16M");
      super.putEnum(Long.valueOf(25L), "4M");
      super.putEnum(Long.valueOf(26L), "64k");
      super.putEnum(Long.valueOf(27L), "NA");
      super.putEnum(Long.valueOf(28L), "3.5G");

      super.putEnum(Long.valueOf(29L), "320G");
      super.putEnum(Long.valueOf(30L), "400G");
      super.putEnum(Long.valueOf(31L), "800G");
      super.putEnum(Long.valueOf(32L), "1600G");

      super.putEnum(Long.valueOf(33L), "32M");

      super.putEnum(Long.valueOf(34L), "FE");
      super.putEnum(Long.valueOf(35L), "GE");
      super.putEnum(Long.valueOf(36L), "10GE");
      super.putEnum(Long.valueOf(37L), "FC100");
      super.putEnum(Long.valueOf(38L), "FC200");
      super.putEnum(Long.valueOf(39L), "FC400");
      super.putEnum(Long.valueOf(40L), "FC800");
    }
  }

  public static class AtmType extends GenericEnum
  {
    public static final long ATM = 1L;
    public static final long ATMTRUNK = 2L;
    public static final long RPR = 3L;

    private AtmType()
    {
      super.putEnum(Long.valueOf(1L), "ATM");
      super.putEnum(Long.valueOf(2L), "ATMTRUNK");
    }
  }

  public static class EthType extends GenericEnum
  {
    public static final long MAC = 1L;
    public static final long MP = 2L;
    public static final long RPR = 3L;

    private EthType()
    {
      super.putEnum(Long.valueOf(1L), "MAC");
      super.putEnum(Long.valueOf(2L), "MP");
      super.putEnum(Long.valueOf(3L), "RPR");
    }
  }

  public static class Domain extends GenericEnum
  {
    public static final long SDH = 1L;
    public static final long ETH = 2L;
    public static final long ATM = 3L;
    public static final long UNKNOWN = 0L;
    public static final long WDM = 5L;
    public static final long RTN = 6L;
    public static final long PTN = 7L;
    public static final long LAG = 8L;
    public static final long IMA = 9L;

    private Domain()
    {
      super.putEnum(Long.valueOf(1L), "sdh");
      super.putEnum(Long.valueOf(2L), "eth");
      super.putEnum(Long.valueOf(3L), "atm");
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(5L), "wdm");
      super.putEnum(Long.valueOf(6L), "rtn");
      super.putEnum(Long.valueOf(7L), "ptn");
      super.putEnum(Long.valueOf(8L), "lag");
      super.putEnum(Long.valueOf(9L), "ima");
    }
  }

  public static class IsConnState extends GenericEnum
  {
    public static final long Y = 1L;
    public static final long N = 0L;

    private IsConnState()
    {
      super.putEnum(Long.valueOf(1L), "TRUE");
      super.putEnum(Long.valueOf(0L), "FALSE");
    }
  }

  public static class Position extends GenericEnum
  {
    public static final long POSITION_INNER_BOTTOM = 10L;
    public static final long POSITION_INNER_LEFT = 12L;
    public static final long POSITION_INNER_RIGHT = 13L;
    public static final long POSITION_INNER_TOP = 11L;
    public static final long POSITION_CENTER = 1L;

    private Position()
    {
      super.putEnum(Long.valueOf(1L), "中间");
      super.putEnum(Long.valueOf(11L), "上面");
      super.putEnum(Long.valueOf(10L), "下面");
      super.putEnum(Long.valueOf(12L), "左面");
      super.putEnum(Long.valueOf(13L), "右面");
    }
  }

  public static class Directionality extends GenericEnum
  {
    public static final long _NA = 1L;
    public static final long BIDIRECTIONAL = 2L;
    public static final long SOURCE = 3L;
    public static final long SINK = 4L;

    private Directionality()
    {
      super.putEnum(Long.valueOf(1L), "NA");
      super.putEnum(Long.valueOf(2L), "双向");
      super.putEnum(Long.valueOf(3L), "源");
      super.putEnum(Long.valueOf(4L), "宿");
    }
  }

  public static class TerminationMode extends GenericEnum
  {
    public static final long NA = 1L;
    public static final long TERMINATED_AVAILABLE_MAPPING = 2L;
    public static final long NEITHER_TERMINATED_NOR_AVAILABLE_MAPPING = 3L;

    private TerminationMode()
    {
      super.putEnum(Long.valueOf(1L), "NA");
      super.putEnum(Long.valueOf(2L), "TERMINATED_AVAILABLE_MAPPING");
      super.putEnum(Long.valueOf(3L), "NEITHER_TERMINATED_NOR_AVAILABLE_MAPPING");
    }
  }

  public static class TransPortType1 extends GenericEnum
  {
    public static final long ELEC_PORT = 1L;
    public static final long LIGHT_PORT = 2L;
    public static final long UNKNOW_PORT = 0L;

    private TransPortType1()
    {
      super.putEnum(Long.valueOf(1L), "电口");
      super.putEnum(Long.valueOf(2L), "光口");
      super.putEnum(Long.valueOf(0L), "未知");
    }
  }

  public static class TransPortSubType extends GenericEnum
  {
    public static final long UNKNOW_PORT = 0L;
    public static final long MSTP_PORT = 3L;
    public static final long IF_PORT = 5L;
    public static final long RF_PORT = 6L;
    public static final long IMA_PORT = 7L;
    public static final long LAG_PORT = 8L;
    public static final long GPON_PORT = 9L;
    public static final long EPON_PORT = 10L;
    public static final long OLTUP_PORT = 11L;
    public static final long LIGHTUP_PORT = 12L;
    public static final long LIGHTDOWN_PORT = 13L;
    public static final long ONUUP_PORT = 14L;
    public static final long FE_PORT = 15L;
    public static final long POTS_PORT = 16L;
    public static final long SDH_PORT = 21L;
    public static final long PDH_PORT = 22L;
    public static final long ADSL_PORT = 23L;
    public static final long ADSL2_PLUS_PORT = 24L;
    public static final long POS_PORT = 25L;
    public static final long SHDSL_PORT = 26L;
    public static final long VDSL2_PORT = 27L;
    public static final long ATM_PORT = 28L;
    public static final long ETH = 29L;
    public static final long PSTN = 30L;
    public static final long WDM_PORT = 31L;
    public static final long PTN_PORT = 32L;
    public static final long PON_OPT_GE = 33L;
    public static final long PON_ELC_GE = 36L;
    public static final long PON_ELC_FE = 37L;
    public static final long PON_OPT_FE = 38L;
    public static final long XDK = 39L;

    private TransPortSubType()
    {
      super.putEnum(Long.valueOf(0L), "未知");

      super.putEnum(Long.valueOf(3L), "MSTP口");
      super.putEnum(Long.valueOf(5L), "中频口");
      super.putEnum(Long.valueOf(6L), "射频口");
      super.putEnum(Long.valueOf(7L), "IMA口");
      super.putEnum(Long.valueOf(8L), "LAG口");
      super.putEnum(Long.valueOf(9L), "GPON口");
      super.putEnum(Long.valueOf(10L), "EPON口");

      super.putEnum(Long.valueOf(11L), "OLT上联口");
      super.putEnum(Long.valueOf(12L), "分光器上联口");
      super.putEnum(Long.valueOf(13L), "分光器下联口");
      super.putEnum(Long.valueOf(14L), "ONU上联口");
      super.putEnum(Long.valueOf(15L), "FE");
      super.putEnum(Long.valueOf(16L), "POTS");

      super.putEnum(Long.valueOf(21L), "SDH口");
      super.putEnum(Long.valueOf(22L), "PDH");
      super.putEnum(Long.valueOf(23L), "ADSL");
      super.putEnum(Long.valueOf(24L), "ADSL2_PLUS");
      super.putEnum(Long.valueOf(25L), "POS");
      super.putEnum(Long.valueOf(26L), "SHDSL");
      super.putEnum(Long.valueOf(27L), "VDSL2");
      super.putEnum(Long.valueOf(28L), "ATM");
      super.putEnum(Long.valueOf(29L), "ETH");
      super.putEnum(Long.valueOf(30L), "PSTN");
      super.putEnum(Long.valueOf(31L), "波分口");
      super.putEnum(Long.valueOf(32L), "PTN口");

      super.putEnum(Long.valueOf(33L), "光GE口");
      super.putEnum(Long.valueOf(36L), "电GE口");
      super.putEnum(Long.valueOf(37L), "电FE口");
      super.putEnum(Long.valueOf(38L), "光FE口");
      super.putEnum(Long.valueOf(39L), "虚端口");
    }

    private TransPortSubType(long domain)
    {
      if ((domain == 2L) || (domain == 3L))
      {
        super.putEnum(Long.valueOf(3L), "MSTP口");
        super.putEnum(Long.valueOf(0L), "未知");
      }
    }

    public TransPortSubType getTransPortSubType(long domain)
    {
      return new TransPortSubType(domain);
    }

    public TransPortSubType getAll()
    {
      return new TransPortSubType();
    }
  }

  public static class TransPortType extends GenericEnum
  {
    public static final long ELEC_PORT = 1L;
    public static final long LIGHT_PORT = 2L;
    public static final long LOGIC_PORT = 4L;

    private TransPortType()
    {
      super.putEnum(Long.valueOf(1L), "电口");
      super.putEnum(Long.valueOf(2L), "光口");

      super.putEnum(Long.valueOf(4L), "逻辑口");
    }

    private TransPortType(long domain)
    {
      if (domain == 1L)
      {
        super.putEnum(Long.valueOf(1L), "电口");
        super.putEnum(Long.valueOf(2L), "光口");
      }
    }

    public TransPortType getTransPortType(long domain)
    {
      return new TransPortType(domain);
    }

    public TransPortType getAll()
    {
      return new TransPortType();
    }
  }

  public static class TransPortStateType extends GenericEnum
  {
    public static final long _unknown = 0L;
    public static final long _idle = 1L;
    public static final long _inuse = 2L;
    public static final long _preuse = 3L;
    public static final long _bad = 4L;
    public static final long _resKeep = 5L;

    private TransPortStateType()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "空闲");
      super.putEnum(Long.valueOf(2L), "占用");
      super.putEnum(Long.valueOf(3L), "预占用");
      super.putEnum(Long.valueOf(4L), "坏端口");
      super.putEnum(Long.valueOf(5L), "保留");
    }
  }

  public static class ServiceState extends GenericEnum
  {
    public static final long USER = 1L;
    public static final long UNUSER = 2L;

    private ServiceState()
    {
      super.putEnum(Long.valueOf(1L), "可用");
      super.putEnum(Long.valueOf(2L), "不可用");
    }
  }

  public static class ResistanceType extends GenericEnum
  {
    public static final long _120 = 1L;
    public static final long _75 = 2L;
    public static final long _fc = 3L;
    public static final long _sc = 4L;

    private ResistanceType()
    {
      super.putEnum(Long.valueOf(1L), "120欧姆");
      super.putEnum(Long.valueOf(2L), "75欧姆");
      super.putEnum(Long.valueOf(3L), "FC");
      super.putEnum(Long.valueOf(4L), "SC");
    }
  }

  public static class SwitchPortType extends GenericEnum
  {
    public static final long BIDIRECT_ELEMENT = 1L;
    public static final long BIDIRECT_FULL = 2L;

    private SwitchPortType()
    {
      super.putEnum(Long.valueOf(1L), "双向电");
      super.putEnum(Long.valueOf(2L), "双向充");
    }
  }

  public static class InterFaceType extends GenericEnum
  {
    public static final long _UNKNOW = 0L;
    public static final long _ETHERNET = 1L;
    public static final long _E1 = 2L;

    private InterFaceType()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "以太网口");
      super.putEnum(Long.valueOf(2L), "E1");
    }
  }

  public static class SwitchPortStateType extends GenericEnum
  {
    public static final long _idle = 1L;
    public static final long _inuse = 2L;
    public static final long _preuse = 3L;
    public static final long _prerelease = 4L;
    public static final long _prerelease_preuse = 5L;
    public static final long _bad = 6L;

    private SwitchPortStateType()
    {
      super.putEnum(Long.valueOf(1L), "空闲");
      super.putEnum(Long.valueOf(2L), "占用");
      super.putEnum(Long.valueOf(3L), "预占用");
      super.putEnum(Long.valueOf(4L), "预释放");
      super.putEnum(Long.valueOf(5L), "预占用释放");
      super.putEnum(Long.valueOf(6L), "坏端口");
    }
  }

  public static class ServiceType extends GenericEnum
  {
    public static final long _talk = 1L;
    public static final long _dcn = 2L;

    private ServiceType()
    {
      super.putEnum(Long.valueOf(1L), "语音");
      super.putEnum(Long.valueOf(2L), "DCN");
    }
  }

  public static class RackOwnerShip extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _self = 1L;
    public static final long _leasehold = 2L;

    private RackOwnerShip()
    {
      super.putEnum(Long.valueOf(1L), "自建");
      super.putEnum(Long.valueOf(2L), "租用");
      super.putEnum(Long.valueOf(0L), "未知");
    }
  }

  public static class mstpFCSCALSEQ extends GenericEnum
  {
    public static final long _Littleendian = 1L;
    public static final long _Bigendian = 2L;

    private mstpFCSCALSEQ()
    {
      super.putEnum(Long.valueOf(1L), "Little endian");
      super.putEnum(Long.valueOf(2L), "Big endian");
    }
  }

  public static class mstpCFLEN extends GenericEnum
  {
    public static final long _FCS32 = 1L;
    public static final long _FCS16 = 2L;
    public static final long _No = 3L;

    private mstpCFLEN()
    {
      super.putEnum(Long.valueOf(1L), "FCS32");
      super.putEnum(Long.valueOf(2L), "FCS16");
      super.putEnum(Long.valueOf(3L), "No");
    }
  }

  public static class mstpEXTENDEADER extends GenericEnum
  {
    public static final long _No = 1L;
    public static final long _Yes = 2L;

    private mstpEXTENDEADER()
    {
      super.putEnum(Long.valueOf(1L), "No");
      super.putEnum(Long.valueOf(2L), "Yes");
    }
  }

  public static class mstpSCRAMBEL extends GenericEnum
  {
    public static final long _x431 = 1L;
    public static final long _x481 = 2L;
    public static final long _NotScramble = 3L;

    private mstpSCRAMBEL()
    {
      super.putEnum(Long.valueOf(1L), "[x43+1]");
      super.putEnum(Long.valueOf(2L), "[x48+1]");
      super.putEnum(Long.valueOf(3L), "Not Scramble");
    }
  }

  public static class mstpLcasFlag extends GenericEnum
  {
    public static final long _Enabled = 1L;
    public static final long _Disabled = 2L;

    private mstpLcasFlag()
    {
      super.putEnum(Long.valueOf(1L), "Enabled");
      super.putEnum(Long.valueOf(2L), "Disabled");
    }
  }

  public static class mstpENCAPFORMAT extends GenericEnum
  {
    public static final long _MartinioE = 1L;
    public static final long _CCCoE = 2L;
    public static final long _VMANoE = 3L;
    public static final long _MartinioP = 4L;

    private mstpENCAPFORMAT()
    {
      super.putEnum(Long.valueOf(1L), "MartinioE");
      super.putEnum(Long.valueOf(2L), "CCCoE");
      super.putEnum(Long.valueOf(3L), "VMANoE");
      super.putEnum(Long.valueOf(4L), "MartinioP");
    }
  }

  public static class mstpENCAPPROTOCOL extends GenericEnum
  {
    public static final long _HDLC = 1L;
    public static final long _LAPS = 2L;
    public static final long _ATM = 3L;
    public static final long _PPP = 4L;
    public static final long _GFP = 5L;

    private mstpENCAPPROTOCOL()
    {
      super.putEnum(Long.valueOf(1L), "HDLC");
      super.putEnum(Long.valueOf(2L), "LAPS");
      super.putEnum(Long.valueOf(3L), "ATM");
      super.putEnum(Long.valueOf(4L), "PPP");
      super.putEnum(Long.valueOf(5L), "GFP");
    }
  }

  public static class mstpEdetect extends GenericEnum
  {
    public static final long _Enabled = 1L;
    public static final long _Disabled = 2L;

    private mstpEdetect()
    {
      super.putEnum(Long.valueOf(1L), "Enabled");
      super.putEnum(Long.valueOf(2L), "Disabled");
    }
  }

  public static class mstpBmsgsuppress extends GenericEnum
  {
    public static final long _Enabled = 1L;
    public static final long _Disabled = 2L;

    private mstpBmsgsuppress()
    {
      super.putEnum(Long.valueOf(1L), "Enabled");
      super.putEnum(Long.valueOf(2L), "Disabled");
    }
  }

  public static class mstpAnfcMode extends GenericEnum
  {
    public static final long _Disabled = 1L;
    public static final long _NonSymmetricFlowControl = 2L;
    public static final long _SymmetricFlowControl = 3L;
    public static final long _SymmetricOrNonSymmetricFlowControl = 4L;

    private mstpAnfcMode()
    {
      super.putEnum(Long.valueOf(1L), "Disabled");
      super.putEnum(Long.valueOf(2L), "NonSymmetricFlowControl");
      super.putEnum(Long.valueOf(3L), "SymmetricFlowControl");
      super.putEnum(Long.valueOf(4L), "SymmetricOrNonSymmetricFlowControl");
    }
  }

  public static class mstpNanfcMode extends GenericEnum
  {
    public static final long _Disabled = 1L;
    public static final long _SymmetricFlowControl = 2L;
    public static final long _SendOnly = 3L;
    public static final long _ReceiveOnly = 4L;

    private mstpNanfcMode()
    {
      super.putEnum(Long.valueOf(1L), "Disabled");
      super.putEnum(Long.valueOf(2L), "SymmetricFlowControl");
      super.putEnum(Long.valueOf(3L), "SendOnly");
      super.putEnum(Long.valueOf(4L), "ReceiveOnly");
    }
  }

  public static class mstpPortServiceType extends GenericEnum
  {
    public static final long _SW = 1L;
    public static final long _PKT = 2L;

    private mstpPortServiceType()
    {
      super.putEnum(Long.valueOf(1L), "SW");
      super.putEnum(Long.valueOf(2L), "PKT");
    }
  }

  public static class mstpPortType2 extends GenericEnum
  {
    public static final long _PE = 1L;
    public static final long _P = 2L;

    private mstpPortType2()
    {
      super.putEnum(Long.valueOf(1L), "PE");
      super.putEnum(Long.valueOf(2L), "P");
    }
  }

  public static class mstpWorkMode extends GenericEnum
  {
    public static final long _10Mhalf = 1L;
    public static final long _10Mall = 2L;
    public static final long _100Mhalf = 3L;
    public static final long _100Mall = 4L;
    public static final long _arrange = 5L;
    public static final long _1000Mhalf = 6L;
    public static final long _1000Mall = 7L;

    private mstpWorkMode()
    {
      super.putEnum(Long.valueOf(1L), "10M半双工");
      super.putEnum(Long.valueOf(2L), "10M全双工");
      super.putEnum(Long.valueOf(3L), "100M半双工");
      super.putEnum(Long.valueOf(4L), "100M全双工");
      super.putEnum(Long.valueOf(6L), "1000M半双工");
      super.putEnum(Long.valueOf(7L), "1000M全双工");
      super.putEnum(Long.valueOf(5L), "自协商");
    }
  }

  public static class mstpPtpEnable extends GenericEnum
  {
    public static final long _Enabled = 1L;
    public static final long _Disabled = 2L;

    private mstpPtpEnable()
    {
      super.putEnum(Long.valueOf(1L), "Enabled");
      super.putEnum(Long.valueOf(2L), "Disabled");
    }
  }

  public static class mstpPortEnable extends GenericEnum
  {
    public static final long _Enabled = 1L;
    public static final long _Disabled = 2L;

    private mstpPortEnable()
    {
      super.putEnum(Long.valueOf(1L), "Enabled");
      super.putEnum(Long.valueOf(2L), "Disabled");
    }
  }

  public static class msptFlowCtrl extends GenericEnum
  {
    public static final long _Enabled = 1L;
    public static final long _Disabled = 2L;

    private msptFlowCtrl()
    {
      super.putEnum(Long.valueOf(1L), "Enabled");
      super.putEnum(Long.valueOf(2L), "Disabled");
    }
  }

  public static class mstpTagFlag extends GenericEnum
  {
    public static final long _tagaware = 1L;
    public static final long _access = 2L;
    public static final long _hybrid = 3L;

    private mstpTagFlag()
    {
      super.putEnum(Long.valueOf(1L), "TagAware");
      super.putEnum(Long.valueOf(2L), "Access");
      super.putEnum(Long.valueOf(3L), "Hybrid");
    }
  }

  public static class mstpPortType extends GenericEnum
  {
    public static final long _mac = 1L;
    public static final long _ethtrunk = 2L;
    public static final long _rpr = 3L;
    public static final long _atm = 4L;
    public static final long _atmtrunk = 5L;
    public static final long _lp = 6L;

    private mstpPortType()
    {
      super.putEnum(Long.valueOf(1L), "MAC");
      super.putEnum(Long.valueOf(2L), "MP");
      super.putEnum(Long.valueOf(3L), "RPR");
      super.putEnum(Long.valueOf(4L), "ATM");
      super.putEnum(Long.valueOf(5L), "ATMTRUNK");
      super.putEnum(Long.valueOf(6L), "LP");
    }
  }

  public static class mstpBindPathLevel extends GenericEnum
  {
    public static final long _VC4 = 1L;
    public static final long _VC3 = 2L;
    public static final long _VC12 = 3L;

    private mstpBindPathLevel()
    {
      super.putEnum(Long.valueOf(1L), "VC4");
      super.putEnum(Long.valueOf(2L), "VC3");
      super.putEnum(Long.valueOf(3L), "VC12");
    }
  }

  public static class mstpBindPathDir extends GenericEnum
  {
    public static final long _None = 1L;
    public static final long _DoubleDir = 2L;
    public static final long _Upper = 3L;
    public static final long _Down = 4L;

    private mstpBindPathDir()
    {
      super.putEnum(Long.valueOf(1L), "空");
      super.putEnum(Long.valueOf(2L), "双向");
      super.putEnum(Long.valueOf(3L), "上行");
      super.putEnum(Long.valueOf(4L), "下行");
    }
  }

  public static class mstpEthServiceType extends GenericEnum
  {
    public static final long _EPL = 1L;
    public static final long _EVPL = 2L;
    public static final long _EPLAN = 3L;
    public static final long _EVPLAN = 4L;

    private mstpEthServiceType()
    {
      super.putEnum(Long.valueOf(1L), "EPL");
      super.putEnum(Long.valueOf(2L), "EVPL");
      super.putEnum(Long.valueOf(3L), "EPLAN");
      super.putEnum(Long.valueOf(4L), "EVPLAN");
    }
  }

  public static class mstpEthServiceDirection extends GenericEnum
  {
    public static final long _DoubleDir = 1L;
    public static final long _SimpleDir = 2L;

    private mstpEthServiceDirection()
    {
      super.putEnum(Long.valueOf(1L), "双向");
      super.putEnum(Long.valueOf(2L), "单向");
    }
  }

  public static class LoginLog extends GenericEnum
  {
    public static final String _login = "0";
    public static final String _quit = "1";

    private LoginLog()
    {
      super.putEnum("0", "登陆");
      super.putEnum("1", "退出");
    }
  }

  public static class LinePairPhyAble extends GenericEnum
  {
    public static final long line_pair_fine = 1L;
    public static final long line_pair_damage = 2L;

    private LinePairPhyAble()
    {
      super.putEnum(Long.valueOf(1L), "完好");
      super.putEnum(Long.valueOf(2L), "破损");
    }
  }

  public static class LinePairUseState extends GenericEnum
  {
    public static final long line_pair_free = 1L;
    public static final long line_pair_state = 2L;
    public static final long line_pair_pre = 3L;

    private LinePairUseState()
    {
      super.putEnum(Long.valueOf(1L), "空闲");
      super.putEnum(Long.valueOf(2L), "占用");
      super.putEnum(Long.valueOf(3L), "预占");
    }
  }

  public static class ExtendType extends GenericEnum
  {
    public static final long send = 1L;
    public static final long receive = 2L;

    private ExtendType()
    {
      super.putEnum(Long.valueOf(1L), "发端");
      super.putEnum(Long.valueOf(2L), "收端");
    }
  }

  public static class LinePairType extends GenericEnum
  {
    public static final long line_pair = 1L;
    public static final long extend_line = 2L;

    private LinePairType()
    {
      super.putEnum(Long.valueOf(1L), "楼间线");
      super.putEnum(Long.valueOf(2L), "延伸线");
    }
  }

  public static class ResourceType extends GenericEnum
  {
    public static final long _ptp = 1L;
    public static final long _ctp = 2L;
    public static final long _pq1 = 3L;
    public static final long _pq1Not = 4L;
    public static final long _topo = 5L;

    private ResourceType()
    {
      super.putEnum(Long.valueOf(1L), "端口");
      super.putEnum(Long.valueOf(2L), "时隙");
      super.putEnum(Long.valueOf(3L), "槽路落PQ");
      super.putEnum(Long.valueOf(4L), "槽路不落PQ");
      super.putEnum(Long.valueOf(5L), "拓扑");
    }
  }

  public static class PreWriteResState extends GenericEnum
  {
    public static final long _idle = 1L;
    public static final long _use = 2L;

    private PreWriteResState()
    {
      super.putEnum(Long.valueOf(1L), "空闲");
      super.putEnum(Long.valueOf(2L), "占用");
    }
  }
}