package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class TransSystemEnum
{
  public static final TransSysLevel TRANS_SYS_LEVEL = new TransSysLevel(null);
  public static final TransSysOwnerShip TRANS_SYS_WONERSHIP = new TransSysOwnerShip(null);
  public static final TransSysState TRANS_SYS_STAE = new TransSysState(null);
  public static final TransSysMaintMode TRANS_SYS_MAINTMODE = new TransSysMaintMode(null);
  public static final TransSysProtectMode TRANS_SYS_PROTECTMODE = new TransSysProtectMode(null);
  public static final TransSysNetType TRANS_SYS_NETTYPE = new TransSysNetType(null);

  public static final TransSysDirection TRANS_SYS_DIRECTION = new TransSysDirection(null);

  public static final TransSystemTypeValue TRANSSYSTEMTYPE = new TransSystemTypeValue(null);

  public static final TransSystemTypeCn TRANSSYSTEMTYPECN = new TransSystemTypeCn(null);
  public static final TransSystemState TRANSSYSTEMSTATE = new TransSystemState(null);

  public static class TransSystemState extends GenericEnum
  {
    public static final long _WORKSTATE = 1L;
    public static final long _PROTECTSTATE = 2L;

    private TransSystemState()
    {
      super.putEnum(Long.valueOf(1L), "工作");
      super.putEnum(Long.valueOf(2L), "保护");
    }
  }

  public static class TransSystemTypeCn extends GenericEnum
  {
    public static final long _NP_RING = 1L;
    public static final long _NP_CHAIN = 2L;
    public static final long _MSP_1_PLUS_1 = 3L;
    public static final long _MSP_1_FOR_N = 4L;
    public static final long _2_FIBER_ULSR = 5L;
    public static final long _2_FIBER_BLSR = 6L;
    public static final long _4_FIBER_BLSR = 7L;
    public static final long _UPP = 8L;
    public static final long _BPP = 9L;

    private TransSystemTypeCn()
    {
      super.putEnum(Long.valueOf(1L), "无保护环");
      super.putEnum(Long.valueOf(2L), "无保护链");
      super.putEnum(Long.valueOf(3L), "1+1复用段保护");
      super.putEnum(Long.valueOf(4L), "1:N复用段保护");
      super.putEnum(Long.valueOf(5L), "二纤单向复用段保护换");
      super.putEnum(Long.valueOf(6L), "二纤双向复用段共享保护换");
      super.putEnum(Long.valueOf(7L), "四纤双向复用段保护换");
      super.putEnum(Long.valueOf(8L), "单向通道保护环");
      super.putEnum(Long.valueOf(9L), "双向通道保护环");
    }
  }

  public static class TransSystemTypeValue extends GenericEnum
  {
    public static final long _NP_RING = 1L;
    public static final long _NP_CHAIN = 2L;
    public static final long _MSP_1_PLUS_1 = 3L;
    public static final long _MSP_1_FOR_N = 4L;
    public static final long _2_FIBER_ULSR = 5L;
    public static final long _2_FIBER_BLSR = 6L;
    public static final long _4_FIBER_BLSR = 7L;
    public static final long _UPP = 8L;
    public static final long _BPP = 9L;

    private TransSystemTypeValue()
    {
      super.putEnum(Long.valueOf(1L), "TST_NP_RING");
      super.putEnum(Long.valueOf(2L), "TST_NP_CHAIN");
      super.putEnum(Long.valueOf(3L), "TST_MSP_1_PLUS_1");
      super.putEnum(Long.valueOf(4L), "TST_MSP_1_FOR_N");
      super.putEnum(Long.valueOf(5L), "TST_2_FIBER_ULSR");
      super.putEnum(Long.valueOf(6L), "TST_2_FIBER_BLSR");
      super.putEnum(Long.valueOf(7L), "TST_4_FIBER_BLSR");
      super.putEnum(Long.valueOf(8L), "TST_UPP");
      super.putEnum(Long.valueOf(9L), "TST_BPP");
    }
  }

  public static class TransSysDirection extends GenericEnum
  {
    public static final long Direct = 1L;
    public static final long Retrorse = 2L;

    private TransSysDirection()
    {
      super.putEnum(Long.valueOf(1L), "A");
      super.putEnum(Long.valueOf(2L), "B");
    }
  }

  public static class TransSysNetType extends GenericEnum
  {
    public static final long Circle = 1L;
    public static final long Chain = 2L;
    public static final long Circle_Chanin = 3L;

    private TransSysNetType()
    {
      super.putEnum(Long.valueOf(1L), "环型");
      super.putEnum(Long.valueOf(2L), "链型");
      super.putEnum(Long.valueOf(3L), "复合型");
    }
  }

  public static class TransSysProtectMode extends GenericEnum
  {
    public static final long NoProtected = 0L;
    public static final long TwoFiberChannel = 1L;
    public static final long TwoFiberFuYong = 2L;
    public static final long FoureFiberFuYong = 3L;
    public static final long TwoFiberOneDirect = 4L;
    public static final long FourFiberOneDirect = 5L;

    private TransSysProtectMode()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "两纤通道保护");
      super.putEnum(Long.valueOf(2L), "两纤复用段保护");
      super.putEnum(Long.valueOf(3L), "四纤复用段保护");
      super.putEnum(Long.valueOf(4L), "两纤单向保护");
      super.putEnum(Long.valueOf(5L), "四纤单向保护");
    }
  }

  public static class TransSysMaintMode extends GenericEnum
  {
    public static final long unknow = 0L;
    public static final long self = 1L;
    public static final long other = 2L;

    private TransSysMaintMode()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "自维");
      super.putEnum(Long.valueOf(2L), "代维");
    }
  }

  public static class TransSysState extends GenericEnum
  {
    public static final long Design = 1L;
    public static final long Building = 2L;
    public static final long Finish = 3L;
    public static final long Abandon = 4L;
    public static final long Maintain = 5L;

    private TransSysState()
    {
      super.putEnum(Long.valueOf(1L), "设计");
      super.putEnum(Long.valueOf(2L), "在建");
      super.putEnum(Long.valueOf(3L), "竣工");
      super.putEnum(Long.valueOf(3L), "废弃");
      super.putEnum(Long.valueOf(3L), "维护");
    }
  }

  public static class TransSysOwnerShip extends GenericEnum
  {
    public static final long ZiJian = 1L;
    public static final long GongJian = 2L;
    public static final long HeJian = 3L;
    public static final long ZuYong = 4L;
    public static final long GouMai = 5L;
    public static final long ZhiHuan = 6L;

    private TransSysOwnerShip()
    {
      super.putEnum(Long.valueOf(1L), "自建");
      super.putEnum(Long.valueOf(2L), "共建");
      super.putEnum(Long.valueOf(3L), "合建");
      super.putEnum(Long.valueOf(4L), "租用");
      super.putEnum(Long.valueOf(5L), "购买");
      super.putEnum(Long.valueOf(6L), "置换");
    }
  }

  public static class TransSysLevel extends GenericEnum
  {
    public static final long ProvLevel0 = 0L;
    public static final long ProvLevel1 = 1L;
    public static final long ProvLevel2 = 2L;
    public static final long InProvLevel1 = 3L;
    public static final long LocalMain = 4L;
    public static final long LocalGather = 5L;
    public static final long LocalConnect = 6L;

    private TransSysLevel()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "省际一级");
      super.putEnum(Long.valueOf(2L), "省际二级");
      super.putEnum(Long.valueOf(3L), "省内二级");
      super.putEnum(Long.valueOf(4L), "本地骨干");
      super.putEnum(Long.valueOf(5L), "本地汇聚");
      super.putEnum(Long.valueOf(6L), "本地接入");
    }
  }
}