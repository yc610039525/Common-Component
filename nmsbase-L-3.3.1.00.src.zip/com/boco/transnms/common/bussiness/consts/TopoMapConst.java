package com.boco.transnms.common.bussiness.consts;

public class TopoMapConst
{
  public static final String MAPX = "topomapx";
  public static final String MAPY = "topomapy";
  public static final String CHILD_NUM = "childnum";
  public static final String CHILD = "child";
  public static final String OBJECT_TYPE_NAME = "OBJECT_TYPE_NAME";
  public static final String A_PTP_NAME = "A_PTP_NAME";
  public static final String Z_PTP_NAME = "Z_PTP_NAME";
  public static final String A_ELEMENT_CUID = "A_ELEMENT_CUID";
  public static final String Z_ELEMENT_CUID = "Z_ELEMENT_CUID";
  public static final String A_ELEMENT_NAME = "A_ELEMENT_NAME";
  public static final String Z_ELEMENT_NAME = "Z_ELEMENT_NAME";
  public static final String ELEMENT_POS = "ELEMENT_POS";
  public static final String TRANS_SYSTEM_NAME = "TRANS_SYSTEM_NAME";
  public static final String SITE_NAME = "SITE_NAME";
  public static final String DISTRICT_NAME = "DISTRICT_NAME";
  public static final String ROUTE_POINT_SUM = "ROUTE_POINT_SUM";
  public static final String SEG_LIST = "SEG_LIST";
  public static final String POINT_LIST = "POINT_LIST";
  public static final String GRAPH_PATH_CUID = "GRAPH_PATH_CUID";
  public static final String ELEMENT_CUID = "ELEMENT_CUID";
  public static final String SEGPATH_DIRECTION = "SEGPATH_DIRECTION";
  public static final String MUL_SEG_NE = "MUL_SEG_NE";
  public static final String REG_SEG_NE = "REG_SEG_NE";
  public static final String TRANS_SUBNETWORK_CUID = "TRANS_SUBNETWORK_CUID";
  public static final int VC4_VC12_NUM = 63;
  public static final int OBJECT_TYPE_SDH_SYSTEM = 2007;
  public static final int OBJECT_TYPE_WDM_SYSTEM = 2008;
  public static final int OBJECT_TYPE_PDH_SYSTEM = 2009;
  public static final int OBJECT_TYPE_MICROWAVE_SYSTEM = 2010;
  public static final int OBJECT_TYPE_SUBNET = 7000;
  public static final int PATH_DIRECTION_END = 1;
  public static final int PATH_DIRECTION_IN = 2;
  public static final int PATH_DIRECTION_OUT = 3;
  public static final String RELATED_SYS_CUIDS = "RELATED_SYS_CUIDS";
  public static final int PATH_STATUS_NOT_EXIST = 1;
  public static final int PATH_STATUS_EMPTY = 2;
  public static final int PATH_STATUS_USED = 3;
  public static final String OPPOSITE_SITE_NAME = "OPPOSITE_SITE_NAME";
  public static final String OPPOSITE_NE_NAME = "OPPOSITE_NE_NAME";
  public static final String ORIG_POINT_OBJ = "ORIG_POINT_OBJ";
  public static final String DEST_POINT_OBJ = "DEST_POINT_OBJ";
}