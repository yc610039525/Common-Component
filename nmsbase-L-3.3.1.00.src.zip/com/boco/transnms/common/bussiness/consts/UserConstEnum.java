package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class UserConstEnum
{
  public static final String ADMIN_USER_NAME = "admin";
  public static final String ADMIN_USER_PWD = "boco";
  public static final String ADMIN_USER_CUID = "SYS_USER-0";
  public static final String DISTRICT_ROOT = "DISTRICT-00001";
  public static final ServiceLevel SERVICE_LEVEL = new ServiceLevel(null);
  public static final UserServiceLevel USER_SERVICE_LEVEL = new UserServiceLevel(null);
  public static final NewUserServiceLevel NEW_USER_SERVICE_LEVEL = new NewUserServiceLevel(null);
  public static final DefaultSystem DEFAULT_SYSTEM = new DefaultSystem(null);

  public static class DefaultSystem extends GenericEnum
  {
    public static final long _maintainSys = 1L;
    public static final long _reportSys = 2L;
    public static final long _maintainWFSys = 3L;
    public static final long _circuitWorkflowSys = 4L;
    public static final long _opticalWorkflowSys = 5L;

    private DefaultSystem()
    {
      super.putEnum(Long.valueOf(1L), "loginMaintainSys");
      super.putEnum(Long.valueOf(2L), "loginReportSys");
      super.putEnum(Long.valueOf(3L), "loginMaintainWFSys");
      super.putEnum(Long.valueOf(4L), "loginWorkflowSys");
      super.putEnum(Long.valueOf(5L), "loginOpticalWorkflowSys");
    }
  }

  public static class NewUserServiceLevel extends GenericEnum
  {
    public static final long _State = 1L;
    public static final long _Province = 2L;
    public static final long _LocalBone = 4L;
    public static final long _LocalAggregate = 5L;
    public static final long _LocalAccess = 6L;

    private NewUserServiceLevel()
    {
      super.putEnum(Long.valueOf(1L), "省际");
      super.putEnum(Long.valueOf(2L), "省内");

      super.putEnum(Long.valueOf(4L), "本地骨干");
      super.putEnum(Long.valueOf(5L), "本地汇聚");
      super.putEnum(Long.valueOf(6L), "本地接入");
    }
  }

  public static class UserServiceLevel extends GenericEnum
  {
    public static final long _State = 1L;
    public static final long _Province = 2L;
    public static final long _ProvinceAndLocal = 3L;
    public static final long _Local = 4L;

    private UserServiceLevel()
    {
      super.putEnum(Long.valueOf(1L), "省际");
      super.putEnum(Long.valueOf(2L), "省内");
      super.putEnum(Long.valueOf(3L), "省内/本地");
      super.putEnum(Long.valueOf(4L), "本地");
    }
  }

  public static class ServiceLevel extends GenericEnum
  {
    public static final long _State = 1L;
    public static final long _Province = 2L;
    public static final long _ProvinceAndLocal = 3L;
    public static final long _LocalBone = 4L;
    public static final long _LocalAggregate = 5L;
    public static final long _LocalAccess = 6L;

    private ServiceLevel()
    {
      super.putEnum(Long.valueOf(1L), "省际");
      super.putEnum(Long.valueOf(2L), "省内");
      super.putEnum(Long.valueOf(3L), "省内/本地");
      super.putEnum(Long.valueOf(4L), "本地骨干");
      super.putEnum(Long.valueOf(5L), "本地汇聚");
      super.putEnum(Long.valueOf(6L), "本地接入");
    }
  }
}