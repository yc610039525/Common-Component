package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class DuctEnum
{
  public static final DMWireSegType DM_WireSeg_Type = new DMWireSegType(null);
  public static final DMOwnerShip DM_OWNER_SHIP = new DMOwnerShip(null);

  public static final DMOpticalway DM_OPTICALWAY_EXE_TYPE = new DMOpticalway(null);
  public static final DMSystemLevel DM_SYSTEM_LEVEL = new DMSystemLevel(null);
  public static final DMSystemType DM_SYSTEM_TYPE = new DMSystemType(null);
  public static final DMMaintMode DM_MAINT_MODE = new DMMaintMode(null);
  public static final LineStyle LINE_STYLE = new LineStyle(null);
  public static final DMState DM_STATE = new DMState(null);
  public static final DMDirection DM_DIRECTION = new DMDirection(null);
  public static final DMPurpose DM_PURPOSE = new DMPurpose(null);
  public static final DuctSegDirection DUCTSEG_DIRECTION = new DuctSegDirection();
  public static final DuctSegSpec DUCTSEG_SPEC = new DuctSegSpec();

  public static final DMPoleKind DM_POLE_KIND = new DMPoleKind(null);
  public static final DMPoleType DM_POLE_TYPE = new DMPoleType(null);
  public static final ManhleKind MANHLE_KIND = new ManhleKind();
  public static final ManhleModel MANHLE_MODEL = new ManhleModel();
  public static final ManhleSpec MANHLE_SPEC = new ManhleSpec();
  public static final ManhleStruct MANHLE_STRUCT = new ManhleStruct();
  public static final ManhleType MANHLE_TYPE = new ManhleType();
  public static final WrType WDM_RATE_TYPE = new WrType();

  public static final CabType CAB_TYPE = new CabType();
  public static final DpType DP_TYPE = new DpType();
  public static final DMPoleHighType POLE_HIGH_TYPE = new DMPoleHighType();
  public static final DMMapLayerCfgType MAP_LAYER_CFG_TYPE = new DMMapLayerCfgType();
  public static final DMFBoxKindType FBox_Kind_Type = new DMFBoxKindType();
  public static final IconInfType ICONINF_TYPE = new IconInfType(null);
  public static final LabelCNShowType LABELCN_SHOW_TYPE = new LabelCNShowType();
  public static final DMProtectstate DMPROTECT_STATE = new DMProtectstate();

  public static final DMPullLineType DM_PULL_LINE_TYPE = new DMPullLineType();
  public static final DMRingDia DM_RING_DIA = new DMRingDia();
  public static final DMPlywoodType DM_PLYWOOD_TYPE = new DMPlywoodType();
  public static final DMStoneType DM_STONE_TYPE = new DMStoneType();
  public static final DMCabOwnerShip DM_CAB_OWNER_SHIP = new DMCabOwnerShip();
  public static final DMServiceState DM_SERVICE_STATE = new DMServiceState();
  public static final DMConnecrType DM_CONNECR_TYPE = new DMConnecrType();
  public static final DMJunctionType DM_JUNCTION_TYPE = new DMJunctionType();
  public static final DMSIGNALDIRECTION DM_SIGNAL_DIRECTION = new DMSIGNALDIRECTION(null);
  public static final DMSUSAGESTATE DM_SUSAGE_STATE = new DMSUSAGESTATE(null);
  public static final DMFIBERLEVEL DM_FIBER_LEVEL = new DMFIBERLEVEL(null);
  public static final HoleType DM_DUCTHOLE_TYPE = new HoleType(null);
  public static final ChildHoleState DM_CHILDHOLE_STATE = new ChildHoleState(null);
  public static final DMPullLineSpec DM_PULLLINE_SPEC = new DMPullLineSpec();
  public static final DMLayType DM_LAYTYPE = new DMLayType(null);

  public static final DMFiberType DM_FIBERTYPE = new DMFiberType(null);
  public static final ManhleDirection MANHLE_DIRECTION = new ManhleDirection();
  public static final PoleType POLE_TYPE = new PoleType();
  public static final DtrectionType DTRECTION_TYPE = new DtrectionType();
  public static final DuctLineType DUCT_LINE_TYPE = new DuctLineType();
  public static final LineCrossType LINE_CROSS_TYPE = new LineCrossType();
  public static final EnumType ENUM_TYPE = new EnumType();

  public static final DuctLineSystemType DUCT_LINE_SYSTEM_TYPE = new DuctLineSystemType();
  public static final AloneSietType ALONE_SITE_TYPE = new AloneSietType();
  public static final SameRouteLevel SAME_ROUTE_LEVEL = new SameRouteLevel();
  public static final SameRouteDescripton SAME_ROUTE_DESCRIPTION = new SameRouteDescripton();
  public static final SameRouteType SAME_ROUTE_TYPE = new SameRouteType();
  public static final DuctSegType DUCT_SEG_TYPE = new DuctSegType();
  public static final DuctOpticalType DUCT_OPTICAL_TYPE = new DuctOpticalType();
  public static final DuctBigOrSmall DUCT_BIG_OR_SMALL = new DuctBigOrSmall();

  public static final DMROOMType DM_ROOM_TYPE = new DMROOMType(null);
  public static final DuctProjectState DUCT_PROJECT_STATE = new DuctProjectState(null);
  public static final MaintType MAINT_TYPE = new MaintType(null);
  public static final MaintState MAINT_STATE = new MaintState(null);
  public static final DuctProjectStateChange PROJECT_STATE_CHANGE = new DuctProjectStateChange(null);
  public static final MaintStateChange MAINT_STATE_CHANGE = new MaintStateChange(null);
  public static final ProjectType PROJECT_TYPE = new ProjectType(null);
  public static final ExtType EXT_TYPE = new ExtType();
  public static final FunctionState FUNCTION_STATE = new FunctionState();
  public static final CessionType CESSION_TYPE = new CessionType();
  public static final SchemeState SCHEME_STATE = new SchemeState();
  public static final CessionLevel CESSION_LEVEL = new CessionLevel();
  public static final WireTroubleState WIRE_TROUBLE_STATE = new WireTroubleState(null);
  public static final TroubleType TROUBLE_TYPE = new TroubleType(null);
  public static final TroubleSystemLevel TROUBLE_SYSTEM_LEVEL = new TroubleSystemLevel(null);

  public static final PDAUseState PDA_USE_STATE = new PDAUseState();
  public static final PointType POINT_TYPE = new PointType();
  public static final TaskTypeEnum TASK_TYPE_ENUM = new TaskTypeEnum();
  public static final TaskStateEnum TASK_STATE_ENUM = new TaskStateEnum();
  public static final PDATaskStateEnum PDA_TASK_STATE_ENUM = new PDATaskStateEnum();
  public static final HiddenTypeEnum HIDDEN_TYPE_ENUM = new HiddenTypeEnum();
  public static final DetailHiddenTypeEnum DETAIL_HIDDEN_TYPE_ENUM = new DetailHiddenTypeEnum();
  public static final ResultStateEnum RESULT_STATE_ENUM = new ResultStateEnum();
  public static final CycleEnum CYCLE_ENUM = new CycleEnum();
  public static final LongiLatiTypeEnum LONGI_LATITYPE_ENUM = new LongiLatiTypeEnum();
  public static final FrequenceTypeEnum FREQUENCE_TYPE_ENUM = new FrequenceTypeEnum();
  public static final DeviceStateEnum DEVICE_STATE_ENUM = new DeviceStateEnum();
  public static final DataStateEnum DATA_STATE_ENUM = new DataStateEnum(null);
  public static final IsYjrPoint IS_YJR_POINT = new IsYjrPoint(null);

  public static final WireCutStateEnum WIRE_CUT_STATE_ENUM = new WireCutStateEnum(null);
  public static final WireCutTypeEnum WIRE_CUT_TYPE_ENUM = new WireCutTypeEnum(null);

  public static final DMSpecialPurpose DM_SPECIAL_PURPOSE_ENUM = new DMSpecialPurpose(null);

  public static final DMWireSegOlevel DM_WIRE_SEG_OLEVEL_ENUM = new DMWireSegOlevel(null);

  public static final InterruptPointEnum INTERRUP_POINT_ENUM = new InterruptPointEnum(null);
  public static final AbnormalEnum ABNORMAL_ENUM = new AbnormalEnum(null);
  public static final String DUCTSECTIONASSISPIC = "DUCTSECTIONASSISPIC";

  public static class AbnormalEnum extends GenericEnum
  {
    public static final long _noabnormal = 0L;
    public static final long _abnormal = 1L;

    private AbnormalEnum()
    {
      super.putEnum(Long.valueOf(0L), "否");
      super.putEnum(Long.valueOf(1L), "是");
    }
  }

  public static class InterruptPointEnum extends GenericEnum
  {
    public static final long _isnothave = 0L;
    public static final long _ishave = 1L;

    private InterruptPointEnum()
    {
      super.putEnum(Long.valueOf(0L), "无");
      super.putEnum(Long.valueOf(1L), "有");
    }
  }

  public static class DMWireSegOlevel extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _wirelevelone = 1L;
    public static final long _wireleveltwo = 2L;
    public static final long _locallevelbone = 3L;
    public static final long _localleveltwo = 4L;
    public static final long _locallevelthree = 5L;
    public static final long _goldmedal = 6L;
    public static final long _silvermedal = 7L;
    public static final long _coppermedal = 8L;
    public static final long _normal = 9L;

    private DMWireSegOlevel()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "一干");
      super.putEnum(Long.valueOf(2L), "二干");
      super.putEnum(Long.valueOf(3L), "本地一级");
      super.putEnum(Long.valueOf(4L), "本地二级");
      super.putEnum(Long.valueOf(5L), "本地三级");
      super.putEnum(Long.valueOf(6L), "金牌");
      super.putEnum(Long.valueOf(7L), "银牌");
      super.putEnum(Long.valueOf(8L), "铜牌");
      super.putEnum(Long.valueOf(9L), "标准");
    }
  }

  public static class DMSpecialPurpose extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _group = 1L;
    public static final long _family = 2L;
    public static final long _groupandfamily = 3L;

    private DMSpecialPurpose()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "集客");
      super.putEnum(Long.valueOf(2L), "家客");
      super.putEnum(Long.valueOf(3L), "集客家客");
    }
  }

  public static class DMTraphRateEnum extends GenericEnum
  {
    public static final int _16S = 16;

    private DMTraphRateEnum()
    {
      super.putEnum(Integer.valueOf(16), "16S");
    }
  }

  public static class IsYjrPoint extends GenericEnum
  {
    public static final long _isnotyjr = 0L;
    public static final long _isyjr = 1L;

    private IsYjrPoint()
    {
      super.putEnum(Long.valueOf(0L), "否");
      super.putEnum(Long.valueOf(1L), "是");
    }
  }

  public static class WireCutTypeEnum extends GenericEnum
  {
    public static final long _finishcut = 1L;
    public static final long _middlesegcut = 2L;

    private WireCutTypeEnum()
    {
      super.putEnum(Long.valueOf(1L), "光缆成端割接");
      super.putEnum(Long.valueOf(2L), "中间光缆段割接");
    }
  }

  public static class WireCutStateEnum extends GenericEnum
  {
    public static final long _new = 1L;
    public static final long _schemedesign = 2L;
    public static final long _cutsuccess = 3L;
    public static final long _cutfail = 4L;

    private WireCutStateEnum()
    {
      super.putEnum(Long.valueOf(1L), "新建");
      super.putEnum(Long.valueOf(2L), "方案设计");
      super.putEnum(Long.valueOf(3L), "割接成功");
      super.putEnum(Long.valueOf(4L), "割接失败");
    }
  }

  public static class DataStateEnum extends GenericEnum
  {
    public static final long _right = 0L;
    public static final long _wrong = 1L;

    private DataStateEnum()
    {
      super.putEnum(Long.valueOf(0L), "无问题数据");
      super.putEnum(Long.valueOf(1L), "有问题数据");
    }
  }

  public static class DeviceStateEnum extends GenericEnum
  {
    public static final long _unkown = 0L;
    public static final long _useable = 1L;
    public static final long _onuseable = 2L;

    protected DeviceStateEnum()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "可用");
      super.putEnum(Long.valueOf(2L), "不可用");
    }
  }

  public static class FrequenceTypeEnum extends GenericEnum
  {
    public static final long _week = 1L;
    public static final long _month = 2L;

    protected FrequenceTypeEnum()
    {
      super.putEnum(Long.valueOf(1L), "周");
      super.putEnum(Long.valueOf(2L), "月");
    }
  }

  public static class LongiLatiTypeEnum extends GenericEnum
  {
    public static final long _oldxy = 1L;
    public static final long _newxy = 2L;

    protected LongiLatiTypeEnum()
    {
      super.putEnum(Long.valueOf(1L), "原经纬度");
      super.putEnum(Long.valueOf(2L), "修改经纬度");
    }
  }

  public static class CycleEnum extends GenericEnum
  {
    public static final long _yes = 1L;
    public static final long _no = 0L;

    protected CycleEnum()
    {
      super.putEnum(Long.valueOf(1L), "是");
      super.putEnum(Long.valueOf(0L), "否");
    }
  }

  public static class ResultStateEnum extends GenericEnum
  {
    public static final long _done = 1L;
    public static final long _nodone = 0L;

    protected ResultStateEnum()
    {
      super.putEnum(Long.valueOf(1L), "完成");
      super.putEnum(Long.valueOf(0L), "未完成");
    }
  }

  public static class DetailHiddenTypeEnum extends GenericEnum
  {
    public static final long _shigongtafang = 11L;
    public static final long _xianlutafang = 12L;
    public static final long _qiangxiuyiliu = 13L;
    public static final long _xianluguohegou = 14L;
    public static final long _jingsunhuai = 21L;
    public static final long _jingbeimai = 22L;
    public static final long _biaoshibeimai = 31L;
    public static final long _biaosunhuai = 32L;
    public static final long _biaoshibuqingchu = 33L;
    public static final long _diangansunhuai = 41L;
    public static final long _xianlubeijiya = 42L;
    public static final long _xianlubuhege = 43L;
    public static final long _dianganbianhaobuqingchu = 44L;

    protected DetailHiddenTypeEnum()
    {
      super.putEnum(Long.valueOf(11L), "施工隐患");
      super.putEnum(Long.valueOf(12L), "线路塌方或下陷");
      super.putEnum(Long.valueOf(13L), "抢修后遗留隐患");
      super.putEnum(Long.valueOf(14L), "线路过河沟处隐患");
      super.putEnum(Long.valueOf(21L), "管道人手井损坏或丢失");
      super.putEnum(Long.valueOf(22L), "管道人手井被埋");
      super.putEnum(Long.valueOf(31L), "直埋标石被埋");
      super.putEnum(Long.valueOf(32L), "直埋标石损坏或丢失");
      super.putEnum(Long.valueOf(33L), "直埋标石编号不清楚");
      super.putEnum(Long.valueOf(41L), "架空电杆损坏或歪斜");
      super.putEnum(Long.valueOf(42L), "架空线路被异物挤压");
      super.putEnum(Long.valueOf(43L), "架空线路的三线交越不合格");
      super.putEnum(Long.valueOf(44L), "架空电杆编号不清楚");
    }
  }

  public static class HiddenTypeEnum extends GenericEnum
  {
    public static final long _common_trouble = 1L;
    public static final long _duct_trouble = 2L;
    public static final long _stone_trouble = 3L;
    public static final long _pole_trouble = 4L;

    protected HiddenTypeEnum()
    {
      super.putEnum(Long.valueOf(1L), "线路公共隐患");
      super.putEnum(Long.valueOf(2L), "管道隐患");
      super.putEnum(Long.valueOf(3L), "直埋隐患");
      super.putEnum(Long.valueOf(4L), "架空隐患");
    }
  }

  public static class PDATaskStateEnum extends GenericEnum
  {
    public static final long _noaccept = 0L;
    public static final long _accept = 1L;
    public static final long _doing = 2L;
    public static final long _complete = 3L;

    protected PDATaskStateEnum()
    {
      super.putEnum(Long.valueOf(0L), "未接受");
      super.putEnum(Long.valueOf(1L), "接受");
      super.putEnum(Long.valueOf(2L), "正在处理");
      super.putEnum(Long.valueOf(3L), "完成");
    }
  }

  public static class TaskStateEnum extends GenericEnum
  {
    public static final long _start = 1L;
    public static final long _nostart = 0L;
    public static final long _end = 2L;

    protected TaskStateEnum()
    {
      super.putEnum(Long.valueOf(1L), "开始");
      super.putEnum(Long.valueOf(0L), "未开始");
      super.putEnum(Long.valueOf(2L), "结束");
    }
  }

  public static class TaskTypeEnum extends GenericEnum
  {
    public static final long _inspect = 1L;
    public static final long _newtask = 2L;
    public static final long _trouble = 3L;
    public static final long _cutover = 4L;

    protected TaskTypeEnum()
    {
      super.putEnum(Long.valueOf(1L), "巡线任务");
      super.putEnum(Long.valueOf(2L), "新建任务");
      super.putEnum(Long.valueOf(3L), "故障任务");
      super.putEnum(Long.valueOf(4L), "割接任务");
    }
  }

  public static class PointType extends GenericEnum
  {
    public static final long _site = 1L;
    public static final long _manhle = 2L;
    public static final long _pole = 3L;
    public static final long _stone = 4L;
    public static final long _inflexion = 5L;
    public static final long _fibercab = 6L;
    public static final long _fiberdp = 7L;
    public static final long _jointbox = 8L;
    public static final long _accesspoint = 9L;

    protected PointType()
    {
      super.putEnum(Long.valueOf(1L), "站点");
      super.putEnum(Long.valueOf(2L), "人井");
      super.putEnum(Long.valueOf(3L), "电杆");
      super.putEnum(Long.valueOf(4L), "标石");
      super.putEnum(Long.valueOf(5L), "拐点");
      super.putEnum(Long.valueOf(6L), "交接箱");
      super.putEnum(Long.valueOf(7L), "分纤箱");
      super.putEnum(Long.valueOf(8L), "接头盒");
      super.putEnum(Long.valueOf(9L), "接入点");
    }
  }

  public static class PDAUseState extends GenericEnum
  {
    public static final long _able = 1L;
    public static final long _unable = 2L;
    public static final long _unknown = 3L;

    protected PDAUseState()
    {
      super.putEnum(Long.valueOf(1L), "可用");
      super.putEnum(Long.valueOf(2L), "不可用");
      super.putEnum(Long.valueOf(3L), "未知");
    }
  }

  public static class TroubleSystemLevel extends GenericEnum<Object>
  {
    public static final long _interprovincial = 1L;
    public static final long _localprovince = 2L;
    public static final long _localbackbone = 3L;
    public static final long _localpool = 4L;
    public static final long _localconnect = 5L;

    private TroubleSystemLevel()
    {
      super.putEnum(Long.valueOf(1L), "省际");
      super.putEnum(Long.valueOf(2L), "省内");
      super.putEnum(Long.valueOf(3L), "本地骨干");
      super.putEnum(Long.valueOf(4L), "本地汇聚");
      super.putEnum(Long.valueOf(5L), "本地接入");
    }
  }

  public static class TroubleType extends GenericEnum<Object>
  {
    public static final long _danger = 1L;
    public static final long _construct = 2L;
    public static final long _unstable = 3L;

    private TroubleType()
    {
      super.putEnum(Long.valueOf(1L), "危险路段");
      super.putEnum(Long.valueOf(2L), "施工路段");
      super.putEnum(Long.valueOf(3L), "险情未稳定路段");
    }
  }

  public static class WireTroubleState extends GenericEnum<Object>
  {
    public static final long _valid = 1L;
    public static final long _expire = 2L;

    private WireTroubleState()
    {
      super.putEnum(Long.valueOf(1L), "有效");
      super.putEnum(Long.valueOf(2L), "过期");
    }
  }

  public static class CessionLevel extends GenericEnum
  {
    public static final long _local = 0L;
    public static final long _province = 1L;

    protected CessionLevel()
    {
      super.putEnum(Long.valueOf(0L), "本地");
      super.putEnum(Long.valueOf(1L), "二干");
    }
  }

  public static class SchemeState extends GenericEnum
  {
    public static final long _apply = 1L;
    public static final long _examinesucc = 2L;
    public static final long _examinefail = 3L;
    public static final long _projectset = 4L;
    public static final long _feedback = 5L;
    public static final long _verifysucc = 6L;
    public static final long _verifyfail = 7L;
    public static final long _finish = 8L;

    protected SchemeState()
    {
      super.putEnum(Long.valueOf(1L), "申请");
      super.putEnum(Long.valueOf(2L), "审批通过");
      super.putEnum(Long.valueOf(3L), "审批不通过");
      super.putEnum(Long.valueOf(4L), "工程态设置");
      super.putEnum(Long.valueOf(5L), "割接反馈");
      super.putEnum(Long.valueOf(6L), "审核通过");
      super.putEnum(Long.valueOf(7L), "审核不通过");
      super.putEnum(Long.valueOf(8L), "归档");
    }
  }

  public static class CessionType extends GenericEnum
  {
    public static final long _project = 0L;
    public static final long _maint = 1L;

    protected CessionType()
    {
      super.putEnum(Long.valueOf(0L), "工程割接");
      super.putEnum(Long.valueOf(1L), "维护割接");
    }
  }

  public static class FunctionState extends GenericEnum
  {
    public static final long _use = 1L;
    public static final long _bad = 2L;

    protected FunctionState()
    {
      super.putEnum(Long.valueOf(1L), "可用");
      super.putEnum(Long.valueOf(2L), "坏纤");
    }
  }

  public static class ExtType extends GenericEnum
  {
    public static final long _ordinary = 1L;
    public static final long _transystem = 2L;
    public static final long _opticalrent = 3L;

    protected ExtType()
    {
      super.putEnum(Long.valueOf(1L), "普通业务");
      super.putEnum(Long.valueOf(2L), "传输系统");
      super.putEnum(Long.valueOf(3L), "光纤出租");
    }
  }

  public static class OpticalNum extends GenericEnum
  {
    public static final long _one = 1L;
    public static final long _two = 2L;

    protected OpticalNum()
    {
      super.putEnum(Long.valueOf(1L), "1芯");
      super.putEnum(Long.valueOf(2L), "2芯");
    }
  }

  public static class ProjectType extends GenericEnum
  {
    public static final long _ductline = 1L;
    public static final long _poleway = 2L;
    public static final long _stoneway = 3L;
    public static final long _wire = 4L;

    private ProjectType()
    {
      super.putEnum(Long.valueOf(1L), "管道工程");
      super.putEnum(Long.valueOf(2L), "杆路工程");
      super.putEnum(Long.valueOf(3L), "直埋工程");
      super.putEnum(Long.valueOf(4L), "光缆工程");
    }
  }

  public static class MaintStateChange extends GenericEnum
  {
    public static final long _working = 1L;
    public static final long _workingtowaiting = 2L;
    public static final long _waitingtofinish = 3L;
    public static final long _waitingtoworking = 4L;
    public static final long _waitingconfirm = 5L;
    public static final long _finish = 6L;
    public static final long _workingtofinish = 7L;

    private MaintStateChange()
    {
      super.putEnum(Long.valueOf(1L), "作业中");
      super.putEnum(Long.valueOf(2L), "作业中->待确认");
      super.putEnum(Long.valueOf(3L), "待确认->完成");
      super.putEnum(Long.valueOf(4L), "待确认->作业中");
      super.putEnum(Long.valueOf(5L), "待确认");
      super.putEnum(Long.valueOf(6L), "完成");
      super.putEnum(Long.valueOf(7L), "作业中->完成");
    }
  }

  public static class DuctProjectStateChange extends GenericEnum
  {
    public static final long _build = 1L;
    public static final long _buildtowaiting = 2L;
    public static final long _waitingtomaint = 3L;
    public static final long _waitingtobuild = 4L;
    public static final long _waitingmaint = 5L;
    public static final long _maint = 6L;
    public static final long _buildtomaint = 7L;

    private DuctProjectStateChange()
    {
      super.putEnum(Long.valueOf(1L), "竣工");
      super.putEnum(Long.valueOf(2L), "竣工->待维护");
      super.putEnum(Long.valueOf(3L), "待维护->维护");
      super.putEnum(Long.valueOf(4L), "待维护->竣工");
      super.putEnum(Long.valueOf(5L), "待维护");
      super.putEnum(Long.valueOf(6L), "维护");
      super.putEnum(Long.valueOf(7L), "竣工->维护");
    }
  }

  public static class MaintState extends GenericEnum
  {
    public static final long _working = 1L;
    public static final long _waitingconfirm = 2L;
    public static final long _finish = 3L;

    private MaintState()
    {
      super.putEnum(Long.valueOf(1L), "作业中");
      super.putEnum(Long.valueOf(2L), "待确认");
      super.putEnum(Long.valueOf(3L), "完成");
    }
  }

  public static class MaintType extends GenericEnum
  {
    public static final long _daily = 1L;
    public static final long _emergency = 2L;
    public static final long _change = 3L;

    private MaintType()
    {
      super.putEnum(Long.valueOf(1L), "日常维护");
      super.putEnum(Long.valueOf(2L), "应急抢修");
      super.putEnum(Long.valueOf(3L), "维修改迁");
    }
  }

  public static class DuctProjectState extends GenericEnum
  {
    public static final long _build = 1L;
    public static final long _waitingmaint = 2L;
    public static final long _maint = 3L;

    private DuctProjectState()
    {
      super.putEnum(Long.valueOf(1L), "竣工");
      super.putEnum(Long.valueOf(2L), "待维护");
      super.putEnum(Long.valueOf(3L), "维护");
    }
  }

  public static class DuctBigOrSmall extends GenericEnum
  {
    public static final long _big = 1L;
    public static final long _small = 2L;

    protected DuctBigOrSmall()
    {
      super.putEnum(Long.valueOf(1L), "大于等于");
      super.putEnum(Long.valueOf(2L), "小于等于");
    }
  }

  public static class DuctOpticalType extends GenericEnum
  {
    public static final long _1310 = 1L;
    public static final long _1550 = 2L;

    protected DuctOpticalType()
    {
      super.putEnum(Long.valueOf(1L), "1310");
      super.putEnum(Long.valueOf(2L), "1550");
    }
  }

  public static class DuctSegType extends GenericEnum
  {
    public static final long _duct = 1L;
    public static final long _slotduct = 2L;

    protected DuctSegType()
    {
      super.putEnum(Long.valueOf(1L), "管道");
      super.putEnum(Long.valueOf(2L), "槽道");
    }
  }

  public static class SameRouteType extends GenericEnum
  {
    public static final long _duct = 0L;
    public static final long _wire = 1L;

    protected SameRouteType()
    {
      super.putEnum(Long.valueOf(0L), "管道同路由");
      super.putEnum(Long.valueOf(1L), "光缆同路由");
    }
  }

  public static class SameRouteDescripton extends GenericEnum
  {
    public static final long _des1 = 1L;
    public static final long _des2 = 2L;
    public static final long _des3 = 3L;
    public static final long _des4 = 4L;
    public static final long _des5 = 5L;
    public static final long _des6 = 6L;
    public static final long _des7 = 7L;

    protected SameRouteDescripton()
    {
      super.putEnum(Long.valueOf(1L), "传输系统N个不相邻拓扑同路由(N>2)");
      super.putEnum(Long.valueOf(2L), "传输系统N个相邻拓扑局前同路由(N>2)");
      super.putEnum(Long.valueOf(3L), "传输系统N个相邻拓扑同路由(N>2)");
      super.putEnum(Long.valueOf(4L), "传输系统两个不相邻拓扑同路由");
      super.putEnum(Long.valueOf(5L), "传输系统两个相邻拓扑局前同路由");
      super.putEnum(Long.valueOf(6L), "传输系统两个相邻拓扑同路由");
      super.putEnum(Long.valueOf(7L), "传输系统同一拓扑同路由");
    }
  }

  public static class SameRouteLevel extends GenericEnum
  {
    public static final long _ordinary = 1L;
    public static final long _importance = 2L;
    public static final long _emergency = 3L;

    protected SameRouteLevel()
    {
      super.putEnum(Long.valueOf(1L), "一般");
      super.putEnum(Long.valueOf(2L), "重要");
      super.putEnum(Long.valueOf(3L), "紧急");
    }
  }

  public static class EnumType extends GenericEnum
  {
    public static final String _ductsegstuff = "DUCT_SEG_STUFF";

    protected EnumType()
    {
      super.putEnum("DUCT_SEG_STUFF", "管道材质");
    }
  }

  public static class LineCrossType extends GenericEnum
  {
    public static final long _electric = 1L;
    public static final long _tele = 2L;
    public static final long _brocast = 3L;

    protected LineCrossType()
    {
      super.putEnum(Long.valueOf(1L), "电力");
      super.putEnum(Long.valueOf(2L), "电信");
      super.putEnum(Long.valueOf(3L), "广电");
    }
  }

  public static class DMProtectstate extends GenericEnum
  {
    public static final long _maplayercfg1 = 0L;
    public static final long _maplabelshowtype2 = 1L;
    public static final long _maplabelshowtype3 = 2L;
    public static final long _maplabelshowtype4 = 3L;
    public static final long _maplabelshowtype5 = 4L;
    public static final long _maplabelshowtype6 = 5L;
    public static final long _maplabelshowtype7 = 6L;
    public static final long _maplabelshowtype8 = 7L;
    public static final long _maplabelshowtype9 = 8L;

    protected DMProtectstate()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "PUC管保护");
      super.putEnum(Long.valueOf(2L), "混凝土保护");
      super.putEnum(Long.valueOf(3L), "堵塞保护");
      super.putEnum(Long.valueOf(4L), "护坡保护");
      super.putEnum(Long.valueOf(5L), "护坎保护");
      super.putEnum(Long.valueOf(6L), "防水墙保护");
      super.putEnum(Long.valueOf(7L), "钢管保护");
      super.putEnum(Long.valueOf(8L), "竖砖保护");
    }
  }

  public static class AloneSietType extends GenericEnum
  {
    public static final long _wiresystem = 1L;
    public static final long _ductsystem = 2L;

    protected AloneSietType()
    {
      super.putEnum(Long.valueOf(1L), "未接入光缆站点");
      super.putEnum(Long.valueOf(2L), "未接入管线站点");
    }
  }

  public static class DuctLineSystemType extends GenericEnum
  {
    public static final long _wiresystem = 1L;
    public static final long _ductsystem = 2L;
    public static final long _microwave = 3L;
    public static final long _polewaysystem = 4L;
    public static final long _stonewaysystem = 5L;
    public static final long _uplinesystem = 6L;
    public static final long _hangwallsystem = 7L;

    protected DuctLineSystemType()
    {
      super.putEnum(Long.valueOf(1L), "光缆系统");
      super.putEnum(Long.valueOf(2L), "管道系统");
      super.putEnum(Long.valueOf(3L), "微波系统");
      super.putEnum(Long.valueOf(4L), "杆路系统");
      super.putEnum(Long.valueOf(5L), "标石系统");
      super.putEnum(Long.valueOf(6L), "引上系统");
      super.putEnum(Long.valueOf(7L), "挂墙系统");
    }
  }

  public static class DuctLineType extends GenericEnum
  {
    public static final long _ductseg = 1L;
    public static final long _ducthole = 2L;
    public static final long _childhole = 3L;
    public static final long _polewayseg = 4L;
    public static final long _carryingcable = 5L;
    public static final long _stonewayseg = 6L;
    public static final long _uplineseg = 7L;
    public static final long _hangwallseg = 8L;

    protected DuctLineType()
    {
      super.putEnum(Long.valueOf(1L), "管道段");
      super.putEnum(Long.valueOf(2L), "管孔");
      super.putEnum(Long.valueOf(3L), "子孔");
      super.putEnum(Long.valueOf(4L), "杆路段");
      super.putEnum(Long.valueOf(5L), "吊线段");
      super.putEnum(Long.valueOf(6L), "标石路由段");
      super.putEnum(Long.valueOf(7L), "引上段");
      super.putEnum(Long.valueOf(8L), "挂墙段");
    }
  }

  public static class DtrectionType extends GenericEnum
  {
    public static final long _fdtrection = 1L;
    public static final long _rdtrection = 2L;

    protected DtrectionType()
    {
      super.putEnum(Long.valueOf(1L), "正向");
      super.putEnum(Long.valueOf(2L), "反向");
    }
  }

  public static class PoleType extends GenericEnum
  {
    public static final long _1 = 1L;
    public static final long _2 = 2L;
    public static final long _3 = 3L;
    public static final long _4 = 4L;
    public static final long _5 = 5L;
    public static final long _0 = 0L;

    protected PoleType()
    {
      super.putEnum(Long.valueOf(1L), "平杆");
      super.putEnum(Long.valueOf(2L), "抬杆");
      super.putEnum(Long.valueOf(3L), "吊杆");
      super.putEnum(Long.valueOf(4L), "角杆");
      super.putEnum(Long.valueOf(5L), "Π杆");
      super.putEnum(Long.valueOf(0L), "未知");
    }
  }

  public static class WrType extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _1 = 16L;
    public static final long _2 = 17L;
    public static final long _3 = 19L;

    protected WrType()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(16L), "2.5G");
      super.putEnum(Long.valueOf(17L), "10G");
      super.putEnum(Long.valueOf(19L), "40G");
    }
  }

  public static class DMJunctionType extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _zhitong = 1L;
    public static final long _fenqi = 2L;

    protected DMJunctionType()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "直通");
      super.putEnum(Long.valueOf(2L), "分歧");
    }
  }

  public static class DMConnecrType extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _rongjie = 1L;
    public static final long _yajie = 2L;

    protected DMConnecrType()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "熔接");
      super.putEnum(Long.valueOf(2L), "压接");
    }
  }

  public static class DMServiceState extends GenericEnum
  {
    public static final long _empty = 1L;
    public static final long _impropriate = 2L;
    public static final long _destine = 3L;
    public static final long _bad = 4L;

    protected DMServiceState()
    {
      super.putEnum(Long.valueOf(1L), "空闲");
      super.putEnum(Long.valueOf(2L), "占用");
      super.putEnum(Long.valueOf(3L), "预占");
      super.putEnum(Long.valueOf(4L), "坏");
    }
  }

  public static class DMCabOwnerShip extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _self = 1L;
    public static final long _shbu = 2L;
    public static final long _share = 3L;
    public static final long _pull = 4L;
    public static final long _rent = 5L;
    public static final long _buy = 6L;
    public static final long _exch = 7L;

    protected DMCabOwnerShip()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "自建");
      super.putEnum(Long.valueOf(2L), "共建");
      super.putEnum(Long.valueOf(3L), "合建");
      super.putEnum(Long.valueOf(4L), "附挂/附穿");
      super.putEnum(Long.valueOf(5L), "租用");
      super.putEnum(Long.valueOf(6L), "购买");
      super.putEnum(Long.valueOf(7L), "置换");
    }
  }

  public static class DMStoneType extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _general = 1L;
    public static final long _tiein = 2L;
    public static final long _zhixian = 3L;
    public static final long _jietou = 4L;
    public static final long _yuliu = 5L;
    public static final long _zhangai = 6L;
    public static final long _guaijiao = 7L;

    protected DMStoneType()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "普通标石");
      super.putEnum(Long.valueOf(2L), "接头坑");
      super.putEnum(Long.valueOf(3L), "直线");
      super.putEnum(Long.valueOf(4L), "接头");
      super.putEnum(Long.valueOf(5L), "预留");
      super.putEnum(Long.valueOf(6L), "障碍");
      super.putEnum(Long.valueOf(7L), "转角");
    }
  }

  public static class DMPlywoodType extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _3single = 1L;
    public static final long _3double = 2L;
    public static final long _1single = 3L;

    protected DMPlywoodType()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "三眼单槽板");
      super.putEnum(Long.valueOf(2L), "三眼双槽板");
      super.putEnum(Long.valueOf(3L), "单眼单槽板");
    }
  }

  public static class DMRingDia extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _124MM = 1L;
    public static final long _144MM = 2L;
    public static final long _164MM = 3L;
    public static final long _184MM = 4L;
    public static final long _204MM = 5L;
    public static final long _224MM = 6L;
    public static final long _244MM = 7L;

    protected DMRingDia()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "124MM");
      super.putEnum(Long.valueOf(2L), "144MM");
      super.putEnum(Long.valueOf(3L), "164MM");
      super.putEnum(Long.valueOf(4L), "184MM");
      super.putEnum(Long.valueOf(5L), "204MM");
      super.putEnum(Long.valueOf(6L), "224MM");
      super.putEnum(Long.valueOf(7L), "244MM");
    }
  }

  public static class DMPullLineSpec extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _712 = 1L;
    public static final long _716 = 2L;
    public static final long _722 = 3L;
    public static final long _726 = 4L;
    public static final long _730 = 5L;

    protected DMPullLineSpec()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "7/1.2");
      super.putEnum(Long.valueOf(2L), "7/1.6");
      super.putEnum(Long.valueOf(3L), "7/2.2");
      super.putEnum(Long.valueOf(4L), "7/2.6");
      super.putEnum(Long.valueOf(5L), "7/3.0");
    }
  }

  public static class DMPullLineType extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _single = 1L;
    public static final long _double = 2L;
    public static final long _v = 3L;
    public static final long _21v = 4L;
    public static final long _11v = 5L;
    public static final long _high = 6L;
    public static final long _bord = 7L;
    public static final long _wall = 8L;

    protected DMPullLineType()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "单股");
      super.putEnum(Long.valueOf(2L), "双股");
      super.putEnum(Long.valueOf(3L), "V型");
      super.putEnum(Long.valueOf(4L), "上2下1V型");
      super.putEnum(Long.valueOf(5L), "上1下1V型");
      super.putEnum(Long.valueOf(6L), "高桩");
      super.putEnum(Long.valueOf(7L), "吊板");
      super.putEnum(Long.valueOf(8L), "墙拉");
    }
  }

  public static class DMPoleType extends GenericEnum
  {
    public static final long _zero = 0L;
    public static final long _line = 1L;
    public static final long _cary = 2L;
    public static final long _up = 3L;
    public static final long _angle = 4L;
    public static final long _down = 5L;

    private DMPoleType()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "平杆");
      super.putEnum(Long.valueOf(2L), "抬杆");
      super.putEnum(Long.valueOf(3L), "吊杆");
      super.putEnum(Long.valueOf(4L), "角杆");
      super.putEnum(Long.valueOf(5L), "Π杆");
    }
  }

  public static class DMPoleKind extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _commoncement = 1L;
    public static final long _stresscement = 2L;
    public static final long _wooden = 3L;
    public static final long _danjie = 4L;
    public static final long _pinjie = 5L;

    private DMPoleKind()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "普通水泥杆");
      super.putEnum(Long.valueOf(2L), "预应力水泥杆");
      super.putEnum(Long.valueOf(3L), "木制电杆");
      super.putEnum(Long.valueOf(4L), "单接杆");
      super.putEnum(Long.valueOf(5L), "品接杆");
    }
  }

  public static class LabelCNShowType extends GenericEnum
  {
    public static final long _maplabelshowtype2 = 1L;
    public static final long _maplabelshowtype3 = 2L;
    public static final long _maplabelshowtype4 = 3L;

    protected LabelCNShowType()
    {
      super.putEnum(Long.valueOf(1L), "不显示");
      super.putEnum(Long.valueOf(2L), "过滤显示");
      super.putEnum(Long.valueOf(3L), "显示");
    }
  }

  public static class DMMapLayerCfgType extends GenericEnum
  {
    public static final long _maplayercfg2 = 1L;
    public static final long _maplayercfg3 = 2L;
    public static final long _maplayercfg4 = 3L;

    protected DMMapLayerCfgType()
    {
      super.putEnum(Long.valueOf(1L), "线");
      super.putEnum(Long.valueOf(2L), "点");
      super.putEnum(Long.valueOf(3L), "区块");
    }
  }

  public static class DMPoleHighType extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _polehigh1 = 0L;
    public static final long _polehigh2 = 1L;
    public static final long _polehigh3 = 2L;
    public static final long _polehigh4 = 3L;
    public static final long _polehigh5 = 4L;
    public static final long _polehigh6 = 5L;
    public static final long _polehigh7 = 6L;
    public static final long _polehigh8 = 7L;

    protected DMPoleHighType()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(0L), "其他");
      super.putEnum(Long.valueOf(1L), "6M");
      super.putEnum(Long.valueOf(2L), "7M");
      super.putEnum(Long.valueOf(3L), "7.5M");
      super.putEnum(Long.valueOf(4L), "8M");
      super.putEnum(Long.valueOf(5L), "9M");
      super.putEnum(Long.valueOf(6L), "10M");
      super.putEnum(Long.valueOf(7L), "12M");
    }
  }

  public static class DMFBoxKindType extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _fjointboxkindkind1 = 1L;
    public static final long _fjointboxkindkind2 = 2L;

    protected DMFBoxKindType()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "光接头盒");
      super.putEnum(Long.valueOf(2L), "光终端盒");
    }
  }

  public static class DpType extends GenericEnum
  {
    public static final long _cab = 0L;

    protected DpType()
    {
      super.putEnum(Long.valueOf(0L), "未知");
    }
  }

  public static class CabType extends GenericEnum
  {
    public static final long _cab = 0L;

    protected CabType()
    {
      super.putEnum(Long.valueOf(0L), "未知");
    }
  }

  public static class ManhleType extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _manhle = 1L;
    public static final long _handhle = 2L;

    protected ManhleType()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "人井");
      super.putEnum(Long.valueOf(2L), "手井");
    }
  }

  public static class ManhleStruct extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _zhuanhun = 1L;
    public static final long _ganghun = 2L;
    public static final long _zhutie = 3L;
    public static final long _fuhe = 4L;
    public static final long _shuini = 5L;

    protected ManhleStruct()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "砖混");
      super.putEnum(Long.valueOf(2L), "钢混");
      super.putEnum(Long.valueOf(3L), "铸铁");
      super.putEnum(Long.valueOf(4L), "复合");
      super.putEnum(Long.valueOf(5L), "水泥");
    }
  }

  public static class ManhleSpec extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _xlarge = 1L;
    public static final long _large = 2L;
    public static final long _middle = 3L;
    public static final long _small = 4L;

    protected ManhleSpec()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "特大");
      super.putEnum(Long.valueOf(2L), "大");
      super.putEnum(Long.valueOf(3L), "中");
      super.putEnum(Long.valueOf(4L), "小");
    }
  }

  public static class ManhleModel extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _juqian = 1L;
    public static final long _zhitong = 2L;
    public static final long _santong = 3L;
    public static final long _sitong = 4L;
    public static final long _xietong = 5L;
    public static final long _teshu = 6L;
    public static final long _guaiwan = 7L;
    public static final long _shanxing = 8L;
    public static final long _shizi = 9L;

    protected ManhleModel()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "局前");
      super.putEnum(Long.valueOf(2L), "直通");
      super.putEnum(Long.valueOf(3L), "三通");
      super.putEnum(Long.valueOf(4L), "四通");
      super.putEnum(Long.valueOf(5L), "斜通");
      super.putEnum(Long.valueOf(6L), "特殊异型");
      super.putEnum(Long.valueOf(7L), "拐弯型");
      super.putEnum(Long.valueOf(8L), "扇型");
      super.putEnum(Long.valueOf(9L), "十字型");
    }
  }

  public static class ManhleKind extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _upline = 1L;
    public static final long _single = 2L;
    public static final long _double = 3L;
    public static final long _three = 4L;
    public static final long _four = 5L;
    public static final long _channel = 6L;

    protected ManhleKind()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "引上井");
      super.putEnum(Long.valueOf(2L), "单人井");
      super.putEnum(Long.valueOf(3L), "双人井");
      super.putEnum(Long.valueOf(4L), "三人井");
      super.putEnum(Long.valueOf(5L), "四人井");
      super.putEnum(Long.valueOf(6L), "通道");
    }
  }

  public static class DuctSegDirection extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _front = 1L;
    public static final long _back = 2L;
    public static final long _double = 3L;

    protected DuctSegDirection()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "顺序");
      super.putEnum(Long.valueOf(2L), "逆序");
      super.putEnum(Long.valueOf(3L), "双向");
    }
  }

  public static class ManhleDirection extends GenericEnum
  {
    public static final long _east = 1L;
    public static final long _south = 2L;
    public static final long _west = 3L;
    public static final long _north = 4L;
    public static final long _southeast = 5L;
    public static final long _southwest = 6L;
    public static final long _northeast = 7L;
    public static final long _northwest = 8L;
    public static final long _unknown = 9L;

    protected ManhleDirection()
    {
      super.putEnum(Long.valueOf(1L), "东");
      super.putEnum(Long.valueOf(2L), "南");
      super.putEnum(Long.valueOf(3L), "西");
      super.putEnum(Long.valueOf(4L), "北");
      super.putEnum(Long.valueOf(5L), "东南");
      super.putEnum(Long.valueOf(6L), "西南");
      super.putEnum(Long.valueOf(7L), "东北");
      super.putEnum(Long.valueOf(8L), "西北");
      super.putEnum(Long.valueOf(9L), "未确定");
    }
  }

  public static class DuctSegSpec extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _B2 = 1L;
    public static final long _B3 = 2L;
    public static final long _B4 = 3L;
    public static final long _B5 = 4L;
    public static final long _B6 = 5L;
    public static final long _B9 = 6L;
    public static final long _B12 = 7L;
    public static final long _Z12 = 8L;
    public static final long _Z13 = 9L;
    public static final long _tongdao = 10L;

    protected DuctSegSpec()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "B2");
      super.putEnum(Long.valueOf(2L), "B3");
      super.putEnum(Long.valueOf(3L), "B4");
      super.putEnum(Long.valueOf(4L), "B5");
      super.putEnum(Long.valueOf(5L), "B6");
      super.putEnum(Long.valueOf(6L), "B9");
      super.putEnum(Long.valueOf(7L), "B12");
      super.putEnum(Long.valueOf(8L), "Z12");
      super.putEnum(Long.valueOf(9L), "Z13");
      super.putEnum(Long.valueOf(10L), "通道");
    }
  }

  public static class ChildHoleState extends GenericEnum
  {
    public static final long _free = 1L;
    public static final long _use = 2L;
    public static final long _bad = 3L;
    public static final long _advance = 4L;

    private ChildHoleState()
    {
      super.putEnum(Long.valueOf(1L), "未用");
      super.putEnum(Long.valueOf(2L), "占用");
      super.putEnum(Long.valueOf(3L), "坏孔");
      super.putEnum(Long.valueOf(4L), "预占");
    }
  }

  public static class HoleType extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _round = 1L;
    public static final long _square = 2L;

    private HoleType()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "圆孔");
      super.putEnum(Long.valueOf(2L), "方孔");
    }
  }

  public static class DMPurpose extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _selfuse = 1L;
    public static final long _hire = 2L;
    public static final long _alluse = 3L;
    public static final long _shareuse = 4L;

    private DMPurpose()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "自用");
      super.putEnum(Long.valueOf(2L), "出租");
      super.putEnum(Long.valueOf(3L), "共享");
      super.putEnum(Long.valueOf(4L), "共享我方资源");
    }
  }

  public static class DMDirection extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _unknown = 0L;
    public static final long _backorder = 1L;
    public static final long _unilateralism = 2L;

    private DMDirection()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "单向");
      super.putEnum(Long.valueOf(2L), "双向");
    }
  }

  public static class DMState extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _design = 1L;
    public static final long _building = 2L;
    public static final long _finish = 3L;
    public static final long _abandon = 4L;
    public static final long _maintenance = 5L;
    public static final long _planning = 6L;
    public static final long _firstleveldesign = 7L;

    private DMState()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "设计");
      super.putEnum(Long.valueOf(2L), "在建");
      super.putEnum(Long.valueOf(3L), "竣工");
      super.putEnum(Long.valueOf(4L), "废弃");
      super.putEnum(Long.valueOf(5L), "维护");
      super.putEnum(Long.valueOf(6L), "规划");
      super.putEnum(Long.valueOf(7L), "一级设计");
    }
  }

  public static class DMMaintMode extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _selfservice = 1L;
    public static final long _agentservice = 2L;

    private DMMaintMode()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "自维");
      super.putEnum(Long.valueOf(2L), "代维");
    }
  }

  public static class LineStyle extends GenericEnum
  {
    public static final long _solid = 1L;
    public static final long _dash = 2L;
    public static final long _chain = 3L;
    public static final long _dot = 4L;
    public static final long _zigzag = 5L;
    public static final long _broken = 6L;

    private LineStyle()
    {
      super.putEnum(Long.valueOf(1L), "solid");
      super.putEnum(Long.valueOf(2L), "dash");
      super.putEnum(Long.valueOf(3L), "chain");
      super.putEnum(Long.valueOf(4L), "dot");
      super.putEnum(Long.valueOf(5L), "zigzag");
      super.putEnum(Long.valueOf(6L), "broken");
    }
  }

  public static class DMSystemLevel extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _interprovincial = 1L;
    public static final long _localprovince = 2L;
    public static final long _localbackbone = 3L;
    public static final long _localpool = 4L;
    public static final long _localconnect = 5L;

    private DMSystemLevel()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "省际");
      super.putEnum(Long.valueOf(2L), "省内");
      super.putEnum(Long.valueOf(3L), "本地骨干");
      super.putEnum(Long.valueOf(4L), "本地汇聚");
      super.putEnum(Long.valueOf(5L), "本地接入");
    }
  }

  public static class DMSystemType extends GenericEnum
  {
    public static final long _wiresystem = 1L;
    public static final long _ductsystem = 2L;
    public static final long _polewaysystem = 3L;
    public static final long _stonewaysystem = 4L;
    public static final long _upLine = 5L;
    public static final long _hangwall = 6L;
    public static final long _microwavesystem = 7L;
    public static final long _slotDuctsystem = 8L;

    private DMSystemType()
    {
      super.putEnum(Long.valueOf(1L), "WireSystem");
      super.putEnum(Long.valueOf(2L), "DuctSystem");
      super.putEnum(Long.valueOf(3L), "PolewaySystem");
      super.putEnum(Long.valueOf(4L), "StonewaySystem");
      super.putEnum(Long.valueOf(5L), "UpLine");
      super.putEnum(Long.valueOf(6L), "HangWall");
      super.putEnum(Long.valueOf(7L), "MicrowaveSystem");
      super.putEnum(Long.valueOf(8L), "SLOT_DUCT_SYSTEM");
    }
  }

  public static class DMFIBERLEVEL extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _inte = 1L;
    public static final long _prise = 2L;
    public static final long _local = 3L;
    public static final long _local2 = 4L;
    public static final long _local3 = 5L;

    private DMFIBERLEVEL()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "省际");
      super.putEnum(Long.valueOf(2L), "省内");
      super.putEnum(Long.valueOf(3L), "本地骨干");
      super.putEnum(Long.valueOf(4L), "本地汇聚");
      super.putEnum(Long.valueOf(5L), "本地接入");
    }
  }

  public static class DMSUSAGESTATE extends GenericEnum
  {
    public static final long _no = 1L;
    public static final long _use = 2L;
    public static final long _preuse = 3L;
    public static final long _bad = 4L;
    public static final long _notuse = 5L;

    private DMSUSAGESTATE()
    {
      super.putEnum(Long.valueOf(1L), "未用");
      super.putEnum(Long.valueOf(2L), "在用");
      super.putEnum(Long.valueOf(3L), "预占");
      super.putEnum(Long.valueOf(4L), "坏纤");
      super.putEnum(Long.valueOf(5L), "不可用纤");
    }
  }

  public static class DMWireSegType extends GenericEnum
  {
    public static final long _core = 1L;
    public static final long _accesspoint = 2L;

    private DMWireSegType()
    {
      super.putEnum(Long.valueOf(1L), "核心网");
      super.putEnum(Long.valueOf(2L), "接入网");
    }
  }

  public static class DMFiberType extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _gfive = 1L;
    public static final long _gtwo = 2L;
    public static final long _gseven = 3L;

    private DMFiberType()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "G.652");
      super.putEnum(Long.valueOf(2L), "G.655");
      super.putEnum(Long.valueOf(3L), "G.657");
    }
  }

  public static class DMLayType extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _duct = 1L;
    public static final long _poleway = 2L;
    public static final long _stoneway = 3L;
    public static final long _muti = 4L;
    public static final long _undersea = 5L;
    public static final long _special = 6L;

    private DMLayType()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "管道");
      super.putEnum(Long.valueOf(2L), "架空");
      super.putEnum(Long.valueOf(3L), "直埋");
      super.putEnum(Long.valueOf(4L), "混合");
      super.putEnum(Long.valueOf(5L), "海缆");
      super.putEnum(Long.valueOf(6L), "特种");
    }
  }

  public static class DMSIGNALDIRECTION extends GenericEnum
  {
    public static final long _no = 1L;
    public static final long _left = 2L;
    public static final long _right = 3L;
    public static final long _full = 4L;

    private DMSIGNALDIRECTION()
    {
      super.putEnum(Long.valueOf(1L), "无");
      super.putEnum(Long.valueOf(2L), "左向");
      super.putEnum(Long.valueOf(3L), "右向");
      super.putEnum(Long.valueOf(4L), "双向");
    }
  }

  public static class IconInfType extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _dis = 1L;
    public static final long _tools = 2L;
    public static final long _topo = 3L;
    public static final long _draw = 4L;
    public static final long _line = 5L;

    private IconInfType()
    {
      super.putEnum(Long.valueOf(1L), "区域");
      super.putEnum(Long.valueOf(2L), "工具箱");
      super.putEnum(Long.valueOf(3L), "拓扑");
      super.putEnum(Long.valueOf(4L), "画图");
      super.putEnum(Long.valueOf(5L), "管线");
    }
  }

  public static class DMOpticalway extends GenericEnum
  {
    public static final long _externalnetwork = 1L;
    public static final long _intranet = 2L;
    public static final long _confidentialnetwork = 3L;
    public static final long _egovernmentextranet = 4L;
    public static final long _hire = 5L;

    private DMOpticalway()
    {
      super.putEnum(Long.valueOf(1L), "外网(互联网)");
      super.putEnum(Long.valueOf(2L), "内网");
      super.putEnum(Long.valueOf(3L), "机要网");
      super.putEnum(Long.valueOf(4L), "电子政务外网");
      super.putEnum(Long.valueOf(5L), "租用");
    }
  }

  public static class DMOwnerShip extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _self = 1L;
    public static final long _shbu = 2L;
    public static final long _share = 3L;
    public static final long _pull = 4L;
    public static final long _rent = 5L;
    public static final long _buy = 6L;
    public static final long _exch = 7L;

    private DMOwnerShip()
    {
      super.putEnum(Long.valueOf(0L), "未知");
      super.putEnum(Long.valueOf(1L), "自建");
      super.putEnum(Long.valueOf(2L), "共建");
      super.putEnum(Long.valueOf(3L), "合建");
      super.putEnum(Long.valueOf(4L), "附挂/附穿");
      super.putEnum(Long.valueOf(5L), "租用");
      super.putEnum(Long.valueOf(6L), "购买");
      super.putEnum(Long.valueOf(7L), "置换");
    }
  }

  public static class DMROOMType extends GenericEnum
  {
    public static final long _unknow = 0L;
    public static final long _self = 1L;
    public static final long _shbu = 2L;
    public static final long _share = 3L;
    public static final long _pull = 4L;

    private DMROOMType()
    {
      super.putEnum(Long.valueOf(0L), "电杆");
      super.putEnum(Long.valueOf(1L), "人井");
      super.putEnum(Long.valueOf(2L), "标石");
      super.putEnum(Long.valueOf(3L), "拐点");
      super.putEnum(Long.valueOf(4L), "机房");
    }
  }
}