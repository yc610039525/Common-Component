package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class WorkflowEnum
{
  public static final AttempType ATTEMP_TYPE_CH = new AttempType(null);
  public static final AttempTypeSH ATTEMP_TYPE_SH = new AttempTypeSH(null);
  public static final AutoDispachType AUTO_DISPACH_TYPE = new AutoDispachType(null);
  public static final AttempResultTypeSH ATTEMP_RESULT_TYPE_SH = new AttempResultTypeSH(null);
  public static final UrgentGrade URGENT_GRADE = new UrgentGrade(null);
  public static final SignType SIGN_TYPE_CH = new SignType(null);
  public static final ReplyState REPLY_STATE_CH = new ReplyState(null);
  public static final SheetType DD_ALL_SHEET_TYPE_CH = new SheetType(null);
  public static final AttempResult ATTEMP_RESULT_CH = new AttempResult(null);
  public static final WriteResult WRITE_RESULT_CH = new WriteResult(null);
  public static final SheetArchive SHEET_ARCHIVE = new SheetArchive(null);
  public static final ServiceComplete SERVICE_COMPLETE = new ServiceComplete(null);
  public static final SheetType SHEET_TYPE_CH = new SheetType(null);
  public static final AttempStatRole ATTEMP_STAT_ROLE = new AttempStatRole();

  public static final BusinessType BUSINESS_TYPE_CH = new BusinessType(null);
  public static final JustType JUST = new JustType(null);
  public static final HandlerType HANDLER_TYPE = new HandlerType(null);
  public static final AdjustState ADJUST_STATE = new AdjustState(null);
  public static final ProcessId processId = new ProcessId(null);
  public static final ProcessIdCH processType = new ProcessIdCH(null);
  public static final RoleIdCH roleId = new RoleIdCH(null);
  public static final RoleId role = new RoleId(null);
  public static final NetcomReplyState netcomReplyState = new NetcomReplyState(null);
  public static final ProcessIdCHWorkflow processIdChWorkflow = new ProcessIdCHWorkflow(null);
  public static final ProductVersion productVersion = new ProductVersion(null);
  public static final FromSource fromSource = new FromSource(null);
  public static final SecretLevel secretLevel = new SecretLevel();
  public static final TestTime testTime = new TestTime();
  public static final IsConnect isConnect = new IsConnect();

  public static final RoleName roleName = new RoleName(null);

  public static final AttempRoleId attempRoleId = new AttempRoleId();

  public static class IsConnect extends GenericEnum
  {
    public static final int _ALL_CONNECT = 1;
    public static final int _PART_CONNECT = 2;
    public static final int _UN_CONNECT = 3;

    public IsConnect()
    {
      super.putEnum(Integer.valueOf(1), "全部调通");
      super.putEnum(Integer.valueOf(2), "部分调通");
      super.putEnum(Integer.valueOf(3), "未调通");
    }
  }

  public static class TestTime extends GenericEnum
  {
    public static final int _M15 = 1;
    public static final int _H24 = 2;
    public static final int _success = 3;

    public TestTime()
    {
      super.putEnum(Integer.valueOf(1), "15分钟");
      super.putEnum(Integer.valueOf(2), "24小时");
      super.putEnum(Integer.valueOf(3), "调通");
    }
  }

  public static class SecretLevel extends GenericEnum
  {
    public static final int _mm = 1;
    public static final int _jim = 2;
    public static final int _jm = 3;

    public SecretLevel()
    {
      super.putEnum(Integer.valueOf(1), "秘密");
      super.putEnum(Integer.valueOf(2), "机密");
      super.putEnum(Integer.valueOf(3), "绝密");
    }
  }

  public static class FromSource extends GenericEnum
  {
    public static final int _fromCompany = 1;
    public static final int _fromProvince = 2;
    public static final int _fromZb = 3;

    private FromSource()
    {
      super.putEnum(Integer.valueOf(1), "公司申请");
      super.putEnum(Integer.valueOf(2), "省分下发");
      super.putEnum(Integer.valueOf(3), "总部下发");
    }
  }

  public static class ProductVersion extends GenericEnum
  {
    public static final int _chinaMobile = 1;
    public static final int _chinaUnicom = 2;

    private ProductVersion()
    {
      super.putEnum(Integer.valueOf(1), "中国移动");
      super.putEnum(Integer.valueOf(2), "中国联通");
    }
  }

  public static class ProcessIdCHWorkflow extends GenericEnum
  {
    public static final long _dlApp = 11L;
    public static final long _dlDgn = 12L;
    public static final long _dlRpl = 13L;
    public static final long _glApp = 14L;
    public static final long _glDgn = 15L;
    public static final long _glRpl = 16L;
    public static final long _netcomDlApp = 21L;
    public static final long _netcomDlDgn = 22L;
    public static final long _netcomDlRpl = 23L;

    private ProcessIdCHWorkflow()
    {
      super.putEnum(Long.valueOf(11L), "电路-申请单");
      super.putEnum(Long.valueOf(12L), "电路-调度单");
      super.putEnum(Long.valueOf(13L), "电路-回执单");
      super.putEnum(Long.valueOf(14L), "光路-申请单");
      super.putEnum(Long.valueOf(15L), "光路-调度单");
      super.putEnum(Long.valueOf(16L), "光路-回执单");
      super.putEnum(Long.valueOf(21L), "综合资源电路-申请单");
      super.putEnum(Long.valueOf(22L), "综合资源电路-调度单");
      super.putEnum(Long.valueOf(23L), "综合资源电路-回执单");
    }
  }

  public static class NetcomReplyState extends GenericEnum
  {
    public static final long _doing = 1L;
    public static final long _problem = 2L;
    public static final long _done = 3L;
    public static final long _all = 4L;

    private NetcomReplyState()
    {
      super.putEnum(Long.valueOf(1L), "处理中");
      super.putEnum(Long.valueOf(2L), "反馈有问题");
      super.putEnum(Long.valueOf(3L), "反馈有问题已处理");
      super.putEnum(Long.valueOf(4L), "待归档");
    }
  }

  public static class ProcessId extends GenericEnum
  {
    public static final long _dlApp = 11L;
    public static final long _dlDgn = 12L;
    public static final long _dlRpl = 13L;
    public static final long _glApp = 14L;
    public static final long _glDgn = 15L;
    public static final long _glRpl = 16L;
    public static final long _netcomDlApp = 21L;
    public static final long _netcomDlDgn = 22L;
    public static final long _netcomDlRpl = 23L;

    private ProcessId()
    {
      super.putEnum(Long.valueOf(11L), "attempAppWF-attempappworkflow");
      super.putEnum(Long.valueOf(12L), "attempDgnWF-attempdgnworkflow");
      super.putEnum(Long.valueOf(13L), "attempRplWF-attemprplworkflow");
      super.putEnum(Long.valueOf(14L), "glAttempAppWF-glattempappworkflow");
      super.putEnum(Long.valueOf(15L), "glAttempDgnWF-glattempdgnworkflow");
      super.putEnum(Long.valueOf(16L), "glAttempRplWF-glattemprplworkflow");
      super.putEnum(Long.valueOf(21L), "netcomAttempAppWF-netcomappworkflow");
      super.putEnum(Long.valueOf(22L), "netcomAttempDgnWF-netcomdgnworkflow");
      super.putEnum(Long.valueOf(23L), "netcomAttempRplWF-netcomrplworkflow");
    }
  }

  public static class ProcessIdCH extends GenericEnum
  {
    public static final long _dlApp = 11L;
    public static final long _dlDgn = 12L;
    public static final long _dlRpl = 13L;
    public static final long _glApp = 14L;
    public static final long _glDgn = 15L;
    public static final long _glRpl = 16L;
    public static final long _netcomDlApp = 21L;
    public static final long _netcomDlDgn = 22L;
    public static final long _netcomDlRpl = 23L;

    private ProcessIdCH()
    {
      super.putEnum(Long.valueOf(11L), "电路申请流程");
      super.putEnum(Long.valueOf(12L), "电路调度流程");
      super.putEnum(Long.valueOf(13L), "电路回执流程");
      super.putEnum(Long.valueOf(14L), "光路申请流程");
      super.putEnum(Long.valueOf(15L), "光路调度流程");
      super.putEnum(Long.valueOf(16L), "光路回执流程");
      super.putEnum(Long.valueOf(21L), "综合资源电路申请流程");
      super.putEnum(Long.valueOf(22L), "综合资源电路调度流程");
      super.putEnum(Long.valueOf(23L), "综合资源电路回执流程");
    }
  }

  public static class RoleId extends GenericEnum
  {
    public static final long _dlAppr = 10L;
    public static final long _dlChek = 20L;
    public static final long _dlDsgn = 30L;
    public static final long _dlDgnAppr = 40L;
    public static final long _dlDpch = 50L;
    public static final long _glAppr = 60L;
    public static final long _glChek = 70L;
    public static final long _glDsgn = 80L;
    public static final long _glDgnAppr = 90L;
    public static final long _glDpch = 100L;

    private RoleId()
    {
      super.putEnum(Long.valueOf(10L), "appApproveRole");
      super.putEnum(Long.valueOf(20L), "checkRole");
      super.putEnum(Long.valueOf(30L), "designRole");
      super.putEnum(Long.valueOf(40L), "dgnApproveRole");
      super.putEnum(Long.valueOf(50L), "dispatchRole");

      super.putEnum(Long.valueOf(60L), "glApproveRole");
      super.putEnum(Long.valueOf(70L), "glCheckRole");
      super.putEnum(Long.valueOf(80L), "glDesignRole");
      super.putEnum(Long.valueOf(90L), "glDgnApproveRole");
      super.putEnum(Long.valueOf(100L), "glDispatchRole");
    }
  }

  public static class RoleIdCH extends GenericEnum
  {
    public static final long _dlAppr = 10L;
    public static final long _dlChek = 20L;
    public static final long _dlDsgn = 30L;
    public static final long _dlDgnAppr = 40L;
    public static final long _dlDpch = 50L;
    public static final long _glAppr = 60L;
    public static final long _glChek = 70L;
    public static final long _glDsgn = 80L;
    public static final long _glDgnAppr = 90L;
    public static final long _glDpch = 100L;

    private RoleIdCH()
    {
      super.putEnum(Long.valueOf(10L), "审核人");
      super.putEnum(Long.valueOf(20L), "资源核查人");
      super.putEnum(Long.valueOf(30L), "参与设计人");
      super.putEnum(Long.valueOf(40L), "调单审核人");
      super.putEnum(Long.valueOf(50L), "派发人");

      super.putEnum(Long.valueOf(60L), "光路审核人");
      super.putEnum(Long.valueOf(70L), "光路资源核查人");
      super.putEnum(Long.valueOf(80L), "光路调度设计人");
      super.putEnum(Long.valueOf(90L), "光路调度审核人");
      super.putEnum(Long.valueOf(100L), "光路调度派发人");
    }
  }

  public static class BusinessType extends GenericEnum
  {
    public static final long _circuit = 1L;
    public static final long _optical = 2L;
    public static final long _jkSepcial = 3L;
    public static final long _pon = 4L;
    public static final long _servicePath = 5L;
    public static final long _topo = 6L;
    public static final long _interface_circuit = 7L;
    public static final long _interface_pon = 8L;
    public static final long _interface_serviceOpenCircuit = 9L;

    private BusinessType()
    {
      super.putEnum(Long.valueOf(1L), "电路");
      super.putEnum(Long.valueOf(2L), "光路");
      super.putEnum(Long.valueOf(3L), "集客专线");
      super.putEnum(Long.valueOf(4L), "PON业务");
      super.putEnum(Long.valueOf(5L), "高转通道");
      super.putEnum(Long.valueOf(6L), "拓扑");
      super.putEnum(Long.valueOf(7L), "接口电路");
      super.putEnum(Long.valueOf(9L), "业务开通接口电路");
      super.putEnum(Long.valueOf(8L), "接口PON");
    }
  }

  public static class WriteResult extends GenericEnum
  {
    public static final long _new_occupy = 11L;
    public static final long _new_release = 12L;
    public static final long _new_continue = 13L;
    public static final long _stop_release = 21L;
    public static final long _stop_dispatch = 22L;
    public static final long _stop_occupy = 23L;
    public static final long _adjust_adjust = 31L;
    public static final long _adjust_dispatch = 32L;
    public static final long _adjust_occupy = 33L;
    public static final long _modify_new_occupy = 41L;
    public static final long _modify_new_release = 42L;
    public static final long _modify_stop_release = 51L;
    public static final long _modify_stop_dispatch = 52L;
    public static final long _modify_adjust_adjust = 61L;
    public static final long _modify_adjust_dispatch = 62L;

    private WriteResult()
    {
      super.putEnum(Long.valueOf(11L), "占用");
      super.putEnum(Long.valueOf(12L), "取消预占");
      super.putEnum(Long.valueOf(13L), "继续预占");
      super.putEnum(Long.valueOf(21L), "释放占用");
      super.putEnum(Long.valueOf(22L), "取消停闭");
      super.putEnum(Long.valueOf(23L), "继续占用");
      super.putEnum(Long.valueOf(31L), "调整");
      super.putEnum(Long.valueOf(32L), "取消调整");
      super.putEnum(Long.valueOf(33L), "继续调整");
      super.putEnum(Long.valueOf(41L), "修改单回写");
      super.putEnum(Long.valueOf(42L), "修改单回写");
      super.putEnum(Long.valueOf(51L), "修改单回写");
      super.putEnum(Long.valueOf(52L), "修改单回写");
      super.putEnum(Long.valueOf(61L), "修改单回写");
      super.putEnum(Long.valueOf(62L), "修改单回写");
    }
  }

  public static class ServiceComplete extends GenericEnum
  {
    public static final long _not_archive = 1L;
    public static final long _archive = 2L;

    private ServiceComplete()
    {
      super.putEnum(Long.valueOf(1L), "待归档");
      super.putEnum(Long.valueOf(2L), "已归档");
    }
  }

  public static class SheetArchive extends GenericEnum
  {
    public static final long _app_not_archive = 1L;
    public static final long _dgn_not_archive = 1L;
    public static final long _rpl_not_archive = 1L;
    public static final long _app_archive = 10L;
    public static final long _dgn_archive = 10L;
    public static final long _rpl_archive = 10L;
    public static final long _archive = 10L;

    private SheetArchive()
    {
      super.putEnum(Long.valueOf(1L), "申请单未归档");
      super.putEnum(Long.valueOf(1L), "调单未归档");
      super.putEnum(Long.valueOf(1L), "回执单未归档");
      super.putEnum(Long.valueOf(1L), "申请单归档");
      super.putEnum(Long.valueOf(1L), "调单归档");
      super.putEnum(Long.valueOf(1L), "回执单归档");
    }
  }

  public static class AttempResult extends GenericEnum
  {
    public static final long _unadd = 11L;
    public static final long _added = 12L;
    public static final long _unstop = 21L;
    public static final long _stoped = 22L;
    public static final long _unadjust = 31L;
    public static final long _adjusted = 32L;
    public static final long _undo = 0L;

    private AttempResult()
    {
      super.putEnum(Long.valueOf(11L), "未开通");
      super.putEnum(Long.valueOf(12L), "已开通");
      super.putEnum(Long.valueOf(21L), "未停闭");
      super.putEnum(Long.valueOf(22L), "已停闭");
      super.putEnum(Long.valueOf(31L), "未调整");
      super.putEnum(Long.valueOf(32L), "已调整");
      super.putEnum(Long.valueOf(0L), "未处理");
    }
  }

  public static class HandlerType extends GenericEnum
  {
    public static final long _app_approve = 11L;
    public static final long _app_resourceCheck = 12L;
    public static final long _app_approveTransmit = 13L;
    public static final long _dgn_design = 21L;
    public static final long _dgn_approve = 22L;
    public static final long _dgn_dispatch = 23L;

    private HandlerType()
    {
      super.putEnum(Long.valueOf(11L), "申请单审核");
      super.putEnum(Long.valueOf(12L), "申请单核查");
      super.putEnum(Long.valueOf(21L), "调度单设计");
      super.putEnum(Long.valueOf(22L), "调度单审核");
      super.putEnum(Long.valueOf(23L), "调度单派发");
      super.putEnum(Long.valueOf(13L), "转发发起人");
    }
  }

  public static class SignType extends GenericEnum
  {
    public static final long _app = 1L;
    public static final long _dgn = 2L;
    public static final long _rpl = 3L;
    public static final long _resourceCheck = 4L;
    public static final long _complete = 5L;

    private SignType()
    {
      super.putEnum(Long.valueOf(1L), "申请单审核");
      super.putEnum(Long.valueOf(2L), "调度单");
      super.putEnum(Long.valueOf(3L), "回执单");
      super.putEnum(Long.valueOf(4L), "资源核查");
      super.putEnum(Long.valueOf(5L), "调单归档");
    }
  }

  public static class JustType extends GenericEnum
  {
    public static final long _yes = 1L;
    public static final long _no = 0L;

    private JustType()
    {
      super.putEnum(Long.valueOf(1L), "是");
      super.putEnum(Long.valueOf(0L), "否");
    }
  }

  public static class ReplyState extends GenericEnum
  {
    public static final long _all = 1L;
    public static final long _null = 2L;
    public static final long _part = 3L;

    private ReplyState()
    {
      super.putEnum(Long.valueOf(1L), "全部回单");
      super.putEnum(Long.valueOf(2L), "未回单");
      super.putEnum(Long.valueOf(3L), "部分回单");
    }
  }

  public static class UrgentGrade extends GenericEnum
  {
    public static final long _grade1 = 1L;
    public static final long _grade2 = 2L;
    public static final long _grade3 = 3L;

    private UrgentGrade()
    {
      super.putEnum(Long.valueOf(1L), "一般");
      super.putEnum(Long.valueOf(2L), "紧急");
      super.putEnum(Long.valueOf(3L), "特急");
    }
  }

  public static class AttempType extends GenericEnum
  {
    public static final long _add = 1L;
    public static final long _stop = 2L;
    public static final long _adjust = 3L;
    public static final long _cutover = 4L;

    private AttempType()
    {
      super.putEnum(Long.valueOf(1L), "新增");
      super.putEnum(Long.valueOf(2L), "停闭");
      super.putEnum(Long.valueOf(3L), "调整");
      super.putEnum(Long.valueOf(4L), "割接");
    }
  }

  public static class AttempResultTypeSH extends GenericEnum
  {
    public static final long _add = 1L;
    public static final long _stop = 2L;
    public static final long _adjust = 3L;

    private AttempResultTypeSH()
    {
      super.putEnum(Long.valueOf(1L), "已开通");
      super.putEnum(Long.valueOf(2L), "已割接");
      super.putEnum(Long.valueOf(3L), "已拆除");
    }
  }

  public static class AutoDispachType extends GenericEnum
  {
    public static final String _SDH_TD = "SDH_TD";
    public static final String _SDH_2G = "SDH_2G";
    public static final String _PTN_2G = "PTN_2G";
    public static final String _PTN_TD = "PTN_TD";
    public static final String _PTN_LTE = "PTN-LTE";
    public static final String _SDH_MSTP = "SDH_MSTP";
    public static final String _PTN_MSTP = "PTN_MSTP";
    public static final String _PERSON = "PERSON";

    private AutoDispachType()
    {
      super.putEnum("SDH_TD", "自动基站SDH-TD");
      super.putEnum("SDH_2G", "自动基站SDH-2G");
      super.putEnum("PTN_2G", "自动基站_PTN_2G");
      super.putEnum("PTN_TD", "自动基站PTN_TD");
      super.putEnum("PTN-LTE", "自动基站PTN-LTE");
      super.putEnum("SDH_MSTP", "自动基站SDH_MSTP");
      super.putEnum("PTN_MSTP", "自动基站PTN_MSTP");
      super.putEnum("PERSON", "人工派发");
    }
  }

  public static class AttempTypeSH extends GenericEnum
  {
    public static final long _add = 1L;
    public static final long _stop = 2L;
    public static final long _adjust = 3L;

    private AttempTypeSH()
    {
      super.putEnum(Long.valueOf(1L), "待开通");
      super.putEnum(Long.valueOf(2L), "待拆除");
      super.putEnum(Long.valueOf(3L), "待割接");
    }
  }

  public static class SheetType extends GenericEnum
  {
    public static final long _app = 1L;
    public static final long _dgn = 2L;
    public static final long _rpl = 3L;

    private SheetType()
    {
      super.putEnum(Long.valueOf(1L), "申请单");
      super.putEnum(Long.valueOf(2L), "设计单");
      super.putEnum(Long.valueOf(3L), "回执单");
    }
  }

  public static class SheetState extends GenericEnum
  {
    public static final long _his = 2L;

    private SheetState()
    {
      super.putEnum(Long.valueOf(2L), "历史单");
    }
  }

  public static class AdjustState extends GenericEnum
  {
    public static final long _adjust_pre = 1L;
    public static final long _adjust_hind = 2L;

    private AdjustState()
    {
      super.putEnum(Long.valueOf(1L), "调前");
      super.putEnum(Long.valueOf(2L), "调后");
    }
  }

  public static class AttempStatRole extends GenericEnum
  {
    public static final String _designRole = "designRole";
    public static final String _glDesignRole = "glDesignRole";
  }

  public static class RoleName extends GenericEnum
  {
    public static final String _publicRole = "publicRole";
    public static final String _appRole = "appCreateAct";
    public static final String _appRecycleAct = "appRecycleAct";
    public static final String _appApproveRole = "appApproveAct";
    public static final String _checkRole = "appCheckAct";
    public static final String _designRole = "dgnCreateAct";
    public static final String _recycleAct = "recycleAct";
    public static final String _dgnApproveRole = "dgnApproveAct";
    public static final String _dispatchRole = "dispatchAct";
    public static final String _transCompleteRole = "transCompleteAct";
    public static final String _operateCompleteRole = "serviceCompleteAct";
    public static final String _rplCreateRole = "rplCreateAct";
    public static final String _replyRole = "replyAct";
    public static final String _rplApproveRole = "reReplyAct";

    private RoleName()
    {
      super.putEnum("publicRole", "");
      super.putEnum("appCreateAct", "申请");
      super.putEnum("appRecycleAct", "申请");
      super.putEnum("appApproveAct", "审核");
      super.putEnum("appCheckAct", "资源核查");

      super.putEnum("dgnCreateAct", "设计");
      super.putEnum("recycleAct", "设计");
      super.putEnum("dgnApproveAct", "审核");
      super.putEnum("dispatchAct", "派发");
      super.putEnum("transCompleteAct", "传输竣工归档");
      super.putEnum("serviceCompleteAct", "业务竣工归档");

      super.putEnum("rplCreateAct", "收单");
      super.putEnum("replyAct", "回单");
      super.putEnum("reReplyAct", "再次回单");
    }
  }

  public static class AttempRoleId extends GenericEnum
  {
    public static final String _appRole = "appRole";
    public static final String _appApproveRole = "appApproveRole";
    public static final String _checkRole = "checkRole";
    public static final String _designRole = "designRole";
    public static final String _dgnApproveRole = "dgnApproveRole";
    public static final String _dispatchRole = "dispatchRole";
    public static final String _transCompleteRole = "transCompleteRole";
    public static final String _operateCompleteRole = "operateCompleteRole";
    public static final String _rplCreateRole = "rplCreateRole";
    public static final String _replyRole = "replyRole";
    public static final String _rplApproveRole = "rplApproveRole";
  }
}