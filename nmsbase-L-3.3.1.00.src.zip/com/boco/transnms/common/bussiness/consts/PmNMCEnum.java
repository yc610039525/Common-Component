package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class PmNMCEnum
{
  public static final PMLocation pMLocation = new PMLocation(null);
  public static final PMCycle pMCycle = new PMCycle(null);
  public static final AUTOTESTTYPE autoTestType = new AUTOTESTTYPE(null);

  public static enum HistoryPMDataStyle
  {
    collect, 
    autoTestPmTask;
  }

  public static class SCOPE_TYPE
  {
    public static final int SITE = 1;
    public static final int TRANS_SYSTEM = 2;
    public static final int NONE = 3;
    public static final int PORT = 4;
  }

  public static class AUTOTESTTYPE extends GenericEnum<Integer>
  {
    public static final int SDH = 1;
    public static final int OTM = 2;
    public static final int OA = 3;
    public static final int WDM = 4;
    public static final int TD = 5;
    public static final int SDH_PORT = 6;

    private AUTOTESTTYPE()
    {
      putEnum(Integer.valueOf(1), "SDH");
      putEnum(Integer.valueOf(2), "OTM");
      putEnum(Integer.valueOf(3), "OA");
      putEnum(Integer.valueOf(4), "WDM");
      putEnum(Integer.valueOf(5), "TD");
      putEnum(Integer.valueOf(6), "SDH_PORT");
    }
  }

  public static class TASK_STATUS
  {
    public static final int START = 1;
    public static final int STOP = 2;
  }

  public static class MONITOR_CYCLE
  {
    public static final int MIN15 = 1;
    public static final int HOUR24 = 2;
  }

  public static class AUTOTEST_CYCLE
  {
    public static final int DAY = 1;
    public static final int WEEK = 2;
    public static final int MONTH = 3;
    public static final int SEASON = 4;
    public static final int HALF_YEAR = 5;
    public static final int YEAR = 6;
  }

  public static class AUTOTEST_STYLE
  {
    public static final int MANUAL = 1;
    public static final int AUTO = 2;
  }

  public static class NeSignalType
  {
    public static final int SDH = 1;
    public static final int PDH = 2;
    public static final int WDM = 3;
    public static final int WAVELET = 4;
    public static final int MIX = 5;
  }

  public static class RTUHistoryTitle
  {
    public static int UserLabel = 0;
    public static int EMSName = 1;
    public static int EMSNativeName = 2;
    public static int MEName = 3;
    public static int MENativeName = 4;
    public static int PTPName = 5;
    public static int PTPNativeName = 6;
    public static int CTPName = 7;
    public static int CTPNativeName = 8;
    public static int LayerRate = 9;
    public static int Granularity = 10;
    public static int PeriodStartTime = 11;
    public static int MonitoredTime = 12;
    public static int PMParameter = 13;
    public static int Location = 14;
    public static int Value = 15;
    public static int Unit = 16;
    public static int Status = 17;
    public static int NrOfPeriods = 18;
  }

  public static enum DealModel
  {
    History, 
    Curr, 
    Message, 
    PmAutoTestTask;
  }

  public static class LocateLevel
  {
    public static final int NE = 1;
    public static final int PLATE = 2;
    public static final int PTP = 3;
    public static final int CTP = 4;
  }

  public static enum LOCATE_LEVEL
  {
    NE, 
    PLATE, 
    PTP, 
    CTP;
  }

  public static enum OperateType
  {
    Create, 
    Modify, 
    Delete, 
    Activate, 
    Suspend;
  }

  public static class PMCycle extends GenericEnum<Integer>
  {
    public static final String value1 = "15min";
    public static final String value2 = "24h";

    private PMCycle()
    {
      putEnum(Integer.valueOf(1), "15min");
      putEnum(Integer.valueOf(2), "24h");
    }
  }

  public static class PMLocation extends GenericEnum<Integer>
  {
    public static final int PML_NEAR_END_Rx = 1;
    public static final int PML_FAR_END_Rx = 2;
    public static final int PML_NEAR_END_Tx = 3;
    public static final int PML_FAR_END_Tx = 4;
    public static final int PML_BIDIRECTIONAL = 5;

    private PMLocation()
    {
      putEnum(Integer.valueOf(1), "PML_NEAR_END_Rx");
      putEnum(Integer.valueOf(2), "PML_FAR_END_Rx");
      putEnum(Integer.valueOf(3), "PML_NEAR_END_Tx");
      putEnum(Integer.valueOf(4), "PML_FAR_END_Tx");
      putEnum(Integer.valueOf(5), "PML_BIDIRECTIONAL");
    }
  }
}