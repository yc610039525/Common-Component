package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class ResourceCheckEnum
{
  public static final Type TYPE = new Type(null);
  public static final TaskType TASK_TYPE = new TaskType(null);
  public static final IsActive IS_ACTIVE = new IsActive(null);
  public static final Frequency FREQUENCY = new Frequency(null);
  public static final Weekt WEEKT = new Weekt(null);
  public static final Day DAY = new Day(null);
  public static final ExecuteState EXECUTE_STATE = new ExecuteState(null);
  public static final cycle CYCLE = new cycle(null);

  public static class cycle extends GenericEnum
  {
    public static final long _day = 1L;
    public static final long _week = 7L;
    public static final long _month = 31L;

    private cycle()
    {
      super.putEnum(Long.valueOf(1L), "日");
      super.putEnum(Long.valueOf(7L), "周");
      super.putEnum(Long.valueOf(31L), "月");
    }
  }

  public static class ExecuteState extends GenericEnum
  {
    public static final long _over = 1L;
    public static final long _run = 2L;
    public static final long _unrun = 3L;

    private ExecuteState()
    {
      super.putEnum(Long.valueOf(1L), "完成");
      super.putEnum(Long.valueOf(2L), "正在执行");
      super.putEnum(Long.valueOf(3L), "未执行");
    }
  }

  public static class Day extends GenericEnum
  {
    public static final long _1 = 1L;
    public static final long _2 = 2L;
    public static final long _3 = 3L;
    public static final long _4 = 4L;
    public static final long _5 = 5L;
    public static final long _6 = 6L;
    public static final long _7 = 7L;
    public static final long _8 = 8L;
    public static final long _9 = 9L;
    public static final long _10 = 10L;
    public static final long _11 = 11L;
    public static final long _12 = 12L;
    public static final long _13 = 13L;
    public static final long _14 = 14L;
    public static final long _15 = 15L;
    public static final long _16 = 16L;
    public static final long _17 = 17L;
    public static final long _18 = 18L;
    public static final long _19 = 19L;
    public static final long _20 = 20L;
    public static final long _21 = 21L;
    public static final long _22 = 22L;
    public static final long _23 = 23L;
    public static final long _24 = 24L;
    public static final long _25 = 25L;
    public static final long _26 = 26L;
    public static final long _27 = 27L;
    public static final long _28 = 28L;
    public static final long _29 = 29L;
    public static final long _30 = 30L;
    public static final long _31 = 31L;

    private Day()
    {
      super.putEnum(Long.valueOf(1L), "1");
      super.putEnum(Long.valueOf(2L), "2");
      super.putEnum(Long.valueOf(3L), "3");
      super.putEnum(Long.valueOf(4L), "4");
      super.putEnum(Long.valueOf(5L), "5");
      super.putEnum(Long.valueOf(6L), "6");
      super.putEnum(Long.valueOf(7L), "7");
      super.putEnum(Long.valueOf(8L), "8");
      super.putEnum(Long.valueOf(9L), "9");
      super.putEnum(Long.valueOf(10L), "10");
      super.putEnum(Long.valueOf(11L), "11");
      super.putEnum(Long.valueOf(12L), "12");
      super.putEnum(Long.valueOf(13L), "13");
      super.putEnum(Long.valueOf(14L), "14");
      super.putEnum(Long.valueOf(15L), "15");
      super.putEnum(Long.valueOf(16L), "16");
      super.putEnum(Long.valueOf(17L), "17");
      super.putEnum(Long.valueOf(18L), "18");
      super.putEnum(Long.valueOf(19L), "19");
      super.putEnum(Long.valueOf(20L), "20");
      super.putEnum(Long.valueOf(21L), "21");
      super.putEnum(Long.valueOf(22L), "22");
      super.putEnum(Long.valueOf(23L), "23");
      super.putEnum(Long.valueOf(24L), "24");
      super.putEnum(Long.valueOf(25L), "25");
      super.putEnum(Long.valueOf(26L), "26");
      super.putEnum(Long.valueOf(27L), "27");
      super.putEnum(Long.valueOf(28L), "28");
      super.putEnum(Long.valueOf(29L), "29");
      super.putEnum(Long.valueOf(30L), "30");
      super.putEnum(Long.valueOf(31L), "31");
    }
  }

  public static class Weekt extends GenericEnum
  {
    public static final long _Sun = 1L;
    public static final long _Mon = 2L;
    public static final long _Tues = 3L;
    public static final long _Wed = 4L;
    public static final long _Thurs = 5L;
    public static final long _Friday = 6L;
    public static final long _Sat = 7L;

    private Weekt()
    {
      super.putEnum(Long.valueOf(1L), "星期日");
      super.putEnum(Long.valueOf(2L), "星期一");
      super.putEnum(Long.valueOf(3L), "星期二");
      super.putEnum(Long.valueOf(4L), "星期三");
      super.putEnum(Long.valueOf(5L), "星期四");
      super.putEnum(Long.valueOf(6L), "星期五");
      super.putEnum(Long.valueOf(7L), "星期六");
    }
  }

  public static class Frequency extends GenericEnum
  {
    public static final long _date = 1L;
    public static final long _week = 2L;
    public static final long _month = 3L;

    private Frequency()
    {
      super.putEnum(Long.valueOf(1L), "每日");
      super.putEnum(Long.valueOf(2L), "每周");
      super.putEnum(Long.valueOf(3L), "每月");
    }
  }

  public static class IsActive extends GenericEnum
  {
    public static final long _use = 0L;
    public static final long _unuse = 1L;

    private IsActive()
    {
      super.putEnum(Long.valueOf(0L), "启用");
      super.putEnum(Long.valueOf(1L), "禁用");
    }
  }

  public static class TaskType extends GenericEnum
  {
    public static final long _manual = 1L;
    public static final long _auto = 2L;

    private TaskType()
    {
      super.putEnum(Long.valueOf(1L), "手动");
      super.putEnum(Long.valueOf(2L), "定时");
    }
  }

  public static class Type extends GenericEnum
  {
    public static final long _gaff = 0L;
    public static final long _amount = 1L;
    public static final long _less = 2L;
    public static final long _gf_am = 3L;
    public static final long _le_am = 4L;

    private Type()
    {
      super.putEnum(Long.valueOf(0L), "大于");
      super.putEnum(Long.valueOf(1L), "等于");
      super.putEnum(Long.valueOf(2L), "小于");
      super.putEnum(Long.valueOf(3L), "大于等于");
      super.putEnum(Long.valueOf(4L), "小于等于");
    }
  }
}