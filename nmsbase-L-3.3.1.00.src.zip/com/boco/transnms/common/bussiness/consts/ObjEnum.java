package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class ObjEnum
{
  public static final OperateType OPERATE_TYPE = new OperateType(null);
  public static final ObjType OBJ_TYPE = new ObjType(null);

  public static class ObjType extends GenericEnum { public static final long _district = 1L;
    public static final long _site = 2L;
    public static final long _room = 3L;
    public static final long _ne = 4L;
    public static final long _transpath = 5L;
    public static final long _traph = 6L;
    public static final long _xdf = 7L;
    public static final long _xdfport = 8L;
    public static final long _jump = 9L;
    public static final long _port = 10L;
    public static final long _terminal = 11L;
    public static final long _net = 12L;
    public static final long _xianxinshangjia = 13L;
    public static final long _wireSystem = 101L;
    public static final long _microwaveSystem = 102L;
    public static final long _ductSystem = 103L;
    public static final long _polewaySystem = 104L;
    public static final long _stonewaySystem = 105L;
    public static final long _hangwall = 106L;
    public static final long _upline = 107L;
    public static final long _ductBranch = 111L;
    public static final long _polewayBranch = 112L;
    public static final long _stonewayBranch = 113L;
    public static final long _wireSeg = 121L;
    public static final long _microwaveLineSeg = 122L;
    public static final long _ductSeg = 123L;
    public static final long _polewaySeg = 124L;
    public static final long _stonewaySeg = 125L;
    public static final long _hangwallSeg = 126L;
    public static final long _uplineSeg = 127L;
    public static final long _fiberCab = 131L;
    public static final long _fiberDp = 132L;
    public static final long _fiberJointBox = 133L;
    public static final long _manhle = 134L;
    public static final long _pole = 135L;
    public static final long _stone = 136L;
    public static final long _inflexion = 137L;
    public static final long _accesspoint = 138L;
    public static final long _wireTrouble = 139L;
    public static final long _wireToWireTrouble = 140L;
    public static final long _optical = 141L;
    public static final long _opticalWay = 142L;
    public static final long _fiber = 143L;

    private ObjType() { super.putEnum(Long.valueOf(1L), "区域");
      super.putEnum(Long.valueOf(2L), "站点");
      super.putEnum(Long.valueOf(3L), "机房");
      super.putEnum(Long.valueOf(4L), "网元");
      super.putEnum(Long.valueOf(5L), "通道");
      super.putEnum(Long.valueOf(6L), "电路");
      super.putEnum(Long.valueOf(7L), "配线架");
      super.putEnum(Long.valueOf(8L), "配线架端子");
      super.putEnum(Long.valueOf(9L), "跳纤跳线");

      super.putEnum(Long.valueOf(10L), "端口");
      super.putEnum(Long.valueOf(11L), "端子");
      super.putEnum(Long.valueOf(12L), "子网");
      super.putEnum(Long.valueOf(13L), "纤芯上架");

      super.putEnum(Long.valueOf(101L), "光缆系统");
      super.putEnum(Long.valueOf(102L), "微波系统");
      super.putEnum(Long.valueOf(103L), "管道系统");
      super.putEnum(Long.valueOf(104L), "杆路系统");
      super.putEnum(Long.valueOf(105L), "标石路由");
      super.putEnum(Long.valueOf(106L), "挂墙");
      super.putEnum(Long.valueOf(107L), "引上");

      super.putEnum(Long.valueOf(111L), "管道分支");
      super.putEnum(Long.valueOf(112L), "杆路分支");
      super.putEnum(Long.valueOf(113L), "标石路由分支");

      super.putEnum(Long.valueOf(121L), "光缆段");
      super.putEnum(Long.valueOf(122L), "微波段");
      super.putEnum(Long.valueOf(123L), "管道段");
      super.putEnum(Long.valueOf(124L), "杆路段");
      super.putEnum(Long.valueOf(125L), "标石路由段");
      super.putEnum(Long.valueOf(126L), "挂墙段");
      super.putEnum(Long.valueOf(127L), "引上段");

      super.putEnum(Long.valueOf(131L), "光交接箱");
      super.putEnum(Long.valueOf(132L), "光分纤箱");
      super.putEnum(Long.valueOf(133L), "光接头盒");
      super.putEnum(Long.valueOf(134L), "人手井");
      super.putEnum(Long.valueOf(135L), "电杆");
      super.putEnum(Long.valueOf(136L), "标石");
      super.putEnum(Long.valueOf(137L), "拐点");
      super.putEnum(Long.valueOf(138L), "接入点");
      super.putEnum(Long.valueOf(139L), "隐患");

      super.putEnum(Long.valueOf(141L), "光纤");
      super.putEnum(Long.valueOf(142L), "光路");
      super.putEnum(Long.valueOf(143L), "纤芯");
    }
  }

  public static class OperateType extends GenericEnum
  {
    public static final long _add = 1L;
    public static final long _modify = 2L;
    public static final long _delete = 3L;

    private OperateType()
    {
      super.putEnum(Long.valueOf(1L), "添加");
      super.putEnum(Long.valueOf(2L), "修改");
      super.putEnum(Long.valueOf(3L), "删除");
    }
  }
}