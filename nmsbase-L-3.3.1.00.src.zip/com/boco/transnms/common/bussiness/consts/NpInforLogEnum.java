package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class NpInforLogEnum
{
  public static final Type TYPE = new Type(null);
  public static final InfoType INFO_TYPE = new InfoType(null);
  public static final InfoFlag INFO_FLAG = new InfoFlag(null);

  public static class InfoFlag extends GenericEnum
  {
    public static final long _undeal = 1L;
    public static final long _succeed = 2L;
    public static final long _lost = 3L;

    private InfoFlag()
    {
      super.putEnum(Long.valueOf(1L), "未处理");
      super.putEnum(Long.valueOf(2L), "成功");
      super.putEnum(Long.valueOf(3L), "失败");
    }
  }

  public static class InfoType extends GenericEnum
  {
    public static final long _send = 1L;
    public static final long _resive = 2L;
    public static final long _urge = 3L;
    public static final long _returnwirte = 4L;
    public static final long _pigeonhole = 5L;
    public static final long _returnreceipt = 6L;
    public static final long _remove = 7L;
    public static final long _preremove = 8L;
    public static final long _cancelremove = 9L;

    private InfoType()
    {
      super.putEnum(Long.valueOf(1L), "发单");
      super.putEnum(Long.valueOf(2L), "收单");
      super.putEnum(Long.valueOf(3L), "催单");
      super.putEnum(Long.valueOf(4L), "回写");
      super.putEnum(Long.valueOf(5L), "归档");
      super.putEnum(Long.valueOf(6L), "回执");
      super.putEnum(Long.valueOf(7L), "撤消");
      super.putEnum(Long.valueOf(8L), "预撤消");
      super.putEnum(Long.valueOf(9L), "取消撤消");
    }
  }

  public static class Type extends GenericEnum
  {
    public static final long _send = 1L;
    public static final long _resive = 2L;

    private Type()
    {
      super.putEnum(Long.valueOf(1L), "发送");
      super.putEnum(Long.valueOf(2L), "接收");
    }
  }
}