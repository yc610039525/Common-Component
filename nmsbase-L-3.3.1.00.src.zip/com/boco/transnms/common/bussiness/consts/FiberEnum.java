package com.boco.transnms.common.bussiness.consts;

import com.boco.common.util.lang.GenericEnum;

public class FiberEnum
{
  public static final OpticalFiberState OPTICAL_FIBERSTATE = new OpticalFiberState(null);
  public static final OpticalOwnerShip OPTICAL_OWNERSHIP = new OpticalOwnerShip(null);
  public static final OpticalFiberLevel OPTICAL_FIBERLEVEL = new OpticalFiberLevel(null);
  public static final OpticalFiberType OPTICAL_FIBERTYPE = new OpticalFiberType(null);
  public static final OpticalFiberDir OPTICAL_FIBERDIR = new OpticalFiberDir(null);
  public static final FCabDpPurpose FCABDP_PURPOSE = new FCabDpPurpose(null);
  public static final FCabDpMaintMode FCABDP_MAINTMODE = new FCabDpMaintMode(null);
  public static final FCabDpOwnerShip FCABDP_OWNERSHIP = new FCabDpOwnerShip(null);

  public static final OpticalNum OPTICAL_NUM = new OpticalNum(null);
  public static final OpticalRouteState OPTICAL_ROUTE_STATE = new OpticalRouteState(null);
  public static final OpticalRouteType OPTICAL_ROUTE_TYPE = new OpticalRouteType(null);

  public static final OpticalMakeFlag OPTICAL_MAKE_FLAG = new OpticalMakeFlag(null);

  public static class OpticalMakeFlag extends GenericEnum
  {
    public static final long _1 = 1L;
    public static final long _2 = 2L;
    public static final long _3 = 3L;

    private OpticalMakeFlag()
    {
      super.putEnum(Long.valueOf(1L), "待核查");
      super.putEnum(Long.valueOf(2L), "成功");
      super.putEnum(Long.valueOf(3L), "失败");
    }
  }

  public static class OpticalRouteType extends GenericEnum
  {
  }

  public static class OpticalRouteState extends GenericEnum
  {
  }

  public static class OpticalNum extends GenericEnum
  {
    public static final long _1 = 1L;
    public static final long _2 = 2L;
    public static final long _4 = 4L;

    private OpticalNum()
    {
      super.putEnum(Long.valueOf(1L), "1芯");
      super.putEnum(Long.valueOf(2L), "2芯");
      super.putEnum(Long.valueOf(4L), "4芯");
    }
  }

  public static class FCabDpOwnerShip extends GenericEnum
  {
    public static final long _self = 1L;
    public static final long _leasehold = 2L;

    private FCabDpOwnerShip()
    {
      super.putEnum(Long.valueOf(1L), "自建");
      super.putEnum(Long.valueOf(2L), "租用");
    }
  }

  public static class FCabDpMaintMode extends GenericEnum
  {
    public static final long self = 1L;
    public static final long other = 2L;

    private FCabDpMaintMode()
    {
      super.putEnum(Long.valueOf(1L), "自维");
      super.putEnum(Long.valueOf(2L), "代维");
    }
  }

  public static class FCabDpPurpose extends GenericEnum
  {
    public static final int _SELF = 1;
    public static final int _RENT = 2;

    private FCabDpPurpose()
    {
      super.putEnum(Integer.valueOf(1), "自用");
      super.putEnum(Integer.valueOf(2), "出租");
    }
  }

  public static class OpticalFiberDir extends GenericEnum
  {
    public static final long _unknown = 1L;
    public static final long _deasil = 2L;
    public static final long _converse = 3L;
    public static final long _double = 4L;

    private OpticalFiberDir()
    {
      super.putEnum(Long.valueOf(1L), "无");
      super.putEnum(Long.valueOf(2L), "左向");
      super.putEnum(Long.valueOf(3L), "右向");
      super.putEnum(Long.valueOf(4L), "双向");
    }
  }

  public static class OpticalFiberType extends GenericEnum
  {
    public static final long _g_652 = 1L;
    public static final long _g_655 = 2L;

    private OpticalFiberType()
    {
      super.putEnum(Long.valueOf(1L), "G.652");
      super.putEnum(Long.valueOf(2L), "G.655");
    }
  }

  public static class OpticalDeviceType extends GenericEnum
  {
    public static final long _odf = 1L;
    public static final long _fcab = 2L;
    public static final long _fdp = 3L;
    public static final long _site = 4L;

    private OpticalDeviceType()
    {
      super.putEnum(Long.valueOf(1L), "ODF");
      super.putEnum(Long.valueOf(2L), "FIBERCAB");
      super.putEnum(Long.valueOf(3L), "FIBERDP");
      super.putEnum(Long.valueOf(4L), "SITE");
    }
  }

  public static class OpticalFiberLevel extends GenericEnum
  {
    public static final long _interprovince = 1L;
    public static final long _innerprovince = 2L;
    public static final long _local = 3L;

    private OpticalFiberLevel()
    {
      super.putEnum(Long.valueOf(1L), "省际");
      super.putEnum(Long.valueOf(2L), "省内");
      super.putEnum(Long.valueOf(3L), "本地");
    }
  }

  public static class OpticalOwnerShip extends GenericEnum
  {
    public static final long _self = 1L;
    public static final long _share = 2L;
    public static final long _combine = 3L;
    public static final long _affix = 4L;
    public static final long _leasehold = 5L;

    private OpticalOwnerShip()
    {
      super.putEnum(Long.valueOf(1L), "自建");
      super.putEnum(Long.valueOf(2L), "共建");
      super.putEnum(Long.valueOf(3L), "合建");
      super.putEnum(Long.valueOf(4L), "附挂/附穿");
      super.putEnum(Long.valueOf(5L), "租用");
    }
  }

  public static class OpticalFiberState extends GenericEnum
  {
    public static final long _idle = 1L;
    public static final long _inuse = 2L;
    public static final long _preuse = 3L;
    public static final long _bad = 4L;
    public static final long _unusable = 5L;

    private OpticalFiberState()
    {
      super.putEnum(Long.valueOf(1L), "未用");
      super.putEnum(Long.valueOf(2L), "在用");
      super.putEnum(Long.valueOf(3L), "预占");
      super.putEnum(Long.valueOf(4L), "坏纤");
      super.putEnum(Long.valueOf(5L), "不可用纤");
    }
  }
}