package com.boco.transnms.common.bussiness.helper;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.lang.StringHelper;
import org.apache.commons.logging.Log;

public class AnFdnHelper
{
  public static final String EmsHeader = "EMS=";
  public static final String OltHeader = "ManagedElement=";
  public static final String OnuHeader = "ONU=";
  public static final String PosHeader = "POS=";
  public static final String HolderHeader = "EquipmentHolder=";
  public static final String CardHeader = "Equipment=";
  public static final String PtpHeader = "PTP=";
  public static final String FtpHeader = "FTP=";
  public static final String RackHeader = "rack=";
  public static final String ShelfHeader = "shelf=";
  public static final String SlotHeader = "slot=";
  public static final String PortHeader = "port=";
  public static final String fdnSpliter = ":";
  public static final String fdnSpliterB = "=";
  public static final String fdnSpliterC = "/";
  public static final String fdnSpliterD = "-";

  public static String makeEmsFdn(String emsName)
  {
    if (!StringHelper.isEmpty(emsName)) {
      return new StringBuilder().append("EMS=").append(emsName).toString();
    }
    return "";
  }

  public static String makeOltFdn(String emsFdn, String oltName)
  {
    if ((!StringHelper.isEmpty(emsFdn)) && (!StringHelper.isEmpty(oltName))) {
      return new StringBuilder().append(emsFdn).append(":").append("ManagedElement=").append(oltName).toString();
    }
    return "";
  }

  public static String makeOltFdnByNames(String emsName, String oltName)
  {
    if ((!StringHelper.isEmpty(emsName)) && (!StringHelper.isEmpty(oltName))) {
      return new StringBuilder().append(makeEmsFdn(emsName)).append(":").append("ManagedElement=").append(oltName).toString();
    }
    return "";
  }

  public static String makeOnuFdn(String emsFdn, String oltFdn, String onuName)
  {
    if ((!StringHelper.isEmpty(emsFdn)) && (!StringHelper.isEmpty(oltFdn)) && (!StringHelper.isEmpty(onuName))) {
      return new StringBuilder().append(emsFdn).append(":").append(oltFdn).append(":").append("ONU=").append(onuName).toString();
    }
    return "";
  }

  public static String makeOnuFdnByNames(String emsName, String oltName, String onuName)
  {
    if ((!StringHelper.isEmpty(emsName)) && (!StringHelper.isEmpty(oltName)) && (!StringHelper.isEmpty(onuName))) {
      return new StringBuilder().append(makeOltFdnByNames(emsName, oltName)).append(":").append("ONU=").append(onuName).toString();
    }
    return "";
  }

  public static String makePosFdn(String oltFdn, String posName)
  {
    if ((!StringHelper.isEmpty(oltFdn)) && (!StringHelper.isEmpty(posName))) {
      return new StringBuilder().append(oltFdn).append(":").append("POS=").append(posName).toString();
    }
    return "";
  }

  public static String makePosFdnByNames(String emsName, String oltName, String posName)
  {
    if ((!StringHelper.isEmpty(emsName)) && (!StringHelper.isEmpty(oltName)) && (!StringHelper.isEmpty(posName))) {
      return new StringBuilder().append(makeOltFdnByNames(emsName, oltName)).append(":").append("POS=").append(posName).toString();
    }
    return "";
  }

  public static String makeOltHolderFdn(String emsName, String oltName, String equipmentHolderName)
  {
    if ((!StringHelper.isEmpty(emsName)) && (!StringHelper.isEmpty(oltName)) && (!StringHelper.isEmpty(equipmentHolderName))) {
      return new StringBuilder().append(makeOltFdnByNames(emsName, oltName)).append(":").append("EquipmentHolder=").append(equipmentHolderName).toString();
    }
    return "";
  }

  public static String makeOltHolderFdn(String oltFdn, String equipmentHolderName)
  {
    if ((!StringHelper.isEmpty(oltFdn)) && (!StringHelper.isEmpty(equipmentHolderName))) {
      return new StringBuilder().append(oltFdn).append(":").append("EquipmentHolder=").append(equipmentHolderName).toString();
    }
    return "";
  }

  public static String makeOnuHolderFdn(String emsName, String oltName, String onuName, String equipmentHolderName)
  {
    if ((!StringHelper.isEmpty(emsName)) && (!StringHelper.isEmpty(oltName)) && (!StringHelper.isEmpty(onuName)) && (!StringHelper.isEmpty(equipmentHolderName))) {
      return new StringBuilder().append(makeOnuFdnByNames(emsName, oltName, onuName)).append(":").append("EquipmentHolder=").append(equipmentHolderName).toString();
    }
    return "";
  }

  public static String makeOnuHolderFdn(String onuFdn, String equipmentHolderName)
  {
    if ((!StringHelper.isEmpty(onuFdn)) && (!StringHelper.isEmpty(equipmentHolderName))) {
      return new StringBuilder().append(onuFdn).append(":").append("EquipmentHolder=").append(equipmentHolderName).toString();
    }
    return "";
  }

  public static String makePosHolderFdn(String emsName, String oltName, String posName, String equipmentHolderName)
  {
    if ((!StringHelper.isEmpty(emsName)) && (!StringHelper.isEmpty(oltName)) && (!StringHelper.isEmpty(posName)) && (!StringHelper.isEmpty(equipmentHolderName))) {
      return new StringBuilder().append(makePosFdnByNames(emsName, oltName, posName)).append(":").append("EquipmentHolder=").append(equipmentHolderName).toString();
    }
    return "";
  }

  public static String makePosHolderFdn(String posFdn, String equipmentHolderName)
  {
    if ((!StringHelper.isEmpty(posFdn)) && (!StringHelper.isEmpty(equipmentHolderName))) {
      return new StringBuilder().append(posFdn).append(":").append("EquipmentHolder=").append(equipmentHolderName).toString();
    }
    return "";
  }

  public static String makeOltCardFdn(String emsName, String oltname, String equipmentHolderName, String equipment)
  {
    if ((!StringHelper.isEmpty(emsName)) && (!StringHelper.isEmpty(oltname)) && (!StringHelper.isEmpty(equipmentHolderName)))
    {
      if (StringHelper.isEmpty(equipment)) {
        equipment = "1";
      }
      return new StringBuilder().append(makeOltFdnByNames(emsName, oltname)).append(":").append("EquipmentHolder=").append(equipmentHolderName).append(":").append("Equipment=").append(equipment).toString();
    }
    return "";
  }

  public static String makeOltCardFdn(String OltFdn, String equipmentHolderName, String equipment)
  {
    if ((!StringHelper.isEmpty(OltFdn)) && (!StringHelper.isEmpty(equipmentHolderName)))
    {
      if (StringHelper.isEmpty(equipment)) {
        equipment = "1";
      }
      return new StringBuilder().append(OltFdn).append(":").append("EquipmentHolder=").append(equipmentHolderName).append(":").append("Equipment=").append(equipment).toString();
    }
    return "";
  }

  public static String makeOnuCardFdn(String emsName, String oltName, String onuName, String equipmentHolderName, String equipment)
  {
    if ((!StringHelper.isEmpty(emsName)) && (!StringHelper.isEmpty(oltName)) && (!StringHelper.isEmpty(onuName)) && (!StringHelper.isEmpty(equipmentHolderName)))
    {
      if (StringHelper.isEmpty(equipment)) {
        equipment = "1";
      }
      return new StringBuilder().append(makeOnuFdnByNames(emsName, oltName, onuName)).append(":").append("EquipmentHolder=").append(equipmentHolderName).append(":").append("Equipment=").append(equipment).toString();
    }
    return "";
  }

  public static String makeOnuCardFdn(String onuFdn, String equipmentHolderName, String equipment)
  {
    if ((!StringHelper.isEmpty(onuFdn)) && (!StringHelper.isEmpty(equipmentHolderName)))
    {
      if (StringHelper.isEmpty(equipment)) {
        equipment = "1";
      }
      return new StringBuilder().append(onuFdn).append(":").append("EquipmentHolder=").append(equipmentHolderName).append(":").append("Equipment=").append(equipment).toString();
    }
    return "";
  }

  public static String makePosCardFdn(String emsName, String oltName, String posName, String equipmentHolderName, String equipment)
  {
    if ((!StringHelper.isEmpty(emsName)) && (!StringHelper.isEmpty(oltName)) && (!StringHelper.isEmpty(posName)) && (!StringHelper.isEmpty(equipmentHolderName)))
    {
      if (StringHelper.isEmpty(equipment)) {
        equipment = "1";
      }
      return new StringBuilder().append(makePosFdnByNames(emsName, oltName, posName)).append(":").append("EquipmentHolder=").append(equipmentHolderName).append(":").append("Equipment=").append(equipment).toString();
    }
    return "";
  }

  public static String makePosCardFdn(String posFdn, String equipmentHolderName, String equipment)
  {
    if ((!StringHelper.isEmpty(posFdn)) && (!StringHelper.isEmpty(equipmentHolderName)))
    {
      if (StringHelper.isEmpty(equipment)) {
        equipment = "1";
      }
      return new StringBuilder().append(posFdn).append(":").append("EquipmentHolder=").append(equipmentHolderName).append(":").append("Equipment=").append(equipment).toString();
    }
    return "";
  }

  public static String makeOltPortFdn(String emsName, String oltName, String portName)
  {
    if ((!StringHelper.isEmpty(emsName)) && (!StringHelper.isEmpty(oltName)) && (!StringHelper.isEmpty(portName))) {
      return new StringBuilder().append(makeOltFdnByNames(emsName, oltName)).append(":").append("PTP=").append(portName).toString();
    }
    return "";
  }

  public static String makeOltPortFdnByPortInfo(String oltFdn, String ponPortInfo)
  {
    if ((!StringHelper.isEmpty(oltFdn)) && (!StringHelper.isEmpty(ponPortInfo)))
    {
      String[] port = ponPortInfo.split("-");
      if ((port != null) && (port.length == 4)) {
        return new StringBuilder().append(oltFdn).append(":").append("PTP=").append("/").append("rack=").append(port[0]).append("/").append("shelf=").append(port[1]).append("/").append("slot=").append(port[2]).append("/").append("port=").append(port[3]).toString();
      }

      return "";
    }

    return "";
  }

  public static String makeOltPortFdn(String oltFdn, String portName)
  {
    if ((!StringHelper.isEmpty(oltFdn)) && (!StringHelper.isEmpty(portName))) {
      return new StringBuilder().append(oltFdn).append(":").append("PTP=").append(portName).toString();
    }
    return "";
  }

  public static String makeOnuPortFdn(String emsName, String oltName, String onuName, String portName)
  {
    if ((!StringHelper.isEmpty(emsName)) && (!StringHelper.isEmpty(oltName)) && (!StringHelper.isEmpty(onuName)) && (!StringHelper.isEmpty(portName))) {
      return new StringBuilder().append(makeOnuFdnByNames(emsName, oltName, onuName)).append(":").append("PTP=").append(portName).toString();
    }
    return "";
  }

  public static String makeOnuPortFdn(String onuFdn, String portName)
  {
    if ((!StringHelper.isEmpty(onuFdn)) && (!StringHelper.isEmpty(portName))) {
      return new StringBuilder().append(onuFdn).append(":").append("PTP=").append(portName).toString();
    }
    return "";
  }

  public static String makePosPortFdn(String emsName, String oltName, String posName, String portName)
  {
    if ((!StringHelper.isEmpty(emsName)) && (!StringHelper.isEmpty(oltName)) && (!StringHelper.isEmpty(posName)) && (!StringHelper.isEmpty(portName))) {
      return new StringBuilder().append(makePosFdnByNames(emsName, oltName, posName)).append(":").append("PTP=").append(portName).toString();
    }
    return "";
  }

  public static String makePosPortFdn(String posFdn, String portName)
  {
    if ((!StringHelper.isEmpty(posFdn)) && (!StringHelper.isEmpty(portName))) {
      return new StringBuilder().append(posFdn).append(":").append("PTP=").append(portName).toString();
    }
    return "";
  }

  public static String getEmsFdnByStr(String souFdn)
  {
    if (souFdn == null) {
      return null;
    }
    int emsPlace = souFdn.indexOf("EMS=");
    String[] fdnBuf = souFdn.split(":");
    if (emsPlace < 0) {
      return new StringBuilder().append("EMS=").append(souFdn).toString();
    }
    return fdnBuf[0];
  }

  public static String getEmsNameByStr(String souFdn)
  {
    if (souFdn == null) {
      return null;
    }
    int emsPlace = souFdn.indexOf("EMS=");
    String[] fdnBuf = souFdn.split(":");
    if (emsPlace < 0) {
      return souFdn;
    }
    String[] emsName = fdnBuf[0].split("=");
    return emsName[1];
  }

  public static String getMeFdnByStr(String souFdn, String header)
  {
    if (souFdn == null) {
      return null;
    }
    if (StringHelper.isEmpty(header)) {
      return null;
    }
    if (souFdn.indexOf(header) < 0) {
      return null;
    }
    String[] fdnBuf = souFdn.split(":");
    if ("ManagedElement=".equals(header)) {
      if (fdnBuf.length >= 2)
        return new StringBuilder().append(fdnBuf[0]).append(":").append(fdnBuf[1]).toString();
    }
    else if ("ONU=".equals(header)) {
      if (fdnBuf.length >= 3)
        return new StringBuilder().append(fdnBuf[0]).append(":").append(fdnBuf[1]).append(":").append(fdnBuf[2]).toString();
    }
    else if ("POS=".equals(header))
    {
      if (souFdn.indexOf("EquipmentHolder=") > -1)
      {
        return souFdn.substring(0, souFdn.indexOf("EquipmentHolder=") - 1);
      }if (souFdn.indexOf("PTP=") > -1)
      {
        return souFdn.substring(0, souFdn.indexOf("PTP=") - 1);
      }
      return souFdn;
    }

    return null;
  }

  public static int getSlotNumByStr(String souFdn) {
    int slotNum = -1;
    if (souFdn != null) {
      int place = souFdn.indexOf("/slot=");
      if (place > -1) {
        place++;
        int endIndex = souFdn.indexOf(":", place);
        String[] fdnBuf;
        String[] fdnBuf;
        if (endIndex >= 0)
          fdnBuf = souFdn.substring(place, endIndex).split("/");
        else {
          fdnBuf = souFdn.substring(place).split("/");
        }
        String[] rackBuf = fdnBuf[0].split("=");
        if (rackBuf.length >= 2) {
          slotNum = new Integer(rackBuf[1]).intValue();
        }
      }
    }
    return slotNum;
  }

  public static int getPortNumByStr(String souFdn) {
    int slotNum = -1;
    if (souFdn != null) {
      int place = souFdn.indexOf("/port=");
      if (place > -1) {
        place++;
        int endIndex = souFdn.indexOf(":", place);
        String[] fdnBuf;
        String[] fdnBuf;
        if (endIndex >= 0)
          fdnBuf = souFdn.substring(place, endIndex).split("/");
        else {
          fdnBuf = souFdn.substring(place).split("/");
        }
        String[] rackBuf = fdnBuf[0].split("=");
        if (rackBuf.length >= 2) {
          slotNum = new Integer(rackBuf[1]).intValue();
        }
      }
    }
    return slotNum;
  }

  public static int getShelfNumByStr(String souFdn) {
    int shelfNum = -1;
    if (souFdn != null) {
      int place = souFdn.indexOf("/shelf=");
      if (place > -1) {
        place++;
        int endIndex = souFdn.indexOf(":", place);
        String[] fdnBuf;
        String[] fdnBuf;
        if (endIndex >= 0)
          fdnBuf = souFdn.substring(place, endIndex).split("/");
        else {
          fdnBuf = souFdn.substring(place).split("/");
        }
        String[] rackBuf = fdnBuf[0].split("=");
        if (rackBuf.length >= 2) {
          shelfNum = new Integer(rackBuf[1]).intValue();
        }
      }
    }
    return shelfNum;
  }

  public static String getMeFdnByPtpFdn(String ptpFdn) {
    if (ptpFdn == null) {
      return null;
    }
    if (ptpFdn.indexOf("PTP=") < 0) {
      return null;
    }
    String[] fdnBuf = ptpFdn.split(":PTP=");
    if ((fdnBuf != null) && (fdnBuf.length == 2)) {
      return fdnBuf[0];
    }
    return null;
  }

  public static String getCardFdnByPtpFdn(String ptpFdn)
  {
    if (ptpFdn == null) {
      return null;
    }
    if (ptpFdn.indexOf("PTP=") < 0) {
      return null;
    }
    String[] fdnBuf = ptpFdn.split(":PTP=");
    if ((fdnBuf != null) && (fdnBuf.length == 2)) {
      String meFdn = fdnBuf[0];
      if ((!StringHelper.isEmpty(meFdn)) && (!StringHelper.isEmpty(fdnBuf[1]))) {
        fdnBuf = fdnBuf[1].split("/port=");
        if ((fdnBuf != null) && (fdnBuf.length == 2)) {
          String holderLocation = fdnBuf[0];
          if (holderLocation.indexOf("domain") > -1)
          {
            int holderPlace = holderLocation.indexOf("/domain");
            holderLocation = holderLocation.substring(0, holderPlace);
          }
          return new StringBuilder().append(meFdn).append(":").append("EquipmentHolder=").append(holderLocation).append(":").append("Equipment=").append("1").toString();
        }
      }
    }
    return null;
  }

  public static String getEquipmentHolderFdnByCardFdn(String cardFdn) {
    if (StringHelper.isEmpty(cardFdn)) {
      return null;
    }
    if (cardFdn.indexOf("Equipment=") < 0) {
      return null;
    }
    String[] fdnBuf = cardFdn.split(":Equipment=");
    if ((fdnBuf != null) && (fdnBuf.length == 2)) {
      return fdnBuf[0];
    }
    return null;
  }

  public static String getDefalutEquipmentHolderStr(String rack)
  {
    if (StringHelper.isEmpty(rack)) {
      return null;
    }
    return new StringBuilder().append(rack).append("/").append("shelf=").append("1").append("/").append("slot=").append("1").toString();
  }

  public static String getPortFdnByStr(String souFdn) {
    if (StringHelper.isEmpty(souFdn)) {
      return null;
    }
    if (souFdn.indexOf("PTP=") < 0) {
      return null;
    }
    String[] fdnBuf = souFdn.split("PTP=");
    if ((fdnBuf != null) && (fdnBuf.length >= 2)) {
      String temp = fdnBuf[1];
      if (!StringHelper.isEmpty(temp)) {
        String[] tempArray = temp.split(":");
        if (tempArray != null) {
          if (tempArray.length > 1) {
            return new StringBuilder().append(fdnBuf[0]).append("PTP=").append(tempArray[0]).toString();
          }
          return new StringBuilder().append(fdnBuf[0]).append("PTP=").append(fdnBuf[1]).toString();
        }
      }
    }
    return null;
  }

  public static String getEquitFdnByStr(String souFdn)
  {
    if (souFdn == null) {
      return null;
    }
    String neFdn = "";
    if (souFdn.indexOf("ONU=") > 0)
      neFdn = getMeFdnByStr(souFdn, "ONU=");
    else if (souFdn.indexOf("POS=") > 0)
      neFdn = getMeFdnByStr(souFdn, "POS=");
    else {
      neFdn = getMeFdnByStr(souFdn, "ManagedElement=");
    }
    StringBuilder holderFdnBuffer = new StringBuilder();
    String tmpFdn = souFdn.substring(neFdn.length());
    int nePlace = tmpFdn.indexOf("Equipment=");
    String[] fdnBuf = tmpFdn.split(":");
    if (nePlace < 0)
    {
      int ptpPlace = souFdn.indexOf("PTP=");
      int ftpPlace = souFdn.indexOf("FTP=");
      if ((ptpPlace < 0) && (ftpPlace < 0)) {
        return null;
      }
      holderFdnBuffer.append(neFdn);
      holderFdnBuffer.append(":");
      String[] ptp = fdnBuf[1].split("=", 2);
      holderFdnBuffer.append("EquipmentHolder=");
      int portplace;
      int portplace;
      if (ptp[1].indexOf("domain") < 0)
        portplace = ptp[1].indexOf("/port");
      else {
        portplace = ptp[1].indexOf("/domain");
      }
      holderFdnBuffer.append(ptp[1].substring(0, portplace));
      holderFdnBuffer.append(":");
      holderFdnBuffer.append("Equipment=1");
      return holderFdnBuffer.toString();
    }

    if (fdnBuf.length >= 3) {
      holderFdnBuffer.append(neFdn);
      holderFdnBuffer.append(":");
      holderFdnBuffer.append(fdnBuf[1]);
      holderFdnBuffer.append(":");
      holderFdnBuffer.append(fdnBuf[2]);
    } else {
      holderFdnBuffer.setLength(0);
    }
    return holderFdnBuffer.toString();
  }

  public static String getNeHolderFdnByStr(String souFdn)
  {
    if (souFdn == null) {
      return null;
    }
    String neFdn = "";
    if (souFdn.indexOf("ONU=") > 0)
      neFdn = getMeFdnByStr(souFdn, "ONU=");
    else if (souFdn.indexOf("POS=") > 0)
      neFdn = getMeFdnByStr(souFdn, "POS=");
    else {
      neFdn = getMeFdnByStr(souFdn, "ManagedElement=");
    }
    StringBuilder holderFdnBuffer = new StringBuilder();
    String tmpFdn = souFdn.substring(neFdn.length());
    int nePlace = tmpFdn.indexOf("EquipmentHolder=");
    String[] fdnBuf = tmpFdn.split(":");
    if (nePlace < 0) {
      int ptpPlace = souFdn.indexOf("PTP=");
      int ftpPlace = souFdn.indexOf("FTP=");
      if ((ptpPlace < 0) && (ftpPlace < 0)) {
        return null;
      }
      holderFdnBuffer.append(neFdn);
      holderFdnBuffer.append(":");
      String[] ptp = fdnBuf[1].split("=", 2);
      holderFdnBuffer.append("EquipmentHolder=");
      int portplace = 0;
      if (ptp[1].indexOf("domain") < 0)
        portplace = ptp[1].indexOf("/port");
      else {
        portplace = ptp[1].indexOf("/domain");
      }
      holderFdnBuffer.append(ptp[1].substring(0, portplace));
    }
    else {
      holderFdnBuffer.append(neFdn);
      holderFdnBuffer.append(":");
      holderFdnBuffer.append(fdnBuf[1]);
    }
    return holderFdnBuffer.toString();
  }

  public static String getPortIdByPtpFdn(String ptpFdn) {
    if ((StringHelper.isEmpty(ptpFdn)) || (ptpFdn.indexOf("PTP=") < 0)) {
      return null;
    }
    String[] fdnBuf = ptpFdn.split("PTP=");
    if ((fdnBuf != null) && (fdnBuf.length == 2)) {
      String portId = fdnBuf[1];
      if (!StringHelper.isEmpty(portId)) {
        if (portId.indexOf("domain") > -1)
        {
          portId = new StringBuilder().append(portId.substring(0, portId.indexOf("/domain"))).append(portId.substring(portId.indexOf("/port"), portId.length())).toString();
        }
        fdnBuf = portId.split("/");
        if ((fdnBuf != null) && (fdnBuf.length == 5) && (!StringHelper.isEmpty(fdnBuf[1])) && (fdnBuf[1].indexOf("rack=") > -1) && (!StringHelper.isEmpty(fdnBuf[2])) && (fdnBuf[2].indexOf("shelf=") > -1) && (!StringHelper.isEmpty(fdnBuf[3])) && (fdnBuf[3].indexOf("slot=") > -1) && (!StringHelper.isEmpty(fdnBuf[4])) && (fdnBuf[4].indexOf("port=") > -1))
        {
          StringBuilder sb = new StringBuilder();
          String[] rackArray = fdnBuf[1].split("=");
          if (rackArray[1].contains("-"))
            sb.append("NA-");
          else {
            sb.append(new StringBuilder().append(fdnBuf[1].split("=")[1]).append("-").toString());
          }
          if (fdnBuf[2].split("=")[1].contains("-"))
            sb.append("NA-");
          else {
            sb.append(new StringBuilder().append(fdnBuf[2].split("=")[1]).append("-").toString());
          }
          if (fdnBuf[3].split("=")[1].contains("-"))
            sb.append("NA-");
          else {
            sb.append(new StringBuilder().append(fdnBuf[3].split("=")[1]).append("-").toString());
          }
          sb.append(fdnBuf[4].split("=")[1]);
          return sb.toString();
        }
      }
    }
    return null;
  }

  public static String getPortFdnByCardFdnAndPortNo(String cardFdn, int portNo)
  {
    String portFdn = "";
    if (!StringHelper.isEmpty(cardFdn)) {
      int holderIndex = cardFdn.indexOf("EquipmentHolder=");
      int cardIndex = cardFdn.indexOf("Equipment=");
      if ((holderIndex > -1) && (cardIndex > -1)) {
        String neFdn = cardFdn.substring(0, holderIndex);
        String holderInfo = cardFdn.substring(holderIndex, cardIndex - 1);
        portFdn = new StringBuilder().append(neFdn).append("PTP=").append(holderInfo.substring("EquipmentHolder=".length())).append("/").append("port=").append(portNo).toString();
      }

    }

    return portFdn;
  }

  public static String replacePonMeFdn(String sourceFdn)
  {
    try
    {
      if ((StringHelper.isEmpty(sourceFdn)) || (sourceFdn.indexOf("ManagedElement=") < 0)) {
        return null;
      }
      String[] tempArray = sourceFdn.split(":");
      if ((sourceFdn.indexOf("POS=") > -1) || (sourceFdn.indexOf("ONU=") > -1))
      {
        if ((tempArray != null) && (tempArray.length >= 3) && 
          (!StringHelper.isEmpty(tempArray[2])) && (
          (tempArray[2].indexOf("POS=") > -1) || (sourceFdn.indexOf("ONU=") > -1))) {
          String[] meStr = tempArray[2].split("=");
          if ((meStr != null) && (!StringHelper.isEmpty(meStr[1]))) {
            return makeOltFdn(tempArray[0], meStr[1]);
          }
        }
      }
      else if (sourceFdn.indexOf("ManagedElement=") > -1)
      {
        if ((tempArray != null) && (tempArray.length >= 2))
          return new StringBuilder().append(tempArray[0]).append(":").append(tempArray[1]).toString();
      }
      else
        return null;
    }
    catch (Exception ex)
    {
      LogHome.getLog().error(new StringBuilder().append("转换传输FDN失败,").append(sourceFdn).append(ex).toString());
    }
    return null;
  }
}