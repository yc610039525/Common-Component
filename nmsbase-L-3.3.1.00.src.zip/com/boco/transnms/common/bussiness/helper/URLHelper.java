package com.boco.transnms.common.bussiness.helper;

import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

public class URLHelper
{
  public static String getUrlMap(HttpServletRequest request)
  {
    String WEB_HOSTIP = request.getHeader("Host");
    return WEB_HOSTIP.split(":")[0];
  }

  public static Map getUrlMap(HttpServletRequest request, String urlKey)
  {
    String WEB_HOSTIP = request.getHeader("Host");
    Map urlMap = new HashMap();
    urlMap.put("hostIP", WEB_HOSTIP.split(":")[0]);
    urlMap.put("urlKey", urlKey);
    return urlMap;
  }
}