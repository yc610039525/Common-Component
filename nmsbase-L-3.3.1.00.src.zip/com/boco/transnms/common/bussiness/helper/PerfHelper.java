package com.boco.transnms.common.bussiness.helper;

import java.util.zip.CRC32;

public class PerfHelper
{
  public static Long Crc32str(String str)
  {
    CRC32 crc = new CRC32();
    crc.update(str.getBytes());
    return Long.valueOf(crc.getValue());
  }
}