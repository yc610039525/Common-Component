package com.boco.transnms.common.bussiness.helper;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.Ddfport;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.misc.LogicDfPort;
import java.util.ArrayList;
import java.util.List;

public class JumperHelper
{
  public static List getRelationDdfports(String ddfPortLabelCn, DataObjectList ddfPorts)
  {
    List relationDdfports = ddfPorts.getObjectByAttr("LABEL_CN", ddfPortLabelCn);
    return relationDdfports;
  }

  public static Ddfport getDdfport(String cuid, List ddfPorts) {
    if (ddfPorts != null) {
      for (int i = 0; i < ddfPorts.size(); i++) {
        GenericDO dbo = (GenericDO)ddfPorts.get(i);
        if (((dbo instanceof Ddfport)) && (dbo.getCuid().equals(cuid))) {
          return (Ddfport)dbo;
        }
      }
    }
    return null;
  }

  public static Ddfport popDdfport(String cuid, List ddfPorts)
  {
    if (ddfPorts != null) {
      for (int i = ddfPorts.size() - 1; i >= 0; i--) {
        GenericDO dbo = (GenericDO)ddfPorts.get(i);
        if (((dbo instanceof Ddfport)) && (dbo.getCuid().equals(cuid))) {
          ddfPorts.remove(i);
          return (Ddfport)dbo;
        }
      }
    }
    return null;
  }

  public static boolean Validate2RelationDdfPorts(List ddfPorts)
  {
    if (ddfPorts.size() == 2) {
      Ddfport ddfport1 = (Ddfport)ddfPorts.get(0);
      Ddfport ddfport2 = (Ddfport)ddfPorts.get(1);
      if ((ddfport1.getLabelCn().equals(ddfport2.getLabelCn())) && (ddfport1.getCuid().equals(ddfport2.getOppositeDdfportCuid())) && (ddfport2.getCuid().equals(ddfport1.getOppositeDdfportCuid())))
      {
        if ((ddfport1.getNumInMcol() == ddfport2.getNumInMcol()) || (ddfport1.getNumInMrow() == ddfport2.getNumInMrow())) {
          return true;
        }
      }
    }
    return false;
  }

  public static boolean Validate4RelationDdfPorts(List oldddfPorts)
  {
    List ddfPorts = new ArrayList();
    ddfPorts.addAll(oldddfPorts);
    if (ddfPorts.size() == 4) {
      Ddfport ddfport1 = (Ddfport)ddfPorts.get(0);
      Ddfport ddfport2 = (Ddfport)ddfPorts.get(1);
      Ddfport ddfport3 = (Ddfport)ddfPorts.get(2);
      Ddfport ddfport4 = (Ddfport)ddfPorts.get(3);
      if ((ddfport1.getLabelCn().equals(ddfport2.getLabelCn())) && (ddfport2.getLabelCn().equals(ddfport3.getLabelCn())) && (ddfport3.getLabelCn().equals(ddfport4.getLabelCn())))
      {
        popDdfport(ddfport1.getCuid(), ddfPorts);
        Ddfport oppositeDdfport1 = popDdfport(ddfport1.getOppositeDdfportCuid(), ddfPorts);
        if (oppositeDdfport1 != null) {
          if (ddfport1.getNumInMcol() == oppositeDdfport1.getNumInMcol()) {
            Ddfport tempPort1 = (Ddfport)ddfPorts.get(0);
            Ddfport tempPort2 = (Ddfport)ddfPorts.get(1);
            if ((tempPort1.getCuid().equals(tempPort2.getOppositeDdfportCuid())) && (tempPort2.getCuid().equals(tempPort1.getOppositeDdfportCuid())) && (tempPort1.getNumInMcol() == tempPort2.getNumInMcol()))
            {
              return true;
            }
          } else {
            Ddfport tempPort1 = (Ddfport)ddfPorts.get(0);
            Ddfport tempPort2 = (Ddfport)ddfPorts.get(1);
            if ((tempPort1.getCuid().equals(tempPort2.getOppositeDdfportCuid())) && (tempPort2.getCuid().equals(tempPort1.getOppositeDdfportCuid())) && (tempPort1.getNumInMrow() == tempPort2.getNumInMrow()))
            {
              return true;
            }
          }
        }
      }
    }
    return false;
  }

  public static LogicDfPort getLogicDfPort(String startOdfportCuid, DataObjectList allDdfPortsInMod)
    throws UserException
  {
    Ddfport port = getDdfport(startOdfportCuid, allDdfPortsInMod);
    List ddfPorts = getRelationDdfports(port.getLabelCn(), allDdfPortsInMod);
    if ((ddfPorts.size() == 2) && (Validate2RelationDdfPorts(ddfPorts))) {
      LogicDfPort logicDfPort = new LogicDfPort();
      Ddfport ddfport = popDdfport(startOdfportCuid, ddfPorts);
      logicDfPort.setUpLeftDdfPort(ddfport);
      Ddfport oppsiteDdfport = popDdfport(ddfport.getOppositeDdfportCuid(), ddfPorts);
      logicDfPort.setUpRightDdfPort(oppsiteDdfport);
      return logicDfPort;
    }if ((ddfPorts.size() == 4) && (Validate4RelationDdfPorts(ddfPorts))) {
      LogicDfPort logicDfPort = new LogicDfPort();
      Ddfport ddfport = popDdfport(startOdfportCuid, ddfPorts);
      logicDfPort.setUpLeftDdfPort(ddfport);
      Ddfport oppsiteDdfport = popDdfport(ddfport.getOppositeDdfportCuid(), ddfPorts);
      if (oppsiteDdfport != null)
      {
        Ddfport downPort1 = (Ddfport)ddfPorts.get(0);
        Ddfport downPort2 = (Ddfport)ddfPorts.get(1);
        if (oppsiteDdfport.getNumInMcol() == ddfport.getNumInMcol()) {
          logicDfPort.setUpRightDdfPort(oppsiteDdfport);
          if ((downPort1.getNumInMrow() == ddfport.getNumInMrow()) && (!downPort1.getIsConnected())) {
            logicDfPort.setDownLeftDdfPort(downPort1);
            logicDfPort.setDownRightDdfPort(downPort2);
          } else if ((downPort2.getNumInMrow() == ddfport.getNumInMrow()) && (!downPort2.getIsConnected())) {
            logicDfPort.setDownRightDdfPort(downPort1);
            logicDfPort.setDownLeftDdfPort(downPort2);
          }
        } else if (oppsiteDdfport.getNumInMrow() == ddfport.getNumInMrow()) {
          logicDfPort.setUpRightDdfPort(oppsiteDdfport);
          if ((downPort1.getNumInMcol() == ddfport.getNumInMcol()) && (!downPort1.getIsConnected())) {
            logicDfPort.setDownLeftDdfPort(downPort1);
            logicDfPort.setDownRightDdfPort(downPort2);
          } else if ((downPort2.getNumInMcol() == ddfport.getNumInMcol()) && (!downPort2.getIsConnected())) {
            logicDfPort.setDownRightDdfPort(downPort1);
            logicDfPort.setDownLeftDdfPort(downPort2);
          }
        }
      }
      return logicDfPort;
    }
    throw new UserException("端子连接关系异常！");
  }
}