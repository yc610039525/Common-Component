package com.boco.transnms.common.bussiness.helper;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.bussiness.consts.NetEnum;
import com.boco.transnms.common.bussiness.consts.NetEnum.SysProjectType;
import com.boco.transnms.common.bussiness.consts.RackEnum;
import com.boco.transnms.common.bussiness.consts.RackEnum.Rate;
import com.boco.transnms.common.bussiness.consts.TraphEnum;
import com.boco.transnms.common.bussiness.consts.TraphEnum.TraphRate;
import com.boco.transnms.common.dto.Ctp;
import com.boco.transnms.common.dto.District;
import com.boco.transnms.common.dto.PdhSystem;
import com.boco.transnms.common.dto.SdhSystem;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.dm.LocatedPoint;
import com.boco.transnms.common.dto.misc.ElementPic;
import com.boco.transnms.server.dao.base.DaoHelper;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import org.apache.commons.logging.Log;

public class TopoHelper
{
  public static String CHILDREN = "DataChildren";

  public static void getSiteLocation(DataObjectList siteList)
  {
    Vector list = new Vector();

    for (int i = 0; i < siteList.size(); i++) {
      GenericDO site = (GenericDO)siteList.get(i);
      site.setAttrValue("topomapx", String.valueOf(0));
      site.setAttrValue("topomapy", String.valueOf(0));
    }

    for (int i = 0; i < siteList.size(); i++) {
      GenericDO site = (GenericDO)siteList.get(i);
      Object obj = site.getAttrValue("LONGITUDE");
      if ((obj != null) && ((obj instanceof Double))) {
        list.add(new SortedSite(site, site.getAttrDouble("LONGITUDE")));
      }
    }
    Collections.sort(list);
    int i = 0;
    Iterator it = list.iterator();
    while (it.hasNext()) {
      GenericDO site = ((SortedSite)it.next()).getSite();
      site.setAttrValue("topomapx", String.valueOf(i++));
    }

    list = new Vector();
    for (i = 0; i < siteList.size(); i++) {
      GenericDO site = (GenericDO)siteList.get(i);
      Object obj = site.getAttrValue("LATITUDE");
      if ((obj != null) && ((obj instanceof Double))) {
        list.add(new SortedSite(site, site.getAttrDouble("LATITUDE")));
      }
    }
    Collections.sort(list);
    int len = list.size();
    i = 0;
    it = list.iterator();
    while (it.hasNext()) {
      GenericDO site = ((SortedSite)it.next()).getSite();
      site.setAttrValue("topomapy", String.valueOf(len - 1 - i++));
    }
  }

  public static void getSystemVol(DataObjectList sysList)
  {
    if ((sysList == null) || (sysList.isEmpty())) {
      return;
    }
    for (GenericDO gdo : sysList) {
      String className = gdo.getClassName();
      if (className != null)
      {
        if (className.equals("WDM_SYSTEM")) {
          Object num = gdo.getAttrValue("WAVE_NUM");
          Object rate = gdo.getAttrValue("WAVE_RATE");
          if ((num != null) && ((num instanceof Long)) && (rate != null) && ((rate instanceof Long))) {
            String wdmvol = getRateName(((Long)rate).longValue());
            gdo.setAttrValue("VOL", num + "*" + wdmvol);
          }
        } else if (((gdo instanceof SdhSystem)) || ((gdo instanceof PdhSystem))) {
          Object vol = gdo.getAttrValue("VOL");
          if ((vol != null) && ((vol instanceof Long))) {
            String sdhvol = getRateName(((Long)vol).longValue());
            gdo.setAttrValue("VOL", sdhvol);
          }
        }
      }
    }
  }

  public static int getVc4NoByLabel(String label)
  {
    String sNo = "";
    int iNo = 0;
    if (label != null) {
      int iIndex = label.indexOf("/");
      if (iIndex >= 0) {
        label = label.substring(0, iIndex);
      }
      if (label.indexOf("155M") >= 0) {
        sNo = label.substring(4);
      }
      if (sNo.length() > 0) {
        iNo = Integer.valueOf(sNo).intValue();
      }
    }
    return iNo;
  }

  public static int getVc12NoByLabel(String label)
  {
    String sNo = "";
    int iNo = 0;
    if (label != null) {
      int iIndex = label.indexOf("/");
      if (iIndex >= 0) {
        label = label.substring(iIndex + 1);
      }
      if (label.indexOf("2M") >= 0) {
        sNo = label.substring(label.indexOf("2M") + 2);
      }

      if (sNo.length() > 0) {
        iNo = Integer.valueOf(sNo).intValue();
      }
    }
    return iNo;
  }

  public static void setCtpLayerRate(DataObjectList ctpList)
  {
    for (int i = 0; i < ctpList.size(); i++) {
      Ctp ctp = (Ctp)ctpList.get(i);
      int iVc4 = getVc4NoByLabel(ctp.getCtpName());
      int iTu12 = getVc12NoByLabel(ctp.getCtpName());
      int iVc4ed = iVc4 == 0 ? iVc4 + 1 : iVc4;
      int iTu12ed = iTu12 == 0 ? iTu12 + 1 : iTu12;
      int i2MNo = (iVc4ed - 1) * 63 + iTu12ed;
      ctp.setAttrValue("CtpVc4No", Integer.valueOf(iVc4));
      ctp.setAttrValue("CtpVc12No", Integer.valueOf(iTu12));
      ctp.setAttrValue("Ctp2MNum", Integer.valueOf(i2MNo));
    }
    ctpList.sort("Ctp2MNum", true);
  }

  public static GenericDO sortSeg(Object startNode, Object endNode, DataObjectList sortList, String origString, String destString)
  {
    Map origMap = new HashMap();
    Map destMap = new HashMap();
    for (GenericDO gdo : sortList) {
      Object o = gdo.getAttrValue(origString);
      Object d = gdo.getAttrValue(destString);
      if ((o == null) || (d == null)) {
        throw new UserException("CUID:" + gdo.getCuid() + " 的 " + origString + "属性或者 " + destString + " 为空！");
      }
      origMap.put(o, gdo);
      destMap.put(d, gdo);
    }
    GenericDO retDo = null;
    GenericDO endRetDo = null;
    List nodeList = new ArrayList();
    DataObjectList sortCompleteList = new DataObjectList();
    List tempNodeList = null;
    DataObjectList tempSortCompleteList = null;
    if (startNode != null) {
      retDo = sortSeg(startNode, origMap, destMap, origString, destString, true);
      tempNodeList = (List)retDo.getAttrValue("nodeList");
      nodeList.add(startNode);
      nodeList.addAll(tempNodeList);
      tempSortCompleteList = (DataObjectList)retDo.getAttrValue("sortCompleteList");
      sortCompleteList.addAll(tempSortCompleteList);
    }

    if (endNode != null) {
      endRetDo = sortSeg(endNode, origMap, destMap, origString, destString, false);
    }
    GenericDO node = null;
    while ((!origMap.isEmpty()) || (!destMap.isEmpty())) {
      if (!origMap.isEmpty())
        node = (GenericDO)origMap.values().iterator().next();
      else {
        node = (GenericDO)destMap.values().iterator().next();
      }
      retDo = sortSeg(node, origMap, destMap, origString, destString, false);

      tempNodeList = (List)retDo.getAttrValue("nodeList");
      nodeList.addAll(tempNodeList);
      tempSortCompleteList = (DataObjectList)retDo.getAttrValue("sortCompleteList");
      sortCompleteList.addAll(tempSortCompleteList);
      nodeList.add(startNode);
      retDo = sortSeg(node, origMap, destMap, origString, destString, true);
      tempNodeList = (List)retDo.getAttrValue("nodeList");
      nodeList.addAll(tempNodeList);
      tempSortCompleteList = (DataObjectList)retDo.getAttrValue("sortCompleteList");
      sortCompleteList.addAll(tempSortCompleteList);
    }

    if (endRetDo != null) {
      tempNodeList = (List)endRetDo.getAttrValue("nodeList");
      nodeList.addAll(tempNodeList);
      tempSortCompleteList = (DataObjectList)endRetDo.getAttrValue("sortCompleteList");
      sortCompleteList.addAll(tempSortCompleteList);

      if (!tempSortCompleteList.isEmpty()) {
        nodeList.add(endNode);
      }
    }
    endRetDo = null;
    retDo = null;
    retDo = new GenericDO();
    retDo.setAttrValue("nodeList", nodeList);
    retDo.setAttrValue("sortCompleteList", sortCompleteList);
    return retDo;
  }

  private static GenericDO sortSeg(Object node, Map origMap, Map destMap, String origString, String destString, boolean ahead)
  {
    List nodeList = new ArrayList();
    DataObjectList sortCompleteList = new DataObjectList();
    GenericDO gdo = null;
    boolean orig = true;
    while (true) {
      gdo = (GenericDO)origMap.get(node);
      orig = true;
      if (gdo == null) {
        gdo = (GenericDO)destMap.get(node);
        orig = false;
      }
      if (gdo == null)
      {
        break;
      }
      Object next = null;
      if (orig) {
        next = gdo.getAttrValue(destString);
        origMap.remove(node);
        destMap.remove(next);
      } else {
        next = gdo.getAttrValue(origString);
        destMap.remove(node);
        origMap.remove(next);
      }
      if (ahead) {
        nodeList.add(next);
        sortCompleteList.add(gdo);
      } else {
        nodeList.add(0, next);
        sortCompleteList.add(0, gdo);
      }
      System.out.println(next);
      node = next;
    }
    GenericDO rutDo = new GenericDO();
    rutDo.setAttrValue("nodeList", nodeList);
    rutDo.setAttrValue("sortCompleteList", sortCompleteList);
    return rutDo;
  }

  public static Object getFirstNode(GenericDO link1, GenericDO link2, String origString, String destString) {
    Object o = link1.getAttrValue(origString);
    Object d = link1.getAttrValue(destString);
    if ((o == null) || (d == null)) {
      throw new UserException();
    }
    if ((o.equals(link2.getAttrValue(origString))) || (o.equals(link2.getAttrValue(destString))))
    {
      return d;
    }
    return o;
  }

  public static void putListToMap(DataObjectList l, Map m)
  {
    if (l != null)
      for (int i = 0; i < l.size(); i++) {
        GenericDO g = (GenericDO)l.get(i);
        m.put(g.getCuid(), g);
      }
  }

  public static void putAll(List src, List dest)
  {
    if ((src != null) && (dest != null))
      for (int i = 0; i < src.size(); i++)
        dest.add(src.get(i));
  }

  public static boolean isUserMagDistrict(DataObjectList districts, String districtCuid)
  {
    return getOwnerDistrict(districts, districtCuid) != null;
  }

  public static District getOwnerDistrict(DataObjectList districts, String districtCuid) {
    District ownerDistrict = null;
    if (districts != null) {
      for (int i = 0; i < districts.size(); i++) {
        District district = (District)districts.get(i);

        Object isIncludeSubDistrict = district.getAttrValue("IS_INCLUDE_SUB_DISTRICT");
        if ((isIncludeSubDistrict != null) && (Boolean.valueOf(isIncludeSubDistrict.toString()).booleanValue()))
        {
          if (districtCuid.indexOf(district.getCuid()) >= 0) {
            ownerDistrict = district;
            break;
          }
        }
        else if (district.getCuid().equals(districtCuid)) {
          ownerDistrict = district;
          break;
        }
      }
    }

    return ownerDistrict;
  }

  public static void putDboCollectionToList(DboCollection dboCollection, List list, String clazzName) throws Exception {
    for (int j = 0; j < dboCollection.size(); j++) {
      GenericDO dbo = dboCollection.getQueryDbo(j, clazzName);
      list.add(dbo);
    }
  }

  public static Integer compareRate(long rate1, long rate2) {
    if ((rate1 >= 1L) && (rate1 <= 21L) && (rate2 >= 1L) && (rate2 <= 21L)) {
      if (rate1 == rate2)
        return Integer.valueOf(0);
      if (rate1 > rate2)
        return Integer.valueOf(1);
      if (rate1 < rate2)
        return Integer.valueOf(-1);
    }
    else {
      LogHome.getLog().error(" 不支持比较的得速率 枚举值 rate1:" + rate1 + " rate2:" + rate2);
    }
    return null;
  }

  public static long getVc12Count(long rate)
  {
    long vc12 = -1L;
    switch ((int)rate) {
    case 1:
      vc12 = 1L;
      break;
    case 2:
      vc12 = 4L;
      break;
    case 3:
      vc12 = -1L;
      break;
    case 4:
      vc12 = 21L;
      break;
    case 5:
      vc12 = 21L;
      break;
    case 6:
      vc12 = -1L;
      break;
    case 7:
      vc12 = -1L;
      break;
    case 8:
      vc12 = 63L;
      break;
    case 9:
      vc12 = 63L;
      break;
    case 10:
      vc12 = -1L;
      break;
    case 11:
      vc12 = -1L;
      break;
    case 12:
      vc12 = -1L;
      break;
    case 13:
      vc12 = 252L;
      break;
    case 14:
      vc12 = -1L;
      break;
    case 15:
      vc12 = 504L;
      break;
    case 16:
      vc12 = 1008L;
      break;
    case 17:
      vc12 = 4032L;
      break;
    case 19:
      vc12 = 16128L;
      break;
    case 20:
      vc12 = 32256L;
      break;
    case 21:
      vc12 = 48384L;
      break;
    case 18:
    }

    if (vc12 < 0L) {
      LogHome.getLog().error("不支持的速率类型枚举：" + rate);
    }
    return vc12;
  }

  public static long getVc4Count(long rate)
  {
    long vc4Count = -1L;
    long vc12Count = getVc12Count(rate);
    if ((vc12Count > 0L) && (vc12Count % 63L == 0L)) {
      vc4Count = vc12Count / 63L;
    }
    return vc4Count;
  }

  public static String getRateName(long sysVol)
  {
    String rateName = RackEnum.RATR_TYPE.getName(Long.valueOf(sysVol));
    if (rateName == null) {
      return "";
    }
    return rateName;
  }

  public static void setListDtoPropNull(DataObjectList list, String attrName) {
    if (list == null) {
      return;
    }
    for (GenericDO gdo : list)
      gdo.setAttrNull(attrName);
  }

  public static void setListDtoProp(DataObjectList list, String attrName, Object attrValue)
  {
    if (list == null) {
      return;
    }
    for (GenericDO gdo : list)
      if (gdo != null)
      {
        gdo.setAttrValue(attrName, attrValue);
        gdo.setObjectLoadType(1);
        DataObjectList children = getChildren(gdo);
        if ((children != null) && (!children.isEmpty()))
          setListDtoProp(children, attrName, attrValue);
      }
  }

  public static void setListDtoLoadType(DataObjectList list, int attrValue)
  {
    if (list == null) {
      return;
    }
    for (GenericDO gdo : list)
      if (gdo != null)
      {
        gdo.setObjectLoadType(attrValue);
        DataObjectList children = getChildren(gdo);
        if ((children != null) && (!children.isEmpty()))
          setListDtoLoadType(children, attrValue);
      }
  }

  public static void setElementLocation(HashMap neMap, List picElements)
  {
    for (int i = 0; i < picElements.size(); i++)
      if ((picElements.get(i) instanceof ElementPic)) {
        ElementPic picElement = (ElementPic)picElements.get(i);
        GenericDO neObj = (GenericDO)neMap.get(picElement.getCuid());
        if (neObj != null) {
          neObj.setAttrValue("topomapx", String.valueOf(picElement.getX()));
          neObj.setAttrValue("topomapy", String.valueOf(picElement.getY()));
        }
      }
  }

  public static Map<Object, DataObjectList> getListMapByAttribute(DataObjectList list)
  {
    Map map = new HashMap();
    putListToMapByAttribute(list, map);
    return map;
  }

  public static void putListToMapByAttribute(DataObjectList list, Map<Object, DataObjectList> map) {
    Map dtoMap = new HashMap();
    for (GenericDO gdo : list) {
      Object key = gdo;
      if ((key instanceof GenericDO)) {
        String cuid = ((GenericDO)key).getCuid();
        dtoMap.put(cuid, (GenericDO)key);
        key = cuid;
      }
      DataObjectList mList = (DataObjectList)map.get(key);
      if (mList == null) {
        mList = new DataObjectList();
        map.put(key, mList);
      }
      mList.add(gdo);
    }
    if (!dtoMap.isEmpty())
      for (String cuid : dtoMap.keySet()) {
        DataObjectList tempList = (DataObjectList)map.remove(cuid);
        map.put(cuid, tempList);
      }
  }

  public static Map<Object, DataObjectList> getListMapByAttr(DataObjectList list, String attrName)
  {
    Map map = new HashMap();
    putListToMapByAttr(list, map, attrName);
    return map;
  }

  public static void putListToMapByAttr(DataObjectList list, Map<Object, DataObjectList> map, String attrName) {
    Map dtoMap = new HashMap();
    for (GenericDO gdo : list)
    {
      Object key = gdo.getAttrValue(attrName);
      if ((key instanceof GenericDO)) {
        String cuid = ((GenericDO)key).getCuid();
        dtoMap.put(cuid, (GenericDO)key);
        key = cuid;
      }
      DataObjectList mList = (DataObjectList)map.get(key);
      if (mList == null) {
        mList = new DataObjectList();
        map.put(key, mList);
      }
      mList.add(gdo);
    }
    if (!dtoMap.isEmpty())
      for (String cuid : dtoMap.keySet()) {
        DataObjectList tempList = (DataObjectList)map.remove(cuid);

        map.put(dtoMap.get(cuid), tempList);
      }
  }

  public static DataObjectList getChildren(GenericDO gdo)
  {
    DataObjectList childs = (DataObjectList)gdo.getAttrValue(CHILDREN);
    if (childs == null) {
      childs = new DataObjectList();
      gdo.setAttrValue(CHILDREN, childs);
    }
    return childs;
  }

  public static void setChildren(GenericDO gdo, DataObjectList childs) {
    if (childs == null)
      gdo.removeAttr(CHILDREN);
    else
      gdo.setAttrValue(CHILDREN, childs);
  }

  public static DataObjectList getAllLeafChildren(DataObjectList dataList)
  {
    DataObjectList list = new DataObjectList();
    for (GenericDO childDbo : dataList) {
      list.addAll(getAllLeafChildren(childDbo));
    }
    return list;
  }

  public static DataObjectList getContinuousDtoByAttr(DataObjectList dols, String attrName)
  {
    if ((dols == null) || (dols.isEmpty())) {
      return new DataObjectList();
    }
    DataObjectList rList = new DataObjectList();
    GenericDO dto = (GenericDO)dols.get(0);
    Object value = dto.getAttrValue(attrName);
    GenericDO propertyDto = new GenericDO();
    rList.add(propertyDto);
    propertyDto.setAttrValue(attrName, value);
    getChildren(propertyDto).add(dto);
    for (int i = 1; i < dols.size(); i++) {
      GenericDO gdo = (GenericDO)dols.get(i);
      Object key = gdo.getAttrValue(attrName);
      if (((key == null) && (value == null)) || ((key != null) && (key.equals(value)))) {
        getChildren(propertyDto).add(gdo);
      } else {
        value = key;
        propertyDto = new GenericDO();
        rList.add(propertyDto);
        propertyDto.setAttrValue(attrName, value);
        getChildren(propertyDto).add(gdo);
      }
    }
    return rList;
  }

  public static DataObjectList getAllLeafChildren(GenericDO gdo)
  {
    DataObjectList list = new DataObjectList();
    DataObjectList childs = (DataObjectList)gdo.getAttrValue(CHILDREN);
    if ((childs == null) || (childs.isEmpty()))
      list.add(gdo);
    else {
      for (GenericDO childDbo : childs) {
        list.addAll(getAllLeafChildren(childDbo));
      }
    }
    return list;
  }

  public static boolean isAttrsEqual(GenericDO gdo1, GenericDO gdo2, String[] attrNames) {
    for (String attrName : attrNames) {
      Object o1 = gdo1.getAttrValue(attrName);
      Object o2 = gdo2.getAttrValue(attrName);
      if (!isEqual(o1, o2)) {
        return false;
      }
    }
    return true;
  }

  public static boolean isEqual(Object o1, Object o2) {
    if ((o1 == null) && (o2 == null)) {
      return true;
    }
    if (o1 != null) {
      return o1.equals(o2);
    }
    return false;
  }

  public static long getVC12Count(String bandwidth, long traphRate)
  {
    long vc12Coutn = 0L;
    try {
      if ((34L != traphRate) && (35L != traphRate)) {
        vc12Coutn = getVc12Count(traphRate);
        if (vc12Coutn == -1L) {
          vc12Coutn = 0L;
        }
      }
      else if (DaoHelper.isNotEmpty(bandwidth)) {
        bandwidth = bandwidth.replaceAll("X", "*");
        bandwidth = bandwidth.replaceAll("x", "*");
        String[] bandwidths = bandwidth.split("\\*");

        if (bandwidths.length == 2) {
          long rate = Long.valueOf(TraphEnum.TRAPH_RATE.getValue(bandwidths[1]).toString()).longValue();
          long count = Long.valueOf(bandwidths[0]).longValue();
          long _vc12Count = getVc12Count(rate);
          vc12Coutn = count * _vc12Count;
        }
      }
    }
    catch (Exception ex) {
      LogHome.getLog().error("电路速率折算2M个数出错:速率枚举[" + traphRate + "],电路带宽[" + bandwidth + "]");
      LogHome.getLog().error("电路速率折算2M个数出错:" + ex);
    }
    return vc12Coutn;
  }

  public static Map<String, GenericDO> getStringMapByAttrs(DataObjectList dbos, String[] attrNames) {
    Map map = new HashMap();
    for (GenericDO gdo : dbos) {
      String key = "";
      for (String attr : attrNames) {
        key = key + DaoHelper.getRelatedCuid(gdo.getAttrValue(attr));
      }

      map.put(key, gdo);
    }
    return map;
  }

  public static Map<Integer, Integer> getVc4ProtectionType(String protectionDetail)
    throws Exception
  {
    Map map = new HashMap();
    if (DaoHelper.isNotEmpty(protectionDetail)) {
      String[] oneProtectionType = protectionDetail.split(";");
      for (int i = 0; i < oneProtectionType.length; i++) {
        String[] str = oneProtectionType[i].split("\\(");
        if (NetEnum.SYS_PROJECT_TYPE_CH.getName(Long.valueOf(str[0])) != null) {
          Integer type = Integer.valueOf(str[0]);
          if ((type.intValue() != 0) && (type.intValue() != 9)) {
            String vc4s = str[1].substring(0, str[1].length() - 1);
            String newVc4s = getUnMergerStr(vc4s);
            List vc4List = DaoHelper.getStrToArrayList(newVc4s);

            if (vc4List.size() > 0)
              for (int j = 0; j < vc4List.size(); j++)
                map.put(Integer.valueOf((String)vc4List.get(j)), type);
          }
          else
          {
            throw new UserException("保护方式不合法!");
          }
        } else {
          throw new UserException("无法解析的保护类型!");
        }
      }
    }
    return map;
  }

  public static Map<Integer, String> getProtectionTypeVc4(String protectionDetail)
    throws Exception
  {
    Map map = new HashMap();
    if (DaoHelper.isNotEmpty(protectionDetail)) {
      String[] oneProtectionType = protectionDetail.split(";");
      for (int i = 0; i < oneProtectionType.length; i++) {
        String[] str = oneProtectionType[i].split("\\(");
        if (NetEnum.SYS_PROJECT_TYPE_CH.getName(Long.valueOf(str[0])) != null) {
          Integer type = Integer.valueOf(str[0]);
          if ((type.intValue() != 0) && (type.intValue() != 9)) {
            String vc4s = str[1].substring(0, str[1].length() - 1);
            String newVc4s = getUnMergerStr(vc4s);
            if (DaoHelper.isNotEmpty(newVc4s))
              map.put(type, newVc4s);
          }
        }
        else {
          throw new UserException("无法解析的保护类型!");
        }
      }
    }
    return map;
  }

  public static String checkProtectionDetail(String protectionDetail, long sysVol)
    throws Exception
  {
    String newProtectionDetail = "";
    if (DaoHelper.isNotEmpty(protectionDetail)) {
      long vc12Count = getVc12Count(sysVol);
      if (vc12Count >= 63L) {
        long vc4Count = vc12Count / 63L;
        if (vc4Count > 0L) {
          int sum = 0;
          if (protectionDetail.indexOf(";") > 0) {
            Map map = getProtectionTypeVc4(protectionDetail);
            Integer[] key = new Integer[map.size()];
            map.keySet().toArray(key);
            List sortList = new ArrayList();
            for (int i = 0; i < key.length; i++) {
              sortList.add(key[i]);
            }
            Collections.sort(sortList);

            for (int i = 0; i < sortList.size(); i++) {
              String vc4s = (String)map.get(sortList.get(i));
              List vc4List = DaoHelper.getStrToArrayList(vc4s);
              sum += vc4List.size();

              if (((((Integer)sortList.get(i)).intValue() == 4L) || (((Integer)sortList.get(i)).intValue() == 5L) || (((Integer)sortList.get(i)).intValue() == 6L) || (((Integer)sortList.get(i)).intValue() == 7L)) && (vc4List.size() % 2 != 0))
              {
                throw new UserException(NetEnum.SYS_PROJECT_TYPE_CH.getName(Long.valueOf(((Integer)sortList.get(i)).intValue())) + " 保护的时隙应该为偶数!");
              }
              String newVc4s = getMergerStr(vc4s);

              if (newVc4s.length() > 0) {
                if (newProtectionDetail.length() > 0)
                  newProtectionDetail = newProtectionDetail + ";" + sortList.get(i) + "(" + newVc4s + ")";
                else
                  newProtectionDetail = sortList.get(i) + "(" + newVc4s + ")";
              }
            }
          }
          else
          {
            throw new UserException("混合明细指定的保护方式应不小于2种!");
          }
          if (sum != vc4Count)
            throw new UserException("指定的时隙总数和系统容量不一致!");
        }
        else {
          throw new UserException("系统容量小于155M,无法指定混合明细!");
        }
      }
    }

    return newProtectionDetail;
  }

  public static String getMergerStr(String vc4s)
    throws Exception
  {
    StringBuffer bf = new StringBuffer();
    String newVc4s = "";
    if (DaoHelper.isNotEmpty(vc4s)) {
      List vc4List = DaoHelper.getStrToArrayList(vc4s);
      List list = new ArrayList();
      int[] temp = new int[2];
      temp[0] = Integer.valueOf((String)vc4List.get(0)).intValue();
      temp[1] = Integer.valueOf((String)vc4List.get(0)).intValue();
      for (int i = 0; i < vc4List.size() - 1; i++) {
        if (Integer.valueOf((String)vc4List.get(i + 1)).intValue() - temp[1] == 1) {
          temp[1] = Integer.valueOf((String)vc4List.get(i + 1)).intValue();
        } else {
          list.add(temp);
          temp = new int[2];
          temp[0] = Integer.valueOf((String)vc4List.get(i + 1)).intValue();
          temp[1] = Integer.valueOf((String)vc4List.get(i + 1)).intValue();
        }
      }
      list.add(temp);
      for (int i = 0; i < list.size(); i++) {
        temp = (int[])list.get(i);
        if (temp[0] == temp[1])
          bf.append(",").append(temp[0]);
        else {
          bf.append(",").append(temp[0]).append("-").append(temp[1]);
        }
      }
      if (bf.length() > 0) {
        newVc4s = bf.substring(1, bf.length());
      }
    }
    return newVc4s;
  }

  public static String getUnMergerStr(String vc4s)
    throws Exception
  {
    String newVc4s = "";
    if (DaoHelper.isNotEmpty(vc4s)) {
      String[] vc4Array = vc4s.split(",");
      List vc4List = new ArrayList();
      for (int i = 0; i < vc4Array.length; i++) {
        if (vc4Array[i].indexOf("-") > 0) {
          String[] a2z = vc4Array[i].split("-");
          int start = Integer.valueOf(a2z[0]).intValue();
          int end = Integer.valueOf(a2z[1]).intValue();
          for (int j = start; j <= end; j++) {
            if (!vc4List.contains(Integer.valueOf(j))) {
              vc4List.add(Integer.valueOf(j));
            }
          }
        }
        else if (!vc4List.contains(vc4Array[i])) {
          vc4List.add(Integer.valueOf(Integer.parseInt(vc4Array[i])));
        }

      }

      if (vc4List.size() > 0) {
        Collections.sort(vc4List);
        StringBuffer bf = new StringBuffer();
        if ((vc4List != null) && (vc4List.size() > 0)) {
          for (int i = 0; i < vc4List.size(); i++) {
            String s = String.valueOf(vc4List.get(i));
            if (bf.length() == 0)
              bf.append(s);
            else {
              bf.append(",").append(s);
            }
          }
        }
        newVc4s = bf.toString();
      }
    }
    return newVc4s;
  }

  public static LocatedPoint copyLocatePoint(GenericDO dbo) {
    if (dbo == null) {
      return null;
    }
    LocatedPoint locatedPoint = new LocatedPoint();
    locatedPoint.setCuid(dbo.getCuid());
    locatedPoint.setObjectNum(dbo.getObjectNum());
    locatedPoint.setLabelCn(dbo.getAttrString("LABEL_CN"));
    locatedPoint.setLongitude(dbo.getAttrDouble("LONGITUDE", 0.0D));
    locatedPoint.setLatitude(dbo.getAttrDouble("LATITUDE", 0.0D));
    if (dbo.getClassName().equals("SITE")) {
      locatedPoint.setRelatedDistrictCuid(dbo.getAttrString("RELATED_SPACE_CUID"));
    }
    else {
      if (dbo.getClassName().equals("FIBER_JOINT_BOX")) {
        locatedPoint.setRelatedLocationCuid(dbo.getAttrString("RELATED_LOCATION_CUID"));
      }
      locatedPoint.setRelatedDistrictCuid(dbo.getAttrString("RELATED_DISTRICT_CUID"));
      if (dbo.getAttrBool("IS_CONN_POINT", false))
        locatedPoint.setPointType(1);
      else if (dbo.getAttrBool("IS_DANGER_POINT", false))
        locatedPoint.setPointType(2);
      else if (dbo.getAttrBool("IS_KEEP_POINT", false)) {
        locatedPoint.setPointType(3);
      }
    }
    return locatedPoint;
  }

  public static class SortedSite
    implements Comparable
  {
    private GenericDO site;
    private double value;

    public SortedSite(GenericDO site, double value)
    {
      this.site = site;
      this.value = value;
    }

    public GenericDO getSite() {
      return this.site;
    }

    public int compareTo(Object obj) {
      int ret = 0;
      if (this.value > ((SortedSite)obj).value)
        ret = 1;
      else if (this.value == ((SortedSite)obj).value)
        ret = 0;
      else if (this.value < ((SortedSite)obj).value) {
        ret = -1;
      }
      return ret;
    }
  }
}