package com.boco.transnms.common.bussiness.helper;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.lang.StringHelper;
import com.boco.transnms.common.bussiness.consts.RackEnum;
import com.boco.transnms.common.bussiness.consts.RackEnum.Domain;
import com.boco.transnms.common.bussiness.consts.RackEnum.mstpPortType;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import org.apache.commons.logging.Log;

public class FdnHelper
{
  public static final RateLayerHelper rateLayerHelper = new RateLayerHelper();

  public static String fdnSpliter = ":";
  public static String fdnSpliterB = "=";
  public static String fdnSpliterC = "/";
  public static String emsHeader = "EMS=";
  public static String CtpHeader = "CTP=";
  public static String PtpHeader = "PTP=";
  public static String FtpHeader = "FTP=";
  public static String PWTPHeader = "PWFTP=";
  public static String IPCROSSHeader = "IPCrossConnection=";
  public static String HolderHeader = "EquipmentHolder=";
  public static String CardHeader = "Equipment=";
  public static String neHeader = "ManagedElement=";
  public static String posNeHeader = "POS=";
  public static String onuNeHeader = "ONU=";

  public static String WAVE_HEAD = "λ";
  public static String WAVE_DSR = "dsr";
  public static String WAVE_ODU3 = "odu3";
  public static String WAVE_ODU2 = "odu2";
  public static String WAVE_ODU1 = "odu1";
  public static String WAVE_OTU3 = "otu3";
  public static String WAVE_OTU2 = "otu2";
  public static String WAVE_OTU1 = "otu1";
  public static String WAVE_OCH = "och";
  public static String WAVE_OTS = "ots";
  public static String WAVE_OS = "os";
  public static String WAVE_OMS = "oms";

  public static String SHELF = "shelf";
  public static String RACK = "rack";
  public static String SUB_SHELF = "sub_shelf";
  public static String PORT = "port";
  public static String SLOT = "slot";
  public static String SUB_SLOT = "sub_slot";
  public static String SUB_RACK = "sub_rack";
  public static String DOMAIN = "domain";
  public static String ZTE_PTP_HEADER = "zte-PTPNAME";
  public static String TYPE = "type";
  public static final String jilianVcHead = "vc4";
  public static final String Vc4header = "sts3c_au4-j";
  public static final String AU4 = "au4";
  public static final String VC3 = "tu3_vc3";
  public static final String TU12 = "vt2_tu12";
  private static final String Pdh140 = "e4";
  private static final String Pdh34 = "e3";
  private static final String Pdh8 = "e2";
  private static final String Pdh2 = "e1";
  private static final long IN_SEQUENCE = 1L;
  private static final long NOT_IN_SEQUENCE = 2L;
  private static final String AU4_CN = "155M";
  private static final String VC3_CN = "34M";
  private static final String TU12_CN = "2M";
  private static final String ODU3 = "ODU3";
  private static final String ODU2 = "ODU2";
  private static final String ODU1 = "ODU1";
  public static final String FREQUENCE_HEAD = "Frequency";
  public static final String WDM_WAVE_HEAD = "och";
  public static final String MSTP_TIMEGAP_HEAD = "/mstp_eth_";

  public static int getPdh140ByCtp(String ctp)
  {
    int result = 0;
    int i = ctp.indexOf("e4");
    if (i > -1) {
      int j = ctp.indexOf(61, i);
      int k = ctp.indexOf(47, j);
      if (k < 0)
        result = Integer.valueOf(ctp.substring(j + 1)).intValue();
      else {
        result = Integer.valueOf(ctp.substring(j + 1, k)).intValue();
      }
    }
    return result;
  }

  public static int getPdh34ByCtp(String ctp)
  {
    int result = 0;
    int i = ctp.indexOf("e3");
    if (i > -1) {
      int j = ctp.indexOf(61, i);
      int k = ctp.indexOf(47, j);
      if (k < 0)
        result = Integer.valueOf(ctp.substring(j + 1)).intValue();
      else {
        result = Integer.valueOf(ctp.substring(j + 1, k)).intValue();
      }
    }
    return result;
  }

  public static int getPdh8ByCtp(String ctp)
  {
    int result = 0;
    int i = ctp.indexOf("e2");
    if (i > -1) {
      int j = ctp.indexOf(61, i);
      int k = ctp.indexOf(47, j);
      if (k < 0)
        result = Integer.valueOf(ctp.substring(j + 1)).intValue();
      else {
        result = Integer.valueOf(ctp.substring(j + 1, k)).intValue();
      }
    }
    return result;
  }

  public static String getFdnDomain(String fdnString) {
    String domainName = null;
    int i = fdnString.indexOf(DOMAIN);
    if (i > -1) {
      int j = fdnString.indexOf(61, i);
      int k = fdnString.indexOf(47, j);
      if (k < 0)
        domainName = fdnString.substring(j + 1);
      else {
        domainName = fdnString.substring(j + 1, k);
      }
    }
    return domainName;
  }

  public static String getFdnType(String fdnString) {
    String domainName = null;
    int i = fdnString.indexOf(TYPE);
    if (i > -1) {
      int j = fdnString.indexOf(61, i);
      int k = fdnString.indexOf(47, j);
      if (k < 0)
        domainName = fdnString.substring(j + 1);
      else {
        domainName = fdnString.substring(j + 1, k);
      }
    }
    return domainName;
  }

  public static int getPdh2ByCtp(String ctp)
  {
    int result = 0;
    int i = ctp.indexOf("e1");
    if (i > -1) {
      int j = ctp.indexOf(61, i);
      int k = ctp.indexOf(47, j);
      if (k < 0)
        result = Integer.valueOf(ctp.substring(j + 1)).intValue();
      else {
        result = Integer.valueOf(ctp.substring(j + 1, k)).intValue();
      }
    }
    return result;
  }

  public static int getVc4ByCTP(String ctp)
  {
    int result = 0;

    int i = ctp.indexOf("au4");
    try {
      if (i >= 0) {
        int j = ctp.indexOf(61, i);
        int k = ctp.indexOf(47, j);
        if (k < 0)
          result = Integer.valueOf(ctp.substring(j + 1)).intValue();
        else
          result = Integer.valueOf(ctp.substring(j + 1, k)).intValue();
      }
    }
    catch (Exception e)
    {
    }
    return result;
  }

  public static int getTu3ByCTP(String ctp)
  {
    int result = 0;

    int i = ctp.indexOf("tu3_vc3");
    try {
      if (i >= 0) {
        int j = ctp.indexOf(61, i);
        int k = ctp.indexOf(45, j);
        if (k < 0)
          result = Integer.valueOf(ctp.substring(j + 1)).intValue();
        else
          result = Integer.valueOf(ctp.substring(j + 1, k)).intValue();
      }
    }
    catch (Exception e)
    {
    }
    return result;
  }

  public static int getTu3ByTu12(int vc12Num, long ctpSequenceFlag) {
    int vc12 = vc12Num - 1;
    int k = 0;
    if (ctpSequenceFlag == 1L) {
      k = vc12 % 21 % 3 + 1;
    }
    else if (ctpSequenceFlag == 2L) {
      k = vc12 / 21 + 1;
    }
    return k;
  }

  public static int getTu3ByVc12Fdn(String ctpFdn) {
    int result = 0;

    int i = ctpFdn.indexOf("vt2_tu12");
    try {
      if (i >= 0) {
        String tmpSource = ctpFdn.substring(i);
        String[] tmp = tmpSource.split("-");
        if (tmp.length > 3)
          result = Integer.valueOf(tmp[1].split("=")[1]).intValue();
      }
    }
    catch (Exception e)
    {
    }
    return result;
  }

  public static int getTu2ByCTP(String ctp)
  {
    int result = 0;
    return result;
  }

  public static int getTu12ByCTP(String ctp, long ctpSequenceFlag)
  {
    int result = 0;

    int i = ctp.indexOf("vt2_tu12");
    try {
      if (i >= 0) {
        String tmpSource = ctp.substring(i);
        String[] tmp = tmpSource.split("-");
        if (tmp.length > 3) {
          int k = Integer.valueOf(tmp[1].split("=")[1]).intValue();
          int l = Integer.valueOf(tmp[2].split("=")[1]).intValue();
          int m = Integer.valueOf(tmp[3].split("=")[1]).intValue();
          if (ctpSequenceFlag == 2L)
            result = (k - 1) * 21 + (l - 1) * 3 + m;
          else if (ctpSequenceFlag == 1L)
            result = (m - 1) * 21 + (l - 1) * 3 + k;
        }
        else if (tmp.length == 1) {
          result = Integer.valueOf(tmp[0].split("=")[1]).intValue();
        } else if (tmp.length == 2) {
          result = Integer.parseInt(tmp[1].split("=")[1]);
        }
      }
    }
    catch (Exception e) {
    }
    return result;
  }

  public static int getWaveNumByCtp(String ctp) {
    int result = 0;
    int indexa = ctp.indexOf("och");
    if (indexa > 0) {
      int indexb = ctp.indexOf("/", indexa + "och".length());
      indexa = ctp.indexOf("=", indexa) + 1;
      try {
        if (indexb > -1)
          result = new Integer(ctp.substring(indexa, indexb)).intValue();
        else
          result = new Integer(ctp.substring(indexa)).intValue();
      }
      catch (Exception e)
      {
      }
    }
    return result;
  }

  public static int getODU3ByCTP(String ctp)
  {
    int result = 0;

    int i = ctp.indexOf("ODU3");
    try {
      if (i >= 0) {
        int j = ctp.indexOf(61, i);
        int k = ctp.indexOf(47, j);
        if (k < 0)
          result = Integer.valueOf(ctp.substring(j + 1)).intValue();
        else
          result = Integer.valueOf(ctp.substring(j + 1, k)).intValue();
      }
    }
    catch (Exception e)
    {
    }
    return result;
  }

  public static int getODU2ByCTP(String ctp)
  {
    int result = 0;

    int i = ctp.indexOf("ODU2");
    try {
      if (i >= 0) {
        int j = ctp.indexOf(61, i);
        int k = ctp.indexOf(47, j);
        if (k < 0)
          result = Integer.valueOf(ctp.substring(j + 1)).intValue();
        else
          result = Integer.valueOf(ctp.substring(j + 1, k)).intValue();
      }
    }
    catch (Exception e)
    {
    }
    return result;
  }

  public static int getODU1ByCTP(String ctp)
  {
    int result = 0;

    int i = ctp.indexOf("ODU1");
    try {
      if (i >= 0) {
        int j = ctp.indexOf(61, i);
        int k = ctp.indexOf(47, j);
        if (k < 0)
          result = Integer.valueOf(ctp.substring(j + 1)).intValue();
        else
          result = Integer.valueOf(ctp.substring(j + 1, k)).intValue();
      }
    }
    catch (Exception e)
    {
    }
    return result;
  }

  public static String convertCTPInfo(String source, long ctpSequence)
  {
    StringBuilder objectCtp = new StringBuilder();

    int ctpIndex = source.indexOf(CtpHeader);
    if (ctpIndex == -1) {
      return "";
    }
    int waveNum = getWaveNumByCtp(source);
    ctpIndex += 5;
    if (waveNum > 0) {
      objectCtp.append(WAVE_HEAD).append(waveNum).append(fdnSpliterC);
      ctpIndex = source.indexOf("och");
      ctpIndex = source.indexOf(fdnSpliterC, ctpIndex + "och".length()) + 1;
    }
    String ctptime = source.substring(ctpIndex);
    String[] allTimeList = ctptime.split("/");
    for (int i = 0; i < allTimeList.length; i++) {
      if (i > 0) {
        objectCtp.append(fdnSpliterC);
      }
      String[] oneCtp = allTimeList[i].split("=");
      if (oneCtp.length == 2) {
        String ctpname = RateLayerHelper.getCtpLayerCHName(oneCtp[0]);
        objectCtp.append(ctpname).append(oneCtp[1]);
      } else if (oneCtp.length > 2) {
        objectCtp.append("2M").append(getTu12ByCTP(source, ctpSequence));
      }
    }

    if (objectCtp.length() == 0) {
      objectCtp.append(" ");
    }

    return objectCtp.toString();
  }

  public static String convertCtpFdnFromNmsToEms(String portFdn, String nmsCtp, String portVol, long ctpSequenceFlag)
  {
    return new StringBuilder().append(portFdn).append(":CTP=").append(convertCtpNameFromNmsToEms(nmsCtp, portVol, ctpSequenceFlag)).toString();
  }

  public static String convertCtpNameFromNmsToEms(String nmsCtp, String portVol, long ctpSequenceFlag)
  {
    StringBuilder result = new StringBuilder();
    try {
      if (!nmsCtp.equals("")) {
        String[] nameList = nmsCtp.split("/");
        for (int i = 0; i < nameList.length; i++) {
          String[] vcList = nameList[i].split("M");

          if (vcList.length == 1) {
            vcList = nameList[i].split("G");
          }

          if (vcList[0].equals("155")) {
            result.append("/sts3c_au4-j=").append(vcList[1]);
          }
          else if (vcList[0].equals("34")) {
            result.append("/tu3_vc3-k=").append(vcList[1]);
          }
          else if (vcList[0].equals("2")) {
            if (ctpSequenceFlag == 1L) {
              int vc12 = new Integer(vcList[1]).intValue() - 1;
              int m = vc12 / 21 + 1;
              vc12 %= 21;
              int l = vc12 / 3 + 1;
              int k = vc12 % 3 + 1;
              result.append("/vt2_tu12-k=").append(k);
              result.append("-l=").append(l);
              result.append("-m=").append(m);
            } else if (ctpSequenceFlag == 2L) {
              int vc12 = new Integer(vcList[1]).intValue() - 1;
              int k = vc12 / 21 + 1;
              vc12 %= 21;
              int l = vc12 / 3 + 1;
              int m = vc12 % 3 + 1;
              result.append("/vt2_tu12-k=").append(k);
              result.append("-l=").append(l);
              result.append("-m=").append(m);
            }
          } else if (vcList[0].equals("622"))
            result.append("/").append(RateLayerHelper.getSdhLayer("622M")).append("=").append(vcList[1]);
          else if (vcList[0].equals("2.5"))
            result.append("/").append(RateLayerHelper.getSdhLayer("2.5G")).append("=").append(vcList[1]);
          else if (vcList[0].equals("10")) {
            result.append("/").append(RateLayerHelper.getSdhLayer("10G")).append("=").append(vcList[1]);
          }
        }

      }
      else if ("2M".equals(portVol)) {
        result.append("/vt2_tu12=1");
      } else if ("155M".equals(portVol)) {
        result.append("/sts3c_au4=1");
      } else if ("34M".equals(portVol)) {
        result.append("/tu3_vc3-k=1");
      } else if ("2.5G".equals(portVol)) {
        result.append("/sts48c_vc4_16c=1");
      } else if ("10G".equals(portVol)) {
        result.append("/sts192c_vc4_64c=1");
      }

    }
    catch (Exception e)
    {
    }

    return result.toString();
  }

  public static String getCtpName(String ctpFdn, long ctpSequenceFlag) {
    StringBuilder ctpName = new StringBuilder();
    try {
      String[] vcList = ctpFdn.split("CTP=");
      String ctpStr = vcList[1];
      String[] ctpRate = ctpStr.split("/");
      for (int i = 1; i < ctpRate.length; i++) {
        String[] temp = ctpRate[i].split("=");
        ctpName.append("/");
        if (temp[0].indexOf("tu3_vc3") > -1) {
          ctpName.append(new StringBuilder().append("34M").append(temp[1]).toString());
        } else if (temp[0].equals("vt2_tu12-k")) {
          String[] temp1 = ctpRate[i].split("-");
          int k = Integer.parseInt(temp1[1].substring(2));
          int l = Integer.parseInt(temp1[2].substring(2));
          int m = Integer.parseInt(temp1[3].substring(2));
          int vc12 = 0;
          if (ctpSequenceFlag == 1L)
            vc12 = (m - 1) * 21 + (l - 1) * 3 + k;
          else if (ctpSequenceFlag == 2L) {
            vc12 = (k - 1) * 21 + (l - 1) * 3 + m;
          }
          ctpName.append(new StringBuilder().append("2M").append(String.valueOf(vc12)).toString());
        } else {
          String namea = (String)RateLayerHelper.layerRateNameMap.get(temp[0]);
          if (namea == null) {
            ctpName.append(temp[0]).append("=");
            if (temp.length > 1) {
              ctpName.append(temp[1]);
            }
          }
          else if (ctpName.indexOf(new StringBuilder().append("/").append(namea).toString()) < 0) {
            ctpName.append(namea);
            if (temp.length > 1)
              ctpName.append(temp[1]);
          }
          else {
            ctpName.deleteCharAt(ctpName.length() - 1);
          }

        }

      }

      if (StringHelper.isEmpty(ctpName.toString()))
        ctpName.append(ctpStr);
      else
        ctpName.deleteCharAt(0);
    }
    catch (Throwable ex) {
      LogHome.getLog().info(new StringBuilder().append("取层CTP名字出错，检查CTP FDN是否符合规范: ctpFnd = ").append(ctpFdn).toString(), ex);
    }
    if (ctpName.toString().equals("")) {
      LogHome.getLog().info(new StringBuilder().append("取层CTP名字出错，检查CTP FDN是否符合规范: ctpFnd = ").append(ctpFdn).toString());
    }
    return ctpName.toString();
  }

  public static String getWdmCtpName(String ctpFdn)
  {
    StringBuilder ctpName = new StringBuilder();
    try {
      String[] vcList = ctpFdn.split("CTP=");
      String ctpStr = vcList[1];
      String[] ctpRate = ctpStr.split("/");
      for (int i = 1; i < ctpRate.length; i++) {
        String[] temp = ctpRate[i].split("=");
        String namea = (String)RateLayerHelper.layerRateNameMap.get(temp[0]);
        if ((namea == null) || (ctpName.indexOf(namea) <= -1))
        {
          ctpName.append("/");
          if (namea == null)
            ctpName.append(temp[0]).append("=");
          else {
            ctpName.append(namea);
          }
          if (temp.length > 1)
            ctpName.append(temp[1]);
        }
      }
      ctpName.deleteCharAt(0);
    } catch (Throwable ex) {
      LogHome.getLog().info(new StringBuilder().append("取层CTP名字出错，检查CTP FDN是否符合规范: ctpFnd = ").append(ctpFdn).toString(), ex);
    }
    if (ctpName.toString().equals("")) {
      LogHome.getLog().info(new StringBuilder().append("取层CTP名字出错，检查CTP FDN是否符合规范: ctpFnd = ").append(ctpFdn).toString());
    }
    return ctpName.toString();
  }

  public static String getUpperCtpName(String ctpName)
  {
    String upperCtpName = null;
    int kIndex = ctpName.lastIndexOf("/");
    int j = ctpName.indexOf(WAVE_HEAD);
    if (j > -1) {
      j = ctpName.indexOf("/");
    }
    if ((kIndex > -1) && (kIndex > j)) {
      upperCtpName = ctpName.substring(0, kIndex);
    }
    return upperCtpName;
  }

  public static String getEmsFdnByStr(String souFdn)
  {
    if (souFdn == null) {
      return null;
    }
    int emsPlace = souFdn.indexOf(emsHeader);
    String[] fdnBuf = souFdn.split(fdnSpliter);
    if (emsPlace < 0) {
      return new StringBuilder().append(emsHeader).append(souFdn).toString();
    }
    return fdnBuf[0];
  }

  public static String getEmsVendorByStr(String souFdn)
  {
    if (souFdn == null) {
      return null;
    }
    String[] souBuf = souFdn.split(fdnSpliter);
    if (souBuf.length == 0) {
      return null;
    }
    int signalplace = souBuf[0].indexOf(fdnSpliterB);
    String[] vendorBuf;
    String[] vendorBuf;
    if (signalplace < 0)
      vendorBuf = souBuf[0].split(fdnSpliterC);
    else {
      vendorBuf = souBuf[0].substring(signalplace + 1).split(fdnSpliterC);
    }
    if (vendorBuf.length == 1) {
      return souFdn;
    }
    return vendorBuf[0];
  }

  public static String getEmsNameByStr(String souFdn)
  {
    if (souFdn == null) {
      return null;
    }
    int emsPlace = souFdn.indexOf(emsHeader);
    String[] fdnBuf = souFdn.split(fdnSpliter);
    if (emsPlace < 0) {
      return souFdn;
    }
    String[] emsName = fdnBuf[0].split(fdnSpliterB);
    return emsName[1];
  }

  public static String getNeFdnByStr(String souFdn)
  {
    if (souFdn == null) {
      return null;
    }
    int nePlace = souFdn.indexOf(neHeader);
    String[] fdnBuf = souFdn.split(fdnSpliter);
    if (nePlace < 0) {
      return null;
    }
    String neFdn = new StringBuilder().append(fdnBuf[0]).append(fdnSpliter).append(fdnBuf[1]).toString();

    if (fdnBuf.length > 2)
    {
      for (int i = 2; i < fdnBuf.length; i++) {
        if (fdnBuf[i].indexOf("--") > 0) {
          neFdn = new StringBuilder().append(neFdn).append(":").append(fdnBuf[i]).toString();
          break;
        }if (fdnBuf[i].indexOf(posNeHeader) > -1)
          neFdn = new StringBuilder().append(neFdn).append(":").append(fdnBuf[i]).toString();
        else if (fdnBuf[i].indexOf(onuNeHeader) > -1)
          neFdn = new StringBuilder().append(neFdn).append(":").append(fdnBuf[i]).toString();
        else {
          try {
            if (new Long(fdnBuf[2]).longValue() > -1L) {
              neFdn = new StringBuilder().append(neFdn).append(":").append(fdnBuf[2]).toString();
            }
          }
          catch (Exception e)
          {
          }
        }
      }
    }

    return neFdn;
  }

  public static String getNeNameByStr(String souFdn)
  {
    if (souFdn == null) {
      return null;
    }
    String neFdn = getNeFdnByStr(souFdn);
    String neName = null;
    if (neFdn != null) {
      String[] fdnBuf = neFdn.split(fdnSpliterB);
      neName = fdnBuf[(fdnBuf.length - 1)];
    }
    return neName;
  }

  public static String getNeHolderFdnByStr(String souFdn)
  {
    if (souFdn == null) {
      return null;
    }
    String neFdn = getNeFdnByStr(souFdn);
    StringBuilder holderFdnBuffer = new StringBuilder();
    String tmpFdn = souFdn.substring(neFdn.length());
    int nePlace = tmpFdn.indexOf("EquipmentHolder=");
    String[] fdnBuf = tmpFdn.split(fdnSpliter);
    if (nePlace < 0) {
      int ptpPlace = souFdn.indexOf(PtpHeader);
      int ftpPlace = souFdn.indexOf(FtpHeader);
      if ((ptpPlace < 0) && (ftpPlace < 0)) {
        return null;
      }
      holderFdnBuffer.append(neFdn);
      holderFdnBuffer.append(fdnSpliter);
      String[] ptp = fdnBuf[1].split(fdnSpliterB, 2);
      holderFdnBuffer.append("EquipmentHolder=");
      int portplace = 0;
      if (ptp[1].indexOf("domain") < 0) {
        if (ptp[1].indexOf("type") < 0)
          portplace = ptp[1].indexOf("/port");
        else
          portplace = ptp[1].indexOf("/type");
      }
      else {
        portplace = ptp[1].indexOf("/domain");
      }
      holderFdnBuffer.append(ptp[1].substring(0, portplace));
    }
    else {
      holderFdnBuffer.append(neFdn);
      holderFdnBuffer.append(fdnSpliter);
      holderFdnBuffer.append(fdnBuf[1]);
    }
    return holderFdnBuffer.toString();
  }

  public static String getEquitFdnByStr(String souFdn)
  {
    if (souFdn == null) {
      return null;
    }
    String neFdn = getNeFdnByStr(souFdn);
    StringBuilder holderFdnBuffer = new StringBuilder();
    String tmpFdn = souFdn.substring(neFdn.length());
    int nePlace = tmpFdn.indexOf("Equipment=");
    String[] fdnBuf = tmpFdn.split(fdnSpliter);
    if (nePlace < 0) {
      int ptpPlace = souFdn.indexOf(PtpHeader);
      int ftpPlace = souFdn.indexOf(FtpHeader);
      if ((ptpPlace < 0) && (ftpPlace < 0)) {
        return null;
      }
      holderFdnBuffer.append(neFdn);
      holderFdnBuffer.append(fdnSpliter);
      String[] ptp = fdnBuf[1].split(fdnSpliterB, 2);
      holderFdnBuffer.append("EquipmentHolder=");
      int portplace;
      int portplace;
      if (ptp[1].indexOf("domain") < 0)
      {
        int portplace;
        if (ptp[1].indexOf("type") < 0)
          portplace = ptp[1].indexOf("/port");
        else
          portplace = ptp[1].indexOf("/type");
      }
      else {
        portplace = ptp[1].indexOf("/domain");
      }
      holderFdnBuffer.append(ptp[1].substring(0, portplace));
      holderFdnBuffer.append(fdnSpliter);
      holderFdnBuffer.append("Equipment=1");
      return holderFdnBuffer.toString();
    }

    if (fdnBuf.length >= 3) {
      holderFdnBuffer.append(neFdn);
      holderFdnBuffer.append(fdnSpliter);
      holderFdnBuffer.append(fdnBuf[1]);
      holderFdnBuffer.append(fdnSpliter);
      holderFdnBuffer.append(fdnBuf[2]);
    } else {
      holderFdnBuffer.setLength(0);
    }
    return holderFdnBuffer.toString();
  }

  public static String getPortFdnByStr(String souFdn)
  {
    if (souFdn == null) {
      return null;
    }
    int ptpPlace = souFdn.indexOf(PtpHeader);
    int ftpPlace = souFdn.indexOf(FtpHeader);
    if ((ptpPlace < 0) && (ftpPlace < 0)) {
      return null;
    }
    String neFdn = getNeFdnByStr(souFdn);
    String tmpFdn = souFdn.substring(neFdn.length());
    String[] fdnBuf = tmpFdn.split(fdnSpliter);
    StringBuffer portFdnBuffer = new StringBuffer();
    if (fdnBuf.length >= 2) {
      portFdnBuffer.append(neFdn);
      portFdnBuffer.append(fdnSpliter);
      portFdnBuffer.append(fdnBuf[1]);
    }
    else
    {
      portFdnBuffer.setLength(0);
    }
    return portFdnBuffer.toString();
  }

  public static int getRackNumByStr(String souFdn)
  {
    int rackNum = -1;
    if (souFdn != null) {
      int nePlace = souFdn.indexOf("/rack=");
      if (nePlace > -1) {
        nePlace++;
        int endIndex = souFdn.indexOf(fdnSpliter, nePlace);
        String[] fdnBuf;
        String[] fdnBuf;
        if (endIndex >= 0)
          fdnBuf = souFdn.substring(nePlace, endIndex).split(fdnSpliterC);
        else {
          fdnBuf = souFdn.substring(nePlace).split(fdnSpliterC);
        }
        String[] rackBuf = fdnBuf[0].split(fdnSpliterB);
        if (rackBuf.length >= 2) {
          rackNum = new Integer(rackBuf[1]).intValue();
        }
      }
    }
    return rackNum;
  }

  public static int getShelfNumByStr(String souFdn)
  {
    int shelfNum = -1;
    if (souFdn != null) {
      int place = souFdn.indexOf("/shelf=");
      if (place > -1) {
        place++;
        int endIndex = souFdn.indexOf(fdnSpliter, place);
        String[] fdnBuf;
        String[] fdnBuf;
        if (endIndex >= 0)
          fdnBuf = souFdn.substring(place, endIndex).split(fdnSpliterC);
        else {
          fdnBuf = souFdn.substring(place).split(fdnSpliterC);
        }
        String[] rackBuf = fdnBuf[0].split(fdnSpliterB);
        if (rackBuf.length >= 2) {
          shelfNum = new Integer(rackBuf[1]).intValue();
        }
      }
    }
    return shelfNum;
  }

  public static int getSubshelfNumByStr(String souFdn)
  {
    int subshelfNum = -1;
    if (souFdn != null) {
      int place = souFdn.indexOf("/sub_shelf=");
      if (place > -1) {
        place++;
        int endIndex = souFdn.indexOf(fdnSpliter, place);
        String[] fdnBuf;
        String[] fdnBuf;
        if (endIndex >= 0)
          fdnBuf = souFdn.substring(place, endIndex).split(fdnSpliterC);
        else {
          fdnBuf = souFdn.substring(place).split(fdnSpliterC);
        }
        String[] rackBuf = fdnBuf[0].split(fdnSpliterB);
        if (rackBuf.length >= 2) {
          subshelfNum = new Integer(rackBuf[1]).intValue();
        }
      }
    }
    return subshelfNum;
  }

  public static int getSubRackNumByStr(String souFdn)
  {
    int subshelfNum = -1;
    if (souFdn != null) {
      int place = souFdn.indexOf("/sub_rack=");
      if (place > -1) {
        place++;
        int endIndex = souFdn.indexOf(fdnSpliter, place);
        String[] fdnBuf;
        String[] fdnBuf;
        if (endIndex >= 0)
          fdnBuf = souFdn.substring(place, endIndex).split(fdnSpliterC);
        else {
          fdnBuf = souFdn.substring(place).split(fdnSpliterC);
        }
        String[] rackBuf = fdnBuf[0].split(fdnSpliterB);
        if (rackBuf.length >= 2) {
          subshelfNum = new Integer(rackBuf[1]).intValue();
        }
      }
    }
    return subshelfNum;
  }

  public static int getSlotNumByStr(String souFdn)
  {
    int slotNum = -1;
    if (souFdn != null) {
      int place = souFdn.indexOf("/slot=");
      if (place > -1) {
        place++;
        int endIndex = souFdn.indexOf(fdnSpliter, place);
        String[] fdnBuf;
        String[] fdnBuf;
        if (endIndex >= 0)
          fdnBuf = souFdn.substring(place, endIndex).split(fdnSpliterC);
        else {
          fdnBuf = souFdn.substring(place).split(fdnSpliterC);
        }
        String[] rackBuf = fdnBuf[0].split(fdnSpliterB);
        if (rackBuf.length >= 2) {
          slotNum = new Integer(rackBuf[1]).intValue();
        }
      }
    }
    return slotNum;
  }

  public static int getSubslotNumByStr(String souFdn)
  {
    int slotNum = -1;
    if (souFdn != null) {
      int place = souFdn.indexOf("/sub_slot=");
      if (place > -1) {
        place++;
        int endIndex = souFdn.indexOf(fdnSpliter, place);
        String[] fdnBuf;
        String[] fdnBuf;
        if (endIndex >= 0)
          fdnBuf = souFdn.substring(place, endIndex).split(fdnSpliterC);
        else {
          fdnBuf = souFdn.substring(place).split(fdnSpliterC);
        }
        String[] rackBuf = fdnBuf[0].split(fdnSpliterB);
        if (rackBuf.length >= 2) {
          slotNum = new Integer(rackBuf[1]).intValue();
        }
      }
    }
    return slotNum;
  }

  public static int getPortNumByStr(String souFdn)
  {
    int slotNum = -1;
    if (souFdn != null) {
      int place = souFdn.indexOf("port=");
      if (place > -1) {
        int endIndex = souFdn.indexOf(fdnSpliter, place);
        String[] fdnBuf;
        String[] fdnBuf;
        if (endIndex >= 0)
          fdnBuf = souFdn.substring(place, endIndex).split(fdnSpliterC);
        else {
          fdnBuf = souFdn.substring(place).split(fdnSpliterC);
        }
        String[] rackBuf = fdnBuf[0].split(fdnSpliterB);
        if (rackBuf.length >= 2) {
          slotNum = new Integer(rackBuf[1]).intValue();
        }
      }
    }
    return slotNum;
  }

  public static String getCtpFdnOnly(String souFdn) {
    if (souFdn == null) {
      return null;
    }
    int ctpPlace = souFdn.indexOf(CtpHeader);
    if (ctpPlace < 0) {
      return null;
    }
    return souFdn.substring(ctpPlace).split(fdnSpliter)[0];
  }

  public static String getPWTPInfoOnly(String souFdn)
  {
    if (souFdn == null) {
      return null;
    }
    int ctpPlace = souFdn.indexOf(PWTPHeader);
    if (ctpPlace < 0) {
      return null;
    }
    return souFdn.substring(ctpPlace).split(fdnSpliter)[0];
  }

  public static String getIpCrossConnectionInfoOnly(String souFdn)
  {
    if (souFdn == null) {
      return null;
    }
    int ctpPlace = souFdn.indexOf(IPCROSSHeader);
    if (ctpPlace < 0) {
      return null;
    }
    return souFdn.substring(ctpPlace).split(fdnSpliter)[0];
  }

  public static int getCtpSignalRate(String ctpFdn)
  {
    int lowestRateIndex = ctpFdn.lastIndexOf("/");
    String tempCtpStr = ctpFdn.substring(lowestRateIndex);
    String[] timgapList = tempCtpStr.split("=");
    int rate = 0;
    if (timgapList.length > 1) {
      if (timgapList[0].indexOf("vt2_tu12") > -1)
        rate = 1;
      else if (timgapList[0].indexOf("tu3_vc3") > -1)
        rate = 4;
      else if (timgapList[0].indexOf("sts3c_au4") > -1)
        rate = 9;
      else if (timgapList[0].indexOf("ODU3") > -1)
        rate = 19;
      else if (timgapList[0].indexOf("ODU2") > -1)
        rate = 17;
      else if (timgapList[0].indexOf("ODU1") > -1)
        rate = 16;
      else if (timgapList[0].indexOf("vc4_16c") > -1)
        rate = 16;
      else if (timgapList[0].indexOf("vc4_64c") > -1) {
        rate = 17;
      }
    }
    return rate;
  }

  public static String getCtpSignalRateName(String ctpFdn) {
    int lowestRateIndex = ctpFdn.lastIndexOf("/");
    String tempCtpStr = ctpFdn.substring(lowestRateIndex);
    String[] timgapList = tempCtpStr.split("=");
    String rate = null;
    if (timgapList.length > 1) {
      if (timgapList[0].indexOf("vt2_tu12") > -1)
        rate = "2M";
      else if (timgapList[0].indexOf("tu3_vc3") > -1)
        rate = "34M";
      else if (timgapList[0].indexOf("sts3c_au4") > -1)
        rate = "155M";
      else if (timgapList[0].indexOf("sts12c_vc4_4c") > -1)
        rate = "622M";
      else if (timgapList[0].indexOf("sts48c_vc4_16c") > -1)
        rate = "10G";
      else if (timgapList[0].indexOf("ODU3") > -1)
        rate = "40G";
      else if (timgapList[0].indexOf("ODU2") > -1)
        rate = "10G";
      else if (timgapList[0].indexOf("ODU1") > -1)
        rate = "2D5G";
      else if (timgapList[0].indexOf("vc4_16c") > -1)
        rate = "2D5G";
      else if (timgapList[0].indexOf("vc4_64c") > -1) {
        rate = "10G";
      }
    }
    return rate;
  }

  public static int getBingPathLevel(String ctpFdn)
  {
    int temp = 3;
    int lowestRateIndex = ctpFdn.lastIndexOf("/");
    String tempCtpStr = ctpFdn.substring(lowestRateIndex);
    String[] timgapList = tempCtpStr.split("=");
    if (timgapList.length > 1) {
      if (timgapList[0].indexOf("vt2_tu12") > -1)
        temp = 3;
      else if (timgapList[0].indexOf("sts3c_au4") > -1)
        temp = 1;
      else if (timgapList[0].indexOf("tu3_vc3") > -1) {
        temp = 2;
      }
    }
    return temp;
  }

  public static int getCtpLayerLevel(int ctpRate)
  {
    int layerLevel;
    switch (ctpRate) {
    case 1:
      layerLevel = 1;
      break;
    case 4:
      layerLevel = 1;
      break;
    case 9:
      layerLevel = 2;
      break;
    case 16:
      layerLevel = 3;
      break;
    case 17:
      layerLevel = 4;
      break;
    case 19:
      layerLevel = 5;
      break;
    case 2:
    case 3:
    case 5:
    case 6:
    case 7:
    case 8:
    case 10:
    case 11:
    case 12:
    case 13:
    case 14:
    case 15:
    case 18:
    default:
      layerLevel = 0;
    }

    return layerLevel;
  }

  public static String makePortFdn(String holderFdn, long domain, long type, long portNum)
  {
    StringBuilder portFdn = new StringBuilder(holderFdn);
    int placeIndex = portFdn.indexOf(CardHeader);
    if (placeIndex > 0) {
      placeIndex--;
      portFdn.delete(placeIndex, portFdn.length());
    }
    placeIndex = portFdn.indexOf(HolderHeader);
    if (placeIndex > 0) {
      portFdn.delete(placeIndex, placeIndex + HolderHeader.length());
      portFdn.insert(placeIndex, PtpHeader);
      if ((domain == 2L) || (domain == 3L)) {
        portFdn.append("/");
        portFdn.append(DOMAIN).append(fdnSpliterB).append(RackEnum.DOMAIN.getName(Long.valueOf(domain)));
        if (type > 0L) {
          portFdn.append("/");
          portFdn.append(TYPE).append(fdnSpliterB).append(RackEnum.MSTP_PORT_TYPE.getName(Long.valueOf(type)));
        }
      }
      portFdn.append("/");
      portFdn.append(PORT).append(fdnSpliterB).append(portNum);
    }

    return portFdn.toString();
  }

  public static String makeCardFdn(String holderFdn)
  {
    return new StringBuilder().append(holderFdn).append(":").append(CardHeader).append("1").toString();
  }

  public static String makeHolderFdn(String upHolderFdn, String holderType, int holderNum) {
    int holderHeadIndex = upHolderFdn.indexOf(HolderHeader);
    if (holderHeadIndex > 0) {
      return new StringBuilder().append(upHolderFdn).append(fdnSpliterC).append(holderType).append(fdnSpliterB).append(holderNum).toString();
    }
    return new StringBuilder().append(upHolderFdn).append(fdnSpliter).append(HolderHeader).append(fdnSpliterC).append(holderType).append(fdnSpliterB).append(holderNum).toString();
  }

  public static String makeHolderFdn(String upHolderFdn, String holderType, String holderlabel)
  {
    int holderHeadIndex = upHolderFdn.indexOf(HolderHeader);
    if (holderHeadIndex > 0) {
      return new StringBuilder().append(upHolderFdn).append(fdnSpliterC).append(holderType).append(fdnSpliterB).append(holderlabel).toString();
    }
    return new StringBuilder().append(upHolderFdn).append(fdnSpliter).append(HolderHeader).append(fdnSpliterC).append(holderType).append(fdnSpliterB).append(holderlabel).toString();
  }

  public static String makeNeFdn(String emsFdn, String neLebal)
  {
    return new StringBuilder().append(emsFdn).append(fdnSpliter).append(neHeader).append(neLebal).toString();
  }

  public static String convertEmsFdnToLocalFdn(cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NamingAttributesType dd) {
    cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NameAndValueType[] nameList = dd.getItem();
    StringBuilder nameStr = new StringBuilder();
    for (cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NameAndValueType name : nameList) {
      nameStr.append(name.getName()).append(fdnSpliterB).append(name.getValue()).append(fdnSpliter);
    }
    nameStr.deleteCharAt(nameStr.length() - 1);
    return nameStr.toString();
  }

  public static String convertEmsFdnToLocalFdn(cn.com.chinamobile.adaption.adaptionInterface.adaptionCommon.NamingAttributesType dd) {
    cn.com.chinamobile.adaption.adaptionInterface.adaptionCommon.NameAndValueType[] nameList = dd.getItemArray();
    StringBuilder nameStr = new StringBuilder();
    for (cn.com.chinamobile.adaption.adaptionInterface.adaptionCommon.NameAndValueType name : nameList) {
      nameStr.append(name.getName()).append(fdnSpliterB).append(name.getValue()).append(fdnSpliter);
    }
    if (nameStr.length() != 0) {
      nameStr.deleteCharAt(nameStr.length() - 1);
    }

    return nameStr.toString();
  }

  public static String getSdhRadioCtpFdn(String portFdn, String portRate) {
    return new StringBuilder().append(portFdn).append(":").append(CtpHeader).append("/").append(RateLayerHelper.getSdhLayer(portRate)).append("=1").toString();
  }

  public static String getPdhCtpFdn(String upperFdn, String timegap)
    throws Exception
  {
    StringBuilder timeGapall = new StringBuilder();
    timeGapall.append(getPortFdnByStr(upperFdn)).append(":").append(CtpHeader);

    if ((timegap != null) && (timegap.length() > 0)) {
      String[] timeGapList = timegap.toUpperCase().split("/");
      for (int i = 0; i < timeGapList.length; i++)
        if (i == 0) {
          timeGapall.append("/").append(RateLayerHelper.getPdhLayer(timeGapList[0].substring(0, timeGapList[0].indexOf("M") + 1))).append("=1");
        } else {
          String[] sepTimeGap = timeGapList[i].split("M");
          timeGapall.append("/").append(RateLayerHelper.getPdhLayer(new StringBuilder().append(sepTimeGap[0]).append("M").toString())).append("=").append(sepTimeGap[1]);
        }
    }
    else
    {
      throw new Exception(new StringBuilder().append("CTP名称未正确设置：").append(timegap).toString());
    }
    return timeGapall.toString();
  }

  public static String getMstpCtpFdn(String upperFdn, String timegap)
    throws Exception
  {
    StringBuilder timeGapall = new StringBuilder();
    timeGapall.append(getPortFdnByStr(upperFdn)).append(":").append(CtpHeader).append("/mstp_eth_");

    if ((timegap != null) && (timegap.length() > 0)) {
      String[] timeGapList = timegap.toUpperCase().split("/");
      for (int i = 0; i < timeGapList.length; i++)
        if (i == 0) {
          timeGapall.append(timeGapList[0]).append("=1");
        } else {
          String[] sepTimeGap = timeGapList[i].split("M");
          timeGapall.append("/").append(RateLayerHelper.getMstpLayer(new StringBuilder().append(sepTimeGap[0]).append("M").toString())).append("=").append(sepTimeGap[1]);
        }
    }
    else
    {
      throw new Exception(new StringBuilder().append("CTP名称未正确设置：").append(timegap).toString());
    }
    return timeGapall.toString();
  }

  public static String getSDHCtpFdn(String upperFdn, String timegap, String rate, long ctpSequenceFlag)
    throws Exception
  {
    StringBuilder timeGapall = new StringBuilder();
    timeGapall.append(getPortFdnByStr(upperFdn)).append(":").append(CtpHeader);

    if ((timegap != null) && (timegap.length() > 0)) {
      String ctpLocal = convertCtpNameFromNmsToEms(timegap, rate, ctpSequenceFlag);
      timeGapall.append(ctpLocal);
    } else {
      throw new Exception(new StringBuilder().append("CTP名称未正确设置：").append(timegap).toString());
    }
    return timeGapall.toString();
  }

  public static String getSDHCtpFdn_split(String upperFdn, String restimegap, String desctimegap, boolean isEquals) throws Exception
  {
    int i = upperFdn.indexOf("CTP=/");
    int j = upperFdn.indexOf("/", i + 7);
    String au4Str = upperFdn.substring(i + 5, j);
    StringBuilder timeGapall = new StringBuilder();
    timeGapall.append(getPortFdnByStr(upperFdn)).append(":").append(CtpHeader).append("/");
    try
    {
      if (((restimegap != null ? 1 : 0) & (restimegap.indexOf("155") != -1 ? 1 : 0)) != 0) {
        if ((desctimegap != null) && (desctimegap.indexOf("2") != -1)) {
          if (isEquals) {
            String[] timeGap_after = desctimegap.split("M");
            timeGapall.append(RateLayerHelper.getSdhLayer("2M")).append("=").append(timeGap_after[1]);
          }
          else {
            String[] timeGap_after = desctimegap.split("M");
            timeGapall.append(au4Str).append("/").append(RateLayerHelper.getSdhLayer("2M")).append("=").append(timeGap_after[1]);
          }
        }
        else if ((desctimegap != null) && (desctimegap.indexOf("34") != -1)) {
          if (isEquals) {
            String[] timeGap_after = desctimegap.split("M");
            timeGapall.append(RateLayerHelper.getSdhLayer("34M")).append("=").append(timeGap_after[1]);
          }
          else {
            String[] timeGap_after = desctimegap.split("M");
            timeGapall.append(au4Str).append("/").append(RateLayerHelper.getSdhLayer("34M")).append("=").append(timeGap_after[1]);
          }
        }
        else
          throw new Exception("从上层转入的参数目标CTP速率不是2M或34M，请重新转入目标速率 ！");
      }
      else if ((restimegap != null) && (restimegap.indexOf("34") != -1)) {
        if ((desctimegap != null) && (desctimegap.indexOf("2") != -1)) {
          String[] timeGap_after = desctimegap.split("M");
          timeGapall.append(RateLayerHelper.getSdhLayer("2M")).append("=").append(timeGap_after[1]);
        }
        else
        {
          throw new Exception("从上层转入的参数目标CTP速率不是2M，请重新转入目标速率 ！");
        }
      }
      else throw new Exception("从数据库取出的源CTP速率不是155M或34M，请重新传入CTP ！"); 
    }
    catch (Exception e)
    {
      LogHome.getLog().info(new StringBuilder().append("拆分CTP时，制作CTP的FDN时出错").append(e).toString());
      throw new Exception(e);
    }
    return timeGapall.toString();
  }

  public static String getUserHolderLabelFromFdn(String neName, String Fdn)
  {
    StringBuilder userLable = new StringBuilder();
    String holderFdn = getNeHolderFdnByStr(Fdn);
    userLable.append(neName);
    String[] holderList = holderFdn.split(fdnSpliter);
    String[] holderOnly = holderList[2].split("/");
    for (int i = 1; i < holderOnly.length; i++) {
      String[] oneHold = holderOnly[i].split("=");
      if (oneHold[1].length() > 0) {
        userLable.append("/").append(oneHold[1]);
      }
    }
    return userLable.toString();
  }

  public static String getTopLevelCtp(String fdn) {
    StringBuilder topLevelCtp = new StringBuilder();
    if (fdn.indexOf(CtpHeader) < 0) {
      return topLevelCtp.toString();
    }
    String[] ctpAllList = fdn.split(CtpHeader);
    String[] ctpList = ctpAllList[1].split("/");
    topLevelCtp.append(ctpAllList[0]).append(CtpHeader).append("/").append(ctpList[1]);
    return topLevelCtp.toString();
  }

  public static long getRateFromVc4Count(int vc4Count) {
    long portRate = 0L;

    if (vc4Count == 4)
      portRate = 13L;
    else if (vc4Count == 8)
      portRate = 15L;
    else if (vc4Count == 16)
      portRate = 16L;
    else if (vc4Count == 2)
      portRate = 11L;
    else if (vc4Count == 64) {
      portRate = 17L;
    }
    return portRate;
  }

  public static String getFormatedPort(int portNum)
  {
    String portName = null;
    if (portNum > 9)
      portName = new StringBuilder().append("").append(portNum).toString();
    else {
      portName = new StringBuilder().append("0").append(portNum).toString();
    }
    return portName;
  }

  public static void main(String[] argc)
  {
    String ctpFdn = "EMS=Huawei/T2000:ManagedElement=114-软件园:PTP=/rack=1/shelf=1/slot=15/domain=sdh/port=1:CTP=/sts3c_au4-j=19/vt2_tu12-k=2-l=1-m=3";

    System.out.println(getTu3ByTu12(22, 1L));
    System.out.println(getTu3ByTu12(22, 2L));
    System.out.println(getTu12ByCTP(ctpFdn, 1L));
    System.out.println(getTu12ByCTP(ctpFdn, 2L));
    System.out.println(convertCtpNameFromNmsToEms("155M1/2M14", null, 1L));
    System.out.println(convertCtpNameFromNmsToEms("155M1/2M14", null, 2L));
    System.out.println(getCtpName(ctpFdn, 1L));
    System.out.println(getCtpName(ctpFdn, 2L));
  }

  public static class RateLayerHelper
  {
    private static HashMap pdhLayerMap = new HashMap();
    private static HashMap rateLayeNumMap = new HashMap();
    private static HashMap sdhLayerMap = new HashMap();

    private static HashMap dwdmLayerMap = new HashMap();
    private static HashMap mstpLayerMap = new HashMap();

    private static HashMap layerRateNameMap = new HashMap();

    public static String getPdhLayer(String portRate)
    {
      return (String)pdhLayerMap.get(portRate);
    }

    public static String getSdhLayer(String portRate) {
      return (String)sdhLayerMap.get(portRate);
    }

    public static long getSdhCtpLayerRate(String portRate) {
      Long rate = new Long(0L);
      try {
        rate = new Long((String)rateLayeNumMap.get("SDH" + portRate));
      }
      catch (Exception ce) {
      }
      return rate.longValue();
    }

    public static long getPdhCtpLayerRate(String portRate) {
      Long rate = new Long(0L);
      try {
        rate = new Long((String)rateLayeNumMap.get("PDH" + portRate));
      }
      catch (Exception ce) {
      }
      return rate.longValue();
    }

    public static long getMstpCtpLayerRate(String portRate) {
      Long rate = new Long(0L);
      try {
        rate = new Long((String)rateLayeNumMap.get("MSTP" + portRate));
      }
      catch (Exception ce) {
      }
      return rate.longValue();
    }

    public static long getDwdmCtpLayerRate(String portRate) {
      Long rate = new Long(0L);
      try {
        rate = new Long((String)rateLayeNumMap.get("SDH" + portRate));
      }
      catch (Exception ce) {
      }
      return rate.longValue();
    }

    public static String getDwdmLayer(String portRate) {
      return (String)dwdmLayerMap.get(portRate);
    }

    public static String getMstpLayer(String portRate) {
      return (String)mstpLayerMap.get(portRate);
    }

    public static String getCtpLayerCHName(String ctpENName) {
      Set keyset = layerRateNameMap.keySet();
      Iterator point = keyset.iterator();
      String ctpCHName = "";
      while (point.hasNext()) {
        String keyName = (String)point.next();
        if (ctpENName.startsWith(keyName)) {
          ctpCHName = (String)layerRateNameMap.get(keyName);
          break;
        }
      }
      return ctpCHName;
    }

    static
    {
      rateLayeNumMap.put("PDH1.5M", "2");
      rateLayeNumMap.put("PDH6M", "3");
      rateLayeNumMap.put("PDH45M", "4");
      rateLayeNumMap.put("PDH2M", "5");
      rateLayeNumMap.put("PDH4M", "94");
      rateLayeNumMap.put("PDH8M", "6");
      rateLayeNumMap.put("PDH12M", "698");
      rateLayeNumMap.put("PDH16M", "699");
      rateLayeNumMap.put("PDH34M", "7");
      rateLayeNumMap.put("PDH68M", "700");
      rateLayeNumMap.put("PDH140M", "8");
      rateLayeNumMap.put("PDH280M", "701");
      rateLayeNumMap.put("PDH565M", "9");

      rateLayeNumMap.put("SDH2M", "11");
      rateLayeNumMap.put("SDH34M", "13");
      rateLayeNumMap.put("SDH45M", "13");
      rateLayeNumMap.put("SDH155M", "15");
      rateLayeNumMap.put("SDH2.5G", "17");
      rateLayeNumMap.put("SDH10G", "18");
      rateLayeNumMap.put("SDH40G", "78");

      rateLayeNumMap.put("MSTP10M", "692");
      rateLayeNumMap.put("MSTP100M", "693");
      rateLayeNumMap.put("MSTP1G", "694");
      rateLayeNumMap.put("MSTP10G", "695");

      pdhLayerMap.put("1.5M", "ds1");
      pdhLayerMap.put("6M", "ds2");
      pdhLayerMap.put("45M", "ds3");
      pdhLayerMap.put("4M", "e20");
      pdhLayerMap.put("2M", "e1");
      pdhLayerMap.put("8M", "e2");
      pdhLayerMap.put("12M", "e16");
      pdhLayerMap.put("16M", "e30");
      pdhLayerMap.put("34M", "e3");
      pdhLayerMap.put("68M", "e32");
      pdhLayerMap.put("140M", "e4");
      pdhLayerMap.put("280M", "e42");
      pdhLayerMap.put("565M", "e5");

      sdhLayerMap.put("2M", "vt2_tu12");
      sdhLayerMap.put("34M", "tu3_vc3");
      sdhLayerMap.put("45M", "tu3_vc3");
      sdhLayerMap.put("155M", "sts3c_au4");
      sdhLayerMap.put("622M", "sts12c_vc4_4c");
      sdhLayerMap.put("1.25G", "sts24c_vc4_8c");
      sdhLayerMap.put("2.5G", "sts48c_vc4_16c");
      sdhLayerMap.put("10G", "sts192c_vc4_64c");

      dwdmLayerMap.put("40G", "ODU3");
      dwdmLayerMap.put("10G", "ODU2");
      dwdmLayerMap.put("2.5G", "ODU1");

      mstpLayerMap.put("2M", "vt2_tu12");
      mstpLayerMap.put("10M", "mstp_eth_10M");
      mstpLayerMap.put("100M", "mstp_eth_100M");
      mstpLayerMap.put("45M", "tu3_vc3");
      mstpLayerMap.put("155M", "sts3c_au4");
      mstpLayerMap.put("1G", "sts48c_vc4_16c");
      mstpLayerMap.put("10G", "sts192c_vc4_64c");

      layerRateNameMap.put("vt2_tu12", "2M");
      layerRateNameMap.put("tu3_vc3", "34M");
      layerRateNameMap.put("sts3c_au4-j", "155M");
      layerRateNameMap.put("sts48c_vc4_16c", "2.5G");
      layerRateNameMap.put("sts192c_vc4_64c", "10G");
      layerRateNameMap.put("odu3", "40G");
      layerRateNameMap.put("odu2", "10G");
      layerRateNameMap.put("odu1", "2.5G");
      layerRateNameMap.put("otu3", "40G");
      layerRateNameMap.put("otu2", "10G");
      layerRateNameMap.put("otu1", "2.5G");
      layerRateNameMap.put("och", "λ");
      layerRateNameMap.put("dsr", "DSR");
      layerRateNameMap.put("ots", "OTS");
      layerRateNameMap.put("oms", "OMS");
      layerRateNameMap.put("os", "OM");
      layerRateNameMap.put("e1", "2M");
      layerRateNameMap.put("e2", "8M");
      layerRateNameMap.put("e16", "12M");
      layerRateNameMap.put("e30", "16M");
      layerRateNameMap.put("e3", "34M");
      layerRateNameMap.put("e32", "68M");
      layerRateNameMap.put("e4", "140M");
      layerRateNameMap.put("e42", "280M");
      layerRateNameMap.put("5", "565M");
    }
  }

  public static class LayerRate
  {
    public static final int _2D5G = 16;
    public static final int _10G = 17;
    public static final int _40G = 19;
    public static final int VC4 = 9;
    public static final int VC3 = 4;
    public static final int VC12 = 1;
  }
}