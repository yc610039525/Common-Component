package com.boco.transnms.common.bussiness.helper;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.lang.StringHelper;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.misc.NpnProvinceInterfaceDto;
import com.boco.transnms.server.dao.base.DaoHomeFactory;
import com.boco.transnms.server.dao.base.GenericDAO;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;

public class NpnProvinceInterfaceModel
{
  private static NpnProvinceInterfaceModel instance = new NpnProvinceInterfaceModel();

  public NpnProvinceInterfaceDto getNpnProvinceInterfaceByDistrictName(String name)
  {
    NpnProvinceInterfaceDto dbo = null;
    if (!StringHelper.isEmpty(name)) {
      try {
        String wheresql = " RElATED_DISTRICT = '" + name + "'";
        List dataList = getNpnProvinceInterfaceBySql(wheresql);
        if ((dataList != null) && (!dataList.isEmpty()))
          dbo = (NpnProvinceInterfaceDto)dataList.get(0);
      }
      catch (Exception e) {
        LogHome.getLog().error("", e);
      }

    }

    return dbo;
  }

  public List getAllNpnProvinceInterfaceByIsAlarm()
  {
    String wheresql = " IS_ALARM_OPEN >= 1";

    List list = getNpnProvinceInterfaceBySql(wheresql);

    return list;
  }

  public List getAllNpnProvinceInterfaceByIsSheet()
  {
    String wheresql = " IS_SHEET_OPEN >= 1";

    List list = getNpnProvinceInterfaceBySql(wheresql);

    return list;
  }

  public void modify(NpnProvinceInterfaceDto dto)
  {
  }

  public static NpnProvinceInterfaceModel getInstance()
  {
    return instance;
  }

  private List getNpnProvinceInterfaceBySql(String wheresql) {
    String sql = "SELECT RElATED_DISTRICT,IS_SHEET_OPEN,IS_ALARM_OPEN,IP_ADDRESS,PORT_NUMBER FROM NPN_PROVINCE_INTERFACE ";
    if (!StringHelper.isEmpty(wheresql)) {
      sql = sql + " WHERE " + wheresql;
    }
    List list = new ArrayList();
    try {
      DataObjectList dataList = getGenericDAO().selectDBOs(sql, new Class[] { String.class, Long.TYPE, Long.TYPE, String.class, Long.TYPE });

      for (int i = 0; i < dataList.size(); i++) {
        GenericDO dbo = (GenericDO)dataList.get(i);
        NpnProvinceInterfaceDto dto = new NpnProvinceInterfaceDto();

        String relatedDistrict = dbo.getAttrString("1");
        dto.setRelatedDistrict(relatedDistrict);
        long sheet = dbo.getAttrLong("2");
        if (sheet == 0L)
          dto.setIsSheetOpen(false);
        else {
          dto.setIsSheetOpen(true);
        }
        long alarm = dbo.getAttrLong("3");
        if (alarm == 0L)
          dto.setIsAlarmOpen(false);
        else {
          dto.setIsAlarmOpen(true);
        }
        String address = dbo.getAttrString("4");
        dto.setIpAddress(address);
        long portnum = dbo.getAttrLong("5");
        dto.setPortNumber(portnum);
        list.add(dto);
      }
    } catch (Exception e) {
      LogHome.getLog().error("", e);
    }
    return list;
  }

  public Map getAllNpnProvinceInterface() {
    List list = getNpnProvinceInterfaceBySql("");
    Map npnProvinceInterfaces = new HashMap();
    Iterator i$;
    if ((list != null) && (!list.isEmpty())) {
      for (i$ = list.iterator(); i$.hasNext(); ) { Object object = i$.next();
        NpnProvinceInterfaceDto dto = (NpnProvinceInterfaceDto)object;
        npnProvinceInterfaces.put(dto.getRelatedDistrcit(), dto);
      }
    }
    return npnProvinceInterfaces;
  }

  private GenericDAO getGenericDAO() {
    return (GenericDAO)DaoHomeFactory.getInstance().getDAO("GenericDAO");
  }
}