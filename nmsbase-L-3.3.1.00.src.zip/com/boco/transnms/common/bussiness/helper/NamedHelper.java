package com.boco.transnms.common.bussiness.helper;

import com.boco.transnms.common.bussiness.consts.ElementEnum;
import com.boco.transnms.common.bussiness.consts.ElementEnum.CardType;
import com.boco.transnms.common.dto.Card;
import com.boco.transnms.common.dto.TransElement;

public class NamedHelper
{
  private static NamedHelper helper;
  private static int count = 0;

  public static NamedHelper getInstanse()
  {
    if (helper == null)
      helper = new NamedHelper();
    return helper;
  }

  public String nameCard(TransElement ne, String slotName, Card card)
  {
    if (ne != null) {
      return ne.getLabelCn() + slotName + "-" + ElementEnum.CARD_TYPE.getName(Long.valueOf(card.getCardKind()));
    }
    return slotName + "-" + ElementEnum.CARD_TYPE.getName(Long.valueOf(card.getCardKind()));
  }

  public String namePtp(Card card, long maxPort)
  {
    return card.getLabelCn() + "/" + maxPort;
  }
}