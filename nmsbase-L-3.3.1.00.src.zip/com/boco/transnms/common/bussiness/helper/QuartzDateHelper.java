package com.boco.transnms.common.bussiness.helper;

import com.boco.common.util.except.UserException;
import com.boco.common.util.lang.GenericEnum;
import com.boco.common.util.lang.TimeFormatHelper;
import java.util.Calendar;
import java.util.Date;

public class QuartzDateHelper
{
  public static final TaskCycType TASK_CYC_TYPE = new TaskCycType(null);
  public static final DayOfWeek DAY_OF_WEEK = new DayOfWeek(null);

  public static String getQuartzDateBy(Date startTime, long taskCycType, String taskCyc)
  {
    String quartzDate = "";
    String second = "*";
    String minute = "*";
    String hour = "*";
    String day = "*";
    String month = "*"; String tempMonth = "";
    String year = "*";
    String dayOfWeek = "*";
    Calendar startCal = Calendar.getInstance();
    if (startTime != null) {
      String formatStartTimeStr = TimeFormatHelper.getFormatDate(startTime, "yyyy-MM-dd HH:mm:ss");
      Date formatStartTime = TimeFormatHelper.convertDate(formatStartTimeStr, "yyyy-MM-dd HH:mm:ss");
      startCal.setTime(formatStartTime);
      second = startCal.get(13) + "";
      minute = startCal.get(12) + "";
      hour = startCal.get(10) + "";
      day = startCal.get(5) + "";
      tempMonth = startCal.get(2) + 1 + "";
      if (startCal.get(9) == 1)
        hour = startCal.get(10) + 12 + "";
      else
        hour = startCal.get(10) + "";
    }
    else {
      throw new UserException("开始时间不能为空");
    }

    if (taskCycType == 0L) {
      hour = taskCyc;
      day = "*";
      dayOfWeek = "?";
    } else if (taskCycType == 1L) {
      day = taskCyc;
      dayOfWeek = "?";
    } else if (taskCycType == 2L) {
      day = "?";
      dayOfWeek = taskCyc;
    } else if (taskCycType == 3L) {
      month = taskCyc;
      dayOfWeek = "?";
    } else if (taskCycType == 4L) {
      month = tempMonth;
      dayOfWeek = "?";
    }

    if (taskCycType == 4L)
      quartzDate = second + " " + minute + " " + hour + " " + day + " " + month + " " + dayOfWeek + " " + year;
    else {
      quartzDate = second + " " + minute + " " + hour + " " + day + " " + month + " " + dayOfWeek;
    }

    return quartzDate;
  }

  public static class DayOfWeek extends GenericEnum
  {
    public static final long _sun = 1L;
    public static final long _mon = 2L;
    public static final long _tues = 3L;
    public static final long _wednes = 4L;
    public static final long _thurs = 5L;
    public static final long _fri = 6L;
    public static final long _satur = 7L;

    private DayOfWeek()
    {
      super.putEnum(Long.valueOf(1L), "星期日");
      super.putEnum(Long.valueOf(2L), "星期一");
      super.putEnum(Long.valueOf(3L), "星期二");
      super.putEnum(Long.valueOf(4L), "星期三");
      super.putEnum(Long.valueOf(5L), "星期四");
      super.putEnum(Long.valueOf(6L), "星期五");
      super.putEnum(Long.valueOf(7L), "星期六");
    }
  }

  public static class TaskCycType extends GenericEnum
  {
    public static final long _hour = 0L;
    public static final long _day = 1L;
    public static final long _weekday = 2L;
    public static final long _month = 3L;
    public static final long _year = 4L;

    private TaskCycType()
    {
      super.putEnum(Long.valueOf(0L), "小时");
      super.putEnum(Long.valueOf(1L), "天");
      super.putEnum(Long.valueOf(2L), "星期");
      super.putEnum(Long.valueOf(3L), "月");
      super.putEnum(Long.valueOf(4L), "年");
    }
  }
}