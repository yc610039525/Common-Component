package com.boco.transnms.common.bussiness.helper;

public class FaultHelper
{
  public static class FaultChangeStatus
  {
    public static int NEW = 0;
    public static int CLEARED = 1;
    public static int NEWFAULTTIP = 2;
    public static int UPDATE = 3;
  }
}