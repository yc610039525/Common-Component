package com.boco.transnms.common.cache;

import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.dao.base.IDataAccessObject;
import java.sql.Timestamp;

public abstract interface ICacheLoader
{
  public abstract DataObjectList loadCache(IDataAccessObject paramIDataAccessObject, String paramString);

  public abstract DataObjectList loadCache(IDataAccessObject paramIDataAccessObject, String paramString, Timestamp paramTimestamp);
}