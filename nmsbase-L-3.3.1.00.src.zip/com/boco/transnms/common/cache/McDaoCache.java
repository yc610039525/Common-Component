package com.boco.transnms.common.cache;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.plugins.memcached.MemcachedManager;
import com.boco.transnms.server.dao.base.CacheManagerFactory;
import java.security.MessageDigest;
import java.util.List;
import net.spy.memcached.MemcachedClient;
import org.apache.commons.logging.Log;

public class McDaoCache<K, V>
  implements IDaoCache<K, V>
{
  private final String cacheName;

  public McDaoCache(String _cacheName)
  {
    this.cacheName = _cacheName;
  }

  public void put(K key, V value) {
    MemcachedClient client = getCache(this.cacheName);
    if (client != null)
      client.set(getSha1Key(key.toString()), 0, value);
  }

  public void put(K key, V value, boolean isQuiet)
  {
    MemcachedClient client = getCache(this.cacheName);
    if (client != null)
      client.set(getSha1Key(key.toString()), 0, value);
  }

  public V get(K key)
  {
    Object obj = null;
    MemcachedClient client = getCache(this.cacheName);
    if (client != null) {
      obj = client.get(getSha1Key(key.toString()));
    }
    return obj;
  }

  public V remove(K key)
  {
    MemcachedClient client = getCache(this.cacheName);
    if (client != null) {
      client.delete(getSha1Key(key.toString()));
    }
    return null;
  }

  public void clear() {
    MemcachedClient client = getCache(this.cacheName);
    if (client != null)
      client.flush();
  }

  public boolean containsKey(K key)
  {
    MemcachedClient client = getCache(this.cacheName);
    if (client != null) {
      return client.get(getSha1Key(key.toString())) != null;
    }
    return false;
  }

  public List<K> keySet()
  {
    throw new UserException("memcached不支持该方法");
  }

  public List<V> values() {
    throw new UserException("memcached不支持该方法");
  }

  public int size() {
    return -1;
  }

  private MemcachedClient getCache(String cacheName)
  {
    MemcachedClient client = ((MemcachedManager)CacheManagerFactory.getInstance().getCacheManager()).getCache(cacheName);
    if (client == null) {
      LogHome.getLog().error("memcached缓存对象不存在：" + cacheName + ",请检查memcached服务器是否可用！");
    }
    return client;
  }

  public String getName() {
    MemcachedClient client = null;
    try {
      client = ((MemcachedManager)CacheManagerFactory.getInstance().getCacheManager()).getCache(this.cacheName);
    } catch (Exception ex) {
      if (LogHome.getLog().isDebugEnabled()) {
        LogHome.getLog().debug("获取缓存名称失败" + this.cacheName);
      }
    }
    if (client != null) {
      return this.cacheName;
    }
    return "DEFAULT";
  }

  private static String getSha1Key(String key)
  {
    String sha1Key = key;
    try {
      byte[] plainText = key.getBytes("UTF-8");
      MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
      messageDigest.update(plainText);
      byte[] digest = messageDigest.digest();
      String keyTemp = "";
      for (int i = 0; i < digest.length; i++) {
        keyTemp = keyTemp + digest[i];
      }
      sha1Key = keyTemp;
    } catch (Exception e) {
      e.printStackTrace();
    }

    return sha1Key;
  }
}