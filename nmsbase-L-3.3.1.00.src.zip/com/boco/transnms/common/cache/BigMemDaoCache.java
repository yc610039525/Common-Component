package com.boco.transnms.common.cache;

import com.boco.common.util.debug.LogHome;
import com.boco.plugins.ehcache.EcacheManager;
import com.boco.plugins.memcached.MemcachedManager;
import com.boco.transnms.server.dao.base.CacheManagerFactory;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;
import net.spy.memcached.MemcachedClient;
import org.apache.commons.logging.Log;

public class BigMemDaoCache<K, V>
  implements IDaoCache<K, V>
{
  private final String cacheName;

  public BigMemDaoCache(String cacheName, boolean isLocal)
  {
    this.cacheName = cacheName;
    if (isLocal)
      EcacheManager.getInstance().addLocalCache(this.cacheName);
    else
      EcacheManager.getInstance().addDistributedCahce(this.cacheName);
  }

  public void put(K key, V value)
  {
    put(key, value, false);
    try {
      ((MemcachedManager)CacheManagerFactory.getInstance().getCacheManager()).getCache(this.cacheName).add(key.toString(), 0, value);
    } catch (Exception ex) {
      LogHome.getLog().warn("同步更新Memcached缓存失败：" + ex);
    }
  }

  public void put(K key, V value, boolean isQuiet) {
    if (isQuiet) {
      getCache().putQuiet(new Element(key, value));
    } else {
      getCache().put(new Element(key, value));
      try {
        ((MemcachedManager)CacheManagerFactory.getInstance().getCacheManager()).getCache(this.cacheName).add(key.toString(), 0, value);
      } catch (Exception ex) {
        LogHome.getLog().warn("同步更新Memcached缓存失败：" + ex);
      }
    }
  }

  public V get(K key) {
    Object rtn = null;
    Element element = getCache().getQuiet(key);
    if (element == null)
      try
      {
        rtn = ((MemcachedManager)CacheManagerFactory.getInstance().getCacheManager()).getCache(this.cacheName).get(key.toString());
      } catch (Exception ex) {
        LogHome.getLog().warn("从Memcached获取缓存失败：" + ex);
      }
    else {
      rtn = element.getValue();
    }
    return rtn;
  }

  public V remove(K key) {
    Object value = get(key);
    getCache().remove(key);
    try {
      ((MemcachedManager)CacheManagerFactory.getInstance().getCacheManager()).getCache(this.cacheName).delete(key.toString());
    } catch (Exception ex) {
      LogHome.getLog().warn("同步Memcached删除缓存对象失败：" + ex);
    }
    return value;
  }

  public boolean containsKey(K key) {
    return getCache().isKeyInCache(key);
  }

  public void clear() {
    getCache().removeAll();
  }

  public List<K> keySet() {
    return getCache().getKeys();
  }

  public int size() {
    return getCache().getSize();
  }

  private Cache getCache() {
    return EcacheManager.getInstance().getCache(this.cacheName);
  }

  public List<V> values() {
    List values = new ArrayList();
    List keys = keySet();
    for (Iterator i$ = keys.iterator(); i$.hasNext(); ) { Object key = i$.next();
      values.add(get(key));
    }
    return values;
  }
}