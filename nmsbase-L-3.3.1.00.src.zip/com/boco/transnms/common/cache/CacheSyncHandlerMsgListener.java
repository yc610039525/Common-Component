package com.boco.transnms.common.cache;

import com.boco.raptor.common.message.IMessage;
import com.boco.raptor.common.message.ISimpleMsgListener;
import com.boco.transnms.server.common.cfg.TnmsServerName;
import java.io.Serializable;
import java.util.Map;

public class CacheSyncHandlerMsgListener<K extends Serializable, V extends Serializable>
  implements ISimpleMsgListener
{
  private String boName = null;
  private String varName = null;
  protected Map<K, V> localCache = null;

  public CacheSyncHandlerMsgListener(String boName, String varName, Map<K, V> localCache) {
    this.boName = boName;
    this.varName = varName;
    this.localCache = localCache;
  }

  public void notify(IMessage _msg)
  {
    if ((_msg instanceof CacheHashMsg)) {
      CacheHashMsg msg = (CacheHashMsg)_msg;
      if (TnmsServerName.isLocalServer(msg.getSourceName())) return;
      String[] targetId = msg.getTargetId().split("-");
      String _boName = targetId[0];
      String _varName = targetId[1];
      if ((this.boName.equals(_boName)) && (this.varName.equals(_varName))) {
        Serializable key = msg.getKey();
        Serializable value = msg.getValue();
        if (msg.getMsgType() == CacheHashMsg.MSG_TYPE.PUT)
          this.localCache.put(key, value);
        else if (msg.getMsgType() == CacheHashMsg.MSG_TYPE.REMOVE)
          this.localCache.remove(key);
        else if (msg.getMsgType() == CacheHashMsg.MSG_TYPE.CLEAR)
          this.localCache.clear();
      }
    }
  }
}