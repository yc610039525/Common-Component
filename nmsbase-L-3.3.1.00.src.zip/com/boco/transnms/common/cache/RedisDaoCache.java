package com.boco.transnms.common.cache;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.plugins.redis.RedisCacheManager;
import com.boco.transnms.server.dao.base.CacheManagerFactory;
import java.util.List;
import org.apache.commons.logging.Log;
import redis.clients.jedis.Jedis;

public class RedisDaoCache<K, V>
  implements IDaoCache<K, V>
{
  private final String cacheName;

  public RedisDaoCache(String _cacheName)
  {
    this.cacheName = _cacheName;
  }

  public void put(K key, V value) {
    Jedis client = getCache(this.cacheName);
    if (client != null)
      client.set(getSha1Key(key.toString()), CacheHelper.getBytesByObject(value));
  }

  public void put(K key, V value, boolean isQuiet)
  {
    Jedis client = getCache(this.cacheName);
    if (client != null)
      client.set(getSha1Key(key.toString()), CacheHelper.getBytesByObject(value));
  }

  public V get(K key)
  {
    Jedis client = getCache(this.cacheName);
    if (client != null) {
      byte[] b = client.get(getSha1Key(key.toString()));
      Object obj = CacheHelper.getObjectByBytes(b);
      return obj;
    }
    return null;
  }

  public V remove(K key)
  {
    Jedis client = getCache(this.cacheName);
    if (client != null) {
      client.del(new byte[][] { getSha1Key(key.toString()) });
    }
    return null;
  }

  public void clear() {
    throw new UserException("redis不支持该方法");
  }

  public boolean containsKey(K key) {
    Jedis client = getCache(this.cacheName);
    if (client != null) {
      return client.get(getSha1Key(key.toString())) != null;
    }
    return false;
  }

  public List<K> keySet()
  {
    throw new UserException("redis不支持该方法");
  }

  public List<V> values() {
    throw new UserException("redis不支持该方法");
  }

  public int size() {
    return -1;
  }

  private Jedis getCache(String cacheName)
  {
    Jedis client = ((RedisCacheManager)CacheManagerFactory.getInstance().getCacheManager()).getCache(cacheName);
    if (client == null) {
      LogHome.getLog().error("redis缓存对象不存在：" + cacheName + ",请检查redis服务器是否可用！");
    }
    return client;
  }
  public String getName() {
    return this.cacheName;
  }

  private static byte[] getSha1Key(String key) {
    return key.getBytes();
  }
}