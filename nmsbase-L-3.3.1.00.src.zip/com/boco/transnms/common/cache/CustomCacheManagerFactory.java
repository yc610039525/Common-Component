package com.boco.transnms.common.cache;

import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;
import net.sf.ehcache.config.CacheConfiguration;

public class CustomCacheManagerFactory
{
  private static CustomCacheManagerFactory instance = new CustomCacheManagerFactory();
  private String syncTopicName = "";
  private Map<String, GenericDaoCache> cacheManagers = new HashMap();
  private Map<String, IDaoCache> moduleCustomCacheManagers = new HashMap();

  public Map<String, GenericDaoCache> getCacheManagers()
  {
    return this.cacheManagers;
  }

  public void setCacheManagers(Map<String, GenericDaoCache> cacheManagers) {
    this.cacheManagers = cacheManagers;
  }

  public String getSyncTopicName() {
    return this.syncTopicName;
  }

  public void setSyncTopicName(String syncTopicName) {
    this.syncTopicName = syncTopicName;
  }

  public static CustomCacheManagerFactory getInstance()
  {
    return instance;
  }

  public IDaoCache createModuleCustomCache(String cacheName, int timeToIdleSeconds, int timeToLiveSeconds) {
    IDaoCache cache = (IDaoCache)this.moduleCustomCacheManagers.get(cacheName);
    if (cache == null) {
      cache = new EcDaoCache(cacheName, createCacheConfiguration(timeToIdleSeconds, timeToLiveSeconds));
      this.moduleCustomCacheManagers.put(cacheName, cache);
    }
    return cache;
  }

  public IDaoCache getModuleCustomCache(String cacheName) {
    return (IDaoCache)this.moduleCustomCacheManagers.get(cacheName);
  }

  private CacheConfiguration createCacheConfiguration(int timeToIdleSeconds, int timeToLiveSeconds) {
    CacheConfiguration cf = new CacheConfiguration();
    cf.setEternal(false);

    cf.setTimeToIdleSeconds(timeToIdleSeconds);
    cf.setTimeToLiveSeconds(timeToLiveSeconds);
    cf.setOverflowToDisk(false);
    cf.setMemoryStoreEvictionPolicy("LRU");
    cf.setMaxElementsInMemory(100000);
    return cf;
  }

  public GenericDaoCache getCustomCache(String boName, String varName) {
    String key = boName + "-" + varName;
    GenericDaoCache cache = (GenericDaoCache)this.cacheManagers.get(key);
    return cache;
  }

  public static void main(String[] args) {
    IDaoCache cache = getInstance().createModuleCustomCache("test", 3, 0);
    cache.put("dd", "dd");
    try {
      Thread.sleep(1000L);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    System.out.println(cache.get("dd"));
    try {
      Thread.sleep(3000L);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    System.out.println(cache.get("dd"));
  }
}