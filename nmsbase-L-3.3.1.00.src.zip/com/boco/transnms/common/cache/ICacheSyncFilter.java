package com.boco.transnms.common.cache;

import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;

public abstract interface ICacheSyncFilter
{
  public abstract boolean doFilter(DataObjectList paramDataObjectList);

  public abstract boolean doFilter(GenericDO paramGenericDO);
}