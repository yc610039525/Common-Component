package com.boco.transnms.common.cache;

import com.boco.raptor.common.message.GenericMessage;
import java.io.Serializable;

public class CacheHashMsg extends GenericMessage
{
  private MSG_TYPE msgType;
  private Serializable key;

  public CacheHashMsg(String topicName, MSG_TYPE msgType)
  {
    super(topicName);
    this.msgType = msgType;
  }

  public void put(Serializable key, Serializable value) {
    this.key = key;
    super.setDataObject(value);
  }

  public void setKey(Serializable key) {
    this.key = key;
  }

  public Serializable getKey() {
    return this.key;
  }

  public Serializable getValue() {
    return super.getDataObject();
  }

  public void setValue(Serializable value) {
    super.setDataObject(value);
  }

  public MSG_TYPE getMsgType() {
    return this.msgType;
  }

  public static enum MSG_TYPE
  {
    PUT, REMOVE, CLEAR;
  }
}