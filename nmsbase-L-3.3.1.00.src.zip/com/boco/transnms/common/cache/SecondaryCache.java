package com.boco.transnms.common.cache;

public class SecondaryCache
{
}