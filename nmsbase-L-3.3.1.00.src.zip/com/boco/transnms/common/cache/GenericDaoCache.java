package com.boco.transnms.common.cache;

import com.boco.common.util.debug.LogHome;
import com.boco.raptor.common.message.MsgBusManager;
import com.boco.transnms.server.common.cfg.TnmsServerName;
import com.boco.transnms.server.common.cfg.TnmsServerName.ServerName;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.commons.logging.Log;

public class GenericDaoCache<K extends Serializable, V extends Serializable>
  implements IDaoCache<K, V>
{
  protected Map<K, V> localCache = new ConcurrentHashMap();
  private boolean isInited = false;
  private String syncTopicName;
  private String boName;
  private String varName;

  public GenericDaoCache(String boName, String varName)
  {
    this.boName = boName;
    this.varName = varName;
  }

  public void init() {
    try {
      this.syncTopicName = CustomCacheManagerFactory.getInstance().getSyncTopicName();
      if ((!TnmsServerName.getLocalServerFullName().equals(TnmsServerName.ServerName.ALL.toString())) && (!this.isInited)) {
        MsgBusManager.getInstance().addMsgListener(this.syncTopicName, "", new CacheSyncHandlerMsgListener(this.boName, this.varName, this.localCache));
        this.isInited = true;
      }
    } catch (Exception ex) {
      LogHome.getLog().error(ex.toString(), ex);
      LogHome.getLog().error("MQ消息通道异常，不能同步BO缓存变化 ！");
    }
  }

  public void put(K key, V value) {
    put(key, value, false);
  }

  public void put(K key, V value, boolean isQuiet) {
    this.localCache.put(key, value);
    if (!isQuiet)
      sendMessage(CacheHashMsg.MSG_TYPE.PUT, key, value);
  }

  public V get(K key)
  {
    return (Serializable)this.localCache.get(key);
  }

  public V remove(K key) {
    Serializable value = (Serializable)this.localCache.remove(key);
    sendMessage(CacheHashMsg.MSG_TYPE.REMOVE, key, null);
    return value;
  }

  public void clear() {
    this.localCache.clear();
    sendMessage(CacheHashMsg.MSG_TYPE.CLEAR, null, null);
  }

  public boolean containsKey(K key) {
    return this.localCache.containsKey(key);
  }

  public List<K> keySet() {
    List list = new ArrayList(size());
    list.addAll(this.localCache.keySet());
    return list;
  }

  public List<V> values() {
    List values = new ArrayList(size());
    values.addAll(this.localCache.values());
    return values;
  }

  public int size() {
    return this.localCache.size();
  }

  public void setCache(Map<K, V> localCache) {
    this.localCache = localCache;
  }

  public Map<K, V> getCache() {
    return this.localCache;
  }

  private void sendMessage(CacheHashMsg.MSG_TYPE msgType, Serializable key, Serializable value) {
    if ((!TnmsServerName.isAllInOneServer()) && (this.isInited)) {
      CacheHashMsg msg = new CacheHashMsg(this.syncTopicName, msgType);
      msg.setTargetId(this.boName + "-" + this.varName);
      msg.setSourceName(TnmsServerName.getLocalServerFullName());
      msg.put(key, value);
      MsgBusManager.getInstance().sendMessage(msg);
    }
  }
}