package com.boco.transnms.common.cache;

public class CustomCacheName
{
  public static String PATH_CHECK_TRANS_ELEMENT_CUID = "PATH_CHECK_TRANS_ELEMENT_CUID";
  public static String PATH_CHECK_PTP_CUID = "PATH_CHECK_PTP_CUID";
  public static String PATH_CHECK_PTP_FDN = "PATH_CHECK_PTP_FDN";
  public static String PATH_CHECK_CTP_CUID = "PATH_CHECK_CTP_CUID";
  public static String PATH_CHECK_CTP_FDN = "PATH_CHECK_CTP_FDN";
  public static String PATH_CHECK_TRANSPATH_CUID = "PATH_CHECK_TRANSPATH_CUID";
}