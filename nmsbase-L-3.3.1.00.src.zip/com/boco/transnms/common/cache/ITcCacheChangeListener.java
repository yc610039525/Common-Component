package com.boco.transnms.common.cache;

public abstract interface ITcCacheChangeListener
{
  public abstract void notify(Object paramObject1, Object paramObject2);
}