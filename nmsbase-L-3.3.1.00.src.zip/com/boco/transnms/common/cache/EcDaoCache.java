package com.boco.transnms.common.cache;

import com.boco.plugins.ehcache.EcacheManager;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;
import net.sf.ehcache.config.CacheConfiguration;

public class EcDaoCache<K, V>
  implements IDaoCache<K, V>
{
  private final String cacheName;

  public EcDaoCache(String cacheName, boolean isLocal)
  {
    this.cacheName = cacheName;
    if (isLocal)
      EcacheManager.getInstance().addLocalCache(this.cacheName);
    else
      EcacheManager.getInstance().addDistributedCahce(this.cacheName);
  }

  public EcDaoCache(String cacheName, CacheConfiguration cf)
  {
    this.cacheName = cacheName;
    EcacheManager.getInstance().addLocalCache(this.cacheName, cf);
  }

  public void put(K key, V value)
  {
    put(key, value, false);
  }

  public void put(K key, V value, boolean isQuiet) {
    if (isQuiet)
      getCache().putQuiet(new Element(key, value));
    else
      getCache().put(new Element(key, value));
  }

  public V get(K key)
  {
    Element element = getCache().getQuiet(key);
    if (element == null)
    {
      return null;
    }
    return element.getValue();
  }

  public V remove(K key) {
    Object value = get(key);
    getCache().remove(key);
    return value;
  }

  public boolean containsKey(K key) {
    return getCache().isKeyInCache(key);
  }

  public void clear() {
    getCache().removeAll();
  }

  public List<K> keySet() {
    return getCache().getKeys();
  }

  public int size() {
    return getCache().getSize();
  }

  private Cache getCache() {
    return EcacheManager.getInstance().getCache(this.cacheName);
  }

  public List<V> values() {
    List values = new ArrayList();
    List keys = keySet();
    for (Iterator i$ = keys.iterator(); i$.hasNext(); ) { Object key = i$.next();
      values.add(get(key));
    }
    return values;
  }
}