package com.boco.transnms.common.cache;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;

public class CacheHelper
{
  public static byte[] getBytesByObject(Object value)
  {
    byte[] b = new byte[0];
    try {
      ByteArrayOutputStream bos = new ByteArrayOutputStream();
      ObjectOutput out = new ObjectOutputStream(bos);
      out.writeObject(value);
      b = bos.toByteArray();
      out.close();
      bos.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
    return b;
  }

  public static Object getObjectByBytes(byte[] b) {
    Object o = null;
    try {
      if (b != null) {
        ByteArrayInputStream bis = new ByteArrayInputStream(b);

        ObjectInput in = new ObjectInputStream(bis);
        o = in.readObject();
        bis.close();
        in.close();
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return o;
  }
}