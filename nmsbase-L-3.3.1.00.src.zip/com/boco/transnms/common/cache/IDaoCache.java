package com.boco.transnms.common.cache;

import java.util.List;

public abstract interface IDaoCache<K, V>
{
  public abstract void put(K paramK, V paramV);

  public abstract void put(K paramK, V paramV, boolean paramBoolean);

  public abstract V get(K paramK);

  public abstract V remove(K paramK);

  public abstract void clear();

  public abstract boolean containsKey(K paramK);

  public abstract List<K> keySet();

  public abstract List<V> values();

  public abstract int size();
}