package com.boco.transnms.common.cache;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HashDaoCache<K, V>
  implements IDaoCache<K, V>
{
  protected final Map<K, V> localCache = new HashMap();

  public synchronized void put(K key, V value)
  {
    this.localCache.put(key, value);
  }

  public synchronized void put(K key, V value, boolean isQuiet) {
    this.localCache.put(key, value);
  }

  public synchronized V get(K key) {
    return this.localCache.get(key);
  }

  public synchronized V remove(K key) {
    return this.localCache.remove(key);
  }

  public synchronized void clear() {
    this.localCache.clear();
  }

  public synchronized boolean containsKey(K key) {
    return this.localCache.containsKey(key);
  }

  public synchronized List<K> keySet() {
    List list = new ArrayList(size());
    list.addAll(this.localCache.keySet());
    return list;
  }

  public List<V> values() {
    List values = new ArrayList(size());
    values.addAll(this.localCache.values());
    return values;
  }

  public int size() {
    return this.localCache.size();
  }
}