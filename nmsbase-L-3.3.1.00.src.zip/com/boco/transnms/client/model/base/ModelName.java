package com.boco.transnms.client.model.base;

public class ModelName
{
  public static final String AlarmReciver = "AlarmReciver";
  public static final String EventReciver = "EventReciver";
  public static final String ObjectEventReciver = "ObjectEventReciver";
  public static final String SystemEventReceiver = "SystemEventReceiver";
  public static final String UserSecurityModel = "UserSecurityModel";
}