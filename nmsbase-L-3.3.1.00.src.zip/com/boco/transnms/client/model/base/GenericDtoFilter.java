package com.boco.transnms.client.model.base;

import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class GenericDtoFilter extends GenericDO
  implements IFilter
{
  protected Map valueMap = new HashMap();

  public String getAttrName()
  {
    return getAttrString("FILTER_ATTR_NAME");
  }

  public void setAttrName(String attrName) {
    setAttrValue("FILTER_ATTR_NAME", attrName);
  }

  public List getValues() {
    return getAttrList(getAttrName());
  }

  public void setValues(List values) {
    setAttrValue(getAttrName(), values);
    this.valueMap.clear();
    Iterator i$;
    if (values != null)
      for (i$ = values.iterator(); i$.hasNext(); ) { Object value = i$.next();
        this.valueMap.put(value, value);
      }
  }

  public boolean isEnable(GenericDO dto)
  {
    if (this.valueMap.isEmpty()) {
      return true;
    }
    Object value = dto.getAttrValue(getAttrName());
    if (this.valueMap.containsKey(value))
      return true;
    return false;
  }

  public boolean isEnable(Object o) {
    if ((o instanceof GenericDO)) {
      return isEnable((GenericDO)o);
    }
    return false;
  }
}