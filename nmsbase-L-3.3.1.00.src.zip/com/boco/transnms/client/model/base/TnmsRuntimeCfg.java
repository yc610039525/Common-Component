package com.boco.transnms.client.model.base;

import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.server.common.cfg.TransNmsCfg.ProductSP;
import com.boco.transnms.server.common.cfg.TransNmsCfg.ProductType;
import java.util.HashMap;

public class TnmsRuntimeCfg
{
  public static String productSP = TransNmsCfg.ProductSP.CHINA_MOBILE;
  public static String productType = TransNmsCfg.ProductType.TNMS;
  public static boolean supportMstp = false;
  public static String defaultTheme = "GreyTheme";
  public static boolean startNanfangTheme = false;
  public static boolean vipTraph = false;

  protected void init()
    throws Exception
  {
    HashMap map = (HashMap)BoCmdFactory.getInstance().execBoCmd("IVersionManagerBO.getTnmsRuntimeCfgParams", new Object[] { new BoActionContext() });

    productSP = (String)map.get("productSP");
    productType = (String)map.get("productType");
    startNanfangTheme = ((Boolean)map.get("startNanfangTheme")).booleanValue();
    vipTraph = ((Boolean)map.get("vipTraph")).booleanValue();
  }
}