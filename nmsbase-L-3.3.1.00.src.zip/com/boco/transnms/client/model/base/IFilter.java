package com.boco.transnms.client.model.base;

public abstract interface IFilter
{
  public abstract boolean isEnable(Object paramObject);
}