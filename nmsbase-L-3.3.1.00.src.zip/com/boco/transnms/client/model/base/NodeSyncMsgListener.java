package com.boco.transnms.client.model.base;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.io.NetHelper;
import com.boco.raptor.common.message.GenericMessage;
import com.boco.raptor.common.message.IMessage;
import com.boco.raptor.common.message.ISimpleMsgListener;
import com.boco.raptor.common.message.MsgBusManager;
import com.boco.transnms.common.dto.misc.DevState;
import org.apache.commons.logging.Log;

public class NodeSyncMsgListener
  implements ISimpleMsgListener
{
  private static String NODE_STATE_ACK = "NODE_STATE_ACK";
  private DevState devState;
  private String topicName = "";

  public NodeSyncMsgListener(long devType) {
    this.devState = new DevState();
    this.devState.setDevIp(NetHelper.getHostIP());
    this.devState.setDevName(NetHelper.getHostName());
    this.devState.setDevType(Long.valueOf(devType));
    this.devState.setCuid(this.devState.getDevName() + "_" + devType + "_" + NetHelper.getHostIP());
    initListener(devType);
  }

  private void initListener(long devType) {
    try {
      int _devType = Integer.parseInt(Long.valueOf(devType).toString());
      switch (_devType) {
      case 50:
        this.topicName = "T_CM_NODE_STATE_SYNC";
        break;
      case 51:
        this.topicName = "T_CM_NODE_STATE_SYNC";
        break;
      case 52:
        this.topicName = "T_CM_NODE_STATE_SYNC";
        break;
      case 53:
        this.topicName = "T_CM_NODE_STATE_SYNC";
        break;
      case 54:
        this.topicName = "T_AM_NODE_STATE_SYNC";
        break;
      case 55:
        this.topicName = "T_CM_NODE_STATE_SYNC";
        break;
      case 56:
        this.topicName = "T_CM_NODE_STATE_SYNC";
        break;
      }

      if (("T_AM_NODE_STATE_SYNC".equals(this.topicName)) || ("T_CM_NODE_STATE_SYNC".equals(this.topicName)) || ("T_DM_NODE_STATE_SYNC".equals(this.topicName)))
      {
        MsgBusManager.getInstance().addMsgListener(this.topicName, "", this);
      }
      else LogHome.getLog().error("未正确配置web服务器往指定服务器发送的TOPIC名称");
    }
    catch (Exception e)
    {
      LogHome.getLog().error("添加客户端节点状态消息失败", e);
    }
  }

  public void notify(IMessage msg)
  {
    if (((msg instanceof GenericMessage)) && 
      (msg.getTargetId().equals("NODE_STATE_QUERY")))
      sendAckMsg();
  }

  private void sendAckMsg()
  {
    if (this.devState != null) {
      GenericMessage ackMsg = new GenericMessage(this.topicName, NODE_STATE_ACK, this.devState);
      MsgBusManager.getInstance().sendMessage(ackMsg);
    }
  }

  public DevState getDevState() {
    return this.devState;
  }
}