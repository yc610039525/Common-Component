package com.boco.transnms.client.model.base;

public abstract interface IBoProxyChangeListener
{
  public abstract void serverChanged(BoProxyChangeType paramBoProxyChangeType);

  public abstract void updateView(BoProxyChangeType paramBoProxyChangeType);
}