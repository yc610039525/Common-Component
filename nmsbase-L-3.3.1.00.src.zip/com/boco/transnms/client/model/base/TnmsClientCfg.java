package com.boco.transnms.client.model.base;

import java.util.List;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class TnmsClientCfg
{
  private static final String SupportNormalLogin = "SupportNormalLogin";
  private static final String SupportSingleSignOnLogin = "SupportSingleSignOnLogin";
  private static final String Support4ALogin = "Support4ALogin";
  private static final String SupportBoco4ALogin = "SupportBoco4ALogin";
  private static final String SupportLink4ALogin = "SupportLink4ALogin";
  private static TnmsClientCfg instance = new TnmsClientCfg();
  private List mapServiceConfig;
  private String loginPattern = "SupportNormalLogin";
  private String casServerUrlPrefix;
  private boolean casLogin = false;

  public static TnmsClientCfg loadCfgFile(String springCfgFile)
    throws Exception
  {
    FileSystemXmlApplicationContext springContext = new FileSystemXmlApplicationContext(springCfgFile);
    return instance;
  }

  public static TnmsClientCfg getInstance() {
    return instance;
  }

  public String getCasServerUrlPrefix() {
    return this.casServerUrlPrefix;
  }

  public void setCasServerUrlPrefix(String casServerUrlPrefix) {
    this.casServerUrlPrefix = casServerUrlPrefix;
  }

  public void setLoginPattern(String loginPattern)
  {
    this.loginPattern = loginPattern;
  }

  public String getLoginPattern() {
    return this.loginPattern;
  }

  public void setMapServiceConfig(List mapServiceConfig) {
    this.mapServiceConfig = mapServiceConfig;
  }

  public List getMapServiceConfig() {
    return this.mapServiceConfig;
  }

  public boolean isSupportNormalLogin() {
    return this.loginPattern.equals("SupportNormalLogin");
  }

  public boolean isSupportSingleSignOnLogin() {
    return this.loginPattern.equals("SupportSingleSignOnLogin");
  }

  public boolean isSupportSingleSignon() {
    return this.loginPattern.equals("SupportSingleSignOnLogin");
  }

  public boolean isSupport4ALogin() {
    return this.loginPattern.equals("Support4ALogin");
  }

  public boolean isSupportBoco4ALogin() {
    return this.loginPattern.equals("SupportBoco4ALogin");
  }

  public boolean isSupportLink4ALogin() {
    return this.loginPattern.equals("SupportLink4ALogin");
  }

  public void setCasLogin(boolean pCasLogin) {
    this.casLogin = pCasLogin;
  }

  public boolean isCasLogin() {
    return this.casLogin;
  }
}