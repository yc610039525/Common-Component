package com.boco.transnms.server.bo.upload;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.ibo.upload.IUploadBO;
import com.boco.transnms.server.common.cfg.SystemEnv;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="CM")
public class UploadBO extends AbstractBO
  implements IUploadBO
{
  public UploadFile addFile(BoActionContext actionContext, UploadFile file)
    throws UserException
  {
    BufferedInputStream buffer = null;
    BufferedOutputStream bufferout = null;
    String serverPath = checkSaveDir();
    if (file != null) {
      try {
        buffer = new BufferedInputStream(new ByteArrayInputStream(file.getFileByte()));

        File savedFile = new File(serverPath + file.getFileName());
        bufferout = new BufferedOutputStream(new FileOutputStream(savedFile));
        int i = 0;
        while ((i = buffer.read()) != -1) {
          bufferout.write(i);
        }
        file.setModifyDate(savedFile.lastModified());
        return file;
      } catch (FileNotFoundException e) {
        LogHome.getLog().info("读取文件失败");
        throw new UserException(e.getMessage());
      }
      catch (IOException e) {
        LogHome.getLog().info("写文件失败");
        throw new UserException(e.getMessage());
      } finally {
        try {
          if (bufferout != null) {
            bufferout.flush();
            bufferout.close();
          }
          if (buffer != null)
            buffer.close();
        }
        catch (IOException e) {
          LogHome.getLog().info("写文件失败");
        }
      }
    }
    return null;
  }

  public UploadFile getFile(BoActionContext actionContext, UploadFile uploadFile) throws UserException {
    String serverPath = checkSaveDir();

    File file = new File(serverPath + uploadFile.getFileName());
    if (file.exists()) {
      return new UploadFile(file);
    }
    return null;
  }

  private String checkSaveDir() {
    String serverPath = SystemEnv.getPathEnv("TNMS_SERVER_HOME") + "/tnms-run/background/room/";
    File dir = new File(serverPath);
    if (!dir.exists()) {
      dir.mkdirs();
    }
    return serverPath;
  }

  public void deleteFile(BoActionContext actionContext, UploadFile uploadFile) {
    String serverPath = checkSaveDir();

    File file = new File(serverPath + uploadFile.getFileName());

    if (file.exists())
      file.delete();
  }

  public Boolean isSynFile(BoActionContext actionContext, String fileName) throws UserException
  {
    if (fileName != null) {
      int beginIndex = fileName.lastIndexOf("_");
      int endIndex = fileName.lastIndexOf(".");
      if ((beginIndex > 0) && (endIndex > 0)) {
        String modifyTimeStr = fileName.substring(beginIndex + 1, endIndex);
        Long moidfyTime = Long.valueOf(modifyTimeStr);

        String serverPath = null;

        if (fileName.indexOf("TransNMS-Topo-Alarm") >= 0) {
          serverPath = SystemEnv.getPathEnv("TNMS_SERVER_HOME") + "/tnms-run/manual/TransNMS-Topo-Alarm.chm";
        } else if (fileName.indexOf("TransNMS-DuctManager") >= 0) {
          serverPath = SystemEnv.getPathEnv("TNMS_SERVER_HOME") + "/tnms-run/manual/TransNMS-DuctManager.chm";
        } else {
          LogHome.getLog().info("获取帮助文件失败,文件名:" + fileName);
          return Boolean.TRUE;
        }

        File serverFile = new File(serverPath);
        if ((serverFile != null) && (serverFile.exists())) {
          return Boolean.valueOf(serverFile.lastModified() == moidfyTime.longValue());
        }
      }
    }
    return Boolean.valueOf(false);
  }

  public UploadFile getZipFile(BoActionContext actionContext, UploadFile uploadFile) throws UserException {
    String serverPath = null;
    try {
      if (uploadFile.getFileName().indexOf("TransNMS-Topo-Alarm") >= 0) {
        serverPath = SystemEnv.getPathEnv("TNMS_SERVER_HOME") + "/tnms-run/manual/TransNMS-Topo-Alarm.chm";
      }
      else if (uploadFile.getFileName().indexOf("TransNMS-DuctManager") >= 0) {
        serverPath = SystemEnv.getPathEnv("TNMS_SERVER_HOME") + "/tnms-run/manual/TransNMS-DuctManager.chm";
      }
      else {
        LogHome.getLog().info("获取帮助文件失败,文件名:" + uploadFile.getFileName());
      }

      File serverFile = new File(serverPath);
      if ((serverFile != null) && (serverFile.exists())) {
        UploadFile retFile = new UploadFile(serverFile);
        retFile.zipDbBlob();
        return retFile;
      }
      return null;
    }
    catch (Exception e) {
      LogHome.getLog().error("获取服务器上文件失败", e);
    }throw new UserException("获取服务器上文件失败");
  }
}