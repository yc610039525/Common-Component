package com.boco.transnms.server.bo.upload;

import com.boco.common.util.db.DbBlob;
import com.boco.common.util.debug.LogHome;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import org.apache.commons.logging.Log;

public class UploadFile
  implements Serializable
{
  private byte[] fileByte;
  private String fileName;
  private String filePath;
  private long modifyDate;
  private DbBlob dbBlob;

  public UploadFile()
  {
  }

  public void zipDbBlob()
  {
    this.dbBlob = new DbBlob();
    this.dbBlob.setBlobBytes(this.fileByte);
    this.dbBlob.zipBytes();
  }

  public DbBlob upZipDbBlob() {
    if ((this.dbBlob != null) && (this.dbBlob.isZipBytes())) {
      this.dbBlob.unzipBytes();
    }
    return this.dbBlob;
  }

  public UploadFile(File file) {
    if (file != null) {
      this.fileName = file.getName();
      this.filePath = file.getPath();
      FileInputStream fileStream = null;
      try {
        this.modifyDate = file.lastModified();
        if (file.exists()) {
          this.fileByte = new byte[(int)file.length()];
          fileStream = new FileInputStream(file);
          int start = 0;
          int str;
          while ((str = fileStream.read()) != -1) {
            this.fileByte[start] = ((byte)str);
            start++;
          }
        }
      } catch (FileNotFoundException e) {
        LogHome.getLog().error("文件没有找到" + file.getPath(), e);
      } catch (IOException e) {
        LogHome.getLog().error("文件IO异常" + file.getPath(), e);
      } finally {
        try {
          if (fileStream != null)
            fileStream.close();
        } catch (IOException e) {
          LogHome.getLog().error("文件IO关闭异常" + file.getPath(), e);
        }
      }
    }
  }

  public String getFilePath()
  {
    return this.filePath;
  }

  public void setFilePath(String filePath) {
    this.filePath = filePath;
  }

  public String getFileName() {
    return this.fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public byte[] getFileByte() {
    return this.fileByte;
  }

  public void setFileByte(byte[] fileByte) {
    this.fileByte = fileByte;
  }

  public long getModifyDate() {
    return this.modifyDate;
  }

  public void setModifyDate(long modifyDate) {
    this.modifyDate = modifyDate;
  }
}