package com.boco.transnms.server.bo.alarm;

import com.boco.common.util.debug.LogHome;
import com.boco.transnms.common.dto.MqSwitchLog;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.common.cfg.TnmsServerName;
import com.boco.transnms.server.dao.base.DaoHomeFactory;
import com.boco.transnms.server.dao.common.CommonDAO;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.commons.logging.Log;

public abstract class MQSwitchAlarmHandler extends Thread
{
  public void run()
  {
    String serverName = TnmsServerName.getLocalServerNameStr();
    String sql = "SERVER_FULL_NAME='" + serverName + "'" + " and " + "STATE" + "=1";
    while (true)
    {
      try {
        DataObjectList dbos = getDAO().getObjectsBySql(sql, new MqSwitchLog(), 0);
        Timestamp switchTime = new Timestamp(System.currentTimeMillis());
        if ((dbos != null) && (dbos.size() > 0)) {
          Iterator i$ = dbos.iterator(); if (i$.hasNext()) { GenericDO dbo = (GenericDO)i$.next();
            MqSwitchLog switchLog = (MqSwitchLog)dbo;
            if (switchLog.getSwitchTime().before(switchTime)) {
              switchTime = switchLog.getSwitchTime();
            }
            continue; }
          doSwitch(switchTime);
        }
        Map updateAttrs = new HashMap();
        updateAttrs.put("STATE", Long.valueOf(2L));
        getDAO().updateObjects(new BoActionContext(), dbos, updateAttrs);
      } catch (Exception ex) {
        LogHome.getLog().error("", ex);
      }
      try {
        sleep(300000L);
      } catch (Exception ex) {
      }
    }
  }

  public abstract void doSwitch(Timestamp paramTimestamp);

  private CommonDAO getDAO() {
    return (CommonDAO)DaoHomeFactory.getInstance().getDAO("CommonDAO");
  }
}