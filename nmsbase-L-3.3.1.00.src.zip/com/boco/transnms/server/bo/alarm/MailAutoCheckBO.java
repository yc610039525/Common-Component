package com.boco.transnms.server.bo.alarm;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.lang.TimeFormatHelper;
import com.boco.transnms.common.dto.Mailinfo;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.server.bo.base.StateBO;
import com.boco.transnms.server.bo.ibo.alarm.IMailInfoBO;
import com.boco.transnms.server.bo.scheduler.GenericScheduleTaskBO;
import com.boco.transnms.server.bo.scheduler.SchedulerBO;
import java.util.Calendar;
import java.util.Date;
import javax.management.Notification;
import org.apache.commons.logging.Log;

@StateBO(serverName="COMMON")
public class MailAutoCheckBO extends GenericScheduleTaskBO
{
  private boolean inited = false;

  public MailAutoCheckBO() {
    super("MailAutoCheckBO");
  }

  public void initBO()
  {
    if (!this.inited)
    {
      BoActionContext actionContext = new BoActionContext();
      Calendar currCalendar = Calendar.getInstance();
      currCalendar.setTime(new Date());

      setUnit("min");
      setStartTime(TimeFormatHelper.getFormatDate(currCalendar.getTime(), "yyyy-MM-dd HH:mm:ss"));
      LogHome.getLog().info("Email Check StartTime: " + TimeFormatHelper.getFormatDate(currCalendar.getTime(), "yyyy-MM-dd HH:mm:ss"));
      addScheduleTask(this);
      this.inited = true;
    }
  }

  protected void doScheduleTask(Notification notification, Object handback)
    throws Exception
  {
    BoActionContext actionContext = new BoActionContext();
    DboCollection mailinfoCollection = getMailInfoBO().getMailInfoByState();
    for (int i = 0; i < mailinfoCollection.size(); i++) {
      Mailinfo mailinfo = (Mailinfo)mailinfoCollection.getAttrField("MAILINFO", i);
      if ((mailinfo.getMsgstate() == 2L) || (mailinfo.getMsgstate() == 1L)) {
        getMailInfoBO().addSendMailInfo(actionContext, mailinfo.getObjectNum() + "");
      }
    }

    Calendar currCalendar = Calendar.getInstance();
    currCalendar.setTime(new Date());

    setUnit("min");
    setStartTime(TimeFormatHelper.getFormatDate(currCalendar.getTime(), "yyyy-MM-dd HH:mm:ss"));
    LogHome.getLog().info("Email Check StartTime: " + TimeFormatHelper.getFormatDate(currCalendar.getTime(), "yyyy-MM-dd HH:mm:ss"));
    addScheduleTask(this);
  }

  public void handleNotification(Notification notification, Object handback)
  {
    LogHome.getLog().info("定时服务通知[message=" + notification.getMessage() + ", timestamp=" + new Date(notification.getTimeStamp()) + ", source=" + notification.getSource() + ", userdata=" + notification.getUserData() + "]");
    try
    {
      doScheduleTask(notification, handback);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    } finally {
      initBO();
    }
  }

  public void addScheduleTask(MailAutoCheckBO autoCheckBO) {
    getSchedulerBO().addScheduleTask(autoCheckBO);
  }

  private IMailInfoBO getMailInfoBO() {
    return (IMailInfoBO)super.getBO("IMailInfoBO");
  }
}