package com.boco.transnms.server.bo.alarm;

import com.boco.common.util.db.DbConnManager;
import com.boco.common.util.db.DbContext;
import com.boco.common.util.db.SqlHelper;
import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.common.util.lang.TimeFormatHelper;
import com.boco.transnms.common.bussiness.helper.EmailAuthenticatorHelper;
import com.boco.transnms.common.dto.MailServerCfg;
import com.boco.transnms.common.dto.Mailinfo;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.workflow.EmailModel;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.ibo.alarm.IMailInfoBO;
import com.boco.transnms.server.dao.alarm.MailInfoDAO;
import java.io.PrintStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="COMMON", initByAllServer=false)
public class MailInfoBO extends AbstractBO
  implements IMailInfoBO
{
  public MailInfoBO()
  {
    super("IMailInfoBO");
  }

  public void addMailInfo(BoActionContext actionContext, Mailinfo mailInfo)
    throws UserException
  {
    try
    {
      getMailInfoDAO().addMailInfo(actionContext, mailInfo);
    } catch (Exception ex) {
      LogHome.getLog().info("DAO 访问异常", ex);
    }
  }

  public void deleteMailInfo(BoActionContext actionContext, Mailinfo mailInfo)
    throws UserException
  {
    try
    {
      getMailInfoDAO().deleteObject(actionContext, mailInfo);
    } catch (Exception ex) {
      LogHome.getLog().info("DAO 访问异常", ex);
    }
  }

  public void addResendMailInfo(BoActionContext actionContext, String objectids) throws UserException {
    try {
      Mailinfo mailInfo = getMailInfoDAO().getMailinfo(actionContext, Long.valueOf(Long.parseLong(objectids)));
      mailInfo.setMsgstate(1L);
      getMailInfoDAO().updateObject(actionContext, mailInfo);
    } catch (Exception ex) {
      LogHome.getLog().info("DAO 访问异常", ex);
    }
  }

  public void addSendMailInfo(BoActionContext actionContext, String objectids) throws UserException {
    List succeed = new ArrayList();
    List fault = new ArrayList();
    try {
      String[] objectIds = objectids.split(",");
      MailServerCfg[] cfg = getAllMailServerCfgs(actionContext);
      if (cfg == null) {
        LogHome.getLog().info("未配置邮件服务器：");
        return;
      }
      for (int i = 0; i < objectIds.length; i++) {
        Mailinfo mailInfo = getMailInfoDAO().getMailinfo(actionContext, Long.valueOf(Long.parseLong(objectIds[i])));

        EmailModel email = new EmailModel();
        Address[] to = { new InternetAddress(mailInfo.getEmailAddr()) };

        email.setSubject(mailInfo.getMsg());
        email.setContent(mailInfo.getMsg());

        email.setPassword(cfg[0].getUserPassword());
        email.setServerIP(cfg[0].getServerAddr());
        email.setServerPort(String.valueOf(cfg[0].getServerPort()));
        email.setFromUserAddress(new InternetAddress(cfg[0].getUserName() + '@' + cfg[0].getServerAddr()));
        email.setToUserAddress(to);
        int isSucceed = sendEmail(email);
        String resultMsg = "";
        if (isSucceed == 2) {
          resultMsg = "给用户" + mailInfo.getEmailUser() + "发送邮件失败！\n" + "可能是由于：未设置邮件服务器信息。";
          fault.add(resultMsg);
        } else if (isSucceed == 3) {
          resultMsg = "给用户" + mailInfo.getEmailUser() + "发送邮件失败！\n" + "可能是由于：发件箱为空。";
          fault.add(resultMsg);
        } else if (isSucceed == 4) {
          resultMsg = "给用户" + mailInfo.getEmailUser() + "发送邮件失败！\n" + "可能是由于：接收邮箱为空。";
          fault.add(resultMsg);
        } else if (isSucceed == 5) {
          resultMsg = "给用户" + mailInfo.getEmailUser() + "发送邮件失败！\n" + "可能是由于：接收邮箱不完整。";
          fault.add(resultMsg);
        } else if (isSucceed == 6) {
          resultMsg = "给用户" + mailInfo.getEmailUser() + "发送邮件失败！\n" + "可能是由于：发件箱与邮件服务器设置不统一。";
          fault.add(resultMsg);
        } else if (isSucceed == 0) {
          resultMsg = "给用户" + mailInfo.getEmailUser() + "发送邮件成功！";
          succeed.add(resultMsg);
        }
        if (isSucceed == 0) {
          mailInfo.setMsgstate(3L);
        }
        else if (mailInfo.getSendtimes() > 20L) {
          mailInfo.setMsgstate(4L);
        } else {
          mailInfo.setMsgstate(2L);
          mailInfo.setSendtimes(mailInfo.getSendtimes() + 1L);
        }

        String toDay = TimeFormatHelper.getFormatDate(new Date(), "yyyy-MM-dd HH:mm:ss");
        Timestamp toDayTime = TimeFormatHelper.getFormatTimestamp(toDay);
        mailInfo.setLasttimes(toDayTime);
        getMailInfoDAO().updateObject(actionContext, mailInfo);
      }
    } catch (Exception ex) {
      LogHome.getLog().info("DAO 访问异常", ex);
    }
  }

  public void deleteMailInfo(BoActionContext actionContext, DataObjectList mailList)
    throws UserException
  {
    try
    {
      getMailInfoDAO().deleteObjects(actionContext, mailList);
    } catch (Exception ex) {
      LogHome.getLog().info("DAO 访问异常", ex);
    }
  }

  public Mailinfo getMailInfoByCuid(BoActionContext actionContext, String cuid)
    throws UserException
  {
    Mailinfo mailInfo = null;
    try {
      mailInfo = (Mailinfo)getMailInfoDAO().getObjByCuid(new Mailinfo(cuid));
    } catch (Exception ex) {
      LogHome.getLog().info("DAO 访问异常", ex);
    }
    return mailInfo;
  }

  public void modifyMailInfo(BoActionContext actionContext, Mailinfo mailInfo)
    throws UserException
  {
    try
    {
      getMailInfoDAO().modifyMailInfo(actionContext, mailInfo);
    } catch (Exception ex) {
      LogHome.getLog().info("DAO 访问异常", ex);
    }
  }

  private MailInfoDAO getMailInfoDAO() {
    return (MailInfoDAO)super.getDAO("MailInfoDAO");
  }

  public DboCollection getMailInfoByCondition(BoQueryContext actionContext, String emailAddr, String msgtype, String msgstate, String starttime, String endtime)
  {
    try {
      if (!starttime.equals("")) {
        starttime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(starttime));
      }
      if (!endtime.equals("")) {
        endtime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(endtime));
      }
      return getMailInfoDAO().queryMailinfo(actionContext, emailAddr, msgtype, msgstate, starttime, endtime);
    } catch (Exception ex) {
      LogHome.getLog().error("查询失败" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public DboCollection getMailInfoByState() {
    try {
      return getMailInfoDAO().queryMailinfoByState();
    } catch (Exception ex) {
      LogHome.getLog().error("查询失败" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public DboCollection getMailInfoExcel(BoQueryContext actionContext, String emailAddr, String msgtype, String msgstate, String starttime, String endtime) {
    try {
      if (!starttime.equals("")) {
        starttime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(starttime));
      }
      if (!endtime.equals("")) {
        endtime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(endtime));
      }
      return getMailInfoDAO().getMailinfoExcel(actionContext, emailAddr, msgtype, msgstate, starttime, endtime);
    } catch (Exception ex) {
      LogHome.getLog().error("查询失败" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public void deleteMailInfo(BoActionContext actionContext, String objectids) throws UserException {
    try {
      String[] objectIds = objectids.split(",");
      for (int i = 0; i < objectIds.length; i++)
        getMailInfoDAO().deleteMailinfo(actionContext, Long.valueOf(objectIds[i]));
    }
    catch (Exception ex) {
      LogHome.getLog().error("删除失败" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public void saveUserEmailCfg(BoActionContext actionContext, MailServerCfg dbo) throws Exception {
    getMailInfoDAO().createObject(actionContext, dbo);
  }

  public void updateUserEmailCfg(BoActionContext actionContext, MailServerCfg dbo) throws Exception {
    getMailInfoDAO().updateObject(actionContext, dbo);
  }

  public MailServerCfg[] getAllMailServerCfgs(BoActionContext actionContext)
    throws Exception
  {
    DataObjectList mailServerCfgs = getMailInfoDAO().getAllObjByClass(new MailServerCfg(), 0);
    MailServerCfg[] result = null;
    if ((mailServerCfgs != null) && (mailServerCfgs.size() > 0)) {
      result = new MailServerCfg[mailServerCfgs.size()];
      result = (MailServerCfg[])mailServerCfgs.toArray(result);
    }
    return result;
  }

  public int sendEmail(EmailModel emailModel)
  {
    int count = 0;

    String username = emailModel.getFromUserAddress().toString();
    int num = username.indexOf("@");
    if (num > 0) {
      username = username.substring(0, num);
    }

    String passwords = emailModel.getPassword();
    String mailService = emailModel.getServerIP();
    String mainBody = emailModel.getContent();
    String annex = emailModel.getAccessories();

    String port = emailModel.getServerPort();
    int portnum = 25;
    if ((port != null) && (!port.trim().equals(""))) {
      portnum = Integer.parseInt(port);
    }

    if ((username == null) || (username.equals(""))) {
      return 2;
    }
    if ((passwords == null) || (passwords.equals(""))) {
      return 2;
    }
    if ((port == null) || (port.equals(""))) {
      return 2;
    }
    if ((mailService == null) || (mailService.equals(""))) {
      return 2;
    }
    if (emailModel.getFromUserAddress().equals("")) {
      return 3;
    }
    Address[] add = emailModel.getToUserAddress();
    if (add.length == 0) {
      return 4;
    }

    Properties props = new Properties();

    props.put("mail.smtp.host", mailService);

    EmailAuthenticatorHelper popAuthenticator = new EmailAuthenticatorHelper(username, passwords);
    Session sendMailSession = Session.getInstance(props, popAuthenticator);

    MimeMessage newMessage = new MimeMessage(sendMailSession);
    try
    {
      newMessage.setFrom(emailModel.getFromUserAddress());
    } catch (MessagingException ex1) {
      return 3;
    }
    try {
      newMessage.setRecipients(Message.RecipientType.TO, emailModel.getToUserAddress());
    } catch (Exception ex1) {
      return 7;
    }
    try {
      newMessage.setSubject(emailModel.getSubject());
      BodyPart bp = new MimeBodyPart();
      bp.setContent("<meta http-equiv=Content-Type content=text/html; charset=gb2312>" + mainBody, "text/html;charset=GB2312");

      Multipart mp = new MimeMultipart();
      mp.addBodyPart(bp);
      newMessage.setContent(mp);
    } catch (Exception ex1) {
      return 1;
    }

    try
    {
      Transport transport = sendMailSession.getTransport("smtp");
      try {
        props.put("mail.smtp.auth", "true");
        transport.connect((String)props.get("mail.smtp.host"), portnum, username, passwords);
      } catch (MessagingException ex2) {
        System.err.println("邮件发送失败！" + ex2);
        return 2;
      }
      try {
        if (!transport.isConnected()) {
          return 2;
        }
        Transport.send(newMessage);
      } catch (MessagingException ex3) {
        System.err.println("邮件发送失败！" + ex3);
        return 1;
      }
    } catch (NoSuchProviderException ex) {
      System.err.println("邮件发送失败！" + ex);
      return 1;
    }
    return count;
  }
}