package com.boco.transnms.server.bo.area;

import com.boco.common.util.db.TransactionFactory;
import com.boco.common.util.db.UserTransaction;
import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.Floor;
import com.boco.transnms.common.dto.Site;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.ibo.cm.IFloorBO;
import com.boco.transnms.server.bo.ibo.misc.ISecurityBO;
import com.boco.transnms.server.dao.area.FloorDAO;
import com.boco.transnms.server.dao.area.RoomDAO;
import com.boco.transnms.server.dao.area.SiteDAO;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="COMMON")
public class FloorBO extends AbstractBO
  implements IFloorBO
{
  public DataObjectList getAllFloor(BoActionContext actionContext)
    throws UserException
  {
    try
    {
      return getFloorDAO().getAllFloor();
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex);
    }
  }

  public Floor addFloor(BoActionContext actionContext, Floor dbo) throws UserException
  {
    try
    {
      String cuid = getFloorDAO().getCuidByFloor(actionContext, dbo);
      if (!cuid.equals("")) {
        throw new UserException("已经存在重名的楼层");
      }
      return getFloorDAO().addFloor(actionContext, dbo);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex);
    }
  }

  public DataObjectList addBatchFloor(BoActionContext actionContext, String siteCuid, Integer beginNumber, Integer endNumber) throws UserException {
    DataObjectList floors = new DataObjectList();
    try {
      for (int i = beginNumber.intValue(); i <= endNumber.intValue(); i++) {
        if (i != 0) {
          Floor dbo = new Floor();
          dbo.setRelatedSpaceCuid(siteCuid);
          dbo.setFloorNum(i);

          String cuid = getFloorDAO().getCuidByFloor(actionContext, dbo);
          if (cuid.equals("")) {
            Floor newfloor = getFloorDAO().addFloor(actionContext, dbo);
            floors.add(newfloor);
          } else {
            Floor newfloor = getFloorDAO().getFloorByCuid(cuid);
            floors.add(newfloor);
          }
        }
      }
      return floors;
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex);
    }
  }

  public Floor getFloor(BoActionContext actionContext, Long objectId) throws UserException {
    try {
      return getFloorDAO().getFloor(actionContext, objectId);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex);
    }
  }

  public Floor getFloorByCuid(BoActionContext actionContext, String cuid) throws UserException {
    try {
      return getFloorDAO().getFloorByCuid(cuid);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex);
    }
  }

  public void deleteFloor(BoActionContext actionContext, Long objectId) throws UserException {
    try {
      Floor floor = getFloor(actionContext, objectId);
      DataObjectList rooms = getChildRoom(actionContext, floor.getCuid());
      if ((rooms != null) && (rooms.size() > 0)) {
        throw new UserException("当前楼层下已经有机房，不能删除");
      }
      getFloorDAO().delFloor(actionContext, objectId);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void deleteBatchFloor(BoActionContext actionContext, String objectIds) throws UserException {
    String[] objectId = objectIds.split(",");
    UserTransaction trx = TransactionFactory.getInstance().createTransaction();
    try {
      trx.begin();
      for (int i = 0; i < objectId.length; i++) {
        deleteFloor(actionContext, Long.valueOf(objectId[i]));
      }
      trx.commit();
    } catch (Exception ex) {
      trx.rollback();
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void modifyFloor(BoActionContext actionContext, Floor dbo) throws UserException
  {
    try {
      String cuid = getFloorDAO().getCuidByFloor(actionContext, dbo);
      if ((!cuid.equals("")) && (!cuid.equals(dbo.getCuid()))) {
        throw new UserException("已经存在相同编号的楼层");
      }
      getFloorDAO().modifyFloor(actionContext, dbo);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex);
    }
  }

  public DataObjectList getFloorBySiteCuid(BoActionContext actionContext, String relatedSpaceCuid) throws UserException {
    try {
      return getFloorDAO().getFloorBySiteCuid(relatedSpaceCuid);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex);
    }
  }

  public DataObjectList getChildRoom(BoActionContext actionContext, String floorCuid) throws UserException {
    try {
      return getRoomDAO().getRoomByFloorCuid(actionContext, floorCuid);
    } catch (Exception ex) {
      LogHome.getLog().error("根据楼层取机房失败", ex);
      throw new UserException(ex);
    }
  }

  public DboCollection getFloorBySiteCuidByPage(BoQueryContext queryContext, String relatedSpaceCuid, String sortFieldId) throws UserException {
    try {
      return getFloorDAO().getFloorBySiteCuidByPage(queryContext, relatedSpaceCuid, sortFieldId);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex);
    }
  }

  public int getRelatedDeleteObjCount(String className, GenericDO deleteObj) throws UserException {
    int size = 0;
    try {
      if ((deleteObj.getClassName() != null) && (deleteObj.getClassName().equals("SITE"))) {
        String sql = "select count(*) from FLOOR where RELATED_SPACE_CUID = '" + deleteObj.getCuid() + "'";
        size = getFloorDAO().getFloorCountBySql(new BoActionContext(), sql);
      }
    } catch (Exception ex) {
      LogHome.getLog().info("查询楼层个数出错" + ex.getMessage());
      throw new UserException("查询楼层个数出错" + ex.getMessage());
    }
    return size;
  }

  public DataObjectList getRelatedDeleteObjects(String className, GenericDO deleteObj) throws UserException
  {
    return null;
  }

  public void deleteReletedOfObject(String className, GenericDO deleteObj)
    throws UserException
  {
    try
    {
      BoActionContext actionContext = new BoActionContext();
      if ((deleteObj.getClassName() != null) && (deleteObj.getClassName().equals("SITE"))) {
        DataObjectList floorList = getFloorBySiteCuid(actionContext, deleteObj.getCuid());
        if ((floorList != null) && (floorList.size() > 0))
          for (int i = 0; i < floorList.size(); i++) {
            Floor floor = (Floor)floorList.get(i);
            deleteFloor(actionContext, Long.valueOf(floor.getObjectNum()));
          }
      }
    }
    catch (Exception ex) {
      LogHome.getLog().error("级联删除楼层失败", ex);
      throw new UserException(ex);
    }
  }

  public boolean isHaveRelatedObj(String className, GenericDO deleteObj) throws UserException {
    try {
      BoActionContext actionContext = new BoActionContext();
      if (deleteObj.getClassName().equals("SITE")) {
        Site site = (Site)deleteObj;
        String cuid = site.getCuid();
        DataObjectList floors = getFloorDAO().getFloorBySiteCuid(cuid);
        if ((floors != null) && (floors.size() > 0)) {
          return true;
        }
        return false;
      }
      return false;
    } catch (Exception ex) {
      throw new UserException(ex);
    }
  }

  public FloorDAO getFloorDAO() {
    return (FloorDAO)super.getDAO("FloorDAO");
  }

  public RoomDAO getRoomDAO() {
    return (RoomDAO)super.getDAO("RoomDAO");
  }

  public SiteDAO getSiteDAO() {
    return (SiteDAO)super.getDAO("SiteDAO");
  }

  public ISecurityBO getSecurityBO() {
    return (ISecurityBO)super.getBO("ISecurityBO");
  }
}