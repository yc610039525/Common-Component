package com.boco.transnms.server.bo.area;

import com.boco.common.util.db.TransactionFactory;
import com.boco.common.util.db.UserTransaction;
import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.core.utils.encoding.GetCh2Spell;
import com.boco.transnms.common.dto.District;
import com.boco.transnms.common.dto.JumpFiber;
import com.boco.transnms.common.dto.JumpPair;
import com.boco.transnms.common.dto.Room;
import com.boco.transnms.common.dto.Site;
import com.boco.transnms.common.dto.TopoLink;
import com.boco.transnms.common.dto.TransElement;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.BoHomeFactory;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.dm.DMDataSynHelperX;
import com.boco.transnms.server.bo.ibo.IObjectSecurityBO;
import com.boco.transnms.server.bo.ibo.cm.IObjectOperateLogBO;
import com.boco.transnms.server.bo.ibo.cm.IRoomBO;
import com.boco.transnms.server.bo.ibo.cm.ISiteBO;
import com.boco.transnms.server.bo.ibo.misc.ISecurityBO;
import com.boco.transnms.server.dao.area.RoomDAO;
import com.boco.transnms.server.dao.area.SiteDAO;
import com.boco.transnms.server.dao.base.DaoHelper;
import com.boco.transnms.server.dao.common.CommonDAO;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="COMMON", initByAllServer=true)
public class SiteBO extends AbstractBO
  implements ISiteBO
{
  public DataObjectList getAllSite(BoActionContext actionContext)
    throws UserException
  {
    try
    {
      return getSiteDAO().getAllSite();
    }
    catch (Throwable ex)
    {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getAllSimpleSite(BoActionContext actionContext)
    throws UserException
  {
    try
    {
      DataObjectList dataObjectList = new DataObjectList();
      DataObjectList sites = getSiteDAO().getAllSite();
      if (sites != null) {
        for (int i = 0; i < sites.size(); i++) {
          Site temp = (Site)sites.get(i);
          Site site = new Site();
          site.clearDefaultValue();
          site.setObjectNum(temp.getObjectNum());
          site.setCuid(temp.getCuid());
          site.setLabelCn(temp.getLabelCn());
          site.setRelatedSpaceCuid(temp.getRelatedSpaceCuid());
          site.setLatitude(temp.getLatitude());
          site.setLongitude(temp.getLongitude());
          site.setSiteType(temp.getSiteType());
          site.setServiceLevel(temp.getServiceLevel());
          site.setOlevel(temp.getOlevel());
          site.setObjectLoadType(1);
          dataObjectList.add(site);
        }
      }
      return dataObjectList;
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public Site getSite(BoActionContext actionContext, Long objectId) throws UserException {
    try {
      return getSiteDAO().getSite(actionContext, objectId);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public Site getSiteByCuid(BoActionContext actionContext, String cuid) throws UserException
  {
    try {
      return getSiteDAO().getSiteByCuid(actionContext, cuid);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getSiteByDistrictCuids(BoActionContext actionContext, String[] cuids, String siteName) throws UserException {
    try {
      return getSiteDAO().getSiteByDistrictCuids(actionContext, cuids, siteName);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public Site addSite(BoActionContext actionContext, Site dbo) throws UserException {
    try {
      String cuid = getSiteDAO().getCuidByLabelcn(actionContext, dbo.getLabelCn());
      if (!cuid.equals("")) {
        throw new UserException("已经存在同名的站点");
      }
      if ((dbo.getSpellabbreviation() == null) || (dbo.getSpellabbreviation().trim().length() == 0)) {
        dbo.setSpellabbreviation(GetCh2Spell.getBeginCharacter(dbo.getLabelCn()));
      }
      dbo.setSpellabbreviation(dbo.getSpellabbreviation());
      Site newdbo = getSiteDAO().addSite(actionContext, dbo);

      boolean flag = DMDataSynHelperX.needSysn();
      if (flag) {
        DMDataSynHelperX.addPoint(dbo);
      }

      BoActionContext boactioncontext = new BoActionContext();
      boactioncontext.setUserId(actionContext.getUserId());
      boactioncontext.setHostIP(actionContext.getHostIP());
      IObjectOperateLogBO ibo = (IObjectOperateLogBO)BoHomeFactory.getInstance().getBO("IObjectOperateLogBO");
      ibo.addObjOperateLog(boactioncontext, 1L, 2L, dbo, dbo);

      return newdbo;
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void deleteSite(BoActionContext actionContext, Long objectId) throws UserException { UserTransaction trx = TransactionFactory.getInstance().createTransaction();
    Site site;
    try { trx.begin();
      site = getSite(actionContext, objectId);
      getSiteDAO().delSite(actionContext, objectId);

      BoActionContext boactioncontext = new BoActionContext();
      boactioncontext.setUserId(actionContext.getUserId());
      boactioncontext.setHostIP(actionContext.getHostIP());
      IObjectOperateLogBO ibo = (IObjectOperateLogBO)BoHomeFactory.getInstance().getBO("IObjectOperateLogBO");
      ibo.addObjOperateLog(boactioncontext, 3L, 2L, site, site);

      trx.commit();
    } catch (Throwable ex) {
      trx.rollback();
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
    try
    {
      boolean flag = DMDataSynHelperX.needSysn();
      if (flag)
        DMDataSynHelperX.deletePoint(site);
    }
    catch (Exception e) {
      LogHome.getLog().error("同步删除站点出错", e);
    }
  }

  public void modifySite(BoActionContext actionContext, Site dbo)
    throws UserException
  {
    try
    {
      Site site_past = getSiteByCuid(actionContext, dbo.getCuid());

      getSiteDAO().modifySite(actionContext, dbo);
      boolean flag = DMDataSynHelperX.needSysn();
      if (flag) {
        boolean isArc = DMDataSynHelperX.getIsModifyArcgis(site_past, dbo, 0);
        if (isArc)
          DMDataSynHelperX.modifyPoint(dbo);
      }
    }
    catch (Throwable ex) {
      LogHome.getLog().error("更新站点信息失败！", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void modifySiteLocation(BoActionContext actionContext, Site dbo) throws UserException
  {
    try {
      Site site = getSiteDAO().getSiteByCuid(actionContext, dbo.getCuid());
      site.setLongitude(dbo.getLongitude());
      site.setLatitude(dbo.getLatitude());
      getSiteDAO().modifySite(actionContext, site);
      boolean flag = DMDataSynHelperX.needSysn();
      if (flag)
        DMDataSynHelperX.modifyPoint(site);
    }
    catch (Exception ex) {
      LogHome.getLog().error("更新站点显示经纬度失败！", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getSiteByQuery(BoActionContext actionContext, String relatedSpaceCuid, String labelCn, String contactAddress, Boolean includeChild, Boolean province, Boolean city, Boolean county, String siteTypes)
    throws UserException
  {
    try
    {
      return getSiteDAO().querySite(relatedSpaceCuid, labelCn, contactAddress, includeChild, province, city, county, siteTypes);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getSiteByPageCondition(BoQueryContext queryContext, String sql) throws UserException {
    try {
      return getSiteDAO().querySiteByPageCondition(queryContext, sql);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getAccessByPageCondition(BoQueryContext queryContext, String sql) throws UserException {
    try {
      return getSiteDAO().getAccessByPageCondition(queryContext, sql);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList querySiteLabelAndCuidByPageCondition(BoQueryContext queryContext, String sql) throws UserException
  {
    try {
      return getSiteDAO().querySiteLabelAndCuidByPageCondition(queryContext, sql);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getSiteByPage(BoQueryContext queryContext, String relatedSpaceCuid, String labelCn, String contactAddress, Boolean includeChild, Long serviceLevel, String siteTypes, String querySitecoding, Long oLevel, Long ownerShip, String orderString)
    throws UserException
  {
    try
    {
      BoActionContext boActionContext = new BoActionContext();
      boActionContext.copyFromBean(queryContext);
      String sql = getSecurityObjectBO().getQueryFilterSql(boActionContext, "SITE", "", "RELATED_SPACE_CUID", relatedSpaceCuid, includeChild.booleanValue(), "SERVICE_LEVEL");

      return getSiteDAO().querySiteByPage(queryContext, relatedSpaceCuid, labelCn, contactAddress, includeChild, serviceLevel, siteTypes, querySitecoding, oLevel, ownerShip, orderString, sql);
    }
    catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getChildRoom(BoActionContext actionContext, String siteCuids)
    throws UserException
  {
    try
    {
      return getSiteDAO().getChildRoom(siteCuids);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getChildRoomByRoomName(BoActionContext actionContext, String siteCuids, String roomName) throws UserException {
    try {
      return getSiteDAO().getChildRoomByRoomName(siteCuids, roomName);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getChildRoomBycuidorRoomNamePage(BoQueryContext queryContext, String siteCuids, String roomName, String orderString) throws UserException
  {
    try {
      BoActionContext boActionContext = new BoActionContext();

      boActionContext.setUserId(queryContext.getUserId());
      DboCollection dbc = new DboCollection();
      Site site = getSiteDAO().getSiteByCuid(boActionContext, siteCuids);
      if (site != null) {
        String sql = getSecurityObjectBO().getQueryFilterSql(boActionContext, "ROOM", "", "", site.getRelatedSpaceCuid(), false, "SERVICE_LEVEL");

        return getSiteDAO().getChildRoomBycuidorRoomName(queryContext, siteCuids, roomName, orderString, sql);
      }
      return dbc;
    }
    catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  protected CommonDAO getCommonDAO() {
    return (CommonDAO)super.getDAO("CommonDAO");
  }

  public Site getSiteOfRoom(BoActionContext actionContext, Room room)
    throws UserException
  {
    try
    {
      return getSiteDAO().getSiteOfRoom(actionContext, room);
    } catch (Exception ex) {
      LogHome.getLog().error("根据机房获取站点失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getSiteBySubNetWorks(BoActionContext actionContext, DataObjectList subnetworkList)
    throws UserException
  {
    DataObjectList doList = new DataObjectList();
    String sql = "select  A.* from TRANS_ELEMENT T ,SN_NE S,SITE A where  A.CUID = T.RELATED_SITE_CUID and T.CUID=S.RELATED_NE_CUID and S.SUBNET_TYPE =1 ";

    String cuids = null;
    if (subnetworkList == null) {
      return doList;
    }
    for (int i = 0; i < subnetworkList.size(); i++) {
      String cuid = ((GenericDO)subnetworkList.get(i)).getCuid();
      if (cuids == null)
        cuids = "S.RELATED_SUBNET_CUID ='" + cuid + "'";
      else {
        cuids = cuids + " or " + "S.RELATED_SUBNET_CUID =" + "'" + cuid + "'";
      }
    }
    if (cuids == null) {
      return doList;
    }
    cuids = " ( " + cuids + " ) ";
    sql = sql + " and " + cuids;
    try {
      DboCollection siteList = getSiteDAO().selectDBOs(sql, new GenericDO[] { new Site() });
      Map sitemap = new HashMap();
      if (siteList != null) {
        for (int i = 0; i < siteList.size(); i++) {
          Site site = (Site)siteList.getQueryDbo(i, "SITE");
          sitemap.put(site.getCuid(), site);
        }
        Iterator it = sitemap.values().iterator();
        while (it.hasNext()) {
          Object o = it.next();
          if ((o instanceof GenericDO))
            doList.add((GenericDO)o);
        }
      }
    }
    catch (Exception ex) {
      LogHome.getLog().error("根据子网cuid获取站点cuid失败", ex);
    }
    return doList;
  }

  public DataObjectList getSiteByTransSystems(BoActionContext actionContext, DataObjectList subnetworkList)
    throws UserException
  {
    DataObjectList doList = new DataObjectList();
    try {
      DataObjectList topolinkList = getSiteDAO().getAllObjByClass(new TopoLink(), 0);
      Map map = new HashMap();
      for (int i = 0; i < topolinkList.size(); i++) {
        TopoLink topolink = (TopoLink)topolinkList.get(i);
        String systemcuid = topolink.getRelatedSystemCuid();
        for (int j = 0; j < subnetworkList.size(); j++) {
          String cuid = ((GenericDO)subnetworkList.get(j)).getCuid();
          if ((systemcuid != null) && (systemcuid.equals(cuid))) {
            String destsitecuid = topolink.getDestSiteCuid();
            String origsitecuid = topolink.getOrigSiteCuid();
            if (destsitecuid != null) {
              map.put(destsitecuid, destsitecuid);
            }
            if (origsitecuid != null) {
              map.put(origsitecuid, origsitecuid);
            }
          }
        }
      }
      Iterator it = map.values().iterator();
      List sitecuidlist = new ArrayList();
      while (it.hasNext()) {
        Object o = it.next();
        if ((o instanceof String)) {
          sitecuidlist.add((String)o);
        }
      }
      doList = getSiteDAO().getObjsByCuids(sitecuidlist, new Site());
    } catch (Exception ex1) {
      LogHome.getLog().error("根据子网cuid获取站点cuid失败", ex1);
    }
    return doList;
  }

  public String getSiteCuidByRoomCuid(BoActionContext actionContext, String roomCuid) throws UserException {
    try {
      String cuid = "";
      Room room = getRoomBO().getRoomByCuid(actionContext, roomCuid);
      Site site;
      if (room != null) { site = getSiteOfRoom(actionContext, room);
        if (site == null); }
      return site.getCuid();
    }
    catch (Exception ex)
    {
      LogHome.getLog().error("根据机房cuid获取站点cuid失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getSiteByName(BoActionContext actionContext, String name) throws UserException {
    try {
      return getSiteDAO().getSiteByName(actionContext, name);
    } catch (Exception ex) {
      LogHome.getLog().error("根据名称获取站点失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  private IRoomBO getRoomBO() {
    return (IRoomBO)super.getBO("IRoomBO");
  }

  public SiteDAO getSiteDAO() {
    return (SiteDAO)super.getDAO("SiteDAO");
  }

  public RoomDAO getRoomDAO() {
    return (RoomDAO)super.getDAO("RoomDAO");
  }

  public IObjectSecurityBO getSecurityObjectBO()
  {
    return (IObjectSecurityBO)super.getBO("IObjectSecurityBO");
  }

  public ISecurityBO getSecurityBO() {
    return (ISecurityBO)super.getBO("ISecurityBO");
  }

  public DboCollection getSiteByDistrictCuidAndSiteName(BoQueryContext boQueryContext, String districtCuid, String siteName, Boolean includeChildDistrict)
    throws UserException
  {
    try
    {
      BoActionContext boActionContext = new BoActionContext();
      boActionContext.copyFromBean(boQueryContext);
      String sql = getSecurityObjectBO().getQueryFilterSql(boActionContext, "SITE", "", "RELATED_SPACE_CUID", districtCuid, includeChildDistrict.booleanValue(), "SERVICE_LEVEL");

      return getSiteDAO().getSiteByDistrictCuidAndSiteName(boQueryContext, districtCuid, siteName, includeChildDistrict, sql);
    } catch (Exception ex) {
      LogHome.getLog().error("根据区域获取站点失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void addSiteCfgType(String siteValue) throws UserException {
    try {
      String[] siteValues = siteValue.split(",");
      for (int i = 1; i <= siteValues.length / 2; i++) {
        String keys = siteValues[(i * 2 - 2)];
        String value = siteValues[(i * 2 - 1)];
        int key = Integer.parseInt(keys);
        getSiteDAO().addSiteCfgType(key, value);
      }
    } catch (Throwable ex) {
      throw new UserException(ex.getMessage());
    }
  }

  public void modifySiteCfgType(String siteValue) throws UserException {
    try {
      String[] siteValues = siteValue.split(",");
      for (int i = 1; i <= siteValues.length / 2; i++) {
        String keys = siteValues[(i * 2 - 2)];
        String value = siteValues[(i * 2 - 1)];
        int key = Integer.parseInt(keys);
        getSiteDAO().modifySiteCfgType(key, value);
      }
    } catch (Throwable ex) {
      throw new UserException(ex.getMessage());
    }
  }

  public void delSiteCfgType(String objectids) throws UserException {
    try {
      String[] objectid = objectids.split(",");
      getSiteDAO().delSiteCfgType(objectid);
    } catch (Throwable ex) {
      throw new UserException(ex.getMessage());
    }
  }

  public void addSwitchCfgType(String siteValue) throws UserException {
    try {
      String[] siteValues = siteValue.split(",");
      for (int i = 1; i <= siteValues.length / 2; i++) {
        String keys = siteValues[(i * 2 - 2)];
        String value = siteValues[(i * 2 - 1)];
        int key = Integer.parseInt(keys);
        getSiteDAO().addSwitchCfgType(key, value);
      }
    } catch (Throwable ex) {
      throw new UserException(ex.getMessage());
    }
  }

  public void modifySwitchCfgType(String siteValue) throws UserException {
    try {
      String[] siteValues = siteValue.split(",");
      for (int i = 1; i <= siteValues.length / 2; i++) {
        String keys = siteValues[(i * 2 - 2)];
        String value = siteValues[(i * 2 - 1)];
        int key = Integer.parseInt(keys);
        getSiteDAO().modifySwitchCfgType(key, value);
      }
    } catch (Throwable ex) {
      throw new UserException(ex.getMessage());
    }
  }

  public void delSwitchCfgType(String objectids) throws UserException {
    try {
      String[] objectid = objectids.split(",");
      getSiteDAO().delSwitchCfgType(objectid);
    } catch (Throwable ex) {
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getSiteCfgType() throws UserException {
    try {
      return getSiteDAO().getSiteCfgType();
    } catch (Throwable ex) {
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getRoomCfgType() throws UserException {
    try {
      return getSiteDAO().getRoomCfgType();
    } catch (Throwable ex) {
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getSwitchCfgType() throws UserException
  {
    try {
      return getSiteDAO().getSwitchCfgType();
    } catch (Throwable ex) {
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getIsRoomType(BoActionContext actionContext, String[] value) throws UserException {
    try {
      return getSiteDAO().getIsRoomType(actionContext, value);
    } catch (Exception ex) {
      LogHome.getLog().error("获取机房类型失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public String getCuidByLabelcn(BoActionContext actionContext, String labelcn) throws UserException {
    try {
      return getSiteDAO().getCuidByLabelcn(actionContext, labelcn);
    } catch (Exception ex) {
      LogHome.getLog().error("获取站点失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public boolean isHaveRelatedObj(String className, GenericDO deleteObj)
    throws UserException
  {
    BoActionContext actionContext = new BoActionContext();
    if (deleteObj.getClassName().equals("DISTRICT")) {
      District district = (District)deleteObj;
      String[] cuids = { district.getCuid() };
      DataObjectList sites = getSiteByDistrictCuids(actionContext, cuids, "");
      if ((sites != null) && (sites.size() > 0)) {
        return true;
      }
      return false;
    }

    return false;
  }

  public int getRelatedDeleteObjCount(String className, GenericDO deleteObj) throws UserException
  {
    return Integer.getInteger("0").intValue();
  }

  public DataObjectList getRelatedDeleteObjects(String className, GenericDO deleteObj) throws UserException {
    return null;
  }

  public void deleteReletedOfObject(String className, GenericDO deleteObj) throws UserException
  {
  }

  public DataObjectList getSiteTypeInfo() throws UserException
  {
    try {
      return getSiteDAO().getSiteTypeInfo();
    } catch (Throwable ex) {
      throw new UserException(ex.getMessage());
    }
  }

  public Map getSitesByCuids(BoActionContext actionContext, String siteCuids)
    throws UserException
  {
    HashMap nodeMap = new HashMap();
    if (siteCuids.trim().length() > 0) {
      String[] cuidarray = siteCuids.split(",");
      String cuid = new String();
      HashMap tempMap = new HashMap();
      for (int i = 0; i < cuidarray.length; i++) {
        cuid = cuidarray[i];
        if (!tempMap.containsKey(cuid)) {
          tempMap.put(cuid, Integer.valueOf(1));
          if (!nodeMap.containsKey(cuid)) {
            String tableName = GenericDO.parseClassNameFromCuid(cuid);
            if ((DaoHelper.isNotEmpty(tableName)) && (DaoHelper.isNotEmpty(cuid))) {
              if (tableName.equals("SITE")) {
                Site site = null;
                try {
                  site = getSiteDAO().getSiteByCuid(actionContext, cuid);
                } catch (Throwable ex) {
                  LogHome.getLog().error("根据站点cuid获取站点失败", ex);
                  throw new UserException(ex.getMessage());
                }
                if (site != null)
                  nodeMap.put(cuid, site);
              }
              else if (tableName.equals("ROOM")) {
                Room room = null;
                Site site = null;
                try {
                  room = getRoomBO().getRoomByCuid(actionContext, cuid);
                  if (room != null)
                    site = getSiteOfRoom(actionContext, room);
                }
                catch (Exception ex) {
                  LogHome.getLog().error("根据机房cuid获取站点失败", ex);
                  throw new UserException(ex.getMessage());
                }
                if (site != null)
                  nodeMap.put(cuid, site);
              }
              else if (tableName.equals("TRANS_ELEMENT")) {
                TransElement transElement = null;
                Site site = null;
                try {
                  transElement = (TransElement)getCommonDAO().getObjByCuid(cuid);
                  if (transElement != null) {
                    String siteCuid = transElement.getRelatedSiteCuid();
                    site = getSiteByCuid(actionContext, siteCuid);
                  }
                } catch (Exception ex) {
                  LogHome.getLog().error("根据传输系统cuid获取站点失败", ex);
                  throw new UserException(ex.getMessage());
                }
                if (site != null) {
                  nodeMap.put(cuid, site);
                }
              }
            }
          }
        }
      }
      tempMap.clear();
    }
    return nodeMap;
  }

  public DataObjectList getSiteBySql(BoActionContext actionContext, String sql) throws UserException
  {
    try
    {
      return getSiteDAO().getObjectsBySql(sql, new Site(), 0);
    } catch (Exception e) {
      throw new UserException("查询站点失败，" + e.getMessage());
    }
  }

  public DataObjectList getSiteBySql(BoActionContext actionContext, String sql, int objGetType) throws UserException {
    try {
      return getSiteDAO().getObjectsBySql(sql, new Site(), objGetType);
    } catch (Exception e) {
      throw new UserException("获取站点失败：" + e.getMessage());
    }
  }

  public DataObjectList getSiteByServicelevel(BoActionContext actionContext, Long serviceLevel)
    throws UserException
  {
    try
    {
      Site site = new Site();
      site.setServiceLevel(serviceLevel.longValue());
      return getSiteDAO().getObjByAttrs(new BoQueryContext(), site);
    } catch (Exception ex) {
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getAllSiteCuidAndRelatedSpaceCuid(BoActionContext actionContext) throws UserException {
    try {
      return getSiteDAO().getAllSiteCuidAndRelatedSpaceCuid();
    }
    catch (Exception e) {
      LogHome.getLog().error("", e);
      throw new UserException(e.getMessage());
    }
  }

  public DataObjectList getAllSiteCuidAndLabelCn(BoActionContext actionContext) throws UserException {
    try {
      return getSiteDAO().getAllSiteCuidAndLabelCn();
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getSitesByCuidList(BoActionContext actionContext, List siteCuidlist) throws UserException {
    DataObjectList siteList = null;
    try {
      return getSiteDAO().getObjsByCuids(siteCuidlist, new Site());
    }
    catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void delPointAnalyseConf(BoActionContext actionContext, String value) throws UserException
  {
    try {
      getSiteDAO().delPointAnalyseConf(actionContext, value);
    } catch (Throwable ex) {
      throw new UserException(ex.getMessage());
    }
  }

  public void modifyJumpFiberAndPair(BoActionContext actionContext, String newName, String ptpCuid) throws UserException
  {
    try {
      String sql = "select * from JUMP_FIBER where ORIG_POINT_CUID = '" + ptpCuid + "' " + " or " + "DEST_POINT_CUID" + " = '" + ptpCuid + "'";

      DboCollection jumpFiberList = getSiteDAO().selectDBOs(sql, new GenericDO[] { new JumpFiber() });
      LogHome.getLog().info("根据端口PtpCuid取到JumpFiber " + jumpFiberList.size() + " 个");
      for (int i = 0; i < jumpFiberList.size(); i++) {
        JumpFiber jumpfiber = (JumpFiber)jumpFiberList.getQueryDbo(i, "JUMP_FIBER");
        String newLabel = "";
        if (jumpfiber.getOrigPointCuid().trim().equals(ptpCuid)) {
          String oldLabelCn = jumpfiber.getLabelCn();
          newLabel = newName + " => " + oldLabelCn.split(" => ")[1];
          jumpfiber.setLabelCn(newLabel);
        }
        if (jumpfiber.getDestPointCuid().trim().equals(ptpCuid)) {
          if (newLabel.equals("")) {
            String oldLabelCn = jumpfiber.getLabelCn();
            newLabel = oldLabelCn.split(" => ")[0] + " => " + newName;
            jumpfiber.setLabelCn(newLabel);
          } else {
            newLabel = newLabel.split(" => ")[0] + " => " + newName;
            jumpfiber.setLabelCn(newLabel);
          }
        }
        modifyJumpFiber(actionContext, jumpfiber);
      }

      String sql2 = "select * from JUMP_PAIR where ORIG_POINT_CUID = '" + ptpCuid + "' " + " or " + "DEST_POINT_CUID" + " = '" + ptpCuid + "'";

      DboCollection jumpPairList = getSiteDAO().selectDBOs(sql2, new GenericDO[] { new JumpPair() });
      LogHome.getLog().info("根据端口PtpCuid取到JumpPair " + jumpPairList.size() + " 个");
      for (int i = 0; i < jumpPairList.size(); i++) {
        JumpPair jumppaire = (JumpPair)jumpPairList.getQueryDbo(i, "JUMP_PAIR");
        String newLabel = "";
        if (jumppaire.getOrigPointCuid().trim().equals(ptpCuid)) {
          String oldLabelCn = jumppaire.getLabelCn();
          newLabel = newName + " => " + oldLabelCn.split(" => ")[1];
          jumppaire.setLabelCn(newLabel);
        }
        if (jumppaire.getDestPointCuid().trim().equals(ptpCuid)) {
          if (newLabel.equals("")) {
            String oldLabelCn = jumppaire.getLabelCn();
            newLabel = oldLabelCn.split(" => ")[0] + " => " + newName;
            jumppaire.setLabelCn(newLabel);
          } else {
            newLabel = newLabel.split(" => ")[0] + " => " + newName;
            jumppaire.setLabelCn(newLabel);
          }
        }
        modifyJumpPair(actionContext, jumppaire);
      }
    } catch (Exception ex) {
      LogHome.getLog().info("根据端口修改纤芯出错" + ex.getMessage());
      throw new UserException("根据端口修改纤芯出错");
    }
  }

  public void modifyJumpPair(BoActionContext actionContext, JumpPair jumppair)
    throws UserException
  {
    try
    {
      JumpPair oldJumpPair = getSiteDAO().getJumpPairByCuid(actionContext, jumppair.getCuid());
      getSiteDAO().updateObject(actionContext, jumppair);
      if (jumppair.getJumpType() == 1L) {
        GenericDO oirgPort = getConnectPortByCuid(actionContext, jumppair.getOrigPointCuid());
        GenericDO destPort = getConnectPortByCuid(actionContext, jumppair.getDestPointCuid());
        if ((oldJumpPair.getOrigPointCuid().indexOf("PTP") > -1) || (oldJumpPair.getOrigPointCuid().indexOf("SWITCH_PORT") > -1) || (oldJumpPair.getDestPointCuid().indexOf("PTP") > -1) || (oldJumpPair.getDestPointCuid().indexOf("SWITCH_PORT") > -1))
        {
          ((IObjectOperateLogBO)getBO("IObjectOperateLogBO")).addObjOperateLog(actionContext, 2L, 10L, oirgPort, destPort);
        }
        else {
          ((IObjectOperateLogBO)getBO("IObjectOperateLogBO")).addObjOperateLog(actionContext, 2L, 11L, oirgPort, destPort);
        }

        ((IObjectOperateLogBO)getBO("IObjectOperateLogBO")).addObjOperateLog(actionContext, 2L, 9L, oldJumpPair, jumppair);
      }
    }
    catch (Exception ex)
    {
      LogHome.getLog().error("修改跳线失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public GenericDO getConnectPortByCuid(BoActionContext actionContext, String pointCuid) {
    if (pointCuid != null) {
      return getSiteDAO().getObjByCuid(pointCuid);
    }
    return null;
  }

  public void modifyJumpFiber(BoActionContext actionContext, JumpFiber jumpfiber)
    throws UserException
  {
    try
    {
      JumpFiber oldJumpFiber = getSiteDAO().getJumpFiberByCuid(actionContext, jumpfiber.getCuid());
      getSiteDAO().updateObject(actionContext, jumpfiber);
      GenericDO oirgPort = getConnectPortByCuid(actionContext, oldJumpFiber.getOrigPointCuid());
      GenericDO destPort = getConnectPortByCuid(actionContext, oldJumpFiber.getDestPointCuid());
      if ((oldJumpFiber.getOrigPointCuid().indexOf("PTP") > -1) || (oldJumpFiber.getOrigPointCuid().indexOf("SWITCH_PORT") > -1) || (oldJumpFiber.getDestPointCuid().indexOf("PTP") > -1) || (oldJumpFiber.getDestPointCuid().indexOf("SWITCH_PORT") > -1))
      {
        ((IObjectOperateLogBO)getBO("IObjectOperateLogBO")).addObjOperateLog(actionContext, 2L, 10L, oirgPort, destPort);
      }
      else {
        ((IObjectOperateLogBO)getBO("IObjectOperateLogBO")).addObjOperateLog(actionContext, 2L, 11L, oirgPort, destPort);
      }

      ((IObjectOperateLogBO)getBO("IObjectOperateLogBO")).addObjOperateLog(actionContext, 2L, 9L, oldJumpFiber, jumpfiber);
    } catch (Exception ex) {
      LogHome.getLog().error("修改跳纤失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public long getSiteCountByDistrictCuid(BoActionContext actionContext, String districtCuid) throws Exception {
    Class[] type = { Long.TYPE };
    String sql = "select count(cuid)  FROM SITE where RELATED_SPACE_CUID like '" + districtCuid + "%'";

    DataObjectList dataList = getSiteDAO().selectDBOs(sql, type);
    if (dataList != null) {
      GenericDO dboyes = (GenericDO)dataList.get(0);
      return dboyes.getAttrLong("1");
    }
    return 0L;
  }

  public DboCollection getSitePageBySql(BoQueryContext queryContext, String sql)
    throws UserException
  {
    String sqlwherein = "";
    DboCollection list = null;
    try {
      String userId = queryContext.getUserId();
      if (!userId.equals("SYS_USER-0")) {
        DataObjectList districts = null;
        try {
          districts = ((ISecurityBO)super.getBO("ISecurityBO")).getUserDistricts(queryContext, userId);
        } catch (Throwable ex) {
          LogHome.getLog().error("加载可管理区域对象出错", ex);
          throw new UserException(ex);
        }
        sqlwherein = getDistrictInSql(queryContext, sql, districts);
      }

      if (sqlwherein.trim().length() == 0) {
        list = getSiteDAO().querySiteByPageCondition(queryContext, sql);
      }
      return getSiteDAO().querySiteByPageCondition(queryContext, sqlwherein);
    }
    catch (Throwable e)
    {
      LogHome.getLog().info("查询对象时出错" + e.getMessage());
      throw new UserException(e.getMessage());
    }
  }

  public static String getDistrictInSql(BoQueryContext queryContext, String sql, DataObjectList districts)
    throws UserException
  {
    try
    {
      String sqlin;
      if (districts != null) {
        sqlin = "";
        for (int i = 0; i < districts.size(); i++) {
          String districtCuid = ((GenericDO)districts.get(i)).getCuid();
          if (districtCuid.equals("DISTRICT-00001")) {
            return sql;
          }
          sqlin = sqlin + "'" + districtCuid + "',";
        }
      }
      return sql + " and " + "RELATED_SPACE_CUID" + " in (" + sqlin + "'0')";
    }
    catch (Throwable e)
    {
      LogHome.getLog().info("站点得到用户所属区域sql时出错" + e.getMessage());
      throw new UserException(e);
    }
  }

  public DataObjectList getSiteBtsElement()
    throws Exception
  {
    DataObjectList list = null;
    try {
      return getSiteDAO().getSiteBtnEle();
    }
    catch (Throwable e) {
      LogHome.getLog().info("查询所有site站点，同时将关联的基站信息、网元信息查询出时出错" + e.getMessage());
      throw new UserException(e);
    }
  }
}