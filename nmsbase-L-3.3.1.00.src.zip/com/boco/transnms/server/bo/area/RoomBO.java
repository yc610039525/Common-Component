package com.boco.transnms.server.bo.area;

import com.boco.common.util.db.TransactionFactory;
import com.boco.common.util.db.UserTransaction;
import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.bussiness.helper.TopoHelper;
import com.boco.transnms.common.dto.District;
import com.boco.transnms.common.dto.Fiber;
import com.boco.transnms.common.dto.FiberJointBox;
import com.boco.transnms.common.dto.FiberJointPoint;
import com.boco.transnms.common.dto.Miscrack;
import com.boco.transnms.common.dto.Odf;
import com.boco.transnms.common.dto.Odfport;
import com.boco.transnms.common.dto.Optical;
import com.boco.transnms.common.dto.OpticalWay;
import com.boco.transnms.common.dto.Ptp;
import com.boco.transnms.common.dto.Room;
import com.boco.transnms.common.dto.Site;
import com.boco.transnms.common.dto.SwitchPort;
import com.boco.transnms.common.dto.SysUser;
import com.boco.transnms.common.dto.TransElement;
import com.boco.transnms.common.dto.WireSeg;
import com.boco.transnms.common.dto.WireToDuctline;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.base.IAttrObject;
import com.boco.transnms.common.dto.common.BatchUpdataNameData;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.BoHomeFactory;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.dm.DMDataSynHelperX;
import com.boco.transnms.server.bo.ibo.cm.IDistrictBO;
import com.boco.transnms.server.bo.ibo.cm.IObjectOperateLogBO;
import com.boco.transnms.server.bo.ibo.cm.IRoomBO;
import com.boco.transnms.server.bo.ibo.cm.ISiteBO;
import com.boco.transnms.server.bo.ibo.misc.ISecurityBO;
import com.boco.transnms.server.dao.area.RoomDAO;
import com.boco.transnms.server.dao.area.SiteDAO;
import com.boco.transnms.server.dao.base.DaoHelper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="COMMON", initByAllServer=true)
public class RoomBO extends AbstractBO
  implements IRoomBO
{
  public DataObjectList getAllRoom(BoActionContext actionContext)
    throws UserException
  {
    try
    {
      return getRoomDAO().getAllRoom(actionContext);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public Room addRoom(BoActionContext actionContext, Room dbo) throws UserException
  {
    try {
      String sitecuid = dbo.getRelatedSiteCuid();
      DataObjectList cks = getRoomDAO().getRoomBySiteAndName(actionContext, sitecuid, dbo.getLabelCn());
      if (cks.size() > 0) {
        throw new UserException("已经存在重名的机房");
      }

      Room room = getRoomDAO().addRoom(actionContext, dbo);

      BoActionContext boactioncontext = new BoActionContext();
      boactioncontext.setUserId(actionContext.getUserId());
      boactioncontext.setHostIP(actionContext.getHostIP());
      IObjectOperateLogBO ibo = (IObjectOperateLogBO)BoHomeFactory.getInstance().getBO("IObjectOperateLogBO");
      ibo.addObjOperateLog(boactioncontext, 1L, 3L, room, room);
      return room;
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public Room getRoom(BoActionContext actionContext, Long objectId) throws UserException {
    try {
      return getRoomDAO().getRoom(actionContext, objectId);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public Room getRoomByCuid(BoActionContext actionContext, String cuid) throws UserException {
    try {
      return getRoomDAO().getRoomByCuid(actionContext, cuid);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getRoomBySiteCuids(BoActionContext actionContext, String[] cuids) throws UserException {
    try {
      return getRoomDAO().getRoomBySiteCuids(actionContext, cuids);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getRoomBySiteCuid(BoActionContext actionContext, String cuid) throws UserException {
    try {
      return getRoomDAO().getRoomBySiteCuid(actionContext, cuid);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getRoomByDistrictCuid(BoActionContext actionContext, String cuid, String roomName) throws UserException {
    try {
      return getRoomDAO().getRoomByDistrictCuid(actionContext, cuid, roomName);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getRoomByFloorCuid(BoActionContext actionContext, String cuid) throws UserException {
    try {
      return getRoomDAO().getRoomByFloorCuid(actionContext, cuid);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void deleteRoom(BoActionContext actionContext, Long objectId) throws UserException {
    UserTransaction trx = TransactionFactory.getInstance().createTransaction();
    try {
      trx.begin();
      deleteRoomWithOutTrans(actionContext, objectId);
      trx.commit();
    } catch (Exception ex) {
      trx.rollback();
      LogHome.getLog().error("未知原因机房删除失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void deleteRoomWithOutTrans(BoActionContext actionContext, Long objectId) throws UserException
  {
    try
    {
      Room room = getRoom(actionContext, objectId);
      getRoomDAO().delRoom(actionContext, objectId);
    }
    catch (Throwable ex)
    {
      LogHome.getLog().error("未知原因机房删除失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void deleteRooms(BoActionContext actionContext, String objectIds) throws UserException {
    UserTransaction trx = TransactionFactory.getInstance().createTransaction();
    try {
      trx.begin();
      String[] ids = objectIds.split(",");
      for (int i = 0; i < ids.length; i++) {
        Room room = getRoom(actionContext, Long.valueOf(ids[i]));
        getRoomDAO().delRoom(actionContext, Long.valueOf(ids[i]));

        BoActionContext boactioncontext = new BoActionContext();
        boactioncontext.setUserId(actionContext.getUserId());
        boactioncontext.setHostIP(actionContext.getHostIP());
        IObjectOperateLogBO ibo = (IObjectOperateLogBO)BoHomeFactory.getInstance().getBO("IObjectOperateLogBO");
        ibo.addObjOperateLog(boactioncontext, 3L, 3L, room, room);
      }

      trx.commit();
    } catch (Throwable ex) {
      trx.rollback();
      LogHome.getLog().error("未知原因机房删除失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void modifyRoom(BoActionContext actionContext, Room dbo) throws UserException
  {
    try {
      String sitecuid = dbo.getRelatedSiteCuid();
      DataObjectList cks = getRoomDAO().getRoomBySiteAndName(actionContext, sitecuid, dbo.getLabelCn());
      if (cks.size() > 0) {
        String cuid = ((Room)cks.get(0)).getCuid();
        if ((!cuid.equals("")) && (!cuid.equals(dbo.getCuid()))) {
          throw new UserException("已经存在重名的机房");
        }

      }

      Room room = getRoom(actionContext, Long.valueOf(dbo.getObjectNum()));
      if (!dbo.getLabelCn().equals(room.getLabelCn()));
      getRoomDAO().modifyRoom(actionContext, dbo);

      BoActionContext boactioncontext = new BoActionContext();
      boactioncontext.setUserId(actionContext.getUserId());
      boactioncontext.setHostIP(actionContext.getHostIP());
      IObjectOperateLogBO ibo = (IObjectOperateLogBO)BoHomeFactory.getInstance().getBO("IObjectOperateLogBO");
      ibo.addObjOperateLog(boactioncontext, 2L, 3L, room, dbo);
    }
    catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getChildSwitch(BoActionContext actionContext, String roomCuids)
    throws UserException
  {
    try
    {
      return getRoomDAO().getChildSwitch(actionContext, roomCuids);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getChildElement(BoActionContext actionContext, String roomCuids) throws UserException {
    try {
      return getRoomDAO().getChildElement(actionContext, roomCuids);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getRoomByName(BoActionContext actionContext, String name) throws UserException {
    try {
      return getRoomDAO().getRoomByName(actionContext, name);
    } catch (Exception ex) {
      LogHome.getLog().error("根据名称取机房失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getRoomByNameAndSiteCuid(BoActionContext actionContext, String name, String cuid) throws UserException {
    try {
      return getRoomDAO().getRoomBySiteAndName(actionContext, cuid, name);
    } catch (Exception ex) {
      LogHome.getLog().error("根据名称和站点cuid取机房失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getRoomByRoomName(BoQueryContext boQueryContext, String roomName) throws UserException {
    try {
      return getRoomDAO().getRoomByRoomName(boQueryContext, roomName);
    } catch (Exception ex) {
      LogHome.getLog().error("根据名称取机房失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getRoomByRoomNameNew(BoQueryContext boQueryContext, String roomName, String districtcuid, String issub) throws UserException {
    try {
      String sql = "";
      boolean flag = false;
      if ((districtcuid != null) && (districtcuid.trim().length() > 0) && (districtcuid.indexOf("DISTRICT-") >= 0)) {
        sql = "SELECT * FROM ROOM WHERE RELATED_SPACE_CUID";
        if (issub.equals("true"))
          sql = sql + " LIKE '" + districtcuid + "%'";
        else
          sql = sql + " = '" + districtcuid + "'";
      }
      else if ((districtcuid != null) && (districtcuid.trim().length() > 0) && (districtcuid.indexOf("SITE-") >= 0)) {
        sql = "SELECT * FROM ROOM WHERE RELATED_SITE_CUID='" + districtcuid + "'";
      }
      else {
        sql = "SELECT * FROM ROOM";
        if ((boQueryContext == null) || (boQueryContext.getUserId() == null)) {
          flag = true;
        }
        else
        {
          String userId = boQueryContext.getUserId();
          if ((!DaoHelper.isNotEmpty(userId)) || ("SYS_USER-0".equals(userId))) {
            flag = true;
          } else {
            sql = "SELECT * FROM ROOM WHERE 1=1 ";
            List includeDisList = new ArrayList();
            List disList = new ArrayList();
            DataObjectList disDbos = getSecurityBO().getUserDistricts(new BoActionContext(), userId);
            List tempList = new ArrayList();
            String tempsql = "";
            if ((disDbos != null) && (disDbos.size() > 0))
            {
              for (int i = 0; i < disDbos.size(); i++) {
                District dis = (District)disDbos.get(i);
                if (dis.getAttrBool("IS_INCLUDE_SUB_DISTRICT"))
                  includeDisList.add(dis.getCuid());
                else {
                  tempList.add(dis.getCuid());
                }
              }
              boolean flag1 = true;
              for (int i = 0; i < tempList.size(); i++) {
                flag1 = true;
                String temp = (String)tempList.get(i);
                if (temp.length() > 13) {
                  for (int j = 14; j < temp.length(); ) {
                    String parentDis = temp.substring(0, j);
                    if (includeDisList.contains(parentDis)) {
                      flag1 = false;
                      break;
                    }
                    j += 6;
                  }
                  if (flag1) {
                    disList.add(temp);
                  }
                }
              }

              DaoHelper.getInstance(); String includeDisStr = DaoHelper.getArrayListToStr(includeDisList);
              if (DaoHelper.isNotEmpty(includeDisStr)) {
                String temp = "%' OR RELATED_SPACE_CUID LIKE '";
                tempsql = "RELATED_SPACE_CUID LIKE '" + includeDisStr.replaceAll(",", temp) + "%'";
              }

              DaoHelper.getInstance(); String disStr = DaoHelper.getArrayListToStr(disList);
              if (DaoHelper.isNotEmpty(disStr)) {
                String temp = "' OR RELATED_SPACE_CUID='";
                if (DaoHelper.isNotEmpty(tempsql))
                  tempsql = tempsql + " OR RELATED_SPACE_CUID='" + disStr.replaceAll(",", temp) + "'";
                else {
                  tempsql = "RELATED_SPACE_CUID='" + disStr.replaceAll(",", temp) + "'";
                }
              }
            }
            if (DaoHelper.isNotEmpty(tempsql)) {
              sql = sql + " AND( " + tempsql + " ) ";
            }
          }
        }
      }
      if ((roomName != null) && (roomName.trim().length() > 0)) {
        if (flag == true)
          sql = sql + " WHERE " + "LABEL_CN" + " LIKE '%" + roomName + "%'";
        else {
          sql = sql + " AND " + "LABEL_CN" + " LIKE '%" + roomName + "%'";
        }
      }
      return getRoomDAO().getRoomByRoomNameNew(boQueryContext, sql);
    } catch (Exception ex) {
      LogHome.getLog().error("根据名称取机房失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public ISecurityBO getSecurityBO() {
    return (ISecurityBO)super.getBO("ISecurityBO");
  }

  public DboCollection getRoomByPageCondition(BoQueryContext queryContext, String districtCuid, String siteCuids, String roomName, Boolean isIncludeChild, Map map, String roomType, String serviceLevel) throws UserException {
    try {
      SysUser user = getSecurityBO().getSysUserByCuid(new BoActionContext(), queryContext.getUserId());
      return getRoomDAO().getRoomByPageCondition(queryContext, districtCuid, siteCuids, roomName, user, isIncludeChild, map, roomType, serviceLevel);
    } catch (Exception ex) {
      LogHome.getLog().error("根据区域站点名称取机房失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public String getRoomCuidByLabelCn(BoActionContext actionContext, String labelCn) throws UserException {
    try {
      return getRoomDAO().getCuidByLabelcn(actionContext, labelCn);
    } catch (Exception ex) {
      LogHome.getLog().error("获取站点失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public RoomDAO getRoomDAO()
  {
    return (RoomDAO)super.getDAO("RoomDAO");
  }

  public SiteDAO getSiteDAO() {
    return (SiteDAO)super.getDAO("SiteDAO");
  }

  public DboCollection getSwitchElementByLabelcnAndRoomCuidByPage(BoQueryContext boQueryContext, String labelcn, String roomCuid) throws UserException
  {
    try {
      return getRoomDAO().getSwitchElementByLabelcnAndRoomCuidByPage(boQueryContext, labelcn, roomCuid);
    } catch (Exception ex) {
      LogHome.getLog().error("根据设备失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getSwitchElementByCuidByPage(BoQueryContext boQueryContext, String cuid) throws Exception {
    try {
      return getRoomDAO().getSwitchElementByCuidByPage(boQueryContext, cuid);
    } catch (Exception ex) {
      LogHome.getLog().error("根据设备失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public boolean isHaveRelatedObj(String className, GenericDO deleteObj) throws UserException
  {
    try {
      BoActionContext actionContext = new BoActionContext();
      if (deleteObj.getClassName().equals("SITE")) {
        Site site = (Site)deleteObj;
        String cuid = site.getCuid();
        DataObjectList rooms = getSiteDAO().getChildRoom(cuid);
        if ((rooms != null) && (rooms.size() > 0)) {
          return true;
        }
        return false;
      }

      return false;
    }
    catch (Exception ex) {
      throw new UserException(ex.getMessage());
    }
  }

  public int getRelatedDeleteObjCount(String className, GenericDO deleteObj) throws UserException {
    int size = 0;
    try {
      if ((deleteObj.getClassName() != null) && (deleteObj.getClassName().equals("SITE"))) {
        String sql = "select count(*) from ROOM where RELATED_SITE_CUID = '" + deleteObj.getCuid() + "'";
        size = getRoomDAO().getRoomCountBySql(new BoActionContext(), sql);
      }
    } catch (Exception ex) {
      LogHome.getLog().info("查询机房个数出错" + ex.getMessage());
      throw new UserException("查询机房个数出错" + ex.getMessage());
    }
    return size;
  }

  public DataObjectList getRelatedDeleteObjects(String className, GenericDO deleteObj) throws UserException
  {
    return null;
  }

  public void deleteReletedOfObject(String className, GenericDO deleteObj)
    throws UserException
  {
    try
    {
      BoActionContext actionContext = new BoActionContext();
      if ((deleteObj.getClassName() != null) && (deleteObj.getClassName().equals("SITE"))) {
        String sitecuid = deleteObj.getCuid();
        String[] cuids = { sitecuid };
        DataObjectList roomList = getRoomBySiteCuids(actionContext, cuids);
        if ((roomList != null) && (roomList.size() > 0))
          for (int i = 0; i < roomList.size(); i++) {
            Room room = (Room)roomList.get(i);
            deleteRoomWithOutTrans(actionContext, Long.valueOf(room.getObjectNum()));
          }
      }
    }
    catch (Exception ex) {
      LogHome.getLog().error("级联删除机房失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getRoomTypeInfo() throws UserException
  {
    try {
      return getRoomDAO().getRoomTypeInfo();
    } catch (Throwable ex) {
      throw new UserException(ex.getMessage());
    }
  }

  private void copyA1LinepairProperty(GenericDO retDO, GenericDO dto)
  {
    retDO.setAttrValue("A1EqptName", dto.getAttrValue("eqptName"));
    retDO.setAttrValue("A1ModuleName", dto.getAttrValue("moduleName"));
    retDO.setAttrValue("A1PortName", dto.getAttrValue("portName"));
    retDO.setAttrValue("A1PortRow", dto.getAttrValue("portRow"));
    retDO.setAttrValue("A1PortCol", dto.getAttrValue("portCol"));
  }

  private void copyA2LinepairProperty(GenericDO retDO, GenericDO dto) {
    retDO.setAttrValue("A2EqptName", dto.getAttrValue("eqptName"));
    retDO.setAttrValue("A2ModuleName", dto.getAttrValue("moduleName"));
    retDO.setAttrValue("A2PortName", dto.getAttrValue("portName"));
    retDO.setAttrValue("A2PortRow", dto.getAttrValue("portRow"));
    retDO.setAttrValue("A2PortCol", dto.getAttrValue("portCol"));
  }

  private void copyZ1LinepairProperty(GenericDO retDO, GenericDO dto) {
    retDO.setAttrValue("Z1EqptName", dto.getAttrValue("eqptName"));
    retDO.setAttrValue("Z1ModuleName", dto.getAttrValue("moduleName"));
    retDO.setAttrValue("Z1PortName", dto.getAttrValue("portName"));
    retDO.setAttrValue("Z1PortRow", dto.getAttrValue("portRow"));
    retDO.setAttrValue("Z1PortCol", dto.getAttrValue("portCol"));
  }

  private void copyZ2LinepairProperty(GenericDO retDO, GenericDO dto) {
    retDO.setAttrValue("Z2EqptName", dto.getAttrValue("eqptName"));
    retDO.setAttrValue("Z2ModuleName", dto.getAttrValue("moduleName"));
    retDO.setAttrValue("Z2PortName", dto.getAttrValue("portName"));
    retDO.setAttrValue("Z2PortRow", dto.getAttrValue("portRow"));
    retDO.setAttrValue("Z2PortCol", dto.getAttrValue("portCol"));
  }

  private void copyIsFix(GenericDO jumplink, GenericDO retDO) {
    if (((Boolean)jumplink.getAttrValue("IS_FIXED")).booleanValue())
      retDO.setAttrValue("isFix", "是");
    else
      retDO.setAttrValue("isFix", "否");
  }

  private void copyZWireProperty(GenericDO retDO, GenericDO zdto)
  {
    retDO.setAttrValue("ZWireSystemName", zdto.getAttrValue("wireSystemName"));
    retDO.setAttrValue("ZWireSegName", zdto.getAttrValue("wireSegName"));
    retDO.setAttrValue("ZOrigPointName", zdto.getAttrValue("origPointName"));
    retDO.setAttrValue("ZDestPointName", zdto.getAttrValue("destPointName"));
    retDO.setAttrValue("ZWireNo", zdto.getAttrValue("wireNo"));
  }

  private void copyAPortProperty(GenericDO retDO, GenericDO adto) {
    retDO.setAttrValue("districtName", adto.getAttrValue("districtName"));
    retDO.setAttrValue("siteName", adto.getAttrValue("siteName"));
    retDO.setAttrValue("roomName", adto.getAttrValue("roomName"));
    retDO.setAttrValue("AEqptType", adto.getAttrValue("eqptType"));
    retDO.setAttrValue("AEqptName", adto.getAttrValue("eqptName"));
    retDO.setAttrValue("AModuleName", adto.getAttrValue("moduleName"));
    retDO.setAttrValue("APortName", adto.getAttrValue("portName"));
    retDO.setAttrValue("APortRow", adto.getAttrValue("portRow"));
    retDO.setAttrValue("APortCol", adto.getAttrValue("portCol"));
  }

  private void copyZPortProperty(GenericDO retDO, GenericDO zdto) {
    retDO.setAttrValue("districtName", zdto.getAttrValue("districtName"));
    retDO.setAttrValue("siteName", zdto.getAttrValue("siteName"));
    retDO.setAttrValue("roomName", zdto.getAttrValue("roomName"));
    retDO.setAttrValue("ZEqptType", zdto.getAttrValue("eqptType"));
    retDO.setAttrValue("ZEqptName", zdto.getAttrValue("eqptName"));
    retDO.setAttrValue("ZModuleName", zdto.getAttrValue("moduleName"));
    retDO.setAttrValue("ZPortName", zdto.getAttrValue("portName"));
    retDO.setAttrValue("ZPortRow", zdto.getAttrValue("portRow"));
    retDO.setAttrValue("ZPortCol", zdto.getAttrValue("portCol"));
  }

  private void copyAPtpProperty(GenericDO retDO, GenericDO adto) {
    retDO.setAttrValue("districtName", adto.getAttrValue("districtName"));
    retDO.setAttrValue("siteName", adto.getAttrValue("siteName"));
    retDO.setAttrValue("roomName", adto.getAttrValue("roomName"));
    retDO.setAttrValue("AEqptName", adto.getAttrValue("eqptName"));
    retDO.setAttrValue("ARackNum", adto.getAttrValue("rackNum"));
    retDO.setAttrValue("ASubRackNum", adto.getAttrValue("subRackNum"));
    retDO.setAttrValue("AShelfNum", adto.getAttrValue("shelfNum"));
    retDO.setAttrValue("ASubShelfNum", adto.getAttrValue("subShelfNum"));
    retDO.setAttrValue("ASlotNum", adto.getAttrValue("slotNum"));
    retDO.setAttrValue("ASubSlotNum", adto.getAttrValue("subSlotNum"));
    retDO.setAttrValue("APortNo", adto.getAttrValue("portNo"));
  }

  private ISiteBO getSiteBO()
  {
    return (ISiteBO)super.getBO("ISiteBO");
  }

  private IDistrictBO getDistrictBO() {
    return (IDistrictBO)super.getBO("IDistrictBO");
  }

  public DataObjectList getOdfByNameAndRoomCuid(BoActionContext actionContext, String odfname, String roomCuid) throws UserException
  {
    try
    {
      return getRoomDAO().getOdfByRoomAndName(actionContext, roomCuid, odfname);
    } catch (Exception ex) {
      LogHome.getLog().error("根据名称和机房cuid取odf失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getMiscrackByNameAndRoomCuid(BoActionContext actionContext, String miscrackname, String roomCuid) throws UserException
  {
    try {
      return getRoomDAO().getMiscrackByRoomAndName(actionContext, roomCuid, miscrackname);
    } catch (Exception ex) {
      LogHome.getLog().error("根据名称和机房cuid取Miscrack失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public Room getRoomByPort(BoActionContext actionContext, String portCuid)
  {
    if (portCuid == null) {
      return null;
    }
    GenericDO gdo = new GenericDO();
    gdo.setCuid(portCuid);
    if (gdo.getClassName() == null)
      return null;
    try
    {
      gdo = gdo.cloneByClassName();
      GenericDO port = getRoomDAO().getObjByCuid(gdo);
      if (port != null) {
        String devCuid = null;
        if (((port instanceof Ptp)) || ((port instanceof SwitchPort)))
          devCuid = port.getAttrString("RELATED_NE_CUID");
        else {
          devCuid = port.getAttrString("RELATED_DEVICE_CUID");
        }

        if (devCuid != null) {
          gdo = new GenericDO();
          gdo.setCuid(devCuid);
          if (gdo.getClassName() == null) {
            return null;
          }
          gdo = gdo.cloneByClassName();
          GenericDO dev = getRoomDAO().getObjByCuid(gdo);
          String roomCuid = (String)dev.getAttrValue("RELATED_ROOM_CUID");
          if (roomCuid != null) {
            return getRoomByCuid(actionContext, roomCuid);
          }
        }
      }

    }
    catch (Exception e)
    {
      LogHome.getLog().error("getRoomByPort " + portCuid, e);
    }
    return null;
  }

  public void modifyShelfName(BoActionContext actionContext, BatchUpdataNameData batchUpdataNameData, HashMap portMap)
    throws UserException
  {
  }

  public DboCollection getAllRoomCuidAndLabelCn(BoActionContext actionContext)
    throws UserException
  {
    try
    {
      return getRoomDAO().getAllRoomCuidAndLabelCn(actionContext);
    } catch (Exception ex) {
      LogHome.getLog().error("查询机房失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getRoomBySql(BoActionContext actionContext, String sql) throws UserException {
    try {
      return getRoomDAO().getObjectsBySql(sql, new Room(), 0);
    } catch (Exception e) {
      throw new UserException("查询站点失败，" + e.getMessage());
    }
  }

  public void deleteRoomByCuid(BoActionContext actionContext, String roomCuid)
    throws UserException
  {
    try
    {
      Room room = getRoomByCuid(actionContext, roomCuid);
      getRoomDAO().delRoom(actionContext, Long.valueOf(room.getObjectNum()));

      BoActionContext boactioncontext = new BoActionContext();
      boactioncontext.setUserId(actionContext.getUserId());
      boactioncontext.setHostIP(actionContext.getHostIP());
      IObjectOperateLogBO ibo = (IObjectOperateLogBO)BoHomeFactory.getInstance().getBO("IObjectOperateLogBO");
      ibo.addObjOperateLog(boactioncontext, 3L, 3L, room, room);
    }
    catch (Throwable ex) {
      LogHome.getLog().error("机房删除失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void deleteRoomFiber(BoActionContext actionContext, Map devMap)
    throws Exception
  {
    try
    {
      LogHome.getLog().info("调用接口-----deleteRoomFiber----begin");

      if (devMap.get("ODF") != null) {
        DataObjectList dbos = (DataObjectList)devMap.get("ODF");
        if ((dbos != null) && (dbos.size() > 0)) {
          DboCollection odfCol = new DboCollection();
          for (int i = 0; i < dbos.size(); i++) {
            odfCol.insertAttrField(i, (IAttrObject)dbos.get(i));
          }
          modifyRelatedFiberAndOpticalAndOpticalWayMakeFlag(actionContext, odfCol, new Odf());
          modifyPort(actionContext, odfCol, new Odf());
        }
      }
      if (devMap.get("MISCRACK") != null) {
        DataObjectList dbos = (DataObjectList)devMap.get("MISCRACK");
        if ((dbos != null) && (dbos.size() > 0)) {
          DboCollection miscrackCol = new DboCollection();
          for (int i = 0; i < dbos.size(); i++) {
            miscrackCol.insertAttrField(i, (IAttrObject)dbos.get(i));
          }
          modifyRelatedFiberAndOpticalAndOpticalWayMakeFlag(actionContext, miscrackCol, new Miscrack());
          modifyPort(actionContext, miscrackCol, new Miscrack());
        }
      }
      if (devMap.get("TRANS_ELEMENT") != null) {
        DataObjectList dbos = (DataObjectList)devMap.get("TRANS_ELEMENT");
        if ((dbos != null) && (dbos.size() > 0)) {
          DboCollection transElementCol = new DboCollection();
          for (int i = 0; i < dbos.size(); i++) {
            transElementCol.insertAttrField(i, (IAttrObject)dbos.get(i));
          }

          modifyRelatedFiberAndOpticalAndOpticalWayMakeFlag(actionContext, transElementCol, new TransElement());
        }
      }

      if (devMap.get("FIBER_JOINT_BOX") != null) {
        DataObjectList dbos = (DataObjectList)devMap.get("FIBER_JOINT_BOX");
        if ((dbos != null) && (dbos.size() > 0)) {
          DboCollection fiberJointBoxCol = new DboCollection();
          for (int i = 0; i < fiberJointBoxCol.size(); i++) {
            fiberJointBoxCol.insertAttrField(i, (IAttrObject)dbos.get(i));
          }

          modifyRelatedFiberAndOpticalAndOpticalWayMakeFlag(actionContext, fiberJointBoxCol, new FiberJointBox());
          modifyPort(actionContext, fiberJointBoxCol, new FiberJointBox());
        }

      }

      LogHome.getLog().info("调用接口-----deleteRoomFiber----end");
    }
    catch (Exception e)
    {
      LogHome.getLog().error("删除机房内设备的纤芯关联关系出错", e);
      throw new UserException("删除机房内设备的纤芯关联关系出错" + e.getMessage());
    }
  }

  private void modifyPort(BoActionContext actionContext, DboCollection collection, GenericDO template) throws Exception { if ((collection == null) && (collection.size() == 0)) {
      return;
    }
    DataObjectList ports = new DataObjectList();
    String sql = "";
    String className = template.getClassName();
    for (int i = 0; i < collection.size(); i++) {
      GenericDO gdo = (GenericDO)collection.getAttrField(className, i);

      if ((className.equals("ODF")) || (className.equals("MISCRACK"))) {
        sql = "SELECT * FROM ODFPORT  WHERE RELATED_DEVICE_CUID = '" + gdo.getCuid() + "'";
        DboCollection odfports = new DboCollection();
        odfports = getRoomDAO().selectDBOs(sql, new GenericDO[] { new Odfport() });
        DataObjectList odfportList = new DataObjectList();
        if (odfports.size() > 0) {
          TopoHelper.putDboCollectionToList(odfports, odfportList, "ODFPORT");
          ports.addAll(odfportList);
        }
      }
      else if (className.equals("FIBER_JOINT_BOX")) {
        sql = "SELECT * FROM FIBER_JOINT_POINT WHERE RELATED_DEVICE_CUID= '" + gdo.getCuid() + "'";
        DboCollection fiberJointPoints = new DboCollection();
        fiberJointPoints = getRoomDAO().selectDBOs(sql, new GenericDO[] { new FiberJointPoint() });
        DataObjectList fiberJointPointList = new DataObjectList();

        if (fiberJointPoints.size() > 0) {
          TopoHelper.putDboCollectionToList(fiberJointPoints, fiberJointPointList, "FIBER_JOINT_POINT");
          ports.addAll(fiberJointPointList);
        }
      }
    }

    for (GenericDO port : ports) {
      port.setAttrValue("IS_CONNECTED", false);
      port.setAttrValue("IS_CONNECTED_TO_FIBER", false);
      port.setAttrValue("SERVICE_STATE", 1L);
    }
    getRoomDAO().updateObjects(actionContext, ports, null);
  }

  private void modifyOpticalWayMakeFlag(BoActionContext actionContext, DataObjectList fiberList)
    throws Exception
  {
    DataObjectList opticalWayList = new DataObjectList();
    if ((fiberList != null) && (fiberList.size() > 0)) {
      for (GenericDO fiberGdo : fiberList)
      {
        String opticalWaySql = "select * from OPTICAL_WAY where  CUID IN (SELECT OPR.RELATED_SERVICE_CUID FROM OPTICAL_ROUTE OPR ,OPTICAL_ROUTE_TO_PATH OPRTP WHERE OPR.CUID = OPRTP.OPTICAL_ROUTE_CUID AND PATH_CUID IN (SELECT OPTICAL_CUID FROM OPTICAL_TO_FIBER WHERE FIBER_CUID = '" + fiberGdo.getCuid() + "'))";
        DboCollection opticalWayCol = new DboCollection();
        opticalWayCol = getRoomDAO().selectDBOs(opticalWaySql, new GenericDO[] { new OpticalWay() });
        if (opticalWayCol.size() > 0) {
          DataObjectList tempOpticalWayList = new DataObjectList();
          TopoHelper.putDboCollectionToList(opticalWayCol, tempOpticalWayList, "OPTICAL_WAY");
          opticalWayList.addAll(tempOpticalWayList);
        }
      }
    }

    if (opticalWayList.size() > 0) {
      for (GenericDO opticalWay : opticalWayList) {
        opticalWay.setAttrValue("MAKE_FLAG", 1L);
      }
      getRoomDAO().updateObjects(actionContext, opticalWayList, null);
    }
  }

  private void modifyOpticalMakeFlag(BoActionContext actionContext, DataObjectList fiberList)
    throws Exception
  {
    DataObjectList opticalList = new DataObjectList();
    if ((fiberList != null) && (fiberList.size() > 0)) {
      for (GenericDO fiberGdo : fiberList)
      {
        String opticalSql = "select A.* from OPTICAL A, OPTICAL_TO_FIBER B where A.CUID=B.OPTICAL_CUID and B.FIBER_CUID='" + fiberGdo.getCuid() + "'";
        DboCollection opticalCol = new DboCollection();
        opticalCol = getRoomDAO().selectDBOs(opticalSql, new GenericDO[] { new Optical() });
        if (opticalCol.size() > 0) {
          DataObjectList tempOpticalList = new DataObjectList();
          TopoHelper.putDboCollectionToList(opticalCol, tempOpticalList, "OPTICAL");
          opticalList.addAll(tempOpticalList);
        }
      }
    }

    if (opticalList.size() > 0) {
      for (GenericDO optical : opticalList) {
        optical.setAttrValue("MAKE_FLAG", 1L);
      }
      getRoomDAO().updateObjects(actionContext, opticalList, null);
    }
  }

  private DataObjectList modifyRelatedFiber(BoActionContext actionContext, DboCollection collection, GenericDO template)
    throws Exception
  {
    if ((collection == null) || (collection.size() == 0)) {
      return null;
    }
    DataObjectList fiberList = new DataObjectList();
    for (int i = 0; i < collection.size(); i++) {
      GenericDO dbo = (GenericDO)collection.getAttrField(template.getClassName(), i);
      String sql = "select * from FIBER where ORIG_EQP_CUID='" + dbo.getCuid() + "' OR " + "DEST_EQP_CUID" + "='" + dbo.getCuid() + "'";
      DboCollection fiberCol = new DboCollection();

      fiberCol = getRoomDAO().selectDBOs(sql, new GenericDO[] { new Fiber() });

      if (fiberCol.size() > 0) {
        DataObjectList tempFiberList = new DataObjectList();
        TopoHelper.putDboCollectionToList(fiberCol, tempFiberList, "FIBER");
        fiberList.addAll(tempFiberList);
      }
    }

    for (GenericDO fiberGdo : fiberList) {
      fiberGdo.setAttrNull("ORIG_POINT_CUID");
      fiberGdo.setAttrNull("ORIG_EQP_CUID");
      fiberGdo.setAttrNull("DEST_POINT_CUID");
      fiberGdo.setAttrNull("DEST_EQP_CUID");
    }

    getRoomDAO().updateObjects(actionContext, fiberList, null);

    return fiberList;
  }

  private void modifyRelatedFiberAndOpticalAndOpticalWayMakeFlag(BoActionContext actionContext, DboCollection collection, GenericDO template)
    throws Exception
  {
    if ((collection == null) || (collection.size() == 0)) {
      return;
    }
    DataObjectList fiberList = new DataObjectList();
    fiberList = modifyRelatedFiber(actionContext, collection, template);

    modifyOpticalMakeFlag(actionContext, fiberList);
    modifyOpticalWayMakeFlag(actionContext, fiberList);
  }

  public DataObjectList modifyRelatedSpaceByDuctLine(BoActionContext context, Room srcRoom, Room desRoom, GenericDO segTemplate, GenericDO branchTemplate)
    throws Exception
  {
    try
    {
      LogHome.getLog().info("调用接口------modifyRelatedSpaceByDuctLine------begin (" + segTemplate.getClassName() + ")");
      DataObjectList ductLines = new DataObjectList();

      String srcSiteCuid = srcRoom.getRelatedSiteCuid();
      String desSiteCuid = desRoom.getRelatedSiteCuid();

      String segSql = "SELECT * FROM " + segTemplate.getClassName() + " WHERE ORIG_POINT_CUID = '" + srcSiteCuid + "' OR DEST_POINT_CUID = '" + srcSiteCuid + "'";
      DboCollection segs = new DboCollection();
      segs = getRoomDAO().selectDBOs(segSql, new GenericDO[] { segTemplate });

      HashSet cuids = new HashSet();

      for (int i = 0; i < segs.size(); i++) {
        GenericDO seg = (GenericDO)segs.getAttrField(segTemplate.getClassName(), i);
        if (branchTemplate != null) {
          cuids.add(seg.getAttrString("RELATED_BRANCH_CUID"));
        }

        String origPointCuid = seg.getAttrString("ORIG_POINT_CUID");
        String destPointCuid = seg.getAttrString("DEST_POINT_CUID");

        if (srcSiteCuid.equals(origPointCuid)) {
          seg.setAttrValue("ORIG_POINT_CUID", desSiteCuid);
        }
        else if (srcSiteCuid.equals(destPointCuid)) {
          seg.setAttrValue("DEST_POINT_CUID", desSiteCuid);
        }
      }

      DataObjectList branches = new DataObjectList();
      if (cuids.size() > 0) {
        List cuidList = new ArrayList(cuids);
        branches = getRoomDAO().getObjsByCuids(context, cuidList, branchTemplate);
      }

      String wireToDuctLineSql = "SELECT * FROM WIRE_TO_DUCTLINE WHERE LINE_SEG_CUID IN ( SELECT CUID FROM " + segTemplate.getClassName() + " WHERE ORIG_POINT_CUID='" + srcSiteCuid + "' OR DEST_POINT_CUID='" + srcSiteCuid + "')";
      DboCollection wireToDuctLines = new DboCollection();
      wireToDuctLines = getRoomDAO().selectDBOs(wireToDuctLineSql, new GenericDO[] { new WireToDuctline() });

      for (GenericDO branch : branches) {
        String origPointCuid = branch.getAttrString("ORIG_POINT_CUID");
        String destPointCuid = branch.getAttrString("DEST_POINT_CUID");

        if (srcSiteCuid.equals(origPointCuid)) {
          branch.setAttrValue("ORIG_POINT_CUID", desSiteCuid);
        }
        else if (srcSiteCuid.equals(destPointCuid)) {
          branch.setAttrValue("DEST_POINT_CUID", desSiteCuid);
        }

      }

      for (int i = 0; i < wireToDuctLines.size(); i++) {
        GenericDO wireToDuctLine = (GenericDO)wireToDuctLines.getAttrField("WIRE_TO_DUCTLINE", i);

        String disPointCuid = wireToDuctLine.getAttrString("DIS_POINT_CUID");
        String endPointCuid = wireToDuctLine.getAttrString("END_POINT_CUID");

        if (srcSiteCuid.equals(disPointCuid)) {
          wireToDuctLine.setAttrValue("DIS_POINT_CUID", desSiteCuid);
        }
        else if (srcSiteCuid.equals(endPointCuid)) {
          wireToDuctLine.setAttrValue("END_POINT_CUID", desSiteCuid);
        }
      }

      if (segs.size() > 0) {
        DataObjectList segList = new DataObjectList();
        TopoHelper.putDboCollectionToList(segs, segList, segTemplate.getClassName());
        ductLines.addAll(segList);
        getRoomDAO().updateObjects(context, segList, null);
      }

      getRoomDAO().updateObjects(context, branches, null);

      if (wireToDuctLines.size() > 0) {
        DataObjectList wireToDuctLineList = new DataObjectList();
        TopoHelper.putDboCollectionToList(wireToDuctLines, wireToDuctLineList, "WIRE_TO_DUCTLINE");
        getRoomDAO().updateObjects(context, wireToDuctLineList, null);
      }
      LogHome.getLog().info("调用接口------modifyRelatedSpaceByDuctLine------end (" + segTemplate.getClassName() + ")");
      return ductLines;
    }
    catch (Exception e)
    {
      LogHome.getLog().error("机房搬迁外线资源承载路由段失败!", e);
      throw new UserException("机房搬迁外线资源承载路由段失败!" + e.getMessage());
    }
  }

  public DataObjectList modifyRelatedSpaceByWireSeg(BoActionContext context, Room srcRoom, Room desRoom)
    throws Exception
  {
    try
    {
      LogHome.getLog().info("调用接口------modifyRelatedSpaceByWireSeg------begin");
      DataObjectList wireSegs = new DataObjectList();

      String srcSiteCuid = srcRoom.getRelatedSiteCuid();
      String desSiteCuid = desRoom.getRelatedSiteCuid();
      String srcRoomCuid = srcRoom.getCuid();
      String desRoomCuid = desRoom.getCuid();

      String sql = "SELECT * FROM WIRE_SEG WHERE ORIG_POINT_CUID='" + srcSiteCuid + "' OR DEST_POINT_CUID='" + srcSiteCuid + "'";
      DboCollection wireSegCollection = new DboCollection();
      wireSegCollection = getRoomDAO().selectDBOs(sql, new GenericDO[] { new WireSeg() });
      for (int i = 0; i < wireSegCollection.size(); i++) {
        GenericDO wireSeg = (GenericDO)wireSegCollection.getAttrField("WIRE_SEG", i);
        String origPointCuid = wireSeg.getAttrString("ORIG_POINT_CUID");
        String destPointCuid = wireSeg.getAttrString("DEST_POINT_CUID");

        if (srcSiteCuid.equals(origPointCuid)) {
          wireSeg.setAttrValue("ORIG_POINT_CUID", desSiteCuid);
        }
        else if (srcSiteCuid.equals(destPointCuid)) {
          wireSeg.setAttrValue("DEST_POINT_CUID", desSiteCuid);
        }
      }
      if (wireSegCollection.size() > 0) {
        DataObjectList wireSegList = new DataObjectList();
        TopoHelper.putDboCollectionToList(wireSegCollection, wireSegList, "WIRE_SEG");
        wireSegs.addAll(wireSegList);
        getRoomDAO().updateObjects(context, wireSegList, null);
      }

      DataObjectList fibersForOptical = new DataObjectList();

      for (int i = 0; i < wireSegCollection.size(); i++) {
        GenericDO wireSeg = (GenericDO)wireSegCollection.getAttrField("WIRE_SEG", i);
        String fiberSql = "SELECT * FROM FIBER WHERE ORIG_SITE_CUID='" + srcSiteCuid + "' OR DEST_SITE_CUID='" + srcSiteCuid + "'";
        DboCollection fibers = new DboCollection();
        fibers = getRoomDAO().selectDBOs(fiberSql, new GenericDO[] { new Fiber() });

        if (fibers.size() > 0) {
          fibersForOptical.add(fibers.getAttrField("FIBER", 0));
        }

        for (int j = 0; j < fibers.size(); j++) {
          GenericDO fiber = (GenericDO)fibers.getAttrField("FIBER", j);
          String f_origSiteCuid = fiber.getAttrString("ORIG_SITE_CUID");
          String f_destSiteCuid = fiber.getAttrString("DEST_SITE_CUID");

          if (srcSiteCuid.equals(f_origSiteCuid)) {
            fiber.setAttrValue("ORIG_SITE_CUID", desSiteCuid);
          }
          else if (srcSiteCuid.equals(f_destSiteCuid)) {
            fiber.setAttrValue("DEST_SITE_CUID", desSiteCuid);
          }
        }

        if (fibers.size() > 0) {
          DataObjectList fiberList = new DataObjectList();
          TopoHelper.putDboCollectionToList(fibers, fiberList, "FIBER");
          getRoomDAO().updateObjects(context, fiberList, null);
        }

      }

      DataObjectList opticals = new DataObjectList();

      for (int i = 0; i < fibersForOptical.size(); i++) {
        GenericDO fiber = (GenericDO)fibersForOptical.get(i);
        String opticalSql = "SELECT * FROM OPTICAL WHERE CUID IN (SELECT OPTICAL_CUID FROM OPTICAL_TO_FIBER WHERE FIBER_CUID= '" + fiber.getCuid() + "')";
        DboCollection tempOpticals = new DboCollection();
        tempOpticals = getRoomDAO().selectDBOs(opticalSql, new GenericDO[] { new Optical() });

        for (int j = 0; j < tempOpticals.size(); j++) {
          opticals.add(tempOpticals.getAttrField("OPTICAL", j));
        }
      }

      for (GenericDO optical : opticals) {
        String origSiteCuid = optical.getAttrString("ORIG_SITE_CUID");
        String destSiteCuid = optical.getAttrString("DEST_SITE_CUID");

        if (srcSiteCuid.equals(origSiteCuid)) {
          optical.setAttrValue("ORIG_SITE_CUID", desSiteCuid);
          optical.setAttrValue("ORIG_ROOM_CUID", desRoomCuid);
          optical.setAttrNull("ORIG_EQP_CUID");
          optical.setAttrNull("ORIG_POINT_CUID");
        }
        else if (srcSiteCuid.equals(destSiteCuid)) {
          optical.setAttrValue("DEST_SITE_CUID", desSiteCuid);
          optical.setAttrValue("DEST_ROOM_CUID", desRoomCuid);
          optical.setAttrNull("DEST_EQP_CUID");
          optical.setAttrNull("DEST_POINT_CUID");
        }
      }

      if (opticals.size() > 0) {
        getRoomDAO().updateObjects(context, opticals, null);
      }
      LogHome.getLog().info("调用接口------modifyRelatedSpaceByWireSeg------end");
      return wireSegs;
    }
    catch (Exception e)
    {
      LogHome.getLog().error("机房搬迁外线光缆段失败", e);
      throw new UserException("机房搬迁外线光缆段失败" + e.getMessage());
    }
  }

  public void syncModifySegs(DataObjectList segs)
    throws Exception
  {
    try
    {
      boolean flag = DMDataSynHelperX.needSysn();
      if ((flag) && 
        (segs != null) && (segs.size() > 0)) {
        DMDataSynHelperX.modifySeg(segs);
      }
    }
    catch (Exception e)
    {
      LogHome.getLog().error("机房搬迁外线资源同步图形库失败", e);
      throw new UserException("机房搬迁外线资源同步图形库失败" + e.getMessage());
    }
  }
}