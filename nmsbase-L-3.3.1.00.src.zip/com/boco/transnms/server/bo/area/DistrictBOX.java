package com.boco.transnms.server.bo.area;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.District;
import com.boco.transnms.common.dto.Room;
import com.boco.transnms.common.dto.Site;
import com.boco.transnms.common.dto.SwitchElement;
import com.boco.transnms.common.dto.TransElement;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.ibo.cm.IDistrictBOX;
import com.boco.transnms.server.bo.ibo.cm.IRoomBO;
import com.boco.transnms.server.bo.ibo.cm.ISiteBO;
import com.boco.transnms.server.dao.area.DistrictDAO;
import com.boco.transnms.server.dao.common.CommonDAO;
import java.util.HashMap;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="COMMON")
public class DistrictBOX extends AbstractBO
  implements IDistrictBOX
{
  private DistrictDAO getDistrictDAO()
  {
    return (DistrictDAO)super.getDAO("DistrictDAO");
  }

  protected IRoomBO getRoomBO() {
    return (IRoomBO)super.getBO("IRoomBO");
  }

  protected ISiteBO getSiteBO() {
    return (ISiteBO)super.getBO("ISiteBO");
  }

  public District getParentDistrict(BoActionContext actionContext, District district)
    throws UserException
  {
    try
    {
      return getDistrictDAO().getParentDistrict(actionContext, district);
    } catch (Exception ex) {
      LogHome.getLog().error("获取区域上级区域失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public Boolean isEquipOrderRight(BoActionContext actionContext, String aequipCuid, String zequipCuid)
    throws UserException
  {
    int rtn = getLeaderOrderPrivate(actionContext, aequipCuid, zequipCuid);
    if (rtn == 2) {
      return Boolean.valueOf(false);
    }
    return Boolean.valueOf(true);
  }

  public Integer isLeaderOrder(BoActionContext actionContext, String aequipCuid, String zequipCuid) throws UserException
  {
    return Integer.valueOf(getLeaderOrderPrivate(actionContext, aequipCuid, zequipCuid));
  }

  private int getLeaderOrderPrivate(BoActionContext actionContext, String aequipCuid, String zequipCuid) throws UserException {
    int rtn = 0;
    try {
      String aclassName = GenericDO.parseClassNameFromCuid(aequipCuid);
      String zclassName = GenericDO.parseClassNameFromCuid(zequipCuid);
      if (aclassName.equals(zclassName)) {
        District adistrict = null;
        District zdistrict = null;
        Site asite = null;
        Site zsite = null;
        Room aroom = null;
        Room zroom = null;
        TransElement aelement = null;
        TransElement zelement = null;
        SwitchElement aswitch = null;
        SwitchElement zswitch = null;
        if (aclassName.equals("DISTRICT")) {
          adistrict = getDistrictDAO().getDistrictByCuid(actionContext, aequipCuid);
          zdistrict = getDistrictDAO().getDistrictByCuid(actionContext, zequipCuid);
          rtn = Check2DistrictOrder(actionContext, adistrict, zdistrict).intValue();
        } else if (aclassName.equals("SITE")) {
          asite = (Site)getDistrictDAO().getObjByCuid(aequipCuid);
          zsite = (Site)getDistrictDAO().getObjByCuid(zequipCuid);
          adistrict = getDistrictOfSite(actionContext, asite);
          zdistrict = getDistrictOfSite(actionContext, zsite);
          rtn = CheckDistrictAndSite(actionContext, adistrict, zdistrict, asite, zsite, aswitch, zswitch);
        } else if (aclassName.equals("ROOM")) {
          aroom = getRoomBO().getRoomByCuid(actionContext, aequipCuid);
          zroom = getRoomBO().getRoomByCuid(actionContext, zequipCuid);
          asite = getSiteBO().getSiteOfRoom(actionContext, aroom);
          zsite = getSiteBO().getSiteOfRoom(actionContext, zroom);
          adistrict = getDistrictOfSite(actionContext, asite);
          zdistrict = getDistrictOfSite(actionContext, zsite);
          rtn = CheckDistrictAndSite(actionContext, adistrict, zdistrict, asite, zsite, aswitch, zswitch);
        } else if (aclassName.equals("TRANS_ELEMENT"))
        {
          aelement = (TransElement)getCommonDAO().getObjByCuid(aequipCuid);
          zelement = (TransElement)getCommonDAO().getObjByCuid(zequipCuid);
          adistrict = (District)getCommonDAO().getObjByCuid(aelement.getRelatedDistrictCuid());
          zdistrict = (District)getCommonDAO().getObjByCuid(zelement.getRelatedDistrictCuid());
          rtn = CheckDistrictAndSite(actionContext, adistrict, zdistrict, asite, zsite, aswitch, zswitch);
        } else if (aclassName.equals("SWITCH_ELEMENT"))
        {
          aswitch = (SwitchElement)getCommonDAO().getObjByCuid(aequipCuid);
          zswitch = (SwitchElement)getCommonDAO().getObjByCuid(zequipCuid);
          adistrict = (District)getCommonDAO().getObjByCuid(aswitch.getRelatedDistrictCuid());
          zdistrict = (District)getCommonDAO().getObjByCuid(zswitch.getRelatedDistrictCuid());
          rtn = CheckDistrictAndSite(actionContext, adistrict, zdistrict, asite, zsite, aswitch, zswitch);
        }
      }
    } catch (Exception ex) {
      LogHome.getLog().error("判断电路两端点优先级关系失败", ex);
    }
    return rtn;
  }

  protected Integer Check2DistrictOrder(BoActionContext actionContext, District aDis, District zDis) throws UserException {
    try {
      if ((aDis == null) || (aDis == null)) {
        return Integer.valueOf(0);
      }
      if (aDis.getObjectNum() == zDis.getObjectNum()) {
        return Integer.valueOf(0);
      }
      District aprovinceDis = null;
      District zprovinceDis = null;
      District acityDis = null;
      District zcityDis = null;
      District acountyDis = null;
      District zcountyDis = null;
      if (aDis.getDataType() == 4L) {
        acountyDis = aDis;
        acityDis = getParentDistrict(actionContext, acountyDis);
        aprovinceDis = getParentDistrict(actionContext, acityDis);
      }
      if (zDis.getDataType() == 4L) {
        zcountyDis = zDis;
        zcityDis = getParentDistrict(actionContext, zcountyDis);
        zprovinceDis = getParentDistrict(actionContext, zcityDis);
      }
      if (aDis.getDataType() == 3L) {
        acityDis = aDis;
        aprovinceDis = getParentDistrict(actionContext, acityDis);
      }
      if (zDis.getDataType() == 3L) {
        zcityDis = zDis;
        zprovinceDis = getParentDistrict(actionContext, zcityDis);
      }
      if (aDis.getDataType() == 2L) {
        aprovinceDis = aDis;
      }
      if (zDis.getDataType() == 2L) {
        zprovinceDis = zDis;
      }
      if ((aprovinceDis != null) && (zprovinceDis != null) && (aprovinceDis.getObjectNum() == zprovinceDis.getObjectNum())) {
        if ((acityDis != null) && (zcityDis != null)) {
          if (acityDis.getObjectNum() == zcityDis.getObjectNum()) {
            if ((acountyDis != null) && (zcountyDis != null)) {
              if (acountyDis.getObjectNum() == zcountyDis.getObjectNum()) {
                return Integer.valueOf(0);
              }
              if (acountyDis.getSeviceLeaderCode() > zcountyDis.getSeviceLeaderCode())
                return Integer.valueOf(1);
              if (acountyDis.getSeviceLeaderCode() == zcountyDis.getSeviceLeaderCode()) {
                return Integer.valueOf(0);
              }
              return Integer.valueOf(2);
            }

            return Integer.valueOf(0);
          }

          if (acityDis.getSeviceLeaderCode() > zcityDis.getSeviceLeaderCode())
            return Integer.valueOf(1);
          if (acityDis.getSeviceLeaderCode() == zcityDis.getSeviceLeaderCode()) {
            return Integer.valueOf(0);
          }
          return Integer.valueOf(2);
        }

        return Integer.valueOf(0);
      }
      if ((aprovinceDis != null) && (zprovinceDis != null)) {
        if (aprovinceDis.getSeviceLeaderCode() > zprovinceDis.getSeviceLeaderCode())
          return Integer.valueOf(1);
        if (aprovinceDis.getSeviceLeaderCode() == zprovinceDis.getSeviceLeaderCode()) {
          return Integer.valueOf(0);
        }
        return Integer.valueOf(2);
      }
      return Integer.valueOf(0);
    }
    catch (Exception ex)
    {
      LogHome.getLog().error("判断区域的业务领导局关系失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public District getDistrictOfSite(BoActionContext actionContext, Site site) throws UserException {
    try {
      return getDistrictDAO().getDistrictOfSite(actionContext, site);
    } catch (Exception ex) {
      LogHome.getLog().error("根据站点获取区域失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  private int CheckDistrictAndSite(BoActionContext actionContext, District adistrict, District zdistrict, Site asite, Site zsite, SwitchElement aSwitchElement, SwitchElement zSwitchElement)
    throws UserException
  {
    int rtn = 0;
    try {
      int retFlag = Check2DistrictOrder(actionContext, adistrict, zdistrict).intValue();
      if (retFlag == 0) {
        rtn = Check2SiteOrder(actionContext, asite, zsite).intValue();
        if (rtn == 0)
          rtn = check2SwitchElementOrder(aSwitchElement, zSwitchElement);
      }
    }
    catch (Exception ex) {
      LogHome.getLog().error("判断区域站点优先级失败", ex);
      throw new UserException(ex.getMessage());
    }
    return rtn;
  }

  protected CommonDAO getCommonDAO() {
    return (CommonDAO)super.getDAO("CommonDAO");
  }

  private int check2SwitchElementOrder(SwitchElement aSwitchElement, SwitchElement zSwitchElement) throws UserException {
    int rtn = 0;
    try {
      BoActionContext actionContext = new BoActionContext();
      if ((aSwitchElement != null) && (zSwitchElement != null)) {
        if (aSwitchElement.getCuid().equals(zSwitchElement.getCuid())) {
          return 0;
        }
        if (aSwitchElement.getKind() != zSwitchElement.getKind())
        {
          DataObjectList dbos = getCommonDAO().getAllSwitchCfgTypeInfo();
          HashMap hashMap = new HashMap();
          if (dbos != null) {
            for (int i = 0; i < dbos.size(); i++) {
              GenericDO gdo = (GenericDO)dbos.get(i);

              if (aSwitchElement.getKind() == gdo.getAttrLong("3")) {
                return 1;
              }
              if (zSwitchElement.getKind() == gdo.getAttrLong("3")) {
                return 2;
              }
            }
          }
        }
        if (aSwitchElement.getLeaderCode() < zSwitchElement.getLeaderCode())
          return 1;
        if (aSwitchElement.getLeaderCode() > zSwitchElement.getLeaderCode())
          return 2;
      }
    }
    catch (Exception ex)
    {
      LogHome.getLog().info(ex.getMessage());
    }
    return rtn;
  }

  private Integer Check2SiteOrder(BoActionContext actionContext, Site asite, Site zsite) throws UserException {
    try {
      if ((asite == null) || (zsite == null)) {
        return Integer.valueOf(0);
      }
      if (asite.getObjectNum() == zsite.getObjectNum()) {
        return Integer.valueOf(0);
      }
      if (asite.getServiceLevel() < zsite.getServiceLevel())
        return Integer.valueOf(1);
      if (asite.getServiceLevel() > zsite.getServiceLevel()) {
        return Integer.valueOf(2);
      }
      String[] asitetype = asite.getSiteType().split(",");
      String[] zsitetype = zsite.getSiteType().split(",");
      Integer atype = Integer.valueOf(-1);
      Integer ztype = Integer.valueOf(-1);
      for (int i = 0; i < asitetype.length; i++) {
        atype = Integer.valueOf(asitetype[i]);
        for (int j = 0; j < zsitetype.length; j++) {
          ztype = Integer.valueOf(zsitetype[j]);
          if (atype.intValue() < ztype.intValue())
            return Integer.valueOf(1);
          if (atype.intValue() > ztype.intValue()) {
            return Integer.valueOf(2);
          }
        }
      }
      return Integer.valueOf(0);
    }
    catch (Exception ex) {
      LogHome.getLog().error("判断站点的业务领导局关系失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getAllTreePointDistrict(BoActionContext actionContext) throws UserException {
    try {
      return getDistrictDAO().getAllTreePointDistrict();
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }
}