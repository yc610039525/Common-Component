package com.boco.transnms.server.bo.area;

import com.boco.common.util.db.TransactionFactory;
import com.boco.common.util.db.UserTransaction;
import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.core.utils.encoding.GetCh2Spell;
import com.boco.transnms.common.dto.Accesspoint;
import com.boco.transnms.common.dto.District;
import com.boco.transnms.common.dto.FiberCab;
import com.boco.transnms.common.dto.Room;
import com.boco.transnms.common.dto.Site;
import com.boco.transnms.common.dto.SwitchElement;
import com.boco.transnms.common.dto.TLogicNumberRange;
import com.boco.transnms.common.dto.TransElement;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.bo.base.BoHomeFactory;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.ibo.cm.IDistrictBO;
import com.boco.transnms.server.bo.ibo.cm.IObjectOperateLogBO;
import com.boco.transnms.server.bo.ibo.cm.IRoomBO;
import com.boco.transnms.server.bo.ibo.cm.ISiteBO;
import com.boco.transnms.server.bo.ibo.misc.ISecurityBO;
import com.boco.transnms.server.dao.area.DistrictDAO;
import com.boco.transnms.server.dao.base.DaoHelper;
import com.boco.transnms.server.dao.common.CommonDAO;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="COMMON", initByAllServer=true)
public class DistrictBO extends DistrictBOX
  implements IDistrictBO
{
  public DataObjectList getLevelDistrict(BoActionContext actionContext, String districtCuid)
    throws UserException
  {
    try
    {
      return getDistrictDAO().getProvinceDistrict(districtCuid);
    } catch (Throwable ex) {
      LogHome.getLog().info("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public List<String> getBelongDistrictCuidByEquipCuid(BoActionContext actionContext, List<String> equipCuids) throws UserException {
    List result = new ArrayList();
    if (equipCuids == null)
      return null;
    try {
      for (int i = 0; i < equipCuids.size(); i++) {
        String districtCuid = "";
        String equipCuid = (String)equipCuids.get(i);
        districtCuid = getBelongDistrictCuidByEquipCuid(actionContext, equipCuid);
        result.add(districtCuid);
      }
      return result;
    } catch (Exception ex) {
      LogHome.getLog().info("取设备所属区域cuid失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getDeviceVendor(BoActionContext actionContext)
  {
    try
    {
      return getDistrictDAO().getDeviceVendor(actionContext);
    } catch (Throwable ex) {
      LogHome.getLog().info("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void modifyLevelDistrict(BoActionContext actionContext, String[] districtObjectIds) throws UserException {
    try {
      getDistrictDAO().modifyLevelDistrict(actionContext, districtObjectIds);
      getSecurityBO().initUserDistrictRoles();
    } catch (Throwable ex) {
      LogHome.getLog().info("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public District addDistrict(BoActionContext actionContext, District dbo) throws UserException {
    try {
      if (!getDistrictDAO().isRepeatName(dbo.getLabelCn()))
      {
        District parentDistrict = getDistrictByCuid(actionContext, dbo.getRelatedSpaceCuid());

        String code = String.valueOf(parentDistrict.getDistrictChildNum() + 1L);
        String newCuid = parentDistrict.getCuid() + "-" + "00000".substring(0, 5 - code.trim().length()) + code;
        dbo.setCuid(newCuid);
        dbo.setDistrictChildNum(0L);
        if ((dbo.getSpellabbreviation() == null) || (dbo.getSpellabbreviation().trim().length() == 0)) {
          dbo.setSpellabbreviation(GetCh2Spell.getBeginCharacter(dbo.getLabelCn()));
        }

        parentDistrict.setDistrictChildNum(parentDistrict.getDistrictChildNum() + 1L);

        UserTransaction trx = TransactionFactory.getInstance().createTransaction();
        District newdbo = null;
        try {
          trx.begin();
          newdbo = getDistrictDAO().addDistrict(actionContext, dbo);
          getDistrictDAO().modifyDistrict(actionContext, parentDistrict);

          BoActionContext boactioncontext = new BoActionContext();
          boactioncontext.setUserId(actionContext.getUserId());
          boactioncontext.setHostIP(actionContext.getHostIP());
          IObjectOperateLogBO ibo = (IObjectOperateLogBO)BoHomeFactory.getInstance().getBO("IObjectOperateLogBO");
          ibo.addObjOperateLog(boactioncontext, 1L, 1L, dbo, dbo);
          trx.commit();
        } catch (Exception ex) {
          trx.rollback();
          throw new Exception(ex.getMessage());
        }

        getSecurityBO().initUserDistrictRoles();
        return newdbo;
      }
      throw new UserException("已经存在重名的区域!");
    }
    catch (Throwable ex) {
      LogHome.getLog().info("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void importExcelDistricts(BoActionContext actionContext, DataObjectList dbos) throws UserException {
    try {
      UserTransaction trx = TransactionFactory.getInstance().createTransaction();
      trx.begin();
      try {
        for (int i = 0; i < dbos.size(); i++) {
          District dbo = (District)dbos.get(i);
          if (!getDistrictDAO().isRepeatName(dbo.getLabelCn()))
          {
            String parentDistrictCuid = dbo.getRelatedSpaceCuid();
            District parentDistrict = null;
            if (parentDistrictCuid.indexOf("DISTRICT-") == 0)
              parentDistrict = getDistrictDAO().getDistrict(parentDistrictCuid);
            else {
              parentDistrict = getDistrictDAO().getDistrictByLabelCn(dbo.getRelatedSpaceCuid());
            }

            String code = String.valueOf(parentDistrict.getDistrictChildNum() + 1L);
            String newCuid = parentDistrict.getCuid() + "-" + "00000".substring(0, 5 - code.trim().length()) + code;
            dbo.setCuid(newCuid);
            dbo.setDistrictChildNum(0L);
            dbo.setRelatedSpaceCuid(parentDistrict.getCuid());
            if ((dbo.getSpellabbreviation() == null) || (dbo.getSpellabbreviation().trim().length() == 0)) {
              dbo.setSpellabbreviation(GetCh2Spell.getBeginCharacter(dbo.getLabelCn()));
            }

            parentDistrict.setDistrictChildNum(parentDistrict.getDistrictChildNum() + 1L);
            District newdbo = getDistrictDAO().addDistrict(actionContext, dbo);
            getDistrictDAO().modifyDistrict(actionContext, parentDistrict);
          }
          else
          {
            throw new UserException("已经存在重名的区域!");
          }
        }

        getSecurityBO().initUserDistrictRoles();
        trx.commit();
      } catch (Exception ex) {
        LogHome.getLog().error("导入区域报错", ex);
        trx.rollback();
        throw new Exception(ex.getMessage());
      }
    } catch (Throwable ex) {
      LogHome.getLog().info("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public District getDistrict(BoActionContext actionContext, String cuid) throws UserException {
    try {
      return getDistrictDAO().getDistrict(cuid);
    } catch (Throwable ex) {
      LogHome.getLog().info("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void deleteDistrict(BoActionContext actionContext, String cuid) throws UserException
  {
    UserTransaction trx = TransactionFactory.getInstance().createTransaction();
    try {
      trx.begin();
      District district = getDistrict(actionContext, cuid);
      getDistrictDAO().delDistrict(actionContext, cuid);

      BoActionContext boactioncontext = new BoActionContext();
      boactioncontext.setHostIP(actionContext.getHostIP());
      boactioncontext.setUserId(actionContext.getUserId());
      IObjectOperateLogBO ibo = (IObjectOperateLogBO)BoHomeFactory.getInstance().getBO("IObjectOperateLogBO");
      ibo.addObjOperateLog(boactioncontext, 3L, 1L, district, district);

      getSecurityBO().initUserDistrictRoles();
      trx.commit();
    } catch (Throwable ex) {
      trx.rollback();
      LogHome.getLog().info("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void modifyDistrict(BoActionContext actionContext, District dbo) throws UserException
  {
    try {
      String oldcuid = getDistrictDAO().getCuidByLabelCn(actionContext, dbo.getLabelCn());
      District olddbo = getDistrict(actionContext, dbo.getCuid());

      if ((oldcuid == "") || (oldcuid.equals(dbo.getCuid()))) {
        if ((dbo.getSpellabbreviation() == null) || (dbo.getSpellabbreviation().trim().length() == 0)) {
          dbo.setSpellabbreviation(GetCh2Spell.getBeginCharacter(dbo.getLabelCn()));
        }
        if ((dbo.getDataType() == 2L) && (!dbo.getLabelCn().equals(olddbo.getLabelCn()))) {
          throw new UserException("省级区域不允许修改区域名称！");
        }
        getDistrictDAO().modifyDistrict(actionContext, dbo);
        getSecurityBO().initUserDistrictRoles();

        BoActionContext boactioncontext = new BoActionContext();
        boactioncontext.setUserId(actionContext.getUserId());
        boactioncontext.setHostIP(actionContext.getHostIP());
        IObjectOperateLogBO ibo = (IObjectOperateLogBO)BoHomeFactory.getInstance().getBO("IObjectOperateLogBO");
        ibo.addObjOperateLog(boactioncontext, 2L, 1L, olddbo, dbo);
      }
      else
      {
        throw new UserException("已经存在重名的区域!");
      }
    } catch (Throwable ex) {
      LogHome.getLog().info("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public District getDistrictByCuid(BoActionContext actionContext, String districtCuid) throws UserException {
    try {
      return getDistrictDAO().getDistrictByCuid(actionContext, districtCuid);
    } catch (Exception ex) {
      LogHome.getLog().info("根据cuid获取区域失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public String getNameByEquipCuid(BoActionContext actionContext, String equipCuid) throws UserException
  {
    String labelCn = null;
    try {
      String tableName = GenericDO.parseClassNameFromCuid(equipCuid);
      if ((DaoHelper.isNotEmpty(tableName)) && (DaoHelper.isNotEmpty(equipCuid))) {
        GenericDO dbo = getDistrictDAO().getObjByCuid(equipCuid);
        if (dbo != null) {
          Object obj = dbo.getAttrValue("LABEL_CN");
          if (obj != null)
            labelCn = obj.toString();
        }
      }
    }
    catch (Exception ex) {
      LogHome.getLog().info("根据cuid获取多种设备名称失败", ex);
      throw new UserException(ex.getMessage());
    }
    return labelCn;
  }

  public DataObjectList getAllChildDistrict(BoActionContext actionContext, District district) throws UserException {
    try {
      return getDistrictDAO().getAllChildDistrict(actionContext, district);
    } catch (Exception ex) {
      LogHome.getLog().info("获取区域下级区域列表失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getAllChildDistrictTranslate(BoActionContext actionContext, District district) throws UserException {
    try {
      DataObjectList doList = getDistrictDAO().getAllChildDistrict(actionContext, district);
      for (GenericDO ddo : doList) {
        ddo.setObjectLoadType(1);
      }

      return doList;
    } catch (Exception ex) {
      LogHome.getLog().info("获取区域下级区域列表失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getChildDistricts(BoActionContext actionContext, District district) throws UserException {
    try {
      DataObjectList doList = getDistrictDAO().getChildDistricts(actionContext, district);

      for (GenericDO ddo : doList) {
        ddo.setObjectLoadType(1);
      }
      return doList;
    } catch (Exception ex) {
      LogHome.getLog().info("获取区域下级区域列表失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public Integer is2DistrictOrder(BoActionContext actionContext, District aDis, District zDis) throws UserException { return Check2DistrictOrder(actionContext, aDis, zDis); }

  public District getEquipDistrictByCuid(BoActionContext actionContext, String cuid) throws UserException
  {
    District rtn = null;
    try {
      LogHome.getLog().info("转换前的CUID值为:|" + cuid + "|");
      String aclassName = GenericDO.parseClassNameFromCuid(cuid);
      LogHome.getLog().info("转换后的类名为:|" + aclassName + "|");
      if (null == aclassName)
      {
        aclassName = "";
      }
      if (aclassName.equals("DISTRICT")) {
        rtn = getDistrictDAO().getDistrictByCuid(actionContext, cuid);
      } else if (aclassName.equals("SITE")) {
        Site asite = (Site)getDistrictDAO().getObjByCuid(cuid);
        if (null != asite)
        {
          rtn = getDistrictOfSite(actionContext, asite);
        }
      } else if (aclassName.equals("ROOM")) {
        Room aroom = getRoomBO().getRoomByCuid(actionContext, cuid);
        if (null != aroom)
        {
          Site asite = (Site)getDistrictDAO().getObjByCuid(aroom.getRelatedSiteCuid());
          if (null != asite)
          {
            rtn = (District)getCommonDAO().getObjByCuid(asite.getRelatedSpaceCuid());
          }
        }
      } else if (aclassName.equals("TRANS_ELEMENT"))
      {
        TransElement aelement = (TransElement)getCommonDAO().getObjByCuid(cuid);
        if (null != aelement)
        {
          rtn = (District)getCommonDAO().getObjByCuid(aelement.getRelatedDistrictCuid());
        }
      } else if (aclassName.equals("SWITCH_ELEMENT"))
      {
        SwitchElement aswitch = (SwitchElement)getCommonDAO().getObjByCuid(cuid);
        if (null != aswitch)
        {
          rtn = (District)getCommonDAO().getObjByCuid(aswitch.getRelatedDistrictCuid());
        }
      } else if (aclassName.equals("FIBER_CAB")) {
        FiberCab aFiberCab = (FiberCab)getCommonDAO().getObjByCuid(cuid);
        if (null != aFiberCab)
        {
          rtn = (District)getCommonDAO().getObjByCuid(aFiberCab.getRelatedDistrictCuid());
        }
      } else if (aclassName.equals("ACCESSPOINT")) {
        Accesspoint aAccesspoint = (Accesspoint)getCommonDAO().getObjByCuid(cuid);
        if (null != aAccesspoint)
        {
          rtn = (District)getCommonDAO().getObjByCuid(aAccesspoint.getDistrictCuid());
        }
      }
    }
    catch (Exception ex) {
      LogHome.getLog().info("获取设备所属区域失败", ex);
      throw new UserException(ex);
    }
    return rtn;
  }

  public ISecurityBO getSecurityBO()
  {
    return (ISecurityBO)super.getBO("ISecurityBO");
  }

  public DataObjectList getChildSite(BoActionContext actionContext, String districtCuids) throws UserException {
    try {
      return getDistrictDAO().getChildSite(districtCuids);
    } catch (Throwable ex) {
      LogHome.getLog().info("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public String getCuidByLabelCn(BoActionContext actionContext, String labelCn) throws UserException {
    try {
      return getDistrictDAO().getCuidByLabelCn(actionContext, labelCn);
    } catch (Throwable ex) {
      LogHome.getLog().info("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public String getBelongDistrictCuidByEquipCuid(BoActionContext actionContext, String equipCuid) throws UserException {
    try {
      String districtCuid = "";
      if (DaoHelper.isNotEmpty(equipCuid)) {
        String tablename = GenericDO.parseClassNameFromCuid(equipCuid);
        if (DaoHelper.isNotEmpty(tablename))
          if (tablename.equals("DISTRICT"))
            districtCuid = equipCuid;
          else if (tablename.equals("SITE"))
            districtCuid = getSiteDistrictCuid(actionContext, equipCuid);
          else if (tablename.equals("ROOM"))
            districtCuid = getRoomDistrictCuid(actionContext, equipCuid);
          else if (tablename.equals("TRANS_ELEMENT"))
            districtCuid = getTransElementDistrictCuid(actionContext, equipCuid); else if (!tablename.equals("SWITCH_ELEMENT"));
      }
      return getSwitchElementDistrictCuid(actionContext, equipCuid);
    }
    catch (Exception ex)
    {
      LogHome.getLog().info("取设备所属区域cuid失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public String getSiteDistrictCuid(BoActionContext actionContext, String siteCuid) throws UserException {
    try {
      Site site = (Site)getDistrictDAO().getObjByCuid(siteCuid);
      if (site != null) {
        return site.getRelatedSpaceCuid();
      }
      return "";
    } catch (Exception ex) {
      LogHome.getLog().info("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  private String getRoomDistrictCuid(BoActionContext actionContext, String roomCuid) throws UserException {
    try {
      Room room = getRoomBO().getRoomByCuid(actionContext, roomCuid);
      Site site = getSiteBO().getSiteOfRoom(actionContext, room);
      if (site != null) {
        return site.getRelatedSpaceCuid();
      }
      return "";
    } catch (Exception ex) {
      LogHome.getLog().info("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  private String getTransElementDistrictCuid(BoActionContext actionContext, String transelementCuid) throws UserException {
    try {
      TransElement element = (TransElement)getCommonDAO().getObjByCuid(transelementCuid);
      if (element != null) {
        return element.getRelatedDistrictCuid();
      }
      return "";
    } catch (Exception ex) {
      LogHome.getLog().info("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  private String getSwitchElementDistrictCuid(BoActionContext actionContext, String switchelementCuid) throws UserException {
    try {
      SwitchElement element = (SwitchElement)getCommonDAO().getObjByCuid(switchelementCuid);
      if (element != null) {
        return element.getRelatedDistrictCuid();
      }
      return "";
    } catch (Exception ex) {
      LogHome.getLog().info("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public boolean isHaveRelatedObj(String className, GenericDO deleteObj)
    throws UserException
  {
    try
    {
      District district = (District)deleteObj;
      BoActionContext actionContext = new BoActionContext();

      if (deleteObj.getClassName().equals("DISTRICT")) {
        DataObjectList subs = getDistrictDAO().getAllChildDistrict(actionContext, district);
        if ((subs != null) && (subs.size() > 0)) {
          return true;
        }
        return false;
      }

      return false;
    } catch (Exception ex) {
      throw new UserException(ex.getMessage());
    }
  }

  public int getRelatedDeleteObjCount(String className, GenericDO deleteObj) throws UserException {
    return Integer.getInteger("0").intValue();
  }

  public DataObjectList getRelatedDeleteObjects(String className, GenericDO deleteObj) throws UserException {
    return null;
  }

  public void deleteReletedOfObject(String className, GenericDO deleteObj)
    throws UserException
  {
  }

  public void modifyDisDisplayCfg(BoActionContext actionContext, DataObjectList districtList)
    throws Exception
  {
    try
    {
      for (GenericDO dto : districtList) {
        if (!(dto instanceof District)) {
          throw new IllegalArgumentException(dto.getCuid() + "不是区域对象！");
        }
        District district = (District)dto;
        getDistrictDAO().modifyDistrict(actionContext, district);
      }
    } catch (Exception ex) {
      LogHome.getLog().info("修改地区对象出错" + ex.getMessage());
      throw new UserException("修改地区对象出错");
    }
  }

  public DataObjectList getAllDisDisplayCfg(BoActionContext actionContext)
    throws Exception
  {
    try
    {
      return getDistrictDAO().getAllTreePointDistrict();
    } catch (Throwable ex) {
      LogHome.getLog().info("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getAllDistrictCuidAndLabelCn(BoActionContext actionContext) throws UserException {
    try {
      return getDistrictDAO().getAllDistrictCuidAndLabelCn();
    } catch (Exception ex) {
      LogHome.getLog().info("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public String getDistrictCons(String districtCon) throws UserException {
    String districtCons = "";
    try {
      if ((districtCon != null) && (!districtCon.trim().equals(""))) {
        String[] districts = districtCon.split(",");
        HashMap mDistrict = new HashMap();

        for (int i = 0; i < districts.length; i++) {
          District district = getDistrictByCuid(new BoActionContext(), districts[i]);

          if (district == null)
            LogHome.getLog().info("根据区域CUID获取不到区域对象，由于OMP或者GOAT原因引起或者该区域数据已经不存在，所以不往外抛异常，CUID：" + districts[i]);
          else {
            mDistrict.put(district.getCuid(), district.getCuid());
          }

          getAllDistrictByDisCuid(district, mDistrict);
        }

        Iterator itDistrict = mDistrict.keySet().iterator();

        while (itDistrict.hasNext()) {
          String keyVal = (String)itDistrict.next();
          districtCons = districtCons + "'" + keyVal + "',";
        }
      }
    } catch (Throwable ex) {
      LogHome.getLog().info("根据区域获聚合查询条件出错:" + ex.getMessage());
      throw new UserException(ex);
    }

    return districtCons;
  }

  public void getAllDistrictByDisCuid(District district, HashMap mDistrict) throws UserException
  {
    try {
      if ((district != null) && (mDistrict != null) && 
        (district != null)) {
        DataObjectList disObjs = getAllChildDistrict(new BoActionContext(), district);
        for (int i = 0; i < disObjs.size(); i++) {
          District tmpDistrict = (District)disObjs.get(i);

          if (tmpDistrict != null) {
            mDistrict.put(tmpDistrict.getCuid(), tmpDistrict.getCuid());
            getAllDistrictByDisCuid(tmpDistrict, mDistrict);
          }
        }
      }
    }
    catch (Throwable ex) {
      LogHome.getLog().info("根据区域获取下边所有字区域出错:" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  private DistrictDAO getDistrictDAO() {
    return (DistrictDAO)super.getDAO("DistrictDAO");
  }

  public DataObjectList getDistrictBySql(BoActionContext actionContext, String sql) throws UserException
  {
    try {
      return getDistrictDAO().getObjectsBySql(sql, new District(), 0);
    } catch (Exception e) {
      throw new UserException("查询区域失败，" + e.getMessage());
    }
  }

  public DboCollection getDistrictAndChildren(BoActionContext actionContext, String cuid) throws UserException
  {
    try {
      String sql = "SELECT * FROM DISTRICT WHERE CUID LIKE '" + cuid + "%'";
      return getDistrictDAO().selectDBOs(sql, new GenericDO[] { new District() });
    }
    catch (Exception e) {
      LogHome.getLog().info("根据站点得到子站点出错", e);
    }
    return null;
  }

  public boolean addCacheObjectForCM(BoActionContext actionContext, GenericDO dbo)
    throws UserException
  {
    try
    {
      return getDistrictDAO().addCacheObjectForCM(dbo);
    } catch (Exception ex) {
      LogHome.getLog().info(ex);
    }
    return false;
  }

  public boolean updateCacheObjectForCM(BoActionContext actionContext, GenericDO dbo)
    throws UserException
  {
    try
    {
      return getDistrictDAO().updateCacheObjectForCM(dbo);
    } catch (Exception ex) {
      LogHome.getLog().info(ex);
    }
    return false;
  }

  public boolean deleteCacheObjectForCM(BoActionContext actionContext, GenericDO dbo)
    throws UserException
  {
    try
    {
      return getDistrictDAO().deleteCacheObjectForCM(dbo);
    } catch (Exception ex) {
      LogHome.getLog().info(ex);
    }
    return false;
  }

  public GenericDO getObjByCuid(BoActionContext actionContext, String cuid)
    throws UserException
  {
    try
    {
      GenericDO dto = new GenericDO();
      dto.setCuid(cuid);
      return getDistrictDAO().getObjByCuid(actionContext, dto);
    } catch (Exception ex) {
      LogHome.getLog().info(ex);
    }
    return null;
  }

  public GenericDO getSpaceObjectByCuid(BoActionContext actionContext, String cuid)
    throws UserException
  {
    String sql = "";
    DataObjectList dataList = null;
    try {
      if (cuid.indexOf("DISTRICT") >= 0) {
        sql = "CUID='" + cuid + "'";
        dataList = getDistrictDAO().getObjectsBySql(sql, new District(), 0);
      } else if (cuid.indexOf("SITE") >= 0) {
        sql = "CUID='" + cuid + "'";
        dataList = getDistrictDAO().getObjectsBySql(sql, new Site(), 0);
      } else if (cuid.indexOf("ROOM") >= 0) {
        sql = "CUID='" + cuid + "'";
        dataList = getDistrictDAO().getObjectsBySql(sql, new Room(), 0);
      }
      if ((dataList != null) && (dataList.size() > 0))
        return (GenericDO)dataList.get(0);
    }
    catch (Exception e) {
      LogHome.getLog().info(e);
    }
    return null;
  }

  public DataObjectList getNetIp() throws Exception {
    DataObjectList dbos = getDistrictDAO().getNetIp();
    return dbos;
  }
  public TLogicNumberRange addTLogicNumberRange(BoActionContext actionContext, TLogicNumberRange dbo) throws Exception {
    TLogicNumberRange dto = new TLogicNumberRange();
    try {
      dto = getDistrictDAO().addTLogicNumberRange(actionContext, dbo);
    } catch (Exception e) {
      LogHome.getLog().info("增加IP资源管理信息异常！");
      throw new UserException("增加IP资源管理信息异常！");
    }
    return dto;
  }
  public void delTLogicNumberRange(BoActionContext actionContext, String districtCuid) throws Exception {
    try {
      getDistrictDAO().delTLogicNumberRange(actionContext, districtCuid);
    } catch (Exception e) {
      LogHome.getLog().info("根据区域cuid删除IP资源管理信息异常！");
      throw new UserException("根据区域cuid删除IP异常！");
    }
  }

  public DboCollection getTLogicNumberRange(String districtCuid) throws Exception { DboCollection dbos = new DboCollection();
    try {
      dbos = getDistrictDAO().getTLogicNumberRange(districtCuid);
    } catch (Exception e) {
      LogHome.getLog().info("根据区域cuid查询IP资源管理信息异常！");
      throw new UserException("根据区域cuid查询IP资源管理信息异常！");
    }
    return dbos; }

  public void modifyTLogicNumberRange(BoActionContext actionContext, TLogicNumberRange dbo) throws Exception {
    try {
      getDistrictDAO().modifyTLogicNumberRange(actionContext, dbo);
    } catch (Exception e) {
      LogHome.getLog().info("修改IP资源管理信息异常！");
      throw new UserException("修改IP资源管理信息异常！");
    }
  }
}