package com.boco.transnms.server.bo.nmc;

import com.boco.common.util.debug.LogHome;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.misc.LayerRate;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.base.StateLessBoField;
import com.boco.transnms.server.bo.ibo.nmc.IEMBO;
import com.boco.transnms.server.dao.common.CommonDAO;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="AM_RTU")
public class EMBO extends AbstractBO
  implements IEMBO
{

  @StateLessBoField
  public static final String EMS_DISCONNECT = "EMS连接中断";

  @StateLessBoField
  public static final String ALLEMS_DISCONNECT = "主备EMS连接同时中断";

  @StateLessBoField
  private static HashMap<String, LayerRate> layerKeyMap = new HashMap();

  @StateLessBoField
  private static HashMap<String, LayerRate> layerValueMap = new HashMap();

  public EMBO()
  {
    super("EMBO");
  }

  public void initBO() throws Exception {
    initLayerRateMap();
  }

  private void initLayerRateMap() {
    layerKeyMap.clear();
    layerValueMap.clear();
    String sql = "select * from LAYER_RATE";
    try
    {
      DboCollection collection = getCommonDAO().selectDBOs(sql, new GenericDO[] { new LayerRate() });

      if ((collection != null) && (collection.size() > 0))
        for (int i = 0; i < collection.size(); i++) {
          LayerRate layer = (LayerRate)collection.getAttrField("LAYER_RATE", i);
          layerKeyMap.put("" + layer.getEnumValue(), layer);
          layerValueMap.put(layer.getEnumName(), layer);
        }
    }
    catch (Exception e) {
      LogHome.getLog().error("", e);
    }
  }

  private CommonDAO getCommonDAO() {
    return (CommonDAO)super.getDAO(CommonDAO.class);
  }

  public LayerRate getLayerRateByKey(String layerRateNum)
  {
    return (LayerRate)layerKeyMap.get(layerRateNum);
  }

  public LayerRate getLayerRateByValue(String layerRateName)
  {
    return (LayerRate)layerValueMap.get(layerRateName);
  }

  public Integer getSegType(BoActionContext actionContext, Short layerRate)
  {
    return new Integer(getSegType(layerRate.shortValue()));
  }

  public int getSegType(short layerRate)
  {
    LayerRate objRate = (LayerRate)layerKeyMap.get(layerRate + "");
    if (objRate != null) {
      return objRate.getLayerNum().intValue();
    }
    return 0;
  }

  public Integer getLayerRate(Integer portrate, Integer layer)
  {
    Iterator key = layerKeyMap.values().iterator();
    LayerRate objRate = null;
    if ((layer.intValue() == 1) || (layer.intValue() == 4) || (layer.intValue() == 5) || (layer.intValue() == 6) || (layer.intValue() == 7));
    while (key.hasNext()) {
      LayerRate tmpobjRate = (LayerRate)key.next();
      if (tmpobjRate.getLayerNum().intValue() == layer.intValue()) {
        objRate = tmpobjRate;
      }
      else {
        continue;

        while (key.hasNext()) {
          LayerRate tmpobjRate = (LayerRate)key.next();
          if ((tmpobjRate.getLayerNum().intValue() == layer.intValue()) && (tmpobjRate.getRateNum().intValue() == portrate.intValue())) {
            objRate = tmpobjRate;
            break;
          }
        }
      }
    }
    if (objRate != null) {
      return Integer.valueOf(objRate.getLayerRateNum().intValue());
    }
    return Integer.valueOf(0);
  }
}