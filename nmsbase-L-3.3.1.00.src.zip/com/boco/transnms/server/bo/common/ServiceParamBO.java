package com.boco.transnms.server.bo.common;

import com.boco.common.util.except.UserException;
import com.boco.transnms.client.model.base.BoServerUrlManager;
import com.boco.transnms.common.dto.ServiceParam;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.ibo.common.IServiceParamBO;
import com.boco.transnms.server.common.cfg.SystemEnv;
import com.boco.transnms.server.common.cfg.TransNmsCfg;
import com.boco.transnms.server.dao.common.ServiceParamDAO;
import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class ServiceParamBO extends AbstractBO
  implements IServiceParamBO
{
  public void initBO()
    throws Exception
  {
    try
    {
      if (!TransNmsCfg.getInstance().isDevelopmentMode())
      {
        DataObjectList servers = getServiceParamDAO().getServiceParamsBySql(new BoActionContext(), new Long(1L).longValue(), null);
        Map serverUrls = new HashMap();
        Map serverProxyUrls = new HashMap();
        for (int i = 0; i < servers.size(); i++) {
          ServiceParam dbo = (ServiceParam)servers.get(i);
          serverUrls.put(dbo.getServerName(), dbo.getServiceUrl());
          serverProxyUrls.put(dbo.getServerName(), dbo.getServiceProxyUrl());
        }
        BoServerUrlManager.getInstance().setServerUrls(serverUrls);
        BoServerUrlManager.getInstance().setServerProxyUrls(serverProxyUrls);
      } else {
        Properties properties = new Properties();
        String serverHome = SystemEnv.getPathEnv("TNMS_SERVER_HOME");
        String filePath = serverHome + File.separatorChar + "tnms-conf/" + "tnmscfg.properties";
        properties.load(new FileInputStream(new File(filePath)));
        HashMap serverUrls = new HashMap();
        HashMap serverProxyUrls = new HashMap();
        Iterator iterator = properties.keySet().iterator();
        while (iterator.hasNext()) {
          String key = (String)iterator.next();
          String value = (String)properties.get(key);
          if (key.contains("BoServerUrlManager.serverUrls.")) {
            String serviceName = key.replace("BoServerUrlManager.serverUrls.", "");
            serverUrls.put(serviceName, value);
          } else if (key.contains("BoServerUrlManager.serverProxyUrls.")) {
            String serviceName = key.replace("BoServerUrlManager.serverProxyUrls.", "");
            serverProxyUrls.put(serviceName, value);
          }
        }
        BoServerUrlManager.getInstance().setServerUrls(serverUrls);
        BoServerUrlManager.getInstance().setServerProxyUrls(serverProxyUrls);
      }

    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
  }

  public DataObjectList getServiceParamsByType(BoActionContext actionContext, Long serviceType) throws UserException {
    DataObjectList boServices = new DataObjectList();
    try {
      boServices = getServiceParamDAO().getServiceParamsBySql(new BoActionContext(), serviceType.longValue(), null);
    } catch (Exception ex) {
      ex.printStackTrace();
    }
    return boServices;
  }

  public ServiceParam getServiceParamByTypeAndName(BoActionContext actionContext, Long serviceType, String serverName) throws UserException {
    ServiceParam param = null;
    try {
      DataObjectList boServices = new DataObjectList();
      boServices = getServiceParamDAO().getServiceParamsBySql(new BoActionContext(), serviceType.longValue(), serverName);
      if (boServices.size() > 0)
        param = (ServiceParam)boServices.get(0);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    return param;
  }

  private ServiceParamDAO getServiceParamDAO() {
    return (ServiceParamDAO)super.getDAO("ServiceParamDAO");
  }
}