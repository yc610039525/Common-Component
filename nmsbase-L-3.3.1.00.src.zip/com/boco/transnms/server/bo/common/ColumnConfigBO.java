package com.boco.transnms.server.bo.common;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.bo.base.GenericBO;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.ibo.common.IColumnConfigBO;
import com.boco.transnms.server.common.cfg.TnmsRuntime;
import com.boco.transnms.server.dao.common.ColumnConfigDAO;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="CM")
public class ColumnConfigBO extends GenericBO
  implements IColumnConfigBO
{
  public void addColumnConfig(BoActionContext actionContext, String userCuid, String objectType, DataObjectList columnConfigList)
    throws UserException
  {
    ColumnConfigDAO columnConfigDao = getColumnConfigDAO();
    try {
      columnConfigDao.deleteColumnConfigByUser(actionContext, userCuid, objectType);
      columnConfigDao.createObjects(actionContext, columnConfigList);
    } catch (Exception ex) {
      LogHome.getLog().error("增加列配置异常", ex);
      throw new UserException("增加列配置异常", ex);
    }
  }

  public void deleteColumnConfig(BoActionContext actionContext, String userCuid, String objectType) throws UserException {
    ColumnConfigDAO columnConfigDao = getColumnConfigDAO();
    try {
      columnConfigDao.deleteColumnConfigByUser(actionContext, userCuid, objectType);
    } catch (Exception ex) {
      LogHome.getLog().error("删除列配置异常", ex);
      throw new UserException("删除列配置异常", ex);
    }
  }

  public DataObjectList getColumnConfigByUser(BoActionContext actionContext, String userCuid, String objectType) throws UserException {
    try {
      DataObjectList columns = null;
      if ("CURRENT_ALARM".equals(objectType)) {
        columns = getColumnConfigDAO().getColumnConfigByUser(actionContext, userCuid, objectType);
        if (columns != null) break label57;
        columns = getColumnConfigDAO().getColumnConfigByUser(actionContext, "SYS_USER-DEFAULT", objectType);
      }

      label57: return getColumnConfigDAO().getColumnConfigByUser(actionContext, userCuid, objectType);
    }
    catch (Exception ex)
    {
      LogHome.getLog().error("查询列配置异常", ex);
      throw new UserException("查询列配置异常", ex);
    }
  }

  private ColumnConfigDAO getColumnConfigDAO() {
    return (ColumnConfigDAO)super.getDAO("ColumnConfigDAO");
  }

  public Boolean getIsStartAlarmStandard(BoActionContext actionContext) throws UserException {
    return Boolean.valueOf(TnmsRuntime.getInstance().equals("START_ALARM_STANDARD", "true"));
  }
}