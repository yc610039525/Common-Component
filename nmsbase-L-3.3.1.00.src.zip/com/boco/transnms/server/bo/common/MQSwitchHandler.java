package com.boco.transnms.server.bo.common;

import com.boco.common.util.debug.LogHome;
import com.boco.raptor.common.message.IMQSwitchHandler;
import com.boco.transnms.common.dto.MqSwitchLog;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.common.cfg.TnmsServerName;
import com.boco.transnms.server.common.cfg.TnmsServerName.ServerName;
import com.boco.transnms.server.dao.base.DaoHomeFactory;
import com.boco.transnms.server.dao.common.CommonDAO;
import java.sql.Timestamp;
import org.apache.commons.logging.Log;

public class MQSwitchHandler
  implements IMQSwitchHandler
{
  public void doSwitch(String qmName, String sourceIp, String targetIp)
  {
    LogHome.getLog().warn("记录MQ切换日志:管理器名称=" + qmName + ",源地址=" + sourceIp + ",目标地址=" + targetIp);
    String serverName = TnmsServerName.getLocalServerFullName();
    if (serverName == null) {
      return;
    }
    if ((serverName.equals(TnmsServerName.ServerName.AM.toString())) || (serverName.equals(TnmsServerName.ServerName.AMRTU.toString())) || (serverName.contains("ALARM_")))
    {
      String sql = "SERVER_FULL_NAME='" + serverName + "'" + " and " + "STATE" + "=1" + " and " + "SOURCE_IP" + "='" + sourceIp + "'" + " and " + "TARGET_IP" + "='" + targetIp + "'";
      try
      {
        DataObjectList dbos = getDAO().getObjectsBySql(sql, new MqSwitchLog(), 0);
        if ((dbos == null) || (dbos.size() == 0)) {
          MqSwitchLog mqSwitchLog = new MqSwitchLog();
          mqSwitchLog.setQmName(qmName);
          mqSwitchLog.setSourceIp(sourceIp);
          mqSwitchLog.setTargetIp(targetIp);
          mqSwitchLog.setServerFullName(serverName);
          mqSwitchLog.setState(1L);
          mqSwitchLog.setSwitchTime(new Timestamp(System.currentTimeMillis()));
          getDAO().createObject(new BoActionContext(), mqSwitchLog);
        }
      } catch (Exception e) {
        LogHome.getLog().error("添加MQ切换日志出错：", e);
      }
    }
  }

  private CommonDAO getDAO() {
    return (CommonDAO)DaoHomeFactory.getInstance().getDAO("CommonDAO");
  }
}