package com.boco.transnms.server.bo.common;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.bo.base.GenericBO;
import com.boco.transnms.server.bo.ibo.common.IRelationPropertyLoadBO;
import com.boco.transnms.server.dao.base.GenericDAO;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.logging.Log;

public class RelationPropertyLoadBO extends GenericBO
  implements IRelationPropertyLoadBO
{
  public GenericDO getFullObject(BoActionContext actionContext, String cuid, String relationPropertys)
    throws UserException
  {
    String[] relationProperties = relationPropertys.split("\\,");
    List complexProperties = new ArrayList();
    for (String relationPropert : relationProperties) {
      if (relationPropert.contains(":")) {
        complexProperties.add(relationPropert);
      }
    }
    GenericDO fullDbo = getObjByCuid(cuid);
    getGenericDAO().getDboCuidObj(fullDbo, relationProperties);
    if (!complexProperties.isEmpty()) {
      for (String relationProperty : complexProperties) {
        DataObjectList list = loadOneComplexProperties(fullDbo, relationProperty);
        if ((list != null) && (list.size() > 1)) {
          fullDbo.setAttrValue(relationProperty, list);
        } else if ((list != null) && (list.size() == 1)) {
          GenericDO tempDO = (GenericDO)list.get(0);
          fullDbo.setAttrValue(relationProperty, tempDO);
        }
      }
    }
    fullDbo.setObjectLoadType(3);
    return fullDbo;
  }

  protected GenericDAO getGenericDAO() {
    return (GenericDAO)super.getDAO("GenericDAO");
  }

  public GenericDO getObjByCuid(String cuid) throws UserException {
    try {
      GenericDO resDbo = null;
      GenericDO cuidDbo = new GenericDO();
      cuidDbo.setCuid(cuid);
      resDbo = getGenericDAO().getObjByCuid(cuidDbo);
      if ((resDbo instanceof GenericDO)) {
        GenericDO cloneDbo = null;
        cloneDbo = resDbo.createInstanceByClassName();
        resDbo.copyTo(cloneDbo);
        resDbo = cloneDbo;
      }
      if (resDbo == null) {
        throw new UserException("根据cuid得到对象错误：" + cuid);
      }
      return resDbo;
    } catch (Throwable ex) {
      LogHome.getLog().info("getObjsByCuid得到对象出错" + ex.getMessage());
      throw new UserException(ex.getMessage());
    }
  }

  private DataObjectList loadOneComplexProperties(GenericDO fullDbo, String complexProperty)
  {
    try
    {
      DataObjectList tempDO = new DataObjectList();
      tempDO.add(fullDbo);
      String[] split = complexProperty.split(";");
      for (String property : split) {
        if (tempDO == null) {
          break;
        }
        tempDO = loadOneProperty(tempDO, property);
      }
      return tempDO;
    } catch (Exception e) {
      LogHome.getLog().error(e, e);
    }
    return null;
  }

  private DataObjectList loadOneProperty(DataObjectList dataObjectList, String property) throws Exception {
    if (property.trim().length() == 0) {
      return null;
    }
    String[] split2 = property.split(":");
    if (split2.length != 2) {
      return null;
    }
    DataObjectList retList = new DataObjectList();
    if (dataObjectList != null) {
      for (GenericDO tempDO : dataObjectList) {
        Object attrValue = tempDO.getAttrValue(split2[0]);
        String[] split3 = split2[1].split("\\.");
        GenericDO gdo = new GenericDO();
        gdo.setClassName(split3[0]);
        GenericDO cloneByClassName = gdo.cloneByClassName();
        cloneByClassName.clearDefaultValue();
        cloneByClassName.setAttrValue(split3[1], attrValue);
        DataObjectList objByAttrs = getGenericDAO().getObjByAttrs(new BoQueryContext(), cloneByClassName);
        retList.addAll(objByAttrs);
      }
    }

    return retList;
  }

  public List getObjsByCuid(BoActionContext actionContext, String[] cuids) throws UserException {
    try {
      return getGenericDAO().getObjsByCuid(cuids);
    } catch (Throwable ex) {
      LogHome.getLog().info("getObjsByCuid得到对象出错" + ex.getMessage());
      throw new UserException(ex.getMessage());
    }
  }
}