package com.boco.transnms.server.bo.common;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.TemplateGroup;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.ibo.common.ITemplateGroupBO;
import com.boco.transnms.server.dao.common.TemplateDAO;
import com.boco.transnms.server.dao.common.TemplateGroupDAO;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="CM")
public class TemplateGroupBO extends AbstractBO
  implements ITemplateGroupBO
{
  private TemplateGroupDAO getTemplateGroupDAO()
  {
    return (TemplateGroupDAO)super.getDAO("TemplateGroupDAO");
  }

  private TemplateDAO getTemplateDAO() {
    return (TemplateDAO)super.getDAO("TemplateDAO");
  }

  public TemplateGroup addTemplateGroup(BoActionContext actionContext, TemplateGroup templateGroup)
    throws UserException
  {
    try
    {
      String sql = "LABEL_CN='" + templateGroup.getLabelCn() + "'" + " AND " + "RELATED_TEMPLATE_GROUP_CUID" + "='" + templateGroup.getRelatedTemplateGroupCuid() + "'";
      DataObjectList l = getTemplateGroupsBySql(actionContext, sql);
      TemplateGroup t = null;
      if (l.size() == 0)
        t = getTemplateGroupDAO().addTemplateGroup(actionContext, templateGroup);
      else {
        throw new UserException("该模板组下面已经存在名子为" + templateGroup.getLabelCn() + "的模板组！");
      }
      return t;
    } catch (Throwable ex) {
      LogHome.getLog().info("addTemplateGroup新增模板组对象出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public void deleteTemplateGroup(BoActionContext actionContext, TemplateGroup templateGroup)
    throws UserException
  {
    try
    {
      String sql = " 1=1 and RELATED_TEMPLATEGROUP_CUID='" + templateGroup.getCuid() + "' ";

      DataObjectList templates = getTemplateDAO().getFullTemplatesBySql(actionContext, sql);
      if (templates.size() > 0) {
        throw new UserException("模板组有下属模板，不能删除!");
      }
      getTemplateGroupDAO().deleteTemplateGroup(actionContext, templateGroup);
    }
    catch (Throwable ex) {
      LogHome.getLog().info("deleteTemplateGroup删除模板组对象出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public void deleteTemplateGroups(BoActionContext actionContext, DataObjectList templateGroups)
    throws UserException
  {
    try
    {
      for (int i = 0; i < templateGroups.size(); i++) {
        TemplateGroup templateGroup = (TemplateGroup)templateGroups.get(i);
        getTemplateGroupDAO().deleteTemplateGroup(actionContext, templateGroup);
      }
    } catch (Throwable ex) {
      LogHome.getLog().info("deleteTemplateGroups删除模板组对象出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public DataObjectList getAllTemplateGroups(BoActionContext actionContext)
    throws UserException
  {
    try
    {
      return getTemplateGroupDAO().getAllTemplateGroup(actionContext);
    }
    catch (Throwable ex) {
      LogHome.getLog().info("getAllTemplateGroups得到所有模板组对象出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public DataObjectList getTemplateGroupsBySql(BoActionContext actionContext, String sql)
    throws UserException
  {
    try
    {
      return (DataObjectList)getTemplateGroupDAO().getTemplateGroupsBySql(actionContext, sql);
    }
    catch (Throwable ex) {
      LogHome.getLog().info("getTemplateGroupsBySql得到模板组对象出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public void modifyTemplateGroup(BoActionContext actionContext, TemplateGroup templateGroup)
    throws UserException
  {
    try
    {
      getTemplateGroupDAO().modifyTemplateGroup(actionContext, templateGroup);
    } catch (Throwable ex) {
      LogHome.getLog().info("modifyTemplateGroup修改模板组对象出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }
}