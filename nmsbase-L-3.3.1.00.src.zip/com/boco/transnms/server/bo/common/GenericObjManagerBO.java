package com.boco.transnms.server.bo.common;

import com.boco.common.util.db.DbConnManager;
import com.boco.common.util.db.DbContext;
import com.boco.common.util.db.DbType;
import com.boco.common.util.db.SqlHelper;
import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.common.util.lang.StringHelper;
import com.boco.common.util.lang.TimeFormatHelper;
import com.boco.transnms.common.dto.DtoNames;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DataObjectMap;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericAttrGroup;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.base.GenericObjectModel;
import com.boco.transnms.common.dto.base.GenericQueryModel;
import com.boco.transnms.common.dto.common.DtoCacheModel;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.ibo.common.IGenericObjectManagerBO;
import com.boco.transnms.server.dao.common.GenericDbCacheDAO;
import com.boco.transnms.server.dao.common.GenericObjectManagerDAO;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;
import org.apache.commons.logging.Log;

public class GenericObjManagerBO extends AbstractBO
  implements IGenericObjectManagerBO
{
  private Map<String, DataObjectMap> cacheDynAttrMap = new Hashtable();
  private String defaultGroupCuid = null;

  public GenericObjManagerBO() {
    super("GenericObjManagerBO");
  }

  public void initBO() throws Exception {
    Map dynClassNames = getAllDynClassNames();
    cacheAllClassNames(dynClassNames);
    synDto2DynAttrs(dynClassNames);
    cacheAllDynAttrs();
    GenericAttrGroup group = getDefaultAttrGroup(new BoActionContext());
    if (group != null)
      this.defaultGroupCuid = group.getCuid();
  }

  private Map<String, String> getAllDynClassNames() throws Exception
  {
    Map dynClassNames = new HashMap();
    DboCollection dbos = getGenericObjectManagerDAO().getAllDynClassNames();
    for (int i = 0; i < dbos.size(); i++) {
      GenericObjectModel model = (GenericObjectModel)dbos.getQueryDbo(i, "GENERIC_OBJECT_MODEL");
      dynClassNames.put(model.getDynClassName(), model.getClassLabelCn());
    }
    return dynClassNames;
  }

  private void cacheAllClassNames(Map<String, String> dynClassNameMap) throws Exception {
    Map dtoNames = DtoNames.getDtoNames();
    String[] dtoClassNames = new String[dtoNames.size()];
    dtoNames.keySet().toArray(dtoClassNames);
    DataObjectList dtoCacheModels = new DataObjectList();
    for (int i = 0; i < dtoClassNames.length; i++) {
      DtoCacheModel dtoCacheModel = new DtoCacheModel();
      dtoCacheModel.setClassId(dtoClassNames[i]);
      dtoCacheModel.setClassLabelCn((String)dtoNames.get(dtoClassNames[i]));
      dtoCacheModel.setIsDynamic(dynClassNameMap.containsKey(dtoClassNames[i]));
      dtoCacheModels.add(dtoCacheModel);
    }

    String[] dynClassNames = new String[dynClassNameMap.size()];
    dynClassNameMap.keySet().toArray(dynClassNames);
    for (int i = 0; i < dynClassNames.length; i++) {
      String dynClassName = dynClassNames[i];
      if (!dtoNames.containsKey(dynClassName)) {
        DtoCacheModel dtoCacheModel = new DtoCacheModel();
        dtoCacheModel.setClassId(dynClassName);
        dtoCacheModel.setClassLabelCn((String)dynClassNameMap.get(dynClassName));
        dtoCacheModel.setIsDynamic(true);
        dtoCacheModels.add(dtoCacheModel);
      }
    }

    getGenericDbCacheDAO().createDtoModels(dtoCacheModels);
  }

  private void synDto2DynAttrs(Map<String, String> dynClassNameMap) throws Exception {
    DataObjectList dtoNewAttrList = new DataObjectList();
    DataObjectList dtoDelAttrList = new DataObjectList();
    DataObjectList dtoModifyAttrList = new DataObjectList();

    String IS_EXIST_ATTR = "IS_EXIST_ATTR";
    String[] dynClassNames = new String[dynClassNameMap.size()];
    dynClassNameMap.keySet().toArray(dynClassNames);

    for (String dynClassName : dynClassNames) {
      String[] dtoClassAttrNames = (String[])invokeDtoMethod(dynClassName, "getAllUserAttrNames", new Object[0]);
      Map dynClassAttrMap = new HashMap();
      DboCollection dynAttrs = getClassAllAttrs(null, dynClassName);
      for (int i = 0; i < dynAttrs.size(); i++) {
        GenericObjectModel dynAttr = (GenericObjectModel)dynAttrs.getQueryDbo(i, "GENERIC_OBJECT_MODEL");
        dynClassAttrMap.put(dynAttr.getAttrName(), dynAttr);
      }

      for (String dtoAttrName : dtoClassAttrNames) {
        if (!dynClassAttrMap.containsKey(dtoAttrName)) {
          GenericObjectModel dynAttr = createDynAttrByDto(dynClassName, dtoAttrName);
          dynAttr.setIsDtoAttr(true);
          dtoNewAttrList.add(dynAttr);
        } else {
          GenericObjectModel dynAttr = (GenericObjectModel)dynClassAttrMap.get(dtoAttrName);
          if (!dynAttr.getIsDtoAttr()) {
            dynAttr.setIsDtoAttr(true);
            dtoModifyAttrList.add(dynAttr);
          }
          dynAttr.setAttrValue(IS_EXIST_ATTR, true);
        }
      }

      String[] dynAttrNames = new String[dynClassAttrMap.size()];
      dynClassAttrMap.keySet().toArray(dynAttrNames);
      for (String dynAttrName : dynAttrNames) {
        GenericObjectModel dynAttr = (GenericObjectModel)dynClassAttrMap.get(dynAttrName);
        if ((!dynAttr.containsAttr(IS_EXIST_ATTR)) && (dynAttr.getIsDtoAttr())) {
          dtoDelAttrList.add(dynAttr);
        }
        dynAttr.removeAttr(IS_EXIST_ATTR);
      }
    }

    for (GenericDO newDynAttr : dtoNewAttrList) {
      getGenericObjectManagerDAO().insertDynAttr((GenericObjectModel)newDynAttr);
    }

    for (GenericDO delDynAttr : dtoDelAttrList) {
      getGenericObjectManagerDAO().deleteDynAttr(delDynAttr.getCuid());
    }

    for (GenericDO modifyDynAttr : dtoModifyAttrList)
      getGenericObjectManagerDAO().modifyDynAttr((GenericObjectModel)modifyDynAttr);
  }

  private void cacheAllDynAttrs() throws Exception
  {
    DboCollection dynAttrs = getGenericObjectManagerDAO().getDynAttrsOfDynamic();
    for (int i = 0; i < dynAttrs.size(); i++) {
      GenericObjectModel dynAttr = (GenericObjectModel)dynAttrs.getQueryDbo(i, "GENERIC_OBJECT_MODEL");
      refreshCacheDynAttr(dynAttr, false);
    }
  }

  private void refreshCacheDynAttr(GenericObjectModel dynAttr, boolean isDelete) {
    DataObjectMap attrs = (DataObjectMap)this.cacheDynAttrMap.get(dynAttr.getDynClassName());
    if (attrs == null) {
      attrs = new DataObjectMap();
      this.cacheDynAttrMap.put(dynAttr.getDynClassName(), attrs);
    }
    if (!dynAttr.getIsDtoAttr()) {
      if (!isDelete)
        invokeAddDynAttrType(dynAttr);
      else {
        invokeRemoveDynAttrType(dynAttr);
      }
    }
    attrs.remove(dynAttr.getAttrName());
    if (!isDelete)
      attrs.put(dynAttr.getAttrName(), dynAttr);
  }

  private void invokeAddDynAttrType(GenericObjectModel attr)
  {
    try {
      String helperClassName = parseDtoHelperClassName(attr.getDynClassName());
      Class dtoHelperClass = Class.forName(helperClassName);
      Method getInstanceMethod = dtoHelperClass.getDeclaredMethod("getInstance", new Class[0]);
      Object dtoHelperObj = getInstanceMethod.invoke(null, new Object[0]);
      Object[] args = new Object[2];
      args[0] = attr.getAttrName();
      args[1] = attr.getAttrTypeClass();
      Class[] argClasses = new Class[args.length];
      for (int i = 0; i < args.length; i++) {
        argClasses[i] = args[i].getClass();
      }
      Method putAttrTypeMethod = dtoHelperClass.getMethod("putAttrType", argClasses);
      putAttrTypeMethod.invoke(dtoHelperObj, args);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }

  private void invokeRemoveDynAttrType(GenericObjectModel attr) {
    try {
      String helperClassName = parseDtoHelperClassName(attr.getDynClassName());
      Class dtoHelperClass = Class.forName(helperClassName);
      Method getInstanceMethod = dtoHelperClass.getDeclaredMethod("getInstance", new Class[0]);
      Object dtoHelperObj = getInstanceMethod.invoke(null, new Object[0]);
      Object[] args = { attr.getAttrName() };
      Method putAttrTypeMethod = dtoHelperClass.getMethod("removeAttrType", new Class[] { String.class });
      putAttrTypeMethod.invoke(dtoHelperObj, args);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }

  public DboCollection getClassListByCond(BoQueryContext context, String className, String classLabelCn, Boolean isDynObj) throws UserException
  {
    try {
      return getGenericDbCacheDAO().getDtoCacheModelByCond(className, classLabelCn, isDynObj.booleanValue());
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public Boolean isDynClass(BoQueryContext context, String classId) throws UserException {
    try {
      return Boolean.valueOf(getGenericDbCacheDAO().isDynClass(classId));
    } catch (Exception ex) {
      throw new UserException(ex.getMessage());
    }
  }

  private boolean isDefaultGroupAttr(GenericObjectModel attrModel) {
    boolean isDefGroupAttr = true;
    if (this.defaultGroupCuid == null) {
      return true;
    }
    String groups = attrModel.getAttrGroups();
    if ((groups != null) && (groups.trim().length() > 0)) {
      if (groups.indexOf(this.defaultGroupCuid) >= 0)
        isDefGroupAttr = true;
      else
        isDefGroupAttr = false;
    }
    else {
      isDefGroupAttr = false;
    }

    return isDefGroupAttr;
  }

  public DataObjectList getClassDynAttrs(BoActionContext context, String className) throws UserException {
    DataObjectMap dynAttrs = (DataObjectMap)this.cacheDynAttrMap.get(className);
    DataObjectList dbos = new DataObjectList();
    if (dynAttrs == null) return dbos;
    String[] attrNames = new String[dynAttrs.size()];
    dynAttrs.keySet().toArray(attrNames);
    for (String attrName : attrNames) {
      GenericObjectModel attr = (GenericObjectModel)dynAttrs.get(attrName);
      if ((attr.getIsDynamic()) && (isDefaultGroupAttr(attr))) {
        dbos.add(attr);
      }
    }
    return dbos;
  }

  public DataObjectList getClassQueryAttrs(BoActionContext context, String className) throws UserException {
    DataObjectMap dynAttrs = (DataObjectMap)this.cacheDynAttrMap.get(className);
    DataObjectList dbos = new DataObjectList();
    if (dynAttrs == null) return dbos;

    String[] attrNames = new String[dynAttrs.size()];
    dynAttrs.keySet().toArray(attrNames);
    for (String attrName : attrNames) {
      GenericObjectModel attr = (GenericObjectModel)dynAttrs.get(attrName);
      if ((attr.getIsQuery()) && (isDefaultGroupAttr(attr))) {
        dbos.add(attr);
      }
    }
    return dbos;
  }

  public GenericObjectModel getClassDynAttrByName(BoActionContext context, String className, String attrName) {
    GenericObjectModel attr = null;
    DataObjectMap attrs = (DataObjectMap)this.cacheDynAttrMap.get(className);
    if (attrs != null) {
      attr = (GenericObjectModel)attrs.get(attrName);
    }
    return attr;
  }

  public GenericObjectModel getClassAttrByAttrName(BoActionContext context, String className, String attrName) throws UserException {
    GenericObjectModel attr = null;
    try {
      DboCollection dbos = getGenericObjectManagerDAO().getClassAttrByAttrName(className, attrName);
      if (dbos.size() == 1)
        attr = (GenericObjectModel)dbos.getAttrField("GENERIC_OBJECT_MODEL", 0);
    }
    catch (Exception ex) {
      throw new UserException(ex);
    }
    return attr;
  }

  public DboCollection getClassAllAttrs(BoActionContext context, String className) throws UserException {
    try {
      return getGenericObjectManagerDAO().getDynAttrsByclass(className);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  private GenericObjectModel createDynAttrByDto(String className, String attrName) throws Exception {
    GenericObjectModel model = new GenericObjectModel();
    model.setCuid();
    model.setDynClassName(className);
    model.setClassLabelCn((String)DtoNames.getDtoNames().get(className));
    model.setAttrName(attrName);

    String attrLabelCn = (String)invokeDtoMethod(className, "getAttrLabelCn", new Object[] { attrName });
    if ((attrLabelCn != null) && (!attrLabelCn.equals("")))
      model.setAttrLabelCn(attrLabelCn);
    else {
      model.setAttrLabelCn(attrName);
    }
    Class attrType = (Class)invokeDtoMethod(className, "getAttrType", new Object[] { attrName });
    model.writeAttrType(attrType.getName());

    model.setIsDynamic(false);
    model.setIsNotNull(false);
    model.setIsQuery(false);
    model.setIsVisible(false);
    model.setIsDtoAttr(true);
    return model;
  }

  public void modifyMultyAttrs(BoActionContext context, GenericObjectModel dbo, String ids) throws UserException
  {
    String[] idArr = null;
    String classId = "";
    String attrName = "";
    if ((ids != null) && (ids.length() > 0)) {
      idArr = ids.split(",");
      DataObjectList mList = new DataObjectList();
      if (idArr.length > 0) {
        for (int i = 0; i < idArr.length; i++) {
          classId = idArr[i].split("@")[0];
          attrName = idArr[i].split("@")[1];
          GenericObjectModel attr = getClassAttrByAttrName(context, classId, attrName);
          attr.setIsDynamic(dbo.getIsDynamic());
          attr.setIsNotNull(dbo.getIsNotNull());
          attr.setIsQuery(dbo.getIsQuery());
          attr.setIsVisible(dbo.getIsVisible());
          mList.add(attr);
        }
        modifyClassDynAttrs(context, mList);
      }
    }
  }

  public void modifyDynamicClass(BoActionContext context, String className, Boolean isDynClass) throws UserException {
    try {
      if (isDynClass.booleanValue()) {
        String[] attrNames = (String[])invokeDtoMethod(className, "getAllUserAttrNames", new Object[0]);
        GenericObjectModel[] models = new GenericObjectModel[attrNames.length];
        for (int i = 0; i < attrNames.length; i++) {
          models[i] = createDynAttrByDto(className, attrNames[i]);
        }
        getGenericObjectManagerDAO().insertDynAttrs(models);
      } else {
        getGenericObjectManagerDAO().deleteDynClass(className);
      }
      getGenericDbCacheDAO().updateDynClass(className, isDynClass.booleanValue());
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  private static Object invokeDtoMethod(String classId, String methodName, Object[] args) throws Exception {
    String className = parseDtoClassName(classId);
    Object dto = Class.forName(className).newInstance();
    Class[] argClasses = new Class[args.length];
    for (int i = 0; i < args.length; i++) {
      argClasses[i] = args[i].getClass();
    }
    Method method = dto.getClass().getMethod(methodName, argClasses);
    return method.invoke(dto, args);
  }

  private static String parseDtoClassName(String className) {
    String _className = parseClassName(className);
    return "com.boco.transnms.common.dto." + _className;
  }

  private static String parseDtoHelperClassName(String className) {
    String _className = parseClassName(className);
    return "com.boco.transnms.common.dto.helper." + _className + "Helper";
  }

  private static String parseClassName(String className) {
    String[] segs = className.split("_");
    String _className = "";
    for (int i = 0; i < segs.length; i++) {
      _className = _className + segs[i].substring(0, 1).toUpperCase() + segs[i].substring(1, segs[i].length()).toLowerCase();
    }

    return _className;
  }

  public void addClassDynAttr(BoActionContext context, GenericObjectModel attr) throws UserException {
    try {
      if (getGenericObjectManagerDAO().isDynAttrExist(attr, false)) {
        throw new UserException("重复的属性： " + attr.getAttrName());
      }
      if (!getGenericObjectManagerDAO().isAddAttrInDb(attr.getDynClassName(), attr.getAttrName())) {
        throw new UserException("请先升级模型[className=" + attr.getDynClassName() + ", attrName=" + attr.getAttrName() + "] 没有更新到数据库 !");
      }

      getGenericObjectManagerDAO().insertDynAttr(attr);
      refreshCacheDynAttr(attr, false);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void modifyClassDynAttr(BoActionContext context, GenericObjectModel attr) throws UserException {
    try {
      if (getGenericObjectManagerDAO().isDynAttrExist(attr, true)) {
        throw new UserException("重复的属性： " + attr.getAttrName());
      }
      if (!getGenericObjectManagerDAO().isAddAttrInDb(attr.getDynClassName(), attr.getAttrName())) {
        throw new UserException("请先升级模型[className=" + attr.getDynClassName() + ", attrName=" + attr.getAttrName() + "] 没有更新到数据库 !");
      }

      getGenericObjectManagerDAO().modifyDynAttr(attr);
      refreshCacheDynAttr(attr, false);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void modifyClassDynAttrs(BoActionContext context, DataObjectList attrs) throws UserException {
    try {
      for (int i = 0; i < attrs.size(); i++) {
        GenericObjectModel attr = (GenericObjectModel)attrs.get(i);
        getGenericObjectManagerDAO().modifyDynAttr(attr);
        refreshCacheDynAttr(attr, false);
      }
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void deleteClassDynAttrs(BoActionContext context, DataObjectList attrs) throws UserException {
    try {
      for (int i = 0; i < attrs.size(); i++) {
        GenericObjectModel attr = (GenericObjectModel)attrs.get(i);
        if (!attr.getIsDtoAttr()) {
          getGenericObjectManagerDAO().deleteDynAttr(attr.getCuid());
          refreshCacheDynAttr(attr, true);
        } else {
          throw new UserException("DTO的固定属性[" + attr.getAttrName() + "]不允许删除 ！");
        }
      }
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public GenericDO modifyAttrVal2Type(BoActionContext context, GenericDO dbo) throws UserException {
    DataObjectMap dynAttrs = (DataObjectMap)this.cacheDynAttrMap.get(dbo.getClassName());
    String[] attrNames = new String[dynAttrs.size()];
    dynAttrs.keySet().toArray(attrNames);

    for (int i = 0; i < attrNames.length; i++) {
      String attrName = attrNames[i];
      GenericObjectModel attrModel = (GenericObjectModel)dynAttrs.get(attrName);
      String attrVal = (String)dbo.getAttrValue(attrName);
      long attrType = attrModel.getAttrEnumType();
      if (attrVal != null) {
        if ((attrType == 1L) || (attrType == 3L))
        {
          dbo.setAttrValue(attrModel.getAttrName(), new Long(attrVal));
        } else if (attrType == 6L) {
          dbo.setAttrValue(attrModel.getAttrName(), attrVal.equals("1"));
        } else if (attrType == 4L) {
          java.util.Date date = TimeFormatHelper.convertDate(attrVal, "yyyy-MM-dd");
          dbo.setAttrValue(attrModel.getAttrName(), new Timestamp(date.getTime()));
        } else if (attrType == 5L) {
          java.util.Date date = TimeFormatHelper.convertDate(attrVal, "yyyy-MM-dd HH:mm:ss");
          dbo.setAttrValue(attrModel.getAttrName(), new Timestamp(date.getTime()));
        } else if (attrType == 2L) {
          dbo.setAttrValue(attrModel.getAttrName(), new Double(attrVal));
        }
      }
    }
    String objId = dbo.getAttrString("OBJECTID");
    if (objId != null) {
      dbo.setAttrValue("OBJECTID", Long.parseLong(objId));
    }
    return dbo;
  }

  public void addAttrGroup(BoActionContext context, GenericAttrGroup group) throws UserException {
    try {
      if (!getGenericObjectManagerDAO().isRightAttrGroup(group, false)) {
        throw new UserException("重复属性组: " + group.getGroupName());
      }

      if (group.getIsDefault() == true) {
        setAllGroupUnDefault(context);

        this.defaultGroupCuid = group.getCuid();
      }
      getGenericObjectManagerDAO().insertAttrGroup(group);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  private void setAllGroupUnDefault(BoActionContext context) throws Exception
  {
    DboCollection dbos = getGenericObjectManagerDAO().getAllAttrGroup();
    int size = dbos.size();
    for (int i = 0; i < size; i++) {
      GenericAttrGroup dbo = (GenericAttrGroup)dbos.getAttrField("GENERIC_ATTR_GROUP", i);
      dbo.setIsDefault(false);
      getGenericObjectManagerDAO().modifyAttrGroup(dbo);
    }
  }

  public void modifyAttrGroup(BoActionContext context, GenericAttrGroup group)
    throws UserException
  {
    try
    {
      if (getGenericObjectManagerDAO().isRightAttrGroup(group, true)) {
        if (group.getIsDefault() == true)
        {
          setAllGroupUnDefault(context);
          this.defaultGroupCuid = group.getCuid();
        }
        getGenericObjectManagerDAO().modifyAttrGroup(group);
      } else {
        throw new UserException("重复属性组: " + group.getGroupName());
      }
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void deleteAttrGroup(BoActionContext context, GenericAttrGroup group) throws UserException {
    try {
      getGenericObjectManagerDAO().deleteAttrGroup(group.getCuid());
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public HashMap deleteAttrGroups(BoActionContext context, String ids) throws UserException {
    HashMap rtn = new HashMap();
    try
    {
      String[] idArr = ids.split(",");
      if ((idArr != null) && (idArr.length > 0))
        for (int i = 0; i < idArr.length; i++) {
          String cuid = idArr[i].split("@")[1];
          boolean flag = getGenericObjectManagerDAO().deleteAttrGroup(cuid);
          rtn.put(idArr[i], Boolean.valueOf(flag));
        }
    }
    catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
    return rtn;
  }

  public DboCollection getAllAttrGroups(BoActionContext context) throws UserException {
    try {
      return getGenericObjectManagerDAO().getAllAttrGroup();
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getInUseAttrGroups(BoActionContext context) throws UserException {
    try { return getGenericObjectManagerDAO().getInUseAttrGroup();
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public Boolean isHasOtherDefaultGroup(BoActionContext context, String cuid, Boolean isIncludeCuid) throws UserException { Boolean rtn = Boolean.valueOf(false);
    try {
      rtn = Boolean.valueOf(getGenericObjectManagerDAO().isHasOtherDefaultGroup(cuid, isIncludeCuid.booleanValue()));
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
    return Boolean.valueOf(rtn.booleanValue()); }

  public GenericAttrGroup getDefaultAttrGroup(BoActionContext context) throws UserException
  {
    try {
      return getGenericObjectManagerDAO().getDefaultAttrGroup();
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public GenericAttrGroup getAttrGroupByCuid(BoActionContext context, String cuid) throws UserException {
    try {
      return getGenericObjectManagerDAO().getAttrGroupByCuid(cuid);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getClassAttrsOfGroup(BoActionContext context, String groupCuid, String className) throws UserException {
    try {
      return getGenericObjectManagerDAO().getClassAttrsOfGroup(groupCuid, className);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getClassDynQryAttrs(BoActionContext context, String className) throws UserException {
    try {
      return getGenericObjectManagerDAO().getClassDynQryAttrs(className);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getClassesOfGroup(BoActionContext context, String groupCuid) throws UserException {
    try {
      return getGenericObjectManagerDAO().getClassesOfGroup(groupCuid);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public String modifyDateFormat(BoActionContext context, String dateStr)
    throws UserException
  {
    String rtn = "";
    try {
      DbType dbType = DbConnManager.getInstance().getDbContext().getDbType();
      if (dateStr.trim().indexOf(" ") != -1)
        rtn = SqlHelper.getTimestamp(dbType, TimeFormatHelper.getFormatTimestamp(dateStr));
      else
        rtn = SqlHelper.getDate(dbType, java.sql.Date.valueOf(dateStr));
    }
    catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }

    return rtn;
  }

  public void addQueryModel(BoActionContext context, GenericQueryModel qModel) throws UserException
  {
    try {
      if (getGenericObjectManagerDAO().isQueryModelExist(qModel, false)) {
        throw new UserException("重复的查询定义");
      }
      getGenericObjectManagerDAO().insertQueryModel(qModel);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void modifyQueryModel(BoActionContext context, GenericQueryModel qModel) throws UserException {
    try {
      if (getGenericObjectManagerDAO().isQueryModelExist(qModel, true)) {
        throw new UserException("重复的查询定义");
      }
      getGenericObjectManagerDAO().modifyQueryModel(qModel);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void deleteQueryModel(BoActionContext context, GenericQueryModel qModel) throws UserException {
    try {
      getGenericObjectManagerDAO().deleteQueryModel(qModel.getCuid());
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getQueryModelsByClass(BoActionContext context, String classId) throws UserException {
    try {
      return getGenericObjectManagerDAO().getQueryModelsByClass(classId);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public GenericQueryModel getQueryModelByCuid(BoActionContext context, String cuid) throws UserException {
    try {
      return getGenericObjectManagerDAO().getQueryModelByCuid(cuid);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public String convertSql(BoActionContext context, String classId, String srcSql) throws UserException
  {
    String rtn = srcSql;
    try {
      String fixStr = "";
      String repStr = "";
      DboCollection dbos = getClassAllAttrs(context, classId);
      if (dbos.size() > 0)
        for (int i = 0; i < dbos.size(); i++) {
          GenericObjectModel dbo = (GenericObjectModel)dbos.getAttrField("GENERIC_OBJECT_MODEL", i);
          rtn = StringHelper.StrReplace(rtn, "{" + dbo.getAttrLabelCn() + "}", dbo.getAttrName());
        }
    }
    catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }

    return rtn;
  }

  private GenericDbCacheDAO getGenericDbCacheDAO()
  {
    return (GenericDbCacheDAO)getDAO("GenericDbCacheDAO");
  }

  private GenericObjectManagerDAO getGenericObjectManagerDAO() {
    return (GenericObjectManagerDAO)getDAO("GenericObjectManagerDAO");
  }
}