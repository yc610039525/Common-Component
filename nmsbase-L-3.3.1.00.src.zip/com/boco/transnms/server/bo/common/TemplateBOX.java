package com.boco.transnms.server.bo.common;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.graphkit.ext.IViewElement;
import com.boco.graphkit.ext.ModuleNode;
import com.boco.graphkit.ext.PlugInNode;
import com.boco.graphkit.ext.PortNode;
import com.boco.transnms.common.dto.Ddf;
import com.boco.transnms.common.dto.Ddfmodule;
import com.boco.transnms.common.dto.Ddfport;
import com.boco.transnms.common.dto.EquipmentHolder;
import com.boco.transnms.common.dto.JumpPair;
import com.boco.transnms.common.dto.Odf;
import com.boco.transnms.common.dto.Odfmodule;
import com.boco.transnms.common.dto.Odfport;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboBlob;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.common.Template;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.BoHomeFactory;
import com.boco.transnms.server.bo.ibo.common.ITemplateBOX;
import com.boco.transnms.server.dao.common.TemplateDAO;
import java.beans.XMLDecoder;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.logging.Log;
import twaver.BaseEquipment;
import twaver.Dummy;
import twaver.Element;
import twaver.PersistenceManager;
import twaver.TDataBox;

public class TemplateBOX extends AbstractBO
  implements ITemplateBOX
{
  public TemplateBOX()
  {
    super("ITemplateBOX");
  }

  public TemplateDAO getAllPicsDAO() {
    return (TemplateDAO)super.getDAO("TemplateDAO");
  }

  public HashMap getModuleAndPortsByTemplate(BoActionContext actionContext, HashMap paras, Template template)
  {
    String deviceType = (String)paras.get("DEVICE_TYPE");
    try
    {
      if ("ODF".equals(deviceType))
        return getOdfModuleAndPortsByTemplate(actionContext, paras, template);
      if ("DDF".equals(deviceType))
        return getDdfModuleAndPortsByTemplate(actionContext, paras, template);
    }
    catch (Exception e) {
      LogHome.getLog().error("生成模块和端口失败", e);
    }

    return null;
  }

  private String getTemplateXml(Template template) throws UnsupportedEncodingException {
    DboBlob dboBlob = template.getDataPic();
    String templateXml = null;
    String xml;
    if (dboBlob != null) {
      xml = new String(dboBlob.getBlobBytes(), "UTF-8").trim();
    }

    return templateXml;
  }

  private HashMap getDdfModuleAndPortsByTemplate(BoActionContext actionContext, HashMap paras, Template template)
    throws Exception
  {
    HashMap retMap = new HashMap();
    DataObjectList modules = new DataObjectList();
    DataObjectList ports = new DataObjectList();

    String xml = getTemplateXml(template);

    Ddf ddf = (Ddf)paras.get("RELATED_DEVICE");
    paras.put("SHELF_NAME", ddf.getLabelCn());

    TDataBox dataBox = new TDataBox();
    PersistenceManager.readByXML(dataBox, xml, null);

    List list = dataBox.getAllElements();
    if (list != null) {
      for (int i = 0; i < list.size(); i++) {
        Element element = (Element)list.get(i);
        xdfElementProcess(element, ddf, paras);
      }
    }

    List moduleNodes = dataBox.getElementsByType(ModuleNode.class);
    List portNodes = dataBox.getElementsByType(PortNode.class);

    if (moduleNodes != null) {
      for (int i = 0; i < moduleNodes.size(); i++) {
        ModuleNode moduleNode = (ModuleNode)moduleNodes.get(i);
        GenericDO nodeValue = moduleNode.getNodeValue();
        modules.add(nodeValue);
      }

      retMap.put("MODULE", modules);
    }

    if (portNodes != null) {
      for (int i = 0; i < portNodes.size(); i++) {
        PortNode portNode = (PortNode)portNodes.get(i);
        GenericDO nodeValue = portNode.getNodeValue();
        ports.add(nodeValue);
      }
      retMap.put("PORT", ports);
    }

    DataObjectList jumpPairs = generateJumpPair(dataBox, ddf);
    retMap.put("JUMP_PAIR", jumpPairs);

    return retMap;
  }

  private DataObjectList generateJumpPair(TDataBox templateBox, Ddf ddf) {
    List plugInNodeList = new ArrayList();
    if (templateBox.getElementByName("JUMP_PAIR") != null) {
      Element element = templateBox.getElementByName("JUMP_PAIR");

      if ((element instanceof Dummy)) {
        plugInNodeList = element.getChildren();
      }
    }
    else if (templateBox.getElementsByType(PlugInNode.class) != null) {
      plugInNodeList = templateBox.getElementsByType(PlugInNode.class);
    }

    List portNodeList = templateBox.getElementsByType(PortNode.class);
    DataObjectList jumpPairList = new DataObjectList();

    if (plugInNodeList != null) {
      Dummy dummyNode = null;
      if (plugInNodeList.size() > 0) {
        if (templateBox.getElementByName("JUMP_PAIR") == null) {
          dummyNode = new Dummy();
          dummyNode.setName("JUMP_PAIR");
          dummyNode.setParent((Element)templateBox.getRootElements().toArray()[0]);

          templateBox.addElement(dummyNode);
        } else {
          dummyNode = (Dummy)templateBox.getElementByName("JUMP_PAIR");
        }
      }

      int size = plugInNodeList.size();
      for (int i = 0; i < size; i++) {
        PlugInNode plugInNode = (PlugInNode)plugInNodeList.get(i);
        Ddfport sport = (Ddfport)((PortNode)plugInNode.getFromNode()).getNodeValue();

        Ddfport eport = (Ddfport)((PortNode)plugInNode.getToNode()).getNodeValue();

        DataObjectList tempPortList = new DataObjectList();
        tempPortList.clear();
        for (int j = 0; j < portNodeList.size(); j++) {
          Ddfport tempPort = (Ddfport)((PortNode)portNodeList.get(j)).getNodeValue();

          if ((tempPort.getNumInMcol() == sport.getNumInMcol()) && (tempPort.getNumInMrow() == sport.getNumInMrow()) && (tempPort.getRelatedModuleCuid().trim().equals(sport.getRelatedModuleCuid().trim())))
          {
            tempPortList.add(tempPort);
          }
          if ((tempPort.getNumInMcol() == eport.getNumInMcol()) && (tempPort.getNumInMrow() == eport.getNumInMrow()) && (tempPort.getRelatedModuleCuid().trim().equals(eport.getRelatedModuleCuid().trim())))
          {
            tempPortList.add(tempPort);
          }
          if (tempPortList.size() == 2)
          {
            break;
          }
        }
        if (tempPortList.size() > 1) {
          Ddfport port1 = (Ddfport)tempPortList.get(0);
          Ddfport port2 = (Ddfport)tempPortList.get(1);
          port1.setOppositeDdfportCuid(port2.getCuid());
          port2.setOppositeDdfportCuid(port1.getCuid());
          JumpPair jumpPair = new JumpPair();
          jumpPair.setOrigPointCuid(port1.getCuid());
          jumpPair.setDestPointCuid(port2.getCuid());
          jumpPair.setOrigEqpCuid(port1.getRelatedDeviceCuid());
          jumpPair.setDestEqpCuid(port2.getRelatedDeviceCuid());
          jumpPair.setLabelCn(port1.getLabelCn() + port2.getLabelCn());

          jumpPair.setJumpType(2L);
          jumpPair.clearUnknowAttrs();
          jumpPair.convAllObjAttrToCuid();
          jumpPairList.add(jumpPair);
        }
      }

    }

    return jumpPairList;
  }

  private HashMap getOdfModuleAndPortsByTemplate(BoActionContext actionContext, HashMap paras, Template template) throws IOException
  {
    HashMap retMap = new HashMap();
    DataObjectList modules = new DataObjectList();
    DataObjectList ports = new DataObjectList();

    String xml = getTemplateXml(template);

    Odf odf = (Odf)paras.get("RELATED_DEVICE");

    TDataBox dataBox = new TDataBox();
    PersistenceManager.readByXML(dataBox, xml, null);

    List list = dataBox.getAllElements();
    if (list != null) {
      for (int i = 0; i < list.size(); i++) {
        Element element = (Element)list.get(i);
        xdfElementProcess(element, odf, paras);
      }
    }

    List moduleNodes = dataBox.getElementsByType(ModuleNode.class);
    List portNodes = dataBox.getElementsByType(PortNode.class);

    if (moduleNodes != null) {
      for (int i = 0; i < moduleNodes.size(); i++) {
        ModuleNode moduleNode = (ModuleNode)moduleNodes.get(i);
        GenericDO nodeValue = moduleNode.getNodeValue();
        modules.add(nodeValue);
      }

      retMap.put("MODULE", modules);
    }

    if (portNodes != null) {
      for (int i = 0; i < portNodes.size(); i++) {
        PortNode portNode = (PortNode)portNodes.get(i);
        GenericDO nodeValue = portNode.getNodeValue();
        ports.add(nodeValue);
      }
      retMap.put("PORT", ports);
    }

    return retMap;
  }

  private void xdfElementProcess(Element element, GenericDO xdf, HashMap paras) {
    if ((element instanceof IViewElement)) {
      GenericDO dbo = ((IViewElement)element).getNodeValue();
      dbo.setCuid();
      if ((element instanceof BaseEquipment)) {
        ((BaseEquipment)element).setTag(dbo.getCuid());
      }
      if (((dbo instanceof Odfmodule)) || ((dbo instanceof Ddfmodule))) {
        dbo.setAttrValue("RELATED_DEVICE_CUID", xdf.getCuid());

        List list = element.getChildren();
        DataObjectList l = new DataObjectList();
        element.putClientProperty("ModuleChildren", l);

        if (dbo.getAttrValue("LABEL_DEV") == null) {
          element.putClientProperty("LABEL_DEV", "odf");
        }

        long rowCount = 0L;
        if (dbo.getAttrValue("PORT_ROW") != null) {
          rowCount = ((Long)dbo.getAttrValue("PORT_ROW")).intValue();
        }

        long colCount = 16L;
        if ((Long)dbo.getAttrValue("PORT_COL") != null) {
          colCount = ((Long)dbo.getAttrValue("PORT_COL")).intValue();
        }

        element.putClientProperty("PORT_ROW", Long.valueOf(rowCount));
        element.putClientProperty("PORT_COL", Long.valueOf(colCount));
        for (int i = 0; i < list.size(); i++) {
          Element e = (Element)list.get(i);
          if ((e instanceof PortNode)) {
            GenericDO d = ((PortNode)e).getNodeValue();
            l.add(d);
          }
        }

        nameElement(element, paras);
      } else if (((dbo instanceof Odfport)) || ((dbo instanceof Ddfport))) {
        ModuleNode module = (ModuleNode)element.getParent();
        GenericDO odfModule = module.getNodeValue();
        dbo.setAttrValue("RELATED_DEVICE_CUID", xdf.getCuid());

        dbo.setAttrValue("RELATED_MODULE_CUID", odfModule.getCuid());

        long rowInx = ((Long)dbo.getAttrValue("NUM_IN_MROW")).intValue();

        long colInx = ((Long)dbo.getAttrValue("NUM_IN_MCOL")).intValue();

        ((PortNode)element).setEquipIndex(rowInx, colInx);
      }
    }
  }

  public void nameElement(Element element, HashMap paras)
  {
    Long origNum = new Long(1L);
    Long stepNum = new Long(1L);
    GenericDO dbo = null;
    ModuleNode module = null;

    if ((element instanceof PortNode))
      module = (ModuleNode)element.getParent();
    else if ((element instanceof ModuleNode))
      module = (ModuleNode)element;
    else {
      return;
    }

    if (module != null) {
      dbo = module.getNodeValue();

      DataObjectList list = (DataObjectList)dbo.getAttrValue("ModuleChildren");

      Long hDirection = new Long(1L);
      Long vDirection = new Long(1L);
      Long order = new Long(1L);

      boolean horder = vDirection.longValue() == 1L;
      boolean vorder = hDirection.longValue() == 1L;
      if (list != null) {
        if (order.longValue() == 1L) {
          list.sort("NUM_IN_MCOL", horder);
          list.sort("NUM_IN_MROW", vorder);
        } else {
          list.sort("NUM_IN_MROW", vorder);
          list.sort("NUM_IN_MCOL", horder);
        }

        int portNo = 0;

        for (int i = 0; i < list.size(); i++)
        {
          String name = (String)paras.get("Port_NAME_RULE");
          GenericDO dboIt = (GenericDO)list.get(i);
          String label_cn = (String)dboIt.getAttrValue("LABEL_CN");

          portNo = i;
          Long num = Long.valueOf(origNum.longValue() + portNo * stepNum.longValue());
          String portName;
          String portName;
          if (name.equals("机架名称+分隔符+模块编号+分隔符+端子编号")) {
            portName = (String)paras.get("SHELF_NAME") + (String)paras.get("SEPRATOR") + dbo.getAttrValue("LABEL_CN") + paras.get("SEPRATOR") + label_cn;
          }
          else
          {
            portName = (String)paras.get("SHELF_NAME") + (String)paras.get("SEPRATOR") + label_cn;
          }

          dboIt.setAttrValue("LABEL_CN", portName);
        }
      }
    }
  }

  public Template addTemplate(BoActionContext actionContext, Template template)
    throws UserException
  {
    try
    {
      String sql = "NAME='" + template.getName() + "'";
      DataObjectList l = getTemplatesBySql(actionContext, sql);
      if (l.size() == 0)
        getAllPicsDAO().addTemplate(actionContext, template);
      else {
        throw new UserException("已经存在同名模板！");
      }

    }
    catch (Throwable e)
    {
      LogHome.getLog().info("addTemplate添加模板时出错" + e.getMessage());
      throw new UserException(e);
    }
    return template;
  }

  public void deleteTemplate(BoActionContext actionContext, Template template)
    throws UserException
  {
    try
    {
      getAllPicsDAO().deleteTemplate(actionContext, template);
    } catch (Throwable e) {
      LogHome.getLog().info("addTemplate删除模板时出错" + e.getMessage());
      throw new UserException(e);
    }
  }

  public int isTemplateInUse(Template template)
    throws UserException
  {
    try
    {
      String sql = "SELECT T.* FROM TEMPLATE T,TRANS_ELEMENT TE WHERE T.CUID = '" + template.getCuid() + "' AND TE.RELATED_TEMPLATE_NAME = T.NAME";
      ITemplateBOX bo = (ITemplateBOX)BoHomeFactory.getInstance().getBO(ITemplateBOX.class);
      DboCollection list = getAllPicsDAO().selectDBOs(sql, new GenericDO[] { new Template() });
      if ((null != list) && (list.size() > 0)) {
        return 1;
      }
      return 2;
    }
    catch (Exception ex) {
      LogHome.getLog().error(".......isTemplateInUse error......" + ex);
    }return 0;
  }

  public void deleteTemplates(BoActionContext actionContext, DataObjectList templates)
    throws UserException
  {
    for (GenericDO dbo : templates)
      deleteTemplate(actionContext, (Template)dbo);
  }

  public DataObjectList getTemplatesBySql(BoActionContext actionContext, String sql)
    throws UserException
  {
    try
    {
      return getAllPicsDAO().getFullTemplatesBySql(actionContext, sql);
    }
    catch (Throwable e)
    {
      LogHome.getLog().info("addTemplate添加模板时出错" + e.getMessage());
      throw new UserException(e);
    }
  }

  public void modifyTemplateInfo(BoActionContext actionContext, Template template)
    throws UserException
  {
    try
    {
      String sql = "NAME='" + template.getName() + "' and " + "CUID" + "<>'" + template.getCuid() + "'";

      DataObjectList l = getTemplatesBySql(actionContext, sql);
      if (l.size() == 0)
        getAllPicsDAO().modifyTemplateInfo(actionContext, template);
      else {
        throw new UserException("已经存在同名模板！");
      }

    }
    catch (Throwable e)
    {
      LogHome.getLog().info("modifyTemplateInfo修改模板时出错" + e.getMessage());
      throw new UserException(e);
    }
  }

  public void modifyTemplatePic(BoActionContext actionContext, Template template)
    throws UserException
  {
    try
    {
      getAllPicsDAO().modifyPicField(actionContext, template);
      getAllPicsDAO().modifyDataPicField(actionContext, template);
    }
    catch (Throwable e)
    {
      LogHome.getLog().info("modifyTemplatePic修改模板时出错" + e.getMessage());
      throw new UserException(e);
    }
  }

  public DboBlob getTemplatePic(BoActionContext actionContext, Template template)
    throws UserException
  {
    try
    {
      return getAllPicsDAO().getTemplatePic(actionContext, template);
    }
    catch (Throwable e)
    {
      LogHome.getLog().info("getTemplatePic得到模板时出错" + e.getMessage());
      throw new UserException(e);
    }
  }

  public DataObjectList getFullTemplatesBySql(BoActionContext actionContext, String sql) throws UserException {
    try {
      return getAllPicsDAO().getFullTemplatesBySql(actionContext, sql);
    }
    catch (Throwable e)
    {
      LogHome.getLog().info("getFullTemplatesBySql加载模板时出错" + e.getMessage());
      throw new UserException(e);
    }
  }

  public DboBlob getTemplateDataPic(BoActionContext actionContext, Template template)
    throws UserException
  {
    try
    {
      return getAllPicsDAO().getTemplateDataPic(actionContext, template);
    } catch (Throwable e) {
      LogHome.getLog().info("getTemplateDataPic得到模板时出错" + e.getMessage());
      throw new UserException(e);
    }
  }

  public Object readByXML(String xml, String objectName) throws Exception
  {
    try
    {
      ByteArrayInputStream in = new ByteArrayInputStream(xml.getBytes("UTF-8"));
      XMLDecoder decode = new XMLDecoder(in);
      Object obj = decode.readObject();
      boolean isFind = false;
      while (obj != null) {
        if (((obj instanceof String)) && (obj.toString().equals(objectName))) {
          isFind = true;
          break;
        }
        obj = decode.readObject();
      }
      if (isFind)
        obj = decode.readObject();
      else {
        obj = null;
      }
      decode.close();
      return obj;
    } catch (ArrayIndexOutOfBoundsException e) {
    }
    catch (Exception ex) {
      LogHome.getLog().error("读取XML错误！", ex);
    }
    return null;
  }

  public void setGenericDOPropByMap(GenericDO nodeValue, Map map)
  {
    setGenericDOPropByMap(nodeValue, map, true);
  }

  public void setGenericDOPropByMap(GenericDO nodeValue, Map map, boolean isClear) {
    String[] knownAttrNames = nodeValue.getAllUserAttrNames();
    Iterator iter = map.keySet().iterator();
    Map objectMap = new HashMap();
    while (iter.hasNext()) {
      Object key = iter.next();
      if (key != null)
      {
        Object obj = map.get(key);
        if ((obj instanceof Map)) {
          String className = ((Map)obj).get("className").toString();
          GenericDO gdo = new GenericDO(className);
          gdo = gdo.createInstanceByClassName();
          ((Map)obj).remove("className");
          gdo.setAttrValues((Map)obj);
          objectMap.put(key, gdo.getCuid());
        }
      }
    }
    iter = objectMap.keySet().iterator();
    while (iter.hasNext()) {
      Object key = iter.next();
      map.remove(key);
    }

    nodeValue.setAttrValues(map);
    iter = objectMap.keySet().iterator();
    while (iter.hasNext()) {
      Object key = iter.next();
      Object obj = objectMap.get(key);
      nodeValue.setAttrValue(key.toString(), obj);
    }

    if (isClear) {
      ArrayList knownAttrNameList = new ArrayList();
      for (int j = 0; j < knownAttrNames.length; j++) {
        knownAttrNameList.add(knownAttrNames[j]);
      }
      Object[] allAttrNames = nodeValue.getAllAttr().keySet().toArray();
      for (int i = 0; i < allAttrNames.length; i++) {
        Object attrName = allAttrNames[i];
        if (!knownAttrNameList.contains(attrName))
          nodeValue.getAllAttr().remove(attrName);
      }
    }
  }

  public String[][] getSysNoByTemplate(BoActionContext actionContext, String templateName)
    throws UserException
  {
    Template template = null;
    try {
      template = getTemplateByName(actionContext, templateName);
    }
    catch (Exception ex) {
    }
    if (template == null) {
      LogHome.getLog().error("获取模板错误，模板不存在！" + templateName);
      throw new UserException("获取模板错误，模板不存在！" + templateName);
    }
    try {
      DboBlob dataPic = getTemplateDataPic(actionContext, template);
      String templateXml = new String(dataPic.getBlobBytes(), "UTF-8");
      Object obj = readByXML(templateXml, "DATA_PIC");
      if (!(obj instanceof ArrayList)) {
        LogHome.getLog().error("获取模板错误，数据模型解析错误！");
        throw new UserException("获取模板错误，数据模型解析错误！");
      }
      return getSysNoByList((ArrayList)obj);
    }
    catch (Exception ex) {
      LogHome.getLog().error("获取模板错误，数据模型解析错误！" + ex.getMessage());
      throw new UserException("获取模板错误，数据模型解析错误！" + ex.getMessage());
    }
  }

  private String[][] getSysNoByList(ArrayList list) {
    HashMap sysNoMap = new HashMap();
    addSysNoToMap(sysNoMap, list);
    String[][] retValue = new String[sysNoMap.size()][2];
    Iterator iter = sysNoMap.keySet().iterator();
    int i = 0;
    while (iter.hasNext()) {
      Object key = iter.next();
      retValue[i][0] = key.toString();
      retValue[(i++)][1] = sysNoMap.get(key).toString();
    }
    return retValue;
  }

  private void addSysNoToMap(HashMap sysNoMap, ArrayList list) {
    for (int i = 0; i < list.size(); i++) {
      Object object = list.get(i);
      if ((object != null) && ((object instanceof Map))) {
        Map map = (Map)object;
        try {
          Object childObject = map.get("ELEMENT_CHILD_OBJECT");
          map.remove("ELEMENT_CHILD_OBJECT");
          String className = map.get("className").toString();
          GenericDO nodeValue = new GenericDO(className);
          nodeValue = nodeValue.createInstanceByClassName();
          map.remove("className");
          if ((nodeValue instanceof EquipmentHolder)) {
            setGenericDOPropByMap(nodeValue, map, false);
            Object sn = nodeValue.getAttrValue("SYSTEM_NUMBER");
            if (sn != null) {
              sysNoMap.put(((EquipmentHolder)nodeValue).getFdn(), sn);
            }
          }
          if ((childObject != null) && ((childObject instanceof ArrayList)))
            addSysNoToMap(sysNoMap, (ArrayList)childObject);
        }
        catch (Exception ex) {
          LogHome.getLog().error("根据类名生成对象错误！" + ex.getMessage());
        }
      }
    }
  }

  public String getSysNoBySlotDN(BoActionContext actionContext, String templateName, String dnName) throws UserException {
    String[][] sysNos = getSysNoByTemplate(actionContext, templateName);
    if (sysNos != null) {
      for (int i = 0; i < sysNos.length; i++) {
        if ((sysNos[i].length == 2) && (sysNos[i][0].equals(dnName))) {
          return sysNos[i][1];
        }
      }
    }
    return "";
  }

  public Template getTemplateByCuid(BoActionContext actionContext, String templateCuid) throws UserException {
    try {
      return getAllPicsDAO().getTemplateByCuid(actionContext, templateCuid);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex);
    }
  }

  public Template getTemplateByName(BoActionContext actionContext, String templateName) throws UserException {
    try {
      return getAllPicsDAO().getTemplateByName(actionContext, templateName);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex);
    }
  }

  protected TemplateGroupBO getTemplateGroupBO() {
    return (TemplateGroupBO)super.getBO("ITemplateGroupBO");
  }

  public DataObjectList getSimpleTemplatesBySql(BoActionContext actionContext, String sql) throws UserException
  {
    try {
      return getAllPicsDAO().getTemplatesBySql(actionContext, sql);
    } catch (Exception e) {
      throw new UserException(e);
    }
  }

  public DboCollection getWdmTemplatesBySql(BoActionContext actionContext, String sql)
    throws UserException
  {
    try
    {
      return getAllPicsDAO().selectDBOs(new BoQueryContext(), sql, new GenericDO[] { new Template(), new EquipmentHolder() });
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex);
    }
  }
}