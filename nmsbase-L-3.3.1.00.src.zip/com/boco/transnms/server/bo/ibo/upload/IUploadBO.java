package com.boco.transnms.server.bo.ibo.upload;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.server.bo.base.IBusinessObject;
import com.boco.transnms.server.bo.upload.UploadFile;

public abstract interface IUploadBO extends IBusinessObject
{
  public abstract UploadFile addFile(BoActionContext paramBoActionContext, UploadFile paramUploadFile)
    throws UserException;

  public abstract UploadFile getFile(BoActionContext paramBoActionContext, UploadFile paramUploadFile)
    throws UserException;

  public abstract void deleteFile(BoActionContext paramBoActionContext, UploadFile paramUploadFile);

  public abstract Boolean isSynFile(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract UploadFile getZipFile(BoActionContext paramBoActionContext, UploadFile paramUploadFile)
    throws UserException;
}