package com.boco.transnms.server.bo.ibo.cm;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.VersionAttach;
import com.boco.transnms.common.dto.VersionManager;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.server.bo.base.IBusinessObject;
import java.util.HashMap;

public abstract interface IVersionManagerBO extends IBusinessObject
{
  public abstract VersionManager getVersionManager(BoActionContext paramBoActionContext, Long paramLong)
    throws UserException;

  public abstract VersionManager addVersionManager(BoActionContext paramBoActionContext, VersionManager paramVersionManager)
    throws UserException;

  public abstract void modifyVersionManager(BoActionContext paramBoActionContext, VersionManager paramVersionManager)
    throws UserException;

  public abstract void deleteVersionManager(BoActionContext paramBoActionContext, Long paramLong)
    throws UserException;

  public abstract DboCollection getVersionManagerByCondition(BoQueryContext paramBoQueryContext, String paramString1, String paramString2, String paramString3)
    throws UserException;

  public abstract DataObjectList getAllVersionManager(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract String getProductType(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract String getProductSP(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract Boolean getSupportLogicalWireSeg(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract HashMap getActionFilters(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract DboCollection getVersionAttach(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract String addDbo(BoActionContext paramBoActionContext, VersionAttach paramVersionAttach)
    throws Exception;

  public abstract VersionAttach getAttachFile(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract String delAttachFile(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract String getDefaultTheme(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract String getBuildVersion(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract boolean getStartNanfangTheme(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract boolean getVipTraph(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract HashMap getTnmsRuntimeCfgParams(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract HashMap getRuntimeCfgParams(BoActionContext paramBoActionContext)
    throws UserException;
}