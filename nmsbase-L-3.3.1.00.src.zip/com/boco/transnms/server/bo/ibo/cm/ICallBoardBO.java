package com.boco.transnms.server.bo.ibo.cm;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.CallBoard;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.server.bo.base.IBusinessObject;
import java.util.List;

public abstract interface ICallBoardBO extends IBusinessObject
{
  public abstract CallBoard getCallBoard(BoActionContext paramBoActionContext, Long paramLong)
    throws UserException;

  public abstract CallBoard addCallBoard(BoActionContext paramBoActionContext, CallBoard paramCallBoard)
    throws UserException;

  public abstract void modifyCallBoard(BoActionContext paramBoActionContext, CallBoard paramCallBoard)
    throws UserException;

  public abstract void deleteCallBoard(BoActionContext paramBoActionContext, Long paramLong)
    throws UserException;

  public abstract DboCollection getCallBoardByCondition(BoQueryContext paramBoQueryContext, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws UserException;

  public abstract DboCollection getCallBoardByHenan(BoQueryContext paramBoQueryContext)
    throws UserException;

  public abstract DataObjectList getAllCallBoard(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract DataObjectList getCallBoardByCondition(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract List getTransElementStatis(BoQueryContext paramBoQueryContext)
    throws UserException;

  public abstract List getTraphSatistic(BoQueryContext paramBoQueryContext)
    throws UserException;

  public abstract List getDuctSatistic(BoQueryContext paramBoQueryContext)
    throws UserException;

  public abstract List getAlarmSatistic(BoQueryContext paramBoQueryContext)
    throws UserException;

  public abstract CallBoard getCallBoardByCuid(String paramString)
    throws UserException;
}