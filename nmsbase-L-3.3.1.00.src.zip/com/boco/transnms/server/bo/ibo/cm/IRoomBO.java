package com.boco.transnms.server.bo.ibo.cm;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.Room;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.bo.base.IBusinessObject;
import java.util.Map;

public abstract interface IRoomBO extends IBusinessObject
{
  public abstract DataObjectList getChildElement(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getChildSwitch(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract Room getRoom(BoActionContext paramBoActionContext, Long paramLong)
    throws UserException;

  public abstract Room addRoom(BoActionContext paramBoActionContext, Room paramRoom)
    throws UserException;

  public abstract void modifyRoom(BoActionContext paramBoActionContext, Room paramRoom)
    throws UserException;

  public abstract void deleteRoom(BoActionContext paramBoActionContext, Long paramLong)
    throws UserException;

  public abstract void deleteRooms(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract Room getRoomByCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getRoomBySiteCuids(BoActionContext paramBoActionContext, String[] paramArrayOfString)
    throws UserException;

  public abstract DataObjectList getRoomBySiteCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getRoomByDistrictCuid(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract DataObjectList getAllRoom(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract DataObjectList getRoomByName(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DboCollection getRoomByRoomName(BoQueryContext paramBoQueryContext, String paramString)
    throws UserException;

  public abstract String getRoomCuidByLabelCn(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DboCollection getSwitchElementByLabelcnAndRoomCuidByPage(BoQueryContext paramBoQueryContext, String paramString1, String paramString2)
    throws UserException;

  public abstract DboCollection getSwitchElementByCuidByPage(BoQueryContext paramBoQueryContext, String paramString)
    throws Exception;

  public abstract DataObjectList getRoomByNameAndSiteCuid(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract DboCollection getRoomByPageCondition(BoQueryContext paramBoQueryContext, String paramString1, String paramString2, String paramString3, Boolean paramBoolean, Map paramMap, String paramString4, String paramString5)
    throws UserException;

  public abstract DataObjectList getRoomTypeInfo()
    throws UserException;

  public abstract DataObjectList getOdfByNameAndRoomCuid(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract DataObjectList getMiscrackByNameAndRoomCuid(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract Room getRoomByPort(BoActionContext paramBoActionContext, String paramString);

  public abstract DboCollection getRoomByRoomNameNew(BoQueryContext paramBoQueryContext, String paramString1, String paramString2, String paramString3)
    throws UserException;

  public abstract DboCollection getAllRoomCuidAndLabelCn(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract DataObjectList getRoomByFloorCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract int getRelatedDeleteObjCount(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract DataObjectList getRoomBySql(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract boolean isHaveRelatedObj(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract DataObjectList getRelatedDeleteObjects(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract void deleteReletedOfObject(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract void deleteRoomByCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract void deleteRoomFiber(BoActionContext paramBoActionContext, Map paramMap)
    throws Exception;

  public abstract DataObjectList modifyRelatedSpaceByWireSeg(BoActionContext paramBoActionContext, Room paramRoom1, Room paramRoom2)
    throws Exception;

  public abstract DataObjectList modifyRelatedSpaceByDuctLine(BoActionContext paramBoActionContext, Room paramRoom1, Room paramRoom2, GenericDO paramGenericDO1, GenericDO paramGenericDO2)
    throws Exception;

  public abstract void syncModifySegs(DataObjectList paramDataObjectList)
    throws Exception;
}