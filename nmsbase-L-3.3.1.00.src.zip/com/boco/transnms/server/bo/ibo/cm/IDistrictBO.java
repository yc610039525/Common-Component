package com.boco.transnms.server.bo.ibo.cm;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.District;
import com.boco.transnms.common.dto.Site;
import com.boco.transnms.common.dto.TLogicNumberRange;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import java.util.HashMap;
import java.util.List;

public abstract interface IDistrictBO extends IDistrictBOX
{
  public abstract DataObjectList getLevelDistrict(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract void modifyLevelDistrict(BoActionContext paramBoActionContext, String[] paramArrayOfString)
    throws UserException;

  public abstract DataObjectList getChildSite(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract District getDistrict(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract District addDistrict(BoActionContext paramBoActionContext, District paramDistrict)
    throws UserException;

  public abstract void importExcelDistricts(BoActionContext paramBoActionContext, DataObjectList paramDataObjectList)
    throws UserException;

  public abstract void modifyDistrict(BoActionContext paramBoActionContext, District paramDistrict)
    throws UserException;

  public abstract void deleteDistrict(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract District getDistrictByCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract String getNameByEquipCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract District getDistrictOfSite(BoActionContext paramBoActionContext, Site paramSite)
    throws UserException;

  public abstract District getParentDistrict(BoActionContext paramBoActionContext, District paramDistrict)
    throws UserException;

  public abstract DataObjectList getAllChildDistrict(BoActionContext paramBoActionContext, District paramDistrict)
    throws UserException;

  public abstract DataObjectList getChildDistricts(BoActionContext paramBoActionContext, District paramDistrict)
    throws UserException;

  public abstract String getCuidByLabelCn(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract String getBelongDistrictCuidByEquipCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract Integer is2DistrictOrder(BoActionContext paramBoActionContext, District paramDistrict1, District paramDistrict2)
    throws UserException;

  public abstract District getEquipDistrictByCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract String getSiteDistrictCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getAllChildDistrictTranslate(BoActionContext paramBoActionContext, District paramDistrict)
    throws UserException;

  public abstract DataObjectList getAllDistrictCuidAndLabelCn(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract DataObjectList getDistrictBySql(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract String getDistrictCons(String paramString)
    throws UserException;

  public abstract void getAllDistrictByDisCuid(District paramDistrict, HashMap paramHashMap)
    throws UserException;

  public abstract int getRelatedDeleteObjCount(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract boolean isHaveRelatedObj(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract DataObjectList getRelatedDeleteObjects(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract void deleteReletedOfObject(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract List<String> getBelongDistrictCuidByEquipCuid(BoActionContext paramBoActionContext, List<String> paramList)
    throws UserException;

  public abstract DboCollection getDistrictAndChildren(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract boolean addCacheObjectForCM(BoActionContext paramBoActionContext, GenericDO paramGenericDO)
    throws UserException;

  public abstract boolean updateCacheObjectForCM(BoActionContext paramBoActionContext, GenericDO paramGenericDO)
    throws UserException;

  public abstract boolean deleteCacheObjectForCM(BoActionContext paramBoActionContext, GenericDO paramGenericDO)
    throws UserException;

  public abstract GenericDO getObjByCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract GenericDO getSpaceObjectByCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getNetIp()
    throws Exception;

  public abstract TLogicNumberRange addTLogicNumberRange(BoActionContext paramBoActionContext, TLogicNumberRange paramTLogicNumberRange)
    throws Exception;

  public abstract void delTLogicNumberRange(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract DboCollection getTLogicNumberRange(String paramString)
    throws Exception;

  public abstract void modifyTLogicNumberRange(BoActionContext paramBoActionContext, TLogicNumberRange paramTLogicNumberRange)
    throws Exception;
}