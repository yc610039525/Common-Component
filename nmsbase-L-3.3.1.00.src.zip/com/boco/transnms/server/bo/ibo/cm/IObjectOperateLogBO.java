package com.boco.transnms.server.bo.ibo.cm;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.bo.base.IBusinessObject;
import java.util.HashMap;

public abstract interface IObjectOperateLogBO extends IBusinessObject
{
  public abstract void addObjOperateLog(BoActionContext paramBoActionContext, long paramLong1, long paramLong2, GenericDO paramGenericDO1, GenericDO paramGenericDO2)
    throws UserException, Exception;

  public abstract void deleteLogsByIds(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract DboCollection getObjectLog(BoQueryContext paramBoQueryContext, HashMap paramHashMap, String paramString)
    throws UserException;
}