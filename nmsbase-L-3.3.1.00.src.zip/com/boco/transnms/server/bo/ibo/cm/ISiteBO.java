package com.boco.transnms.server.bo.ibo.cm;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.Room;
import com.boco.transnms.common.dto.Site;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.bo.base.IBusinessObject;
import java.util.List;
import java.util.Map;

public abstract interface ISiteBO extends IBusinessObject
{
  public abstract DataObjectList getAllSite(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract Site getSite(BoActionContext paramBoActionContext, Long paramLong)
    throws UserException;

  public abstract Site getSiteByCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getSiteByDistrictCuids(BoActionContext paramBoActionContext, String[] paramArrayOfString, String paramString)
    throws UserException;

  public abstract Site addSite(BoActionContext paramBoActionContext, Site paramSite)
    throws UserException;

  public abstract void modifySite(BoActionContext paramBoActionContext, Site paramSite)
    throws UserException;

  public abstract void deleteSite(BoActionContext paramBoActionContext, Long paramLong)
    throws UserException;

  public abstract DataObjectList getSiteByQuery(BoActionContext paramBoActionContext, String paramString1, String paramString2, String paramString3, Boolean paramBoolean1, Boolean paramBoolean2, Boolean paramBoolean3, Boolean paramBoolean4, String paramString4)
    throws UserException;

  public abstract DboCollection getSiteByPageCondition(BoQueryContext paramBoQueryContext, String paramString)
    throws UserException;

  public abstract DboCollection getAccessByPageCondition(BoQueryContext paramBoQueryContext, String paramString)
    throws UserException;

  public abstract DataObjectList querySiteLabelAndCuidByPageCondition(BoQueryContext paramBoQueryContext, String paramString)
    throws UserException;

  public abstract DboCollection getSiteByPage(BoQueryContext paramBoQueryContext, String paramString1, String paramString2, String paramString3, Boolean paramBoolean, Long paramLong1, String paramString4, String paramString5, Long paramLong2, Long paramLong3, String paramString6)
    throws UserException;

  public abstract DataObjectList getChildRoom(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DboCollection getChildRoomBycuidorRoomNamePage(BoQueryContext paramBoQueryContext, String paramString1, String paramString2, String paramString3)
    throws UserException;

  public abstract DataObjectList getChildRoomByRoomName(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract Site getSiteOfRoom(BoActionContext paramBoActionContext, Room paramRoom)
    throws UserException;

  public abstract DataObjectList getSiteBySubNetWorks(BoActionContext paramBoActionContext, DataObjectList paramDataObjectList)
    throws UserException;

  public abstract DataObjectList getSiteByTransSystems(BoActionContext paramBoActionContext, DataObjectList paramDataObjectList)
    throws UserException;

  public abstract String getSiteCuidByRoomCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getSiteByName(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DboCollection getSiteByDistrictCuidAndSiteName(BoQueryContext paramBoQueryContext, String paramString1, String paramString2, Boolean paramBoolean)
    throws UserException;

  public abstract void modifySiteCfgType(String paramString)
    throws UserException;

  public abstract void addSiteCfgType(String paramString)
    throws UserException;

  public abstract void delSiteCfgType(String paramString)
    throws UserException;

  public abstract void modifySwitchCfgType(String paramString)
    throws UserException;

  public abstract void addSwitchCfgType(String paramString)
    throws UserException;

  public abstract void delSwitchCfgType(String paramString)
    throws UserException;

  public abstract DataObjectList getSiteCfgType()
    throws UserException;

  public abstract DataObjectList getSwitchCfgType()
    throws UserException;

  public abstract DataObjectList getRoomCfgType()
    throws UserException;

  public abstract DataObjectList getIsRoomType(BoActionContext paramBoActionContext, String[] paramArrayOfString)
    throws UserException;

  public abstract String getCuidByLabelcn(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getSiteTypeInfo()
    throws UserException;

  public abstract Map getSitesByCuids(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getSiteBySql(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getSiteByServicelevel(BoActionContext paramBoActionContext, Long paramLong)
    throws UserException;

  public abstract DataObjectList getSiteBySql(BoActionContext paramBoActionContext, String paramString, int paramInt)
    throws UserException;

  public abstract void modifySiteLocation(BoActionContext paramBoActionContext, Site paramSite)
    throws UserException;

  public abstract DataObjectList getAllSiteCuidAndLabelCn(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract DataObjectList getAllSiteCuidAndRelatedSpaceCuid(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract DataObjectList getSitesByCuidList(BoActionContext paramBoActionContext, List paramList)
    throws UserException;

  public abstract DataObjectList getAllSimpleSite(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract void delPointAnalyseConf(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract int getRelatedDeleteObjCount(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract boolean isHaveRelatedObj(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract DataObjectList getRelatedDeleteObjects(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract void deleteReletedOfObject(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract void modifyJumpFiberAndPair(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract long getSiteCountByDistrictCuid(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract DboCollection getSitePageBySql(BoQueryContext paramBoQueryContext, String paramString)
    throws UserException;

  public abstract DataObjectList getSiteBtsElement()
    throws Exception;
}