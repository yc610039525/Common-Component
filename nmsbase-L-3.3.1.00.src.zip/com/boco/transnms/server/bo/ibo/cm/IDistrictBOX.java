package com.boco.transnms.server.bo.ibo.cm;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.bo.base.IBusinessObject;

public abstract interface IDistrictBOX extends IBusinessObject
{
  public abstract Boolean isEquipOrderRight(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract Integer isLeaderOrder(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract DataObjectList getAllTreePointDistrict(BoActionContext paramBoActionContext)
    throws UserException;
}