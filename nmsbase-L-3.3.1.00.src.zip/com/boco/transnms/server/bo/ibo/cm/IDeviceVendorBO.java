package com.boco.transnms.server.bo.ibo.cm;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.DeviceVendor;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.bo.base.IBusinessObject;

public abstract interface IDeviceVendorBO extends IBusinessObject
{
  public abstract void addDeviceVendor(BoActionContext paramBoActionContext, DeviceVendor paramDeviceVendor)
    throws UserException;

  public abstract void modifyDeviceVendor(BoActionContext paramBoActionContext, DeviceVendor paramDeviceVendor)
    throws UserException;

  public abstract void deleteDeviceVendor(BoActionContext paramBoActionContext, DeviceVendor paramDeviceVendor)
    throws UserException;

  public abstract DataObjectList getAllDeviceVendor(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract DeviceVendor getDeviceVendorByName(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DeviceVendor getDeviceVendorByCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;
}