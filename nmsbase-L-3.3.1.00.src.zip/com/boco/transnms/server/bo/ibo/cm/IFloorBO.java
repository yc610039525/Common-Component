package com.boco.transnms.server.bo.ibo.cm;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.Floor;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.bo.base.IBusinessObject;

public abstract interface IFloorBO extends IBusinessObject
{
  public abstract DataObjectList getAllFloor(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract Floor getFloor(BoActionContext paramBoActionContext, Long paramLong)
    throws UserException;

  public abstract Floor addFloor(BoActionContext paramBoActionContext, Floor paramFloor)
    throws UserException;

  public abstract void modifyFloor(BoActionContext paramBoActionContext, Floor paramFloor)
    throws UserException;

  public abstract void deleteFloor(BoActionContext paramBoActionContext, Long paramLong)
    throws UserException;

  public abstract void deleteBatchFloor(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract Floor getFloorByCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getFloorBySiteCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DboCollection getFloorBySiteCuidByPage(BoQueryContext paramBoQueryContext, String paramString1, String paramString2)
    throws UserException;

  public abstract DataObjectList addBatchFloor(BoActionContext paramBoActionContext, String paramString, Integer paramInteger1, Integer paramInteger2)
    throws UserException;

  public abstract int getRelatedDeleteObjCount(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract boolean isHaveRelatedObj(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract DataObjectList getRelatedDeleteObjects(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract void deleteReletedOfObject(String paramString, GenericDO paramGenericDO)
    throws UserException;
}