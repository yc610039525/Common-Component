package com.boco.transnms.server.bo.ibo.alarm;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.MailServerCfg;
import com.boco.transnms.common.dto.Mailinfo;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.server.bo.base.IBusinessObject;

public abstract interface IMailInfoBO extends IBusinessObject
{
  public abstract Mailinfo getMailInfoByCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract void addMailInfo(BoActionContext paramBoActionContext, Mailinfo paramMailinfo)
    throws UserException;

  public abstract void deleteMailInfo(BoActionContext paramBoActionContext, Mailinfo paramMailinfo)
    throws UserException;

  public abstract void modifyMailInfo(BoActionContext paramBoActionContext, Mailinfo paramMailinfo)
    throws UserException;

  public abstract void deleteMailInfo(BoActionContext paramBoActionContext, DataObjectList paramDataObjectList)
    throws UserException;

  public abstract DboCollection getMailInfoByCondition(BoQueryContext paramBoQueryContext, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws UserException;

  public abstract DboCollection getMailInfoByState()
    throws UserException;

  public abstract DboCollection getMailInfoExcel(BoQueryContext paramBoQueryContext, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws UserException;

  public abstract void deleteMailInfo(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract void addResendMailInfo(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract void addSendMailInfo(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract void saveUserEmailCfg(BoActionContext paramBoActionContext, MailServerCfg paramMailServerCfg)
    throws Exception;

  public abstract void updateUserEmailCfg(BoActionContext paramBoActionContext, MailServerCfg paramMailServerCfg)
    throws Exception;

  public abstract MailServerCfg[] getAllMailServerCfgs(BoActionContext paramBoActionContext)
    throws Exception;
}