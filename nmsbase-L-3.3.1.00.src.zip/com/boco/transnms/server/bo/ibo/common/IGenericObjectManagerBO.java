package com.boco.transnms.server.bo.ibo.common;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericAttrGroup;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.base.GenericObjectModel;
import com.boco.transnms.common.dto.base.GenericQueryModel;
import com.boco.transnms.server.bo.base.IBusinessObject;
import java.util.HashMap;

public abstract interface IGenericObjectManagerBO extends IBusinessObject
{
  public abstract DboCollection getClassListByCond(BoQueryContext paramBoQueryContext, String paramString1, String paramString2, Boolean paramBoolean)
    throws UserException;

  public abstract DboCollection getClassAllAttrs(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract GenericObjectModel getClassDynAttrByName(BoActionContext paramBoActionContext, String paramString1, String paramString2);

  public abstract DataObjectList getClassDynAttrs(BoActionContext paramBoActionContext, String paramString);

  public abstract DataObjectList getClassQueryAttrs(BoActionContext paramBoActionContext, String paramString);

  public abstract GenericAttrGroup getDefaultAttrGroup(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract void addClassDynAttr(BoActionContext paramBoActionContext, GenericObjectModel paramGenericObjectModel)
    throws UserException;

  public abstract void modifyClassDynAttr(BoActionContext paramBoActionContext, GenericObjectModel paramGenericObjectModel)
    throws UserException;

  public abstract void modifyClassDynAttrs(BoActionContext paramBoActionContext, DataObjectList paramDataObjectList)
    throws UserException;

  public abstract void modifyMultyAttrs(BoActionContext paramBoActionContext, GenericObjectModel paramGenericObjectModel, String paramString)
    throws UserException;

  public abstract void deleteClassDynAttrs(BoActionContext paramBoActionContext, DataObjectList paramDataObjectList)
    throws UserException;

  public abstract GenericDO modifyAttrVal2Type(BoActionContext paramBoActionContext, GenericDO paramGenericDO)
    throws UserException;

  public abstract void modifyDynamicClass(BoActionContext paramBoActionContext, String paramString, Boolean paramBoolean)
    throws UserException;

  public abstract DboCollection getClassAttrsOfGroup(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract DboCollection getClassDynQryAttrs(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DboCollection getClassesOfGroup(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DboCollection getAllAttrGroups(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract DboCollection getInUseAttrGroups(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract GenericAttrGroup getAttrGroupByCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract void addAttrGroup(BoActionContext paramBoActionContext, GenericAttrGroup paramGenericAttrGroup)
    throws UserException;

  public abstract void modifyAttrGroup(BoActionContext paramBoActionContext, GenericAttrGroup paramGenericAttrGroup)
    throws UserException;

  public abstract void deleteAttrGroup(BoActionContext paramBoActionContext, GenericAttrGroup paramGenericAttrGroup)
    throws UserException;

  public abstract HashMap deleteAttrGroups(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract Boolean isDynClass(BoQueryContext paramBoQueryContext, String paramString)
    throws UserException;

  public abstract Boolean isHasOtherDefaultGroup(BoActionContext paramBoActionContext, String paramString, Boolean paramBoolean)
    throws UserException;

  public abstract GenericObjectModel getClassAttrByAttrName(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws Exception;

  public abstract String modifyDateFormat(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract void addQueryModel(BoActionContext paramBoActionContext, GenericQueryModel paramGenericQueryModel)
    throws UserException;

  public abstract void modifyQueryModel(BoActionContext paramBoActionContext, GenericQueryModel paramGenericQueryModel)
    throws UserException;

  public abstract void deleteQueryModel(BoActionContext paramBoActionContext, GenericQueryModel paramGenericQueryModel)
    throws UserException;

  public abstract DboCollection getQueryModelsByClass(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract GenericQueryModel getQueryModelByCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract String convertSql(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;
}