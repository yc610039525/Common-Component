package com.boco.transnms.server.bo.ibo.common;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.bo.base.IBusinessObject;

public abstract interface IColumnConfigBO extends IBusinessObject
{
  public abstract void addColumnConfig(BoActionContext paramBoActionContext, String paramString1, String paramString2, DataObjectList paramDataObjectList)
    throws UserException;

  public abstract void deleteColumnConfig(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract DataObjectList getColumnConfigByUser(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract Boolean getIsStartAlarmStandard(BoActionContext paramBoActionContext)
    throws UserException;
}