package com.boco.transnms.server.bo.ibo.common;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.TemplateGroup;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.bo.base.IBusinessObject;

public abstract interface ITemplateGroupBO extends IBusinessObject
{
  public abstract DataObjectList getTemplateGroupsBySql(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getAllTemplateGroups(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract TemplateGroup addTemplateGroup(BoActionContext paramBoActionContext, TemplateGroup paramTemplateGroup)
    throws UserException;

  public abstract void modifyTemplateGroup(BoActionContext paramBoActionContext, TemplateGroup paramTemplateGroup)
    throws UserException;

  public abstract void deleteTemplateGroup(BoActionContext paramBoActionContext, TemplateGroup paramTemplateGroup)
    throws UserException;

  public abstract void deleteTemplateGroups(BoActionContext paramBoActionContext, DataObjectList paramDataObjectList)
    throws UserException;
}