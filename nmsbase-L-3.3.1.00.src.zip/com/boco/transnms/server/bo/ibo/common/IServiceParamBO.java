package com.boco.transnms.server.bo.ibo.common;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.ServiceParam;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.bo.base.IBusinessObject;

public abstract interface IServiceParamBO extends IBusinessObject
{
  public abstract DataObjectList getServiceParamsByType(BoActionContext paramBoActionContext, Long paramLong)
    throws UserException;

  public abstract ServiceParam getServiceParamByTypeAndName(BoActionContext paramBoActionContext, Long paramLong, String paramString)
    throws UserException;
}