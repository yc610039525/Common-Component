package com.boco.transnms.server.bo.ibo.common;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.bo.base.IBusinessObject;
import java.util.List;

public abstract interface IRelationPropertyLoadBO extends IBusinessObject
{
  public abstract GenericDO getFullObject(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract List getObjsByCuid(BoActionContext paramBoActionContext, String[] paramArrayOfString)
    throws UserException;
}