package com.boco.transnms.server.bo.ibo.common;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboBlob;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.common.Template;
import com.boco.transnms.server.bo.base.IBusinessObject;
import java.util.HashMap;
import java.util.Map;

public abstract interface ITemplateBOX extends IBusinessObject
{
  public abstract HashMap getModuleAndPortsByTemplate(BoActionContext paramBoActionContext, HashMap paramHashMap, Template paramTemplate);

  public abstract DataObjectList getTemplatesBySql(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DboCollection getWdmTemplatesBySql(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getFullTemplatesBySql(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DboBlob getTemplatePic(BoActionContext paramBoActionContext, Template paramTemplate)
    throws UserException;

  public abstract Template addTemplate(BoActionContext paramBoActionContext, Template paramTemplate)
    throws UserException;

  public abstract void modifyTemplateInfo(BoActionContext paramBoActionContext, Template paramTemplate)
    throws UserException;

  public abstract void modifyTemplatePic(BoActionContext paramBoActionContext, Template paramTemplate)
    throws UserException;

  public abstract void deleteTemplate(BoActionContext paramBoActionContext, Template paramTemplate)
    throws UserException;

  public abstract void deleteTemplates(BoActionContext paramBoActionContext, DataObjectList paramDataObjectList)
    throws UserException;

  public abstract DboBlob getTemplateDataPic(BoActionContext paramBoActionContext, Template paramTemplate)
    throws UserException;

  public abstract Template getTemplateByCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract Template getTemplateByName(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getSimpleTemplatesBySql(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract String getSysNoBySlotDN(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract Object readByXML(String paramString1, String paramString2)
    throws Exception;

  public abstract void setGenericDOPropByMap(GenericDO paramGenericDO, Map paramMap);

  public abstract int isTemplateInUse(Template paramTemplate)
    throws UserException;
}