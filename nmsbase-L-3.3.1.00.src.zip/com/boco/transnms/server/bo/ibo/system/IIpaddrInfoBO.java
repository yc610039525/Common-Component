package com.boco.transnms.server.bo.ibo.system;

import com.boco.transnms.common.dto.IpaddrInfo;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.server.bo.base.IBusinessObject;

public abstract interface IIpaddrInfoBO extends IBusinessObject
{
  public abstract IpaddrInfo addIpaddrInfo(BoActionContext paramBoActionContext, IpaddrInfo paramIpaddrInfo)
    throws Exception;

  public abstract IpaddrInfo modifyIpaddrInfo(BoActionContext paramBoActionContext, IpaddrInfo paramIpaddrInfo)
    throws Exception;

  public abstract void deleteIpaddrInfo(BoActionContext paramBoActionContext, IpaddrInfo paramIpaddrInfo)
    throws Exception;

  public abstract void deleteIpaddrInfos(BoActionContext paramBoActionContext, DataObjectList paramDataObjectList)
    throws Exception;

  public abstract DataObjectList getIpaddrInfoByCondition(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract DboCollection getIpaddrInfoByPage(BoQueryContext paramBoQueryContext, String paramString)
    throws Exception;

  public abstract IpaddrInfo getIpaddrInfo(BoActionContext paramBoActionContext, Long paramLong)
    throws Exception;

  public abstract DataObjectList addIpaddrInfos(BoActionContext paramBoActionContext, DataObjectList paramDataObjectList)
    throws Exception;

  public abstract IpaddrInfo getIpaddrInfoByIp(BoActionContext paramBoActionContext, String paramString)
    throws Exception;
}