package com.boco.transnms.server.bo.ibo.system;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DboCollection;

public abstract interface IObjinfoChangeBO
{
  public abstract DboCollection getObjInfChanageBySql(BoQueryContext paramBoQueryContext, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6)
    throws Exception;

  public abstract void deleteObjInfs(BoActionContext paramBoActionContext, Long[] paramArrayOfLong)
    throws Exception;

  public abstract void deleteAllObjInf()
    throws UserException;
}