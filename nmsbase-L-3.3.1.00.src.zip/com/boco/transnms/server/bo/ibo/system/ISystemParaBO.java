package com.boco.transnms.server.bo.ibo.system;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.QueryCondition;
import com.boco.transnms.common.dto.ShortCodeInfo;
import com.boco.transnms.common.dto.SystemPara;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.IBoActionContext;
import com.boco.transnms.common.dto.traph.TraphViewConfig;
import com.boco.transnms.server.bo.base.IBusinessObject;
import java.util.HashMap;
import java.util.Map;

public abstract interface ISystemParaBO extends IBusinessObject
{
  public abstract String getSystemParaValue(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract SystemPara getSystemPara(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract DataObjectList getSystemParas(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DboCollection getSystemParaByPage(BoQueryContext paramBoQueryContext, HashMap paramHashMap)
    throws UserException;

  public abstract DboCollection getSingleSystemPara(BoQueryContext paramBoQueryContext, HashMap paramHashMap)
    throws UserException;

  public abstract DboCollection addSingleSystemPara(BoQueryContext paramBoQueryContext, HashMap paramHashMap)
    throws UserException;

  public abstract void delSingleSystemPara(BoQueryContext paramBoQueryContext, HashMap paramHashMap)
    throws UserException;

  public abstract DataObjectList getDistinctTable(BoQueryContext paramBoQueryContext, String paramString1, String paramString2)
    throws UserException;

  public abstract Boolean getSmsSwitch();

  public abstract Map getTraphNameAndTraphAlias(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract TraphViewConfig getTraphViewConfigBySystemPara(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract DboCollection getShortCodeByCondition(BoQueryContext paramBoQueryContext, String paramString1, String paramString2)
    throws Exception;

  public abstract ShortCodeInfo addShortCode(BoQueryContext paramBoQueryContext, ShortCodeInfo paramShortCodeInfo)
    throws Exception;

  public abstract void deleteShortCode(BoActionContext paramBoActionContext, String[] paramArrayOfString)
    throws Exception;

  public abstract ShortCodeInfo getShortCodeByCuid(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract void modifyShortCodeByCuid(BoActionContext paramBoActionContext, ShortCodeInfo paramShortCodeInfo)
    throws Exception;

  public abstract boolean isAdded(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract DboCollection getShortCodeExcelByCondition(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract void modifySystemPara(BoActionContext paramBoActionContext, String paramString1, String paramString2, String paramString3)
    throws UserException;

  public abstract void addDevInfoImpConfig(DataObjectList paramDataObjectList)
    throws UserException;

  public abstract DboCollection getDevInfoImpConfig()
    throws UserException;

  public abstract SystemPara createSystemPara(BoActionContext paramBoActionContext, String paramString1, String paramString2, String paramString3, String paramString4)
    throws UserException;

  public abstract DataObjectList getSystemParaByClassName(IBoActionContext paramIBoActionContext, String paramString)
    throws UserException;

  public abstract HashMap getSystemRuntimeCfg(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract String getTnmsRunTimeValue(String paramString);

  public abstract void addQueryCondition(BoActionContext paramBoActionContext, QueryCondition paramQueryCondition)
    throws UserException;

  public abstract void deleteQueryConditionBySQL(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getQueryConditionBySql(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract void modifyQueryCondition(BoActionContext paramBoActionContext, DataObjectList paramDataObjectList)
    throws UserException;
}