package com.boco.transnms.server.bo.ibo.traph;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.UserObjectCfg;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.server.bo.base.IBusinessObject;

public abstract interface IDefaultSiteSettingBO extends IBusinessObject
{
  public abstract DboCollection getDefaultSiteSetting(BoQueryContext paramBoQueryContext, String paramString)
    throws UserException;

  public abstract DboCollection getDefaultRoomSetting(BoQueryContext paramBoQueryContext, String paramString)
    throws UserException;

  public abstract DboCollection getDefaultSiteSettingForTraphEdit(BoQueryContext paramBoQueryContext, String paramString)
    throws UserException;

  public abstract DboCollection getDefaultRoomSettingForTraphEdit(BoQueryContext paramBoQueryContext, String paramString)
    throws UserException;

  public abstract UserObjectCfg addDefaultSiteSetting(BoActionContext paramBoActionContext, UserObjectCfg paramUserObjectCfg)
    throws UserException;

  public abstract UserObjectCfg addDefaultRoomSetting(BoActionContext paramBoActionContext, UserObjectCfg paramUserObjectCfg)
    throws UserException;

  public abstract void deleteDefaultSiteSetting(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract void deleteDefaultRoomSetting(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getDefaultSiteSettingnew(BoQueryContext paramBoQueryContext, String paramString)
    throws UserException;

  public abstract DataObjectList getDefaultAccesspointSettingnew(BoQueryContext paramBoQueryContext, String paramString)
    throws UserException;

  public abstract DataObjectList getDefaultRoomSettingnew(BoQueryContext paramBoQueryContext, String paramString)
    throws UserException;

  public abstract DataObjectList getDefaultSiteSettingForTraphEditnew(BoQueryContext paramBoQueryContext, String paramString)
    throws UserException;

  public abstract DataObjectList getDefaultRoomSettingForTraphEditnew(BoQueryContext paramBoQueryContext, String paramString)
    throws UserException;
}