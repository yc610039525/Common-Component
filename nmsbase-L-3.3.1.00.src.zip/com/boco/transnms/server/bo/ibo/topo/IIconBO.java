package com.boco.transnms.server.bo.ibo.topo;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.Icon;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.bo.base.IBusinessObject;
import java.util.Map;

public abstract interface IIconBO extends IBusinessObject
{
  public abstract Icon getIconByCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getIcons(BoActionContext paramBoActionContext, DataObjectList paramDataObjectList)
    throws UserException;

  public abstract DataObjectList getIconModuleAndAll(BoActionContext paramBoActionContext, Icon paramIcon)
    throws UserException;

  public abstract Map getIconModAndIcon(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract DataObjectList getIconSql(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract Icon modifyIcon(BoActionContext paramBoActionContext, Icon paramIcon)
    throws UserException;

  public abstract Map getAllIcon(BoActionContext paramBoActionContext)
    throws UserException;
}