package com.boco.transnms.server.bo.ibo.topo;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.ThemeMap;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.bo.base.IBusinessObject;

public abstract interface IThemeMapBO extends IBusinessObject
{
  public abstract ThemeMap addThemeMap(BoActionContext paramBoActionContext, ThemeMap paramThemeMap)
    throws UserException;

  public abstract void modifyThemeMap(BoActionContext paramBoActionContext, ThemeMap paramThemeMap)
    throws UserException;

  public abstract void deleteThemeMap(BoActionContext paramBoActionContext, ThemeMap paramThemeMap)
    throws UserException;

  public abstract ThemeMap getThemeMapByUser(BoActionContext paramBoActionContext, String paramString, Long paramLong)
    throws UserException;

  public abstract ThemeMap getThemeMapByCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getAllThemeMapsByUserCUID(BoActionContext paramBoActionContext, String paramString, Long paramLong)
    throws UserException;

  public abstract void addDefaultThemeMapByUser(BoActionContext paramBoActionContext, DataObjectList paramDataObjectList)
    throws UserException;

  public abstract ThemeMap getDefaultThemeMap(BoActionContext paramBoActionContext, Long paramLong);

  public abstract String getTransSysMedia(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract DataObjectList getTransSystemBySelCondition(BoActionContext paramBoActionContext, GenericDO paramGenericDO)
    throws UserException;

  public abstract ThemeMap getThemeMapByUserAndLabelCn(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract ThemeMap getThemeMap(BoActionContext paramBoActionContext, Long paramLong)
    throws UserException;

  public abstract DataObjectList getPtnDisplayThemeMaps(BoActionContext paramBoActionContext)
    throws UserException;
}