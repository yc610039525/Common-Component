package com.boco.transnms.server.bo.ibo.topo;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.ThemeMap;
import com.boco.transnms.common.dto.ThemeMapToObject;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.bo.base.IBusinessObject;

public abstract interface IThemeMapToObjectBO extends IBusinessObject
{
  public abstract ThemeMapToObject addThemeMapToObject(BoActionContext paramBoActionContext, ThemeMapToObject paramThemeMapToObject)
    throws UserException;

  public abstract DataObjectList addThemeMapToObjects(BoActionContext paramBoActionContext, DataObjectList paramDataObjectList)
    throws UserException;

  public abstract void deleteObjectByThemeMapCuid(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract void deleteThemeMapToObjects(BoActionContext paramBoActionContext, DataObjectList paramDataObjectList)
    throws UserException;

  public abstract DataObjectList getThemeMapToObjectByUser(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract DataObjectList getThemeMapToObjectByObjectTypes(BoActionContext paramBoActionContext, String paramString, String[] paramArrayOfString)
    throws UserException;

  public abstract DataObjectList getThemeMapObjectsByUser(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract ThemeMapToObject getThemeMapToObjectByCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract void deleteObjectOnlyByThemeMapCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getObjectsByThemeMapCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getDeletedThemeMapOjbect(BoActionContext paramBoActionContext, ThemeMap paramThemeMap)
    throws UserException;
}