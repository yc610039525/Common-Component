package com.boco.transnms.server.bo.ibo.topo;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.SystemMap;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.dm.LocatedPoint;
import com.boco.transnms.server.bo.base.IBusinessObject;
import java.util.HashSet;
import java.util.List;

public abstract interface ISystemMapBO extends IBusinessObject
{
  public abstract DataObjectList getLocateObjectsByMap(BoActionContext paramBoActionContext, SystemMap paramSystemMap, GenericDO paramGenericDO)
    throws UserException;

  public abstract SystemMap addSystemMap(BoActionContext paramBoActionContext, SystemMap paramSystemMap)
    throws UserException;

  public abstract SystemMap modifySystemMap(BoActionContext paramBoActionContext, SystemMap paramSystemMap)
    throws UserException;

  public abstract void deleteSystemMap(BoActionContext paramBoActionContext, SystemMap paramSystemMap)
    throws UserException;

  public abstract DataObjectList getAllSystemMaps(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract SystemMap getSystemMapByCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getSystemMapByName(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract List<LocatedPoint> getLocateSites(BoActionContext paramBoActionContext, SystemMap paramSystemMap, HashSet paramHashSet)
    throws UserException;

  public abstract List<LocatedPoint> getLocateObjectsByMapCuid(BoActionContext paramBoActionContext, String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract SystemMap getDefaultSystemMap(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getDefaultSystemMapsByDistrictDuids(BoActionContext paramBoActionContext, String[] paramArrayOfString)
    throws UserException;

  public abstract int getRelatedDeleteObjCount(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract boolean isHaveRelatedObj(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract DataObjectList getRelatedDeleteObjects(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract void deleteReletedOfObject(String paramString, GenericDO paramGenericDO)
    throws UserException;
}