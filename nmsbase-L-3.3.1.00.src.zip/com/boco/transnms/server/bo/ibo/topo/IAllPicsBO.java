package com.boco.transnms.server.bo.ibo.topo;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.misc.AllPics;
import com.boco.transnms.server.bo.base.IBusinessObject;

public abstract interface IAllPicsBO extends IBusinessObject
{
  public abstract void addAllPics(BoActionContext paramBoActionContext, AllPics paramAllPics)
    throws UserException;

  public abstract void addDistinctAllPics(BoActionContext paramBoActionContext, AllPics paramAllPics)
    throws UserException;

  public abstract void modifyAllPicsPicField(BoActionContext paramBoActionContext, AllPics paramAllPics)
    throws UserException;

  public abstract void deleteAllPics(BoActionContext paramBoActionContext, AllPics paramAllPics)
    throws UserException;

  public abstract AllPics getAllPics(BoActionContext paramBoActionContext, AllPics paramAllPics)
    throws Exception;

  public abstract DataObjectList getAllPictures(BoActionContext paramBoActionContext, AllPics paramAllPics)
    throws UserException;

  public abstract DataObjectList modifyAllPictures(BoActionContext paramBoActionContext, DataObjectList paramDataObjectList)
    throws UserException;

  public abstract DataObjectList getAllSimplePics(BoActionContext paramBoActionContext, String paramString)
    throws UserException;
}