package com.boco.transnms.server.bo.ibo.topo;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.MapToObject;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.bo.base.IBusinessObject;

public abstract interface IMapToObjectBO extends IBusinessObject
{
  public abstract MapToObject addMapToObject(BoActionContext paramBoActionContext, MapToObject paramMapToObject)
    throws UserException;

  public abstract MapToObject modifyMapToObject(BoActionContext paramBoActionContext, MapToObject paramMapToObject)
    throws UserException;

  public abstract void deleteMapToObject(BoActionContext paramBoActionContext, MapToObject paramMapToObject)
    throws UserException;

  public abstract void deleteMapToObjectsBySql(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract void deleteMapToObjectByKey(BoActionContext paramBoActionContext, MapToObject paramMapToObject)
    throws UserException;

  public abstract void deleteMapToObjectByPointCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getAllMapToObjects(BoActionContext paramBoActionContext)
    throws UserException;
}