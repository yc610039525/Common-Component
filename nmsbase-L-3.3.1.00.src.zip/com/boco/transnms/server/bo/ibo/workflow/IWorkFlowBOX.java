package com.boco.transnms.server.bo.ibo.workflow;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.workflow.SharkRole;
import com.boco.transnms.common.dto.workflow.SharkUser;
import com.boco.transnms.server.bo.base.IBusinessObject;
import java.util.List;

public abstract interface IWorkFlowBOX extends IBusinessObject
{
  public abstract void addUser(BoActionContext paramBoActionContext, SharkUser paramSharkUser)
    throws UserException;

  public abstract void addUserRoleMap(BoActionContext paramBoActionContext, String paramString1, String paramString2, String paramString3, String paramString4)
    throws UserException;

  public abstract Boolean modifySharkUser(BoActionContext paramBoActionContext, String paramString1, String paramString2, String paramString3, String paramString4)
    throws UserException;

  public abstract void addUserRoleMappings(BoActionContext paramBoActionContext, String paramString, List<String[]> paramList)
    throws UserException;

  public abstract void delUserRoleMap(BoActionContext paramBoActionContext, String paramString1, String paramString2, String paramString3, String paramString4)
    throws UserException;

  public abstract void delUser(BoActionContext paramBoActionContext, SharkUser paramSharkUser)
    throws UserException;

  public abstract SharkUser[] getAllUserByRole(BoActionContext paramBoActionContext, String paramString1, String paramString2, String paramString3)
    throws UserException;

  public abstract SharkUser[] getAllUserByRole(BoActionContext paramBoActionContext, SharkRole paramSharkRole, String paramString1, String paramString2)
    throws UserException;

  public abstract SharkRole[] getAllRoleByUser(BoActionContext paramBoActionContext, String paramString1, String paramString2, String paramString3)
    throws UserException;

  public abstract Boolean checkUserRole(BoActionContext paramBoActionContext, String paramString1, String paramString2, String paramString3)
    throws UserException;
}