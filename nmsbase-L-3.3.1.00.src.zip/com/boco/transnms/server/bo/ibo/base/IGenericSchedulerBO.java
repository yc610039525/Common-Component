package com.boco.transnms.server.bo.ibo.base;

import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.server.bo.base.IBusinessObject;
import org.quartz.SchedulerException;

public abstract interface IGenericSchedulerBO extends IBusinessObject
{
  public abstract void addScheduler(BoActionContext paramBoActionContext, String paramString1, String paramString2, String paramString3);

  public abstract boolean isJobExecute(String paramString)
    throws SchedulerException;

  public abstract void deleteJob(String paramString1, String paramString2);

  public abstract void rescheduleJob(String paramString1, String paramString2, String paramString3);

  public abstract boolean isJobExist(String paramString1, String paramString2)
    throws SchedulerException;
}