package com.boco.transnms.server.bo.ibo.base;

public abstract interface IReloadCacheBO
{
  public abstract void initCache();

  public abstract void clearCache();

  public abstract void reInitCache();
}