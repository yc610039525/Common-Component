package com.boco.transnms.server.bo.ibo.misc;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.District;
import com.boco.transnms.common.dto.FunctionTreeNode;
import com.boco.transnms.common.dto.ModuleClickLog;
import com.boco.transnms.common.dto.Organization;
import com.boco.transnms.common.dto.SysUser;
import com.boco.transnms.common.dto.UserPasswordSecurity;
import com.boco.transnms.common.dto.UserRole;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.base.IBoActionContext;
import com.boco.transnms.common.dto.workflow.SharkRole;
import com.boco.transnms.common.dto.workflow.SharkUser;
import com.boco.transnms.server.bo.ibo.IBasicSecurityBO;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

public abstract interface ISecurityBO extends IBasicSecurityBO
{
  public abstract int queryIsExistData(String paramString)
    throws UserException;

  public abstract void updateOnlineUserCountByDate(int paramInt, String paramString)
    throws UserException;

  public abstract void insertOnlineUserCount(int paramInt, String paramString)
    throws UserException;

  public abstract SysUser login(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract void addLogoutLog(BoActionContext paramBoActionContext);

  public abstract void addLogoutLogHaveSystemName(BoActionContext paramBoActionContext, String paramString);

  public abstract void addLoginLog(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract String addLoginLogHaveSystemName(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract SysUser loginNoLog(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract List<String> getUserActions(BoActionContext paramBoActionContext, SysUser paramSysUser)
    throws UserException;

  public abstract DataObjectList getUserDistricts(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract List<String> getDistrictActions(BoActionContext paramBoActionContext, String paramString1, String paramString2);

  public abstract DataObjectList getActionDistricts(IBoActionContext paramIBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract void isDistrictsPermitted(IBoActionContext paramIBoActionContext, String paramString1, String paramString2, String[] paramArrayOfString)
    throws UserException;

  public abstract Organization addOrganization(BoActionContext paramBoActionContext, Organization paramOrganization)
    throws UserException;

  public abstract SysUser addSysUser(BoActionContext paramBoActionContext, SysUser paramSysUser)
    throws UserException;

  public abstract SysUser addCloneSysUser(BoActionContext paramBoActionContext, SysUser paramSysUser)
    throws UserException;

  public abstract void deleteSysUser(BoActionContext paramBoActionContext, Long paramLong)
    throws UserException;

  public abstract void modifySysUser(BoActionContext paramBoActionContext, SysUser paramSysUser)
    throws UserException;

  public abstract List getAllOrganizationByDistrict(BoActionContext paramBoActionContext, District paramDistrict)
    throws UserException;

  public abstract DataObjectList getReceiverOrganization(BoActionContext paramBoActionContext, String paramString1, String paramString2, String paramString3)
    throws UserException;

  public abstract Vector getReceiverUser(BoActionContext paramBoActionContext, String paramString1, String paramString2, String paramString3)
    throws UserException;

  public abstract DataObjectList getAllOrgsByUserDisCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getAllUserRole(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract UserRole getUserRole(BoActionContext paramBoActionContext, Long paramLong)
    throws UserException;

  public abstract UserRole getUserRoleByCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getAllFunctionNode(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract DataObjectList getAllFunctionNodeAndRolePoint(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract UserRole addRoleAndRoleFunPoint(BoActionContext paramBoActionContext, UserRole paramUserRole, String[] paramArrayOfString)
    throws Exception;

  public abstract DataObjectList getRoleFunPoint(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract void modifyRoleAndRoleFunPoint(BoActionContext paramBoActionContext, UserRole paramUserRole, String[] paramArrayOfString)
    throws Exception;

  public abstract Organization getOrganizationByCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DboCollection getLog(BoQueryContext paramBoQueryContext, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7)
    throws Exception;

  public abstract void deleteLog(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DboCollection getLoginLog(BoQueryContext paramBoQueryContext, Long paramLong, String paramString1, String paramString2, String paramString3)
    throws Exception;

  public abstract void modifyOrganization(BoActionContext paramBoActionContext, Organization paramOrganization)
    throws Exception;

  public abstract Organization getOrganization(BoActionContext paramBoActionContext, Long paramLong)
    throws Exception;

  public abstract DataObjectList getAllChildOrganization(BoActionContext paramBoActionContext, Long paramLong)
    throws Exception;

  public abstract DataObjectList getAllOrganization(BoActionContext paramBoActionContext)
    throws Exception;

  public abstract DataObjectList getAllSysUser(BoActionContext paramBoActionContext)
    throws Exception;

  public abstract SysUser getSysUser(BoActionContext paramBoActionContext, Long paramLong)
    throws Exception;

  public abstract void deleteRoleAndRoleFunPoint(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract void addUserHaveRole(BoActionContext paramBoActionContext, String paramString1, String paramString2, String paramString3)
    throws Exception;

  public abstract void deleteUserHaveRole(BoActionContext paramBoActionContext, String paramString1, String paramString2, String paramString3)
    throws Exception;

  public abstract void addUserHaveObject(BoActionContext paramBoActionContext, String paramString1, String paramString2, Long paramLong, Boolean paramBoolean)
    throws Exception;

  public abstract DataObjectList getUserHaveObjects(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract DataObjectList getUserHaveRole(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws Exception;

  public abstract String getRoleName(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract String getLSHbyUserCuid(BoActionContext paramBoActionContext, String paramString, Long paramLong)
    throws Exception;

  public abstract SysUser getSysUserByCuid(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract FunctionTreeNode getFunctionTreeNode(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract FunctionTreeNode getFunctionTreeNodeByObjectId(BoActionContext paramBoActionContext, Long paramLong)
    throws Exception;

  public abstract FunctionTreeNode modifyFunctionTreeNode(BoActionContext paramBoActionContext, FunctionTreeNode paramFunctionTreeNode)
    throws Exception;

  public abstract DataObjectList getSysUserBySql(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract FunctionTreeNode addFunctionTreeNode(BoActionContext paramBoActionContext, FunctionTreeNode paramFunctionTreeNode)
    throws Exception;

  public abstract void deleteFunctionTreeNode(BoActionContext paramBoActionContext, DataObjectList paramDataObjectList)
    throws Exception;

  public abstract void deleteFunctionTreeNodeByCuid(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract void delLoginLogs(BoQueryContext paramBoQueryContext, String[] paramArrayOfString)
    throws Exception;

  public abstract DboCollection getLoginlogs(BoActionContext paramBoActionContext, Long paramLong, String paramString1, String paramString2, String paramString3, String paramString4)
    throws Exception;

  public abstract DboCollection getLoginlogsForExcel(BoActionContext paramBoActionContext, String paramString1, String paramString2, String paramString3, String paramString4)
    throws Exception;

  public abstract Integer getSystemLevel(BoActionContext paramBoActionContext)
    throws Exception;

  public abstract District getSystemDistrict(BoActionContext paramBoActionContext)
    throws Exception;

  public abstract DataObjectList getUserRoleByRoleType(BoActionContext paramBoActionContext, String paramString);

  public abstract DataObjectList getBackupEquipRole(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract void deleteUserHaveRoleByUserCuidAndRoleCuid(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws Exception;

  public abstract DataObjectList getOrganizationByQuery(BoActionContext paramBoActionContext, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws UserException;

  public abstract void deleteOrganizationByCuids(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract DboCollection getSysUserByPage(BoQueryContext paramBoQueryContext, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7)
    throws UserException;

  public abstract DboCollection getSysUserByPageNew(BoQueryContext paramBoQueryContext, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8)
    throws UserException;

  public abstract DboCollection getSystemLog(BoQueryContext paramBoQueryContext, HashMap paramHashMap, String paramString)
    throws UserException;

  public abstract void delSystemLog(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DboCollection getLoginLogBypage(BoQueryContext paramBoQueryContext, HashMap paramHashMap, String paramString)
    throws UserException;

  public abstract void delLoginLogsByCuids(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract List getAllUpOrgsByUserOrgCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract void addFunctionTreeNodeFromXML(BoActionContext paramBoActionContext, DataObjectList paramDataObjectList)
    throws Exception;

  public abstract Boolean getHaveSubDistrictRole(BoActionContext paramBoActionContext, String paramString, District paramDistrict)
    throws Exception;

  public abstract Boolean setIncludeSubDistrict(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws Exception;

  public abstract DboCollection getSysUsersByOrgCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DboCollection getWarningLimit(BoActionContext paramBoActionContext, int paramInt);

  public abstract SharkRole[] getAllRoleByUser(BoActionContext paramBoActionContext, String paramString1, String paramString2, String paramString3)
    throws UserException;

  public abstract SharkUser[] getAllUserByRole(BoActionContext paramBoActionContext, String paramString1, String paramString2, String paramString3)
    throws UserException;

  public abstract Boolean isHasRoleByUser(BoActionContext paramBoActionContext, String paramString1, String paramString2, String paramString3, String paramString4)
    throws UserException;

  public abstract DboCollection getUserWorkFlowRole(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract DataObjectList getUserHaveRoleByUserCuid(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract void deleteAllUserHaveRoleByUserCuid(BoActionContext paramBoActionContext, ArrayList<String> paramArrayList)
    throws Exception;

  public abstract void copyUserRight(BoActionContext paramBoActionContext, String paramString, ArrayList<String> paramArrayList)
    throws Exception;

  public abstract DataObjectList getAllChildOrganizationByCUID(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract DataObjectList getSameDistrictUsers(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract List getAllORG(BoActionContext paramBoActionContext)
    throws Exception;

  public abstract String getUserOrgByName(String paramString)
    throws Exception;

  public abstract SysUser getUserByUserName(String paramString)
    throws Exception;

  public abstract boolean hasRole(String paramString1, String paramString2)
    throws UserException, Exception;

  public abstract DataObjectList getReportFunctionNodeByUserCuid(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract int getPasswordRepeatCount(BoActionContext paramBoActionContext)
    throws Exception;

  public abstract int modifyPasswordRepeatCount(BoActionContext paramBoActionContext, int paramInt)
    throws Exception;

  public abstract int getPasswordAvilableTime(BoActionContext paramBoActionContext, SysUser paramSysUser)
    throws Exception;

  public abstract int modifyPasswordAvilableTime(BoActionContext paramBoActionContext, int paramInt)
    throws Exception;

  public abstract boolean isPasswordAvilable(BoActionContext paramBoActionContext, SysUser paramSysUser)
    throws Exception;

  public abstract DboCollection getUserNameByOrgCuid(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract void modifyUserTheme(BoActionContext paramBoActionContext, SysUser paramSysUser)
    throws UserException;

  public abstract void addLocalReportFunctionTreeNodeFromXML(BoActionContext paramBoActionContext, DataObjectList paramDataObjectList)
    throws Exception;

  public abstract DataObjectList getAllLocalReportFunctionNode(BoActionContext paramBoActionContext)
    throws Exception;

  public abstract boolean modifyIsConstraintPassword(BoActionContext paramBoActionContext, boolean paramBoolean)
    throws Exception;

  public abstract boolean getIsConstraintPassword(BoActionContext paramBoActionContext)
    throws Exception;

  public abstract void deleteRecordToManByUsercuid(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract DataObjectList getOrganizationBySql(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract DboCollection getSecurityByName(BoQueryContext paramBoQueryContext, String paramString1, String paramString2)
    throws Exception;

  public abstract UserPasswordSecurity addUserPasswordSecurity(BoActionContext paramBoActionContext, UserPasswordSecurity paramUserPasswordSecurity)
    throws Exception;

  public abstract UserPasswordSecurity getUserPasswordSecurity(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract DboCollection isSecurityUsed(BoQueryContext paramBoQueryContext, String paramString)
    throws Exception;

  public abstract void deleteUserPasswordSecurity(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract void modifyUserPasswordSecurity(BoActionContext paramBoActionContext, UserPasswordSecurity paramUserPasswordSecurity)
    throws Exception;

  public abstract boolean isSameSecurityName(BoQueryContext paramBoQueryContext, String paramString)
    throws Exception;

  public abstract boolean isSameSecurityNameModify(BoQueryContext paramBoQueryContext, String paramString1, String paramString2)
    throws Exception;

  public abstract String isPasswordValidCanBeUse(BoActionContext paramBoActionContext, SysUser paramSysUser, String paramString)
    throws Exception;

  public abstract DataObjectList getFunctionNodeByUserCuid(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract SysUser loginNoCheckPassword(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract void modifySysUserByNetAdjust(BoActionContext paramBoActionContext, SysUser paramSysUser)
    throws UserException;

  public abstract String addUserToCust(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract String getCustStrbyUserId(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract String getCustStrByUserIdAndCustName(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract DataObjectList getUserManagerDistrictByuserCuid(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract void modifyAttempReceivrBySysUser(BoActionContext paramBoActionContext, SysUser paramSysUser)
    throws UserException;

  public abstract void deleteAttempReceivrBySysUser(BoActionContext paramBoActionContext, SysUser paramSysUser)
    throws UserException;

  public abstract Boolean supportLostPath(BoActionContext paramBoActionContext);

  public abstract Boolean getAlcatelLucentManager(BoActionContext paramBoActionContext);

  public abstract Boolean getOpticalManager(BoActionContext paramBoActionContext);

  public abstract void initUserDistrictRoles()
    throws Exception;

  public abstract DboCollection getSubSysUserByPage(BoQueryContext paramBoQueryContext, String paramString1, String paramString2)
    throws Exception;

  public abstract SysUser addSubSysUser(BoActionContext paramBoActionContext, SysUser paramSysUser)
    throws UserException;

  public abstract SysUser getSubSysUser(BoActionContext paramBoActionContext, long paramLong)
    throws Exception;

  public abstract void deleteSubSysUser(BoActionContext paramBoActionContext, long paramLong)
    throws Exception;

  public abstract SysUser modifySubSysUser(BoActionContext paramBoActionContext, SysUser paramSysUser)
    throws Exception;

  public abstract void addUserToTraph(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws Exception;

  public abstract DboCollection validateRole(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws Exception;

  public abstract void checkUserByAccountDate(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract String addSysuserBy4A(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract String modifySysuserBy4A(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract String deleteSysuserBy4A(BoActionContext paramBoActionContext, String paramString)
    throws Exception;

  public abstract void addAuditOptionLog(BoActionContext paramBoActionContext, Map paramMap)
    throws UserException;

  public abstract DboCollection getSimQrySysUser(BoQueryContext paramBoQueryContext, HashMap paramHashMap)
    throws UserException;

  public abstract int getLoginUserCount(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract void addLoginUserCount(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract void removeLoginUserCount(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract void removeAllLoginUserCount(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract int getRelatedDeleteObjCount(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract boolean isHaveRelatedObj(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract DataObjectList getRelatedDeleteObjects(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract void deleteReletedOfObject(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract int getSysUserCounts(BoActionContext paramBoActionContext)
    throws Exception;

  public abstract void addModuleClickLogs(ArrayList<ModuleClickLog> paramArrayList)
    throws UserException;

  public abstract void addModuleClickLog(BoActionContext paramBoActionContext, ModuleClickLog paramModuleClickLog)
    throws UserException;

  public abstract void addModuleClickLog(ModuleClickLog paramModuleClickLog)
    throws UserException;

  public abstract DboCollection getSysUserInfo(BoQueryContext paramBoQueryContext, String paramString1, String paramString2, String paramString3)
    throws Exception;

  public abstract DataObjectList checkFunctionPermissions(BoQueryContext paramBoQueryContext, String paramString1, String paramString2)
    throws Exception;

  public abstract DataObjectList getOrganization(String paramString)
    throws Exception;
}