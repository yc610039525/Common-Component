package com.boco.transnms.server.bo.ibo.misc;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.misc.DevState;

public abstract interface ISystemDevManageBO extends ISystemManageBOX
{
  public abstract DevState regDevState(BoActionContext paramBoActionContext, DevState paramDevState)
    throws UserException;

  public abstract void regDevState(BoActionContext paramBoActionContext, DataObjectList paramDataObjectList)
    throws UserException;

  public abstract DataObjectList getAllDevState(BoActionContext paramBoActionContext)
    throws UserException;

  public abstract String getServerAddress()
    throws UserException;
}