package com.boco.transnms.server.bo.ibo.misc;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.Room;
import com.boco.transnms.common.dto.Site;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.common.ClientState;
import com.boco.transnms.common.dto.misc.DevState;
import com.boco.transnms.server.bo.base.IBusinessObject;

public abstract interface ISystemManageBOX extends IBusinessObject
{
  public abstract Boolean isHasRuningTask(BoActionContext paramBoActionContext, Room paramRoom)
    throws UserException;

  public abstract Boolean isHasRuningTask(BoActionContext paramBoActionContext, Site paramSite)
    throws UserException;

  public abstract DevState getServerState(BoActionContext paramBoActionContext, ClientState paramClientState)
    throws UserException;

  public abstract String getRoomRuntask(BoActionContext paramBoActionContext, Room paramRoom1, Room paramRoom2)
    throws UserException;
}