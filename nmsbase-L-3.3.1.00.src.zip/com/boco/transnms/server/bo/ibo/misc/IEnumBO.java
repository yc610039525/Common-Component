package com.boco.transnms.server.bo.ibo.misc;

import com.boco.common.util.except.UserException;
import com.boco.common.util.lang.GenericEnum;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.bo.base.IBusinessObject;

public abstract interface IEnumBO extends IBusinessObject
{
  public abstract GenericEnum getEnum(String paramString)
    throws UserException;

  public abstract GenericEnum getEnum(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract void modifyEnum(BoActionContext paramBoActionContext, String paramString1, String paramString2)
    throws UserException;

  public abstract DataObjectList getExcelCache(String paramString1, String paramString2, String paramString3, String paramString4)
    throws Exception;
}