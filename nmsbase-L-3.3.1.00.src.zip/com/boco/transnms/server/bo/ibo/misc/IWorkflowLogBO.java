package com.boco.transnms.server.bo.ibo.misc;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.WorkflowLog;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.server.bo.base.IBusinessObject;

public abstract interface IWorkflowLogBO extends IBusinessObject
{
  public abstract WorkflowLog getWorkflowLogByCuid(BoActionContext paramBoActionContext, String paramString)
    throws UserException;

  public abstract void addWorkflowLog(BoActionContext paramBoActionContext, WorkflowLog paramWorkflowLog)
    throws UserException;

  public abstract void deleteWorkflowLog(BoActionContext paramBoActionContext, WorkflowLog paramWorkflowLog)
    throws UserException;

  public abstract void modifyWorkflowLog(BoActionContext paramBoActionContext, WorkflowLog paramWorkflowLog)
    throws UserException;

  public abstract void deleteWorkflowLog(BoActionContext paramBoActionContext, DataObjectList paramDataObjectList)
    throws UserException;

  public abstract DboCollection getWorkflowLogByCondition(BoQueryContext paramBoQueryContext, String paramString1, String paramString2, String paramString3)
    throws UserException;

  public abstract DboCollection getWorkflowLogByCondition(BoQueryContext paramBoQueryContext, String paramString1, String paramString2)
    throws UserException;
}