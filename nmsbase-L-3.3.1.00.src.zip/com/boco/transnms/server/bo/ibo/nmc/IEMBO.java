package com.boco.transnms.server.bo.ibo.nmc;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.misc.LayerRate;
import com.boco.transnms.server.bo.base.IBusinessObject;

public abstract interface IEMBO extends IBusinessObject
{
  public abstract Integer getLayerRate(Integer paramInteger1, Integer paramInteger2)
    throws UserException;

  public abstract Integer getSegType(BoActionContext paramBoActionContext, Short paramShort);

  public abstract LayerRate getLayerRateByValue(String paramString);

  public abstract LayerRate getLayerRateByKey(String paramString);
}