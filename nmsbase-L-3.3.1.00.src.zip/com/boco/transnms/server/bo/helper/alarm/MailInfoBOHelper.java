package com.boco.transnms.server.bo.helper.alarm;

public class MailInfoBOHelper
{
  public static final String BO_NAME = "IMailInfoBO";

  public static class ActionName
  {
    public static final String addMailInfo = "IMailInfoBO.addMailInfo";
    public static final String modifyMailInfo = "IMailInfoBO.modifyMailInfo";
    public static final String deleteMailInfo = "IMailInfoBO.deleteMailInfo";
    public static final String addSendMailInfo = "IMailInfoBO.addSendMailInfo";
    public static final String addResendMailInfo = "IMailInfoBO.addResendMailInfo";
    public static final String getMailInfoByCondition = "IMailInfoBO.getMailInfoByCondition";
    public static final String getMailInfoExcel = "IMailInfoBO.getMailInfoExcel";
    public static final String saveUserEmailCfg = "IMailInfoBO.saveUserEmailCfg";
    public static final String updateUserEmailCfg = "IMailInfoBO.updateUserEmailCfg";
    public static final String getAllMailServerCfgs = "IMailInfoBO.getAllMailServerCfgs";
  }
}