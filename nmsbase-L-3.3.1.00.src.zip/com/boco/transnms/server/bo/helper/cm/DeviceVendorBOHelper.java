package com.boco.transnms.server.bo.helper.cm;

public class DeviceVendorBOHelper
{
  public static final String BO_NAME = "IDeviceVendorBO";

  public static class ActionName
  {
    public static final String addDeviceVendor = "IDeviceVendorBO.addDeviceVendor";
    public static final String modifyDeviceVendor = "IDeviceVendorBO.modifyDeviceVendor";
    public static final String deleteDeviceVendor = "IDeviceVendorBO.deleteDeviceVendor";
    public static final String getAllDeviceVendor = "IDeviceVendorBO.getAllDeviceVendor";
    public static final String getDeviceVendorByName = "IDeviceVendorBO.getDeviceVendorByName";
    public static final String getDeviceVendorByCuid = "IDeviceVendorBO.getDeviceVendorByCuid";
  }
}