package com.boco.transnms.server.bo.helper.cm;

public class CallBoardBOHelper
{
  public static final String BO_NAME = "ICallBoardBO";

  public static class ActionName
  {
    public static final String getCallBoard = "ICallBoardBO.getCallBoard";
    public static final String addCallBoard = "ICallBoardBO.addCallBoard";
    public static final String modifyCallBoard = "ICallBoardBO.modifyCallBoard";
    public static final String deleteCallBoard = "ICallBoardBO.deleteCallBoard";
    public static final String getAllCallBoard = "ICallBoardBO.getAllCallBoard";
    public static final String getCallBoardByCondition = "ICallBoardBO.getCallBoardByCondition";
  }
}