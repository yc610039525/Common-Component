package com.boco.transnms.server.bo.helper.cm;

public class VersionManagerBOHelper
{
  public static final String BO_NAME = "IVersionManagerBO";

  public static class ActionName
  {
    public static final String getVersionManager = "IVersionManagerBO.getVersionManager";
    public static final String addVersionManager = "IVersionManagerBO.addVersionManager";
    public static final String modifyVersionManager = "IVersionManagerBO.modifyVersionManager";
    public static final String deleteVersionManager = "IVersionManagerBO.deleteVersionManager";
    public static final String getAllVersionManager = "IVersionManagerBO.getAllVersionManager";
    public static final String getVersionManagerByCondition = "IVersionManagerBO.getVersionManagerByCondition";
    public static final String getProductType = "IVersionManagerBO.getProductType";
    public static final String getProductSP = "IVersionManagerBO.getProductSP";
    public static final String getSupportMstp = "IVersionManagerBO.getSupportMstp";
    public static final String getSupportLogicalWireSeg = "IVersionManagerBO.getSupportLogicalWireSeg";
    public static final String getActionFilters = "IVersionManagerBO.getActionFilters";
    public static final String getVersionAttach = "IVersionManagerBO.getVersionAttach";
    public static final String addDbo = "IVersionManagerBO.addDbo";
    public static final String getAttachFile = "IVersionManagerBO.getAttachFile";
    public static final String delAttachFile = "IVersionManagerBO.delAttachFile";
    public static final String getBuildVersion = "IVersionManagerBO.getBuildVersion";
    public static final String getStartNanfangTheme = "IVersionManagerBO.getStartNanfangTheme";
    public static final String getVipTraph = "IVersionManagerBO.getVipTraph";
  }
}