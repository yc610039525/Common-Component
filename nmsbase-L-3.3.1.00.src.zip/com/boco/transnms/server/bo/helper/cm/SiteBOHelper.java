package com.boco.transnms.server.bo.helper.cm;

public class SiteBOHelper
{
  public static final String BO_NAME = "ISiteBO";

  public static class ActionName
  {
    public static final String getAllSite = "ISiteBO.getAllSite";
    public static final String getSite = "ISiteBO.getSite";
    public static final String getSiteByCuid = "ISiteBO.getSiteByCuid";
    public static final String getSiteByDistrictCuids = "ISiteBO.getSiteByDistrictCuids";
    public static final String addSite = "ISiteBO.addSite";
    public static final String modifySite = "ISiteBO.modifySite";
    public static final String deleteSite = "ISiteBO.deleteSite";
    public static final String getSiteByQuery = "ISiteBO.getSiteByQuery";
    public static final String getChildRoom = "ISiteBO.getChildRoom";
    public static final String getChildRoomByRoomName = "ISiteBO.getChildRoomByRoomName";
    public static final String getSiteOfRoom = "ISiteBO.getSiteOfRoom";
    public static final String getSiteCuidByRoomCuid = "ISiteBO.getSiteCuidByRoomCuid";
    public static final String getSiteByName = "ISiteBO.getSiteByName";
    public static final String getSiteByDistrictCuidAndSiteName = "ISiteBO.getSiteByDistrictCuidAndSiteName";
    public static final String addSiteCfgType = "ISiteBO.addSiteCfgType";
    public static final String modifySiteCfgType = "ISiteBO.modifySiteCfgType";
    public static final String modifySiteLocation = "ISiteBO.modifySiteLocation";
    public static final String getSiteCfgType = "ISiteBO.getSiteCfgType";
    public static final String delSiteCfgType = "ISiteBO.delSiteCfgType";
    public static final String getRoomCfgType = "ISiteBO.getRoomCfgType";
    public static final String getSwitchCfgType = "ISiteBO.getSwitchCfgType";
    public static final String addSwitchCfgType = "ISiteBO.addSwitchCfgType";
    public static final String modifySwitchCfgType = "ISiteBO.modifySwitchCfgType";
    public static final String delSwitchCfgType = "ISiteBO.delSwitchCfgType";
    public static final String getIsRoomType = "ISiteBO.getIsRoomType";
    public static final String getCuidByLabelcn = "ISiteBO.getCuidByLabelcn";
    public static final String getSiteByPage = "ISiteBO.getSiteByPage";
    public static final String getSiteByPageCondition = "ISiteBO.getSiteByPageCondition";
    public static final String getChildRoomBycuidorRoomNamePage = "ISiteBO.getChildRoomBycuidorRoomNamePage";
    public static final String getSiteBySubNetWorks = "ISiteBO.getSiteBySubNetWorks";
    public static final String getSiteTypeInfo = "ISiteBO.getSiteTypeInfo";
    public static final String getSitesByCuids = "ISiteBO.getSitesByCuids";
    public static final String getInterCableBySite = "ISiteBO.getInterCableBySite";
    public static final String getSiteByTransSystems = "ISiteBO.getSiteByTransSystems";
    public static final String getSiteBySql = "ISiteBO.getSiteBySql";
    public static final String getSiteByServicelevel = "ISiteBO.getSiteByServicelevel";
    public static final String getAllRoomsAndDevicesBySiteCuid = "ISiteBO.getAllRoomsAndDevicesBySiteCuid";
    public static final String getAllSimpleSite = "ISiteBO.getAllSimpleSite";
    public static final String getSitePageBySql = "ISiteBO.getSitePageBySql";
  }
}