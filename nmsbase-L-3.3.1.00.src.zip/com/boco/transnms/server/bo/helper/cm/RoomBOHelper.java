package com.boco.transnms.server.bo.helper.cm;

public class RoomBOHelper
{
  public static final String BO_NAME = "IRoomBO";

  public static class ActionName
  {
    public static final String getChildElement = "IRoomBO.getChildElement";
    public static final String getChildSwitch = "IRoomBO.getChildSwitch";
    public static final String getRoom = "IRoomBO.getRoom";
    public static final String addRoom = "IRoomBO.addRoom";
    public static final String modifyRoom = "IRoomBO.modifyRoom";
    public static final String deleteRoom = "IRoomBO.deleteRoom";
    public static final String getRoomByCuid = "IRoomBO.getRoomByCuid";
    public static final String getRoomBySiteCuids = "IRoomBO.getRoomBySiteCuids";
    public static final String getRoomByDistrictCuid = "IRoomBO.getRoomByDistrictCuid";
    public static final String getAllRoom = "IRoomBO.getAllRoom";
    public static final String getRoomByName = "IRoomBO.getRoomByName";
    public static final String getRoomByRoomName = "IRoomBO.getRoomByRoomName";
    public static final String getSwitchElementByLabelcnAndRoomCuidByPage = "IRoomBO.getSwitchElementByLabelcnAndRoomCuidByPage";
    public static final String getSwitchElementByCuidByPage = "IRoomBO.getSwitchElementByCuidByPage";
    public static final String getRoomByNameAndSiteCuid = "IRoomBO.getRoomByNameAndSiteCuid";
    public static final String getRoomByPageCondition = "IRoomBO.getRoomByPageCondition";
    public static final String deleteRooms = "IRoomBO.deleteRooms";
    public static final String getRoomTypeInfo = "IRoomBO.getRoomTypeInfo";
    public static final String getRoomBySiteCuid = "IRoomBO.getRoomBySiteCuid";
    public static final String getOdfByNameAndRoomCuid = "IRoomBO.getOdfByNameAndRoomCuid";
    public static final String getMiscrackByNameAndRoomCuid = "IRoomBO.getMiscrackByNameAndRoomCuid";
    public static final String getOdfAndJointBox = "IRoomBO.getOdfAndJointBox";
  }
}