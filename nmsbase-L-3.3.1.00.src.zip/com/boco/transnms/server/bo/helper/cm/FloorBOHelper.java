package com.boco.transnms.server.bo.helper.cm;

public class FloorBOHelper
{
  public static final String BO_NAME = "IFloorBO";

  public static class ActionName
  {
    public static final String getAllFloor = "IFloorBO.getAllFloor";
    public static final String getFloor = "IFloorBO.getFloor";
    public static final String addFloor = "IFloorBO.addFloor";
    public static final String modifyFloor = "IFloorBO.modifyFloor";
    public static final String deleteFloor = "IFloorBO.deleteFloor";
    public static final String getFloorByCuid = "IFloorBO.getFloorByCuid";
    public static final String getFloorBySiteCuid = "IFloorBO.getFloorBySiteCuid";
    public static final String getFloorBySiteCuidByPage = "IFloorBO.getFloorBySiteCuidByPage";
    public static final String addBatchFloor = "IFloorBO.addBatchFloor";
    public static final String deleteBatchFloor = "IFloorBO.deleteBatchFloor";
  }
}