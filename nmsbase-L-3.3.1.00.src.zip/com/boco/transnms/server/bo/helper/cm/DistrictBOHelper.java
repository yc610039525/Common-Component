package com.boco.transnms.server.bo.helper.cm;

public class DistrictBOHelper
{
  public static final String BO_NAME = "IDistrictBO";

  public static class ActionName
  {
    public static final String getAllTreePointDistrict = "IDistrictBO.getAllTreePointDistrict";
    public static final String getLevelDistrict = "IDistrictBO.getLevelDistrict";
    public static final String modifyLevelDistrict = "IDistrictBO.modifyLevelDistrict";
    public static final String getChildSite = "IDistrictBO.getChildSite";
    public static final String getDistrict = "IDistrictBO.getDistrict";
    public static final String addDistrict = "IDistrictBO.addDistrict";
    public static final String importExcelDistricts = "IDistrictBO.importExcelDistricts";
    public static final String modifyDistrict = "IDistrictBO.modifyDistrict";
    public static final String deleteDistrict = "IDistrictBO.deleteDistrict";
    public static final String getDistrictByCuid = "IDistrictBO.getDistrictByCuid";
    public static final String getNameByEquipCuid = "IDistrictBO.getNameByEquipCuid";
    public static final String isEquipOrderRight = "IDistrictBO.isEquipOrderRight";
    public static final String getDistrictOfSite = "IDistrictBO.getDistrictOfSite";
    public static final String getParentDistrict = "IDistrictBO.getParentDistrict";
    public static final String getAllChildDistrict = "IDistrictBO.getAllChildDistrict";
    public static final String getChildDistricts = "IDistrictBO.getChildDistricts";
    public static final String getCuidByLabelCn = "IDistrictBO.getCuidByLabelCn";
    public static final String getBelongDistrictCuidByEquipCuid = "IDistrictBO.getBelongDistrictCuidByEquipCuid";
    public static final String is2DistrictOrder = "IDistrictBO.is2DistrictOrder";
    public static final String getSiteDistrictCuid = "IDistrictBO.getSiteDistrictCuid";
    public static final String modifyDisDisplayCfg = "IDistrictBO.modifyDisDisplayCfg";
    public static final String getAllDisDisplayCfg = "IDistrictBO.getAllDisDisplayCfg";
  }
}