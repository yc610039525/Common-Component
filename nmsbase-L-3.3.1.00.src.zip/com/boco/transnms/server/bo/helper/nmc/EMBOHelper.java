package com.boco.transnms.server.bo.helper.nmc;

public class EMBOHelper
{
  public static final String BO_NAME = "IEMBO";

  public static class ActionName
  {
    public static final String addAlarmEvent = "IEMBO.addAlarmEvent";
    public static final String addTCAEvent = "IEMBO.addTCAEvent";
    public static final String addObjectCreateEvent = "IEMBO.addObjectCreateEvent";
    public static final String addObjectDeleteEvent = "IEMBO.addObjectDeleteEvent";
    public static final String addAVCEvent = "IEMBO.addAVCEvent";
    public static final String addFTSEvent = "IEMBO.addFTSEvent";
    public static final String addProtectSwitch = "IEMBO.addProtectSwitch";
    public static final String getLayerRate = "IEMBO.getLayerRate";
  }
}