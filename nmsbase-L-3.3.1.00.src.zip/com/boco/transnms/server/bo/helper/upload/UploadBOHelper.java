package com.boco.transnms.server.bo.helper.upload;

public class UploadBOHelper
{
  public static final String BO_NAME = "IUploadBO";

  public static class ActionName
  {
    public static final String addFile = "IUploadBO.addFile";
    public static final String getFile = "IUploadBO.getFile";
    public static final String deleteFile = "IUploadBO.deleteFile";
  }
}