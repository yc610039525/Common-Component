package com.boco.transnms.server.bo.helper.workflow;

public class WorkFlowBOHelper
{
  public static final String BO_NAME = "IWorkFlowBO";

  public static class ActionName
  {
    public static final String delUserRoleMap = "IWorkFlowBO.delUserRoleMap";
    public static final String addUserRoleMap = "IWorkFlowBO.addUserRoleMap";
    public static final String addUser = "IWorkFlowBO.addUser";
    public static final String delUser = "IWorkFlowBO.delUser";
    public static final String getUser = "IWorkFlowBO.getUser";
    public static final String modifySharkUser = "IWorkFlowBO.modifySharkUser";
    public static final String getAllProcessIdByPackageId = "IWorkFlowBO.getAllProcessIdByPackageId";
    public static final String getProcessPackage = "IWorkFlowBO.getProcessPackage";
    public static final String getProcessName = "IWorkFlowBO.getProcessName";
    public static final String isHasRoleByUser = "IWorkFlowBO.isHasRoleByUser";
    public static final String modifyCreateProcessAndUpdateAttrs = "IWorkFlowBO.modifyCreateProcessAndUpdateAttrs";
    public static final String setProcRelevantAttr = "IWorkFlowBO.setProcRelevantAttr";
    public static final String modifySetCurActivityInfo = "IWorkFlowBO.modifySetCurActivityInfo";
    public static final String getActivityCount = "IWorkFlowBO.getActivityCount";
    public static final String modifyCheckActivityKey = "IWorkFlowBO.modifyCheckActivityKey";
    public static final String modifySetProcRelevantAttr = "IWorkFlowBO.modifySetProcRelevantAttr";
    public static final String modifyCompleteActivity = "IWorkFlowBO.modifyCompleteActivity";
    public static final String getAllUserByRole = "IWorkFlowBO.getAllUserByRole";
    public static final String getAllRole = "IWorkFlowBO.getAllRole";
    public static final String getHisEventList = "IWorkFlowBO.getHisEventList";
    public static final String getActivityId = "IWorkFlowBO.getActivityId";
    public static final String getProcessGraph = "IWorkFlowBO.getProcessGraph";
    public static final String getActivities = "IWorkFlowBO.getActivities";
    public static final String getActivitiesList = "IWorkFlowBO.getActivitiesList";
    public static final String saveUserEmailCfg = "IWorkFlowBO.saveUserEmailCfg";
    public static final String getMailServerCfgByCuid = "IWorkFlowBO.getMailServerCfgByCuid";
    public static final String getAttempSheetByCuid = "IWorkFlowBO.getAttempSheetByCuid";
    public static final String getApplySheetByCuid = "IWorkFlowBO.getApplySheetByCuid";
    public static final String getRplSheetByCuid = "IWorkFlowBO.getRplSheetByCuid";
    public static final String getCurActivityKey = "IWorkFlowBO.getCurActivityKey";
    public static final String getUserCuidsByUserType = "IWorkFlowBO.getUserCuidsByUserType";
    public static final String getAttCuidsBySql = "IWorkFlowBO.getAttCuidsBySql";
    public static final String getGenericDOByCuid = "IWorkFlowBO.getGenericDOByCuid";
    public static final String delGenericDOByCuid = "IWorkFlowBO.delGenericDOByCuid";
    public static final String delGenericDOBySql = "IWorkFlowBO.delGenericDOBySql";
    public static final String getLineBySheetId = "IWorkFlowBO.getLineBySheetId";
    public static final String addUserRoleMappings = "IWorkFlowBO.addUserRoleMappings";
  }
}