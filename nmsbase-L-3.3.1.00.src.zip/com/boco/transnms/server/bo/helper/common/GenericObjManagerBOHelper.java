package com.boco.transnms.server.bo.helper.common;

public class GenericObjManagerBOHelper
{
  public static final String BO_NAME = "IGenericObjectManagerBO";

  public static class ActionName
  {
    public static final String getClassListByCond = "IGenericObjectManagerBO.getClassListByCond";
    public static final String getClassAllAttrs = "IGenericObjectManagerBO.getClassAllAttrs";
    public static final String getClassDynAttrByName = "IGenericObjectManagerBO.getClassDynAttrByName";
    public static final String getClassDynAttrs = "IGenericObjectManagerBO.getClassDynAttrs";
    public static final String getClassQueryAttrs = "IGenericObjectManagerBO.getClassQueryAttrs";
    public static final String getDefaultAttrGroup = "IGenericObjectManagerBO.getDefaultAttrGroup";
    public static final String addClassDynAttr = "IGenericObjectManagerBO.addClassDynAttr";
    public static final String modifyClassDynAttr = "IGenericObjectManagerBO.modifyClassDynAttr";
    public static final String modifyClassDynAttrs = "IGenericObjectManagerBO.modifyClassDynAttrs";
    public static final String deleteClassDynAttrs = "IGenericObjectManagerBO.deleteClassDynAttrs";
    public static final String checkDynObjLimit = "IGenericObjectManagerBO.checkDynObjLimit";
    public static final String dynAttrVal2String = "IGenericObjectManagerBO.dynAttrVal2String";
    public static final String dynAttrVal2Type = "IGenericObjectManagerBO.dynAttrVal2Type";
    public static final String modifyDynamicClass = "IGenericObjectManagerBO.modifyDynamicClass";
    public static final String getClassAttrsOfGroup = "IGenericObjectManagerBO.getClassAttrsOfGroup";
    public static final String getClassDynQryAttrs = "IGenericObjectManagerBO.getClassDynQryAttrs";
    public static final String getAllAttrGroups = "IGenericObjectManagerBO.getAllAttrGroups";
    public static final String getInUseAttrGroups = "IGenericObjectManagerBO.getInUseAttrGroups";
    public static final String getAttrGroupByCuid = "IGenericObjectManagerBO.getAttrGroupByCuid";
    public static final String addAttrGroup = "IGenericObjectManagerBO.addAttrGroup";
    public static final String modifyAttrGroup = "IGenericObjectManagerBO.modifyAttrGroup";
    public static final String deleteAttrGroup = "IGenericObjectManagerBO.deleteAttrGroup";
    public static final String deleteAttrGroups = "IGenericObjectManagerBO.deleteAttrGroups";
    public static final String getClassesOfGroup = "IGenericObjectManagerBO.getClassesOfGroup";
    public static final String isDynClass = "IGenericObjectManagerBO.isDynClass";
    public static final String getClassAttrByAttrName = "IGenericObjectManagerBO.getClassAttrByAttrName";
    public static final String modifyAttrVal2Type = "IGenericObjectManagerBO.modifyAttrVal2Type";
    public static final String modifyDateFormat = "IGenericObjectManagerBO.modifyDateFormat";
    public static final String addQueryModel = "IGenericObjectManagerBO.addQueryModel";
    public static final String modifyQueryModel = "IGenericObjectManagerBO.modifyQueryModel";
    public static final String deleteQueryModel = "IGenericObjectManagerBO.deleteQueryModel";
    public static final String getQueryModelsByClass = "IGenericObjectManagerBO.getQueryModelsByClass";
    public static final String getQueryModelByCuid = "IGenericObjectManagerBO.getQueryModelByCuid";
    public static final String modifyMultyAttrs = "IGenericObjectManagerBO.modifyMultyAttrs";
    public static final String convertSql = "IGenericObjectManagerBO.convertSql";
    public static final String isHasOtherDefaultGroup = "IGenericObjectManagerBO.isHasOtherDefaultGroup";
  }
}