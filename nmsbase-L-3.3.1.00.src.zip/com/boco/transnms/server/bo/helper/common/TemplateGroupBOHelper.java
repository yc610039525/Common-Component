package com.boco.transnms.server.bo.helper.common;

public class TemplateGroupBOHelper
{
  public static final String BO_NAME = "ITemplateGroupBO";

  public static class ActionName
  {
    public static final String getTemplateGroupsBySql = "ITemplateGroupBO.getTemplateGroupsBySql";
    public static final String getAllTemplateGroups = "ITemplateGroupBO.getAllTemplateGroups";
    public static final String addTemplateGroup = "ITemplateGroupBO.addTemplateGroup";
    public static final String deleteTemplateGroup = "ITemplateGroupBO.deleteTemplateGroup";
    public static final String deleteTemplateGroups = "ITemplateGroupBO.deleteTemplateGroups";
    public static final String modifyTemplateGroup = "ITemplateGroupBO.modifyTemplateGroup";
  }
}