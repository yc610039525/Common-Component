package com.boco.transnms.server.bo.helper.common;

public class TemplateBOHelper
{
  public static final String BO_NAME = "ITemplateBO";

  public static class ActionName
  {
    public static final String getTemplatesBySql = "ITemplateBO.getTemplatesBySql";
    public static final String getTemplatePic = "ITemplateBO.getTemplatePic";
    public static final String addTemplate = "ITemplateBO.addTemplate";
    public static final String modifyTemplateInfo = "ITemplateBO.modifyTemplateInfo";
    public static final String modifyTemplatePic = "ITemplateBO.modifyTemplatePic";
    public static final String deleteTemplate = "ITemplateBO.deleteTemplate";
    public static final String deleteTemplates = "ITemplateBO.deleteTemplates";
    public static final String getFullTemplatesBySql = "ITemplateBO.getFullTemplatesBySql";
    public static final String getTemplateDataPic = "ITemplateBO.getTemplateDataPic";
    public static final String addNeDataTemplateByDevice = "ITemplateBO.addNeDataTemplateByDevice";
    public static final String addNeConfByTemplate = "ITemplateBO.addNeConfByTemplate";
    public static final String getSlotConfByTemplate = "ITemplateBO.getSlotConfByTemplate";
    public static final String getSysNoByTemplate = "ITemplateBO.getSysNoByTemplate";
    public static final String getSysNoBySlotDN = "ITemplateBO.getSysNoBySlotDN";
    public static final String getTemplateByCuid = "ITemplateBO.getTemplateByCuid";
    public static final String getTemplateByName = "ITemplateBO.getTemplateByName";
    public static final String addTemplates = "ITemplateBO.addTemplates";
    public static final String getSimpleTemplatesBySql = "ITemplateBO.getSimpleTemplatesBySql";
    public static final String getSimpleTemplates = "ITemplateBO.getSimpleTemplates";
  }
}