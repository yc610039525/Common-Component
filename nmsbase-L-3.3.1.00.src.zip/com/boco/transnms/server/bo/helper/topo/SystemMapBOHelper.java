package com.boco.transnms.server.bo.helper.topo;

public class SystemMapBOHelper
{
  public static final String BO_NAME = "ISystemMapBO";

  public static class ActionName
  {
    public static final String addSystemMap = "ISystemMapBO.addSystemMap";
    public static final String modifySystemMap = "ISystemMapBO.modifySystemMap";
    public static final String deleteSystemMap = "ISystemMapBO.deleteSystemMap";
    public static final String getAllSystemMaps = "ISystemMapBO.getAllSystemMaps";
    public static final String getSystemMapByCuid = "ISystemMapBO.getSystemMapByCuid";
    public static final String getSystemMapByName = "ISystemMapBO.getSystemMapByName";
    public static final String getLocateSites = "ISystemMapBO.getLocateSites";
    public static final String getDefaultSystemMap = "ISystemMapBO.getDefaultSystemMap";
    public static final String getDefaultSystemMapsByDistrictDuids = "ISystemMapBO.getDefaultSystemMapsByDistrictDuids";
    public static final String isHaveRelatedObj = "ISystemMapBO.isHaveRelatedObj";
    public static final String getRelatedDeleteObjCount = "ISystemMapBO.getRelatedDeleteObjCount";
    public static final String getRelatedDeleteObjects = "ISystemMapBO.getRelatedDeleteObjects";
    public static final String deleteReletedOfObject = "ISystemMapBO.deleteReletedOfObject";
    public static final String getLocateObjectsByMapCuid = "ISystemMapBO.getLocateObjectsByMapCuid";
  }
}