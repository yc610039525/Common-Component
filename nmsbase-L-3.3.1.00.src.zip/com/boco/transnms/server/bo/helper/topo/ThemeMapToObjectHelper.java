package com.boco.transnms.server.bo.helper.topo;

public class ThemeMapToObjectHelper
{
  public static final String BO_NAME = "ThemeMapToObject";

  public static class ActionName
  {
    public static final String addThemeMapToObject = "ThemeMapToObject.addThemeMapToObject";
    public static final String addThemeMapToObjects = "ThemeMapToObject.addThemeMapToObjects";
    public static final String deleteObjectByThemeMapCuid = "ThemeMapToObject.deleteObjectByThemeMapCuid";
    public static final String deleteThemeMapToObjects = "ThemeMapToObject.deleteThemeMapToObjects";
    public static final String getThemeMapToObjectByUser = "ThemeMapToObject.getThemeMapToObjectByUser";
    public static final String getThemeMapToObjectByCuid = "ThemeMapToObject.getThemeMapToObjectByCuid";
    public static final String deleteObjectOnlyByThemeMapCuid = "ThemeMapToObject.deleteObjectOnlyByThemeMapCuid";
  }
}