package com.boco.transnms.server.bo.helper.topo;

public class ThemeMapToObjectBOHelper
{
  public static final String BO_NAME = "IThemeMapToObjectBO";

  public static class ActionName
  {
    public static final String addThemeMapToObject = "IThemeMapToObjectBO.addThemeMapToObject";
    public static final String addThemeMapToObjects = "IThemeMapToObjectBO.addThemeMapToObjects";
    public static final String deleteObjectByThemeMapCuid = "IThemeMapToObjectBO.deleteObjectByThemeMapCuid";
    public static final String deleteThemeMapToObjects = "IThemeMapToObjectBO.deleteThemeMapToObjects";
    public static final String getThemeMapToObjectByUser = "IThemeMapToObjectBO.getThemeMapToObjectByUser";
    public static final String getThemeMapToObjectByObjectTypes = "IThemeMapToObjectBO.getThemeMapToObjectByObjectTypes";
    public static final String getThemeMapObjectsByUser = "IThemeMapToObjectBO.getThemeMapObjectsByUser";
    public static final String getThemeMapToObjectByCuid = "IThemeMapToObjectBO.getThemeMapToObjectByCuid";
    public static final String deleteObjectOnlyByThemeMapCuid = "IThemeMapToObjectBO.deleteObjectOnlyByThemeMapCuid";
    public static final String getDeletedThemeMapOjbect = "IThemeMapToObjectBO.getDeletedThemeMapOjbect";
  }
}