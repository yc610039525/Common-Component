package com.boco.transnms.server.bo.helper.topo;

public class AllPicsBOHelper
{
  public static final String BO_NAME = "IAllPicsBO";

  public static class ActionName
  {
    public static final String addAllPics = "IAllPicsBO.addAllPics";
    public static final String addDistinctAllPics = "IAllPicsBO.addDistinctAllPics";
    public static final String modifyAllPicsPicField = "IAllPicsBO.modifyAllPicsPicField";
    public static final String deleteAllPics = "IAllPicsBO.deleteAllPics";
    public static final String getAllPics = "IAllPicsBO.getAllPics";
    public static final String getAllPictures = "IAllPicsBO.getAllPictures";
    public static final String getAllPicturesBySql = "IAllPicsBO.getAllPicturesBySql";
    public static final String modifyAllPictures = "IAllPicsBO.modifyAllPictures";
    public static final String getAllSimplePics = "IAllPicsBO.getAllSimplePics";
  }
}