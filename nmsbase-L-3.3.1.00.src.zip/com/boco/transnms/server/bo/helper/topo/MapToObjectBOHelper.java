package com.boco.transnms.server.bo.helper.topo;

public class MapToObjectBOHelper
{
  public static final String BO_NAME = "IMapToObjectBO";

  public static class ActionName
  {
    public static final String addMapToObject = "IMapToObjectBO.addMapToObject";
    public static final String modifyMapToObject = "IMapToObjectBO.modifyMapToObject";
    public static final String deleteMapToObject = "IMapToObjectBO.deleteMapToObject";
    public static final String deleteMapToObjectsBySql = "IMapToObjectBO.deleteMapToObjectsBySql";
    public static final String deleteMapToObjectByKey = "IMapToObjectBO.deleteMapToObjectByKey";
    public static final String deleteMapToObjectByPointCuid = "IMapToObjectBO.deleteMapToObjectByPointCuid";
  }
}