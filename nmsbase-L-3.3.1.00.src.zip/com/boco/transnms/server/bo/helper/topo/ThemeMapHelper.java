package com.boco.transnms.server.bo.helper.topo;

public class ThemeMapHelper
{
  public static final String BO_NAME = "IThemeMapBO";

  public static class ActionName
  {
    public static final String addThemeMap = "IThemeMapBO.addThemeMap";
    public static final String modifyThemeMap = "IThemeMapBO.modifyThemeMap";
    public static final String deleteThemeMap = "IThemeMapBO.deleteThemeMap";
    public static final String getThemeMapByUser = "IThemeMapBO.getThemeMapByUser";
    public static final String getThemeMapByCuid = "IThemeMapBO.getThemeMapByCuid";
    public static final String getAllThemeMapsByUserCUID = "IThemeMapBO.getAllThemeMapsByUserCUID";
    public static final String addDefaultThemeMapByUser = "IThemeMapBO.addDefaultThemeMapByUser";
    public static final String getDefaultThemeMap = "IThemeMapBO.getDefaultThemeMap";
  }
}