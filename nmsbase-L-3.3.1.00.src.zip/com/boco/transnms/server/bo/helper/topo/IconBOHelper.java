package com.boco.transnms.server.bo.helper.topo;

public class IconBOHelper
{
  public static final String BO_NAME = "IIconBO";

  public static class ActionName
  {
    public static final String getIconByCuid = "IIconBO.getIconByCuid";
    public static final String getIcons = "IIconBO.getIcons";
    public static final String getIconModuleAndAll = "IIconBO.getIconModuleAndAll";
    public static final String getIconModAndIcon = "IIconBO.getIconModAndIcon";
    public static final String getIconSql = "IIconBO.getIconSql";
    public static final String modifyIcon = "IIconBO.modifyIcon";
    public static final String getAllIcon = "IIconBO.getAllIcon";
  }
}