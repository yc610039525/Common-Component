package com.boco.transnms.server.bo.helper.system;

public class SystemParaBOHelper
{
  public static final String BO_NAME = "ISystemParaBO";

  public static class ActionName
  {
    public static final String getSystemParaByPage = "ISystemParaBO.getSystemParaByPage";
    public static final String getSingleSystemPara = "ISystemParaBO.getSingleSystemPara";
    public static final String addSingleSystemPara = "ISystemParaBO.addSingleSystemPara";
    public static final String delSingleSystemPara = "ISystemParaBO.delSingleSystemPara";
    public static final String getDistinctTable = "ISystemParaBO.getDistinctTable";
    public static final String getSmsSwitch = "ISystemParaBO.getSmsSwitch";
    public static final String getSystemParas = "ISystemParaBO.getSystemParas";
    public static final String modifySystemPara = "ISystemParaBO.modifySystemPara";
    public static final String getSystemParaValue = "ISystemParaBO.getSystemParaValue";
    public static final String getTraphNameAndTraphAlias = "ISystemParaBO.getTraphNameAndTraphAlias";
    public static final String getTraphViewConfigBySystemPara = "ISystemParaBO.getTraphViewConfigBySystemPara";
    public static final String addDevInfoImpConfig = "ISystemParaBO.addDevInfoImpConfig";
    public static final String getDevInfoImpConfig = "ISystemParaBO.getDevInfoImpConfig";
    public static final String getSystemPara = "ISystemParaBO.getSystemPara";
  }
}