package com.boco.transnms.server.bo.helper.misc;

public class EnumBOHelper
{
  public static final String BO_NAME = "IEnumBO";

  public static class ActionName
  {
    public static final String getEnum = "IEnumBO.getEnum";
    public static final String modifyEnum = "IEnumBO.modifyEnum";
    public static final String queryTraphServiceType = "IEnumBO.queryTraphServiceType";
    public static final String getTraphServiceTypeByObjectId = "IEnumBO.getTraphServiceTypeByObjectId";
    public static final String modifyTraphServiceType = "IEnumBO.modifyTraphServiceType";
    public static final String addTraphServiceType = "IEnumBO.addTraphServiceType";
    public static final String getTraphServiceTypeBySql = "IEnumBO.getTraphServiceTypeBySql";
    public static final String deleteTraphServiceTypeByKeyNum = "IEnumBO.deleteTraphServiceTypeByKeyNum";
    public static final String getEnumTypeByName = "IEnumBO.getEnumTypeByName";
    public static final String addPublicType = "IEnumBO.addPublicType";
    public static final String modifyPublicType = "IEnumBO.modifyPublicType";
    public static final String delPublicType = "IEnumBO.delPublicType";
    public static final String getCessionTypeInfo = "IEnumBO.getCessionTypeInfo";
    public static final String getAllDeviceEnumFromPublicEnum = "IEnumBO.getAllDeviceEnumFromPublicEnum";
  }
}