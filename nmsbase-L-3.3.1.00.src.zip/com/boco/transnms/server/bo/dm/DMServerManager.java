package com.boco.transnms.server.bo.dm;

public class DMServerManager
{
  private String serverUrl;
  private static DMServerManager instance = new DMServerManager();

  public static DMServerManager getInstance()
  {
    return instance;
  }

  public String getServerUrl()
  {
    return this.serverUrl;
  }

  public void setServerUrl(String serverUrl) {
    this.serverUrl = serverUrl;
  }
}