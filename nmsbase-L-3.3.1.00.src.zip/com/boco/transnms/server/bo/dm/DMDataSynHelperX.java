package com.boco.transnms.server.bo.dm;

import com.boco.common.util.debug.LogHome;
import com.boco.transnms.common.dto.ServiceParam;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.bo.base.BoHomeFactory;
import com.boco.transnms.server.bo.ibo.common.IServiceParamBO;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.logging.Log;

public class DMDataSynHelperX
{
  public static String serverUrl = null;
  private static int pointOrSegtype = 0;
  private static String[] modifyAttr = { "LONGITUDE", "LATITUDE", "LABEL_CN", "RELATED_DISTRICT_CUID", "IS_CONN_POINT", "IS_DANGER_POINT", "IS_KEEP_POINT", "RELATED_SPACE_CUID", "DISTRICT_CUID", "RELATED_BRANCH_CUID", "RELATED_SYSTEM_CUID", "REMARK", "ORIG_POINT_CUID", "DEST_POINT_CUID", "SPECIAL_PURPOSE" };
  private static String[] modifySystemAttr = { "SYSTEM_LEVEL", "RELATED_SPACE_CUID" };

  private static IServiceParamBO getServiceParamBO()
  {
    return (IServiceParamBO)BoHomeFactory.getInstance().getBO(IServiceParamBO.class);
  }

  private static void execSysn(String exeUrl)
    throws Exception
  {
    needSysn();
    LogHome.getLog().info("调用同步接口:" + serverUrl);
    if (serverUrl == null) {
      LogHome.getLog().info("同步接口地址为空。。。");
      return;
    }
    try {
      URL url = new URL(serverUrl);
      URLConnection openConnection = url.openConnection();
      openConnection.setDoOutput(true);
      openConnection.connect();

      OutputStreamWriter wr = new OutputStreamWriter(openConnection.getOutputStream());
      wr.write(exeUrl);
      wr.flush();

      inputStream = openConnection.getInputStream();
    }
    catch (Exception e)
    {
      InputStream inputStream;
      LogHome.getLog().info("同步信息失败：" + serverUrl + exeUrl);
    }
  }

  public static boolean needSysn()
    throws Exception
  {
    if (serverUrl == null) {
      ServiceParam param = getServiceParamBO().getServiceParamByTypeAndName(new BoActionContext(), new Long(1L), "DMSYN");
      if (param != null) {
        serverUrl = param.getServiceUrl();
      }
      LogHome.getLog().info("ArcGIS客户端开启sde库同步地址：" + serverUrl);
    }
    return serverUrl != null;
  }

  protected static void addPointByCuid(String cuid) throws Exception {
    execSysn("METHOD=ADD&CUID=" + cuid);
  }

  public static void addPoint(GenericDO gdo) throws Exception {
    addPointByCuid(gdo.getCuid());
  }

  protected static void modifyPointByCuid(String cuid) throws Exception {
    execSysn("METHOD=UPDATE&CUID=" + cuid);
  }

  public static void modifyPoint(GenericDO gdo) throws Exception {
    modifyPointByCuid(gdo.getCuid());
  }

  protected static void deletePointByCuid(String cuid) throws Exception {
    execSysn("METHOD=DELETE&CUID=" + cuid);
  }

  public static void deletePoint(GenericDO gdo) throws Exception {
    deletePointByCuid(gdo.getCuid());
  }

  protected static void addSegByCuid(String cuid) throws Exception {
    execSysn("METHOD=ADD&CUID=" + cuid);
  }

  public static void addSeg(GenericDO gdo) throws Exception {
    addSegByCuid(gdo.getCuid());
  }

  public static void modifySegByCuid(String cuid) throws Exception {
    execSysn("METHOD=UPDATE&CUID=" + cuid);
  }

  public static void modifySeg(GenericDO gdo) throws Exception {
    modifySegByCuid(gdo.getCuid());
  }

  protected static void deleteSegByCuid(String cuid) throws Exception {
    execSysn("METHOD=DELETE&CUID=" + cuid);
  }

  public static void deleteSeg(GenericDO gdo) throws Exception {
    deleteSegByCuid(gdo.getCuid());
  }

  public static void addPoint(DataObjectList list)
    throws Exception
  {
    List lis = new ArrayList();
    lis.addAll(list.getCuidList());
    LogHome.getLog().info("增加的点的数量：" + lis.size());
    if ((list != null) && (!list.isEmpty())) {
      List cuidList = new ArrayList();
      for (int i = 0; i < list.size(); i++) {
        String cuid = ((GenericDO)list.get(i)).getCuid();
        cuidList.add(cuid);
        lis.remove(cuid);
        if (cuidList.size() == 500) {
          String cuids = dataListCuidToString(cuidList);
          if (cuids != null) {
            addPointByCuid(cuids);
          }
          cuidList.clear();
        }
        else if (lis.size() == 0) {
          String cuids = dataListCuidToString(cuidList);
          if (cuids != null)
            addPointByCuid(cuids);
        }
      }
    }
  }

  public static void modifyPoint(DataObjectList list) throws Exception
  {
    List lis = new ArrayList();
    lis.addAll(list.getCuidList());
    LogHome.getLog().info("修改的点的数量：" + lis.size());
    if ((list != null) && (!list.isEmpty())) {
      List cuidList = new ArrayList();
      for (int i = 0; i < list.size(); i++) {
        String cuid = ((GenericDO)list.get(i)).getCuid();
        cuidList.add(cuid);
        lis.remove(cuid);
        if (cuidList.size() == 500) {
          String cuids = dataListCuidToString(cuidList);
          if (cuids != null) {
            modifyPointByCuid(cuids);
          }
          cuidList.clear();
        }
        else if (lis.size() == 0) {
          String cuids = dataListCuidToString(cuidList);
          if (cuids != null)
            modifyPointByCuid(cuids);
        }
      }
    }
  }

  public static void deletePoint(DataObjectList list)
    throws Exception
  {
    List lis = new ArrayList();
    lis.addAll(list.getCuidList());
    LogHome.getLog().info("删除的点的数量：" + lis.size());
    if ((list != null) && (!list.isEmpty())) {
      List cuidList = new ArrayList();
      for (int i = 0; i < list.size(); i++) {
        String cuid = ((GenericDO)list.get(i)).getCuid();
        cuidList.add(cuid);
        lis.remove(cuid);
        if (cuidList.size() == 500) {
          String cuids = dataListCuidToString(cuidList);
          if (cuids != null) {
            deletePointByCuid(cuids);
          }
          cuidList.clear();
        }
        else if (lis.size() == 0) {
          String cuids = dataListCuidToString(cuidList);
          if (cuids != null)
            deletePointByCuid(cuids);
        }
      }
    }
  }

  public static void addSeg(DataObjectList list)
    throws Exception
  {
    List lis = new ArrayList();
    lis.addAll(list.getCuidList());
    LogHome.getLog().info("增加的段的数量：" + lis.size());
    if ((list != null) && (!list.isEmpty())) {
      List cuidList = new ArrayList();
      for (int i = 0; i < list.size(); i++) {
        String cuid = ((GenericDO)list.get(i)).getCuid();
        cuidList.add(cuid);
        lis.remove(cuid);
        if (cuidList.size() == 500) {
          String cuids = dataListCuidToString(cuidList);
          if (cuids != null) {
            addSegByCuid(cuids);
          }
          cuidList.clear();
        }
        else if (lis.size() == 0) {
          String cuids = dataListCuidToString(cuidList);
          if (cuids != null)
            addSegByCuid(cuids);
        }
      }
    }
  }

  public static void modifySeg(DataObjectList list)
    throws Exception
  {
    List lis = new ArrayList();
    lis.addAll(list.getCuidList());
    LogHome.getLog().info("修改的段的数量：" + lis.size());
    if ((list != null) && (!list.isEmpty())) {
      List cuidList = new ArrayList();
      for (int i = 0; i < list.size(); i++) {
        String cuid = ((GenericDO)list.get(i)).getCuid();
        cuidList.add(cuid);
        lis.remove(cuid);
        if (cuidList.size() == 500) {
          String cuids = dataListCuidToString(cuidList);
          if (cuids != null) {
            modifySegByCuid(cuids);
          }
          cuidList.clear();
        }
        else if (lis.size() == 0) {
          String cuids = dataListCuidToString(cuidList);
          if (cuids != null)
            modifySegByCuid(cuids);
        }
      }
    }
  }

  public static void deleteSeg(DataObjectList list)
    throws Exception
  {
    List lis = new ArrayList();
    lis.addAll(list.getCuidList());
    LogHome.getLog().info("删除的段的数量：" + lis.size());
    if ((list != null) && (!list.isEmpty())) {
      List cuidList = new ArrayList();
      for (int i = 0; i < list.size(); i++) {
        String cuid = ((GenericDO)list.get(i)).getCuid();
        cuidList.add(cuid);
        lis.remove(cuid);
        if (cuidList.size() == 500) {
          String cuids = dataListCuidToString(cuidList);
          if (cuids != null) {
            deleteSegByCuid(cuids);
          }
          cuidList.clear();
        }
        else if (lis.size() == 0) {
          String cuids = dataListCuidToString(cuidList);
          if (cuids != null)
            deleteSegByCuid(cuids);
        }
      }
    }
  }

  private static String dataListCuidToString(DataObjectList list)
  {
    if (list.isEmpty()) {
      return null;
    }
    String cuid = ((GenericDO)list.get(0)).getCuid();
    for (int i = 1; i < list.size(); i++) {
      cuid = cuid + "," + ((GenericDO)list.get(i)).getCuid();
    }
    return cuid;
  }

  public static boolean getIsModifyArcgis(GenericDO oldDto, GenericDO newDto, int type)
  {
    if ((oldDto == null) || (newDto == null)) {
      return false;
    }
    if (type == pointOrSegtype)
      for (String attr : modifyAttr) {
        String oldValue = getRelatedCuid(oldDto.getAttrValue(attr));
        String newValue = getRelatedCuid(newDto.getAttrValue(attr));
        if (oldValue == null) {
          oldValue = "0.0";
        }
        if ((oldValue != null) && (newValue != null))
        {
          if (!oldValue.equals(newValue))
            return true;
        }
      }
    else {
      for (String attr : modifySystemAttr) {
        String oldValue = getRelatedCuid(oldDto.getAttrValue(attr));
        String newValue = getRelatedCuid(newDto.getAttrValue(attr));

        if ((oldValue != null) && (newValue != null))
        {
          if (!oldValue.equals(newValue))
            return true;
        }
      }
    }
    return false;
  }

  private static String getRelatedCuid(Object obj) {
    if ((obj instanceof GenericDO))
      return ((GenericDO)obj).getCuid();
    if ((obj instanceof String))
      return (String)obj;
    if (obj != null) {
      return obj.toString();
    }
    return null;
  }

  private static String dataListCuidToString(List<String> list) {
    if (list.isEmpty()) {
      return null;
    }
    String cuid = (String)list.get(0);
    for (int i = 1; i < list.size(); i++) {
      cuid = cuid + "," + (String)list.get(i);
    }
    return cuid;
  }

  public static void modifySegAttrValueByCuid(String cuid)
    throws Exception
  {
    execSysn("METHOD=UPDATEATTRVALUE&CUID=" + cuid);
  }

  public static void modifySegAttrValueByCuid(DataObjectList list)
    throws Exception
  {
    String cuid = dataListCuidToString(list);
    if (cuid != null)
      modifySegAttrValueByCuid(cuid);
  }

  public static void modifyDistrictAndLevelByCuid(DataObjectList list)
    throws Exception
  {
    String cuid = dataListCuidToString(list);
    if (cuid != null)
      modifyDistrictAndLevelByCuid(cuid);
  }

  public static void modifyDistrictAndLevelByCuid(String cuid)
    throws Exception
  {
    execSysn("METHOD=UPDATEDISTRICTORLEVEL&CUID=" + cuid);
  }
}