package com.boco.transnms.server.bo.customer;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.DeviceVendor;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.ibo.cm.IDeviceVendorBO;
import com.boco.transnms.server.dao.customer.DeviceVendorDAO;

@StateLessBO(serverName="CM", initByAllServer=true)
public class DeviceVendorBO extends AbstractBO
  implements IDeviceVendorBO
{
  public void addDeviceVendor(BoActionContext actionContext, DeviceVendor vendor)
    throws UserException
  {
    DeviceVendor existVendor = null;
    try {
      existVendor = getDeviceVendorDAO().getDeviceVendorByName(actionContext, vendor.getLabelCn());
    }
    catch (Exception e) {
    }
    if (existVendor != null)
      throw new UserException("该厂家已经添加（名称重复）");
    try
    {
      getDeviceVendorDAO().addDeviceVendor(actionContext, vendor);
    } catch (Exception ex) {
      throw new UserException("添加厂家失败", ex);
    }
  }

  public void deleteDeviceVendor(BoActionContext actionContext, DeviceVendor vendor)
    throws UserException
  {
    try
    {
      getDeviceVendorDAO().deleteDeviceVendor(actionContext, vendor);
    } catch (Exception ex) {
      throw new UserException("删除厂家失败", ex);
    }
  }

  public DataObjectList getAllDeviceVendor(BoActionContext actionContext)
    throws UserException
  {
    try
    {
      DataObjectList dolist = getDeviceVendorDAO().getAllDeviceVendor(actionContext);
      dolist.sort("LABEL_CN", false);
      return dolist;
    } catch (Exception ex) {
      throw new UserException("获取所有厂家失败", ex);
    }
  }

  public DeviceVendor getDeviceVendorByName(BoActionContext actionContext, String vednorName)
    throws UserException
  {
    try
    {
      return getDeviceVendorDAO().getDeviceVendorByName(actionContext, vednorName);
    } catch (Exception ex) {
      throw new UserException("获取指定厂家失败", ex);
    }
  }

  public DeviceVendor getDeviceVendorByCuid(BoActionContext actionContext, String vednorCuid)
    throws UserException
  {
    try
    {
      DeviceVendor vendor = new DeviceVendor();
      vendor.setCuid(vednorCuid);
      return (DeviceVendor)getDeviceVendorDAO().getObjByCuid(vendor);
    } catch (Exception ex) {
      throw new UserException("获取指定厂家失败", ex);
    }
  }

  public void modifyDeviceVendor(BoActionContext actionContext, DeviceVendor vendor)
    throws UserException
  {
    try
    {
      getDeviceVendorDAO().modifyDeviceVendor(actionContext, vendor);
    } catch (Exception ex) {
      throw new UserException("修改指定厂家失败：" + vendor.getLabelCn(), ex);
    }
  }

  private DeviceVendorDAO getDeviceVendorDAO()
  {
    return (DeviceVendorDAO)super.getDAO("DeviceVendorDAO");
  }
}