package com.boco.transnms.server.bo.base;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.base.GenericDO;

public abstract interface IModifyRelatedObjBO
{
  public abstract void modifyReletedOfObject(String paramString, GenericDO paramGenericDO1, GenericDO paramGenericDO2)
    throws UserException;

  public abstract void modifyReletedName(String paramString1, String paramString2, String paramString3, String paramString4)
    throws UserException;
}