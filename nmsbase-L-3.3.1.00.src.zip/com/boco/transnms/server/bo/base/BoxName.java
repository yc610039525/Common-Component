package com.boco.transnms.server.bo.base;

public class BoxName
{
  public static final String JumpFiberBOX = "JumpFiberBOX";
}