package com.boco.transnms.server.bo.base;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.Room;
import com.boco.transnms.common.dto.Site;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;

public abstract interface IModifyRelatedSpaceBO
{
  public abstract Boolean modifyRelatedDistrict(BoActionContext paramBoActionContext, Site paramSite1, Site paramSite2)
    throws UserException;

  public abstract Boolean modifyRelatedSpace(BoActionContext paramBoActionContext, Room paramRoom1, Room paramRoom2, DataObjectList paramDataObjectList)
    throws UserException;
}