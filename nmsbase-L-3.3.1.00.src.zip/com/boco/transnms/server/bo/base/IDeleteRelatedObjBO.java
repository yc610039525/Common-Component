package com.boco.transnms.server.bo.base;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;

public abstract interface IDeleteRelatedObjBO extends IBusinessObject
{
  public abstract int getRelatedDeleteObjCount(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract boolean isHaveRelatedObj(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract DataObjectList getRelatedDeleteObjects(String paramString, GenericDO paramGenericDO)
    throws UserException;

  public abstract void deleteReletedOfObject(String paramString, GenericDO paramGenericDO)
    throws UserException;
}