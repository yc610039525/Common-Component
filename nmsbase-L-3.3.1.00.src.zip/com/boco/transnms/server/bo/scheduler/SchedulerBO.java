package com.boco.transnms.server.bo.scheduler;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.lang.TimeFormatHelper;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.IScheduleTask;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.base.StateLessBoField;
import java.util.Date;
import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.Notification;
import javax.management.NotificationFilter;
import javax.management.ObjectInstance;
import javax.management.ObjectName;
import javax.management.timer.TimerNotification;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="COMMON")
public class SchedulerBO extends AbstractBO
{

  @StateLessBoField
  private ObjectInstance timer;

  @StateLessBoField
  private MBeanServer mBeanServer;

  public SchedulerBO()
    throws Exception
  {
    super("SchedulerBO");
    this.mBeanServer = MBeanServerFactory.createMBeanServer();
    this.timer = this.mBeanServer.createMBean("javax.management.timer.Timer", new ObjectName("DefaultDomain", "service", "timer"));

    start();
  }

  public void stop() {
    try {
      removeAllScheduleTask();
      this.mBeanServer.invoke(this.timer.getObjectName(), "stop", new Object[0], new String[0]);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }

  public void start() throws Exception {
    this.mBeanServer.invoke(this.timer.getObjectName(), "start", new Object[0], new String[0]);
  }

  public void addScheduleTask(IScheduleTask schedulerTask) {
    try {
      Date scheduleTime = schedulerTask.getScheduleTime();
      if (scheduleTime != null) {
        if (schedulerTask.getTaskId() != null) {
          removeScheduleTask(schedulerTask);
        }

        LogHome.getLog().debug("添加定时任务[message=" + schedulerTask.getTaskMessage() + ", time=" + TimeFormatHelper.getFormatDate(schedulerTask.getScheduleTime(), "yyyy-MM-dd HH:mm:ss") + "]");

        final Integer taskId = (Integer)this.mBeanServer.invoke(this.timer.getObjectName(), "addNotification", new Object[] { schedulerTask.getTaskType(), schedulerTask.getTaskMessage(), schedulerTask.getTaskUserData(), scheduleTime }, new String[] { String.class.getName(), String.class.getName(), Object.class.getName(), Date.class.getName() });

        schedulerTask.setTaskId(taskId);

        this.mBeanServer.addNotificationListener(this.timer.getObjectName(), schedulerTask, new NotificationFilter()
        {
          public boolean isNotificationEnabled(Notification notification) {
            if ((notification instanceof TimerNotification)) {
              TimerNotification timerNotification = (TimerNotification)notification;
              return timerNotification.getNotificationID().equals(taskId);
            }
            return false;
          }
        }
        , this);
      }

    }
    catch (Exception ex)
    {
      LogHome.getLog().error("", ex);
    }
  }

  public void removeAllScheduleTask() {
    try {
      this.mBeanServer.invoke(this.timer.getObjectName(), "removeAllNotifications", new Object[0], new String[0]);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }

  public void removeScheduleTask(IScheduleTask schedulerTask) {
    try {
      LogHome.getLog().debug("删除定时任务:" + schedulerTask.getTaskMessage());
      this.mBeanServer.removeNotificationListener(this.timer.getObjectName(), schedulerTask);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }
}