package com.boco.transnms.server.bo.scheduler;

import com.boco.common.util.debug.LogHome;
import com.boco.transnms.server.bo.base.AbstractScheduleTaskBO;
import java.util.Date;
import javax.management.Notification;
import org.apache.commons.logging.Log;

public abstract class GenericScheduleTaskBO extends AbstractScheduleTaskBO
{
  public GenericScheduleTaskBO(String boName)
  {
    super(boName);
  }

  public void initBO() throws Exception {
    addScheduleTask();
  }

  protected void addScheduleTask() {
    getSchedulerBO().addScheduleTask(this);
  }

  protected void removeScheduleTask() {
    getSchedulerBO().removeScheduleTask(this);
  }

  public void handleNotification(Notification notification, Object handback) {
    LogHome.getLog().info("定时服务通知[message=" + notification.getMessage() + ", timestamp=" + new Date(notification.getTimeStamp()) + ", source=" + notification.getSource() + ", userdata=" + notification.getUserData() + "]");
    try
    {
      doScheduleTask(notification, handback);
      nextScheduleTime();
      addScheduleTask();
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }

  protected SchedulerBO getSchedulerBO() {
    return (SchedulerBO)super.getBO("SchedulerBO");
  }
}