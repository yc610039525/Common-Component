package com.boco.transnms.server.bo.misc;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.common.util.lang.GenericEnum;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.base.GenericEnumDO;
import com.boco.transnms.common.dto.misc.DdSheetState;
import com.boco.transnms.common.dto.misc.LayerRate;
import com.boco.transnms.common.dto.misc.PublicEnum;
import com.boco.transnms.common.dto.misc.SegLayer;
import com.boco.transnms.common.dto.misc.SheetState;
import com.boco.transnms.common.dto.misc.TraphServiceType;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.base.StateLessBoField;
import com.boco.transnms.server.bo.ibo.misc.IEnumBO;
import com.boco.transnms.server.dao.base.DaoHelper;
import com.boco.transnms.server.dao.misc.EnumDAO;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="COMMON", initByAllServer=true)
public class EnumBO extends AbstractBO
  implements IEnumBO
{

  @StateLessBoField
  protected final Map<String, GenericEnum> enumMap = new HashMap();

  @StateLessBoField
  protected final Map<String, GenericEnumDO> specialEnumType = new HashMap();

  @StateLessBoField
  protected final Map<String, GenericEnum> publicEnumMap = new HashMap();

  public void initBO()
    throws Exception
  {
    try
    {
      initSpecialEnumType();
      loadEnums();
      loadPublicEnum();
    } catch (Throwable ex) {
      LogHome.getLog().error("枚举初始化错误", ex);
    }
  }

  protected void initSpecialEnumType() {
    this.specialEnumType.put("SHEET_STATE", new SheetState());
    this.specialEnumType.put("LAYER_RATE", new LayerRate());
    this.specialEnumType.put("DD_SHEET_STATE", new DdSheetState());
    this.specialEnumType.put("TRAPH_SERVICE_TYPE", new TraphServiceType());
    this.specialEnumType.put("SEG_LAYER", new SegLayer());
  }

  public GenericEnum getEnum(String enumName) throws UserException {
    GenericEnum ge = (GenericEnum)this.enumMap.get(enumName);
    if (ge == null) {
      ge = (GenericEnum)this.publicEnumMap.get(enumName);
    }
    return ge;
  }

  public GenericEnum getEnum(BoActionContext actionContext, String enumName) throws UserException {
    GenericEnum ge = (GenericEnum)this.enumMap.get(enumName);
    if (ge == null) {
      ge = (GenericEnum)this.publicEnumMap.get(enumName);
    }
    return ge;
  }

  public void modifyEnum(BoActionContext actionContext, String enumName, String sql) throws UserException
  {
    try {
      getEnumDAO().modifyEnums(sql);
      if (this.publicEnumMap.get(enumName) != null)
        loadPublicEnum();
      else
        reloadEnum(enumName);
    }
    catch (Throwable ex)
    {
      LogHome.getLog().error("", ex);
      throw new UserException(ex);
    }
  }

  protected void loadEnums() {
    loadGenericEnum("DD_SIGN_TYPE");
    loadGenericEnum("DD_ALL_BUSINESS_TYPE");
    loadGenericEnum("DD_ALL_DD_RESULT");
    loadGenericEnum("DD_ALL_APP_TYPE");
    loadGenericEnum("DD_ALL_UNOPEN_REASON");
    loadGenericEnum("DD_ALL_SHEET_TYPE");
    loadGenericEnum("DD_ALL_URGTCLASS");
    loadGenericEnum("SERVICE_TYPE");
    loadGenericEnum("SWITCHDEV_CFG_TYPE");
    loadGenericEnum("MICROWAVE_NE_CFG_TYPE");
    loadGenericEnum("SDH_NE_CFG_TYPE");
    loadGenericEnum("WDM_NE_CFG_TYPE");
    loadGenericEnum("RATE");
    loadGenericEnum("SITE_CFG_TYPE");
    loadGenericEnum("ROOM_CFG_TYPE");
    loadGenericEnum("FAULT_TYPE");
    loadGenericEnum("FAULT_LEVEL");
    loadGenericEnum("FAULT_REASON_TYPE");
    loadGenericEnum("VP_TYPE");
    loadGenericEnum("VPN_SERVICE_TYPE");
    loadGenericEnum("VP_SERVICE_LEVEL");
    loadGenericEnum("EXCHANGE_TYPE");
    Object[] keys = this.specialEnumType.keySet().toArray();
    for (int i = 0; i < keys.length; i++) {
      loadSpecialEnum((GenericEnumDO)this.specialEnumType.get(keys[i]));
    }
    loadPortRate();
  }

  private void reloadEnum(String enumName) {
    GenericEnumDO enumDbo = (GenericEnumDO)this.specialEnumType.get(enumName);
    if (enumDbo == null) {
      loadGenericEnum(enumName);
    }
    else
      loadSpecialEnum(enumDbo);
  }

  protected void loadPublicEnum()
  {
    try {
      this.publicEnumMap.clear();
      PublicEnum publicEnum = new PublicEnum();
      DboCollection dbc = getEnumDAO().getEnums(publicEnum);
      GenericEnum genericEnum = null;
      for (int i = 0; i < dbc.size(); i++) {
        PublicEnum dbo = (PublicEnum)dbc.getAttrField(publicEnum.getClassName(), i);
        long keyNum = dbo.getAttrLong("KEY_NUM");
        String enumType = dbo.getAttrString("ENUM_TYPE");
        String keyValue = dbo.getAttrString("KEY_VALUE");
        genericEnum = (GenericEnum)this.publicEnumMap.get(enumType);
        if (genericEnum == null) {
          genericEnum = new GenericEnum();
        }
        genericEnum.putEnum(Long.valueOf(keyNum), keyValue);
        this.publicEnumMap.put(enumType, genericEnum);
      }
    }
    catch (Throwable ex) {
      LogHome.getLog().error("", ex);
    }
  }

  protected void loadGenericEnum(String enumDboName) {
    try {
      GenericEnumDO dboTemplate = new GenericEnumDO(enumDboName);
      DboCollection dbc = getEnumDAO().getEnums(dboTemplate);
      GenericEnum genericEnum = new GenericEnum();

      for (int i = 0; i < dbc.size(); i++) {
        GenericEnumDO dbo = (GenericEnumDO)dbc.getAttrField(dboTemplate.getClassName(), i);
        long enumValue = dbo.getAttrLong("KEY_NUM");
        String enumName = dbo.getAttrString("KEY_VALUE");
        genericEnum.putEnum(Long.valueOf(enumValue), enumName);
      }
      this.enumMap.put(enumDboName, genericEnum);
    }
    catch (Throwable ex) {
      LogHome.getLog().error(enumDboName + " 不存在");
    }
  }

  public void loadPortRate() {
    try {
      GenericEnumDO dboTemplate = new GenericEnumDO("RATE");
      DboCollection dbc = getEnumDAO().getPortRate(dboTemplate);
      GenericEnum genericEnum = new GenericEnum();

      for (int i = 0; i < dbc.size(); i++) {
        GenericEnumDO dbo = (GenericEnumDO)dbc.getAttrField(dboTemplate.getClassName(), i);
        long enumValue = dbo.getAttrLong("KEY_NUM");
        String enumName = dbo.getAttrString("KEY_VALUE");
        genericEnum.putEnum(Long.valueOf(enumValue), enumName);
      }
      this.enumMap.put("PORT_RATE", genericEnum);
    }
    catch (Throwable ex) {
      LogHome.getLog().error("", ex);
    }
  }

  private void loadSpecialEnum(GenericEnumDO dboTemplate) {
    try {
      GenericEnum specialEnum = new GenericEnum();
      DboCollection dbc = getEnumDAO().getEnums(dboTemplate);
      for (int i = 0; i < dbc.size(); i++) {
        GenericEnumDO dbo = (GenericEnumDO)dbc.getAttrField(dboTemplate.getClassName(), i);
        String enumName = dbo.getAttrString("KEY_VALUE");
        specialEnum.putEnum(dbo, enumName);
      }
      this.enumMap.put(dboTemplate.getClassName(), specialEnum);
    }
    catch (Throwable ex) {
      LogHome.getLog().error(dboTemplate.getClassName() + " 不存在");
    }
  }

  private EnumDAO getEnumDAO() {
    return (EnumDAO)super.getDAO("EnumDAO");
  }

  public DboCollection queryTraphServiceType(BoQueryContext queryContext, String orderString) throws UserException
  {
    try
    {
      return getEnumDAO().queryTraphServiceType(queryContext, orderString);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public TraphServiceType getTraphServiceTypeByObjectId(BoActionContext actionContext, Long objectId) throws UserException {
    try {
      return getEnumDAO().getTraphServiceTypeByObjectId(actionContext, objectId);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public TraphServiceType modifyTraphServiceType(BoActionContext actionContext, TraphServiceType dbo) throws UserException, Exception {
    return getEnumDAO().modifyTraphServiceType(actionContext, dbo);
  }

  public TraphServiceType addTraphServiceType(BoActionContext actionContext, TraphServiceType dbo) throws UserException, Exception {
    return getEnumDAO().addTraphServiceType(actionContext, dbo);
  }

  public DboCollection getTraphServiceTypeBySql(BoActionContext queryContext, String sql) throws UserException, Exception {
    DboCollection dbos = getEnumDAO().selectDBOs(sql, new GenericDO[] { new TraphServiceType() });
    return dbos;
  }
  public void deleteTraphServiceTypeByKeyNum(BoActionContext actionContext, String keyNum) throws UserException, Exception {
    getEnumDAO().deleteTraphServiceTypeByKeyNum(actionContext, keyNum);
  }
  public DataObjectList getExcelCache(String table, String key, String value, String sqlcondition) throws Exception {
    return getEnumDAO().getExcelCache(table, key, value, sqlcondition);
  }

  public void addPublicType(BoActionContext actionContext, String enumName, String keyNum, String keyValue)
    throws Exception
  {
    if (("CESSION_TYPE".equals(enumName)) || ("ATTEMP_SHEET_TYPE".equals(enumName))) {
      DboCollection dbos = getPublicTypeByNum(actionContext, enumName, keyNum);
      if ((dbos != null) && (dbos.size() > 0)) {
        throw new UserException("添加的属性有重复的值,请修改！");
      }
      DboCollection _dbos = getPublicTypeByValue(actionContext, enumName, keyValue);
      if ((_dbos != null) && (_dbos.size() > 0)) {
        throw new UserException("添加的名称有重复,请修改！");
      }
    }

    getEnumDAO().addPublicType(actionContext, enumName, keyNum, keyValue);

    loadPublicEnum();
  }

  public DboCollection getPublicTypeByNum(BoActionContext actionContext, String enumName, String keyNum)
    throws Exception
  {
    return getEnumDAO().getPublicTypeByNum(actionContext, enumName, keyNum);
  }

  public DboCollection getPublicTypeByValue(BoActionContext actionContext, String enumName, String keyValue)
    throws Exception
  {
    return getEnumDAO().getPublicTypeByValue(actionContext, enumName, keyValue);
  }

  public DataObjectList getEnumTypeByName(BoActionContext actionContext, String enumName)
    throws Exception
  {
    try
    {
      return getEnumDAO().getEnumTypeByName(actionContext, enumName); } catch (Exception ex) {
    }
    throw new UserException("根据名称取得公共枚举出错！");
  }

  public void modifyPublicType(BoActionContext actionContext, String enumName, String keyNums, String keyValues)
    throws Exception
  {
    boolean flag = false;
    DataObjectList dbos = getEnumTypeByName(actionContext, enumName);
    String[] key_num = null;
    String[] key_value = null;
    if (DaoHelper.isNotEmpty(keyNums)) {
      key_num = keyNums.split(",");
    }
    if (DaoHelper.isNotEmpty(keyValues)) {
      key_value = keyValues.split(",");
    }

    if ((("CESSION_TYPE".equals(enumName)) || ("ATTEMP_SHEET_TYPE".equals(enumName))) && 
      (key_num != null) && (key_num.length == key_value.length)) {
      for (int i = 0; i < key_num.length; i++) {
        String keyNum = key_num[i];
        String keyValue = key_value[i];
        if ((dbos != null) && (dbos.size() > 0)) {
          for (int j = 0; j < dbos.size(); j++) {
            GenericDO dbo = (GenericDO)dbos.get(j);
            int key = dbo.getAttrInt("1");
            String value = dbo.getAttrString("2");
            if ((!String.valueOf(key).equals(keyNum)) && 
              (value.equals(keyValue))) {
              flag = true;
              throw new UserException("修改的名称" + keyValue + "有重复,请修改！");
            }
          }
        }

      }

    }

    if ((!flag) && 
      (key_num != null) && (key_num.length == key_value.length)) {
      for (int i = 0; i < key_num.length; i++) {
        String keyNum = key_num[i];
        String keyValue = key_value[i];
        getEnumDAO().modifyPublicType(actionContext, enumName, keyNum, keyValue);
      }

    }

    loadPublicEnum();
  }

  public List getCessionTypeInfo(BoActionContext actionContext)
    throws Exception
  {
    try
    {
      return getEnumDAO().getCessionTypeInfo(actionContext); } catch (Exception ex) {
    }
    throw new UserException("获取正在使用的割接类型时出错！");
  }

  public void delPublicType(BoActionContext actionContext, String enumName, String objectIds)
    throws Exception
  {
    if (DaoHelper.isNotEmpty(objectIds)) {
      String[] objectid = objectIds.split(",");
      for (int i = 0; i < objectid.length; i++) {
        getEnumDAO().delPublicType(actionContext, enumName, objectid[i]);
      }
    }

    loadPublicEnum();
  }

  public DataObjectList getAllDeviceEnumFromPublicEnum(BoActionContext actionContext) {
    DataObjectList list = new DataObjectList();
    PublicEnum publicEnum = new PublicEnum();
    DboCollection dbc = null;
    try {
      dbc = getEnumDAO().getEnums(publicEnum);
    } catch (Exception ex) {
      throw new UserException("获取公共枚举类型时出错！");
    }
    GenericEnum genericEnum = null;
    if (dbc != null) {
      for (int i = 0; i < dbc.size(); i++) {
        PublicEnum dbo = (PublicEnum)dbc.getAttrField(publicEnum.getClassName(), i);
        long keyNum = dbo.getAttrLong("KEY_NUM");
        String enumType = dbo.getAttrString("ENUM_TYPE");
        String keyValue = dbo.getAttrString("KEY_VALUE");
        if ((enumType != null) && (enumType.length() > 0) && (
          (enumType.equals("RACK")) || (enumType.equals("SUBRACK")) || (enumType.equals("SHELF")) || (enumType.equals("SUBSHELF")) || (enumType.equals("SLOT")) || (enumType.equals("SUBSLOT")) || (enumType.equals("CARD")) || (enumType.equals("ODFMODULE")) || (enumType.equals("DDFMODULE"))))
        {
          list.add(dbo);
        }
      }
    }

    return list;
  }

  public static final class EnumName
  {
    public static final String DD_SIGN_TYPE = "DD_SIGN_TYPE";
    public static final String DD_ALL_BUSSINESS_TYPE = "DD_ALL_BUSINESS_TYPE";
    public static final String DD_ALL_APP_TYPE = "DD_ALL_APP_TYPE";
    public static final String DD_ALL_DD_RESULT = "DD_ALL_DD_RESULT";
    public static final String DD_ALL_SHEET_TYPE = "DD_ALL_SHEET_TYPE";
    public static final String DD_ALL_UNOPEN_REASON = "DD_ALL_UNOPEN_REASON";
    public static final String DD_ALL_URGTCLASS = "DD_ALL_URGTCLASS";
    public static final String SERVICE_TYPE = "SERVICE_TYPE";
    public static final String SWITCHDEV_CFG_TYPE = "SWITCHDEV_CFG_TYPE";
    public static final String SDH_NE_CFG_TYPE = "SDH_NE_CFG_TYPE";
    public static final String MICROWAVE_NE_CFG_TYPE = "MICROWAVE_NE_CFG_TYPE";
    public static final String WDM_NE_CFG_TYPE = "WDM_NE_CFG_TYPE";
    public static final String ROOM_CFG_TYPE = "ROOM_CFG_TYPE";
    public static final String SITE_CFG_TYPE = "SITE_CFG_TYPE";
    public static final String SHEET_STATE = "SHEET_STATE";
    public static final String DD_SHEET_STATE = "DD_SHEET_STATE";
    public static final String RATE = "RATE";
    public static final String LAYER_RATE = "LAYER_RATE";
    public static final String TRAPH_SERVICE_TYPE = "TRAPH_SERVICE_TYPE";
    public static final String SEG_LAYER = "SEG_LAYER";
    public static final String FAULT_TYPE = "FAULT_TYPE";
    public static final String FAULT_LEVEL = "FAULT_LEVEL";
    public static final String FAULT_REASON_TYPE = "FAULT_REASON_TYPE";
    public static final String VP_TYPE = "VP_TYPE";
    public static final String VPN_SERVICE_TYPE = "VPN_SERVICE_TYPE";
    public static final String VP_SERVICE_LEVEL = "VP_SERVICE_LEVEL";
    public static final String EXCHANGE_TYPE = "EXCHANGE_TYPE";
    public static final String TRAPH_IMPORT_LEVE = "TRAPH_IMPORT_LEVEL";
    public static final String TRAPH_GROUP_NAME = "TRAPH_GROUP_NAME";
    public static final String EOMS_STATE = "EOMS_STATE";
    public static final String CESSION_TYPE = "CESSION_TYPE";
    public static final String ATTEMP_SHEET_TYPE = "ATTEMP_SHEET_TYPE";
    public static final String INTERFACE_TYPE = "INTERFACE_TYPE";
    public static final String IMPORT_PROTECT_TYPE = "IMPORT_PROTECT_TYPE";
    public static final String CESSION_BELOND_TYPE = "CESSION_BELOND_TYPE";
  }
}