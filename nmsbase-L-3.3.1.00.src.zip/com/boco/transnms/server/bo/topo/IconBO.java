package com.boco.transnms.server.bo.topo;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.Icon;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.ibo.topo.IIconBO;
import com.boco.transnms.server.dao.topo.IconDAO;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="CM")
public class IconBO extends AbstractBO
  implements IIconBO
{
  private IconDAO getIconDAO()
  {
    return (IconDAO)super.getDAO("IconDAO");
  }

  public Icon getIconByCuid(BoActionContext actionContext, String iconCuid) throws UserException {
    try {
      return getIconDAO().getIconByCuid(actionContext, iconCuid);
    } catch (Exception ex) {
      LogHome.getLog().error("通过图例CUID获取图例信息失败", ex);
      throw new UserException(ex);
    }
  }

  public DataObjectList getIcons(BoActionContext actionContext, DataObjectList iconIds) throws UserException
  {
    return null;
  }

  public DataObjectList getIconSql(BoActionContext actionContext) throws UserException {
    try {
      return getIconDAO().getIconSql(actionContext);
    } catch (Exception ex) {
      LogHome.getLog().error("获取所有图例失败", ex);
      throw new UserException(ex);
    }
  }

  public Icon modifyIcon(BoActionContext actionContext, Icon icon) throws UserException
  {
    try {
      getIconDAO().modifyIcon(actionContext, icon);
      return icon;
    } catch (Throwable e) {
      LogHome.getLog().info("单个修改图例对象时出错" + e.getMessage());
      throw new UserException(e);
    }
  }

  public DataObjectList getIconModuleAndAll(BoActionContext actionContext, Icon icon)
    throws UserException
  {
    try
    {
      return getIconDAO().getRelationIconAll(icon);
    }
    catch (Throwable e) {
      LogHome.getLog().info("getIconModuleAndAll得到图例所有模块下的图例对象时出错" + e.getMessage());
    }return null;
  }

  public Map getIconModAndIcon(BoActionContext actionContext) throws UserException
  {
    try
    {
      Map map = new HashMap();
      DataObjectList list1 = new DataObjectList();
      List list2 = new ArrayList();

      DataObjectList iconlist = getIconSql(actionContext);
      iconlist.sort("SYSTEM_LABEL_CN", true);

      for (int i = 0; i < iconlist.size(); i++) {
        Icon icon = (Icon)iconlist.get(i);
        String systemLabelCn = icon.getSystemLabelCn();
        boolean ishave = false;
        for (int j = 0; j < list1.size(); j++) {
          Icon iconTemp = (Icon)list1.get(j);
          if (systemLabelCn.compareTo(iconTemp.getSystemLabelCn()) == 0) {
            DataObjectList lst = (DataObjectList)list2.get(j);
            lst.add(icon);
            ishave = true;
            break;
          }
        }
        if (!ishave) {
          list1.add(icon);
          DataObjectList lst = new DataObjectList();
          lst.add(icon);
          list2.add(lst);
        }
      }
      list1.sort("SYSTEM_LABEL_CN", true);
      for (int j = 0; j < list1.size(); j++) {
        map.put((Icon)list1.get(j), (DataObjectList)list2.get(j));
      }
      return map;
    } catch (Throwable e) {
      LogHome.getLog().info("getIconModAndIcon得到模块和模块下的图例对象时出错" + e.getMessage());
    }return null;
  }

  public Map getAllIcon(BoActionContext actionContext)
    throws UserException
  {
    try
    {
      Map map = new HashMap();
      DataObjectList iconlist = getIconSql(actionContext);
      for (int i = 0; i < iconlist.size(); i++) {
        Icon icon = (Icon)iconlist.get(i);
        String iconCuid = icon.getCuid();
        String iconPathCn = icon.getIconPathCn();
        map.put(iconCuid, iconPathCn);
      }
      return map;
    } catch (Throwable e) {
      LogHome.getLog().info("getAllIcon所有图例对象时出错" + e.getMessage());
    }return null;
  }

  public DataObjectList getDefaultIconBySql(BoActionContext actionContext) throws UserException
  {
    try {
      return getIconDAO().getIconSql(actionContext);
    } catch (Exception ex) {
      LogHome.getLog().error("获取所有图例失败", ex);
      throw new UserException(ex);
    }
  }
}