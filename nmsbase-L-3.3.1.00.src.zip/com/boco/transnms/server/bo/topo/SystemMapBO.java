package com.boco.transnms.server.bo.topo;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.bussiness.helper.TopoHelper;
import com.boco.transnms.common.dto.District;
import com.boco.transnms.common.dto.FiberCab;
import com.boco.transnms.common.dto.FiberDp;
import com.boco.transnms.common.dto.FiberJointBox;
import com.boco.transnms.common.dto.Inflexion;
import com.boco.transnms.common.dto.Manhle;
import com.boco.transnms.common.dto.MapToObject;
import com.boco.transnms.common.dto.Pole;
import com.boco.transnms.common.dto.Site;
import com.boco.transnms.common.dto.Stone;
import com.boco.transnms.common.dto.SystemMap;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.dm.LocatedPoint;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.ibo.misc.ISecurityBO;
import com.boco.transnms.server.bo.ibo.topo.ISystemMapBO;
import com.boco.transnms.server.dao.area.DistrictDAO;
import com.boco.transnms.server.dao.base.DaoHelper;
import com.boco.transnms.server.dao.topo.SystemMapDAO;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="CM")
public class SystemMapBO extends AbstractBO
  implements ISystemMapBO
{
  private SystemMapDAO getSystemMapDAO()
  {
    return (SystemMapDAO)super.getDAO("SystemMapDAO");
  }

  public DistrictDAO getDistrictDAO() {
    return (DistrictDAO)super.getDAO("DistrictDAO");
  }

  public SystemMap addSystemMap(BoActionContext actionContext, SystemMap systeMap)
    throws UserException
  {
    try
    {
      GenericDO district = (GenericDO)systeMap.getAttrValue("RELATED_DISTRICT_CUID");
      systeMap.setRelatedDistrictCuid(district.getCuid());
      systeMap = getSystemMapDAO().addSystemMap(actionContext, systeMap);
      District dist = getDistrictDAO().getDistrictByCuid(new BoActionContext(), district.getCuid());
      systeMap.setAttrValue("RELATED_DISTRICT_CUID", dist);
      return systeMap;
    } catch (Throwable ex) {
      LogHome.getLog().info("addMapToObject增加地图与对象关系对象出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public SystemMap modifySystemMap(BoActionContext actionContext, SystemMap systeMap) throws UserException {
    try {
      GenericDO district = (GenericDO)systeMap.getAttrValue("RELATED_DISTRICT_CUID");
      systeMap.setRelatedDistrictCuid(district.getCuid());
      systeMap = getSystemMapDAO().modifySystemMap(actionContext, systeMap);
      district = getDistrictDAO().getDistrictByCuid(new BoActionContext(), district.getCuid());
      systeMap.setAttrValue("RELATED_DISTRICT_CUID", district);
      return systeMap;
    } catch (Throwable ex) {
      LogHome.getLog().info("modifySystemMap修改地图与对象关系对象出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public void deleteSystemMap(BoActionContext actionContext, SystemMap systeMap) throws UserException {
    try {
      String sql = "MAP_CUID = '" + systeMap.getCuid() + "'";

      DataObjectList list = getSystemMapDAO().getObjectsBySql(sql, new MapToObject(), 0);
      if ((list != null) && (list.size() > 0)) {
        throw new UserException("已有地图定位点，不能删除地图！");
      }
      getSystemMapDAO().deleteSystemMap(actionContext, systeMap);
    } catch (Throwable ex) {
      LogHome.getLog().info("deleteSystemMap删除地图与对象关系对象出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public DataObjectList getAllSystemMaps(BoActionContext actionContext)
    throws UserException
  {
    try
    {
      DataObjectList sysmaps = getSystemMapDAO().getAllSystemMaps(actionContext);
      for (int i = 0; i < sysmaps.size(); i++) {
        SystemMap map = (SystemMap)sysmaps.get(i);
        String districcuid = map.getRelatedDistrictCuid();
        District district = getDistrictDAO().getDistrictByCuid(new BoActionContext(), districcuid);
        map.setAttrValue("RELATED_DISTRICT_CUID", district);
      }
      return sysmaps;
    } catch (Throwable ex) {
      LogHome.getLog().info("获取所有地图对象时出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public SystemMap getSystemMapByCuid(BoActionContext actionContext, String systeMapCuid) throws UserException {
    try {
      return getSystemMapDAO().getSystemMapByCuid(actionContext, systeMapCuid);
    } catch (Throwable ex) {
      LogHome.getLog().info("deleteSystemMap删除地图与对象关系对象出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public DataObjectList getSystemMapByName(BoActionContext actionContext, String mapName) throws UserException
  {
    try {
      DataObjectList list = getSystemMapDAO().getSystemMapByName(actionContext, mapName);
      if (list == null);
      return new DataObjectList();
    }
    catch (Throwable ex)
    {
      LogHome.getLog().info("根据地图名字找系统地图出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public List<LocatedPoint> getLocateObjectsByMapCuid(BoActionContext actionContext, String systemMapCuid, GenericDO dboTemplate)
    throws UserException
  {
    long startTime = System.currentTimeMillis();
    List resList = new ArrayList();
    try {
      DataObjectList allMapToObjects = getSystemMapDAO().getAllObjByClass(new MapToObject(), 0);
      DataObjectList fullObjects = new DataObjectList();

      if (dboTemplate.getClassName().equals("GenericDO")) {
        List siteCuidList = new ArrayList();
        List manhleCuidList = new ArrayList();
        List poleCuidList = new ArrayList();
        List stoneCuidList = new ArrayList();
        List inflexionCuidList = new ArrayList();
        List fiberCabCuidList = new ArrayList();
        List fiberDpCuidList = new ArrayList();
        List fiberJointBoxCuidList = new ArrayList();
        for (int i = 0; i < allMapToObjects.size(); i++) {
          MapToObject mapToObject = (MapToObject)allMapToObjects.get(i);
          if (systemMapCuid.equals(mapToObject.getMapCuid()))
          {
            Object obj = mapToObject.getAttrValue("OBJECT_CUID");
            String objectCuid = DaoHelper.getRelatedCuid(obj);
            if (objectCuid != null)
            {
              if (objectCuid.startsWith("SITE"))
                siteCuidList.add(objectCuid);
              else if (objectCuid.startsWith("MANHLE"))
                manhleCuidList.add(objectCuid);
              else if (objectCuid.startsWith("POLE"))
                poleCuidList.add(objectCuid);
              else if (objectCuid.startsWith("STONE"))
                stoneCuidList.add(objectCuid);
              else if (objectCuid.startsWith("INFLEXION"))
                inflexionCuidList.add(objectCuid);
              else if (objectCuid.startsWith("FIBER_CAB"))
                fiberCabCuidList.add(objectCuid);
              else if (objectCuid.startsWith("FIBER_DP"))
                fiberDpCuidList.add(objectCuid);
              else if (objectCuid.startsWith("FIBER_JOINT_BOX"))
                fiberJointBoxCuidList.add(objectCuid); 
            }
          }
        }
        if (siteCuidList.size() > 0) {
          fullObjects.addAll(getSystemMapDAO().getObjsByCuids(siteCuidList, new Site()));
        }
        if (manhleCuidList.size() > 0) {
          fullObjects.addAll(getSystemMapDAO().getObjsByCuids(manhleCuidList, new Manhle()));
        }
        if (poleCuidList.size() > 0) {
          fullObjects.addAll(getSystemMapDAO().getObjsByCuids(poleCuidList, new Pole()));
        }
        if (stoneCuidList.size() > 0) {
          fullObjects.addAll(getSystemMapDAO().getObjsByCuids(stoneCuidList, new Stone()));
        }
        if (inflexionCuidList.size() > 0) {
          fullObjects.addAll(getSystemMapDAO().getObjsByCuids(inflexionCuidList, new Inflexion()));
        }
        if (fiberCabCuidList.size() > 0) {
          fullObjects.addAll(getSystemMapDAO().getObjsByCuids(fiberCabCuidList, new FiberCab()));
        }
        if (fiberDpCuidList.size() > 0) {
          fullObjects.addAll(getSystemMapDAO().getObjsByCuids(fiberDpCuidList, new FiberDp()));
        }
        if (fiberJointBoxCuidList.size() > 0)
          fullObjects.addAll(getSystemMapDAO().getObjsByCuids(fiberJointBoxCuidList, new FiberJointBox()));
      }
      else {
        List cuidList = new ArrayList();
        for (int i = 0; i < allMapToObjects.size(); i++) {
          MapToObject mapToObject = (MapToObject)allMapToObjects.get(i);
          if (systemMapCuid.equals(mapToObject.getMapCuid()))
          {
            Object obj = mapToObject.getAttrValue("OBJECT_CUID");
            String objectCuid = DaoHelper.getRelatedCuid(obj);
            if (objectCuid != null)
            {
              if (objectCuid.startsWith(dboTemplate.getClassName()))
                cuidList.add(objectCuid); 
            }
          }
        }
        if (cuidList.size() > 0) {
          fullObjects.addAll(getSystemMapDAO().getObjsByCuids(cuidList, dboTemplate));
        }
      }

      for (GenericDO dto : fullObjects)
        if (dto != null)
        {
          try
          {
            LocatedPoint locatedPoint = TopoHelper.copyLocatePoint(dto);
            if (locatedPoint != null)
              resList.add(locatedPoint);
          }
          catch (Exception ex) {
            LogHome.getLog().error(dto.getCuid(), ex);
          }
        }
      long endTime = System.currentTimeMillis();
      LogHome.getLog().info("加载地图（" + systemMapCuid + "）上的定位点个数：" + resList.size() + " 耗时: " + (endTime - startTime));

      return resList;
    } catch (Throwable e) {
      LogHome.getLog().info("getLocateObjectsByMapCuid得到地图对象时出错" + e.getMessage());
    }return null;
  }

  public List<LocatedPoint> getLocateSites(BoActionContext actionContext, SystemMap systemMap, HashSet set)
    throws UserException
  {
    List resList = new ArrayList();
    try
    {
      DataObjectList dboCollection = getSystemMapDAO().getObjByAttrs(new BoQueryContext(), new Site());

      if ((dboCollection != null) && (dboCollection.size() > 0)) {
        for (int i = 0; i < dboCollection.size(); i++) {
          GenericDO gdo = (GenericDO)dboCollection.get(i);
          if (gdo != null)
            try {
              LocatedPoint locatedPoint = TopoHelper.copyLocatePoint(gdo);
              if ((null != locatedPoint.getRelatedDistrictCuid()) && (set.contains(locatedPoint.getRelatedDistrictCuid())))
              {
                resList.add(locatedPoint);
              }
            } catch (Exception ex) {
              LogHome.getLog().error(gdo.getCuid(), ex);
            }
        }
      }
    }
    catch (Exception e)
    {
      LogHome.getLog().error("查询站点出错", e);
    }

    return resList;
  }

  public DataObjectList getLocateObjectsByMap(BoActionContext actionContext, SystemMap systemMap, GenericDO dboTemplate) throws UserException
  {
    LogHome.getLog().info("getLocateObjectsByMapCuid加载定位点设施类型：" + dboTemplate.getClassName());
    long loadstart = System.currentTimeMillis();
    DataObjectList resList = new DataObjectList();
    try
    {
      Map userMagDistrictMap = new HashMap();

      String userId = actionContext.getUserId();
      DataObjectList districts = ((ISecurityBO)super.getBO("ISecurityBO")).getUserDistricts(actionContext, userId);
      TopoHelper.putListToMap(districts, userMagDistrictMap);

      MapToObject mto = new MapToObject();
      mto.setMapCuid(systemMap.getCuid());

      DataObjectList mapToObjects = getSystemMapDAO().getObjByAttrs(new BoQueryContext(), mto);
      for (int i = 0; i < mapToObjects.size(); i++) {
        MapToObject mapToObject = (MapToObject)mapToObjects.get(i);
        if (dboTemplate.getClassName().equals("GenericDO")) {
          if ((mapToObject.getObjectCuid().startsWith("SITE")) || (mapToObject.getObjectCuid().startsWith("MANHLE")) || (mapToObject.getObjectCuid().startsWith("POLE")) || (mapToObject.getObjectCuid().startsWith("STONE")) || (mapToObject.getObjectCuid().startsWith("INFLEXION")) || (mapToObject.getObjectCuid().startsWith("FIBER_CAB")) || (mapToObject.getObjectCuid().startsWith("FIBER_DP")) || (mapToObject.getObjectCuid().startsWith("FIBER_JOINT_BOX")))
          {
            GenericDO dbo = getSystemMapDAO().getObjByCuid(mapToObject.getObjectCuid());
            if (dbo != null)
              resList.add(dbo);
          }
        }
        else if (mapToObject.getObjectCuid().indexOf(dboTemplate.getClassName()) >= 0) {
          GenericDO dbo = getSystemMapDAO().getObjByCuid(mapToObject.getObjectCuid());
          if (dbo != null) {
            resList.add(dbo);
          }
        }
      }
      long loadend = System.currentTimeMillis();
      LogHome.getLog().info("加载" + actionContext.getUserName() + " 在地图（" + systemMap.getCuid() + "）上的定位点个数：" + resList.size() + " 耗时: " + (loadend - loadstart));

      return resList;
    } catch (Throwable e) {
      LogHome.getLog().info("getLocateObjectsByMapCuid得到地图" + dboTemplate.getClassName() + "对象时出错" + e.getMessage());
    }return null;
  }

  private String getDistrictsInSql(BoActionContext queryContext, String sql)
    throws UserException
  {
    try
    {
      String userId = queryContext.getUserId();
      String sqlin;
      if (!userId.equals("SYS_USER-0")) {
        DataObjectList districts = null;
        try {
          districts = ((ISecurityBO)super.getBO("ISecurityBO")).getUserDistricts(queryContext, userId);
        } catch (Throwable ex) {
          LogHome.getLog().error("加载可管理区域对象出错", ex);
          throw new UserException(ex);
        }
        if (districts != null) {
          sqlin = "";
          for (int i = 0; i < districts.size(); i++) {
            String districtCuid = ((GenericDO)districts.get(i)).getCuid();
            if (districtCuid.equals("DISTRICT-00001")) {
              return sql;
            }
            sqlin = sqlin + "'" + districtCuid + "',";
          }
        }
      }
      return sql + "RELATED_DISTRICT_CUID" + " in (" + sqlin + "'0')";
    }
    catch (Throwable e)
    {
      LogHome.getLog().info("getDistrictsInSql得到用户所属区域sql时出错" + e.getMessage());
      throw new UserException(e);
    }
  }

  public DataObjectList getDefaultSystemMapsByDistrictDuids(BoActionContext context, String[] districtCuids)
    throws UserException
  {
    DataObjectList sysmaplist = new DataObjectList();
    try {
      for (String districtCuid : districtCuids)
        sysmaplist.addAll(getSystemMapDAO().getDefaultSystemMap(context, districtCuid));
    }
    catch (Exception ex) {
      throw new UserException(ex);
    }
    return sysmaplist;
  }

  public SystemMap getDefaultSystemMap(BoActionContext context, String DistrictCuid) throws UserException {
    DataObjectList sysmaplist = new DataObjectList();
    try {
      sysmaplist = getSystemMapDAO().getDefaultSystemMap(context, DistrictCuid);
    } catch (Exception ex) {
      ex.printStackTrace();
      return null;
    }
    SystemMap sysmap = null;
    if (sysmaplist.size() > 0) {
      sysmap = (SystemMap)sysmaplist.get(0);
    }
    return sysmap;
  }

  public boolean isHaveRelatedObj(String className, GenericDO deleteObj)
    throws UserException
  {
    if (deleteObj != null) {
      if (deleteObj.getClassName().trim().equals("DISTRICT")) {
        String districtCuid = deleteObj.getCuid();
        DataObjectList list = new DataObjectList();
        String sql = "RELATED_DISTRICT_CUID = '" + districtCuid + "'";
        try
        {
          list = getSystemMapDAO().getObjectsBySql(sql, new SystemMap(), 0);
        } catch (Throwable e) {
          LogHome.getLog().info("isHaveRelatedObj判断是否存在SystemMap对象时出错" + e.getMessage());
        }
        return (list != null) && (list.size() > 0);
      }
      return false;
    }

    throw new UserException("GenericDO 为空");
  }

  public int getRelatedDeleteObjCount(String className, GenericDO deleteObj)
    throws UserException
  {
    if (deleteObj != null) {
      if (deleteObj.getClassName().trim().equals("DISTRICT")) {
        String districtCuid = deleteObj.getCuid();
        int count = 0;
        String sql = "select count(*) from SYSTEM_MAP where RELATED_DISTRICT_CUID ='" + districtCuid + "' ";
        try
        {
          count = getSystemMapDAO().getCalculateValue(sql);
        } catch (Throwable e) {
          LogHome.getLog().info("getRelatedDeleteObjCount得到SystemMap对象数量时出错" + e.getMessage());
        }
        return count;
      }
      return -1;
    }

    throw new UserException("GenericDO 为空");
  }

  public DataObjectList getRelatedDeleteObjects(String className, GenericDO deleteObj)
    throws UserException
  {
    if (deleteObj != null) {
      if (deleteObj.getClassName().trim().equals("DISTRICT")) {
        String districtCuid = deleteObj.getCuid();
        DataObjectList list = new DataObjectList();
        String sql = "RELATED_DISTRICT_CUID = '" + districtCuid + "'";
        try
        {
          list = getSystemMapDAO().getObjectsBySql(sql, new SystemMap(), 0);
        } catch (Throwable e) {
          LogHome.getLog().info("getRelatedDeleteObjects得到SystemMap对象时出错" + e.getMessage());
        }
        return list;
      }
      return null;
    }

    throw new UserException("GenericDO 为空");
  }

  public void deleteReletedOfObject(String className, GenericDO deleteObj)
    throws UserException
  {
    BoActionContext actionContext = new BoActionContext();
    if (deleteObj != null) {
      if (deleteObj.getClassName().trim().equals("DISTRICT")) {
        String districtCuid = deleteObj.getCuid();
        DataObjectList list = new DataObjectList();
        String sql = "RELATED_DISTRICT_CUID = '" + districtCuid + "'";
        try
        {
          list = getSystemMapDAO().getObjectsBySql(sql, new SystemMap(), 0);
        } catch (Throwable e) {
          LogHome.getLog().info("getSystemMapeBySql得到SystemMap对象时出错" + e.getMessage());
        }
        if ((list != null) && (list.size() > 0))
          try {
            for (int i = 0; i < list.size(); i++)
              deleteSystemMap(actionContext, (SystemMap)list.get(i));
          }
          catch (Throwable e) {
            LogHome.getLog().info("deleteReletedOfObject批量删除SystemMap对象时出错" + e.getMessage());
            throw new UserException(e.getMessage());
          }
      }
    }
    else
      throw new UserException("GenericDO 为空");
  }
}