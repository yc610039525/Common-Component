package com.boco.transnms.server.bo.topo;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.bussiness.consts.NetEnum;
import com.boco.transnms.common.bussiness.consts.NetEnum.TransMedia;
import com.boco.transnms.common.bussiness.consts.TransSystemEnum;
import com.boco.transnms.common.bussiness.consts.TransSystemEnum.TransSysLevel;
import com.boco.transnms.common.dto.MicrowaveSystem;
import com.boco.transnms.common.dto.PdhSystem;
import com.boco.transnms.common.dto.SdhSystem;
import com.boco.transnms.common.dto.ThemeMap;
import com.boco.transnms.common.dto.WdmSystem;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.ibo.misc.ISecurityBO;
import com.boco.transnms.server.bo.ibo.topo.IThemeMapBO;
import com.boco.transnms.server.dao.topo.ThemeMapDAO;
import java.util.HashMap;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="CM")
public class ThemeMapBO extends AbstractBO
  implements IThemeMapBO
{
  public ThemeMapDAO getThemeMapDAO()
  {
    return (ThemeMapDAO)super.getDAO("ThemeMapDAO");
  }

  public ThemeMap addThemeMap(BoActionContext actionContext, ThemeMap themeMap) throws UserException {
    try {
      return getThemeMapDAO().addThemeMap(actionContext, themeMap);
    } catch (Exception ex) {
      LogHome.getLog().error("添加主题图失败,ThemeMapBO.addThemeMap()" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public ThemeMap getThemeMapByUser(BoActionContext actionContext, String userCuid, Long themeMapType) throws UserException {
    try {
      DataObjectList list = getThemeMapDAO().getThemeMapByUser(actionContext, userCuid, themeMapType);
      if (list.size() > 0) {
        return (ThemeMap)list.get(0);
      }
      return null;
    } catch (Exception ex) {
      LogHome.getLog().error("读取主题图失败,ThemeMapBO.getThemeMapByUser()", ex);
      throw new UserException(ex);
    }
  }

  public ThemeMap getThemeMapByCuid(BoActionContext actionContext, String cuid) throws UserException {
    try {
      return getThemeMapDAO().getThemeMapByCuid(actionContext, cuid);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex);
    }
  }

  public DataObjectList getAllThemeMapsByUserCUID(BoActionContext actionContext, String userCuid, Long themeMapType) throws UserException {
    try {
      return getThemeMapDAO().getAllThemeMapsByUserCUID(actionContext, userCuid, themeMapType);
    }
    catch (Throwable ex)
    {
      LogHome.getLog().error("", ex);
      throw new UserException(ex);
    }
  }

  public void modifyThemeMap(BoActionContext actionContext, ThemeMap themeMap) throws UserException {
    try {
      getThemeMapDAO().modifyThemeMap(actionContext, themeMap);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex);
    }
  }

  public void deleteThemeMap(BoActionContext actionContext, ThemeMap themeMap) throws UserException {
    try {
      getThemeMapDAO().deleteThemeMap(actionContext, themeMap);
    } catch (Exception ex) {
      LogHome.getLog().error("删除主题图失败,ThemeMapBO.addThemeMap()" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public void addDefaultThemeMapByUser(BoActionContext actionContext, DataObjectList themeMapList)
    throws UserException
  {
    try
    {
      getThemeMapDAO().setDefaultThemeMapByUser(actionContext, themeMapList);
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public ThemeMap getDefaultThemeMap(BoActionContext context, Long themeMapType) {
    String sUserCuid = context.getUserId();
    DataObjectList maplist = getAllThemeMapsByUserCUID(context, sUserCuid, themeMapType);
    ThemeMap tdmap = null;
    if ((maplist != null) && (maplist.size() > 0)) {
      for (int i = 0; i < maplist.size(); i++) {
        ThemeMap tmap = (ThemeMap)maplist.get(i);
        if (tmap.getDefaultThemeMap()) {
          return tmap;
        }
        tdmap = tmap;
      }
    }

    return tdmap;
  }

  public String getTransSysMedia(BoActionContext context) throws UserException {
    String strTransSysMedia = "";
    HashMap mediaMap = new HashMap();
    try
    {
      String sql = "select distinct TRANS_MEDIA from SDH_SYSTEM";
      DboCollection dbcSdh = getThemeMapDAO().selectDBOs(sql, new GenericDO[] { new SdhSystem() });
      for (int i = 0; i < dbcSdh.size(); i++) {
        SdhSystem sdhsys = (SdhSystem)dbcSdh.getAttrField("SDH_SYSTEM", i);
        Long strmedia = Long.valueOf(sdhsys.getTransMedia());
        if (!mediaMap.containsKey(strmedia)) {
          mediaMap.put(strmedia, strmedia);
          strTransSysMedia = strTransSysMedia + "," + sdhsys.getTransMedia();
        }
      }
    } catch (Exception ex) {
      LogHome.getLog().debug(ex);
    }
    try
    {
      String sql = "select distinct TRANS_MEDIA from PDH_SYSTEM";
      DboCollection dbcPdh = getThemeMapDAO().selectDBOs(sql, new GenericDO[] { new PdhSystem() });
      for (int i = 0; i < dbcPdh.size(); i++) {
        PdhSystem pdhsys = (PdhSystem)dbcPdh.getAttrField("PDH_SYSTEM", i);
        Long strmedia = Long.valueOf(pdhsys.getTransMedia());
        if (!mediaMap.containsKey(strmedia)) {
          mediaMap.put(strmedia, strmedia);
          strTransSysMedia = strTransSysMedia + "," + pdhsys.getTransMedia();
        }
      }
    } catch (Exception ex) {
      LogHome.getLog().debug(ex);
    }
    try
    {
      String sql = "select distinct TRANS_MEDIA from WDM_SYSTEM";
      DboCollection dbcWdm = getThemeMapDAO().selectDBOs(sql, new GenericDO[] { new WdmSystem() });
      for (int i = 0; i < dbcWdm.size(); i++) {
        WdmSystem wdmsys = (WdmSystem)dbcWdm.getAttrField("WDM_SYSTEM", i);
        Long strmedia = Long.valueOf(wdmsys.getTransMedia());
        if (!mediaMap.containsKey(strmedia)) {
          mediaMap.put(strmedia, strmedia);
          strTransSysMedia = strTransSysMedia + "," + wdmsys.getTransMedia();
        }
      }
    } catch (Exception ex) {
      LogHome.getLog().debug(ex);
    }

    return strTransSysMedia;
  }

  private DataObjectList getAllTransSysList(BoActionContext actionContext, String sql, String condition) {
    DataObjectList returnList = new DataObjectList();
    String strSql = "";
    try
    {
      if (condition.equals(""))
        strSql = sql + "SDH_SYSTEM";
      else {
        strSql = sql + "SDH_SYSTEM where " + condition;
      }
      DboCollection dbcSdh = getThemeMapDAO().selectDBOs(strSql, new GenericDO[] { new SdhSystem() });
      for (int i = 0; i < dbcSdh.size(); i++) {
        SdhSystem sdhsys = (SdhSystem)dbcSdh.getAttrField("SDH_SYSTEM", i);
        returnList.add(sdhsys);
      }
    } catch (Exception ex) {
      LogHome.getLog().debug(ex);
    }
    try
    {
      if (condition.equals(""))
        strSql = sql + "PDH_SYSTEM";
      else {
        strSql = sql + "PDH_SYSTEM where " + condition;
      }
      DboCollection dbcPdh = getThemeMapDAO().selectDBOs(strSql, new GenericDO[] { new PdhSystem() });
      for (int i = 0; i < dbcPdh.size(); i++) {
        PdhSystem pdhsys = (PdhSystem)dbcPdh.getAttrField("PDH_SYSTEM", i);
        returnList.add(pdhsys);
      }
    } catch (Exception ex) {
      LogHome.getLog().debug(ex);
    }
    try
    {
      if (condition.equals(""))
        strSql = sql + "WDM_SYSTEM";
      else {
        strSql = sql + "WDM_SYSTEM where " + condition;
      }
      DboCollection dbcwdm = getThemeMapDAO().selectDBOs(strSql, new GenericDO[] { new WdmSystem() });
      for (int i = 0; i < dbcwdm.size(); i++) {
        WdmSystem wdmsys = (WdmSystem)dbcwdm.getAttrField("WDM_SYSTEM", i);
        returnList.add(wdmsys);
      }
    } catch (Exception ex) {
      LogHome.getLog().debug(ex);
    }
    try
    {
      if (condition.equals(""))
        strSql = sql + "MICROWAVE_SYSTEM";
      else {
        strSql = sql + "MICROWAVE_SYSTEM where " + condition;
      }
      DboCollection dbcwic = getThemeMapDAO().selectDBOs(strSql, new GenericDO[] { new MicrowaveSystem() });
      for (int i = 0; i < dbcwic.size(); i++) {
        MicrowaveSystem micsys = (MicrowaveSystem)dbcwic.getAttrField("MICROWAVE_SYSTEM", i);
        returnList.add(micsys);
      }
    } catch (Exception ex) {
      LogHome.getLog().debug(ex);
    }
    return returnList;
  }

  public DataObjectList getTransSystemBySelCondition(BoActionContext actionContext, GenericDO conditionDO) throws UserException {
    DataObjectList returnList = new DataObjectList();
    String sql = "select * from ";
    String strcondition = "";
    String syslev = conditionDO.getAttrString("SYSLEVEL").trim();
    String syscls = conditionDO.getAttrString("SYSCLASS").trim();
    String sysmed = conditionDO.getAttrString("SYSMEDIA").trim();
    String sysnam = conditionDO.getAttrString("SYSNAME").trim();
    if ((syslev.equals("")) && (syscls.equals("")) && (sysmed.equals("")) && (sysnam.equals("")))
    {
      strcondition = getSqlCondition(actionContext, syslev, sysmed, sysnam, strcondition);
      return getAllTransSysList(actionContext, sql, strcondition);
    }
    if (syscls.equals(""))
    {
      strcondition = getSqlCondition(actionContext, syslev, sysmed, sysnam, strcondition);
      return getAllTransSysList(actionContext, sql, strcondition);
    }

    if (syscls.equals("SDH")) {
      sql = sql + "SDH_SYSTEM";
      strcondition = getSqlCondition(actionContext, syslev, sysmed, sysnam, strcondition);
      if (!strcondition.equals(""))
        sql = sql + " where " + strcondition;
      try
      {
        DboCollection dbcSdh = getThemeMapDAO().selectDBOs(sql, new GenericDO[] { new SdhSystem() });
        for (int i = 0; i < dbcSdh.size(); i++) {
          SdhSystem sdhsys = (SdhSystem)dbcSdh.getAttrField("SDH_SYSTEM", i);
          returnList.add(sdhsys);
        }
      } catch (Exception ex) {
        LogHome.getLog().error(ex);
      }
    } else if (syscls.equals("PDH")) {
      sql = sql + "PDH_SYSTEM";
      strcondition = getSqlCondition(actionContext, syslev, sysmed, sysnam, strcondition);
      if (!strcondition.equals(""))
        sql = sql + " where " + strcondition;
      try
      {
        DboCollection dbcPdh = getThemeMapDAO().selectDBOs(sql, new GenericDO[] { new PdhSystem() });
        for (int i = 0; i < dbcPdh.size(); i++) {
          PdhSystem pdhsys = (PdhSystem)dbcPdh.getAttrField("PDH_SYSTEM", i);
          returnList.add(pdhsys);
        }
      } catch (Exception ex) {
        LogHome.getLog().error(ex);
      }
    } else if (syscls.equals("WDM")) {
      sql = sql + "WDM_SYSTEM";
      strcondition = getSqlCondition(actionContext, syslev, sysmed, sysnam, strcondition);
      if (!strcondition.equals(""))
        sql = sql + " where " + strcondition;
      try
      {
        DboCollection dbcwdm = getThemeMapDAO().selectDBOs(sql, new GenericDO[] { new WdmSystem() });
        for (int i = 0; i < dbcwdm.size(); i++) {
          WdmSystem wdmsys = (WdmSystem)dbcwdm.getAttrField("WDM_SYSTEM", i);
          returnList.add(wdmsys);
        }
      } catch (Exception ex) {
        LogHome.getLog().error(ex);
      }
    } else if (syscls.equals("微波")) {
      sql = sql + "MICROWAVE_SYSTEM";
      strcondition = getSqlCondition(actionContext, syslev, sysmed, sysnam, strcondition);
      if (!strcondition.equals(""))
        sql = sql + " where " + strcondition;
      try
      {
        DboCollection dbcwic = getThemeMapDAO().selectDBOs(sql, new GenericDO[] { new MicrowaveSystem() });
        for (int i = 0; i < dbcwic.size(); i++) {
          MicrowaveSystem micsys = (MicrowaveSystem)dbcwic.getAttrField("MICROWAVE_SYSTEM", i);
          returnList.add(micsys);
        }
      } catch (Exception ex) {
        LogHome.getLog().error(ex);
      }

    }

    return returnList;
  }

  private String getSqlCondition(BoActionContext actionContext, String syslev, String sysmed, String sysnam, String strcondition) {
    if (!syslev.equals("")) {
      strcondition = "SYSTEM_LEVEL = " + TransSystemEnum.TRANS_SYS_LEVEL.getValue(syslev);
    }
    if (!sysmed.equals("")) {
      if (!strcondition.equals("")) {
        strcondition = strcondition + " and ";
      }
      strcondition = strcondition + "TRANS_MEDIA = " + NetEnum.TRANS_MEDIA_CH.getValue(sysmed);
    }
    if (!sysnam.equals("")) {
      if (!strcondition.equals("")) {
        strcondition = strcondition + " and ";
      }
      strcondition = strcondition + "LABEL_CN like '%" + sysnam + "%'";
    }
    strcondition = getSpacesInSql(actionContext, strcondition);
    return strcondition;
  }

  public ThemeMap getThemeMap(BoActionContext actionContext, Long themeMapObjectId) throws UserException {
    try {
      return getThemeMapDAO().getThemeMapByObjectId(actionContext, themeMapObjectId);
    } catch (Exception ex) {
      LogHome.getLog().error("得到主题图失败,ThemeMapBO.getThemeMap()" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public String getSpacesInSql(BoActionContext actionContext, String sql)
    throws UserException
  {
    try
    {
      String userId = actionContext.getUserId();
      String sqlin;
      if (!userId.equals("SYS_USER-0")) {
        DataObjectList districts = null;
        try {
          districts = ((ISecurityBO)super.getBO("ISecurityBO")).getUserDistricts(actionContext, userId);
        } catch (Throwable ex) {
          LogHome.getLog().error("加载可管理区域对象出错", ex);
          throw new UserException(ex);
        }
        if (districts != null) {
          sqlin = "";
          for (int i = 0; i < districts.size(); i++) {
            sqlin = sqlin + "'" + ((GenericDO)districts.get(i)).getCuid() + "',";
          }

          if (sql.length() > 0)
            sql = sql + " and " + "RELATED_SPACE_CUID" + " in (" + sqlin + "'0')"; 
        }
      }
      return "RELATED_SPACE_CUID in (" + sqlin + "'0')";
    }
    catch (Throwable e)
    {
      LogHome.getLog().info("getSpacesInSql得到用户所属区域sql时出错" + e.getMessage());
      throw new UserException(e);
    }
  }

  public ThemeMap getThemeMapByUserAndLabelCn(BoActionContext actionContext, String userCuid) throws UserException {
    String sql = "CREATE_USER_CUID = '" + userCuid + "' AND " + "DEFAULT_THEME_MAP" + " = 1" + " AND " + "THEME_MAP_TYPE" + " = 1";
    try
    {
      DataObjectList dataObjectList = getThemeMapDAO().getObjectsBySql(sql, new ThemeMap(), 0);
      if ((dataObjectList != null) && (dataObjectList.size() > 0)) {
        return (ThemeMap)dataObjectList.get(0);
      }
      return null;
    }
    catch (Exception e) {
      LogHome.getLog().error("根据用户名和labelcn查询主题图失败：sql" + sql, e);
    }throw new UserException("查询主题图失败");
  }

  public DataObjectList getPtnDisplayThemeMaps(BoActionContext actionContext)
    throws UserException
  {
    String sql = "THEME_MAP_TYPE = 1 AND FLAG = 1";
    try
    {
      return getThemeMapDAO().getObjectsBySql(sql, new ThemeMap(), 0);
    }
    catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex);
    }
  }
}