package com.boco.transnms.server.bo.topo;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.MapToObject;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.ibo.topo.IMapToObjectBO;
import com.boco.transnms.server.dao.topo.MapToObjectDAO;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="CM")
public class MapToObjectBO extends AbstractBO
  implements IMapToObjectBO
{
  private MapToObjectDAO getMapToObjectDAO()
  {
    return (MapToObjectDAO)super.getDAO("MapToObjectDAO");
  }

  public MapToObject addMapToObject(BoActionContext actionContext, MapToObject mapToObject) throws UserException {
    try {
      String sql = "OBJECT_CUID = '" + mapToObject.getObjectCuid() + "' and MAP_CUID = '" + mapToObject.getMapCuid() + "' ";
      deleteMapToObjectsBySql(actionContext, sql);
      return getMapToObjectDAO().addMapToObject(actionContext, mapToObject);
    }
    catch (Throwable ex) {
      LogHome.getLog().info("addMapToObject增加地图与对象关系对象出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public MapToObject modifyMapToObject(BoActionContext actionContext, MapToObject mapToObject) throws UserException
  {
    try {
      return getMapToObjectDAO().modifyMapToObject(actionContext, mapToObject);
    }
    catch (Throwable ex) {
      LogHome.getLog().info("modifyMapToObject修改地图与对象关系对象出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public void deleteMapToObject(BoActionContext actionContext, MapToObject mapToObject) throws UserException {
    try {
      getMapToObjectDAO().deleteMapToObject(actionContext, mapToObject);
    } catch (Throwable ex) {
      LogHome.getLog().info("deleteMapToObject删除地图与对象关系对象出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public void deleteMapToObjectsBySql(BoActionContext actionContext, String sql) throws UserException {
    try {
      getMapToObjectDAO().deleteObjects(actionContext, "MAP_TO_OBJECT", sql);
    } catch (Throwable ex) {
      LogHome.getLog().info("deleteMapToObjectsBySql删除地图与对象关系对象出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public void deleteMapToObjectByKey(BoActionContext actionContext, MapToObject mapToObject) throws UserException {
    try {
      String sql = " MAP_CUID = '" + mapToObject.getMapCuid() + "' and OBJECT_CUID ='" + mapToObject.getObjectCuid() + "' ";
      deleteMapToObjectsBySql(actionContext, sql);
    } catch (Throwable ex) {
      LogHome.getLog().info("deleteMapToObjectByKey删除地图与对象关系对象出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public void deleteMapToObjectByPointCuid(BoActionContext actionContext, String pointCuid) throws UserException {
    try {
      String sql = " OBJECT_CUID ='" + pointCuid + "' ";
      deleteMapToObjectsBySql(actionContext, sql);
    } catch (Throwable ex) {
      LogHome.getLog().info("deleteMapToObjectByCuid删除所有地图上的关系对象出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public DataObjectList getAllMapToObjects(BoActionContext actionContext) throws UserException {
    try {
      return getMapToObjectDAO().getAllMapToObject();
    } catch (Throwable ex) {
      LogHome.getLog().info("getAllMapToObjects获取所有地图上的关系对象出错", ex);
      throw new UserException(ex);
    }
  }
}