package com.boco.transnms.server.bo.topo;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.DuctSystem;
import com.boco.transnms.common.dto.HangWall;
import com.boco.transnms.common.dto.MicrowaveSystem;
import com.boco.transnms.common.dto.PdhSystem;
import com.boco.transnms.common.dto.PolewaySystem;
import com.boco.transnms.common.dto.SdhSystem;
import com.boco.transnms.common.dto.Site;
import com.boco.transnms.common.dto.StonewaySystem;
import com.boco.transnms.common.dto.ThemeMap;
import com.boco.transnms.common.dto.ThemeMapToObject;
import com.boco.transnms.common.dto.TransElement;
import com.boco.transnms.common.dto.TransSubNetwork;
import com.boco.transnms.common.dto.UpLine;
import com.boco.transnms.common.dto.WdmSystem;
import com.boco.transnms.common.dto.WireSystem;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.ibo.topo.IThemeMapToObjectBO;
import com.boco.transnms.server.dao.area.SiteDAO;
import com.boco.transnms.server.dao.common.CommonDAO;
import com.boco.transnms.server.dao.topo.ThemeMapDAO;
import com.boco.transnms.server.dao.topo.ThemeMapToObjectDAO;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="CM")
public class ThemeMapToObjectBO extends AbstractBO
  implements IThemeMapToObjectBO
{
  public ThemeMapToObjectDAO getThemeMapToObjectDAO()
  {
    return (ThemeMapToObjectDAO)super.getDAO("ThemeMapToObjectDAO");
  }

  public ThemeMapDAO getThemeMapDAO() {
    return (ThemeMapDAO)super.getDAO("ThemeMapDAO");
  }

  public ThemeMapToObject addThemeMapToObject(BoActionContext actionContext, ThemeMapToObject themeMapToObject) throws UserException
  {
    try {
      return getThemeMapToObjectDAO().addThemeMapToObject(actionContext, themeMapToObject);
    } catch (Exception ex) {
      LogHome.getLog().error("BO添加'主体图对象对应关系'失败" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public DataObjectList addThemeMapToObjects(BoActionContext actionContext, DataObjectList tmtolist) throws UserException {
    try {
      return getThemeMapToObjectDAO().addThemeMapToObjects(actionContext, tmtolist);
    } catch (Exception ex) {
      LogHome.getLog().error("BO添加'主体图对象对应关系'失败" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public void deleteObjectByThemeMapCuid(BoActionContext actionContext, String themeMapCuid, String objectType) throws UserException
  {
    try
    {
      getThemeMapToObjectDAO().deleteObjectByThemeMapCuid(actionContext, themeMapCuid, objectType);
    } catch (Exception ex) {
      LogHome.getLog().error("BO删除'主题图对象对应关系'失败" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public void deleteObjectOnlyByThemeMapCuid(BoActionContext actionContext, String themeMapCuid)
    throws UserException
  {
    try
    {
      getThemeMapToObjectDAO().deleteObjectOnlyByThemeMapCuid(actionContext, themeMapCuid);
    } catch (Exception ex) {
      LogHome.getLog().error("BO删除'主题图对象对应关系'失败" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public void deleteThemeMapToObjects(BoActionContext actionContext, DataObjectList tmtolist) throws UserException {
    try {
      getThemeMapToObjectDAO().deleteThemeMapToObjects(actionContext, tmtolist);
    } catch (Exception ex) {
      LogHome.getLog().error("BO删除'主题图对象对应关系'失败" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public DataObjectList getThemeMapToObjectByObjectTypes(BoActionContext actionContext, String themeMapCuid, String[] objectTypes)
    throws UserException
  {
    DataObjectList list = new DataObjectList();
    try {
      for (String objectType : objectTypes) {
        list.addAll(getThemeMapToObjectDAO().getByThemeMapAndObjType(actionContext, themeMapCuid, objectType));
      }
      return list;
    } catch (Exception ex) {
      LogHome.getLog().error("BO读取'主体图对象对应关系'失败", ex);
      throw new UserException(ex);
    }
  }

  public DataObjectList getThemeMapToObjectByUser(BoActionContext actionContext, String themeMapCuid, String objectType) throws UserException
  {
    try
    {
      return getThemeMapToObjectDAO().getByThemeMapAndObjType(actionContext, themeMapCuid, objectType);
    } catch (Exception ex) {
      LogHome.getLog().error("BO读取'主体图对象对应关系'失败", ex);
      throw new UserException(ex);
    }
  }

  public DataObjectList getThemeMapObjectsByUser(BoActionContext actionContext, String themeMapCuid, String objectType)
    throws UserException
  {
    try
    {
      ThemeMapToObject oldDbo = new ThemeMapToObject();
      oldDbo.setThemeMapCuid(themeMapCuid);
      Long type = Long.valueOf(objectType);
      oldDbo.setObjectType(type.longValue());
      DataObjectList lists = getThemeMapDAO().getObjByAttrs(new BoQueryContext(), oldDbo);

      for (int i = lists.size() - 1; i >= 0; i--) {
        ThemeMapToObject tmto = (ThemeMapToObject)lists.get(i);
        if (objectType.equals("2000")) {
          DuctSystem duct = new DuctSystem();
          duct.setCuid(tmto.getObjectCuid());

          duct = (DuctSystem)getCommonDAO().getObjByCuid(duct);
          tmto.setAttrValue("OBJECT_CUID", duct);
        } else if (objectType.equals("2001")) {
          PolewaySystem pole = new PolewaySystem();
          pole.setCuid(tmto.getObjectCuid());

          pole = (PolewaySystem)getCommonDAO().getObjByCuid(pole);
          tmto.setAttrValue("OBJECT_CUID", pole);
        } else if (objectType.equals("2002")) {
          StonewaySystem stone = new StonewaySystem();
          stone.setCuid(tmto.getObjectCuid());

          stone = (StonewaySystem)getCommonDAO().getObjByCuid(stone);
          tmto.setAttrValue("OBJECT_CUID", stone);
        } else if (objectType.equals("2003")) {
          WireSystem wire = new WireSystem();
          wire.setCuid(tmto.getObjectCuid());

          wire = (WireSystem)getCommonDAO().getObjByCuid(wire);
          tmto.setAttrValue("OBJECT_CUID", wire);
        } else if (objectType.equals("2005")) {
          UpLine upl = new UpLine();
          upl.setCuid(tmto.getObjectCuid());

          upl = (UpLine)getCommonDAO().getObjByCuid(upl);
          tmto.setAttrValue("OBJECT_CUID", upl);
        } else if (objectType.equals("2006")) {
          HangWall hangw = new HangWall();
          hangw.setCuid(tmto.getObjectCuid());

          hangw = (HangWall)getCommonDAO().getObjByCuid(hangw);
          tmto.setAttrValue("OBJECT_CUID", hangw);
        } else if (objectType.equals("2008")) {
          MicrowaveSystem micsys = new MicrowaveSystem();
          micsys.setCuid(tmto.getObjectCuid());

          micsys = (MicrowaveSystem)getCommonDAO().getObjByCuid(micsys);
          tmto.setAttrValue("OBJECT_CUID", micsys);
        } else if (objectType.equals("7000")) {
          TransSubNetwork tsnw = new TransSubNetwork();
          tsnw.setCuid(tmto.getObjectCuid());

          tsnw = (TransSubNetwork)getCommonDAO().getObjByCuid(tsnw);
          tmto.setAttrValue("OBJECT_CUID", tsnw);
        } else if (objectType.equals("2007")) {
          if (tmto.getObjectCuid().indexOf("SDH_SYSTEM") > -1) {
            SdhSystem sdhsys = new SdhSystem();
            sdhsys.setCuid(tmto.getObjectCuid());

            sdhsys = (SdhSystem)getCommonDAO().getObjByCuid(sdhsys);
            tmto.setAttrValue("OBJECT_CUID", sdhsys);
          } else if (tmto.getObjectCuid().indexOf("WDM_SYSTEM") > -1) {
            WdmSystem wdmsys = new WdmSystem();
            wdmsys.setCuid(tmto.getObjectCuid());

            wdmsys = (WdmSystem)getCommonDAO().getObjByCuid(wdmsys);
            tmto.setAttrValue("OBJECT_CUID", wdmsys);
          } else if (tmto.getObjectCuid().indexOf("PDH_SYSTEM") > -1) {
            PdhSystem pdhsys = new PdhSystem();
            pdhsys.setCuid(tmto.getObjectCuid());

            pdhsys = (PdhSystem)getCommonDAO().getObjByCuid(pdhsys);
            tmto.setAttrValue("OBJECT_CUID", pdhsys);
          } else if (tmto.getObjectCuid().indexOf("MICROWAVE_SYSTEM") > -1) {
            MicrowaveSystem mwsys = new MicrowaveSystem();
            mwsys.setCuid(tmto.getObjectCuid());

            mwsys = (MicrowaveSystem)getCommonDAO().getObjByCuid(mwsys);
            tmto.setAttrValue("OBJECT_CUID", mwsys);
          }
        } else if (objectType.equals("1001")) {
          Site site = new Site();
          site.setCuid(tmto.getObjectCuid());
          site = (Site)getSiteDAO().getObjByCuid(site);
          tmto.setAttrValue("OBJECT_CUID", site);
        } else if (objectType.equals("4008")) {
          TransElement transElement = new TransElement();
          transElement.setCuid(tmto.getObjectCuid());
          transElement = (TransElement)getCommonDAO().getObjByCuid(transElement);
          tmto.setAttrValue("OBJECT_CUID", transElement);
        }

        if (tmto.getAttrValue("OBJECT_CUID") == null) {
          lists.remove(i);
        }
      }
      return lists;
    } catch (Exception ex) {
      LogHome.getLog().error("BO读取'主体图对象对应关系'及其对象 失败", ex);
      throw new UserException(ex);
    }
  }

  public ThemeMapToObject getThemeMapToObjectByCuid(BoActionContext actionContext, String cuid) throws UserException {
    try {
      return getThemeMapToObjectDAO().getThemeMapToObjectByCuid(actionContext, cuid);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex);
    }
  }

  private CommonDAO getCommonDAO() {
    return (CommonDAO)super.getDAO("CommonDAO");
  }

  private SiteDAO getSiteDAO()
  {
    return (SiteDAO)super.getDAO("SiteDAO");
  }

  public DataObjectList getObjectsByThemeMapCuid(BoActionContext actionContext, String themeMapCuid) throws UserException {
    try {
      return getThemeMapToObjectDAO().getObjectsByThemeMapCuid(actionContext, themeMapCuid);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex);
    }
  }

  public DataObjectList getDeletedThemeMapOjbect(BoActionContext actionContext, ThemeMap themeMap) throws UserException {
    DataObjectList deletedThemeMapObject = new DataObjectList();

    DataObjectList themeMapToObjects = ((IThemeMapToObjectBO)super.getBO("IThemeMapToObjectBO")).getObjectsByThemeMapCuid(actionContext, themeMap.getCuid());

    for (int i = 0; i < themeMapToObjects.size(); i++) {
      ThemeMapToObject themeMapToObject = (ThemeMapToObject)themeMapToObjects.get(i);
      DataObjectList dbos = getThemeMapToObjectDAO().getSimpleObjsByCuid(new String[] { themeMapToObject.getObjectCuid() });
      if ((dbos == null) || (dbos.size() <= 0)) {
        deletedThemeMapObject.add(themeMapToObject);
      }
    }
    return deletedThemeMapObject;
  }
}