package com.boco.transnms.server.bo.topo;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.misc.AllPics;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.ibo.topo.IAllPicsBO;
import com.boco.transnms.server.dao.topo.AllPicsDAO;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="CM")
public class AllPicsBO extends AbstractBO
  implements IAllPicsBO
{
  public AllPicsDAO getAllPicsDAO()
  {
    return (AllPicsDAO)super.getDAO("AllPicsDAO");
  }

  public void addAllPics(BoActionContext actionContext, AllPics allPics) throws UserException
  {
    try {
      getAllPicsDAO().addAllPics(actionContext, allPics);
    } catch (Exception ex) {
      LogHome.getLog().error("BO新增 图形对象对应关系AllPics 出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public void addDistinctAllPics(BoActionContext actionContext, AllPics allPics) throws UserException
  {
    try
    {
      getAllPicsDAO().deleteAllPics(actionContext, allPics);

      getAllPicsDAO().addAllPics(actionContext, allPics);
    }
    catch (Exception ex) {
      LogHome.getLog().error("BO新增 图形对象对应关系AllPics 出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public void modifyAllPicsPicField(BoActionContext actionContext, AllPics allPics) throws UserException
  {
    try {
      getAllPicsDAO().modifyAllPicsPicField(actionContext, allPics);
    } catch (Exception ex) {
      LogHome.getLog().error("BO修改 图形对象对应关系AllPics 出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public void deleteAllPics(BoActionContext actionContext, AllPics allPics) throws UserException
  {
    try {
      getAllPicsDAO().deleteAllPics(actionContext, allPics);
    } catch (Exception ex) {
      LogHome.getLog().error("BO删除 图形对象对应关系AllPics 出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public AllPics getAllPics(BoActionContext actionContext, AllPics allPics) throws UserException
  {
    try {
      return getAllPicsDAO().getAllPics(actionContext, allPics);
    } catch (Exception ex) {
      LogHome.getLog().error("BO读取 图形对象对应关系AllPics 出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public DataObjectList getAllPictures(BoActionContext actionContext, AllPics allPics) throws UserException {
    try {
      return getAllPicsDAO().getAllPictures(actionContext, allPics);
    } catch (Exception ex) {
      LogHome.getLog().error("BO读取 图形对象对应关系AllPics 出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public DataObjectList getAllPicturesBySql(BoActionContext actionContext, String sql) throws UserException {
    try {
      return getAllPicsDAO().getAllPicturesBySql(actionContext, sql);
    } catch (Exception ex) {
      LogHome.getLog().error("BO读取 图形对象对应关系AllPics 出错" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public DataObjectList modifyAllPictures(BoActionContext actionContext, DataObjectList allpics) throws UserException {
    if (allpics != null) {
      for (GenericDO dto : allpics) {
        AllPics pic = (AllPics)dto;
        try {
          getAllPicsDAO().modifyAllPicsPicField(actionContext, pic);
        } catch (Exception ex) {
          LogHome.getLog().error("BO修改 图形对象对应关系AllPics 出错" + ex.getMessage());
          throw new UserException(ex);
        }
      }
    }
    return allpics;
  }

  public DataObjectList getAllSimplePics(BoActionContext actionContext, String sql) throws UserException {
    try {
      return getAllPicsDAO().getAllSimplePics(actionContext, sql);
    } catch (Exception e) {
      throw new UserException(e.getMessage());
    }
  }
}