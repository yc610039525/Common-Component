package com.boco.transnms.server.bo.traph;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.UserObjectCfg;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.ibo.traph.IDefaultSiteSettingBO;
import com.boco.transnms.server.dao.traph.DefaultSiteSettingDAO;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="CM")
public class DefaultSiteSettingBO extends AbstractBO
  implements IDefaultSiteSettingBO
{
  public DefaultSiteSettingBO()
  {
    super("IDefaultSiteSettingBO");
  }

  private DefaultSiteSettingDAO getDefaultSiteSettingDAO() {
    return (DefaultSiteSettingDAO)super.getDAO("DefaultSiteSettingDAO");
  }

  public DboCollection getDefaultSiteSetting(BoQueryContext actionContext, String sysCuid) throws UserException {
    try {
      return getDefaultSiteSettingDAO().getDefaultSiteSetting(actionContext, sysCuid);
    }
    catch (Exception ex) {
      LogHome.getLog().error("查询用户默认站点失败", ex);
      throw new UserException(ex);
    }
  }

  public DataObjectList getDefaultSiteSettingnew(BoQueryContext actionContext, String sysCuid) throws UserException {
    try { return getDefaultSiteSettingDAO().getDefaultSiteSettingnew(actionContext, sysCuid);
    } catch (Exception ex) {
      LogHome.getLog().error("查询用户默认站点失败", ex);
      throw new UserException(ex);
    }
  }

  public DataObjectList getDefaultAccesspointSettingnew(BoQueryContext actionContext, String sysCuid) throws UserException {
    try { return getDefaultSiteSettingDAO().getDefaultAccesspointSettingnew(actionContext, sysCuid);
    } catch (Exception ex) {
      LogHome.getLog().error("查询用户默认站点失败", ex);
      throw new UserException(ex);
    }
  }

  public DboCollection getDefaultRoomSetting(BoQueryContext actionContext, String sysCuid) throws UserException {
    try { return getDefaultSiteSettingDAO().getDefaultRoomSetting(actionContext, sysCuid);
    } catch (Exception ex) {
      LogHome.getLog().error("查询用户默认机房失败", ex);
      throw new UserException(ex);
    }
  }

  public DataObjectList getDefaultRoomSettingnew(BoQueryContext actionContext, String sysCuid) throws UserException {
    try { return getDefaultSiteSettingDAO().getDefaultRoomSettingnew(actionContext, sysCuid);
    } catch (Exception ex) {
      LogHome.getLog().error("查询用户默认机房失败", ex);
      throw new UserException(ex);
    }
  }

  public DboCollection getDefaultSiteSettingForTraphEdit(BoQueryContext actionContext, String sysCuid)
    throws UserException
  {
    return getDefaultSiteSetting(actionContext, sysCuid);
  }

  public DataObjectList getDefaultSiteSettingForTraphEditnew(BoQueryContext actionContext, String sysCuid) throws UserException {
    return getDefaultSiteSettingnew(actionContext, sysCuid);
  }
  public DataObjectList getDefaultAccesspointSettingForTraphEditnew(BoQueryContext actionContext, String sysCuid) throws UserException {
    return getDefaultSiteSettingnew(actionContext, sysCuid);
  }

  public DboCollection getDefaultRoomSettingForTraphEdit(BoQueryContext actionContext, String sysCuid)
    throws UserException
  {
    return getDefaultRoomSetting(actionContext, sysCuid);
  }
  public DataObjectList getDefaultRoomSettingForTraphEditnew(BoQueryContext actionContext, String sysCuid) throws UserException {
    return getDefaultRoomSettingnew(actionContext, sysCuid);
  }

  public UserObjectCfg addDefaultSiteSetting(BoActionContext actionContext, UserObjectCfg dbo) throws UserException {
    try {
      return getDefaultSiteSettingDAO().addDefaultSiteSetting(actionContext, dbo);
    } catch (Exception ex) {
      LogHome.getLog().error("增加用户默认站点失败", ex);
      throw new UserException(ex);
    }
  }

  public UserObjectCfg addDefaultRoomSetting(BoActionContext actionContext, UserObjectCfg dbo) throws UserException {
    try {
      return getDefaultSiteSettingDAO().addDefaultRoomSetting(actionContext, dbo);
    } catch (Exception ex) {
      LogHome.getLog().error("增加用户默认机房失败", ex);
      throw new UserException(ex);
    }
  }

  public void deleteDefaultSiteSetting(BoActionContext actionContext, String objectId) throws UserException
  {
    try {
      getDefaultSiteSettingDAO().deleteDefaultSiteSetting(actionContext, objectId);
    } catch (Exception ex) {
      LogHome.getLog().error("删除用户默认站点失败", ex);
      throw new UserException(ex);
    }
  }

  public void deleteDefaultRoomSetting(BoActionContext actionContext, String objectId) throws UserException {
    try {
      getDefaultSiteSettingDAO().deleteDefaultRoomSetting(actionContext, objectId);
    } catch (Exception ex) {
      LogHome.getLog().error("删除用户默认机房失败", ex);
      throw new UserException(ex);
    }
  }
}