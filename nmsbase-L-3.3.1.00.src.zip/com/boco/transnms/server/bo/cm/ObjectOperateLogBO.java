package com.boco.transnms.server.bo.cm;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.client.model.base.TnmsClientCfg;
import com.boco.transnms.common.bussiness.consts.ObjEnum;
import com.boco.transnms.common.bussiness.consts.ObjEnum.ObjType;
import com.boco.transnms.common.bussiness.consts.ObjEnum.OperateType;
import com.boco.transnms.common.dto.Ctp;
import com.boco.transnms.common.dto.Ddf;
import com.boco.transnms.common.dto.Ddfport;
import com.boco.transnms.common.dto.Fiber;
import com.boco.transnms.common.dto.JumpFiber;
import com.boco.transnms.common.dto.JumpPair;
import com.boco.transnms.common.dto.Miscrack;
import com.boco.transnms.common.dto.ObjectOperateLog;
import com.boco.transnms.common.dto.Odf;
import com.boco.transnms.common.dto.Odfport;
import com.boco.transnms.common.dto.Ptp;
import com.boco.transnms.common.dto.Room;
import com.boco.transnms.common.dto.Site;
import com.boco.transnms.common.dto.SysUser;
import com.boco.transnms.common.dto.TransPath;
import com.boco.transnms.common.dto.TransSubNetwork;
import com.boco.transnms.common.dto.Traph;
import com.boco.transnms.common.dto.WireSeg;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.BoHomeFactory;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.ibo.cm.IObjectOperateLogBO;
import com.boco.transnms.server.bo.ibo.cm.ISiteBO;
import com.boco.transnms.server.bo.ibo.misc.ISecurityBO;
import com.boco.transnms.server.common.cfg.TnmsRuntime;
import com.boco.transnms.server.dao.base.DaoHelper;
import com.boco.transnms.server.dao.base.GenericDAO;
import com.boco.transnms.server.dao.cm.ObjectOperateLogDAO;
import com.boco.transnms.server.dao.common.CommonDAO;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="CM")
public class ObjectOperateLogBO extends AbstractBO
  implements IObjectOperateLogBO
{
  public ObjectOperateLogDAO getObjectOperateLogDAO()
  {
    return (ObjectOperateLogDAO)super.getDAO("ObjectOperateLogDAO");
  }

  private GenericDAO getGenericDAO() {
    return (GenericDAO)super.getDAO("GenericDAO");
  }

  public void addObjOperateLog(BoActionContext actionContext, long operateType, long objType, GenericDO oldObj, GenericDO newObj)
    throws UserException, Exception
  {
    try
    {
      if ((TnmsRuntime.getInstance().equals("WRITE_OBJECT_OPERATE_LOG", Boolean.TRUE.toString())) || (TnmsClientCfg.getInstance().getLoginPattern().equals("Support4ALogin"))) {
        ObjectOperateLog objectoperatelog = new ObjectOperateLog();
        Date date = new Date();
        Timestamp time = new Timestamp(date.getTime());
        String userip = actionContext.getHostIP();
        String userName = actionContext.getUserName();
        String usercuid = actionContext.getUserId();
        if ((userName == null) || (userName.trim().length() == 0)) {
          if ((usercuid != null) && (usercuid.trim().length() > 0)) {
            DboCollection dbos = getObjectOperateLogDAO().getSysUserNameByCuid(usercuid);
            if (dbos.size() > 0) {
              SysUser user = (SysUser)dbos.getQueryDbo(0, "SYS_USER");
              if ((user != null) && (user.getTrueName() != null) && (user.getTrueName().trim().length() > 0))
                userName = user.getTrueName();
              else
                userName = "未知用户";
            }
            else {
              userName = "未知用户";
            }
          } else {
            userName = "未知用户";
          }
        }
        if ((userip != null) && (userip.trim().length() > 0))
          objectoperatelog.setClientIp(userip);
        else {
          objectoperatelog.setClientIp("未知IP");
        }
        objectoperatelog.setOperateUser(userName);
        objectoperatelog.setOperateTime(time);
        Map param = new HashMap();
        if (objType == 1L) {
          objectoperatelog.setObjName(newObj.getAttrString("LABEL_CN"));
          objectoperatelog.setObjType(1L);
          if (operateType == 1L) {
            objectoperatelog.setOperateType(1L);
            objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "添加区域" + newObj.getAttrString("LABEL_CN"));
            param.put("OpType", "Add");
            param.put("AppModule", "空间资源管理");
            param.put("OpText", "增加区域");
          } else if (operateType == 3L) {
            objectoperatelog.setOperateType(3L);
            objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "删除区域" + newObj.getAttrString("LABEL_CN"));
            param.put("OpType", "Del");
            param.put("AppModule", "空间资源管理");
            param.put("OpText", "删除区域");
          } else if (operateType == 2L) {
            objectoperatelog.setOperateType(2L);
            if (!oldObj.getAttrString("LABEL_CN").equals(newObj.getAttrString("LABEL_CN"))) {
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改区域 " + oldObj.getAttrString("LABEL_CN") + ",修改后名字为 " + newObj.getAttrString("LABEL_CN"));
            }
            else {
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改区域" + newObj.getAttrString("LABEL_CN"));
            }
            param.put("OpType", "Update");
            param.put("AppModule", "空间资源管理");
            param.put("OpText", "修改区域");
          }
        } else if (objType == 2L) {
          objectoperatelog.setObjName(newObj.getAttrString("LABEL_CN"));
          objectoperatelog.setObjType(2L);
          if (operateType == 1L) {
            objectoperatelog.setOperateType(1L);
            objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "添加站点" + newObj.getAttrString("LABEL_CN"));
            param.put("OpType", "Add");
            param.put("AppModule", "空间资源管理");
            param.put("OpText", "增加站点");
          } else if (operateType == 3L) {
            objectoperatelog.setOperateType(3L);
            objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "删除站点" + newObj.getAttrString("LABEL_CN"));
            param.put("OpType", "Del");
            param.put("AppModule", "空间资源管理");
            param.put("OpText", "删除站点");
          } else if (operateType == 2L)
          {
            String modifyInfo = "";
            if (!oldObj.getAttrString("LABEL_CN").equals(newObj.getAttrString("LABEL_CN"))) {
              modifyInfo = userName + "于" + time.toString() + "通过" + userip + "修改站点 " + oldObj.getAttrString("LABEL_CN") + ",修改后名字为 " + newObj.getAttrString("LABEL_CN");
            }
            else {
              modifyInfo = userName + "于" + time.toString() + "通过" + userip + "修改站点" + newObj.getAttrString("LABEL_CN");
            }
            if (oldObj.getAttrString("ALIAS") == null) {
              oldObj.setAttrValue("ALIAS", "");
            }
            if (((Site)oldObj).getLocation() == null) {
              oldObj.setAttrValue("LOCATION", "");
            }
            if (!((Site)oldObj).getAlias().equals(((Site)newObj).getAlias())) {
              modifyInfo = modifyInfo + "; 修改站点别名：" + oldObj.getAttrString("ALIAS") + ",修改后站点别名为 " + newObj.getAttrString("ALIAS");
            }
            if (!((Site)oldObj).getLocation().equals(((Site)newObj).getLocation())) {
              modifyInfo = modifyInfo + "; 修改站点位置：" + oldObj.getAttrString("ALIAS") + ",修改后站点位置为 " + newObj.getAttrString("ALIAS");
            }
            objectoperatelog.setLogInfo(modifyInfo);
            param.put("OpType", "Update");
            param.put("AppModule", "空间资源管理");
            param.put("OpText", "修改站点");
          }
        } else if (objType == 3L) {
          objectoperatelog.setObjName(newObj.getAttrString("LABEL_CN"));
          objectoperatelog.setObjType(3L);
          if (operateType == 1L) {
            objectoperatelog.setOperateType(1L);
            objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "添加机房" + newObj.getAttrString("LABEL_CN"));
            param.put("OpType", "Add");
            param.put("AppModule", "空间资源管理");
            param.put("OpText", "增加机房");
          } else if (operateType == 3L) {
            objectoperatelog.setOperateType(3L);
            objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "删除机房" + newObj.getAttrString("LABEL_CN"));
            param.put("OpType", "Del");
            param.put("AppModule", "空间资源管理");
            param.put("OpText", "删除机房");
          } else if (operateType == 2L) {
            objectoperatelog.setOperateType(2L);
            if (!((Room)oldObj).getLabelCn().equals(((Room)newObj).getLabelCn())) {
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改机房 " + oldObj.getAttrString("LABEL_CN") + ",修改后名字为 " + newObj.getAttrString("LABEL_CN"));
            }
            else {
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改删除机房" + newObj.getAttrString("LABEL_CN"));
            }
            param.put("OpType", "Update");
            param.put("AppModule", "空间资源管理");
            param.put("OpText", "修改机房");
          }
        } else if (objType == 4L) {
          objectoperatelog.setObjType(objType);
          String newObjCuid = newObj.getAttrString("CUID");
          String oldObjCuid = oldObj.getAttrString("CUID");
          if ((newObjCuid.indexOf("TRANS_ELEMENT") > -1) && (oldObjCuid.indexOf("TRANS_ELEMENT") > -1)) {
            objectoperatelog.setObjName((String)newObj.getAttrValue("LABEL_CN"));
            if (operateType == 1L) {
              objectoperatelog.setOperateType(1L);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "添加网元" + newObj.getAttrString("LABEL_CN"));
              param.put("OpType", "Add");
              param.put("AppModule", "传输设备管理");
              param.put("OpText", "增加网元");
            } else if (operateType == 3L) {
              objectoperatelog.setOperateType(3L);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "删除网元" + newObj.getAttrString("LABEL_CN"));
              param.put("OpType", "Del");
              param.put("AppModule", "传输设备管理");
              param.put("OpText", "删除网元");
            } else if (operateType == 2L) {
              objectoperatelog.setOperateType(2L);
              if (!oldObj.getAttrValue("LABEL_CN").equals(newObj.getAttrValue("LABEL_CN"))) {
                objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改网元 " + oldObj.getAttrString("LABEL_CN") + ",修改后名字为 " + newObj.getAttrString("LABEL_CN"));
              }
              else {
                objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改网元" + newObj.getAttrString("LABEL_CN"));
              }
              param.put("OpType", "Update");
              param.put("AppModule", "传输设备管理");
              param.put("OpText", "修改网元");
            }
          } else {
            String newObjName = newObj.getAttrString("LABEL_CN");
            String oldObjName = oldObj.getAttrString("LABEL_CN");
            objectoperatelog.setObjName(oldObjName + "-" + newObjName);
            if (newObjCuid.indexOf("TRANS_ELEMENT") > -1)
              newObjName = "网元" + newObjName;
            else if (newObjCuid.indexOf("ROOM") > -1)
              newObjName = "机房" + newObjName;
            else if (newObjCuid.indexOf("TRANS_SUB_NETWORK") > -1) {
              newObjName = "子网" + newObjName;
            }
            if (oldObjCuid.indexOf("TRANS_ELEMENT") > -1)
              oldObjName = "网元" + oldObjName;
            else if (oldObjCuid.indexOf("ROOM") > -1)
              oldObjName = "机房" + oldObjName;
            else if (oldObjCuid.indexOf("TRANS_SUB_NETWORK") > -1) {
              oldObjName = "子网" + oldObjName;
            }
            objectoperatelog.setOperateType(operateType);
            objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + ObjEnum.OPERATE_TYPE.getName(Long.valueOf(operateType)) + oldObjName + "和" + newObjName + "的关联关系");
          }
        } else if (objType == 12L) {
          objectoperatelog.setObjType(objType);
          String newObjCuid = newObj.getAttrString("CUID");
          String oldObjCuid = oldObj.getAttrString("CUID");
          if ((newObjCuid.indexOf("TRANS_SUB_NETWORK") > -1) && (oldObjCuid.indexOf("TRANS_SUB_NETWORK") > -1)) {
            objectoperatelog.setObjName(((TransSubNetwork)newObj).getLabelCn());
            if (operateType == 1L) {
              objectoperatelog.setOperateType(1L);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "添加子网" + newObj.getAttrString("LABEL_CN"));
              param.put("OpType", "Add");
              param.put("AppModule", "网络配置管理");
              param.put("OpText", "增加子网");
            } else if (operateType == 3L) {
              objectoperatelog.setOperateType(3L);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "删除子网" + newObj.getAttrString("LABEL_CN"));
              param.put("OpType", "Del");
              param.put("AppModule", "网络配置管理");
              param.put("OpText", "删除子网");
            } else if (operateType == 2L) {
              objectoperatelog.setOperateType(2L);
              if (!((TransSubNetwork)oldObj).getLabelCn().equals(((TransSubNetwork)newObj).getLabelCn())) {
                objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改子网 " + oldObj.getAttrString("LABEL_CN") + ",修改后名字为 " + newObj.getAttrString("LABEL_CN"));
              }
              else {
                objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改子网" + newObj.getAttrString("LABEL_CN"));
              }
              param.put("OpType", "Update");
              param.put("AppModule", "网络配置管理");
              param.put("OpText", "修改子网");
            }
          } else {
            String newObjName = newObj.getAttrString("LABEL_CN");
            String oldObjName = oldObj.getAttrString("LABEL_CN");
            objectoperatelog.setObjName(oldObjName + "-" + newObjName);
            if (newObjCuid.indexOf("TRANS_ELEMENT") > -1)
              newObjName = "网元" + newObjName;
            else if (newObjCuid.indexOf("ROOM") > -1)
              newObjName = "机房" + newObjName;
            else if (newObjCuid.indexOf("TRANS_SUB_NETWORK") > -1) {
              newObjName = "子网" + newObjName;
            }
            if (oldObjCuid.indexOf("TRANS_ELEMENT") > -1)
              oldObjName = "网元" + oldObjName;
            else if (oldObjCuid.indexOf("ROOM") > -1)
              oldObjName = "机房" + oldObjName;
            else if (oldObjCuid.indexOf("TRANS_SUB_NETWORK") > -1) {
              oldObjName = "子网" + oldObjName;
            }
            objectoperatelog.setOperateType(operateType);
            if ((oldObjCuid.indexOf("TRANS_ELEMENT") > -1) && (newObjCuid.indexOf("TRANS_SUB_NETWORK") > -1) && (operateType == 2L))
            {
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + ObjEnum.OPERATE_TYPE.getName(Long.valueOf(3L)) + oldObjName + "和" + newObjName + "的关联关系");
            }
            else {
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + ObjEnum.OPERATE_TYPE.getName(Long.valueOf(operateType)) + oldObjName + "和" + newObjName + "的关联关系");
            }
          }
        }
        else if (objType == 13L) {
          objectoperatelog.setObjType(objType);
          Fiber newFiber = (Fiber)newObj;
          Fiber oldFiber = (Fiber)oldObj;
          String newOrigPointCuid = DaoHelper.getRelatedCuid(newFiber.getOrigPointCuid());
          String newDestPointCuid = DaoHelper.getRelatedCuid(oldFiber.getDestPointCuid());
          String oldOrigPointCuid = DaoHelper.getRelatedCuid(oldFiber.getOrigPointCuid());
          String oldDestPointCuid = DaoHelper.getRelatedCuid(oldFiber.getDestPointCuid());
          WireSeg wireSeg = (WireSeg)getGenericDAO().getObjByCuid(newFiber.getRelatedSegCuid());
          if (operateType == 2L) {
            objectoperatelog.setObjName(wireSeg.getLabelCn() + "-" + newFiber.getLabelCn());
            if (((oldOrigPointCuid == null) || (oldOrigPointCuid.length() == 0)) && (newOrigPointCuid != null) && (newOrigPointCuid.length() > 0) && (((oldDestPointCuid == null) && (newDestPointCuid == null)) || (newDestPointCuid.equals(oldDestPointCuid))))
            {
              GenericDO dbo = getGenericDAO().getObjByCuid(newOrigPointCuid);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "增加纤芯上架,光缆段: " + wireSeg.getLabelCn() + " 下的纤芯 " + newFiber.getLabelCn() + " A端关联 " + dbo.getAttrString("LABEL_CN"));
            }
            else if (((oldDestPointCuid == null) || (oldDestPointCuid.length() == 0)) && (newDestPointCuid != null) && (newDestPointCuid.length() > 0) && (((oldOrigPointCuid == null) && (newOrigPointCuid == null)) || (newOrigPointCuid.equals(oldOrigPointCuid))))
            {
              GenericDO dbo = getGenericDAO().getObjByCuid(newDestPointCuid);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "增加纤芯上架,光缆段: " + wireSeg.getLabelCn() + " 下的纤芯 " + newFiber.getLabelCn() + " Z端关联 " + dbo.getAttrString("LABEL_CN"));
            }
            else if (((oldOrigPointCuid == null) || (oldOrigPointCuid.length() == 0)) && ((oldDestPointCuid == null) || (oldDestPointCuid.length() == 0)) && (newOrigPointCuid != null) && (newOrigPointCuid.length() > 0) && (newDestPointCuid != null) && (newDestPointCuid.length() > 0))
            {
              GenericDO origGdo = getGenericDAO().getObjByCuid(newOrigPointCuid);
              GenericDO destGdo = getGenericDAO().getObjByCuid(newDestPointCuid);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "增加纤芯上架,光缆段: " + wireSeg.getLabelCn() + " 下的纤芯 " + newFiber.getLabelCn() + " A端关联 " + origGdo.getAttrString("LABEL_CN") + " Z端关联 " + destGdo.getAttrString("LABEL_CN"));
            }
            else if ((oldOrigPointCuid != null) && (newOrigPointCuid != null) && (oldDestPointCuid != null) && (newDestPointCuid != null)) {
              if ((!oldOrigPointCuid.equals(newOrigPointCuid)) && (oldDestPointCuid.equals(newDestPointCuid))) {
                GenericDO oldOrigGdo = getGenericDAO().getObjByCuid(oldOrigPointCuid);
                GenericDO newOrigGdo = getGenericDAO().getObjByCuid(newOrigPointCuid);
                objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改纤芯上架,光缆段: " + wireSeg.getLabelCn() + " 下的纤芯 " + newFiber.getLabelCn() + " A端关联由 " + oldOrigGdo.getAttrString("LABEL_CN") + " 修改到 " + newOrigGdo.getAttrString("LABEL_CN"));
              }
              else if ((!oldDestPointCuid.equals(newDestPointCuid)) && (oldOrigPointCuid.equals(newOrigPointCuid))) {
                GenericDO oldDestGdo = getGenericDAO().getObjByCuid(oldDestPointCuid);
                GenericDO newDestGdo = getGenericDAO().getObjByCuid(newDestPointCuid);
                objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改纤芯上架,光缆段: " + wireSeg.getLabelCn() + " 下的纤芯 " + newFiber.getLabelCn() + " Z端关联由 " + oldDestGdo.getAttrString("LABEL_CN") + " 修改到 " + newDestGdo.getAttrString("LABEL_CN"));
              }
              else if ((!oldOrigPointCuid.equals(newOrigPointCuid)) && (!oldDestPointCuid.equals(newDestPointCuid))) {
                GenericDO oldOrigGdo = getGenericDAO().getObjByCuid(oldOrigPointCuid);
                GenericDO newOrigGdo = getGenericDAO().getObjByCuid(newOrigPointCuid);
                GenericDO oldDestGdo = getGenericDAO().getObjByCuid(oldDestPointCuid);
                GenericDO newDestGdo = getGenericDAO().getObjByCuid(newDestPointCuid);
                objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改纤芯上架,光缆段: " + wireSeg.getLabelCn() + " 下的纤芯 " + newFiber.getLabelCn() + " A端关联由 " + oldOrigGdo.getAttrString("LABEL_CN") + " 修改到 " + newOrigGdo.getAttrString("LABEL_CN") + ", Z端关联由 " + oldDestGdo.getAttrString("LABEL_CN") + " 修改到 " + newDestGdo.getAttrString("LABEL_CN"));
              }

            }
            else if ((oldOrigPointCuid != null) && (oldOrigPointCuid.length() > 0) && (oldDestPointCuid != null) && (oldDestPointCuid.length() > 0) && ((newOrigPointCuid == null) || (newOrigPointCuid.length() == 0)) && ((newDestPointCuid == null) || (newDestPointCuid.length() == 0)))
            {
              GenericDO origGdo = getGenericDAO().getObjByCuid(oldOrigPointCuid);
              GenericDO destGdo = getGenericDAO().getObjByCuid(oldDestPointCuid);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + " 光缆段: " + wireSeg.getLabelCn() + " 下的纤芯 " + newFiber.getLabelCn() + " 断开A端与 " + origGdo.getAttrString("LABEL_CN") + " 的关联, 断开Z端与 " + destGdo.getAttrString("LABEL_CN") + " 的关联");
            }
            else if ((oldDestPointCuid != null) && (oldDestPointCuid.length() > 0) && ((newDestPointCuid == null) || (newDestPointCuid.length() == 0)) && (((oldOrigPointCuid == null) && (newOrigPointCuid == null)) || (newOrigPointCuid.equals(oldOrigPointCuid))))
            {
              GenericDO dbo = getGenericDAO().getObjByCuid(oldDestPointCuid);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + " 光缆段: " + wireSeg.getLabelCn() + " 下的纤芯 " + newFiber.getLabelCn() + " 断开Z端与 " + dbo.getAttrString("LABEL_CN") + " 的关联");
            }
            else if ((oldOrigPointCuid != null) && (oldOrigPointCuid.length() > 0) && ((newOrigPointCuid == null) || (newOrigPointCuid.length() == 0)) && (((oldDestPointCuid == null) && (newDestPointCuid == null)) || (newDestPointCuid.equals(oldDestPointCuid))))
            {
              GenericDO dbo = getGenericDAO().getObjByCuid(oldOrigPointCuid);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + " 光缆段: " + wireSeg.getLabelCn() + " 下的纤芯 " + newFiber.getLabelCn() + " 断开A端与 " + dbo.getAttrString("LABEL_CN") + " 的关联");
            }
          }
        }
        else if ((objType == 10L) || (objType == 11L)) {
          objectoperatelog.setObjType(objType);
          String newObjCuid = newObj.getAttrString("CUID");
          String oldObjCuid = oldObj.getAttrString("CUID");
          String newObjName = newObj.getAttrString("LABEL_CN");
          String oldObjName = oldObj.getAttrString("LABEL_CN");
          objectoperatelog.setObjName(oldObjName + "-" + newObjName);
          if ((newObjCuid.indexOf("PTP") > -1) || (newObjCuid.indexOf("SWITCH_PORT") > -1))
            newObjName = "端口" + newObjName;
          else {
            newObjName = "端子" + newObjName;
          }
          if ((oldObjCuid.indexOf("PTP") > -1) || (oldObjCuid.indexOf("SWITCH_PORT") > -1))
            oldObjName = "端口" + oldObjName;
          else {
            oldObjName = "端子" + oldObjName;
          }
          objectoperatelog.setOperateType(operateType);
          objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + ObjEnum.OPERATE_TYPE.getName(Long.valueOf(operateType)) + oldObjName + "和" + newObjName + "的关联关系");
        } else if (objType == 5L) {
          TransPath newpath = (TransPath)newObj;
          String oldname = "";
          if (oldObj.getAttrString("CUID") != null) {
            TransPath oldpath = (TransPath)oldObj;
            oldname = getPathname(oldpath);
          }
          String newname = getPathname(newpath);
          objectoperatelog.setObjName(getPathname(newpath));
          objectoperatelog.setObjType(5L);
          if (operateType == 1L) {
            objectoperatelog.setOperateType(1L);
            objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "添加通道" + newObj.getAttrString("LABEL_CN"));
            param.put("OpType", "Add");
            param.put("AppModule", "通道资源管理");
            param.put("OpText", "增加通道");
          } else if (operateType == 3L) {
            objectoperatelog.setOperateType(3L);
            objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "删除通道" + newObj.getAttrString("LABEL_CN"));
            param.put("OpType", "Del");
            param.put("AppModule", "通道资源管理");
            param.put("OpText", "删除通道");
          } else if (operateType == 2L) {
            objectoperatelog.setOperateType(2L);
            if (!newname.equals(oldname)) {
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改通道 " + oldname + ",修改后名字为 " + newname);
            }
            else {
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改通道" + newname);
            }
            param.put("OpType", "Update");
            param.put("AppModule", "通道资源管理");
            param.put("OpText", "修改通道");
          }
        }
        else if (objType == 6L) {
          objectoperatelog.setObjName(((Traph)newObj).getLabelCn());
          objectoperatelog.setObjType(6L);
          if (operateType == 1L) {
            objectoperatelog.setOperateType(1L);
            objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "添加电路" + newObj.getAttrString("LABEL_CN"));
            LogHome.getLog().info("==============logInfo=" + userName + "于" + time.toString() + "通过" + userip + "添加电路" + newObj.getAttrString("LABEL_CN"));
            param.put("OpType", "Add");
            param.put("AppModule", "电路资源管理");
            param.put("OpText", "增加电路");
          } else if (operateType == 3L) {
            objectoperatelog.setOperateType(3L);
            objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "删除电路" + newObj.getAttrString("LABEL_CN"));
            LogHome.getLog().info("==============logInfo=" + userName + "于" + time.toString() + "通过" + userip + "删除电路" + newObj.getAttrString("LABEL_CN"));
            param.put("OpType", "Del");
            param.put("AppModule", "电路资源管理");
            param.put("OpText", "删除电路");
          } else if (operateType == 2L) {
            String oldTraphName = oldObj.getAttrString("LABEL_CN");
            String newTraphName = newObj.getAttrString("LABEL_CN");
            LogHome.getLog().info("=============oldTraphName=" + oldTraphName + ",newTraphName=" + newTraphName);
            objectoperatelog.setOperateType(2L);
            if (!oldTraphName.equals(newTraphName)) {
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改电路 " + oldTraphName + ",修改后名字为 " + newTraphName);
            }
            else {
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改电路" + newTraphName);
            }
            LogHome.getLog().info("==============logInfo=" + objectoperatelog.getLogInfo());
            param.put("OpType", "Update");
            param.put("AppModule", "电路资源管理");
            param.put("OpText", "修改电路");
          }
        } else if (objType == 7L) {
          objectoperatelog.setObjType(7L);
          if (newObj.getClassName().equals("ODF")) {
            objectoperatelog.setObjName(newObj.getAttrString("LABEL_CN"));
            if (operateType == 1L) {
              objectoperatelog.setOperateType(1L);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "添加ODF " + newObj.getAttrString("LABEL_CN"));
              param.put("OpType", "Add");
              param.put("AppModule", "配线架管理");
              param.put("OpText", "增加ODF机架");
            } else if (operateType == 3L) {
              objectoperatelog.setOperateType(3L);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "删除ODF " + newObj.getAttrString("LABEL_CN"));
              param.put("OpType", "Del");
              param.put("AppModule", "配线架管理");
              param.put("OpText", "删除ODF架");
            } else if (operateType == 2L) {
              objectoperatelog.setOperateType(2L);
              if (!((Odf)oldObj).getLabelCn().equals(((Odf)newObj).getLabelCn())) {
                objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改ODF " + oldObj.getAttrString("LABEL_CN") + ",修改后名字为 " + newObj.getAttrString("LABEL_CN"));
              }
              else {
                objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改ODF " + newObj.getAttrString("LABEL_CN"));
              }
              param.put("OpType", "Update");
              param.put("AppModule", "配线架管理");
              param.put("OpText", "修改ODF架");
            }
          } else if (newObj.getClassName().equals("DDF")) {
            objectoperatelog.setObjName(newObj.getAttrString("LABEL_CN"));
            if (operateType == 1L) {
              objectoperatelog.setOperateType(1L);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "添加DDF " + newObj.getAttrString("LABEL_CN"));
              param.put("OpType", "Add");
              param.put("AppModule", "配线架管理");
              param.put("OpText", "增加DDF架");
            } else if (operateType == 3L) {
              objectoperatelog.setOperateType(3L);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "删除DDF " + newObj.getAttrString("LABEL_CN"));
              param.put("OpType", "Del");
              param.put("AppModule", "配线架管理");
              param.put("OpText", "删除DDF架");
            } else if (operateType == 2L) {
              objectoperatelog.setOperateType(2L);
              if (!((Ddf)oldObj).getLabelCn().equals(((Ddf)newObj).getLabelCn())) {
                objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改DDF " + oldObj.getAttrString("LABEL_CN") + ",修改后名字为 " + newObj.getAttrString("LABEL_CN"));
              }
              else {
                objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改DDF " + newObj.getAttrString("LABEL_CN"));
              }
              param.put("OpType", "Update");
              param.put("AppModule", "配线架管理");
              param.put("OpText", "修改DDF架");
            }
          } else if (newObj.getClassName().equals("MISCRACK")) {
            objectoperatelog.setObjName(newObj.getAttrString("LABEL_CN"));
            if (operateType == 1L) {
              objectoperatelog.setOperateType(1L);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "添加综合机架 " + newObj.getAttrString("LABEL_CN"));
              param.put("OpType", "Add");
              param.put("AppModule", "配线架管理");
              param.put("OpText", "增加综合机架");
            } else if (operateType == 3L) {
              objectoperatelog.setOperateType(3L);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "删除综合机架 " + newObj.getAttrString("LABEL_CN"));
              param.put("OpType", "Del");
              param.put("AppModule", "配线架管理");
              param.put("OpText", "删除综合机架");
            } else if (operateType == 2L) {
              objectoperatelog.setOperateType(2L);
              if (!((Miscrack)oldObj).getLabelCn().equals(((Miscrack)newObj).getLabelCn())) {
                objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改综合机架 " + oldObj.getAttrString("LABEL_CN") + ",修改后名字为 " + newObj.getAttrString("LABEL_CN"));
              }
              else {
                objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改综合机架 " + newObj.getAttrString("LABEL_CN"));
              }
              param.put("OpType", "Update");
              param.put("AppModule", "配线架管理");
              param.put("OpText", "修改综合机架");
            }
          }
        } else if (objType == 8L) {
          objectoperatelog.setObjType(8L);
          if (newObj.getClassName().equals("ODFPORT")) {
            objectoperatelog.setObjName(((Odfport)newObj).getLabelCn());
            if (operateType == 1L) {
              objectoperatelog.setOperateType(1L);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "添加ODF端子 " + newObj.getAttrString("LABEL_CN"));
              param.put("OpType", "Add");
              param.put("AppModule", "配线架端子管理");
              param.put("OpText", "增加ODF架端子");
            } else if (operateType == 3L) {
              objectoperatelog.setOperateType(3L);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "删除ODF端子 " + newObj.getAttrString("LABEL_CN"));
              param.put("OpType", "Del");
              param.put("AppModule", "配线架端子管理");
              param.put("OpText", "删除ODF架端子");
            } else if (operateType == 2L) {
              objectoperatelog.setOperateType(2L);
              if (!((Odfport)oldObj).getLabelCn().equals(((Odfport)newObj).getLabelCn())) {
                objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改ODF端子 " + oldObj.getAttrString("LABEL_CN") + ",修改后名字为 " + newObj.getAttrString("LABEL_CN"));
              }
              else {
                objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改ODF端子 " + newObj.getAttrString("LABEL_CN"));
              }
              param.put("OpType", "Update");
              param.put("AppModule", "配线架端子管理");
              param.put("OpText", "修改ODF架端子");
            }
          } else if (newObj.getClassName().equals("DDFPORT")) {
            objectoperatelog.setObjName(newObj.getAttrString("LABEL_CN"));
            if (operateType == 1L) {
              objectoperatelog.setOperateType(1L);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "添加DDF端子 " + newObj.getAttrString("LABEL_CN"));
              param.put("OpType", "Add");
              param.put("AppModule", "配线架端子管理");
              param.put("OpText", "增加DDF架端子");
            } else if (operateType == 3L) {
              objectoperatelog.setOperateType(3L);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "删除DDF端子 " + newObj.getAttrString("LABEL_CN"));
              param.put("OpType", "Del");
              param.put("AppModule", "配线架端子管理");
              param.put("OpText", "删除DDF架端子");
            } else if (operateType == 2L) {
              objectoperatelog.setOperateType(2L);
              if (!((Ddfport)oldObj).getLabelCn().equals(((Ddfport)newObj).getLabelCn())) {
                objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改DDF端子 " + oldObj.getAttrString("LABEL_CN") + ",修改后名字为 " + newObj.getAttrString("LABEL_CN"));
              }
              else {
                objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改DDF端子 " + newObj.getAttrString("LABEL_CN"));
              }
              param.put("OpType", "Update");
              param.put("AppModule", "配线架端子管理");
              param.put("OpText", "修改DDF架端子");
            }
          }
        } else if (objType == 9L) {
          objectoperatelog.setObjType(9L);
          if (newObj.getClassName().equals("JUMP_PAIR")) {
            objectoperatelog.setObjName(((JumpPair)newObj).getLabelCn());
            if (operateType == 1L) {
              objectoperatelog.setOperateType(1L);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "添加跳线 " + newObj.getAttrString("LABEL_CN"));
              param.put("OpType", "Add");
              param.put("AppModule", "跳纤跳线管理");
              param.put("OpText", "增加跳线");
            } else if (operateType == 3L) {
              objectoperatelog.setOperateType(3L);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "删除跳线 " + newObj.getAttrString("LABEL_CN"));
              param.put("OpType", "Del");
              param.put("AppModule", "跳纤跳线管理");
              param.put("OpText", "删除跳线");
            } else if (operateType == 2L) {
              objectoperatelog.setOperateType(2L);
              if (!((JumpPair)oldObj).getLabelCn().equals(((JumpPair)newObj).getLabelCn())) {
                objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改跳线 " + oldObj.getAttrString("LABEL_CN") + ",修改后名字为 " + newObj.getAttrString("LABEL_CN"));
              }
              else {
                objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改跳线 " + newObj.getAttrString("LABEL_CN"));
              }
              param.put("OpType", "Update");
              param.put("AppModule", "跳纤跳线管理");
              param.put("OpText", "修改跳线");
            }
          } else if (newObj.getClassName().equals("JUMP_FIBER")) {
            objectoperatelog.setObjName(newObj.getAttrString("LABEL_CN"));
            if (operateType == 1L) {
              objectoperatelog.setOperateType(1L);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "添加跳纤 " + newObj.getAttrString("LABEL_CN"));
              param.put("OpType", "Add");
              param.put("AppModule", "跳纤跳线管理");
              param.put("OpText", "增加跳纤");
            } else if (operateType == 3L) {
              objectoperatelog.setOperateType(3L);
              objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "删除跳纤 " + newObj.getAttrString("LABEL_CN"));
              param.put("OpType", "Del");
              param.put("AppModule", "跳纤跳线管理");
              param.put("OpText", "删除跳纤");
            } else if (operateType == 2L) {
              objectoperatelog.setOperateType(2L);
              if (!((JumpFiber)oldObj).getLabelCn().equals(((JumpFiber)newObj).getLabelCn())) {
                objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改跳纤 " + oldObj.getAttrString("LABEL_CN") + ",修改后名字为 " + newObj.getAttrString("LABEL_CN"));
              }
              else {
                objectoperatelog.setLogInfo(userName + "于" + time.toString() + "通过" + userip + "修改跳纤 " + newObj.getAttrString("LABEL_CN"));
              }
              param.put("OpType", "Update");
              param.put("AppModule", "跳纤跳线管理");
              param.put("OpText", "修改跳纤");
            }
          }
        } else if ((objType > 100L) && (objType <= 200L)) {
          objectoperatelog.setObjType(objType);
          String objTypeName = ObjEnum.OBJ_TYPE.getName(Long.valueOf(objType));

          getObjectOperateLogDAO().getDboCuidObj(newObj, new String[] { newObj.getCuid() });
          getObjectOperateLogDAO().getDboCuidObj(oldObj, new String[] { oldObj.getCuid() });

          String newObjName = newObj.getAttrString("LABEL_CN");
          String oldObjName = oldObj.getAttrString("LABEL_CN");
          objectoperatelog.setObjName(newObjName);
          objectoperatelog.setOperateType(operateType);
          String operateInfo = userName + "于" + time.toString() + "通过" + userip + " " + ObjEnum.OPERATE_TYPE.getName(Long.valueOf(operateType)) + objTypeName + " ";

          if (operateType == 1L) {
            objectoperatelog.setLogInfo(operateInfo + newObjName);
          }
          else if (operateType == 3L) {
            objectoperatelog.setLogInfo(operateInfo + newObjName);
          }
          else if (operateType == 2L) {
            if (!DaoHelper.isSameStr(newObjName, oldObjName)) {
              objectoperatelog.setLogInfo(operateInfo + oldObjName + ",修改后名字为 " + newObjName);
            }
            else {
              objectoperatelog.setLogInfo(operateInfo + newObjName);
            }
          }
        }

        if (TnmsRuntime.getInstance().equals("WRITE_OBJECT_OPERATE_LOG", Boolean.TRUE.toString())) {
          getObjectOperateLogDAO().addObjOperateLog(actionContext, objectoperatelog);
        }
        if (TnmsClientCfg.getInstance().getLoginPattern().equals("Support4ALogin"))
          getSecurityBO().addAuditOptionLog(actionContext, param);
      }
    }
    catch (Exception e) {
      LogHome.getLog().info("方法addObjOperateLog报错", e);
    }
  }

  private String getPathname(TransPath newpath)
  {
    String origsitename = "";
    String destsitename = "";
    String origptpname = "";
    String destptpname = "";
    String origctpname = "";
    String destctpname = "";
    if (newpath.getOrigSiteCuid() != null) {
      ISiteBO ibo = (ISiteBO)BoHomeFactory.getInstance().getBO("ISiteBO");
      Site dbo = ibo.getSiteByCuid(new BoActionContext(), newpath.getOrigSiteCuid());
      if ((dbo != null) && (dbo.getLabelCn() != null)) {
        origsitename = dbo.getLabelCn();
      }
    }
    if (newpath.getDestSiteCuid() != null) {
      ISiteBO ibo = (ISiteBO)BoHomeFactory.getInstance().getBO("ISiteBO");
      Site dbo = ibo.getSiteByCuid(new BoActionContext(), newpath.getDestSiteCuid());
      if ((dbo != null) && (dbo.getLabelCn() != null)) {
        destsitename = dbo.getLabelCn();
      }
    }
    if (newpath.getRelatedAEndPtp() != null)
    {
      Ptp dbo = null;
      try {
        dbo = (Ptp)getCommonDAO().getObjByCuid(new Ptp(newpath.getRelatedAEndPtp()));
      } catch (Exception e) {
        LogHome.getLog().info("打印日志时，获得PTP错误", e);
      }
      if ((dbo != null) && (dbo.getLabelCn() != null)) {
        origptpname = dbo.getLabelCn();
      }
    }
    if (newpath.getRelatedZEndPtp() != null)
    {
      Ptp dbo = null;
      try {
        dbo = (Ptp)getCommonDAO().getObjByCuid(new Ptp(newpath.getRelatedZEndPtp()));
      } catch (Exception e) {
        LogHome.getLog().info("打印日志时，获得PTP错误", e);
      }
      if ((dbo != null) && (dbo.getLabelCn() != null)) {
        destptpname = dbo.getLabelCn();
      }
    }
    if (newpath.getOrigPointCuid() != null)
    {
      Ctp dbo = null;
      try {
        dbo = (Ctp)getCommonDAO().getObjByCuid(new Ctp(newpath.getOrigPointCuid()));
      } catch (Exception e) {
        LogHome.getLog().info("方法getPathname失败", e);
        e.printStackTrace();
      }
      if ((dbo != null) && (dbo.getLabelCn() != null)) {
        LogHome.getLog().info("打印日志时，获得CTP错误");
      }
    }
    if (newpath.getDestPointCuid() != null)
    {
      Ctp dbo = null;
      try {
        dbo = (Ctp)getCommonDAO().getObjByCuid(new Ctp(newpath.getDestPointCuid()));
      } catch (Exception e) {
        LogHome.getLog().info("打印日志时，获得CTP错误", e);
      }
      if ((dbo != null) && (dbo.getLabelCn() != null)) {
        destctpname = dbo.getLabelCn();
      }
    }
    String temp = "";
    if (origsitename.trim().length() != 0) {
      temp = origsitename;
    }
    if (origptpname.trim().length() != 0) {
      temp = temp + "(" + origptpname;
      if (origctpname.trim().length() != 0) {
        temp = temp + "/" + origctpname;
      }
      temp = temp + ")";
    }
    temp = temp + "<>";
    if (destsitename.trim().length() != 0) {
      temp = temp + destsitename;
    }
    if (destptpname.trim().length() != 0) {
      temp = temp + "(" + destptpname;
      if (destctpname.trim().length() != 0) {
        temp = temp + "/" + destctpname;
      }
      temp = temp + ")";
    }
    return temp;
  }

  public void deleteLogsByIds(BoActionContext actionContext, String cuids)
    throws Exception
  {
    String[] cuid = cuids.split(",");
    String condition = "";
    for (int i = 0; i < cuid.length; i++) {
      if (condition.length() == 0)
        condition = "'" + cuid[i] + "'";
      else {
        condition = condition + ",'" + cuid[i] + "'";
      }
    }
    getObjectOperateLogDAO().deleteLogsByIds(actionContext, condition);
  }

  public DboCollection getObjectLog(BoQueryContext actionContext, HashMap param, String orderString)
    throws UserException
  {
    try
    {
      return getObjectOperateLogDAO().getObjectLog(actionContext, param, orderString);
    }
    catch (Throwable ex) {
      LogHome.getLog().info("方法getObjectLog报错", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public CommonDAO getCommonDAO() { return (CommonDAO)super.getDAO("CommonDAO"); }

  private ISecurityBO getSecurityBO() {
    return (ISecurityBO)super.getBO("ISecurityBO");
  }
}