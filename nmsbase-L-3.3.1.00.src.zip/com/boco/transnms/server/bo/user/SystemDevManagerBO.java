package com.boco.transnms.server.bo.user;

import cn.com.chinamobile.adaption.adaptionInterface.pon.adaptionCmService.PingRESPONSEDocument.PingRESPONSE;
import cn.com.chinamobile.adaption.adaptionInterface.pon.adaptionCmService.PingRESPONSEDocument.PingRESPONSE.Factory;
import com.boco.common.util.db.DbConnManager;
import com.boco.common.util.db.DbContext;
import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.bussiness.consts.SystemManageEnum;
import com.boco.transnms.common.bussiness.consts.SystemManageEnum.DevState;
import com.boco.transnms.common.bussiness.consts.SystemManageEnum.DevType;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.misc.DevState;
import com.boco.transnms.server.bo.base.BoHomeFactory;
import com.boco.transnms.server.bo.ibo.misc.ISystemDevManageBO;
import com.boco.transnms.server.bo.ibo.system.ISystemParaBO;
import com.boco.transnms.server.common.cfg.TnmsServerName;
import com.boco.transnms.server.common.cfg.TnmsServerName.ServerName;
import com.boco.transnms.server.dao.common.CommonDAO;
import com.boco.transnms.server.web.ServiceManager;
import java.io.PrintStream;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;

public class SystemDevManagerBO extends SystemManageBOX
  implements ISystemDevManageBO
{
  private static final Map<String, GenericDO> cacheIndexMap = new Hashtable();
  private RefreshServerStateThread refreshServerStateThread;
  private boolean isOnrefreshDevState;
  private boolean isServerStateRefreshing;
  private long activeRefreshServerStateThreadId;
  private int printCount;
  int serverLogCount;
  int ackInterval;

  public SystemDevManagerBO()
  {
    this.isOnrefreshDevState = false;
    this.isServerStateRefreshing = false;
    this.activeRefreshServerStateThreadId = -1L;
    this.printCount = 20;
    this.serverLogCount = 0;
    this.ackInterval = 30;
  }

  public void initBO()
  {
    try
    {
      ServiceManager.getInstance();
      initDBState();

      if (isMainServer())
        try
        {
          this.refreshServerStateThread = new RefreshServerStateThread(null);
          this.refreshServerStateThread.start();
          this.activeRefreshServerStateThreadId = this.refreshServerStateThread.getId();

          RefreshDevStateThread Refreshthread = new RefreshDevStateThread(null);
          Refreshthread.start();
        } catch (Throwable ex) {
          LogHome.getLog().error("SystemDevManageBO 初始化网管组织结构图节点对象出错", ex);
          throw new UserException(ex);
        }
    }
    catch (Exception e) {
      LogHome.getLog().error("初始化监听器失败", e);
    }
  }

  private PingRESPONSEDocument.PingRESPONSE getPing() {
    PingRESPONSEDocument.PingRESPONSE response = PingRESPONSEDocument.PingRESPONSE.Factory.newInstance();
    System.out.println(response);
    return response;
  }

  private void initDBState()
  {
    if (null != DbConnManager.getInstance().getDbContext("GLOBAL_DS_NAME")) {
      DevState dbState = new DevState();
      DbContext dbContext = DbConnManager.getInstance().getDbContext("GLOBAL_DS_NAME");
      String dmIp = dbContext.getDbUrl();
      if ((null != dmIp) && (dmIp.length() > 0)) {
        dmIp = dmIp.substring(dmIp.indexOf("@") + 1);
        dmIp = dmIp.substring(0, dmIp.indexOf(":"));
      }
      dbState.setDevIp(dmIp);
      dbState.setCuid("DM_SERVER_GLOBAL" + dmIp);
      dbState.setDevType(Long.valueOf(101L));
      dbState.setDevName("资源数据处理服务器");
      dbState.setDevState(Long.valueOf(2L));
      regDevState(new BoActionContext(), dbState);
    }
    if (null != DbConnManager.getInstance().getDbContext("ALARM_DS_NAME")) {
      DevState dbState = new DevState();
      DbContext dbContext = DbConnManager.getInstance().getDbContext("ALARM_DS_NAME");
      String dmIp = dbContext.getDbUrl();
      if ((null != dmIp) && (dmIp.length() > 0)) {
        dmIp = dmIp.substring(dmIp.indexOf("@") + 1);
        dmIp = dmIp.substring(0, dmIp.indexOf(":"));
      }
      dbState.setDevIp(dmIp);
      dbState.setCuid("DM_SERVER_ALARM" + dmIp);
      dbState.setDevType(Long.valueOf(101L));
      dbState.setDevName("告警数据处理服务器");
      dbState.setDevState(Long.valueOf(2L));
      regDevState(new BoActionContext(), dbState);
    }
  }

  public boolean checkDB() throws UserException
  {
    try {
      int i = getCommonDAO().getCountOfClass("DISTRICT");
      if (i >= 0) {
        return true;
      }
      return false;
    }
    catch (Exception ex) {
      LogHome.getLog().error("数据管理层连接异常 !", ex);
    }return false;
  }

  public DataObjectList getAllDevState(BoActionContext actionContext) throws UserException
  {
    try {
      DataObjectList devstates = new DataObjectList();
      synchronized (cacheIndexMap) {
        Collection values = cacheIndexMap.values();
        devstates.addAll(values);
      }
      devstates.sort("RELATED_RTU", true);
      return devstates;
    } catch (Throwable ex) {
      LogHome.getLog().error("getAllDevState得到全部管理的设备管理状态出错" + ex);
      throw new UserException(ex);
    }
  }

  private void regDevInfo(BoActionContext actionContext, DevState devstate)
  {
    if ((devstate != null) && (devstate.getCuid() == null)) {
      devstate.setCuid(setDevStateCUID(devstate));
    }
    devstate.setUserName(actionContext.getUserName());
    devstate.setIntervalCycle(Long.valueOf(180L));
    devstate.setLogTime(new Timestamp(System.currentTimeMillis()));
    devstate.setDevState(Long.valueOf(2L));
  }

  public DevState regDevState(BoActionContext actionContext, DevState devstate) throws UserException {
    try {
      if (devstate != null) {
        regDevInfo(actionContext, devstate);
        synchronized (cacheIndexMap) {
          cacheIndexMap.put(devstate.getCuid(), devstate);
        }

        if ((devstate.getDevType() == 104L) && (!this.isOnrefreshDevState))
        {
          Thread t = new Thread() {
            public void run() {
              LogHome.getLog().info("刷新设备状态线程启动");
              SystemDevManagerBO.this.refreshDevState();
              LogHome.getLog().info("刷新设备状态线程终止");
            }
          };
          t.start();
        }
      }

      return devstate;
    } catch (Throwable ex) {
      LogHome.getLog().error("addDevState注册客户机出错", ex);
      throw new UserException(ex);
    }
  }

  public void regDevState(BoActionContext actionContext, DataObjectList devState) throws UserException {
    synchronized (cacheIndexMap) {
      for (GenericDO gdo : devState)
        if ((gdo instanceof DevState)) {
          DevState dev = (DevState)gdo;
          cacheIndexMap.put(dev.getCuid(), dev);
        }
    }
  }

  private void refreshDevState()
  {
    this.isOnrefreshDevState = true;
    try {
      DataObjectList devs = new DataObjectList();
      synchronized (cacheIndexMap) {
        Collection values = cacheIndexMap.values();
        devs.addAll(values);
      }

      Iterator iterator = devs.iterator();
      Timestamp currentTime = new Timestamp(System.currentTimeMillis());
      while (iterator.hasNext()) {
        DevState devstate = (DevState)iterator.next();
        if ((devstate != null) && (
          (devstate.getDevType() == 104L) || (devstate.getDevType() == 105L) || (devstate.getDevType() == 100L)))
        {
          refreshClientState(devstate, currentTime);
        }

      }

      printDevList();
    } catch (Throwable ex) {
      this.isOnrefreshDevState = false;
      LogHome.getLog().error("refreshDevState刷新设备状态出错", ex);
      throw new UserException(ex);
    } finally {
      this.isOnrefreshDevState = false;
    }
  }

  public void modifyDevInfo(DevState devinfor) throws UserException {
    try {
      LogHome.getLog().warn("modifyDevInfo更新设备状态,设置为连接!" + devinfor.toString());
      cacheIndexMap.put(devinfor.getCuid(), devinfor);
    } catch (Throwable ex) {
      LogHome.getLog().error("modifyDevInfo更新设备状态出错", ex);
      throw new UserException(ex);
    }
  }

  private void printDevList() {
    try {
      if (this.printCount > 10) {
        this.printCount = 0;
        DataObjectList alldevstates = getAllDevState(new BoActionContext());
        LogHome.getLog().info("---------- 打印当前设备列表 -- 开始 ----------");
        LogHome.getLog().info("---- cuid ---- DevName ---- DevIp ---- DevType ---- DevState ---- DevInfo ----");
        for (int i = 0; i < alldevstates.size(); i++) {
          DevState devstate = (DevState)alldevstates.get(i);
          LogHome.getLog().info(" " + devstate.getCuid() + " " + devstate.getDevName() + " " + devstate.getDevIp() + "  " + SystemManageEnum.DEV_STATE.getName(Long.valueOf(devstate.getDevState())) + "  " + SystemManageEnum.DEV_TYPE.getName(Long.valueOf(devstate.getDevType())) + " " + devstate.getDevInfo());
        }

        LogHome.getLog().info("---------- 打印当前设备列表 -- 结束 ----------");
      } else {
        this.printCount += 1;
      }
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public void refreshClientState(DevState devstate, Timestamp currentTime)
  {
    if ((devstate.getDevState() == 2L) && (currentTime.getTime() - devstate.getLogTime().getTime() > 3L * devstate.getIntervalCycle() * 1000L))
    {
      setDevStateDisconnect(devstate);
    }
  }

  public void setDevStateDisconnect(DevState devinfor) throws UserException {
    try {
      LogHome.getLog().warn("refreshClientState>>更新设备状态,设置为断开" + devinfor.toString());
      DevState gdo = (DevState)cacheIndexMap.get(devinfor.getCuid());
      if (gdo != null) {
        gdo.setLogTime(new Timestamp(System.currentTimeMillis()));
        gdo.setDevState(Long.valueOf(1L));
        gdo.setCurrentState(Long.valueOf(devinfor.getCurrentState()));
      }
    } catch (Throwable ex) {
      LogHome.getLog().error("refreshClientState>>更新设备状态出错", ex);
      throw new UserException(ex);
    }
  }

  private boolean isMainServer() {
    if ((TnmsServerName.getLocalServerNameStr().equals(TnmsServerName.ServerName.CM.toString())) || (TnmsServerName.getLocalServerNameStr().equals(TnmsServerName.ServerName.DM.toString())))
    {
      return true;
    }
    return false;
  }

  private void refreshServerState()
  {
    LogHome.getLog().debug("刷新服务器状态开始");
    this.isServerStateRefreshing = true;
    try
    {
      try
      {
        clearServiceNodeState();

        ServiceManager.getInstance().sendQueryMsg();
        regDevState(new BoActionContext(), ServiceManager.getInstance().getLocalServerState());
      } catch (Exception ex) {
        ex.printStackTrace();
      }
      LogHome.getLog().debug("刷新服务器状态结束");
    } catch (Throwable ex) {
      LogHome.getLog().error("刷新服务器状态出错", ex);
      throw new UserException(ex);
    } finally {
      this.isServerStateRefreshing = false;
    }
  }

  public void clearServiceNodeState() {
    DevState localDevState = ServiceManager.getInstance().getLocalServerState();
    Iterator iterator = cacheIndexMap.values().iterator();
    while (iterator.hasNext()) {
      DevState devstate = (DevState)iterator.next();
      if ((devstate != null) && (localDevState.getCuid() != null) && (!localDevState.getCuid().equals(devstate.getCuid())))
      {
        if (devstate.getDevType() < 49L)
          devstate.setDevState(Long.valueOf(1L));
      }
    }
  }

  public String setDevStateCUID(DevState devState)
  {
    String CUID = "";
    if (devState != null) {
      long iType = devState.getDevType();
      String cuidStr = "";
      if (iType < 100L)
        cuidStr = TnmsServerName.getLocalServerNameStr();
      else {
        cuidStr = SystemManageEnum.DEV_TYPE.getName(Long.valueOf(iType));
      }
      CUID = cuidStr + devState.getDevIp();
    }
    return CUID;
  }

  private void checkNodeSync(String objTarget)
  {
    if (objTarget.equals("FORCE")) {
      LogHome.getLog().info("可能服务节点检测线程处于未激活状态，强制重新启动线程！");
      if (this.refreshServerStateThread != null) {
        this.refreshServerStateThread.interrupt();
      }
      this.refreshServerStateThread = new RefreshServerStateThread(null);
      this.refreshServerStateThread.start();
      this.activeRefreshServerStateThreadId = this.refreshServerStateThread.getId();
    }
    else if (!this.refreshServerStateThread.isAlive()) {
      LogHome.getLog().info("服务节点检测线程处于未激活状态，重新启动线程！");
      this.refreshServerStateThread = new RefreshServerStateThread(null);
      this.refreshServerStateThread.start();
      this.activeRefreshServerStateThreadId = this.refreshServerStateThread.getId();
    } else {
      LogHome.getLog().info("服务节点检测线程处于激活状态 !");
    }
  }

  public String getServerAddress() throws UserException
  {
    String port = System.getProperty("SERVICE_LOCAL_PORT");
    String address = System.getProperty("SERVICE_LOCAL_ADDRESS");
    return address + "/" + port;
  }

  private ISystemParaBO getSystemParaBO() {
    return (ISystemParaBO)BoHomeFactory.getInstance().getBO(ISystemParaBO.class.getSimpleName());
  }

  private void initAckInterval() {
    String interval = getSystemParaBO().getSystemParaValue(new BoActionContext(), "状态询问时间间隔", "STATE_ACK_INTERVAL");
    if (StringUtils.isNotBlank(interval))
      this.ackInterval = Integer.parseInt(interval);
    else
      getSystemParaBO().createSystemPara(new BoActionContext(), "状态询问时间间隔", "STATE_ACK_INTERVAL", "30", "状态询问时间间隔");
  }

  private class CacheAdminHandler
    implements MessageListener
  {
    private CacheAdminHandler()
    {
    }

    public void onMessage(Message _message)
    {
      if ((_message instanceof TextMessage))
        try {
          TextMessage msg = (TextMessage)_message;
          String adminCmd = msg.getText();
          if (adminCmd != null) {
            String[] _adminCmd = adminCmd.split(":");
            String serverName = _adminCmd[0];
            String cmd = _adminCmd[1];
            String _objTargets = _adminCmd[2];
            String[] objTargets = _objTargets.split(",");
            if (TnmsServerName.ServerName.CM.toString().equals(serverName)) {
              for (String objTarget : objTargets)
                if ("checkNodeSync".equals(cmd))
                  SystemDevManagerBO.this.checkNodeSync(objTarget);
                else
                  LogHome.getLog().error("未知的管理命令：" + cmd);
            }
          }
        }
        catch (Throwable ex)
        {
          LogHome.getLog().error("", ex);
        }
    }
  }

  private class RefreshDevStateThread extends Thread
  {
    private RefreshDevStateThread()
    {
    }

    public void run()
    {
      while (true)
        try
        {
          if (!SystemDevManagerBO.this.isOnrefreshDevState)
            SystemDevManagerBO.this.refreshDevState();
        }
        catch (Exception ex) {
          LogHome.getLog().error("", ex);
        } finally {
          try {
            sleep(180000L);
          }
          catch (Exception ex)
          {
          }
        }
    }
  }

  private class RefreshServerStateThread extends Thread
  {
    private RefreshServerStateThread()
    {
    }

    public void run()
    {
      SystemDevManagerBO.this.initAckInterval();
      while (true)
      {
        if (getId() != SystemDevManagerBO.this.activeRefreshServerStateThreadId) {
          LogHome.getLog().info("当前激活的服务节点检测线程不是当前线程，结束当前线程：" + getId() + ",激活线程ID:" + SystemDevManagerBO.this.activeRefreshServerStateThreadId);
          break;
        }
        try {
          if (!SystemDevManagerBO.this.isServerStateRefreshing)
            SystemDevManagerBO.this.refreshServerState();
        }
        catch (Exception ex) {
          LogHome.getLog().error("刷新服务器状态出错：", ex);
        } finally {
          try {
            sleep(SystemDevManagerBO.this.ackInterval * 1000);
          }
          catch (Exception ex)
          {
          }
        }
      }
    }
  }
}