package com.boco.transnms.server.bo.user;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.AutoChannelTask;
import com.boco.transnms.common.dto.Card;
import com.boco.transnms.common.dto.ConfigCollectTask;
import com.boco.transnms.common.dto.NmsSystem;
import com.boco.transnms.common.dto.PdhSystem;
import com.boco.transnms.common.dto.Ptp;
import com.boco.transnms.common.dto.Room;
import com.boco.transnms.common.dto.SdhSystem;
import com.boco.transnms.common.dto.Site;
import com.boco.transnms.common.dto.TransElement;
import com.boco.transnms.common.dto.TransSubNetwork;
import com.boco.transnms.common.dto.TranspathCheckTask;
import com.boco.transnms.common.dto.WdmSystem;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.common.ClientState;
import com.boco.transnms.common.dto.misc.DevState;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.ibo.misc.ISystemManageBOX;
import com.boco.transnms.server.dao.common.CommonDAO;
import com.boco.transnms.server.proxy.adapter.util.NmcEnum.TaskState;
import com.boco.transnms.server.web.ServiceManager;

@StateLessBO(serverName="CM")
public class SystemManageBOX extends AbstractBO
  implements ISystemManageBOX
{
  public Boolean isHasRuningTask(BoActionContext actionContext, Room room)
    throws UserException
  {
    String ans = getAllRuntask(actionContext, room.getCuid());
    if (ans == null) {
      return Boolean.valueOf(false);
    }
    return Boolean.valueOf(true);
  }

  public Boolean isHasRuningTask(BoActionContext actionContext, Site site) throws UserException
  {
    String ans = getAllRuntask(actionContext, site.getCuid());
    if (ans == null) {
      return Boolean.valueOf(false);
    }
    return Boolean.valueOf(true);
  }

  protected String getAllRuntask(BoActionContext actionContext, String objectCuid) throws UserException
  {
    String ansMsg = null;
    try {
      String sql = "TASK_STATE=" + NmcEnum.TaskState.nmc_processing.ordinal();
      DataObjectList collectMainTaskList = getCommonDAO().getObjectsBySql(sql, new ConfigCollectTask(), 0);
      if ((collectMainTaskList != null) && (collectMainTaskList.size() > 0)) {
        return "系统有采集任务正在进行!";
      }

      sql = "TASK_STATE=1";
      collectMainTaskList = getCommonDAO().getObjectsBySql(sql, new AutoChannelTask(), 0);
      if ((collectMainTaskList != null) && (collectMainTaskList.size() > 0)) {
        return "系统有自动串接任务正在进行!";
      }

      sql = "TASK_STATE=2";
      collectMainTaskList = getCommonDAO().getObjectsBySql(sql, new TranspathCheckTask(), 0);
      if ((collectMainTaskList != null) && (collectMainTaskList.size() > 0))
        return "系统有通道或电路核查任务正在进行!";
    }
    catch (Exception e)
    {
      throw new UserException(e);
    }
    return ansMsg;
  }

  public DevState getServerState(BoActionContext actionContext, ClientState cs) throws UserException
  {
    DevState serverState = null;
    try {
      serverState = ServiceManager.getInstance().getLocalServerState();
    } catch (Exception ex) {
      throw new UserException("获取服务器状态出错：" + ex.getMessage());
    }
    return serverState;
  }

  public String getRoomRuntask(BoActionContext actionContext, Room oldRoom, Room newRoom)
    throws UserException
  {
    String ansMsg = null;
    try {
      Site site = new Site();
      site.setCuid(oldRoom.getRelatedSiteCuid());
      site = (Site)getCommonDAO().getObjByCuid(site);
      String oldDistrict = "";
      if (site != null) {
        oldDistrict = site.getRelatedSpaceCuid();
      }
      String sql = "TASK_STATE=" + NmcEnum.TaskState.nmc_processing.ordinal();
      sql = "TASK_STATE=1";
      DataObjectList collectMainTaskList = getCommonDAO().getObjectsBySql(sql, new AutoChannelTask(), 0);
      if ((collectMainTaskList != null) && (collectMainTaskList.size() > 0))
      {
        boolean flag = true;
        for (int i = 0; i < collectMainTaskList.size(); i++) {
          AutoChannelTask dbo = (AutoChannelTask)collectMainTaskList.get(i);
          String objtype = dbo.getTaskObjType();
          String objCuid = dbo.getTaskObjName();
          if (objtype.equals("1")) {
            TransSubNetwork tr = new TransSubNetwork();
            tr.setCuid(objCuid);
            tr = (TransSubNetwork)getCommonDAO().getObjByCuid(tr);
            if ((tr != null) && (tr.getRelatedDistrictCuid().equals(oldDistrict)))
              flag = false;
          }
          else if (objtype.equals("2")) {
            if (objCuid.indexOf("SDH_SYSTEM") > 0) {
              SdhSystem sys = new SdhSystem();
              sys.setCuid(objCuid);
              sys = (SdhSystem)getCommonDAO().getObjByCuid(sys);
              if ((sys != null) && (sys.getRelatedSpaceCuid().equals(oldDistrict)))
                flag = false;
            }
            else if (objCuid.indexOf("PDH_SYSTEM") > 0) {
              PdhSystem pdhsys = new PdhSystem();
              pdhsys.setCuid(objCuid);
              pdhsys = (PdhSystem)getCommonDAO().getObjByCuid(pdhsys);
              if ((pdhsys != null) && (pdhsys.getRelatedSpaceCuid().equals(oldDistrict)))
                flag = false;
            }
            else if (objCuid.indexOf("WDM_SYSTEM") > 0) {
              WdmSystem wdmsys = new WdmSystem();
              wdmsys.setCuid(objCuid);
              wdmsys = (WdmSystem)getCommonDAO().getObjByCuid(wdmsys);
              if ((wdmsys != null) && (wdmsys.getRelatedSpaceCuid().equals(oldDistrict)))
                flag = false;
            }
          }
          else if (objtype.equals("3")) {
            Site si = new Site();
            si.setCuid(objCuid);
            si = (Site)getCommonDAO().getObjByCuid(si);
            if ((si != null) && (si.getRelatedSpaceCuid().equals(oldDistrict)))
              flag = false;
          }
          else if (objtype.equals("4")) {
            TransElement el = new TransElement();
            el.setCuid(objCuid);
            el = (TransElement)getCommonDAO().getObjByCuid(el);
            if ((el != null) && (el.getRelatedDistrictCuid().equals(oldDistrict)))
              flag = false;
          }
          else if (objtype.equals("5")) {
            Card ca = new Card();
            ca.setCuid(objCuid);
            ca = (Card)getCommonDAO().getObjByCuid(ca);
            if (ca != null) {
              TransElement el = new TransElement();
              el.setCuid(ca.getRelatedDeviceCuid());
              el = (TransElement)getCommonDAO().getObjByCuid(el);
              if ((el != null) && (el.getRelatedDistrictCuid().equals(oldDistrict)))
                flag = false;
            }
          }
          else if (objtype.equals("6")) {
            Ptp ptp = new Ptp();
            ptp.setCuid(objCuid);
            ptp = (Ptp)getCommonDAO().getObjByCuid(ptp);
            if (ptp != null) {
              TransElement el = new TransElement();
              el.setCuid(ptp.getRelatedNeCuid());
              el = (TransElement)getCommonDAO().getObjByCuid(el);
              if ((el != null) && (el.getRelatedDistrictCuid().equals(oldDistrict)))
                flag = false;
            }
          }
          else if (objtype.equals("7")) {
            NmsSystem ems = new NmsSystem();
            ems.setCuid(objCuid);
            ems = (NmsSystem)getCommonDAO().getObjByCuid(ems);
            if ((ems != null) && (ems.getRelatedSpaceCuid().equals(oldDistrict))) {
              flag = false;
            }
          }
          ansMsg = ansMsg + "串接任务名称:" + dbo.getLabelCn() + ",串接任务创建人:" + dbo.getTaskMan() + ",串接任务创建时间:" + dbo.getCreateTime() + ";";
        }
        if (flag) {
          return "";
        }
        return ansMsg;
      }
    }
    catch (Exception e) {
      throw new UserException(e);
    }
    return ansMsg;
  }

  public CommonDAO getCommonDAO()
  {
    return (CommonDAO)super.getDAO(CommonDAO.class);
  }
}