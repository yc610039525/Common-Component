package com.boco.transnms.server.bo.user.sec;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.lang.IQueueThreadHandler;
import com.boco.common.util.lang.QueueThreadPool;
import com.boco.transnms.common.dto.ModuleClickLog;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.server.bo.base.BoHomeFactory;
import com.boco.transnms.server.bo.ibo.misc.ISecurityBO;
import com.boco.transnms.server.common.cfg.TnmsRuntime;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.logging.Log;

public class ModuleClickLogThreadPool
{
  private QueueThreadPool<ModuleClickLog> threadPool;
  private ModuleClickLogHandler handler;
  private int maxModuleClickLogThreadNum = 5;
  private int maxModuleClickLogQueueLen = 500;
  private int addModuleClickLogWaitTime = 1000;

  public ModuleClickLogThreadPool()
  {
    int maxModuleClickLogHandleTime = 2000;
    int checkPoolModuleClickLogNum = 100;
    int checkPoolModuleClickLogTime = 300;
    BoActionContext actionContext = new BoActionContext();
    String threadNum = TnmsRuntime.getInstance().get("MAX_MODULE_CLICK_LOG_THREADNUM");
    if ((threadNum != null) && (threadNum.length() > 0)) {
      this.maxModuleClickLogThreadNum = Integer.parseInt(threadNum);
    }
    String queueLen = TnmsRuntime.getInstance().get("MAX_MODULE_CLICK_LOG_QUEUELEN");
    if ((queueLen != null) && (queueLen.length() > 0)) {
      this.maxModuleClickLogQueueLen = Integer.parseInt(queueLen);
    }
    String waitTime = TnmsRuntime.getInstance().get("ADD_MODULE_CLICK_LOG_WAITTIME");
    if ((waitTime != null) && (waitTime.length() > 0)) {
      this.addModuleClickLogWaitTime = Integer.parseInt(waitTime);
    }
    String handleTime = TnmsRuntime.getInstance().get("MAX_MODULE_CLICK_LOG_HANDELTIME");
    if ((handleTime != null) && (handleTime.length() > 0)) {
      maxModuleClickLogHandleTime = Integer.parseInt(handleTime);
    }
    String checkPoolNum = TnmsRuntime.getInstance().get("CHECK_POOL_MODULE_CLICK_LOG_NUM");
    if ((checkPoolNum != null) && (checkPoolNum.length() > 0)) {
      checkPoolModuleClickLogNum = Integer.parseInt(checkPoolNum);
    }
    String checkPoolTime = TnmsRuntime.getInstance().get("CHECK_POOL_MODULE_CLICK_LOG_TIME");
    if ((checkPoolTime != null) && (checkPoolTime.length() > 0)) {
      checkPoolModuleClickLogTime = Integer.parseInt(checkPoolTime);
    }

    this.threadPool = new QueueThreadPool("当前模块点击日志队列", maxModuleClickLogHandleTime, checkPoolModuleClickLogNum, checkPoolModuleClickLogTime);
    this.handler = new ModuleClickLogHandler();
    this.threadPool.createThreadPool("ModuleClickLog", this.maxModuleClickLogThreadNum, true, this.handler, this.maxModuleClickLogQueueLen, this.addModuleClickLogWaitTime);
  }

  public void sendModuleClickLogToThreadPool(ModuleClickLog moduleClickLog)
  {
    this.threadPool.addElement("ModuleClickLog", moduleClickLog);
  }

  public static class ModuleClickLogHandler implements IQueueThreadHandler<ModuleClickLog>
  {
    public void handle(String threadPoolName, ModuleClickLog moduleClickLog) {
      ISecurityBO bo = (ISecurityBO)BoHomeFactory.getInstance().getBO(ISecurityBO.class);
      bo.addModuleClickLog(moduleClickLog);
    }

    public void handle(String threadPoolName, List<ModuleClickLog> moduleClickLogs) {
      LogHome.getLog().info("模块点击日志添加：threadPoolName=" + threadPoolName + ", 数量=" + moduleClickLogs.size());
      ISecurityBO bo = (ISecurityBO)BoHomeFactory.getInstance().getBO(ISecurityBO.class);
      bo.addModuleClickLogs((ArrayList)moduleClickLogs);
    }
    public void notifyQueueLock() {
    }
    public void notifyQueueUnlock() {
    }

    public boolean isSyncWait(ModuleClickLog moduleClickLog1, ModuleClickLog moduleClickLog2) {
      return false;
    }

    public boolean isSyncWait(ModuleClickLog moduleClickLog, List<ModuleClickLog> handlingModuleClickLogs) {
      return false;
    }

    public Object getElementKey(ModuleClickLog moduleClickLog) {
      return null;
    }
  }
}