package com.boco.transnms.server.bo.user.sec;

import com.boco.common.util.db.DbConnManager;
import com.boco.common.util.db.DbContext;
import com.boco.common.util.db.SqlHelper;
import com.boco.common.util.db.TransactionFactory;
import com.boco.common.util.db.UserTransaction;
import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.common.util.except.UserSecurityException;
import com.boco.common.util.io.FileHelper;
import com.boco.common.util.lang.SecurityHelper;
import com.boco.common.util.lang.TimeFormatHelper;
import com.boco.raptor.common.message.GenericMessage;
import com.boco.raptor.common.message.MsgBusManager;
import com.boco.transnms.common.bussiness.helper.ActionHelper;
import com.boco.transnms.common.cache.CustomCacheManagerFactory;
import com.boco.transnms.common.cache.GenericDaoCache;
import com.boco.transnms.common.dto.ApplySheet;
import com.boco.transnms.common.dto.AttempHandler;
import com.boco.transnms.common.dto.AttempReceiver;
import com.boco.transnms.common.dto.AttempSheet;
import com.boco.transnms.common.dto.Ddf;
import com.boco.transnms.common.dto.District;
import com.boco.transnms.common.dto.FunctionTreeNode;
import com.boco.transnms.common.dto.HistoryUserPassword;
import com.boco.transnms.common.dto.LoginLog;
import com.boco.transnms.common.dto.ModuleClickLog;
import com.boco.transnms.common.dto.Odf;
import com.boco.transnms.common.dto.Organization;
import com.boco.transnms.common.dto.ProActUserList;
import com.boco.transnms.common.dto.RecordData;
import com.boco.transnms.common.dto.ReplySheet;
import com.boco.transnms.common.dto.RoleConsistOfFunPoint;
import com.boco.transnms.common.dto.Room;
import com.boco.transnms.common.dto.Site;
import com.boco.transnms.common.dto.SysUser;
import com.boco.transnms.common.dto.SystemPara;
import com.boco.transnms.common.dto.TransElement;
import com.boco.transnms.common.dto.TransSubNetwork;
import com.boco.transnms.common.dto.UserHaveObject;
import com.boco.transnms.common.dto.UserHaveRole;
import com.boco.transnms.common.dto.UserManageDistrict;
import com.boco.transnms.common.dto.UserPasswordSecurity;
import com.boco.transnms.common.dto.UserRole;
import com.boco.transnms.common.dto.UserToCust;
import com.boco.transnms.common.dto.UserToTraph;
import com.boco.transnms.common.dto.Vp;
import com.boco.transnms.common.dto.VpGroup;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.base.IBoActionContext;
import com.boco.transnms.common.dto.workflow.SharkRole;
import com.boco.transnms.common.dto.workflow.SharkUser;
import com.boco.transnms.common.util.PwdEncodeUtil;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.BoHomeFactory;
import com.boco.transnms.server.bo.base.StateBO;
import com.boco.transnms.server.bo.ibo.base.IGenericSchedulerBO;
import com.boco.transnms.server.bo.ibo.cm.IDistrictBO;
import com.boco.transnms.server.bo.ibo.misc.ISecurityBO;
import com.boco.transnms.server.bo.ibo.system.ISystemParaBO;
import com.boco.transnms.server.bo.ibo.workflow.IWorkFlowBOX;
import com.boco.transnms.server.common.cfg.SystemEnv;
import com.boco.transnms.server.common.cfg.TnmsRuntime;
import com.boco.transnms.server.common.cfg.TnmsServerName;
import com.boco.transnms.server.common.cfg.TnmsServerName.ServerName;
import com.boco.transnms.server.common.cfg.TransNmsCfg;
import com.boco.transnms.server.common.cfg.TransNmsCfg.ProductType;
import com.boco.transnms.server.dao.area.DistrictDAO;
import com.boco.transnms.server.dao.base.internal.ClassUtils;
import com.boco.transnms.server.dao.common.ColumnConfigDAO;
import com.boco.transnms.server.dao.common.CommonDAO;
import com.boco.transnms.server.dao.scheduler.SchedulerDAO;
import com.boco.transnms.server.dao.user.sec.SecurityDAO;
import com.boco.transnms.server.dao.user.sec.SecurityObjectDAO;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import org.apache.commons.logging.Log;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;
import org.xml.sax.InputSource;

@StateBO(serverName="COMMON")
public class SecurityBO extends AbstractBO
  implements ISecurityBO
{
  public static final String ADMIN_USER_CUID = "SYS_USER-0";
  private GenericDaoCache<String, ConcurrentHashMap<String, DataObjectList>> userDistrictRoles = null;
  private GenericDaoCache<String, ArrayList<String>> roleFunctions = null;
  private GenericDaoCache<String, Integer> userCounts = null;
  private static final String COMMON_FUN_TREE_CUID = "FUNCTION_TREE_NODE-0001";
  private List<String> commonActionNames = new ArrayList();
  private GenericDaoCache<String, Integer> userOnLine = null;
  private String paraClassName = "用户数";
  private String paraName = "UserCount";
  private static Map<String, Boolean> userLockState = new ConcurrentHashMap();
  private ModuleClickLogThreadPool moduleClickLogThreadPool;

  public void initBO()
    throws Exception
  {
    boolean isUserExist = getSecurityDAO().hasObjects("SYS_USER");
    ClassUtils.getInstance();
    this.userDistrictRoles = CustomCacheManagerFactory.getInstance().getCustomCache("SecurityBO", "userDistrictRoles");
    if (this.userDistrictRoles != null) {
      this.userDistrictRoles.init();
    }
    this.roleFunctions = CustomCacheManagerFactory.getInstance().getCustomCache("SecurityBO", "roleFunctions");
    if (this.roleFunctions != null) {
      this.roleFunctions.init();
    }
    this.userCounts = CustomCacheManagerFactory.getInstance().getCustomCache("SecurityBO", "userCounts");
    if (this.userCounts != null) {
      int counts = getSecurityDAO().getSysUserCounts(new BoActionContext());
      this.userCounts.put("user", Integer.valueOf(counts));
      this.userCounts.init();
    }
    this.userOnLine = CustomCacheManagerFactory.getInstance().getCustomCache("SecurityBO", "userOnLine");
    if (this.userOnLine != null) {
      String value = "0";
      ISystemParaBO ibo = (ISystemParaBO)BoHomeFactory.getInstance().getBO(ISystemParaBO.class);
      SystemPara sysPara = ibo.getSystemPara(new BoActionContext(), this.paraClassName, this.paraName);
      if (sysPara != null) {
        value = sysPara.getParaValue();
      }
      this.userOnLine.put("loginUser", Integer.valueOf(value));
      this.userOnLine.init();
    }
    boolean isFunctionExist = getSecurityDAO().hasObjects("FUNCTION_TREE_NODE");
    DataObjectList users = new DataObjectList();
    DataObjectList dbos = new DataObjectList();
    dbos.readFromXml("basicdata/initData.xml");
    for (int i = 0; i < dbos.size(); i++) {
      GenericDO dbo = (GenericDO)dbos.get(i);
      if ("SYS_USER".equals(dbo.getClassName())) {
        users.add(dbo);
      }
    }
    if ((!isUserExist) && 
      (users != null) && (users.size() > 0)) {
      getSecurityDAO().createObjects(null, users);
    }

    String serverName = TnmsServerName.getLocalServerNameStr();
    if ((!isFunctionExist) && (TnmsServerName.ServerName.CM.toString().equals(serverName))) {
      String serverHome = SystemEnv.getPathEnv("TNMS_SERVER_HOME");
      String importPath = serverHome + File.separatorChar + "import" + File.separatorChar + "FunctionTreeNode.xml";
      InputStream is = FileHelper.getFileStream(importPath);
      DataObjectList functiondbos = new DataObjectList();
      functiondbos.readFromStream(is);
      addFunctionTreeNodeFromXML(new BoActionContext(), functiondbos);
    } else {
      initSecurityRoleActionNames();
    }
    LogHome.getLog().info("加载用户安全功能列表 ！");

    if ((TnmsRuntime.getInstance().equals("WRITE_MODULE_CLICK_LOG", Boolean.TRUE.toString())) && (
      (serverName.equals(TnmsServerName.ServerName.CM.toString())) || (serverName.equals(TnmsServerName.ServerName.DM.toString())) || (serverName.equals(TnmsServerName.ServerName.ATTEMP.toString())) || (serverName.equals(TnmsServerName.ServerName.PM.toString()))))
    {
      this.moduleClickLogThreadPool = new ModuleClickLogThreadPool();
    }

    initUserLockState();

    UserTransaction trx = TransactionFactory.getInstance().createTransaction();
    try {
      trx.begin();
      DboCollection worddbos = getSecurityDAO().querySecurityByName(new BoQueryContext(), "", "CUID");
      if (worddbos.size() == 0)
      {
        UserPasswordSecurity worddbo = new UserPasswordSecurity();
        worddbo.setSecurityName("默认密码安全策略");
        worddbo.setIsContainCharater(false);
        worddbo.setIsContainLower(false);
        worddbo.setIsContainNum(false);
        worddbo.setIsContainUpper(false);
        worddbo.setPasswordLength(0L);
        worddbo.setPasswordRepeatCount(1L);
        worddbo.setPasswordAvilableTime(999L);
        worddbo = getSecurityDAO().addUserPasswordSecurity(new BoActionContext(), worddbo);

        DataObjectList userdbos = getSecurityDAO().getAllSysUser(new BoActionContext());
        for (int i = 0; i < userdbos.size(); i++) {
          SysUser user = (SysUser)userdbos.get(i);
          user.setRelatedSecurityCuid(worddbo.getCuid());
          getSecurityDAO().modifySysUser(new BoActionContext(), user);
        }
      }
      trx.commit();
    } catch (Exception ex) {
      trx.rollback();
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  private SchedulerDAO getSchedulerDAO()
  {
    return (SchedulerDAO)super.getDAO("SchedulerDAO");
  }

  private IGenericSchedulerBO getGenericSchedulerBO() {
    return (IGenericSchedulerBO)super.getBO("IGenericSchedulerBO");
  }

  public void initUserLockState()
    throws Exception
  {
    DataObjectList allUserList = getSecurityDAO().getAllSysUser(new BoActionContext());
    userLockState.clear();
    for (int i = 0; i < allUserList.size(); i++) {
      SysUser user = (SysUser)allUserList.get(i);
      userLockState.put(user.getCuid(), Boolean.valueOf(user.getIsLocked()));
    }
    LogHome.getLog().info("加载用户锁定列表完成 ！");
  }

  private void initCommonActionNames() throws Exception {
    FunctionTreeNode dbo = new FunctionTreeNode();
    dbo.setCuid("FUNCTION_TREE_NODE-0001");
    dbo = (FunctionTreeNode)getSecurityDAO().getObjByCuid(dbo);
    this.commonActionNames = getActionNames(dbo.getActionNames());
  }

  private void initRoleFuncs() throws Exception {
    DataObjectList dbos = getSecurityDAO().getAllUserRole(new BoActionContext());
    for (int i = 0; i < dbos.size(); i++) {
      UserRole role = (UserRole)dbos.get(i);
      addRoleActionNames(role.getCuid());
    }
  }

  private void refSecurityRoleActionNames() throws Exception
  {
    initCommonActionNames();
    initRoleFuncs();
  }

  private void initSecurityRoleActionNames()
    throws Exception
  {
    initCommonActionNames();
    DataObjectList dbos = getSecurityDAO().getAllUserRole(new BoActionContext());
    for (int i = 0; i < dbos.size(); i++) {
      UserRole role = (UserRole)dbos.get(i);
      addRoleActionNamesForInit(role.getCuid());
    }
  }

  private void addRoleActionNames(String roleCuid) throws Exception
  {
    try {
      ArrayList roleActionNames = new ArrayList();
      roleActionNames.addAll(getRoleActionNames(roleCuid));
      this.roleFunctions.put(roleCuid, roleActionNames, false);
    } catch (Exception ex) {
      LogHome.getLog().error("addRoleActionNames：", ex);
    }
  }

  private void addRoleActionNamesForInit(String roleCuid)
    throws Exception
  {
    try
    {
      ArrayList roleActionNames = new ArrayList();
      roleActionNames.addAll(getRoleActionNames(roleCuid));
      this.roleFunctions.put(roleCuid, roleActionNames, true);
    } catch (Exception ex) {
      LogHome.getLog().error("addRoleActionNames：", ex);
    }
  }

  private List getRoleActionNames(String roleCuid) throws Exception
  {
    List actionNameList = new ArrayList();
    DboCollection funcs = getSecurityDAO().getRoleFunPoints(null, roleCuid);
    for (int i = 0; i < funcs.size(); i++) {
      FunctionTreeNode func = (FunctionTreeNode)funcs.getAttrField("FUNCTION_TREE_NODE", i);
      if (func != null)
      {
        List actionNames = getActionNames(func.getActionNames());

        for (int k = 0; k < actionNames.size(); k++) {
          String actionName = (String)actionNames.get(k);
          if ((actionName != null) && (actionName.trim().length() > 0) && 
            (!actionNameList.contains(actionName))) {
            actionNameList.add(actionName);
          }
        }
      }
    }
    return actionNameList;
  }

  public SysUser login(BoActionContext actionContext, String userName, String password)
    throws UserException
  {
    SysUser user = null;
    SysUser sysUser = null;
    try {
      user = getSecurityDAO().getUser(userName);
      if (user == null)
        throw new UserException("用户不存在 ！");
      if (!isPasswordIdentical(user.getUserPassword(), password)) {
        String dePassword = SecurityHelper.getInstance().getDecrypt(password);
        if (dePassword == null) {
          password = SecurityHelper.getInstance().getEncrypt(password);
          if (!isPasswordIdentical(user.getUserPassword(), password))
            throw new UserException("用户密码不正确 ！");
        }
        else {
          throw new UserException("用户密码不正确 ！");
        }
      } else { if (user.getIsLocked())
          throw new UserException("用户处于锁定状态 ！");
        if (user.getAccountDate() != null) {
          Date date = new Date();
          if ((user.getAccountDate().getTime() < date.getTime()) && 
            (!user.getIsLocked())) {
            user.setIsLocked(true);
            getSecurityDAO().modifySysUser(actionContext, user);
            throw new UserException("用户过期已锁定 ！");
          }
        }
      }

      user = getSecurityDAO().getSysUser(actionContext, user.getObjectNum());
      sysUser = (SysUser)user.deepClone();
      String defaultTheme = TnmsRuntime.getInstance().get("DEFAULT_THEME");
      if ((defaultTheme == null) || ((!defaultTheme.equals("DarkTheme")) && (!defaultTheme.equals("LightTheme")))) {
        defaultTheme = "GreyTheme";
      }
      String returnStr = "";
      if ((user != null) && (user.getTheme() != null) && (user.getTheme().trim().length() > 0)) {
        returnStr = user.getTheme();
      }
      if ((returnStr == null) || (returnStr.equals("DefaultTheme")) || (returnStr.equals("")) || (returnStr.equals("null"))) {
        returnStr = defaultTheme;
      }
      if (returnStr.equals("GreyTheme")) {
        returnStr = "DefaultTheme";
      }
      sysUser.setTheme(returnStr);
      getUserDistrictRoleBySQL(user.getCuid());
    }
    catch (Exception ex) {
      LogHome.getLog().error(ex.getMessage());
      throw new UserException(ex.getMessage());
    }
    try
    {
      sysUser.setAttrValue("isPasswordAvilable", isPasswordAvilable(actionContext, user));
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }

    Map param = new HashMap();
    param.put("OpType", "Login");
    param.put("AppModule", "登录系统");
    param.put("OpText", "登录系统");
    addAuditOptionLog(actionContext, param);
    return sysUser;
  }

  public SysUser loginNoLog(BoActionContext actionContext, String userName, String password) throws UserException {
    SysUser user = null;
    try {
      user = getSecurityDAO().getUser(userName);
      if (user == null)
        throw new UserException("用户不存在 ！");
      if (!isPasswordIdentical(user.getUserPassword(), password)) {
        String dePassword = SecurityHelper.getInstance().getDecrypt(password);
        if (dePassword == null) {
          password = SecurityHelper.getInstance().getEncrypt(password);
          if (!isPasswordIdentical(user.getUserPassword(), password))
            throw new UserException("用户密码不正确 ！");
        }
        else {
          throw new UserException("用户密码不正确 ！");
        }
      } else { if (user.getIsLocked())
          throw new UserException("用户处于锁定状态 ！");
        if (user.getAccountDate() != null) {
          Date date = new Date();
          if ((user.getAccountDate().getTime() < date.getTime()) && 
            (!user.getIsLocked())) {
            user.setIsLocked(true);
            getSecurityDAO().modifySysUser(actionContext, user);
            throw new UserException("用户过期已锁定 ！");
          }
        }
      }

      user = getSecurityDAO().getSysUser(actionContext, user.getObjectNum());
      getUserDistrictRoleBySQL(user.getCuid());
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }

    try
    {
      user.setAttrValue("isPasswordAvilable", isPasswordAvilable(actionContext, user));
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }

    return user;
  }

  public void addLoginLog(BoActionContext actionContext) throws UserException
  {
    try {
      LoginLog dbo = new LoginLog();
      dbo.setUserName(actionContext.getUserName());
      dbo.setCuid();
      dbo.setIpAddress(actionContext.getHostIP());
      dbo.setMachineName(actionContext.getHostName());
      dbo.setLoginType(Long.valueOf(0L).longValue());
      dbo.setLoginTime(new Timestamp(System.currentTimeMillis()));
      getSecurityDAO().insertDbo(actionContext, dbo);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public String addLoginLogHaveSystemName(BoActionContext actionContext, String systemName) throws UserException
  {
    try
    {
      LoginLog dbo = new LoginLog();
      dbo.setUserName(actionContext.getUserName());
      dbo.setCuid();
      dbo.setIpAddress(actionContext.getHostIP());
      dbo.setMachineName(actionContext.getHostName());
      dbo.setLoginTime(new Timestamp(System.currentTimeMillis()));
      dbo.setLoginSystemName(systemName);
      dbo.setLoginType(Long.valueOf(0L).longValue());
      getSecurityDAO().insertDbo(actionContext, dbo);
      return dbo.getCuid();
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void addLogoutLogHaveSystemName(BoActionContext actionContext, String logCuid) throws UserException {
    try {
      Timestamp nowTime = new Timestamp(System.currentTimeMillis());
      String now_time = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), nowTime);
      String sql = " update LOGIN_LOG set LOGOUT_TIME = " + now_time + "  where " + "CUID" + " = '" + logCuid + "'";

      getSecurityDAO().execSql(actionContext, sql);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public int getLoginUserCount(BoActionContext actionContext) throws UserException {
    int loginUser = ((Integer)this.userOnLine.get("loginUser")).intValue() < 0 ? 1 : ((Integer)this.userOnLine.get("loginUser")).intValue();
    return loginUser;
  }

  public void addLoginUserCount(BoActionContext actionContext, String userId) throws UserException {
    String value = "";
    int num = ((Integer)this.userOnLine.get("loginUser")).intValue();

    num += 1;

    this.userOnLine.put("loginUser", Integer.valueOf(num));
  }

  public void removeLoginUserCount(BoActionContext actionContext, String userId) throws UserException
  {
    int num = ((Integer)this.userOnLine.get("loginUser")).intValue();

    num -= 1;

    this.userOnLine.put("loginUser", Integer.valueOf(num));
  }

  public void removeAllLoginUserCount(BoActionContext actionContext) throws UserException {
    int num = 0;

    this.userOnLine.put("loginUser", Integer.valueOf(num));
  }

  public void addLogoutLog(BoActionContext actionContext) throws UserException
  {
    try {
      LoginLog dbo = new LoginLog();
      dbo.setUserName(actionContext.getUserName());
      dbo.setCuid();
      dbo.setIpAddress(actionContext.getHostIP());
      dbo.setMachineName(actionContext.getHostName());
      dbo.setLoginType(Long.valueOf(1L).longValue());
      dbo.setLoginTime(new Timestamp(System.currentTimeMillis()));

      Map param = new HashMap();
      param.put("OpType", "Logout");
      param.put("AppModule", "登出系统");
      param.put("OpText", "登出系统");
      addAuditOptionLog(actionContext, param);
    }
    catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  private boolean isPasswordIdentical(String pwd1, String pwd2)
  {
    boolean isEqual = false;
    if (pwd1 != null)
      isEqual = pwd1.equals(pwd2);
    else if (pwd1 == pwd2) {
      isEqual = true;
    }
    return isEqual;
  }

  public boolean isPasswordAvilable(BoActionContext boActionContext, SysUser user) throws Exception {
    boolean avilable = true;
    if (!user.getCuid().equals("SYS_USER-0"))
    {
      Timestamp time = user.getLastPasswordTime() == null ? new Timestamp(user.getLastModifyTime().getTime()) : user.getLastPasswordTime();
      avilable = !SecurityHelper.isBefor(time, getPasswordAvilableTime(new BoActionContext(), user));
    }
    return avilable;
  }

  private static List<String> getActionNames(String actionNames) {
    List actionNameList = new ArrayList();
    if ((actionNames == null) || (actionNames.trim().length() == 0)) {
      return new ArrayList();
    }
    String[] _actionNames = actionNames.split(",");
    for (int i = 0; i < _actionNames.length; i++) {
      List decomposeActionNames = ActionHelper.decomposeActionName(_actionNames[i]);
      for (int j = 0; j < decomposeActionNames.size(); j++) {
        actionNameList.add(decomposeActionNames.get(j));
      }
    }
    return actionNameList;
  }

  public List<String> getUserActions(BoActionContext boActionContext, SysUser user) throws UserException {
    List actions = new ArrayList();
    try {
      checkUserLogin(user.getCuid());
      if (!isAdminUser(user.getCuid())) {
        Map userDistrictRole = getUserDistrictRoleBySQL(user.getCuid());
        String[] roleCuids = new String[userDistrictRole.size()];
        userDistrictRole.keySet().toArray(roleCuids);
        for (int i = 0; i < roleCuids.length; i++) {
          List roleActions = (List)this.roleFunctions.get(roleCuids[i]);
          for (int k = 0; (roleActions != null) && (k < roleActions.size()); k++) {
            String roleAction = (String)roleActions.get(k);
            if (!actions.contains(roleAction))
              actions.add(roleAction);
          }
        }
      }
    }
    catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
    actions.addAll(this.commonActionNames);
    return actions;
  }

  private ConcurrentHashMap<String, DataObjectList> getUserDistrictRoleBySQL(String userCuid)
    throws Exception
  {
    ConcurrentHashMap userDistrictRole = (ConcurrentHashMap)this.userDistrictRoles.get(userCuid);
    if ((userDistrictRole == null) || (userDistrictRole.size() == 0)) {
      userDistrictRole = new ConcurrentHashMap();

      DataObjectList dbos = getSecurityDAO().getUserHaveRoleByUserCuid(userCuid);
      for (int i = 0; i < dbos.size(); i++) {
        DataObjectList funcdbos = new DataObjectList();
        UserHaveRole userHaveRole = (UserHaveRole)dbos.get(i);
        District district = getDistrictDAO().getDistrictByCuid(null, userHaveRole.getDistrictCuid());
        funcdbos.add(district);
        if (userHaveRole.getIsIncludeSubDistrict()) {
          DataObjectList districtdbos = getDistrictBO().getAllChildDistrict(new BoActionContext(), district);
          if (districtdbos != null) {
            for (int j = 0; j < districtdbos.size(); j++) {
              funcdbos.add(districtdbos.get(j));
            }
          }
        }
        DataObjectList districts = (DataObjectList)userDistrictRole.get(userHaveRole.getRoleCuid());
        if (districts == null) {
          districts = new DataObjectList();
          userDistrictRole.put(userHaveRole.getRoleCuid(), districts);
        }
        districts.addAll(funcdbos);
      }
      this.userDistrictRoles.put(userCuid, userDistrictRole, true);
    }
    return userDistrictRole;
  }

  public DataObjectList getUserDistricts(BoActionContext boActionContext, String userId) throws UserException
  {
    DataObjectList districts = new DataObjectList();
    try {
      checkUserLogin(userId);
      if (isAdminUser(userId)) {
        return getAllDistricts();
      }
      ArrayList distCuids = new ArrayList();

      Map isIncludeSubDistricts = new HashMap();

      String sql = "USER_CUID='" + userId + "'";
      DataObjectList dbos = getSecurityDAO().getObjectsBySql(sql, new UserHaveRole(), 0);
      if (dbos.size() > 0) {
        for (int i = 0; i < dbos.size(); i++) {
          UserHaveRole tmpdbo = (UserHaveRole)dbos.get(i);
          if (tmpdbo.getIsIncludeSubDistrict()) {
            isIncludeSubDistricts.put(tmpdbo.getDistrictCuid(), tmpdbo);
          }
        }
      }
      Map userDistrictRole = getUserDistrictRoleBySQL(userId);
      Object[] keys = userDistrictRole.keySet().toArray();
      for (int i = 0; i < keys.length; i++) {
        DataObjectList _districts = (DataObjectList)userDistrictRole.get(keys[i]);
        for (int j = 0; j < _districts.size(); j++) {
          GenericDO district = (GenericDO)_districts.get(j);
          if (!distCuids.contains(district.getCuid())) {
            distCuids.add(district.getCuid());
            if (isIncludeSubDistricts.get(district.getCuid()) != null)
              district.setAttrValue("IS_INCLUDE_SUB_DISTRICT", true);
            else {
              district.setAttrValue("IS_INCLUDE_SUB_DISTRICT", false);
            }
            districts.add(district);
          }
        }
      }
    } catch (Exception ex) {
      new UserException(ex);
    }
    return districts;
  }

  public List<String> getDistrictActions(BoActionContext boActionContext, String userId, String districtCuid) {
    List actions = new ArrayList();
    try {
      checkUserLogin(userId);
      if (isAdminUser(userId)) {
        return null;
      }

      Map userDistrictRole = getUserDistrictRoleBySQL(userId);

      Object[] keys = userDistrictRole.keySet().toArray();
      for (int i = 0; i < keys.length; i++) {
        DataObjectList districts = (DataObjectList)userDistrictRole.get(keys[i]);
        List cuids = districts.getCuidList();
        if (cuids.contains(districtCuid)) {
          List roleActionNames = (List)this.roleFunctions.get(keys[i].toString());
          for (int j = 0; (roleActionNames != null) && (j < roleActionNames.size()); j++) {
            if (!actions.contains(roleActionNames.get(j))) {
              actions.add(roleActionNames.get(j));
            }
          }
        }
      }
      actions.addAll(this.commonActionNames);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
    return actions;
  }

  private List<String> getActionRoleCuids(String actionName) {
    List roleCuidList = new ArrayList();
    String[] roleCuids = new String[this.roleFunctions.size()];
    this.roleFunctions.keySet().toArray(roleCuids);
    for (int i = 0; i < roleCuids.length; i++) {
      if (((ArrayList)this.roleFunctions.get(roleCuids[i])).contains(actionName)) {
        roleCuidList.add(roleCuids[i]);
      }
    }
    return roleCuidList;
  }

  public DataObjectList getActionDistricts(IBoActionContext boActionContext, String userId, String actionName) throws UserException {
    DataObjectList districts = new DataObjectList();
    try {
      checkUserLogin(userId);
      if (isAdminUser(userId)) {
        return getAllDistricts();
      }

      Map userDistrictRole = getUserDistrictRoleBySQL(userId);
      List roleCuids = getActionRoleCuids(actionName);
      for (int i = 0; i < roleCuids.size(); i++) {
        DataObjectList roleDistricts = (DataObjectList)userDistrictRole.get(roleCuids.get(i));
        if (roleDistricts != null) {
          for (int j = 0; j < roleDistricts.size(); j++) {
            GenericDO roleDistrict = (GenericDO)roleDistricts.get(j);
            if (!districts.getCuidList().contains(roleDistrict.getCuid())) {
              districts.add(roleDistrict);
            }
          }
        }
      }
      if ((districts == null) || (districts.size() == 0)) {
        actionName = ActionHelper.getGenericActionName(actionName);
        roleCuids = getActionRoleCuids(actionName);
        for (int i = 0; i < roleCuids.size(); i++) {
          DataObjectList roleDistricts = (DataObjectList)userDistrictRole.get(roleCuids.get(i));
          if (roleDistricts != null) {
            for (int j = 0; j < roleDistricts.size(); j++) {
              GenericDO roleDistrict = (GenericDO)roleDistricts.get(j);
              if (!districts.getCuidList().contains(roleDistrict.getCuid()))
                districts.add(roleDistrict);
            }
          }
        }
      }
    }
    catch (Exception ex)
    {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
    return districts;
  }

  private DataObjectList getAllDistricts() throws UserException {
    DataObjectList districts = null;
    try {
      districts = getSecurityDAO().getAllObjByClass(new District(), 1);
    }
    catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
    return districts;
  }

  private boolean isCommonAction(String actionName) {
    if ((actionName == null) || (actionName.trim().length() == 0)) {
      return true;
    }
    actionName = ActionHelper.getGenericActionName(actionName);
    return this.commonActionNames.contains(actionName);
  }

  public void isDistrictsPermitted(IBoActionContext boActionContext, String userId, String actionName, String[] districtCuids) throws UserException {
    try {
      if ((isAdminUser(userId)) || (isCommonAction(actionName))) {
        return;
      }
      checkUserLogin(userId);

      DataObjectList districts = getActionDistricts(boActionContext, userId, actionName);

      boolean isValid = true;
      if (districts != null) {
        List cuids = districts.getCuidList();
        for (int i = 0; i < districtCuids.length; i++)
          if (!cuids.contains(districtCuids[i])) {
            isValid = false;
            break;
          }
      }
      else {
        isValid = false;
      }

      if (!isValid)
        throw new UserSecurityException();
    }
    catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getBackupEquipRole(BoActionContext boActionContext, String userId) throws UserException {
    try {
      return getSecurityDAO().getBackupEquipRole(boActionContext, userId);
    }
    catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public boolean isActionValid(String userId, String actionName) throws UserException {
    boolean isPermitted = false;
    try
    {
      isUserLocked(userId);

      if ((isAdminUser(userId)) || (isCommonAction(actionName))) {
        return true;
      }
      checkUserLogin(userId);
      Map userDistrictRole = getUserDistrictRoleBySQL(userId);
      String[] roleCuids = new String[userDistrictRole.size()];
      userDistrictRole.keySet().toArray(roleCuids);
      for (int i = 0; i < roleCuids.length; i++) {
        List actions = (List)this.roleFunctions.get(roleCuids[i]);
        if ((actions != null) && (actions.contains(actionName))) {
          isPermitted = true;
          break;
        }
      }
      if (!isPermitted) {
        actionName = ActionHelper.getGenericActionName(actionName);
        for (int i = 0; i < roleCuids.length; i++) {
          List actions = (List)this.roleFunctions.get(roleCuids[i]);
          if ((actions != null) && (actions.contains(actionName))) {
            isPermitted = true;
            break;
          }
        }
      }
      if (!isPermitted) {
        LogHome.getLog().info("用户[userId=" + userId + "]没有操作[actionName=" + actionName + "]的权限 !");
        throw new UserSecurityException();
      }
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
    return true;
  }

  private void checkUserLogin(String userId) throws Exception {
    Map actionDistricts = getUserDistrictRoleBySQL(userId);
    if ((!isAdminUser(userId)) && (actionDistricts == null))
      throw new UserException("用户未登录[userId=" + userId + "]");
  }

  public static boolean isAdminUser(String userId)
  {
    return (userId == null) || ("SYS_USER-0".equals(userId));
  }

  public void deleteOrganizationByCuids(BoActionContext boActionContext, String cuids)
    throws Exception
  {
    String[] cuidarray = cuids.split(",");
    List objectIds = new ArrayList();
    UserTransaction trx = TransactionFactory.getInstance().createTransaction();
    try {
      trx.begin();
      for (int i = 0; i < cuidarray.length; i++) {
        Organization dbo = getSecurityDAO().getOrganizationByCuid(boActionContext, cuidarray[i]);
        if (dbo.getRelatedOrgCuid().equals("0")) {
          throw new UserException("根用户组" + dbo.getOrgName() + "不能删除！");
        }
        DataObjectList orgs = getSecurityDAO().getAllChildOrganization(boActionContext, Long.valueOf(dbo.getObjectNum()));
        if (orgs.size() > 0) {
          throw new UserException("用户组" + dbo.getOrgName() + "下包含子用户组不能删除！");
        }
        Organization rootorg = getSecurityDAO().getRootOrganization();
        String sql = "RELATED_ORGANIZATION_CUID='" + dbo.getCuid() + "'";
        DataObjectList users = getSecurityDAO().getSysUserBySql(sql);
        if (users.size() > 0)
        {
          for (int j = 0; j < users.size(); j++) {
            SysUser user = (SysUser)users.get(j);
            user.setRelatedOrganizationCuid(rootorg.getCuid());
            getSecurityDAO().modifySysUser(boActionContext, user);
          }
        }
        objectIds.add(Long.valueOf(dbo.getObjectNum()));
      }
      for (int i = 0; i < objectIds.size(); i++) {
        getSecurityDAO().delOrganization(boActionContext, (Long)objectIds.get(i));
      }

      Map param = new HashMap();
      param.put("OpType", "DelPrivilege");
      param.put("AppModule", "用户组管理");
      param.put("OpText", "删除用户组信息");
      addAuditOptionLog(boActionContext, param);

      trx.commit();
    } catch (Exception ex) {
      trx.rollback();
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void hasAttempSheet(SysUser user) throws Exception
  {
    String sql = "RELATED_USER_CUID='" + user.getCuid() + "' AND " + "IS_FINISHED" + "=0";
    DataObjectList dboshandler = getSecurityDAO().getObjectsBySql(sql, new AttempHandler(), 1);
    if (dboshandler.size() > 0) {
      throw new UserException("用户下有未归档的调单，无法删除或者修改所属用户组!");
    }

    sql = "RELATED_CREATER_CUID='" + user.getCuid() + "' AND " + "STATE" + "!=10";
    DataObjectList dbosattemp = getSecurityDAO().getObjectsBySql(sql, new AttempSheet(), 1);
    if (dbosattemp.size() > 0) {
      throw new UserException("用户下有未归档的调单，无法删除或者修改所属用户组!");
    }

    sql = "RELATED_CREATER_CUID='" + user.getCuid() + "' AND (" + "STATE" + "!=10 AND " + "STATE" + " !=10)";
    DataObjectList dbosapply = getSecurityDAO().getObjectsBySql(sql, new ApplySheet(), 1);
    if (dbosapply.size() > 0) {
      throw new UserException("用户下有未归档的调单，无法删除或者修改所属用户组!");
    }

    sql = "RELATED_CREATER_CUID='" + user.getCuid() + "' AND " + "STATE" + "!=10";
    DataObjectList dbosreply = getSecurityDAO().getObjectsBySql(sql, new ReplySheet(), 1);
    if (dbosreply.size() > 0) {
      throw new UserException("用户下有未归档的调单，无法删除或者修改！");
    }

    sql = "RELATED_USER_CUID='" + user.getCuid() + "' OR " + "RELATED_CREATE_USER_CUID" + "='" + user.getCuid() + "'";
    DataObjectList list = getSecurityDAO().getObjectsBySql(sql, new ProActUserList(), 1);
    if (dbosreply.size() > 0)
      throw new UserException("用户下有未归档的调单，无法删除或者修改！");
  }

  public void deleteSysUser(BoActionContext actionContext, Long objectId) throws UserException
  {
    try
    {
      SysUser user = new SysUser();
      user.setObjectNum(objectId.longValue());

      GenericDO tempDbo = getSecurityDAO().getObject(user);
      if (tempDbo != null) {
        user = (SysUser)tempDbo;
      }
      DataObjectList recordDbos = getRecordBySysUser(actionContext, user.getCuid());
      if (recordDbos.size() > 0) {
        throw new UserException("用户已有填报数据，无法删除!");
      }

      hasAttempSheet(user);

      getSecurityDAO().deleteUserManagerDistrict(actionContext, objectId);
      getSecurityDAO().delSysUser(actionContext, objectId);
      int num = ((Integer)this.userCounts.get("user")).intValue();
      this.userCounts.put("user", Integer.valueOf(num - 1));
      getSecurityDAO().delUserHaveRoleByUserCuid(actionContext, user.getCuid());
      getSecurityDAO().delUserHaveObjectByUserCuid(actionContext, user.getCuid());
      getSecurityDAO().delGmccAttempUserroleByUserCuid(actionContext, user.getCuid());
      if (user.getFlowUser()) {
        if (TnmsRuntime.getInstance().equals("START_WF_ENGINE_ID", Boolean.TRUE.toString()))
        {
          SharkUser sharkuser = new SharkUser();
          sharkuser.setUserName(user.getUserName());
          getWorkFlowBOX().delUser(actionContext, sharkuser);
        } else {
          LogHome.getLog().error("无法删除流程中用户，流程引擎没有启动！");
        }
      }

      getColumnConfigDAO().deleteColumnConfigByUser(actionContext, user.getCuid(), null);

      getSecurityObjectBO().deleteSysUser(user);

      this.userDistrictRoles.remove(user.getCuid());

      deleteHistoryUserPasswordByUserCuid(actionContext, user.getCuid());

      userLockState.remove(user.getCuid());

      Map param = new HashMap();
      param.put("OpType", "DelPrivilege");
      param.put("AppModule", "用户管理");
      param.put("OpText", "通过应用系统删除用户信息");
      addAuditOptionLog(actionContext, param);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void initUserDistrictRoles() throws Exception
  {
    this.userDistrictRoles.clear();
  }

  public void modifyOrganization(BoActionContext boActionContext, Organization dbo) throws Exception {
    Organization olddbo = getSecurityDAO().getOrganizationByName(dbo.getOrgName());
    if ((olddbo != null) && (!olddbo.getCuid().equals("")) && (!olddbo.getCuid().equals(dbo.getCuid()))) {
      throw new UserException("已经存在同名的用户组!");
    }
    getSecurityDAO().modifyOrganization(boActionContext, dbo);

    Map param = new HashMap();
    param.put("OpType", "UpdatePrivilege");
    param.put("AppModule", "用户组管理");
    param.put("OpText", "修改用户组信息");
    addAuditOptionLog(boActionContext, param);
  }

  public Organization getOrganization(BoActionContext boActionContext, Long objectId) throws Exception {
    return getSecurityDAO().getOrganization(boActionContext, objectId.longValue());
  }

  public DataObjectList getAllChildOrganization(BoActionContext boActionContext, Long objectId)
    throws Exception
  {
    return getSecurityDAO().getAllChildOrganization(boActionContext, objectId);
  }

  public SecurityDAO getSecurityDAO()
  {
    return (SecurityDAO)super.getDAO("SecurityDAO");
  }

  public IWorkFlowBOX getWorkFlowBOX() {
    if (TnmsRuntime.getInstance().equals("START_WF_ENGINE_ID", Boolean.TRUE.toString())) {
      return (IWorkFlowBOX)super.getBO("IWorkFlowBOX");
    }
    throw new UserException("流程引擎没有配置成启动！");
  }

  public ColumnConfigDAO getColumnConfigDAO()
  {
    return (ColumnConfigDAO)super.getDAO("ColumnConfigDAO");
  }

  public DistrictDAO getDistrictyDAO() {
    return (DistrictDAO)super.getDAO("DistrictDAO");
  }

  public DistrictDAO getDistrictDAO() {
    return (DistrictDAO)super.getDAO("DistrictDAO");
  }

  public Organization addOrganization(BoActionContext actionContext, Organization dbo) throws UserException
  {
    try {
      if (getSecurityDAO().getOrganizationByName(dbo.getOrgName()) != null) {
        throw new UserException("已经存在重名的机构!");
      }

      Map param = new HashMap();
      param.put("OpType", "AddPrivilege");
      param.put("AppModule", "用户组管理");
      param.put("OpText", "增加用户组信息");
      addAuditOptionLog(actionContext, param);
      return getSecurityDAO().addOrganization(actionContext, dbo);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public SysUser addSysUser(BoActionContext actionContext, SysUser dbo) throws UserException
  {
    try
    {
      if (getSecurityDAO().getSysUserByUserName(actionContext, dbo.getUserName()) != null) {
        throw new UserException("用户名已经存在 ！");
      }

      isPasswordValid(actionContext, dbo, SecurityHelper.getInstance().getDecrypt(dbo.getUserPassword()));

      String managerDistrictCuid = dbo.getManagerDistrictCuid();
      dbo.setManagerDistrictCuid("");
      dbo.setFlowUser(false);
      dbo.setLastPasswordTime(new Timestamp(System.currentTimeMillis()));
      SysUser newdbo = getSecurityDAO().addSysUser(actionContext, dbo);
      int num = ((Integer)this.userCounts.get("user")).intValue();
      this.userCounts.put("user", Integer.valueOf(num + 1));
      newdbo.setManagerDistrictCuid(managerDistrictCuid);
      getSecurityDAO().updateUserManagerDistrict(actionContext, newdbo);
      getSecurityObjectBO().refrenceSysUser(newdbo);

      HistoryUserPassword hisPW = new HistoryUserPassword();
      hisPW.setUserCuid(dbo.getCuid());
      hisPW.setUserPassword(dbo.getUserPassword());
      getSecurityDAO().addHistoryUserPassword(actionContext, hisPW);

      userLockState.put(dbo.getCuid(), Boolean.valueOf(dbo.getIsLocked()));
      if ((dbo.getAttrString("isSupportSingleSignon") != null) && (dbo.getAttrString("isSupportSingleSignon").equals("true"))) {
        Map param = new HashMap();
        param.put("appKey", dbo.getAttrString("APP_KEY"));
        param.put("userName", dbo.getUserName());
        param.put("userPassword", dbo.getUserPassword());
        param.put("optionType", "addUser");
      }

      Map param = new HashMap();
      param.put("OpType", "AddPrivilege");
      param.put("AppModule", "用户管理");
      param.put("OpText", "通过应用系统增加用户");
      addAuditOptionLog(actionContext, param);

      return newdbo;
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public UserPasswordSecurity addUserPasswordSecurity(BoActionContext actionContext, UserPasswordSecurity dbo)
    throws Exception
  {
    return getSecurityDAO().addUserPasswordSecurity(actionContext, dbo);
  }

  public DboCollection isSecurityUsed(BoQueryContext queryContext, String cuid)
    throws Exception
  {
    return getSecurityDAO().isSecurityUsed(queryContext, cuid);
  }

  public void deleteUserPasswordSecurity(BoActionContext boActionContext, String cuid)
    throws Exception
  {
    getSecurityDAO().delUserPasswordSecurity(boActionContext, cuid);
  }

  public UserPasswordSecurity getUserPasswordSecurity(BoActionContext boActionContext, String cuid)
    throws Exception
  {
    return getSecurityDAO().getUserPasswordSecurity(boActionContext, cuid);
  }

  public void modifyUserPasswordSecurity(BoActionContext actionContext, UserPasswordSecurity dbo)
    throws Exception
  {
    getSecurityDAO().modifyUserPasswordSecurity(actionContext, dbo);
  }

  public SysUser addCloneSysUser(BoActionContext actionContext, SysUser dbo) throws UserException
  {
    String oldSysUserCuid = dbo.getCuid();
    try
    {
      if (getSecurityDAO().getSysUserByUserName(actionContext, dbo.getUserName()) != null) {
        throw new UserException("用户名已经存在 ！");
      }

      isPasswordValid(actionContext, dbo, SecurityHelper.getInstance().getDecrypt(dbo.getUserPassword()));

      String managerDistrictCuid = dbo.getManagerDistrictCuid();
      dbo.setManagerDistrictCuid("");
      dbo.setCuid();
      dbo.setLastPasswordTime(new Timestamp(System.currentTimeMillis()));
      SysUser newuser = getSecurityDAO().addSysUser(actionContext, dbo);
      int num = ((Integer)this.userCounts.get("user")).intValue();
      this.userCounts.put("user", Integer.valueOf(num + 1));
      addHistoryUserPassword(actionContext, dbo);
      newuser.setManagerDistrictCuid(managerDistrictCuid);
      getSecurityDAO().updateUserManagerDistrict(actionContext, newuser);
      ArrayList l = new ArrayList();
      l.add(newuser.getCuid());
      copyUserRight(actionContext, oldSysUserCuid, l);

      if (dbo.getFlowUser()) {
        SharkUser sharkuser = new SharkUser();
        sharkuser.setEmail(newuser.getRelatedOrganizationCuid());
        sharkuser.setRealName(newuser.getTrueName());
        sharkuser.setUserName(newuser.getUserName());
        sharkuser.setCuid(newuser.getCuid());
        try
        {
          getWorkFlowBOX().addUser(actionContext, sharkuser);
        } catch (Exception ex) {
          LogHome.getLog().error(ex.getMessage());
        }
        DboCollection urs = getSecurityDAO().getUserWorkFlowRole(oldSysUserCuid);
        String roleCuids = "";
        for (int i = 0; i < urs.size(); i++) {
          UserRole ur = (UserRole)urs.getAttrField("USER_ROLE", i);
          if (i == 0)
            roleCuids = ur.getCuid();
          else {
            roleCuids = roleCuids + "," + ur.getCuid();
          }
        }
        List paraList = parseRoleParameter(roleCuids);
        try {
          for (int k = 0; k < paraList.size(); k++)
          {
            getWorkFlowBOX().addUserRoleMap(actionContext, newuser.getUserName(), ((String[])paraList.get(k))[2], ((String[])paraList.get(k))[0], ((String[])paraList.get(k))[1]);
          }
        } catch (Exception ex) {
          LogHome.getLog().error(ex.getMessage());
        }
      }
      getSecurityObjectBO().refrenceSysUser(newuser);
      userLockState.put(dbo.getCuid(), Boolean.valueOf(dbo.getIsLocked()));
      return newuser;
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void modifySysUserByNetAdjust(BoActionContext actionContext, SysUser dbo)
    throws UserException
  {
    try
    {
      getSecurityDAO().updateObject(actionContext, dbo);
    } catch (Exception e) {
      throw new UserException(e.getMessage());
    }
  }

  public void modifySysUser(BoActionContext actionContext, SysUser dbo) throws UserException {
    try {
      SysUser tmpdbo = getSecurityDAO().getSysUserByUserName(actionContext, dbo.getUserName());
      boolean flag = false;
      if ((tmpdbo != null) && (!tmpdbo.getCuid().equals(dbo.getCuid()))) {
        throw new UserException("用户名已经存在 ！");
      }

      boolean ischangegroup = false;
      if ((tmpdbo.getRelatedOrganizationCuid() != null) && (tmpdbo.getRelatedOrganizationCuid().trim().length() > 0)) {
        if ((dbo.getRelatedOrganizationCuid() == null) || (dbo.getRelatedOrganizationCuid().trim().length() == 0)) {
          ischangegroup = true;
        }
        else if (!dbo.getRelatedOrganizationCuid().equals(tmpdbo.getRelatedOrganizationCuid())) {
          ischangegroup = true;
        }
      }

      if (ischangegroup) {
        hasAttempSheet(dbo);
      }
      isPasswordValid(actionContext, dbo, SecurityHelper.getInstance().getDecrypt(dbo.getUserPassword()));
      String alldistrict = dbo.getRelatedDistrictCuid() + "," + dbo.getManagerDistrictCuid();
      String[] districts = alldistrict.split(",");
      UserTransaction trx = TransactionFactory.getInstance().createTransaction();
      try {
        trx.begin();

        SysUser oldUser = getSecurityDAO().getSysUser(actionContext, dbo.getObjectNum());
        if (!oldUser.getUserPassword().equals(dbo.getUserPassword())) {
          addHistoryUserPassword(actionContext, dbo);
          dbo.setLastPasswordTime(new Timestamp(System.currentTimeMillis()));
          flag = true;
        }

        boolean districtHasModify = false;
        if (oldUser.getRelatedDistrictCuid().equals(dbo.getRelatedDistrictCuid())) {
          if ((dbo.getManagerDistrictCuid() != null) && (dbo.getManagerDistrictCuid().trim().length() > 0) && (oldUser.getManagerDistrictCuid() != null) && (oldUser.getManagerDistrictCuid().trim().length() > 0))
          {
            String[] tempstr = dbo.getManagerDistrictCuid().split(",");
            Map dismap = new HashMap();
            for (int i = 0; i < tempstr.length; i++) {
              dismap.put(tempstr[i], tempstr[i]);
            }
            DataObjectList dbosdis = getSecurityDAO().getUserManageDistrict(new BoActionContext(), dbo.getCuid());
            Map olddismap = new HashMap();
            for (int i = 0; i < dbosdis.size(); i++) {
              GenericDO dis = (GenericDO)dbosdis.get(i);
              olddismap.put(dis.getAttrString("2"), dis.getAttrString("2"));
            }
            if (olddismap.size() != dismap.size()) {
              districtHasModify = true;
            } else {
              Iterator iterator = olddismap.keySet().iterator();
              while (iterator.hasNext()) {
                String disCuid = (String)iterator.next();
                if (!dismap.containsKey(disCuid))
                  districtHasModify = true;
              }
            }
          }
          else if (((dbo.getManagerDistrictCuid() == null) || (dbo.getManagerDistrictCuid().trim().length() == 0)) && (oldUser.getManagerDistrictCuid() != null) && (oldUser.getManagerDistrictCuid().trim().length() > 0))
          {
            districtHasModify = true;
          } else if (((oldUser.getManagerDistrictCuid() == null) || (oldUser.getManagerDistrictCuid().trim().length() == 0)) && (dbo.getManagerDistrictCuid() != null) && (dbo.getManagerDistrictCuid().trim().length() > 0))
          {
            districtHasModify = true;
          }
        }
        else districtHasModify = true;

        if ((dbo.getAttrString("isSupportSingleSignon") != null) && (dbo.getAttrString("isSupportSingleSignon").equals("true")) && 
          (flag)) {
          LogHome.getLog().info("------------------------------是否调用了此方法--------------------------------------");
          Map param = new HashMap();
          param.put("appKey", dbo.getAttrString("APP_KEY"));
          param.put("userName", dbo.getUserName());
          param.put("userPassword", SecurityHelper.getInstance().getDecrypt(dbo.getUserPassword()));
          param.put("optionType", "modifyUser");
        }

        getSecurityDAO().deleteUserHaveRole(actionContext, dbo.getCuid(), districts);
        getSecurityDAO().updateUserManagerDistrict(actionContext, dbo);
        dbo.setManagerDistrictCuid("");
        dbo.setActivityIds(oldUser.getActivityIds());
        getSecurityDAO().modifySysUser(actionContext, dbo);

        if (districtHasModify) {
          GenericMessage message = new GenericMessage("T_AM_DEV_CHG", dbo);
          message.setTargetId("UserChange");
          message.setAttachData(Long.valueOf(2L));
          MsgBusManager.getInstance().sendMessage(message);
        }

        userLockState.put(dbo.getCuid(), Boolean.valueOf(dbo.getIsLocked()));

        getSecurityObjectBO().refrenceSysUser(dbo);

        this.userDistrictRoles.remove(dbo.getCuid());

        Map param = new HashMap();
        param.put("OpType", "UpdatePrivilege");
        param.put("AppModule", "修改用户");
        param.put("OpText", "通过应用系统修改用户信息");
        addAuditOptionLog(actionContext, param);

        trx.commit();
      } catch (Exception ex) {
        trx.rollback();
        throw new UserException(ex.getMessage());
      }
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public List getAllOrganizationByDistrict(BoActionContext actionContext, District district)
    throws UserException
  {
    try
    {
      List orgs = new ArrayList();
      DataObjectList objs = null;
      objs = getSecurityDAO().getAllOrganizationByDistrict(actionContext, district);
      for (int i = 0; i < objs.size(); i++) {
        orgs.add((Organization)objs.get(i));
      }
      return orgs;
    } catch (Throwable ex) {
      LogHome.getLog().error("根据区域得到所有机构列表信息失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  private IDistrictBO getDistrictBO()
  {
    return (IDistrictBO)super.getBO("IDistrictBO");
  }

  public DataObjectList getAllOrgsByUserDisCuid(BoActionContext actionContext, String userDistrictCuid) throws UserException
  {
    try
    {
      District district = getDistrictBO().getDistrictByCuid(actionContext, userDistrictCuid);
      DataObjectList dbos = getDistrictBO().getAllChildDistrict(actionContext, district);
      dbos.add(district);
      DataObjectList allOrgs = new DataObjectList();
      String cuids = "";
      int idx = 0;
      for (int i = 0; i < dbos.size(); i++) {
        district = (District)dbos.get(i);
        if (cuids.equals(""))
          cuids = district.getCuid();
        else {
          cuids = cuids + "," + district.getCuid();
        }
        idx++;
        DataObjectList objs = null;
        if (idx == 50) {
          objs = getSecurityDAO().getAllOrganizationByDistricts(actionContext, cuids);
          allOrgs.addAll(objs);

          idx = 0;
          cuids = "";
        } else if (i == dbos.size() - 1) {
          objs = getSecurityDAO().getAllOrganizationByDistricts(actionContext, cuids);
          allOrgs.addAll(objs);
        }
      }
      return allOrgs;
    } catch (Exception ex) {
      LogHome.getLog().error("获得用户所属区域和下一级区域的机构列表失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public List getAllUpOrgsByUserOrgCuid(BoActionContext actionContext, String userOrgCuid)
    throws UserException
  {
    List orgList = new ArrayList();
    Organization org = null;
    try {
      org = getSecurityDAO().getOrganizationByCuid(actionContext, userOrgCuid);
      orgList.add(org);
      while (!"0".equals(org.getRelatedOrgCuid())) {
        org = getSecurityDAO().getOrganizationByCuid(actionContext, org.getRelatedOrgCuid());
        orgList.add(org);
      }
    } catch (Exception ex) {
      LogHome.getLog().error("获得用户所属区域和上级所有机构列表", ex);
      throw new UserException(ex.getMessage());
    }

    return orgList;
  }

  public DataObjectList getReceiverOrganization(BoActionContext boActionContext, String logUser, String roleId, String processType) throws UserException {
    try {
      return getSecurityDAO().getReceiverOrganization(boActionContext, logUser, roleId, processType, "dep");
    } catch (Exception ex) {
      LogHome.getLog().error("获得用户指定接收人构造树异常", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public Vector getReceiverUser(BoActionContext boActionContext, String logUser, String roleId, String processType) throws UserException {
    try {
      return getSecurityDAO().getReceiverUser(boActionContext, logUser, roleId, processType, "user");
    } catch (Exception ex) {
      LogHome.getLog().error("获得用户所属区域和下一级区域的机构列表失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getAllUserRole(BoActionContext actionContext)
    throws UserException
  {
    try
    {
      return getSecurityDAO().getAllUserRole(actionContext);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getUserRoleByRoleType(BoActionContext actionContext, String roletype)
    throws UserException
  {
    try
    {
      return getSecurityDAO().getUserRoleByRoleType(actionContext, roletype);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public UserRole getUserRole(BoActionContext actionContext, Long objectId)
    throws UserException
  {
    try
    {
      return getSecurityDAO().getUserRole(actionContext, objectId);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public UserRole getUserRoleByCuid(BoActionContext actionContext, String cuid) throws UserException
  {
    try {
      return getSecurityDAO().getUserRoleByCuid(actionContext, cuid);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getRoleFunPoint(BoActionContext actionContext, String roleCuid)
    throws UserException
  {
    try
    {
      return getSecurityDAO().getRoleFunPoint(actionContext, roleCuid);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getAllFunctionNode(BoActionContext actionContext)
    throws UserException
  {
    try
    {
      return getSecurityDAO().getAllFunctionNode(actionContext);
    }
    catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getAllFunctionNodeAndRolePoint(BoActionContext actionContext) throws UserException {
    try {
      DataObjectList dbos = getSecurityDAO().getAllFunctionNode(actionContext);
      DboCollection userRoledbos = getSecurityDAO().selectDBOs("SELECT * FROM USER_ROLE WHERE IS_USER_CREATE<>1 OR IS_USER_CREATE IS NULL", new GenericDO[] { new UserRole() });
      for (int i = 0; i < userRoledbos.size(); i++) {
        dbos.add(userRoledbos.getAttrField("USER_ROLE", i));
      }
      DboCollection rpdbos = getSecurityDAO().selectDBOs("SELECT DISTINCT ROLE_CUID,FUNCTION_NODE_CUID,CUID FROM ROLE_CONSIST_OF_FUN_POINT WHERE ROLE_CUID IN (SELECT CUID FROM USER_ROLE WHERE IS_USER_CREATE<>1 OR IS_USER_CREATE IS NULL)", new GenericDO[] { new RoleConsistOfFunPoint() });

      for (int i = 0; i < rpdbos.size(); i++) {
        dbos.add(rpdbos.getAttrField("ROLE_CONSIST_OF_FUN_POINT", i));
      }
      return dbos;
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public UserRole addRoleAndRoleFunPoint(BoActionContext actionContext, UserRole role, String[] funPoincuids)
    throws Exception
  {
    UserTransaction trx = TransactionFactory.getInstance().createTransaction();
    UserRole dbo = null;
    try {
      trx.begin();
      if (getSecurityDAO().getRoleByName(role.getRoleName()) != null) {
        throw new UserException("已经存在重名的角色!");
      }
      dbo = getSecurityDAO().addUserRole(actionContext, role);
      String roleCuid = dbo.getCuid();
      for (int i = 0; i < funPoincuids.length; i++) {
        RoleConsistOfFunPoint roleFunPoint = new RoleConsistOfFunPoint();
        roleFunPoint.setRoleCuid(roleCuid);
        roleFunPoint.setFunctionNodeCuid(funPoincuids[i]);
        getSecurityDAO().addRoleFunPoint(actionContext, roleFunPoint);
      }

      Map param = new HashMap();
      param.put("OpType", "AddPrivilege");
      param.put("AppModule", "角色和功能点管理");
      param.put("OpText", "增加角色和功能点");
      addAuditOptionLog(actionContext, param);

      trx.commit();
      addRoleActionNames(role.getCuid());
    } catch (Throwable ex) {
      trx.rollback();
      LogHome.getLog().error("添加角色和角色所拥有的功能点 ", ex);
      throw new UserException(ex.getMessage());
    }
    return dbo;
  }

  public void modifyRoleAndRoleFunPoint(BoActionContext actionContext, UserRole role, String[] funPoincuids)
    throws Exception
  {
    UserTransaction trx = TransactionFactory.getInstance().createTransaction();
    try {
      trx.begin();
      getSecurityDAO().modifyUserRole(actionContext, role);
      String roleCuid = role.getCuid();

      getSecurityDAO().delRoleFunPoint(actionContext, roleCuid);
      for (int i = 0; i < funPoincuids.length; i++) {
        RoleConsistOfFunPoint roleFunPoint = new RoleConsistOfFunPoint();
        roleFunPoint.setRoleCuid(roleCuid);
        roleFunPoint.setFunctionNodeCuid(funPoincuids[i]);
        getSecurityDAO().addRoleFunPoint(actionContext, roleFunPoint);
      }

      this.roleFunctions.remove(role.getCuid());
      addRoleActionNames(role.getCuid());

      Map param = new HashMap();
      param.put("OpType", "UpdatePrivilege");
      param.put("AppModule", "角色和功能点管理");
      param.put("OpText", "修改角色和功能点");
      addAuditOptionLog(actionContext, param);

      trx.commit();
    } catch (Throwable ex) {
      trx.rollback();
      LogHome.getLog().error("修改角色和角色所拥有的功能点 ", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void deleteRoleAndRoleFunPoint(BoActionContext actionContext, String roleCuid)
    throws Exception
  {
    if (!isRoleInUsed(roleCuid)) {
      UserTransaction trx = TransactionFactory.getInstance().createTransaction();
      trx.begin();
      try {
        getSecurityDAO().delRoleFunPoint(actionContext, roleCuid);
        getSecurityDAO().delUserRoleByCuid(actionContext, roleCuid);

        this.roleFunctions.remove(roleCuid);

        Map param = new HashMap();
        param.put("OpType", "DelPrivilege");
        param.put("AppModule", "删除用户角色和功能点");
        param.put("OpText", "删除用户角色和功能点");
        addAuditOptionLog(actionContext, param);

        trx.commit();
      } catch (Throwable ex) {
        trx.rollback();
        LogHome.getLog().error("删除角色和角色所拥有的功能点 ", ex);
        throw new UserException(ex.getMessage());
      }
    } else {
      LogHome.getLog().error("角色已被用户使用,不能删除!");
      throw new UserException("角色已被用户使用,不能删除!");
    }
  }

  private boolean isRoleInUsed(String roleCuid) throws Exception {
    return getSecurityDAO().isRoleInUsed(roleCuid);
  }

  public Organization getOrganizationByCuid(BoActionContext actionContext, String cuid)
    throws UserException
  {
    try
    {
      return getSecurityDAO().getOrganizationByCuid(actionContext, cuid);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public Boolean setIncludeSubDistrict(BoActionContext actionContext, String userCuid, String districtCuid) throws Exception {
    String sql = "USER_CUID='" + userCuid + "' and " + "DISTRICT_CUID" + "='" + districtCuid + "'";
    DataObjectList dbos = getSecurityDAO().getObjectsBySql(sql, new UserHaveRole(), 0);
    Boolean isIncludeSubDistrict = Boolean.valueOf(false);
    if (dbos.size() > 0) {
      for (int i = 0; i < dbos.size(); i++) {
        UserHaveRole dbo = (UserHaveRole)dbos.get(i);
        dbo.setIsIncludeSubDistrict(!dbo.getIsIncludeSubDistrict());
        getSecurityDAO().updateObject(actionContext, dbo);
        this.userDistrictRoles.remove(userCuid);
        isIncludeSubDistrict = Boolean.valueOf(dbo.getIsIncludeSubDistrict());
      }
    }

    Map param = new HashMap();
    param.put("OpType", "UpdatePrivilege");
    param.put("AppModule", "修改用户角色中的区域权限");
    param.put("OpText", "修改用户角色中的区域权限");
    addAuditOptionLog(actionContext, param);

    return isIncludeSubDistrict;
  }

  public void addUserHaveRole(BoActionContext actionContext, String userCuid, String districtCuid, String roleCuids) throws Exception
  {
    UserTransaction trx = TransactionFactory.getInstance().createTransaction();
    SysUser user = null;
    trx.begin();
    try {
      String[] roles = roleCuids.split(",");
      for (int i = 0; i < roles.length; i++) {
        UserHaveRole dbo = new UserHaveRole();
        dbo.setRoleCuid(roles[i]);
        dbo.setUserCuid(userCuid);
        dbo.setDistrictCuid(districtCuid);

        if (roles[i].trim().equals("BACKUPEQUIP-0001")) {
          String sql = "DISTRICT_CUID='DISTRICT-00001' and USER_CUID='" + userCuid + "' and " + "ROLE_CUID" + "='BACKUPEQUIP-0001'";

          DataObjectList dbos = getSecurityDAO().getObjectsBySql(sql, new UserHaveRole(), 0);
          if (dbos.size() == 0) {
            UserHaveRole tmpdbo = new UserHaveRole();
            tmpdbo.setRoleCuid("BACKUPEQUIP-0001");
            tmpdbo.setUserCuid(userCuid);
            tmpdbo.setDistrictCuid("DISTRICT-00001");
            getSecurityDAO().addUserHaveRole(actionContext, tmpdbo);
            continue;
          }
        }
        if (roles[i].trim().equals("BACKUPEQUIP-0002")) {
          String sql = "DISTRICT_CUID='DISTRICT-00001' and USER_CUID='" + userCuid + "' and " + "ROLE_CUID" + "='BACKUPEQUIP-0002'";

          DataObjectList dbos = getSecurityDAO().getObjectsBySql(sql, new UserHaveRole(), 0);
          if (dbos.size() == 0) {
            UserHaveRole tmpdbo = new UserHaveRole();
            tmpdbo.setRoleCuid("BACKUPEQUIP-0002");
            tmpdbo.setUserCuid(userCuid);
            tmpdbo.setDistrictCuid("DISTRICT-00001");
            getSecurityDAO().addUserHaveRole(actionContext, tmpdbo);
            continue;
          }
        }

        District dis = new District();
        dis.setCuid(districtCuid);
        if (getHaveSubDistrictRole(actionContext, userCuid, dis).booleanValue()) {
          dbo.setIsIncludeSubDistrict(true);
        }
        dbo = getSecurityDAO().addUserHaveRole(actionContext, dbo);
      }

      List paraList = parseRoleParameter(roleCuids);
      if (paraList.size() > 0) {
        if (user == null) {
          user = getSecurityDAO().getSysUserByCuid(actionContext, userCuid);
        }
        SharkUser sharkuser = new SharkUser();
        sharkuser.setEmail(user.getRelatedOrganizationCuid());
        sharkuser.setRealName(user.getTrueName());
        sharkuser.setUserName(user.getUserName());
        sharkuser.setCuid(user.getCuid());
        try
        {
          getWorkFlowBOX().addUser(actionContext, sharkuser);
          getWorkFlowBOX().addUserRoleMappings(actionContext, user.getUserName(), paraList);
        } catch (Throwable ex) {
          LogHome.getLog().error("", ex);
        }

        if (!user.getFlowUser()) {
          user.setFlowUser(true);

          getSecurityDAO().modifySysUser(actionContext, user);
        }
      }
      this.userDistrictRoles.remove(userCuid);

      Map param = new HashMap();
      param.put("OpType", "AddPrivilege");
      param.put("AppModule", "增加用户角色");
      param.put("OpText", "增加用户角色");
      addAuditOptionLog(actionContext, param);

      trx.commit();
    } catch (Throwable ex) {
      trx.rollback();
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void deleteUserHaveRole(BoActionContext actionContext, String userCuid, String districtCuid, String roleCuids)
    throws Exception
  {
    try
    {
      String sql = "";
      String wfDelSql = "";

      if (roleCuids.trim().length() == 0) {
        sql = "DISTRICT_CUID='" + districtCuid + "' and " + "USER_CUID" + "='" + userCuid + "'";
      } else {
        String[] roles = roleCuids.split(",");
        String roleCuidsSql = "";

        for (int i = 0; i < roles.length; i++) {
          if (roles[i].indexOf("WORKFLOW") >= 0) {
            wfDelSql = wfDelSql + "'" + roles[i] + "'";
          }
          if (i == 0)
            roleCuidsSql = "'" + roles[i] + "'";
          else {
            roleCuidsSql = roleCuidsSql + ",'" + roles[i] + "'";
          }
        }
        sql = "DISTRICT_CUID='" + districtCuid + "' and " + "USER_CUID" + "='" + userCuid + "' and " + "ROLE_CUID" + " in (" + roleCuidsSql + ")";
      }

      DataObjectList wfDeldbos = new DataObjectList();
      if (wfDelSql.length() > 0) {
        wfDelSql = "USER_CUID='" + userCuid + "' and " + "ROLE_CUID" + " in (" + wfDelSql.replaceAll("''", "','") + ")";

        wfDeldbos = getSecurityDAO().getObjectsBySql(wfDelSql, new UserHaveRole(), 0);
      }

      DataObjectList dbos = getSecurityDAO().getObjectsBySql(sql, new UserHaveRole(), 0);
      dbos.addAll(wfDeldbos);
      getSecurityDAO().deleteObjects(actionContext, dbos);

      if (roleCuids.indexOf("BACKUPEQUIP-0001") >= 0) {
        sql = "DISTRICT_CUID='DISTRICT-00001' and USER_CUID='" + userCuid + "' and " + "ROLE_CUID" + "='BACKUPEQUIP-0001'";

        dbos = getSecurityDAO().getObjectsBySql(sql, new UserHaveRole(), 0);
        getSecurityDAO().deleteObjects(actionContext, dbos);
      }
      if (roleCuids.indexOf("BACKUPEQUIP-0002") >= 0) {
        sql = "DISTRICT_CUID='DISTRICT-00001' and USER_CUID='" + userCuid + "' and " + "ROLE_CUID" + "='BACKUPEQUIP-0002'";

        dbos = getSecurityDAO().getObjectsBySql(sql, new UserHaveRole(), 0);
        getSecurityDAO().deleteObjects(actionContext, dbos);
      }

      SysUser user = getSecurityDAO().getSysUserByCuid(actionContext, userCuid);
      List paraList = parseRoleParameter(roleCuids);
      if (paraList.size() > 0) {
        try {
          for (int i = 0; i < paraList.size(); i++)
            getWorkFlowBOX().delUserRoleMap(actionContext, user.getUserName(), ((String[])paraList.get(i))[2], ((String[])paraList.get(i))[0], ((String[])paraList.get(i))[1]);
        }
        catch (Throwable ex) {
          LogHome.getLog().error("", ex);
        }

        String wfSql = "CUID in (select ur.CUID from USER_ROLE ur,USER_HAVE_ROLE uhr where uhr.ROLE_CUID=ur.CUID  and ur.CUID like 'WORKFLOW-%' and uhr.USER_CUID='" + userCuid + "') ";

        DataObjectList wfDbos = getSecurityDAO().getObjectsBySql(wfSql, new UserRole(), 1);
        if ((wfDbos == null) || (wfDbos.size() == 0)) {
          SysUser wfUser = getSecurityDAO().getSysUserByCuid(actionContext, userCuid);
          wfUser.setFlowUser(false);
          getSecurityDAO().updateObject(actionContext, wfUser);
        }
      }

      this.userDistrictRoles.remove(userCuid);

      Map param = new HashMap();
      param.put("OpType", "DelPrivilege");
      param.put("AppModule", "删除用户角色");
      param.put("OpText", "删除用户角色");
      addAuditOptionLog(actionContext, param);
    }
    catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void addUserHaveObject(BoActionContext actionContext, String objectCuids, String sysUserCuid, Long operationType, Boolean state) throws Exception {
    String[] cuids = new String[0];
    if (objectCuids.trim().length() > 0) {
      cuids = objectCuids.split(",");
    }
    DataObjectList dbos = new DataObjectList();
    for (int i = 0; i < cuids.length; i++) {
      UserHaveObject dbo = new UserHaveObject();
      String actionName = "";
      String actionCnName = "";
      dbo.setIsIncludeChild(true);
      if (cuids[i].length() > 0) {
        LogHome.getLog().info("权限对象CUID：" + cuids[i]);
        String className = cuids[i].split("-")[0];
        String objCuid = cuids[i];
        dbo.setRelatedObjectCuid(objCuid);
        if (className.equals("SITE"))
        {
          actionName = "ISiteBO";
          actionCnName = "站点管理";
          Site obj = new Site(className);
          obj.setCuid(objCuid);
          obj = (Site)getSecurityDAO().getObjByCuid(obj);
          if (obj != null) {
            String districtCuid = obj.getRelatedSpaceCuid();
            if ((districtCuid != null) && (districtCuid.trim().length() > 0))
              dbo.setRelatedDistrictCuid(districtCuid);
            else
              throw new UserException("对象" + obj + "的所属区域为空错误！");
          }
          else {
            throw new UserException("根据" + objCuid + "获取到一个空对象，失败！");
          }
        } else if (className.equals("ROOM"))
        {
          actionName = "IRoomBO";
          actionCnName = "机房管理";
          Room room = new Room(className);
          room.setCuid(objCuid);
          room = (Room)getSecurityDAO().getObjByCuid(room);
          if (room != null) {
            Site site = new Site(room.getRelatedSiteCuid());
            site = (Site)getSecurityDAO().getObjByCuid(site);
            if (site != null) {
              String districtCuid = site.getRelatedSpaceCuid();
              if ((districtCuid != null) && (districtCuid.trim().length() > 0))
                dbo.setRelatedDistrictCuid(districtCuid);
              else
                throw new UserException("站点对象" + site.getCuid() + "的所属区域为空错误！");
            }
            else {
              throw new UserException("根据" + room.getRelatedSiteCuid() + "获取到一个空站点对象，失败！");
            }
          } else {
            throw new UserException("根据" + objCuid + "获取到一个空机房对象，失败！");
          }
        } else if (className.equals("TRANS_ELEMENT"))
        {
          actionName = "ITransElementBO";
          actionCnName = "网元管理";
          TransElement obj = new TransElement(className);
          obj.setCuid(objCuid);
          obj = (TransElement)getSecurityDAO().getObjByCuid(obj);
          if (obj != null) {
            String districtCuid = obj.getRelatedDistrictCuid();
            if ((districtCuid != null) && (districtCuid.trim().length() > 0))
              dbo.setRelatedDistrictCuid(districtCuid);
            else
              throw new UserException("对象" + obj + "的所属区域为空错误！");
          }
          else {
            throw new UserException("根据" + objCuid + "获取到一个空对象，失败！");
          }
        } else if (className.equals("TRANS_SUB_NETWORK"))
        {
          actionName = "TransSubNetWorkBO";
          actionCnName = "子网管理";
          TransSubNetwork obj = new TransSubNetwork(className);
          obj.setCuid(objCuid);
          obj = (TransSubNetwork)getSecurityDAO().getObjByCuid(obj);
          if (obj != null) {
            String districtCuid = obj.getRelatedDistrictCuid();
            if ((districtCuid != null) && (districtCuid.trim().length() > 0))
              dbo.setRelatedDistrictCuid(districtCuid);
            else
              throw new UserException("对象" + obj + "的所属区域为空错误！");
          }
          else {
            throw new UserException("根据" + objCuid + "获取到一个空对象，失败！");
          }
        } else if ((className.equals("PDH_SYSTEM")) || (className.equals("SDH_SYSTEM")) || (className.equals("WDM_SYSTEM")))
        {
          actionName = "TransSystemBO";
          actionCnName = "传输系统管理";
          GenericDO obj = new GenericDO(className);
          obj.setCuid(objCuid);
          obj = getSecurityDAO().getObjByCuid(obj);
          if (obj != null) {
            String districtCuid = obj.getAttrString("RELATED_SPACE_CUID");
            if ((districtCuid != null) && (districtCuid.trim().length() > 0))
              dbo.setRelatedDistrictCuid(districtCuid);
            else
              throw new UserException("对象" + obj + "的所属区域为空错误！");
          }
          else {
            throw new UserException("根据" + objCuid + "获取到一个空对象，失败！");
          }
        } else if (className.equals("ODF"))
        {
          actionName = "IPhyOdfBO";
          actionCnName = "ODF管理";
          Odf obj = new Odf(className);
          obj.setCuid(objCuid);
          obj = (Odf)getSecurityDAO().getObjByCuid(obj);
          if (obj != null) {
            String roomCuid = obj.getRelatedRoomCuid();
            if ((roomCuid != null) && (roomCuid.trim().length() > 0)) {
              Room room = new Room(roomCuid);
              room = (Room)getSecurityDAO().getObjByCuid(room);
              if ((room != null) && (room.getRelatedSiteCuid() != null) && (room.getRelatedSiteCuid().trim().length() > 0)) {
                Site site = new Site(room.getRelatedSiteCuid());
                site = (Site)getSecurityDAO().getObjByCuid(site);
                if ((site != null) && (site.getRelatedSpaceCuid() != null))
                  dbo.setRelatedDistrictCuid(site.getRelatedSpaceCuid());
                else
                  throw new UserException("对象" + obj + "的所属站点为空错误！");
              }
              else {
                throw new UserException("对象" + obj + "的所属区域为空错误！");
              }
            } else {
              throw new UserException("对象" + obj + "的所属机房为空错误！");
            }
          } else {
            throw new UserException("根据" + objCuid + "获取到一个空对象，失败！");
          }
        } else if (className.equals("DDF"))
        {
          actionName = "IPhyDdfBO";
          actionCnName = "DDF管理";
          Ddf obj = new Ddf(className);
          obj.setCuid(objCuid);
          obj = (Ddf)getSecurityDAO().getObjByCuid(obj);
          if (obj != null) {
            String roomCuid = obj.getRelatedRoomCuid();
            if ((roomCuid != null) && (roomCuid.trim().length() > 0)) {
              Room room = new Room(roomCuid);
              room = (Room)getSecurityDAO().getObjByCuid(room);
              if ((room != null) && (room.getRelatedSiteCuid() != null) && (room.getRelatedSiteCuid().trim().length() > 0)) {
                Site site = new Site(room.getRelatedSiteCuid());
                site = (Site)getSecurityDAO().getObjByCuid(site);
                if ((site != null) && (site.getRelatedSpaceCuid() != null))
                  dbo.setRelatedDistrictCuid(site.getRelatedSpaceCuid());
                else
                  throw new UserException("对象" + obj + "的所属站点为空错误！");
              }
              else {
                throw new UserException("对象" + obj + "的所属区域为空错误！");
              }
            } else {
              throw new UserException("对象" + obj + "的所属机房为空错误！");
            }
          } else {
            throw new UserException("根据" + objCuid + "获取到一个空对象，失败！");
          }

        }

        dbo.setObjectClassname(className);
      } else {
        throw new UserException("传入的对象CUID不能为空");
      }
      dbo.setObjectOperation(operationType.longValue());
      dbo.setRelatedUserCuid(sysUserCuid);
      dbo.setIsInEx(state.booleanValue());

      if (getSecurityDAO().checkUserHaveActionNames(actionName, sysUserCuid).booleanValue())
        dbos.add(dbo);
      else {
        throw new UserException("请先分配‘" + actionCnName + "’区域权限！");
      }
    }
    UserTransaction trx = TransactionFactory.getInstance().createTransaction();
    try {
      trx.begin();
      getSecurityDAO().deleteUserHaveObject(actionContext, sysUserCuid);
      if (dbos.size() > 0) {
        getSecurityDAO().addUserHaveObject(actionContext, dbos);
      }

      getSecurityObjectDAO().cacheUserHaveObjects(sysUserCuid);
      trx.commit();
    } catch (Exception ex) {
      trx.rollback();
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getUserHaveObjects(BoActionContext actionContext, String userCuid) throws Exception {
    DataObjectList dbos = getSecurityDAO().getUserHaveObjects(actionContext, userCuid);
    dbos.sort("OBJECT_CLASSNAME", true);
    for (int i = 0; i < dbos.size(); i++) {
      UserHaveObject dbo = (UserHaveObject)dbos.get(i);
      String objCuid = dbo.getRelatedObjectCuid();
      if ((objCuid != null) && (objCuid.trim().length() > 0)) {
        GenericDO obj = new GenericDO(objCuid.split("-")[0]);
        obj.setCuid(objCuid);
        obj = getSecurityDAO().getObjByCuid(obj);
        if (obj != null) {
          String className = dbo.getRelatedObjectCuid().split("-")[0];
          if (className.equals("SITE"))
          {
            ((UserHaveObject)dbos.get(i)).setAttrValue("LABEL_CN", "[站点]" + obj.getAttrValue("LABEL_CN"));
          } else if (className.equals("ROOM"))
          {
            ((UserHaveObject)dbos.get(i)).setAttrValue("LABEL_CN", "[机房]" + obj.getAttrValue("LABEL_CN"));
          } else if (className.equals("TRANS_ELEMENT"))
          {
            ((UserHaveObject)dbos.get(i)).setAttrValue("LABEL_CN", "[网元]" + obj.getAttrValue("LABEL_CN"));
          } else if (className.equals("TRANS_SUB_NETWORK"))
          {
            ((UserHaveObject)dbos.get(i)).setAttrValue("LABEL_CN", "[子网]" + obj.getAttrValue("LABEL_CN"));
          } else if ((className.equals("PDH_SYSTEM")) || (className.equals("SDH_SYSTEM")) || (className.equals("WDM_SYSTEM")))
          {
            ((UserHaveObject)dbos.get(i)).setAttrValue("LABEL_CN", "[传输系统]" + obj.getAttrValue("LABEL_CN"));
          } else if (className.equals("ODF"))
          {
            ((UserHaveObject)dbos.get(i)).setAttrValue("LABEL_CN", "[ODF]" + obj.getAttrValue("LABEL_CN"));
          } else if (className.equals("DDF"))
          {
            ((UserHaveObject)dbos.get(i)).setAttrValue("LABEL_CN", "[DDF]" + obj.getAttrValue("LABEL_CN"));
          }
        }
      }
    }
    return dbos;
  }

  public Boolean getHaveSubDistrictRole(BoActionContext actionContext, String userCuid, District dbo) throws Exception {
    String sql = "USER_CUID='" + userCuid + "' and " + "DISTRICT_CUID" + "='" + dbo.getCuid() + "'";
    DataObjectList dbos = getSecurityDAO().getObjectsBySql(sql, new UserHaveRole(), 0);
    if (dbos.size() > 0) {
      for (int i = 0; i < dbos.size(); i++) {
        UserHaveRole tmpdbo = (UserHaveRole)dbos.get(i);
        if (tmpdbo.getIsIncludeSubDistrict()) {
          return Boolean.valueOf(true);
        }
      }
      return Boolean.valueOf(false);
    }
    return Boolean.valueOf(false);
  }

  public void deleteUserHaveRoleByUserCuidAndRoleCuid(BoActionContext actionContext, String userCuid, String roleCuid) throws Exception
  {
    try {
      UserHaveRole dbo = null;
      DataObjectList dbos = getSecurityDAO().getUserHaveRoleByuserCuidAndRoleCuid(actionContext, userCuid, roleCuid);
      for (int i = 0; i < dbos.size(); i++) {
        dbo = (UserHaveRole)dbos.get(i);
        getSecurityDAO().delUserHaveRole(actionContext, dbo);
        this.userDistrictRoles.remove(dbo.getUserCuid());
      }
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getUserHaveRole(BoActionContext actionContext, String userCuid, String districCuid) throws Exception {
    try {
      return getSecurityDAO().getUserHaveRole(actionContext, userCuid, districCuid);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getLog(BoQueryContext actionContext, String operatetype, String classname, String createtime, String lastmodifytime, String username, String ipaddress, String description)
    throws UserException
  {
    try
    {
      if (!createtime.equals("")) {
        createtime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(createtime));
      }
      if (!lastmodifytime.equals("")) {
        lastmodifytime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(lastmodifytime));
      }
      return getSecurityDAO().getLog(actionContext, operatetype, classname, createtime, lastmodifytime, username, ipaddress, description);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void deleteLog(BoActionContext actionContext, String objectids)
    throws UserException
  {
    try
    {
      String[] objectIds = objectids.split(",");
      for (int i = 0; i < objectIds.length; i++)
        getSecurityDAO().deleteLog(actionContext, objectIds[i]);
    }
    catch (Exception ex) {
      LogHome.getLog().error("删除失败" + ex.getMessage());
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getLogs(BoActionContext actionContext, String operatetype, String classname, String createtime, String lastmodifytime, String username, String ipaddress, String description, String orgCuid)
    throws UserException
  {
    try
    {
      if (!createtime.equals("")) {
        createtime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(createtime));
      }
      if (!lastmodifytime.equals("")) {
        lastmodifytime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(lastmodifytime));
      }
      return getSecurityDAO().getLogs(actionContext, operatetype, classname, createtime, lastmodifytime, username, ipaddress, description, orgCuid);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getLoginLog(BoQueryContext actionContext, Long loginType, String startTime, String endTime, String userName)
    throws Exception
  {
    try
    {
      if (!startTime.equals("")) {
        startTime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(startTime));
      }
      if (!endTime.equals("")) {
        endTime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(endTime));
      }
      return getSecurityDAO().getLoginLog(actionContext, loginType, startTime, endTime, userName);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getAllOrganization(BoActionContext boActionContext) throws Exception {
    return getSecurityDAO().getAllOrganization(boActionContext);
  }

  public DataObjectList getAllSysUser(BoActionContext boActionContext) throws Exception {
    return getSecurityDAO().getAllSysUser(boActionContext);
  }

  public SysUser getSysUser(BoActionContext boActionContext, Long objectId) throws Exception {
    return getSecurityDAO().getSysUser(boActionContext, objectId.longValue());
  }

  public String getRoleName(BoActionContext boActionContext, String roleCuid) throws Exception {
    try {
      return getSecurityDAO().getRoleName(boActionContext, roleCuid);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public String getLSHbyUserCuid(BoActionContext boActionContext, String userCuid, Long sheetType) throws Exception {
    String LSHName = "";
    String orgCuid = "";
    Organization orgDbo = null;
    SysUser userDbo = null;
    userDbo = getSysUserByCuid(boActionContext, userCuid);
    if (userDbo != null) {
      orgCuid = userDbo.getRelatedOrganizationCuid();
    } else {
      LogHome.getLog().error("用户不存在!");
      throw new UserException("用户不存在!");
    }
    orgDbo = getOrganizationByCuid(boActionContext, orgCuid);
    if (orgDbo == null) {
      LogHome.getLog().error("用户所属机构不存在!");
      throw new UserException("用户所属机构不存在!");
    }
    if (sheetType.longValue() == 1L) {
      LSHName = orgDbo.getAppLsh();
    } else if (sheetType.longValue() == 2L) {
      LSHName = orgDbo.getAttLsh();
    } else if (sheetType.longValue() == 3L) {
      LSHName = orgDbo.getRplLsh();
    } else {
      LogHome.getLog().error("调单类型错误!");
      throw new UserException("调单类型错误!");
    }
    return LSHName;
  }

  public SysUser getSysUserByCuid(BoActionContext boActionContext, String userCuid) throws Exception {
    try {
      return getSecurityDAO().getSysUserByCuid(boActionContext, userCuid);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getSysUserBySql(BoActionContext actionContext, String sql) throws UserException {
    try {
      return getSecurityDAO().getSysUserBySql(sql);
    } catch (Throwable ex) {
      LogHome.getLog().error("按照Sql查询当前系统用户出错", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getSimQrySysUser(BoQueryContext queryContext, HashMap qrySysUserMap) throws UserException
  {
    try
    {
      return getSecurityDAO().getSimQrySysUsers(queryContext, qrySysUserMap);
    } catch (Throwable ex) {
      LogHome.getLog().error("根据条件进行用户查询返回用户列表出错:" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public void addFunctionTreeNodeFromXML(BoActionContext boActionContext, DataObjectList newdbos)
    throws Exception
  {
    if ((newdbos == null) || (newdbos.size() < 700)) {
      throw new UserException("FunctionTreeNode.xml is error");
    }
    UserTransaction trx = TransactionFactory.getInstance().createTransaction();
    try {
      trx.begin();

      LogHome.getLog().info("-----------开始导入功能点------------");

      DataObjectList tnmsFunctionTreeNodes = getSecurityDAO().getObjectsBySql("CUID LIKE 'FUNCTION_TREE_NODE-%'", new FunctionTreeNode(), 1);

      if (tnmsFunctionTreeNodes != null) {
        LogHome.getLog().info("1、获取待删除功能点记录 " + tnmsFunctionTreeNodes.size() + " 条");

        deleteObjects(boActionContext, tnmsFunctionTreeNodes);
        LogHome.getLog().info("1、删除功能点记录 " + tnmsFunctionTreeNodes.size() + " 条");
      }

      DboCollection rpdbos = getSecurityDAO().selectDBOs("SELECT * FROM ROLE_CONSIST_OF_FUN_POINT WHERE ROLE_CUID IN (SELECT CUID FROM USER_ROLE WHERE IS_USER_CREATE<>1 OR IS_USER_CREATE IS NULL)", new GenericDO[] { new RoleConsistOfFunPoint() });

      if (rpdbos != null) {
        LogHome.getLog().info("2、获取非用户建立的角色功能点对应关系记录 " + rpdbos.size() + " 条");
        for (int i = 0; i < rpdbos.size(); i++) {
          getSecurityDAO().deleteObject(boActionContext, (GenericDO)rpdbos.getAttrField("ROLE_CONSIST_OF_FUN_POINT", i));
        }
      }
      LogHome.getLog().info("2、删除非用户建立的角色功能点对应关系记录 " + rpdbos.size() + " 条");

      DboCollection userRoledbos = getSecurityDAO().selectDBOs("SELECT * FROM USER_ROLE WHERE IS_USER_CREATE<>1 OR IS_USER_CREATE IS NULL", new GenericDO[] { new UserRole() });
      if (userRoledbos != null) {
        LogHome.getLog().info("3、获取非用户建立的角色记录 " + userRoledbos.size() + " 条");
        for (int i = 0; i < userRoledbos.size(); i++) {
          getSecurityDAO().deleteObject(boActionContext, (GenericDO)userRoledbos.getAttrField("USER_ROLE", i));
        }
      }
      LogHome.getLog().info("3、删除非用户建立的角色记录 " + userRoledbos.size() + " 条");

      DboCollection delrudbos = getSecurityDAO().selectDBOs("SELECT * FROM ROLE_CONSIST_OF_FUN_POINT WHERE ROLE_CUID NOT IN (SELECT CUID FROM USER_ROLE)", new GenericDO[] { new RoleConsistOfFunPoint() });

      if (delrudbos != null) {
        LogHome.getLog().info("4、获取角色功能点对应关系中，角色已经不存在的数据 " + delrudbos.size() + " 条");
        for (int i = 0; i < delrudbos.size(); i++) {
          getSecurityDAO().deleteObject(boActionContext, (GenericDO)delrudbos.getAttrField("ROLE_CONSIST_OF_FUN_POINT", i));
        }
      }
      LogHome.getLog().info("4、删除角色功能点对应关系中，角色已经不存在的数据 " + delrudbos.size() + " 条");

      getSecurityDAO().createObjects(boActionContext, newdbos);
      LogHome.getLog().info("5、插入新功能点记录 " + newdbos.size() + " 条");

      DboCollection delrpdbos = getSecurityDAO().selectDBOs("SELECT * FROM ROLE_CONSIST_OF_FUN_POINT WHERE FUNCTION_NODE_CUID NOT IN (SELECT CUID FROM FUNCTION_TREE_NODE)", new GenericDO[] { new RoleConsistOfFunPoint() });

      if (delrpdbos != null) {
        LogHome.getLog().info("6、获取角色功能点对应关系中，角色已经不存在的数据 " + delrpdbos.size() + " 条");
        for (int i = 0; i < delrpdbos.size(); i++) {
          getSecurityDAO().deleteObject(boActionContext, (GenericDO)delrpdbos.getAttrField("ROLE_CONSIST_OF_FUN_POINT", i));
        }
      }
      LogHome.getLog().info("6、删除角色功能点对应关系中，角色已经不存在的数据 " + delrpdbos.size() + " 条");

      DboCollection haveroledbos = getSecurityDAO().selectDBOs("SELECT * FROM USER_HAVE_ROLE WHERE ROLE_CUID NOT IN (SELECT CUID FROM USER_ROLE)", new GenericDO[] { new UserHaveRole() });

      if (haveroledbos != null) {
        LogHome.getLog().info("7、获取用户角色关系中，角色已经不存在的数据 " + delrpdbos.size() + " 条");
        for (int i = 0; i < haveroledbos.size(); i++) {
          getSecurityDAO().deleteObject(boActionContext, (GenericDO)haveroledbos.getAttrField("USER_HAVE_ROLE", i));
        }
      }
      LogHome.getLog().info("7、删除用户角色关系中，角色已经不存在的数据 " + haveroledbos.size() + " 条");
      trx.commit();
      refSecurityRoleActionNames();
    } catch (Throwable ex) {
      trx.rollback();
      LogHome.getLog().error("导入功能点失败:", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void addLocalReportFunctionTreeNodeFromXML(BoActionContext boActionContext, DataObjectList newdbos)
    throws Exception
  {
    UserTransaction trx = TransactionFactory.getInstance().createTransaction();
    try {
      trx.begin();
      LogHome.getLog().info("-----------开始导入本地报表功能点------------");

      DataObjectList tnmsFunctionTreeNodes = getSecurityDAO().getAllLocalReportFunctionNode(boActionContext);
      if (tnmsFunctionTreeNodes != null) {
        LogHome.getLog().info("1、获取待删除本地报表功能点记录 " + tnmsFunctionTreeNodes.size() + " 条");
        deleteObjects(boActionContext, tnmsFunctionTreeNodes);
        LogHome.getLog().info("1、删除本地报表功能点记录 " + tnmsFunctionTreeNodes.size() + " 条");
      }

      if (newdbos != null) {
        LogHome.getLog().info("2、获取功能点配置文件功能点记录 " + newdbos.size() + " 条");
        DataObjectList tempList = new DataObjectList();
        for (int i = 0; i < newdbos.size(); i++) {
          FunctionTreeNode func = (FunctionTreeNode)newdbos.get(i);
          if ((func.getCuid() != null) && (func.getCuid().indexOf("FUNCTION_TREE_NODE-3-%") == 0)) {
            tempList.add(func);
          }
        }
        LogHome.getLog().info("2、获取本地报表功能点记录 " + tempList.size() + " 条");
        getSecurityDAO().createObjects(boActionContext, newdbos);
        LogHome.getLog().info("2、插入本地报表功能点记录 " + tempList.size() + " 条");
      }

      DboCollection delrpdbos = getSecurityDAO().selectDBOs("SELECT * FROM ROLE_CONSIST_OF_FUN_POINT WHERE FUNCTION_NODE_CUID NOT IN (SELECT CUID FROM FUNCTION_TREE_NODE)", new GenericDO[] { new RoleConsistOfFunPoint() });

      if (delrpdbos != null) {
        LogHome.getLog().info("3、获取角色功能点对应关系中，角色已经不存在的数据 " + delrpdbos.size() + " 条");
        for (int i = 0; i < delrpdbos.size(); i++) {
          getSecurityDAO().deleteObject(boActionContext, (GenericDO)delrpdbos.getAttrField("ROLE_CONSIST_OF_FUN_POINT", i));
        }
      }
      LogHome.getLog().info("3、删除角色功能点对应关系中，角色已经不存在的数据 " + delrpdbos.size() + " 条");

      DboCollection haveroledbos = getSecurityDAO().selectDBOs("SELECT * FROM USER_HAVE_ROLE WHERE ROLE_CUID NOT IN (SELECT CUID FROM USER_ROLE)", new GenericDO[] { new UserHaveRole() });

      if (haveroledbos != null) {
        LogHome.getLog().info("4、获取用户角色关系中，角色已经不存在的数据 " + delrpdbos.size() + " 条");
        for (int i = 0; i < haveroledbos.size(); i++) {
          getSecurityDAO().deleteObject(boActionContext, (GenericDO)haveroledbos.getAttrField("USER_HAVE_ROLE", i));
        }
      }
      LogHome.getLog().info("4、删除用户角色关系中，角色已经不存在的数据 " + haveroledbos.size() + " 条");

      trx.commit();
      refSecurityRoleActionNames();
    } catch (Throwable ex) {
      trx.rollback();
      LogHome.getLog().error("导入本地报表功能点失败:", ex);
      throw new UserException(ex.getMessage());
    }
  }

  private void deleteObjects(BoActionContext boActionContext, DataObjectList dbos)
    throws Exception
  {
    if (dbos != null)
      for (int i = 0; i < dbos.size(); i++)
        getSecurityDAO().deleteObject(boActionContext, (GenericDO)dbos.get(i));
  }

  public FunctionTreeNode addFunctionTreeNode(BoActionContext boActionContext, FunctionTreeNode dbo)
    throws Exception
  {
    String actionNames = dbo.getActionNames();
    checkActionNames(actionNames);
    if (getSecurityDAO().getFunctionTreeNode(boActionContext, dbo.getCuid()) == null) {
      dbo = getSecurityDAO().addFunctionTreeNode(boActionContext, dbo);
      refSecurityRoleActionNames();
    } else {
      throw new UserException("CUID重复错误！");
    }
    return dbo;
  }

  private void checkActionNames(String actionNames) throws UserException {
    String proType = TnmsRuntime.getInstance().get("PRODUCT_TYPE");
    if ((proType == null) || (proType.trim().length() == 0))
      throw new UserException("tnmscfg.xml配置文件中的productType字段配置错误！");
    if (!proType.equals(TransNmsCfg.ProductType.IRMS))
    {
      checkTnmsActionNames(actionNames);
    }
  }

  private void checkTnmsActionNames(String actionNames) throws UserException {
    if ((actionNames != null) && (actionNames.trim().length() > 0)) {
      String[] methods = actionNames.split(",");
      for (int i = 0; i < methods.length; i++) {
        methods[i] = methods[i].replace('.', '-');
        String[] method = methods[i].split("-");
        if (method.length == 2) {
          if (super.getBO(method[0]) != null) {
            if ((method[1].indexOf("get") == -1) && (method[1].indexOf("edit") == -1) && (method[1].indexOf("add") == -1) && (method[1].indexOf("delete") == -1) && (method[1].indexOf("modify") == -1))
            {
              throw new UserException(method[1] + "方法名称错误！");
            }
          }
          else throw new UserException(method[0] + "BO名称错误！");
        }
        else
          throw new UserException(methods[i] + "格式错误！");
      }
    }
  }

  public FunctionTreeNode getFunctionTreeNode(BoActionContext boActionContext, String cuid)
    throws Exception
  {
    return getSecurityDAO().getFunctionTreeNode(boActionContext, cuid);
  }

  public FunctionTreeNode getFunctionTreeNodeByObjectId(BoActionContext boActionContext, Long objectId) throws Exception {
    return getSecurityDAO().getFunctionTreeNode(boActionContext, objectId);
  }

  public FunctionTreeNode modifyFunctionTreeNode(BoActionContext boActionContext, FunctionTreeNode dbo) throws Exception {
    String actionNames = dbo.getActionNames();
    checkActionNames(actionNames);
    FunctionTreeNode tmpdbo = getSecurityDAO().getFunctionTreeNode(boActionContext, dbo.getCuid());
    if ((tmpdbo != null) && (tmpdbo.getObjectNum() != dbo.getObjectNum())) {
      throw new UserException("CUID重复错误：" + tmpdbo.getNodeName() + "已经存在相同的CUID" + tmpdbo.getCuid() + "！");
    }
    getSecurityDAO().modifyFunctionTreeNode(boActionContext, dbo);
    dbo = getSecurityDAO().getFunctionTreeNode(boActionContext, Long.valueOf(dbo.getObjectNum()));
    refSecurityRoleActionNames();

    return dbo;
  }

  public void deleteFunctionTreeNode(BoActionContext boActionContext, DataObjectList dbos) throws Exception {
    getSecurityDAO().delFunctionTreeNode(boActionContext, dbos);
  }

  public void deleteFunctionTreeNodeByCuid(BoActionContext boActionContext, String cuid) throws Exception {
    getSecurityDAO().delFunctionTreeNodeByCuid(boActionContext, cuid);
  }

  public DataObjectList ImportAllUserRole(Workbook rwb) throws Exception {
    LogHome.getLog().info("导入角色数据开始");
    DataObjectList dbos = new DataObjectList();
    Sheet rs = rwb.getSheet("USER_ROLE");
    int rowcount = rs.getRows();
    for (int i = 1; i < rowcount; i++) {
      UserRole dbo = new UserRole();
      dbo.setCuid(rs.getCell(0, i).getContents());
      dbo.setRoleName(rs.getCell(1, i).getContents());
      dbo.setRoleDescription(rs.getCell(2, i).getContents());
      if (rs.getCell(3, i).getContents().trim().equals("1"))
        dbo.setIsUserCreate(true);
      else {
        dbo.setIsUserCreate(false);
      }
      dbo.setRoleType(rs.getCell(4, i).getContents());
      LogHome.getLog().info(dbo.toString());
      dbos.add(dbo);
    }
    return dbos;
  }

  public DataObjectList ImportAllRoleConsistOfFunPoint(Workbook rwb) throws Exception {
    LogHome.getLog().info("导入角色功能点对应数据开始");
    DataObjectList dbos = new DataObjectList();
    Sheet rs = rwb.getSheet("ROLE_CONSIST_OF_FUN_POINT");
    int rowcount = rs.getRows();
    for (int i = 1; i < rowcount; i++) {
      RoleConsistOfFunPoint dbo = new RoleConsistOfFunPoint();
      dbo.setCuid(rs.getCell(0, i).getContents());
      dbo.setFunctionNodeCuid(rs.getCell(1, i).getContents());
      dbo.setRoleCuid(rs.getCell(2, i).getContents());
      LogHome.getLog().info(dbo.toString());
      dbos.add(dbo);
    }
    return dbos;
  }

  public DataObjectList ImportAllUserFunction(Workbook rwb) throws Exception {
    LogHome.getLog().info("导入功能点数据开始");
    DataObjectList dbos = new DataObjectList();
    Sheet rs = rwb.getSheet("FUNCTION_TREE_NODE");
    int rowcount = rs.getRows();
    for (int i = 1; i < rowcount; i++) {
      FunctionTreeNode dbo = new FunctionTreeNode();
      dbo.setRelatedNodeCuid(rs.getCell(0, i).getContents());
      dbo.setCuid(rs.getCell(1, i).getContents());
      dbo.setNodeCode(rs.getCell(2, i).getContents());
      dbo.setNodeName(rs.getCell(3, i).getContents());
      dbo.setActionNames(rs.getCell(4, i).getContents());
      if (rs.getCell(5, i).getContents().trim().equals("1"))
        dbo.setIsEndFlag(true);
      else {
        dbo.setIsEndFlag(false);
      }

      if ("FUNCTION_TREE_NODE-0001".equals(dbo.getCuid())) {
        this.commonActionNames = getActionNames(dbo.getActionNames());
      }
      LogHome.getLog().info(dbo.toString());
      dbos.add(dbo);
    }
    return dbos;
  }

  public void exportAllUserRole() throws Exception {
    DataObjectList dbos = getSecurityDAO().getAllUserRole(new BoActionContext());
    dbos.sort("CUID", true);
    OutputStream os = new FileOutputStream("ExportUserRole.xls");
    WritableWorkbook wwb = Workbook.createWorkbook(os);
    WritableSheet ws = wwb.createSheet("USER_ROLE", 0);

    Label labelC = new Label(0, 0, "CUID");
    ws.addCell(labelC);
    labelC = new Label(1, 0, "角色名称");
    ws.addCell(labelC);
    labelC = new Label(2, 0, "角色描述");
    ws.addCell(labelC);
    labelC = new Label(3, 0, "系统角色");
    ws.addCell(labelC);

    for (int i = 0; i < dbos.size(); i++) {
      UserRole dbo = (UserRole)dbos.get(i);
      labelC = new Label(0, i + 1, dbo.getCuid());
      ws.addCell(labelC);
      labelC = new Label(1, i + 1, dbo.getRoleName());
      ws.addCell(labelC);
      labelC = new Label(2, i + 1, dbo.getRoleDescription());
      ws.addCell(labelC);
      if (dbo.getIsUserCreate())
        labelC = new Label(3, i + 1, "1");
      else {
        labelC = new Label(3, i + 1, "0");
      }
    }
    wwb.write();
    wwb.close();
  }

  public void exportAllRoleConsistOfFunPoint() throws Exception {
    DataObjectList dbos = getSecurityDAO().getAllRoleFunPoint();
    if (dbos != null)
    {
      dbos.sort("CUID", true);
      OutputStream os = new FileOutputStream("ExportRoleConsistOfFunPoin.xls");
      WritableWorkbook wwb = Workbook.createWorkbook(os);
      WritableSheet ws1 = wwb.createSheet("ROLE_CONSIST_OF_FUN_POINT", 0);
      Label labelC = new Label(0, 0, "CUID");
      ws1.addCell(labelC);
      labelC = new Label(1, 0, "功能点CUID");
      ws1.addCell(labelC);
      labelC = new Label(2, 0, "角色CUID");
      ws1.addCell(labelC);
      for (int i = 0; i < dbos.size(); i++) {
        RoleConsistOfFunPoint dbo = (RoleConsistOfFunPoint)dbos.get(i);
        labelC = new Label(0, i + 1, dbo.getCuid());
        ws1.addCell(labelC);
        labelC = new Label(1, i + 1, dbo.getFunctionNodeCuid());
        ws1.addCell(labelC);
        labelC = new Label(2, i + 1, dbo.getRoleCuid());
        ws1.addCell(labelC);
      }
      wwb.write();
      wwb.close();
    }
  }

  public void delLoginLogs(BoQueryContext queryContext, String[] logs) throws Exception
  {
    for (int i = 0; i < logs.length; i++) {
      LoginLog log = new LoginLog();
      log.setCuid(logs[i].toString());
      getSecurityDAO().delLoginLog(queryContext, log);
    }
  }

  public DboCollection getLoginlogs(BoActionContext actionContext, Long loginType, String startTime, String endTime, String userName, String orgCuid)
    throws Exception
  {
    if ((startTime != null) && (startTime.trim().length() > 0)) {
      startTime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(startTime));
    }
    if ((endTime != null) && (endTime.trim().length() > 0)) {
      endTime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(endTime));
    }
    return getSecurityDAO().getLoginlogs(actionContext, loginType, startTime, endTime, userName, orgCuid);
  }

  public DboCollection getLoginlogsForExcel(BoActionContext actionContext, String startTime, String endTime, String userName, String orgCuid)
    throws Exception
  {
    if ((startTime != null) && (startTime.trim().length() > 0)) {
      startTime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(startTime));
    }
    if ((endTime != null) && (endTime.trim().length() > 0)) {
      endTime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(endTime));
    }
    return getSecurityDAO().getLoginlogsForExcel(actionContext, startTime, endTime, userName, orgCuid);
  }

  public Integer getSystemLevel(BoActionContext actionContext) throws Exception
  {
    Integer rtn = new Integer(0);
    District sysdistrict = getSystemDistrict(actionContext);
    if ((sysdistrict != null) && (!sysdistrict.equals("DISTRICT-00001"))) {
      rtn = new Integer(1);
    }
    return rtn;
  }

  public District getSystemDistrict(BoActionContext actionContext)
    throws Exception
  {
    String districtId = TnmsRuntime.getInstance().get("DISTRICT_ID");
    if (districtId.indexOf("DISTRICT") != -1)
    {
      return getDistrictyDAO().getDistrictByCuid(actionContext, districtId);
    }

    return getDistrictyDAO().getDistrictByLabelCn(districtId);
  }

  public DataObjectList getOrganizationByQuery(BoActionContext actionContext, String orgName, String beginTime, String endTime, String department, String relatedOrgCode) throws UserException
  {
    try
    {
      return getSecurityDAO().getOrganizationByQuery(actionContext, orgName, beginTime, endTime, department, relatedOrgCode);
    } catch (Exception ex) {
      LogHome.getLog().error("getOrganizationByQuery", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getSysUserByPage(BoQueryContext queryContext, String userName, String beginTime, String endTime, String orgCuid, String isLocked, String dep, String orderString) throws UserException
  {
    try {
      return getSecurityDAO().getSysUserByPage(queryContext, userName, beginTime, endTime, orgCuid, isLocked, dep, orderString);
    } catch (Exception ex) {
      LogHome.getLog().error("getSysUserByQuery", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getSysUserByPageNew(BoQueryContext queryContext, String userName, String beginTime, String endTime, String orgCuid, String isLocked, String dep, String orderString, String relatedDistrictCuid) throws UserException
  {
    try {
      return getSecurityDAO().getSysUserByPageNew(queryContext, userName, beginTime, endTime, orgCuid, isLocked, dep, orderString, relatedDistrictCuid);
    } catch (Exception ex) {
      LogHome.getLog().error("getSysUserByQuery", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getSystemLog(BoQueryContext actionContext, HashMap param, String orderString)
    throws UserException
  {
    try
    {
      return getSecurityDAO().getSystemLog(actionContext, param, orderString);
    }
    catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void delSystemLog(BoActionContext actionContext, String cuids)
    throws UserException
  {
    try
    {
      UserTransaction trx = TransactionFactory.getInstance().createTransaction();
      try {
        trx.begin();
        String[] ids = cuids.split(",");
        for (int i = 0; i < ids.length; i++) {
          getSecurityDAO().deleteLog(actionContext, ids[i]);
        }
        trx.commit();
      } catch (Exception ex) {
        trx.rollback();
        throw new Exception(ex);
      }
    } catch (Exception ex) {
      LogHome.getLog().error("删除SystemLog失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getLoginLogBypage(BoQueryContext actionContext, HashMap param, String orderString)
    throws UserException
  {
    try
    {
      return getSecurityDAO().getLoginLogBypage(actionContext, param, orderString);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void delLoginLogsByCuids(BoActionContext actionContext, String cuids)
    throws UserException
  {
    try
    {
      UserTransaction trx = TransactionFactory.getInstance().createTransaction();
      try {
        trx.begin();
        String[] ids = cuids.split(",");
        for (int i = 0; i < ids.length; i++) {
          getSecurityDAO().delLoginLogsBycuid(actionContext, ids[i]);
        }
        trx.commit();
      } catch (Exception ex) {
        trx.rollback();
        throw new Exception(ex);
      }
    } catch (Exception ex) {
      LogHome.getLog().error("删除LoginLog失败", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public boolean isHaveRelatedObj(String className, GenericDO deleteObj) throws UserException {
    try {
      BoActionContext actionContext = new BoActionContext();
      if ((deleteObj.getClassName().equals("DISTRICT")) && (className.equals("SYS_USER"))) {
        District district = (District)deleteObj;
        String sql = "RELATED_DISTRICT_CUID='" + district.getCuid() + "'";
        DataObjectList sysuser = getSysUserBySql(actionContext, sql);
        sql = "DISTRICT_CUID='" + district.getCuid() + "'";
        DataObjectList usermanagerdistricts = getSecurityDAO().getObjectsBySql(sql, new UserManageDistrict(), 1);
        if (((sysuser != null) && (sysuser.size() > 0)) || ((usermanagerdistricts != null) && (usermanagerdistricts.size() > 0))) {
          return true;
        }
        return false;
      }

      if ((deleteObj.getClassName().equals("DISTRICT")) && (className.equals("ORGANIZATION"))) {
        District district = (District)deleteObj;
        List orgs = getAllOrganizationByDistrict(actionContext, district);
        if ((orgs != null) && (orgs.size() > 0)) {
          return true;
        }
        return false;
      }

      return false;
    }
    catch (Exception ex) {
      throw new UserException(ex.getMessage());
    }
  }

  private List<String[]> parseRoleParameter(String roleCuids) {
    List list = new ArrayList();
    String[] roleCuid = roleCuids.split(",");
    for (int i = 0; i < roleCuid.length; i++) {
      if (roleCuid[i].indexOf("WORKFLOW") >= 0) {
        String _cuid = roleCuid[i].substring(roleCuid[i].indexOf("-") + 1, roleCuid[i].length());
        String[] _para = _cuid.split("@");
        if (_para.length != 3) {
          _para = new String[3];
        }
        if ((_para[2] == null) || (!_para[2].equals("admin"))) {
          list.add(_para);
        }
      }
    }
    return list;
  }

  public DboCollection getSysUsersByOrgCuid(BoActionContext actonContext, String orgCuid)
    throws UserException
  {
    try
    {
      return getSecurityDAO().getSysUserByOrgCuid(actonContext, orgCuid); } catch (Exception e) {
    }
    throw new UserException("SecurityBO::getSysUsersByOrgCuid");
  }

  public SharkRole[] getAllRoleByUser(BoActionContext actionContext, String username, String packageId, String processId) throws UserException
  {
    try {
      return getWorkFlowBOX().getAllRoleByUser(actionContext, username, packageId, processId);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex);
    }
  }

  public SharkUser[] getAllUserByRole(BoActionContext actionContext, String roleId, String packageId, String processId) throws UserException {
    try {
      return getWorkFlowBOX().getAllUserByRole(actionContext, roleId, packageId, processId);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex);
    }
  }

  public Boolean isHasRoleByUser(BoActionContext actionContext, String username, String packageId, String processId, String roleId)
    throws UserException
  {
    try
    {
      return getWorkFlowBOX().checkUserRole(actionContext, username, packageId, roleId);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex);
    }
  }

  public SecurityObjectBO getSecurityObjectBO() {
    return (SecurityObjectBO)super.getBO("IObjectSecurityBO");
  }

  private SecurityObjectDAO getSecurityObjectDAO() {
    return (SecurityObjectDAO)super.getDAO("SecurityObjectDAO");
  }

  public int getRelatedDeleteObjCount(String className, GenericDO deleteObj) throws UserException {
    return 0;
  }

  public DataObjectList getRelatedDeleteObjects(String className, GenericDO deleteObj) throws UserException {
    return null;
  }

  public void deleteReletedOfObject(String className, GenericDO deleteObj)
    throws UserException
  {
  }

  public DboCollection getWarningLimit(BoActionContext context, int value)
  {
    try
    {
      return getSecurityDAO().getWarningLimit(context, value);
    } catch (Exception ex) {
      throw new UserException("根据指标ID获取门限失败" + ex.getMessage());
    }
  }

  public DboCollection getUserWorkFlowRole(BoActionContext context, String userCuid) throws UserException
  {
    try {
      return getSecurityDAO().getUserWorkFlowRole(userCuid);
    } catch (Exception ex) {
      throw new UserException(ex);
    }
  }

  private ISystemParaBO getSystemParaBO()
  {
    return (ISystemParaBO)super.getBO("ISystemParaBO");
  }

  public DataObjectList getUserHaveRoleByUserCuid(BoActionContext context, String userCuid)
    throws Exception
  {
    return getSecurityDAO().getUserHaveRoleByUserCuid(userCuid);
  }

  public void deleteAllUserHaveRoleByUserCuid(BoActionContext actionContext, ArrayList<String> userCuids) throws Exception {
    for (String userCuid : userCuids) {
      String sql = "";
      if ((userCuid != null) && (userCuid.trim().length() > 0))
        sql = "USER_CUID='" + userCuid + "'";
      else {
        throw new UserException("用户CUID不能为空！");
      }
      DataObjectList dbos = getSecurityDAO().getObjectsBySql(sql, new UserHaveRole(), 0);
      getSecurityDAO().deleteObjects(actionContext, dbos);
    }
  }

  public void copyUserRight(BoActionContext actionContext, String oldSysUserCuid, ArrayList<String> newuserCuids)
    throws Exception
  {
    for (String _cuid : newuserCuids)
    {
      DataObjectList userhaveobjects = getSecurityDAO().getUserHaveObjects(actionContext, oldSysUserCuid);
      for (int i = 0; i < userhaveobjects.size(); i++) {
        ((GenericDO)userhaveobjects.get(i)).setCuid();
        ((GenericDO)userhaveobjects.get(i)).setAttrValue("RELATED_USER_CUID", _cuid);
      }
      DataObjectList userhaveroles = getSecurityDAO().getUserHaveRoleByUserCuid(oldSysUserCuid);
      for (int i = 0; i < userhaveroles.size(); i++) {
        ((GenericDO)userhaveroles.get(i)).setCuid();
        ((GenericDO)userhaveroles.get(i)).setAttrValue("USER_CUID", _cuid);
      }

      getSecurityDAO().createObjects(actionContext, userhaveroles);

      getSecurityDAO().createObjects(actionContext, userhaveobjects);
    }
  }

  public DataObjectList getAllChildOrganizationByCUID(BoActionContext boActionContext, String cuid) throws Exception
  {
    return getSecurityDAO().getAllChildOrganizationByCUID(boActionContext, cuid);
  }

  public DataObjectList getSameDistrictUsers(BoActionContext boActionContext, String userCuid) throws Exception {
    SysUser dbo = getSysUserByCuid(boActionContext, userCuid);
    String relatedDistrictCuid = dbo.getRelatedDistrictCuid();
    String managerDistrictCuid = dbo.getManagerDistrictCuid();
    String sql = "RELATED_DISTRICT_CUID='" + relatedDistrictCuid + "'";
    DataObjectList userDbos = getSysUserBySql(boActionContext, sql);

    Map userDistrictMap = getUserManageDistrictMap();
    String[] managerDistrictCuids = managerDistrictCuid != null ? managerDistrictCuid.split(",") : new String[0];
    DataObjectList newDbos = new DataObjectList();
    if (managerDistrictCuids.length == 0) {
      return userDbos;
    }
    for (int i = 0; i < userDbos.size(); i++) {
      SysUser _user = (SysUser)userDbos.get(i);
      if (userDistrictMap.containsKey(_user.getCuid())) {
        List l = (List)userDistrictMap.get(_user.getCuid());
        boolean flag = true;
        for (int j = 0; j < managerDistrictCuids.length; j++) {
          if (!l.contains(managerDistrictCuids[j])) {
            flag = false;
          }
        }
        if ((flag) && (!_user.getCuid().equals(dbo.getCuid())))
          newDbos.add(_user);
      }
      else if ((managerDistrictCuids.length == 1) && (managerDistrictCuids[0].trim().length() == 0) && (!_user.getCuid().equals(dbo.getCuid()))) {
        newDbos.add(_user);
      }
    }
    return newDbos;
  }

  private Map getUserManageDistrictMap() throws Exception {
    DataObjectList dbos = new DataObjectList();
    Map userDistrictMap = new HashMap();
    UserManageDistrict dto = new UserManageDistrict();
    dbos = getSecurityDAO().getAllObjByClass(dto, 0);
    for (int i = 0; i < dbos.size(); i++) {
      UserManageDistrict _dto = (UserManageDistrict)dbos.get(i);
      String _userCuid = _dto.getUserCuid();
      if (userDistrictMap.containsKey(_userCuid)) {
        List l = (List)userDistrictMap.get(_userCuid);
        l.add(_dto.getDistrictCuid());
      } else {
        List l = new ArrayList();
        l.add(_dto.getDistrictCuid());
        userDistrictMap.put(_userCuid, l);
      }
    }
    return userDistrictMap;
  }

  public List getAllORG(BoActionContext actionContext) throws Exception {
    DataObjectList dbos = getSecurityDAO().getAllORG();
    List list = new ArrayList();
    for (int i = 0; i < dbos.size(); i++) {
      GenericDO dbo = (GenericDO)dbos.get(i);
      list.add(dbo.getAttrString("1") + ":" + dbo.getAttrString("2") + ":" + dbo.getAttrString("3"));
    }
    return list;
  }

  public String getUserOrgByName(String name) throws Exception {
    DataObjectList dbos = getSecurityDAO().getUserOrgByName(name);
    if (dbos.size() > 0) {
      GenericDO dbo = (GenericDO)dbos.get(0);
      return dbo.getAttrString("1");
    }
    return null;
  }

  public SysUser getUserByUserName(String username)
    throws Exception
  {
    return getSecurityDAO().getSysUserByUserName(new BoActionContext(), username);
  }

  public boolean hasRole(String userId, String actionName) throws UserException, Exception {
    boolean isPermitted = false;
    if ((isAdminUser(userId)) || (isCommonAction(actionName))) {
      return true;
    }
    checkUserLogin(userId);
    Map userDistrictRole = getUserDistrictRoleBySQL(userId);
    String[] roleCuids = new String[userDistrictRole.size()];
    userDistrictRole.keySet().toArray(roleCuids);
    for (int i = 0; i < roleCuids.length; i++) {
      List actions = (List)this.roleFunctions.get(roleCuids[i]);
      if ((actions != null) && (actions.contains(actionName))) {
        isPermitted = true;
        break;
      }
      actionName = ActionHelper.getGenericActionName(actionName);
      if ((actions != null) && (actions.contains(actionName))) {
        isPermitted = true;
        break;
      }

    }

    return isPermitted;
  }

  public DataObjectList getReportFunctionNodeByUserCuid(BoActionContext boActionContext, String userCuid)
    throws Exception
  {
    return getSecurityDAO().getReportFunctionNodeByUserCuid(boActionContext, userCuid);
  }

  public DataObjectList getFunctionNodeByUserCuid(BoActionContext boActionContext, String userCuid)
    throws Exception
  {
    return getSecurityDAO().getFunctionNodeByUserCuid(boActionContext, userCuid);
  }

  public Boolean getIsWorkflowUser(BoActionContext actionContext, String userCuid) throws Exception
  {
    Boolean bol = Boolean.valueOf(false);
    String sql = "";

    sql = "select count(*) from APPLY_SHEET where RELATED_CREATER_CUID='" + userCuid + "'";
    bol = isWFUser(actionContext, sql);
    if (bol.booleanValue()) {
      return bol;
    }

    sql = "select count(*) from ATTEMP_SHEET where RELATED_CREATER_CUID='" + userCuid + "'";
    bol = isWFUser(actionContext, sql);
    if (bol.booleanValue()) {
      return bol;
    }

    sql = "select count(*) from REPLY_SHEET where RELATED_CREATER_CUID='" + userCuid + "'";
    bol = isWFUser(actionContext, sql);
    if (bol.booleanValue()) {
      return bol;
    }

    sql = "select count(*) from ATTEMP_HANDLER where RELATED_USER_CUID='" + userCuid + "'";
    bol = isWFUser(actionContext, sql);

    return bol;
  }

  private Boolean isWFUser(BoActionContext actionContext, String sql)
    throws Exception
  {
    Boolean bol = getSecurityDAO().isWFUser(actionContext, sql);
    return bol;
  }

  private void addHistoryUserPassword(BoActionContext actionContext, SysUser user)
    throws Exception
  {
    DataObjectList dbos = getSecurityDAO().getHistoryUserPasswordBySysUserCuid(actionContext, user.getCuid());
    int repeatCount = SecurityHelper.getInstance().getDEFAULT_REPEAT_COUNT();

    UserPasswordSecurity worddbo = getUserPasswordSecurity(new BoActionContext(), user.getRelatedSecurityCuid());
    if (worddbo != null) {
      long repeatCountlong = worddbo.getPasswordRepeatCount();
      if (repeatCountlong > 0L) {
        repeatCount = Integer.valueOf(String.valueOf(repeatCountlong)).intValue();
      }
    }

    for (int i = 0; (i < dbos.size()) && (i < repeatCount - 1); i++) {
      HistoryUserPassword dbo = (HistoryUserPassword)dbos.get(i);
      if ((dbo.getUserPassword().equals(user.getUserPassword())) && (i != 0)) {
        throw new UserException("用户密码在" + repeatCount + "次内重复,设置失败!");
      }
    }

    for (int i = repeatCount - 1; i < dbos.size(); i++) {
      getSecurityDAO().deleteHistoryUserPassword(actionContext, (HistoryUserPassword)dbos.get(i));
    }

    boolean isNewPassword = true;
    if (dbos.size() > 0) {
      HistoryUserPassword dbo = (HistoryUserPassword)dbos.get(0);
      if (dbo.getUserPassword().equals(user.getUserPassword())) {
        isNewPassword = false;
      }
    }
    if (isNewPassword)
    {
      HistoryUserPassword dbo = new HistoryUserPassword();
      dbo.setUserPassword(user.getUserPassword());
      dbo.setUserCuid(user.getCuid());
      getSecurityDAO().addHistoryUserPassword(actionContext, dbo);
    }
  }

  private void deleteHistoryUserPasswordByUserCuid(BoActionContext actionContext, String userCuid)
    throws Exception
  {
    DataObjectList dbos = getSecurityDAO().getHistoryUserPasswordBySysUserCuid(actionContext, userCuid);
    getSecurityDAO().deleteHistoryUserPasswords(actionContext, dbos);
  }

  public int getPasswordRepeatCount(BoActionContext actionContext)
    throws Exception
  {
    String repeatCountStr = getSystemParaBO().getSystemParaValue(actionContext, "Security", "ModifyPasswordRepeatCount");
    int repeatCount = SecurityHelper.getInstance().getDEFAULT_REPEAT_COUNT();
    if (repeatCountStr != null) {
      repeatCount = Integer.valueOf(repeatCountStr).intValue();
    }
    return repeatCount;
  }

  public int modifyPasswordRepeatCount(BoActionContext actionContext, int repeatCount)
    throws Exception
  {
    if (repeatCount == 0) {
      throw new UserException("修改密码不能重复的次数不能为 0 !");
    }
    String oldRepeatCount = null;
    try {
      oldRepeatCount = getSystemParaBO().getSystemParaValue(actionContext, "Security", "ModifyPasswordRepeatCount");
    }
    catch (Exception ex) {
    }
    if ((oldRepeatCount == null) || (!oldRepeatCount.equals(String.valueOf(repeatCount)))) {
      UserTransaction trx = TransactionFactory.getInstance().createTransaction();
      try {
        trx.begin();
        getSystemParaBO().modifySystemPara(actionContext, "Security", "ModifyPasswordRepeatCount", String.valueOf(repeatCount));

        String userCuid = "";
        int count = 0;
        DataObjectList dbos = getSecurityDAO().getAllHistoryUserPassword(actionContext);
        DataObjectList delList = new DataObjectList();
        for (int i = 0; i < dbos.size(); i++) {
          HistoryUserPassword dbo = (HistoryUserPassword)dbos.get(i);
          if (dbo.getUserCuid().equals(userCuid)) {
            count++;
            if (count > repeatCount)
              delList.add(dbo);
          }
          else {
            userCuid = dbo.getUserCuid();
            count = 1;
          }
        }
        getSecurityDAO().deleteHistoryUserPasswords(actionContext, delList);
        trx.commit();
      } catch (Exception ex) {
        trx.rollback();
        LogHome.getLog().error("修改密码可最多不重复的次数失败:", ex);
        throw new UserException(ex.getMessage());
      }
    }
    return repeatCount;
  }

  public int getPasswordAvilableTime(BoActionContext actionContext, SysUser user)
    throws Exception
  {
    int avilableTime = SecurityHelper.getInstance().getDEFAULT_AVAILABLE_TIME();
    try
    {
      if ((user.getRelatedSecurityCuid() != null) && (user.getRelatedSecurityCuid().trim().length() > 0)) {
        UserPasswordSecurity dbo = getSecurityDAO().getUserPasswordSecurity(new BoActionContext(), user.getRelatedSecurityCuid());
        if ((dbo != null) && (dbo.getPasswordAvilableTime() > 0L))
          avilableTime = Integer.valueOf(String.valueOf(dbo.getPasswordAvilableTime())).intValue();
      }
    }
    catch (Exception ex)
    {
      LogHome.getLog().error(ex);
      throw new UserException(ex);
    }
    return avilableTime;
  }

  public int modifyPasswordAvilableTime(BoActionContext actionContext, int avilableTime)
    throws Exception
  {
    if (avilableTime == 0) {
      throw new UserException("密码有效期不能为 0 !");
    }
    getSystemParaBO().modifySystemPara(actionContext, "Security", "PasswordAvilableTime", String.valueOf(avilableTime));
    return avilableTime;
  }

  public boolean getIsConstraintPassword(BoActionContext actionContext)
    throws Exception
  {
    boolean isConstraintPassword = SecurityHelper.getInstance().isIS_CONSTRAINT_PASSWORD();
    try {
      String avilableTimeStr = getSystemParaBO().getSystemParaValue(actionContext, "Security", "IsConstraintPassword");
      if (avilableTimeStr != null)
        isConstraintPassword = Boolean.valueOf(avilableTimeStr).booleanValue();
    }
    catch (Exception ex) {
      LogHome.getLog().error(ex);
      throw new UserException(ex);
    }
    return isConstraintPassword;
  }

  public boolean modifyIsConstraintPassword(BoActionContext actionContext, boolean isConstraintPassword)
    throws Exception
  {
    getSystemParaBO().modifySystemPara(actionContext, "Security", "IsConstraintPassword", String.valueOf(isConstraintPassword));
    SecurityHelper.getInstance().setIS_CONSTRAINT_PASSWORD(isConstraintPassword);
    return isConstraintPassword;
  }

  public String isPasswordValidCanBeUse(BoActionContext actionContext, SysUser dbo, String str)
    throws Exception
  {
    String isPasswordValid = "";

    UserPasswordSecurity worddbo = getUserPasswordSecurity(new BoActionContext(), dbo.getRelatedSecurityCuid());
    if ((str == null) || (str.length() == 0)) {
      isPasswordValid = "密码不能为空!";
    }

    long wordlength = worddbo.getPasswordLength();
    if (str.length() < wordlength) {
      isPasswordValid = "密码长度不能小于" + String.valueOf(wordlength) + "!";
    }
    if ((worddbo.getIsContainUpper()) && 
      (!SecurityHelper.isContainLetter_A(str))) {
      isPasswordValid = "密码必须包含大写字母!";
    }

    if ((worddbo.getIsContainLower()) && 
      (!SecurityHelper.isContainLetter_a(str))) {
      throw new UserException("密码必须包含小写字母!");
    }

    if ((worddbo.getIsContainNum()) && 
      (!SecurityHelper.isContainNum(str))) {
      isPasswordValid = "密码必须包含数字!";
    }

    if ((worddbo.getIsContainCharater()) && 
      (!SecurityHelper.isContainCharacter(str))) {
      isPasswordValid = "密码必须包含特殊字符!";
    }

    return isPasswordValid;
  }

  private boolean isPasswordValid(BoActionContext actionContext, SysUser dbo, String str)
    throws Exception
  {
    boolean isPasswordValid = true;

    UserPasswordSecurity worddbo = getUserPasswordSecurity(new BoActionContext(), dbo.getRelatedSecurityCuid());
    if ((str == null) || (str.length() == 0)) {
      throw new UserException("密码不能为空!");
    }

    long wordlength = worddbo.getPasswordLength();
    if (str.length() < wordlength) {
      throw new UserException("密码长度不能小于" + String.valueOf(wordlength) + "!");
    }
    if ((worddbo.getIsContainUpper()) && 
      (!SecurityHelper.isContainLetter_A(str))) {
      throw new UserException("密码必须包含大写字母!");
    }

    if ((worddbo.getIsContainLower()) && 
      (!SecurityHelper.isContainLetter_a(str))) {
      throw new UserException("密码必须包含小写字母!");
    }

    if ((worddbo.getIsContainNum()) && 
      (!SecurityHelper.isContainNum(str))) {
      throw new UserException("密码必须包含数字!");
    }

    if ((worddbo.getIsContainCharater()) && 
      (!SecurityHelper.isContainCharacter(str))) {
      throw new UserException("密码必须包含特殊字符!");
    }

    return isPasswordValid;
  }

  public DboCollection getUserNameByOrgCuid(BoActionContext actonContext, String orgCuid, String userName)
    throws UserException
  {
    try
    {
      return getSecurityDAO().getUserNameByOrgCuid(actonContext, orgCuid, userName); } catch (Exception e) {
    }
    throw new UserException("根据用户组cuid和用户名查询登录名称失败!");
  }

  public void isUserLocked(String userCuid)
    throws Exception
  {
    Boolean isUserLock = (Boolean)userLockState.get(userCuid);
    if ((isUserLock != null) && (isUserLock.booleanValue())) {
      SysUser user = getSecurityDAO().getSysUserByCuid(new BoActionContext(), userCuid);
      if ((user != null) && (user.getIsLocked())) {
        LogHome.getLog().info("用户[userId=" + userCuid + "]被锁定 !");
        throw new UserException("当前用户已被锁定！");
      }if (user != null)
        userLockState.put(userCuid, Boolean.valueOf(user.getIsLocked()));
    }
  }

  public void modifyUserTheme(BoActionContext actionContext, SysUser dbo)
    throws UserException
  {
    try
    {
      getSecurityDAO().modifySysUser(actionContext, dbo);
    } catch (Exception e) {
      throw new UserException("更新用户主题风格失败!");
    }
  }

  public DataObjectList getAllLocalReportFunctionNode(BoActionContext boActionContext)
    throws Exception
  {
    return getSecurityDAO().getAllLocalReportFunctionNode(boActionContext);
  }

  private DataObjectList getRecordBySysUser(BoActionContext boActionContext, String userCuid)
    throws Exception
  {
    return getSecurityDAO().getObjectsBySql("SYS_USER_CUID='" + userCuid + "'", new RecordData(), 0);
  }

  public void deleteRecordToManByUsercuid(BoActionContext boActionContext, String userCuid)
    throws Exception
  {
    getSecurityDAO().deleteRecordToManByUsercuid(boActionContext, userCuid);
  }

  public DataObjectList getOrganizationBySql(BoActionContext actionContext, String sql) throws Exception {
    return getSecurityDAO().getObjectsBySql(sql, new Organization(), 0);
  }

  public DboCollection getSecurityByName(BoQueryContext queryContext, String name, String orderString)
    throws Exception
  {
    return getSecurityDAO().querySecurityByName(queryContext, name, orderString);
  }

  public boolean isSameSecurityName(BoQueryContext queryContext, String name)
    throws Exception
  {
    return getSecurityDAO().isSameSecurityName(queryContext, name);
  }

  public boolean isSameSecurityNameModify(BoQueryContext queryContext, String name, String cuid) throws Exception {
    return getSecurityDAO().isSameSecurityNameModify(queryContext, name, cuid);
  }

  public SysUser loginNoCheckPassword(BoActionContext actionContext, String userName, String password)
    throws UserException
  {
    SysUser user = null;
    try {
      user = getSecurityDAO().getUser(userName);
      if (user == null)
        throw new UserException("用户不存在 ！");
      if (!isPasswordIdentical(user.getUserPassword(), password))
        throw new UserException("用户密码不正确 ！");
      if (user.getIsLocked()) {
        throw new UserException("用户处于锁定状态 ！");
      }

      user = getSecurityDAO().getSysUser(actionContext, user.getObjectNum());
      String defaultTheme = TnmsRuntime.getInstance().get("DEFAULT_THEME");
      if ((defaultTheme == null) || ((!defaultTheme.equals("DarkTheme")) && (!defaultTheme.equals("LightTheme")))) {
        defaultTheme = "GreyTheme";
      }
      String returnStr = "";
      if ((user != null) && (user.getTheme() != null) && (user.getTheme().trim().length() > 0)) {
        returnStr = user.getTheme();
      }
      if ((returnStr == null) || (returnStr.equals("DefaultTheme")) || (returnStr.equals("")) || (returnStr.equals("null"))) {
        returnStr = defaultTheme;
      }
      if (returnStr.equals("GreyTheme")) {
        returnStr = "DefaultTheme";
      }
      user.setTheme(returnStr);
      getUserDistrictRoleBySQL(user.getCuid());
    }
    catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
    try {
      user.setAttrValue("isPasswordAvilable", true);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
    return user;
  }

  public String addUserToCust(BoActionContext actionContext, String cuid, String custs) throws UserException {
    try {
      getSecurityDAO().deleteUserToCustByUsercuid(actionContext, cuid);
      return getSecurityDAO().addUserToCust(actionContext, cuid, custs);
    } catch (Exception ex) {
      LogHome.getLog().error("添加用户客户关系出错", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public String getCustStrbyUserId(BoActionContext actionContext, String cuid)
    throws UserException
  {
    try
    {
      DboCollection dbos = getSecurityDAO().getCustStrbyUserId(actionContext, cuid);
      String result = "";
      for (int i = 0; i < dbos.size(); i++) {
        UserToCust userToCust = (UserToCust)dbos.getAttrField("USER_TO_CUST", i);
        if (userToCust.getCustCuid().indexOf("VP_GROUP") != -1)
        {
          VpGroup vpGroup = (VpGroup)getCommonDAO().getObjByCuid(new VpGroup(userToCust.getCustCuid()));
          if (i == 0)
            result = vpGroup.getCuid() + "@" + vpGroup.getLabelCn();
          else {
            result = result + ";" + vpGroup.getCuid() + "@" + vpGroup.getLabelCn();
          }
        }
        else
        {
          Vp vp = (Vp)getCommonDAO().getObjByCuid(new Vp(userToCust.getCustCuid()));
          if (i == 0)
            result = vp.getCuid() + "@" + vp.getLabelCn();
          else {
            result = result + ";" + vp.getCuid() + "@" + vp.getLabelCn();
          }
        }
      }

      return result;
    } catch (Exception ex) {
      LogHome.getLog().error("查询用户客户关系出错", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public String getCustStrByUserIdAndCustName(BoActionContext actionContext, String cuid, String searchCustName)
    throws UserException
  {
    try
    {
      DboCollection dbos = getSecurityDAO().getCustStrByUserIdAndCustName(actionContext, cuid, searchCustName);
      String result = "";
      for (int i = 0; i < dbos.size(); i++) {
        UserToCust userToCust = (UserToCust)dbos.getAttrField("USER_TO_CUST", i);
        if (userToCust.getCustCuid().indexOf("VP_GROUP") != -1)
        {
          VpGroup vpGroup = (VpGroup)getCommonDAO().getObjByCuid(new VpGroup(userToCust.getCustCuid()));
          if (i == 0)
            result = vpGroup.getCuid() + "@" + vpGroup.getLabelCn();
          else {
            result = result + ";" + vpGroup.getCuid() + "@" + vpGroup.getLabelCn();
          }
        }
        else
        {
          Vp vp = (Vp)getCommonDAO().getObjByCuid(new Vp(userToCust.getCustCuid()));
          if (i == 0)
            result = vp.getCuid() + "@" + vp.getLabelCn();
          else {
            result = result + ";" + vp.getCuid() + "@" + vp.getLabelCn();
          }
        }
      }
      return result;
    } catch (Exception ex) {
      LogHome.getLog().error("根据客户名称模糊查询用户客户关系出错", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getUserManagerDistrictByuserCuid(BoActionContext actionContext, String userCuid)
    throws Exception
  {
    String sql = "DISTRICT_CUID='" + userCuid + "'";
    DataObjectList usermanagerdistricts = getSecurityDAO().getObjectsBySql(sql, new UserManageDistrict(), 0);
    return usermanagerdistricts;
  }

  public void modifyAttempReceivrBySysUser(BoActionContext boActionContext, SysUser user) throws UserException {
    if ((null != user) && (user.getCuid().trim().length() > 0) && (user.getRelatedOrganizationCuid().trim().length() > 0)) {
      String sql = "RELATED_USER_CUID='" + user.getCuid() + "'";
      try {
        DataObjectList dbos = getSecurityDAO().getObjectsBySql(sql, new AttempReceiver(), 0);
        if ((null != dbos) && (dbos.size() > 0)) {
          Map attrMap = new HashMap();
          attrMap.put("RELATED_DEP_CUID", user.getRelatedOrganizationCuid());
          getSecurityDAO().updateObjects(boActionContext, dbos, attrMap);
        }
      } catch (Exception ex) {
        LogHome.getLog().error("", ex);
        throw new UserException(ex.getMessage());
      }
    }
  }

  public void deleteAttempReceivrBySysUser(BoActionContext boActionContext, SysUser user) throws UserException {
    if ((null != user) && (user.getCuid().trim().length() > 0) && (user.getRelatedOrganizationCuid().trim().length() > 0)) {
      String sql = "RELATED_USER_CUID='" + user.getCuid() + "'";
      try {
        DataObjectList dbos = getSecurityDAO().getObjectsBySql(sql, new AttempReceiver(), 0);
        if ((null != dbos) && (dbos.size() > 0))
          getSecurityDAO().deleteObjects(boActionContext, dbos);
      }
      catch (Exception ex) {
        LogHome.getLog().error("", ex);
        throw new UserException(ex.getMessage());
      }
    }
  }

  public Boolean supportLostPath(BoActionContext boActionContext) {
    return Boolean.valueOf(TnmsRuntime.getInstance().equals("SUPPORT_LOST_PATH", Boolean.TRUE.toString()));
  }

  public Boolean getAlcatelLucentManager(BoActionContext boActionContext) {
    return Boolean.valueOf(TnmsRuntime.getInstance().equals("ALCATEL_LUCENT_MANAGER", Boolean.TRUE.toString()));
  }
  public Boolean getOpticalManager(BoActionContext boActionContext) {
    boolean isOpticalManager = TransNmsCfg.getInstance().isOpticalManager();
    return Boolean.valueOf(isOpticalManager);
  }
  public Boolean checkUserHaveActionNames(String actionName, String userCuid) throws Exception {
    return getSecurityDAO().checkUserHaveActionNames(actionName, userCuid);
  }

  public DboCollection getSubSysUserByPage(BoQueryContext queryContext, String userName, String creatUser)
    throws Exception
  {
    return getSecurityDAO().getSubSysUserByPage(queryContext, userName, creatUser);
  }

  public SysUser addSubSysUser(BoActionContext actionContext, SysUser dbo) throws UserException {
    try {
      if (getSecurityDAO().getSysUserByUserName(actionContext, dbo.getUserName()) != null) {
        throw new UserException("用户名已经存在 ！");
      }

      String managerDistrictCuid = dbo.getManagerDistrictCuid();
      dbo.setManagerDistrictCuid("");
      dbo.setFlowUser(false);
      dbo.setLastPasswordTime(new Timestamp(System.currentTimeMillis()));
      SysUser newdbo = getSecurityDAO().addSysUser(actionContext, dbo);
      int num = ((Integer)this.userCounts.get("user")).intValue();
      this.userCounts.put("user", Integer.valueOf(num + 1));
      newdbo.setManagerDistrictCuid(managerDistrictCuid);
      getSecurityDAO().updateUserManagerDistrict(actionContext, newdbo);

      return newdbo;
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public SysUser getSubSysUser(BoActionContext boActionContext, long objectId) throws Exception {
    return getSecurityDAO().getSysUser(boActionContext, objectId);
  }

  public void deleteSubSysUser(BoActionContext boActionContext, long objectId) throws Exception {
    SysUser subSysUser = getSubSysUser(boActionContext, objectId);
    UserTransaction trx = TransactionFactory.getInstance().createTransaction();
    try {
      trx.begin();
      getSecurityDAO().deleteUserManagerDistrict(boActionContext, subSysUser.getCuid());

      getSecurityDAO().deleteUserToTraphByUserCuid(boActionContext, subSysUser.getCuid());
      getSecurityDAO().delSubSysUser(boActionContext, Long.valueOf(objectId));
      trx.commit();
    } catch (Exception ex) {
      trx.rollback();
      throw new UserException(ex.getMessage());
    }
  }

  public SysUser modifySubSysUser(BoActionContext actionContext, SysUser dbo) throws Exception {
    SysUser oldUser = getSubSysUser(actionContext, Long.valueOf(dbo.getObjectId()).longValue());
    UserTransaction trx = TransactionFactory.getInstance().createTransaction();
    SysUser newUser = null;
    SysUser tempUser = getSecurityDAO().getSysUserByUserName(actionContext, dbo.getUserName());
    if ((tempUser != null) && (!tempUser.getCuid().equals(dbo.getCuid())))
      throw new UserException("用户名已经存在 ！");
    try
    {
      trx.begin();
      if (!oldUser.getUserPassword().equals(dbo.getUserPassword())) {
        dbo.setLastPasswordTime(new Timestamp(System.currentTimeMillis()));
      }
      newUser = getSecurityDAO().modifySubSysUser(actionContext, dbo);
      trx.commit();
    } catch (Exception ex) {
      trx.rollback();
      throw new UserException(ex.getMessage());
    }
    return newUser;
  }

  public void addUserToTraph(BoActionContext actionContext, String userCuid, String traphIds)
    throws Exception
  {
    UserTransaction trx = TransactionFactory.getInstance().createTransaction();
    try {
      trx.begin();
      SecurityDAO subSysUserDAO = getSecurityDAO();
      subSysUserDAO.deleteUserToTraphByUserCuid(actionContext, userCuid);
      String[] traph = traphIds.split(",");

      for (int i = 0; (i < traph.length) && 
        (!traph[i].trim().equals("")); i++)
      {
        UserToTraph userToTraph = new UserToTraph();
        userToTraph.setRelatedSysUserCuid(userCuid);
        userToTraph.setRelatedTraphCuid(traph[i]);
        subSysUserDAO.addUserToTraph(actionContext, userToTraph);
      }
      trx.commit();
    } catch (Exception ex) {
      trx.rollback();
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection validateRole(BoActionContext actionContext, String userCuid, String nodeName) throws Exception {
    return getSecurityDAO().validateRole(actionContext, userCuid, nodeName);
  }

  public void checkUserByAccountDate(BoActionContext actionContext, String jobName) throws UserException
  {
    try {
      DataObjectList userdbos = getSecurityDAO().getAllSysUser(actionContext);
      for (int i = 0; i < userdbos.size(); i++) {
        SysUser user = (SysUser)userdbos.get(i);
        Date date = new Date();
        if ((user.getAccountDate() != null) && 
          (user.getAccountDate().getTime() < date.getTime()) && 
          (!user.getIsLocked())) {
          user.setIsLocked(true);
          getSecurityDAO().modifySysUser(actionContext, user);
        }
      }
    }
    catch (Exception e)
    {
      LogHome.getLog().error("核查用户有效期异常：" + e.getMessage());
    }
  }

  private List getXmlValueByParam(BoActionContext actionContext, String xmlData, String optionType)
    throws Exception
  {
    List list = new ArrayList();
    Map userMap = new HashMap();
    DataObjectList sysDbos = getAllSysUser(actionContext);
    if ((sysDbos != null) && (sysDbos.size() > 0)) {
      for (int i = 0; i < sysDbos.size(); i++) {
        SysUser dbo = (SysUser)sysDbos.get(i);
        userMap.put(dbo.getUserName(), dbo);
      }
    }
    Element headElement = new Element("delresults");
    Element resultFirst = new Element("result");
    resultFirst.setAttribute("returncode", "1300");
    Element resultSec = new Element("result");
    resultSec.setAttribute("returncode", "1301");
    headElement.addContent(resultFirst);
    headElement.addContent(resultSec);
    InputSource input = new InputSource(new StringReader(xmlData));
    SAXBuilder parser = new SAXBuilder();
    try {
      Document document = parser.build(input);
      Element opDetail = document.getRootElement();
      List records = opDetail.getChildren();
      for (Element filed : records) {
        String oldPassword = "";
        Element filedInfo = filed.getChild("accId");
        String userName = filedInfo.getText();
        SysUser user = null;

        if (optionType.equals("addSysuser")) {
          user = new SysUser();
          if ((userName != null) && (userName.length() > 0))
            user.setUserName(userName);
        }
        else {
          user = (SysUser)userMap.get(userName);
          oldPassword = user.getUserPassword();
        }
        if (user != null)
        {
          filedInfo = filed.getChild("name");
          String trueName = filedInfo.getText();
          if ((trueName != null) && (trueName.length() > 0)) {
            user.setTrueName(trueName);

            LogHome.getLog().info("---------------传进的登录名和真实姓名分别为--------------" + userMap + ":" + trueName + "\r\n");

            filedInfo = filed.getChild("userPassword");
            String userPassword = "";
            if (filedInfo != null) {
              userPassword = filedInfo.getText();

              if ((userPassword != null) && (userPassword.length() > 0))
                user.setUserPassword(PwdEncodeUtil.sha1Base64(userPassword));
              else
                user.setUserPassword(PwdEncodeUtil.sha1Base64("123456"));
            }
            else {
              user.setUserPassword(PwdEncodeUtil.sha1Base64("123456"));
            }

            filedInfo = filed.getChild("description");
            if (filedInfo != null) {
              String description = filedInfo.getText();
              if ((description != null) && (description.length() > 0)) {
                user.setRemark(description);
              }
            }

            filedInfo = filed.getChild("email");
            if (filedInfo != null) {
              String email = filedInfo.getText();
              if ((email != null) && (email.length() > 0)) {
                user.setEmailAddress(email);
              }
            }

            filedInfo = filed.getChild("mobile");
            if (filedInfo != null) {
              String mobile = filedInfo.getText();
              if ((mobile != null) && (mobile.length() > 0)) {
                user.setTelephone(mobile);
              }
            }

            filedInfo = filed.getChild("postalAddress");
            if (filedInfo != null) {
              String postalAddress = filedInfo.getText();
              if ((postalAddress != null) && (postalAddress.length() > 0)) {
                user.setAddr(postalAddress);
              }
            }

            filedInfo = filed.getChild("facsimileTelephoneNumber");
            if (filedInfo != null) {
              String facsimileTelephoneNumber = filedInfo.getText();
              if ((facsimileTelephoneNumber != null) && (facsimileTelephoneNumber.length() > 0)) {
                user.setFacsimile(facsimileTelephoneNumber);
              }
            }

            filedInfo = filed.getChild("passwordModifiedDate");
            if (filedInfo != null) {
              String passwordModifiedDate = filedInfo.getText();
              if ((passwordModifiedDate != null) && (passwordModifiedDate.length() > 0)) {
                Timestamp date = TimeFormatHelper.getFormatTimestamp(passwordModifiedDate);
                user.setLastPasswordTime(date);
              } else {
                user.setLastPasswordTime(TimeFormatHelper.getFormatTimestampNow());
              }
            }

            filedInfo = filed.getChild("employeeNumber");
            if (filedInfo != null) {
              String employeeNumber = filedInfo.getText();
              if ((employeeNumber != null) && (employeeNumber.length() > 0)) {
                user.setEmployeeId(employeeNumber);
              }
            }

            String sysDistrictCuid = "";
            District district = getSystemDistrict(actionContext);
            if (district != null) {
              sysDistrictCuid = district.getCuid();
            }
            if ((sysDistrictCuid != null) && (sysDistrictCuid.trim().length() > 0))
              user.setRelatedDistrictCuid(sysDistrictCuid);
            else {
              user.setRelatedDistrictCuid("DISTRICT-00001");
            }

            if (optionType.equals("addSysuser")) {
              user.setIsLocked(false);
            }

            DboCollection worddbos = getSecurityDAO().querySecurityByName(new BoQueryContext(), "", "CUID");
            if ((worddbos != null) && (worddbos.size() > 0)) {
              UserPasswordSecurity sec = (UserPasswordSecurity)worddbos.getAttrField("USER_PASSWORD_SECURITY", 0);
              if (sec != null) {
                user.setRelatedSecurityCuid(sec.getCuid());
              }
            }

            DataObjectList orgdbos = getSecurityDAO().getAllORG();
            if ((orgdbos != null) && (orgdbos.size() > 0)) {
              GenericDO org = (GenericDO)orgdbos.get(0);
              if (org != null) {
                user.setRelatedOrganizationCuid(org.getAttrString("1"));
              }
            }
            if (optionType.equals("addSysuser")) {
              if (!userMap.containsKey(userName)) {
                list.add(user);
                userMap.put(userName, user);
                resultFirst.addContent(new Element("accId").addContent(filed.getChildText("accId")));
              } else {
                resultSec.addContent(new Element("accId").addContent(filed.getChildText("accId")));
              }
            }
            else if (user != null) {
              if (!oldPassword.equals(user.getUserPassword())) {
                user.setAttrValue("isModifyPassword", true);
              }
              resultFirst.addContent(new Element("accId").addContent(filed.getChildText("accId")));
              list.add(user);
            } else {
              resultSec.addContent(new Element("accId").addContent(filed.getChildText("accId")));
            }
          }
        }
      }
      headElement.addContent(new Element("errorMsg").addContent(""));
      Document myDocument = new Document(headElement);
      Format format = Format.getCompactFormat();
      format.setEncoding("UTF-8");
      format.setIndent("");
      XMLOutputter outputter = new XMLOutputter(format);
      list.add(outputter.outputString(myDocument));
    } catch (Exception ex) {
      LogHome.getLog().error("解析xml数据失败，xml：" + xmlData, ex);
    }
    return list;
  }

  public String addSysuserBy4A(BoActionContext boActionContext, String xmlString)
    throws Exception
  {
    List list = getXmlValueByParam(boActionContext, xmlString, "addSysuser");
    if ((list != null) && (list.size() > 0)) {
      for (int i = 0; i < list.size() - 1; i++) {
        SysUser dbo = (SysUser)list.get(i);
        String managerDistrictCuid = dbo.getManagerDistrictCuid();
        dbo.setManagerDistrictCuid("");
        dbo.setFlowUser(false);
        dbo.setLastPasswordTime(new Timestamp(System.currentTimeMillis()));
        SysUser newdbo = getSecurityDAO().addSysUser(boActionContext, dbo);
        int num = ((Integer)this.userCounts.get("user")).intValue();
        this.userCounts.put("user", Integer.valueOf(num + 1));
        newdbo.setManagerDistrictCuid(managerDistrictCuid);
        getSecurityDAO().updateUserManagerDistrict(boActionContext, newdbo);
        getSecurityObjectBO().refrenceSysUser(newdbo);

        HistoryUserPassword hisPW = new HistoryUserPassword();
        hisPW.setUserCuid(dbo.getCuid());
        hisPW.setUserPassword(dbo.getUserPassword());
        getSecurityDAO().addHistoryUserPassword(boActionContext, hisPW);
        userLockState.put(dbo.getCuid(), Boolean.valueOf(dbo.getIsLocked()));
      }
    }

    Map param = new HashMap();
    param.put("OpType", "AddPrivilege");
    param.put("AppModule", "用户管理");
    param.put("OpText", "通过门户系统增加用户");
    addAuditOptionLog(boActionContext, param);
    return (String)list.get(list.size() - 1);
  }

  public String modifySysuserBy4A(BoActionContext boActionContext, String xmlString)
    throws Exception
  {
    List list = getXmlValueByParam(boActionContext, xmlString, "modifySysuser");
    if ((list != null) && (list.size() > 0)) {
      for (int i = 0; i < list.size() - 1; i++) {
        SysUser dbo = (SysUser)list.get(i);
        String managerDistrictCuid = dbo.getManagerDistrictCuid();
        dbo.setManagerDistrictCuid("");
        dbo.setFlowUser(false);
        dbo.setLastPasswordTime(new Timestamp(System.currentTimeMillis()));
        getSecurityDAO().modifySysUser(boActionContext, dbo);
        dbo.setManagerDistrictCuid(managerDistrictCuid);
        getSecurityDAO().updateUserManagerDistrict(boActionContext, dbo);
        getSecurityObjectBO().refrenceSysUser(dbo);

        boolean isModifyPassword = dbo.getAttrBool("isModifyPassword", false);
        if (isModifyPassword) {
          HistoryUserPassword hisPW = new HistoryUserPassword();
          hisPW.setUserCuid(dbo.getCuid());
          hisPW.setUserPassword(dbo.getUserPassword());
          getSecurityDAO().addHistoryUserPassword(boActionContext, hisPW);
        }
        userLockState.put(dbo.getCuid(), Boolean.valueOf(dbo.getIsLocked()));
      }
    }

    Map param = new HashMap();
    param.put("OpType", "UpdatePrivilege");
    param.put("AppModule", "修改用户");
    param.put("OpText", "通过门户系统修改用户");
    addAuditOptionLog(boActionContext, param);
    return (String)list.get(list.size() - 1);
  }

  public String deleteSysuserBy4A(BoActionContext actionContext, String cuids)
    throws Exception
  {
    SAXBuilder parser = new SAXBuilder();
    InputSource input = new InputSource(new StringReader(cuids));
    LogHome.getLog().info("---------------传进的cuids为--------------" + cuids);
    Element headElement = new Element("delresults");
    Element resultFirst = new Element("result");
    resultFirst.setAttribute("returncode", "1304");
    Element resultSec = new Element("result");
    resultSec.setAttribute("returncode", "1305");
    headElement.addContent(resultFirst);
    headElement.addContent(resultSec);
    try {
      Document document = parser.build(input);
      Element opDetail = document.getRootElement();
      List records = opDetail.getChildren();
      for (Element filed : records)
      {
        String userName = filed.getText();
        if ((userName != null) && (!userName.equals("")) && (!userName.equals("null"))) {
          SysUser user = getSecurityDAO().getSysUserByUserName(actionContext, userName);
          if (user != null) {
            deleteSysUser(actionContext, Long.valueOf(user.getObjectNum()));
          }
          resultFirst.addContent(new Element("accId").addContent(userName));
        } else {
          resultSec.addContent(new Element("accId").addContent(userName));
        }
      }
    } catch (Exception ex) {
      LogHome.getLog().error("解析xml数据失败，xml：" + cuids, ex);
    }
    headElement.addContent(new Element("errorMsg").addContent(""));
    Document myDocument = new Document(headElement);
    Format format = Format.getCompactFormat();
    format.setEncoding("UTF-8");
    format.setIndent("");
    XMLOutputter outputter = new XMLOutputter(format);
    String opDetail = outputter.outputString(myDocument);

    Map param = new HashMap();
    param.put("OpType", "DelPrivilege");
    param.put("AppModule", "删除用户");
    param.put("OpText", "通过门户系统删除用户");
    addAuditOptionLog(actionContext, param);
    return opDetail;
  }

  public void addAuditOptionLog(BoActionContext actionContext, Map param)
    throws UserException
  {
    try
    {
      boolean supportOpLog = false;
      String supportAuditOpLog = getSystemParaBO().getSystemParaValue(actionContext, "Security", "IsSupportAuditOpLog");
      if ((supportAuditOpLog != null) && (supportAuditOpLog.trim().length() > 0)) {
        supportOpLog = Boolean.valueOf(supportAuditOpLog).booleanValue();
      }

      if (supportOpLog) {
        Timestamp nowTime = new Timestamp(System.currentTimeMillis());
        String now_time = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), nowTime);
        String userName = actionContext.getUserName();
        String hostIp = actionContext.getHostIP();
        String opType = (String)param.get("OpType");
        String appModule = (String)param.get("AppModule");
        String opText = (String)param.get("OpText");
        String sql = "INSERT INTO AUDIT_OPLOG(LOGTIME,SUBUSER,APP,SIP,APPMODULE,OPTYPE,OPTEXT) VALUES(" + now_time + ",'" + userName + "','TNMS','" + hostIp + "','" + appModule + "','" + opType + "','" + opText + "')";

        getSecurityDAO().execSql(sql);
      }
    } catch (Exception ex) {
      LogHome.getLog().error("-----------向日志表里增加操作日志失败！-----------------" + ex.getMessage());
    }
  }

  public void addModuleClickLog(BoActionContext actionContext, ModuleClickLog dbo)
    throws UserException
  {
    try
    {
      if (TnmsRuntime.getInstance().equals("WRITE_MODULE_CLICK_LOG", Boolean.TRUE.toString()))
        this.moduleClickLogThreadPool.sendModuleClickLogToThreadPool(dbo);
    }
    catch (Exception ex) {
      LogHome.getLog().error("-----------增加模块点击日志失败！-----------------" + ex);
    }
  }

  public void addModuleClickLog(ModuleClickLog dbo) throws UserException
  {
    try {
      getSecurityDAO().addModuleClickLog(new BoActionContext(), dbo);
    }
    catch (Exception ex) {
      LogHome.getLog().error("-----------增加模块点击日志失败！-----------------" + ex);
    }
  }

  public void addModuleClickLogs(ArrayList<ModuleClickLog> moduleClickLogList) throws UserException {
    if ((moduleClickLogList == null) || (moduleClickLogList.size() == 0)) {
      return;
    }
    for (int i = 0; i < moduleClickLogList.size(); i++) {
      ModuleClickLog moduleClickLog = (ModuleClickLog)moduleClickLogList.get(i);
      addModuleClickLog(moduleClickLog);
    }
  }

  private CommonDAO getCommonDAO()
  {
    return (CommonDAO)super.getDAO("CommonDAO");
  }

  public int getSysUserCounts(BoActionContext actionContext) throws Exception {
    int num = ((Integer)this.userCounts.get("user")).intValue();
    return num;
  }

  public DboCollection getSysUserInfo(BoQueryContext boQueryContext, String userId, String funcCuid, String funcName) throws Exception {
    String sql = "select A.* from FUNCTION_TREE_NODE A, ROLE_CONSIST_OF_FUN_POINT B,USER_HAVE_ROLE C where A.CUID= B.FUNCTION_NODE_CUID and B.ROLE_CUID= C.ROLE_CUID";

    if (userId != null) {
      sql = sql + " and C." + "USER_CUID" + "='" + userId + "'";
    }
    if (funcCuid != null) {
      sql = sql + " and A." + "CUID" + "='" + funcCuid + "'";
    }
    if (funcName != null) {
      sql = sql + " and A." + "NODE_NAME" + "='" + funcName + "'";
    }
    return getSecurityDAO().selectDBOs(boQueryContext, sql, new GenericDO[] { new FunctionTreeNode() });
  }

  public int queryIsExistData(String date)
    throws UserException
  {
    int result = 0;
    try {
      SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
      Date sdate = sdf.parse(date);
      String ssdate = sdf.format(sdate) + " 00:00:00";
      LogHome.getLog().info("========ssdate=" + ssdate);

      String sql = "SELECT USER_COUNT FROM online_user_count where (to_date(substr(new_date,1,10),'%Y-%m-%d')) = '" + ssdate + "'";
      Class[] types = { Integer.TYPE };
      LogHome.getLog().info("方法queryIsExistData中的sql=" + sql);
      DataObjectList dbos = getSecurityDAO().selectDBOs(sql, types);
      if ((dbos != null) && (dbos.size() > 0)) {
        GenericDO dbo = (GenericDO)dbos.get(0);
        return dbo.getAttrInt("1");
      }

      return result;
    }
    catch (Exception e) {
      LogHome.getLog().info("方法queryIsExistData出错", e);
    }
    return result;
  }

  public void insertOnlineUserCount(int max, String date)
    throws UserException
  {
    try
    {
      String sql = "INSERT INTO ONLINE_USER_COUNT (NEW_DATE,USER_COUNT) VALUES('" + date + "','" + max + "')";
      LogHome.getLog().info("方法insertOnlineUserCount中的sql=" + sql);
      getSecurityDAO().execSql(sql);
    } catch (Exception e) {
      LogHome.getLog().info("方法insertOnlineUserCount出错", e);
    }
  }

  public void updateOnlineUserCountByDate(int max, String date)
    throws UserException
  {
    try
    {
      SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
      Date sdate = sdf.parse(date);
      String ssdate = sdf.format(sdate) + " 00:00:00";
      LogHome.getLog().info("========ssdate=" + ssdate);
      String sql = "UPDATE ONLINE_USER_COUNT set user_count='" + max + "',new_date='" + date + "' WHERE (to_date(substr(new_date,1,10),'%Y-%m-%d')) = '" + ssdate + "'";
      LogHome.getLog().info("方法updateOnlineUserCountByDate中的sql=" + sql);
      getSecurityDAO().execSql(sql);
    } catch (Exception e) {
      LogHome.getLog().info("方法updateOnlineUserCountByDate出错", e);
    }
  }

  public DataObjectList checkFunctionPermissions(BoQueryContext boQueryContext, String functionTreeNodeId, String userId) throws Exception {
    String sql = "select distinct A.cuid from FUNCTION_TREE_NODE A, ROLE_CONSIST_OF_FUN_POINT B,USER_HAVE_ROLE C where A.CUID= B.FUNCTION_NODE_CUID and B.ROLE_CUID= C.ROLE_CUID";

    if (userId != null) {
      sql = sql + " and C." + "USER_CUID" + "='" + userId + "'";
    }
    if (functionTreeNodeId != null) {
      sql = sql + " and A." + "CUID" + " in (" + functionTreeNodeId + ")";
    }
    DataObjectList dbos = getSecurityDAO().checkFunctionPermissions(sql);
    LogHome.getLog().info("用户权限检查====dbos.size" + dbos.size());
    return dbos;
  }

  public DataObjectList getOrganization(String relatedDistrictCuid) throws Exception {
    DataObjectList dbos = getSecurityDAO().getOrganization(relatedDistrictCuid);
    return dbos;
  }
}