package com.boco.transnms.server.bo.user.sec;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.District;
import com.boco.transnms.common.dto.Room;
import com.boco.transnms.common.dto.Site;
import com.boco.transnms.common.dto.SysUser;
import com.boco.transnms.common.dto.TransElement;
import com.boco.transnms.common.dto.TransPath;
import com.boco.transnms.common.dto.Traph;
import com.boco.transnms.common.dto.UserHaveObject;
import com.boco.transnms.common.dto.Vp;
import com.boco.transnms.common.dto.VpGroup;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.base.IBoActionContext;
import com.boco.transnms.common.dto.base.IBoQueryContext;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.StateBO;
import com.boco.transnms.server.bo.ibo.IObjectSecurityBO;
import com.boco.transnms.server.bo.system.relatedobject.RelatedObjXmlModel;
import com.boco.transnms.server.dao.base.DaoHelper;
import com.boco.transnms.server.dao.user.sec.SecurityObjectDAO;
import com.boco.transnms.xsdmap.relatedobject.ObjectRelationListType;
import com.boco.transnms.xsdmap.relatedobject.ObjectRelationType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;

@StateBO(serverName="COMMON")
public class SecurityObjectBO extends AbstractBO
  implements IObjectSecurityBO
{
  private static final String TRAIL_SEPARATE = "-";
  private Map<String, UserClassNode> objectRelationTree = new HashMap();
  private Map<String, List<NodeTrail>> objectTrail = new HashMap();
  private Map<String, SysUser> sysUsers = new HashMap();

  public void initBO()
    throws Exception
  {
    if (!getSecurityObjectDAO().isAlreadyCreateTable()) {
      getSecurityObjectDAO().createCacheUserHaveObjectTable();
      getSecurityObjectDAO().cacheAllUserHaveObjects();
    }
    initObjectRelationTree();
    initObjectTrail();
    initSysUsers();
  }

  private void initObjectRelationTree()
    throws Exception
  {
    RelatedObjXmlModel xmlmodel = new RelatedObjXmlModel("xmlmodel/user-object-relation.xml");
    List objRelationList = xmlmodel.getQueryRootModel().getObjectRelationList();
    for (ObjectRelationType objRelation : objRelationList) {
      String theNodeClassName = objRelation.getClassName().trim();
      String districtFieldName = objRelation.getBoName().trim();
      UserClassNode userClassNode = (UserClassNode)this.objectRelationTree.get(theNodeClassName);
      if (userClassNode == null) {
        userClassNode = new UserClassNode(theNodeClassName, districtFieldName);
        this.objectRelationTree.put(theNodeClassName, userClassNode);
      }

      String parentClassPairs = objRelation.getParentClassNames();
      if ((parentClassPairs != null) && (parentClassPairs.trim().length() > 0)) {
        String[] parentClassPairsList = parentClassPairs.split(",");
        for (String parentClassPair : parentClassPairsList) {
          parentClassPair = parentClassPair.replace(".", "-");
          String[] pairs = parentClassPair.split("-");
          String parentClassName = pairs[0].trim();
          String relatedParentFieldName = pairs[1].trim();
          if (!userClassNode.parentNodes.containsKey(parentClassName)) {
            RelatedClassNode relatedNode = new RelatedClassNode(relatedParentFieldName, parentClassName);
            userClassNode.parentNodes.put(parentClassName, relatedNode);
          }
        }
      }

      String childClassPairs = objRelation.getChildClassNames();
      if ((childClassPairs != null) && (childClassPairs.trim().length() > 0)) {
        String[] childClassPairsList = childClassPairs.split(",");
        for (String childClassPair : childClassPairsList) {
          childClassPair = childClassPair.replace(".", "-");
          String[] pairs = childClassPair.split("-");
          String childClassName = pairs[0].trim();
          String relatedParentFieldName = pairs[1].trim();
          UserClassNode childUserClassNode = (UserClassNode)this.objectRelationTree.get(childClassName);
          if (childUserClassNode == null) {
            childUserClassNode = new UserClassNode(childClassName, null);
            this.objectRelationTree.put(childClassName, childUserClassNode);
          }

          if (!childUserClassNode.parentNodes.containsKey(theNodeClassName)) {
            RelatedClassNode relatedNode = new RelatedClassNode(relatedParentFieldName, theNodeClassName);
            childUserClassNode.parentNodes.put(theNodeClassName, relatedNode);
          }
        }
      }
    }
  }

  private void initObjectTrail() {
    for (UserClassNode userClassNode : this.objectRelationTree.values()) {
      List trails = new ArrayList();
      for (RelatedClassNode parentNode : userClassNode.parentNodes.values()) {
        patchTrail(parentNode, "-", trails, 0);
      }
      this.objectTrail.put(userClassNode.className, trails);
    }
  }

  private void patchTrail(RelatedClassNode parentNode, String trail, List<NodeTrail> trails, int nodeCount)
  {
    UserClassNode parentUserClassNode = (UserClassNode)this.objectRelationTree.get(parentNode.relatedClassName);
    if (trail.equals("-"))
      trail = new StringBuilder().append(trail).append(parentNode.relatedClassName).toString();
    else {
      trail = new StringBuilder().append(trail).append("-").append(parentNode.relatedClassName).toString();
    }
    nodeCount++;
    if (parentUserClassNode.parentNodes.size() == 0) {
      NodeTrail nodeTrail = new NodeTrail(trail, nodeCount);
      trails.add(nodeTrail);
    } else {
      for (RelatedClassNode upNode : parentUserClassNode.parentNodes.values())
        patchTrail(upNode, trail, trails, nodeCount);
    }
  }

  private void initSysUsers() throws Exception
  {
    DboCollection dbos = getSecurityObjectDAO().getAllSysUsers();
    for (int i = 0; i < dbos.size(); i++) {
      SysUser user = (SysUser)dbos.getQueryDbo(i, "SYS_USER");
      this.sysUsers.put(user.getCuid(), user);
    }
  }

  public void refrenceSysUser(SysUser user)
    throws Exception
  {
    this.sysUsers.put(user.getCuid(), user);
    getSecurityObjectDAO().cacheUserHaveObjects(user.getCuid());
  }

  public void deleteSysUser(SysUser user) throws Exception
  {
    this.sysUsers.remove(user.getCuid());
    getSecurityObjectDAO().cacheUserHaveObjects(user.getCuid());
  }

  public SysUser getSysUser(String userId) {
    return (SysUser)this.sysUsers.get(userId);
  }

  public String getQueryFilterSqlAndCardKind(BoActionContext actionContext, String queryClassName, String sqlPrefix, String districtFieldName, String districtCuid, boolean isIncludeSubDistrict, String serviceLevelFieldName)
    throws UserException
  {
    if ((actionContext == null) || (actionContext.getUserId() == null) || (actionContext.isActionChecked())) {
      return "";
    }
    String userId = actionContext.getUserId();

    if ("SYS_USER-0".equals(userId)) {
      return "";
    }

    LogHome.getLog().info(new StringBuilder().append("开始查询用户安全检查[userId=").append(userId).append(", actionName=").append(actionContext.getActionName()).append(", districtFieldName=").append(districtFieldName).append(", serviceLevelFieldName=").append(serviceLevelFieldName).append("]").toString());

    String sqlCond = "";
    if (!isIncludeSubDistrict) {
      if ((districtFieldName != null) && (districtFieldName.trim().length() > 0)) {
        String[] distcuids = districtCuid.split(",");
        if (distcuids.length > 1) {
          sqlCond = new StringBuilder().append(sqlCond).append(" (").toString();
          for (int i = 0; i < distcuids.length; i++) {
            if (i == 0)
              sqlCond = new StringBuilder().append(sqlCond).append(" T.").append(districtFieldName).append("='").append(distcuids[i]).append("'").toString();
            else {
              sqlCond = new StringBuilder().append(sqlCond).append(" OR T.").append(districtFieldName).append("='").append(distcuids[i]).append("'").toString();
            }
          }
          sqlCond = new StringBuilder().append(sqlCond).append(") ").toString();
        } else {
          sqlCond = new StringBuilder().append(sqlCond).append(" T.").append(districtFieldName).append("='").append(districtCuid).append("'").toString();
        }
      }
    }
    else if ((districtFieldName != null) && (districtFieldName.trim().length() > 0)) {
      String[] distcuids = districtCuid.split(",");
      if (distcuids.length > 1) {
        sqlCond = new StringBuilder().append(sqlCond).append(" (").toString();
        for (int i = 0; i < distcuids.length; i++) {
          if (i == 0)
            sqlCond = new StringBuilder().append(sqlCond).append(" T.").append(districtFieldName).append(" LIKE '").append(distcuids[i]).append("%'").toString();
          else {
            sqlCond = new StringBuilder().append(sqlCond).append(" OR T.").append(districtFieldName).append(" LIKE '").append(distcuids[i]).append("%'").toString();
          }
        }
        sqlCond = new StringBuilder().append(sqlCond).append(") ").toString();
      } else {
        sqlCond = new StringBuilder().append(sqlCond).append(" T.").append(districtFieldName).append(" LIKE '").append(districtCuid).append("%'").toString();
      }
    }

    String andFlag = "";
    if (sqlCond.trim().length() == 0)
      andFlag = "";
    else {
      andFlag = " and ";
    }

    if ((serviceLevelFieldName != null) && (serviceLevelFieldName.trim().length() > 0)) {
      long serviceLevel = getUserServiceLevel(userId);
      SysUser user = (SysUser)this.sysUsers.get(userId);
      String newUserLevel = user.getNewUserLevel();
      if ((newUserLevel.indexOf("2") >= 0) || (newUserLevel.indexOf("4") >= 0) || (newUserLevel.indexOf("5") >= 0) || (newUserLevel.indexOf("6") >= 0)) {
        newUserLevel = new StringBuilder().append(newUserLevel).append(",3").toString();
      }
      sqlCond = new StringBuilder().append(sqlCond).append(" ").append(andFlag).append(" ").append(serviceLevelFieldName).append(" IN (").append(newUserLevel).append(")").toString();
    }

    if (sqlCond.trim().length() == 0)
      andFlag = "";
    else {
      andFlag = " and ";
    }

    String sqlPrefixStatic = "T";
    if (isUserObjectDistrict(userId, districtCuid)) {
      String sql = getObjectCuidOfDistrict(userId, queryClassName, sqlPrefixStatic, districtCuid, isIncludeSubDistrict);
      if ((sql != null) && (sql.trim().length() > 0)) {
        sqlCond = new StringBuilder().append(sqlCond).append(" ").append(andFlag).append(" ").append(sql).toString();
      }
    }

    LogHome.getLog().info(new StringBuilder().append("结束查询用户安全检查[sqlCond=").append(sqlCond).append("]").toString());
    return sqlCond;
  }

  public String getQueryFilterSql(BoActionContext actionContext, String queryClassName, String sqlPrefix, String districtFieldName, String districtCuid, boolean isIncludeSubDistrict, String serviceLevelFieldName)
    throws UserException
  {
    if ((actionContext == null) || (actionContext.getUserId() == null) || (actionContext.isActionChecked())) {
      return "";
    }
    String userId = actionContext.getUserId();

    if ("SYS_USER-0".equals(userId)) {
      return "";
    }

    LogHome.getLog().info(new StringBuilder().append("开始查询用户安全检查[userId=").append(userId).append(", actionName=").append(actionContext.getActionName()).append(", districtFieldName=").append(districtFieldName).append(", serviceLevelFieldName=").append(serviceLevelFieldName).append("]").toString());

    String sqlCond = "";
    if (!isIncludeSubDistrict) {
      if ((districtFieldName != null) && (districtFieldName.trim().length() > 0)) {
        String[] distcuids = districtCuid.split(",");
        if (distcuids.length > 1) {
          sqlCond = new StringBuilder().append(sqlCond).append(" (").toString();
          for (int i = 0; i < distcuids.length; i++) {
            if (i == 0)
              sqlCond = new StringBuilder().append(sqlCond).append(" ").append(districtFieldName).append("='").append(distcuids[i]).append("'").toString();
            else {
              sqlCond = new StringBuilder().append(sqlCond).append(" OR ").append(districtFieldName).append("='").append(distcuids[i]).append("'").toString();
            }
          }
          sqlCond = new StringBuilder().append(sqlCond).append(") ").toString();
        } else {
          sqlCond = new StringBuilder().append(sqlCond).append(" ").append(districtFieldName).append("='").append(districtCuid).append("'").toString();
        }
      }
    }
    else if ((districtFieldName != null) && (districtFieldName.trim().length() > 0)) {
      String[] distcuids = districtCuid.split(",");
      if (distcuids.length > 1) {
        sqlCond = new StringBuilder().append(sqlCond).append(" (").toString();
        for (int i = 0; i < distcuids.length; i++) {
          if (i == 0)
            sqlCond = new StringBuilder().append(sqlCond).append(" ").append(districtFieldName).append(" LIKE '").append(distcuids[i]).append("%'").toString();
          else {
            sqlCond = new StringBuilder().append(sqlCond).append(" OR ").append(districtFieldName).append(" LIKE '").append(distcuids[i]).append("%'").toString();
          }
        }
        sqlCond = new StringBuilder().append(sqlCond).append(") ").toString();
      } else {
        sqlCond = new StringBuilder().append(sqlCond).append(" ").append(districtFieldName).append(" LIKE '").append(districtCuid).append("%'").toString();
      }
    }

    String andFlag = "";
    if (sqlCond.trim().length() == 0)
      andFlag = "";
    else {
      andFlag = " and ";
    }

    if ((serviceLevelFieldName != null) && (serviceLevelFieldName.trim().length() > 0)) {
      long serviceLevel = getUserServiceLevel(userId);
      SysUser user = (SysUser)this.sysUsers.get(userId);
      String newUserLevel = user.getNewUserLevel();
      if ((newUserLevel.indexOf("2") >= 0) || (newUserLevel.indexOf("4") >= 0) || (newUserLevel.indexOf("5") >= 0) || (newUserLevel.indexOf("6") >= 0)) {
        newUserLevel = new StringBuilder().append(newUserLevel).append(",3").toString();
      }
      sqlCond = new StringBuilder().append(sqlCond).append(" ").append(andFlag).append(" ").append(serviceLevelFieldName).append(" IN (").append(newUserLevel).append(")").toString();
    }

    if (sqlCond.trim().length() == 0)
      andFlag = "";
    else {
      andFlag = " and ";
    }

    if (isUserObjectDistrict(userId, districtCuid)) {
      String sql = "";
      if (sqlPrefix.trim().length() > 0)
        sql = getObjectCuidOfDistrict(userId, queryClassName, sqlPrefix, districtCuid, isIncludeSubDistrict);
      else {
        sql = getObjectCuidOfDistrict(userId, queryClassName, queryClassName, districtCuid, isIncludeSubDistrict);
      }
      if ((sql != null) && (sql.trim().length() > 0)) {
        sqlCond = new StringBuilder().append(sqlCond).append(" ").append(andFlag).append(" ").append(sql).toString();
      }
    }

    LogHome.getLog().info(new StringBuilder().append("结束查询用户安全检查[sqlCond=").append(sqlCond).append("]").toString());
    return sqlCond;
  }

  public void isObjectPermitEdit(IBoActionContext actionContext, GenericDO object) throws Exception {
    if ((actionContext == null) || (actionContext.getUserId() == null) || (actionContext.getActionName() == null) || (actionContext.isActionChecked()))
    {
      return;
    }

    if ("SYS_USER-0".equals(actionContext.getUserId())) {
      return;
    }

    String userId = actionContext.getUserId();
    String actionName = actionContext.getActionName();
    LogHome.getLog().info(new StringBuilder().append("开始编辑用户权限校验[userId=").append(userId).append(", actionName=").append(actionName).append(", className=").append(object.getClassName()).append(", objectId=").append(object.getObjectNum()).append(", CUID=").append(object.getCuid()).append("]").toString());

    String cuid = object.getCuid();
    if ((cuid == null) && (object.getObjectNum() != 0L)) {
      GenericDO _dbo = new GenericDO();
      _dbo.setObjectNum(object.getObjectNum());
      getSecurityObjectDAO().getObject(_dbo);
      object.setCuid(_dbo.getCuid());
    }

    boolean isSpecialObject = checkSpecialObject(actionContext, object);

    if (!isSpecialObject) {
      String districtCuid = getObjectDistrictCuid(object);
      if (districtCuid == null) {
        LogHome.getLog().info(new StringBuilder().append("相关的区域CUID为空[className=").append(object.getClassName()).append(", objectId=").append(object.getObjectNum()).append("]，无法进行权限校验 ！").toString());

        return;
      }
      boolean isUserObjectDistrict = isUserObjectDistrict(actionContext.getUserId(), districtCuid);
      if (isUserObjectDistrict) {
        boolean isObjectPermitEdit = checkObjectEditRight(userId, districtCuid, object);
        if (!isObjectPermitEdit) {
          LogHome.getLog().info("结束编辑用户对象权限校验");
          throw new UserException("用户没有此对象的编辑权限 ！");
        }
      } else {
        getSecurityBO().isDistrictsPermitted(actionContext, actionContext.getUserId(), actionContext.getActionName(), new String[] { districtCuid });
      }
    }
  }

  protected boolean checkSpecialObject(IBoActionContext actionContext, GenericDO object) throws Exception
  {
    boolean isSpecialObject = true;
    if (object.getClassName().trim().equals("TOPO_LINK"))
    {
      String[] districtCuids = new String[2];
      String neCuid = object.getAttrString("DEST_NE_CUID");
      TransElement ne = new TransElement(neCuid);
      ne = (TransElement)getSecurityObjectDAO().getObjByCuid(ne);
      districtCuids[0] = ne.getRelatedDistrictCuid();
      neCuid = object.getAttrString("ORIG_NE_CUID");
      ne = new TransElement(neCuid);
      ne = (TransElement)getSecurityObjectDAO().getObjByCuid(ne);
      districtCuids[1] = ne.getRelatedDistrictCuid();
      for (int i = 0; i < districtCuids.length; i++) {
        if (districtCuids[i] == null) {
          LogHome.getLog().info(new StringBuilder().append("相关的区域CUID为空[").append(object).append("]，无法进行权限校验 ！").toString());
        } else {
          boolean isUserObjectDistrict = isUserObjectDistrict(actionContext.getUserId(), districtCuids[i]);
          if (isUserObjectDistrict)
          {
            boolean isObjectPermitEdit = checkObjectEditRight(actionContext.getUserId(), districtCuids[i], ne);
            if (!isObjectPermitEdit) {
              LogHome.getLog().info("结束编辑用户对象权限校验");
              throw new UserException("用户没有此对象的编辑权限 ！");
            }
          } else {
            getSecurityBO().isDistrictsPermitted(actionContext, actionContext.getUserId(), actionContext.getActionName(), new String[] { districtCuids[i] });
          }
        }
      }
    }
    else if (object.getClassName().trim().equals("SHELF"))
    {
      String relatedDeviceCuid = object.getAttrString("RELATED_DEVICE_CUID");
      GenericDO rack = null;
      if (relatedDeviceCuid.split("-")[0].trim().equals("RACK")) {
        rack = new GenericDO("RACK");
        rack.setCuid(relatedDeviceCuid);
      } else if (relatedDeviceCuid.split("-")[0].trim().equals("MISCRACK")) {
        rack = new GenericDO("MISCRACK");
        rack.setCuid(relatedDeviceCuid);
      }
      rack = getSecurityObjectDAO().getObjByCuid(rack);
      if (rack != null) {
        String roomCuid = rack.getAttrString("RELATED_ROOM_CUID");
        if ((roomCuid != null) && (roomCuid.trim().length() > 0)) {
          Room room = new Room(roomCuid);
          room = (Room)getSecurityObjectDAO().getObjByCuid(room);
          if (room != null) {
            String siteCuid = room.getRelatedSiteCuid();
            if ((siteCuid != null) && (siteCuid.trim().length() > 0)) {
              Site site = new Site(siteCuid);
              site = (Site)getSecurityObjectDAO().getObjByCuid(site);
              if (site != null) {
                String districtCuid = site.getRelatedSpaceCuid();
                if (districtCuid == null) {
                  LogHome.getLog().info(new StringBuilder().append("相关的区域CUID为空[").append(object).append("]，无法进行权限校验 ！").toString());
                } else {
                  boolean isUserObjectDistrict = isUserObjectDistrict(actionContext.getUserId(), districtCuid);
                  if (isUserObjectDistrict)
                  {
                    boolean isObjectPermitEdit = checkObjectEditRight(actionContext.getUserId(), districtCuid, room);
                    if (!isObjectPermitEdit) {
                      LogHome.getLog().info("结束编辑用户对象权限校验");
                      throw new UserException("用户没有此对象的编辑权限 ！");
                    }
                  } else {
                    getSecurityBO().isDistrictsPermitted(actionContext, actionContext.getUserId(), actionContext.getActionName(), new String[] { districtCuid });
                  }
                }
              }
            }
          }
        }
      }
    }
    else if (object.getClassName().trim().equals("VPN"))
    {
      String relatedCuid = object.getAttrString("RELATED_VP_VPGROUP_CUID");
      String districtCuid = null;
      GenericDO dbo = null;
      if (relatedCuid.split("-")[0].trim().equals("VP")) {
        Vp vp = new Vp(relatedCuid);
        vp.setCuid(relatedCuid);
        vp = (Vp)getSecurityObjectDAO().getObjByCuid(vp);
        districtCuid = vp.getRelatedDistrictCuid();
        dbo = vp;
      } else if (relatedCuid.split("-")[0].trim().equals("VP_GROUP")) {
        VpGroup vpgroup = new VpGroup(relatedCuid);
        vpgroup.setCuid(relatedCuid);
        vpgroup = (VpGroup)getSecurityObjectDAO().getObjByCuid(vpgroup);
        districtCuid = vpgroup.getRelatedDistrictCuid();
        dbo = vpgroup;
      }
      if (districtCuid == null) {
        LogHome.getLog().info(new StringBuilder().append("相关的区域CUID为空[").append(object).append("]，无法进行权限校验 ！").toString());
      } else {
        boolean isUserObjectDistrict = isUserObjectDistrict(actionContext.getUserId(), districtCuid);
        if (isUserObjectDistrict)
        {
          boolean isObjectPermitEdit = checkObjectEditRight(actionContext.getUserId(), districtCuid, dbo);
          if (!isObjectPermitEdit) {
            LogHome.getLog().info("结束编辑用户对象权限校验");
            throw new UserException("用户没有此对象的编辑权限 ！");
          }
        } else {
          getSecurityBO().isDistrictsPermitted(actionContext, actionContext.getUserId(), actionContext.getActionName(), new String[] { districtCuid });
        }
      }
    }
    else if (object.getClassName().trim().equals("TRAPH"))
    {
      String[] districtCuids = new String[2];
      Traph traph = new Traph();
      traph = (Traph)object;
      districtCuids[0] = traph.getRelatedADistrictCuid();
      districtCuids[1] = traph.getRelatedZDistrictCuid();
      boolean flag1 = false;
      boolean flag2 = false;
      for (int i = 0; i < districtCuids.length; i++) {
        if (districtCuids[i] == null) {
          LogHome.getLog().info(new StringBuilder().append("相关的区域CUID为空[").append(object).append("]，无法进行权限校验 ！").toString());
        } else {
          boolean isUserObjectDistrict = isUserObjectDistrict(actionContext.getUserId(), districtCuids[i]);
          if (isUserObjectDistrict)
          {
            boolean isObjectPermitEdit = checkObjectEditRight(actionContext.getUserId(), districtCuids[i], traph);
            if (!isObjectPermitEdit)
              if (i == 0)
                flag1 = true;
              else
                flag2 = true;
          }
          else
          {
            getSecurityBO().isDistrictsPermitted(actionContext, actionContext.getUserId(), actionContext.getActionName(), new String[] { districtCuids[i] });
          }
        }
      }

      if ((flag1 == true) && (flag2 == true)) {
        LogHome.getLog().info("结束编辑用户对象权限校验");
        throw new UserException("用户没有此对象的编辑权限 ！");
      }
    } else if (object.getClassName().trim().equals("TRANS_PATH"))
    {
      String[] districtCuids = new String[2];
      TransPath transPath = (TransPath)object;
      districtCuids[0] = transPath.getRelatedADistrictCuid();
      districtCuids[1] = transPath.getRelatedZDistrictCuid();
      boolean flag1 = false;
      boolean flag2 = false;
      for (int i = 0; i < districtCuids.length; i++) {
        if (districtCuids[i] == null) {
          LogHome.getLog().info(new StringBuilder().append("相关的区域CUID为空[").append(object).append("]，无法进行权限校验 ！").toString());
        } else {
          boolean isUserObjectDistrict = isUserObjectDistrict(actionContext.getUserId(), districtCuids[i]);
          if (isUserObjectDistrict)
          {
            boolean isObjectPermitEdit = checkObjectEditRight(actionContext.getUserId(), districtCuids[i], transPath);
            if (!isObjectPermitEdit)
            {
              LogHome.getLog().info("结束编辑用户对象权限校验");
              throw new UserException("用户没有此对象的编辑权限 ！");
            }
          } else {
            getSecurityBO().isDistrictsPermitted(actionContext, actionContext.getUserId(), actionContext.getActionName(), new String[] { districtCuids[i] });
          }

        }

      }

    }
    else
    {
      isSpecialObject = false;
    }
    return isSpecialObject;
  }

  private boolean checkObjectEditRight(String userId, String districtCuid, GenericDO object) {
    boolean isObjectPermitEdit = true;
    try
    {
      List userObjectClassNames = getUserObjectClassNames(districtCuid, userId);
      boolean isExclude = isUserDistrictExclude(userId, districtCuid);
      if (isExclude)
      {
        isObjectPermitEdit = true;
      }
      else {
        isObjectPermitEdit = false;
      }
      if (userObjectClassNames.contains(object.getClassName())) {
        isObjectPermitEdit = isCuidPermit(userObjectClassNames, isExclude, userId, districtCuid, object.getClassName(), object.getCuid());
      }
      else {
        List trails = getTrailClassNames(userObjectClassNames, object.getClassName());
        boolean isContinueSearch = true;
        if (trails == null) {
          isObjectPermitEdit = true;
        }
        for (int i = 0; (trails != null) && (i < trails.size()) && (isContinueSearch); i++) {
          isContinueSearch = false;
          List parentClassNames = (List)trails.get(i);
          if ((parentClassNames != null) && (parentClassNames.size() > 0)) {
            String theClassName = object.getClassName();

            String cuid = null;
            for (int j = 0; j < parentClassNames.size(); j++) {
              String parentClassName = (String)parentClassNames.get(j);
              UserClassNode userObjectNode = (UserClassNode)this.objectRelationTree.get(theClassName);
              RelatedClassNode parentNode = (RelatedClassNode)userObjectNode.parentNodes.get(parentClassName);
              if (j == 0) {
                cuid = object.getAttrString(parentNode.relatedFieldName);
                if ((cuid == null) && (object.getCuid() != null)) {
                  cuid = getClassFiledValue(theClassName, object.getCuid(), parentNode.relatedFieldName);
                  if ((cuid == null) || (cuid.trim().length() == 0)) {
                    LogHome.getLog().info(new StringBuilder().append("相关的区域CUID为空[").append(object).append("]，无法进行权限校验 ！").toString());
                    return true;
                  }
                }
              } else {
                cuid = getClassFiledValue(theClassName, cuid, parentNode.relatedFieldName);
              }
              if ((cuid != null) && (cuid.trim().length() > 0))
              {
                boolean isCuidPermit = isCuidPermit(userObjectClassNames, isExclude, userId, districtCuid, parentClassName, cuid);

                if (!isCuidPermit) {
                  if (!isExclude)
                  {
                    theClassName = parentClassName;
                  }
                  else
                  {
                    return false;
                  }
                }
                else if (userObjectClassNames.contains(parentClassName))
                {
                  if (!isExclude)
                  {
                    return true;
                  }

                  theClassName = parentClassName;
                }
                else
                {
                  theClassName = parentClassName;
                }

              }
              else
              {
                isContinueSearch = true;
                break;
              }
            }
          }
        }
      }
    } catch (Exception ex) {
      LogHome.getLog().info("", ex);
    }

    return isObjectPermitEdit;
  }

  public void isObjectsPermitEdit(IBoActionContext actionContext, DataObjectList objects) throws Exception
  {
    for (int i = 0; i < objects.size(); i++)
      isObjectPermitEdit(actionContext, (GenericDO)objects.get(i));
  }

  protected boolean isCuidPermit(List<String> userObjClassNames, boolean isExclude, String userId, String districtCuid, String objClassName, String objCuid)
  {
    boolean isCuidPermit = true;
    if (userObjClassNames.contains(objClassName)) {
      boolean isExist = getSecurityObjectDAO().isUserObjectCuidExist(userId, districtCuid, objCuid, true);
      if ((isExist) && (isExclude))
        isCuidPermit = false;
      else if ((!isExist) && (!isExclude)) {
        isCuidPermit = false;
      }
    }
    return isCuidPermit;
  }

  private boolean isUserObjectDistrict(String userId, String districtCuid)
  {
    return getSecurityObjectDAO().isUserObjectDistrict(userId, districtCuid);
  }

  private String getObjectCuidOfDistrict(String userId, String className, String sqlPrefix, String districtCuid, boolean isIncludeSubDistrict)
  {
    String rtnStr = "";
    try {
      String[] discuids = districtCuid.split(",");
      if (discuids.length > 0) {
        if (isIncludeSubDistrict) {
          for (int i = 0; i < discuids.length; i++) {
            if (i == 0)
              districtCuid = new StringBuilder().append("RELATED_DISTRICT_CUID like '").append(discuids[i]).append("%'").toString();
            else
              districtCuid = new StringBuilder().append(districtCuid).append(" or ").append("RELATED_DISTRICT_CUID").append(" like '").append(discuids[i]).append("%'").toString();
          }
        }
        else {
          for (int i = 0; i < discuids.length; i++) {
            if (i == 0)
              districtCuid = new StringBuilder().append("'").append(discuids[i]).append("'").toString();
            else {
              districtCuid = new StringBuilder().append(districtCuid).append(",'").append(discuids[i]).append("'").toString();
            }
          }
        }

      }

      String sql = "select CUID,OBJECT_CLASSNAME,RELATED_DISTRICT_CUID,RELATED_OBJECT_CUID,RELATED_USER_CUID,IS_INCLUDE_CHILD,IS_IN_EX,OBJECT_OPERATION from USER_HAVE_OBJECT";

      String condition = new StringBuilder().append(" where RELATED_USER_CUID='").append(userId).append("'").toString();
      if (isIncludeSubDistrict)
        condition = new StringBuilder().append(condition).append(" and (").append(districtCuid).append(")").toString();
      else {
        condition = new StringBuilder().append(condition).append(" and RELATED_DISTRICT_CUID in (").append(districtCuid).append(")").toString();
      }
      condition = new StringBuilder().append(condition).append(" and OBJECT_CLASSNAME='").append(className).append("'").toString();
      condition = new StringBuilder().append(condition).append(" and OBJECT_OPERATION=1").toString();

      IBoQueryContext context = new BoQueryContext();
      context.setDsName("cacheDB");
      sql = new StringBuilder().append(sql).append(condition).toString();
      DboCollection dbos = getSecurityObjectDAO().selectDBOs(context, sql, new GenericDO[] { new UserHaveObject() });

      sql = new StringBuilder().append("select RELATED_OBJECT_CUID from USER_HAVE_OBJECT").append(condition).toString();

      if ((dbos != null) && (dbos.size() > 0)) {
        rtnStr = new StringBuilder().append(rtnStr).append(sqlPrefix).append(".CUID ").toString();
        UserHaveObject dbo = (UserHaveObject)dbos.getQueryDbo(0, "USER_HAVE_OBJECT");
        if (dbo.getIsInEx())
          rtnStr = new StringBuilder().append(rtnStr).append(" NOT IN (").append(sql).append(")").toString();
        else
          rtnStr = new StringBuilder().append(rtnStr).append(" IN (").append(sql).append(")").toString();
      }
      else
      {
        return "";
      }
    }
    catch (Exception ex) {
      LogHome.getLog().info("", ex);
    }
    return rtnStr;
  }

  private String getObjectCuidOfDistrict(String userId, String className, String sqlPrefix, String districtCuid)
  {
    String rtnStr = "";
    try {
      boolean isExclude = true;
      String[] discuids = districtCuid.split(",");
      if (discuids.length > 0) {
        for (int i = 0; i < discuids.length; i++) {
          if (i == 0)
            districtCuid = new StringBuilder().append("'").append(discuids[i]).append("'").toString();
          else {
            districtCuid = new StringBuilder().append(districtCuid).append(",'").append(discuids[i]).append("'").toString();
          }
        }
      }
      DboCollection dbos = getSecurityObjectDAO().getDistrictObjects(userId, districtCuid, className);
      String cuids = "";
      for (int i = 0; i < dbos.size(); i++) {
        UserHaveObject dbo = (UserHaveObject)dbos.getQueryDbo(i, "USER_HAVE_OBJECT");
        if (i == 0)
          cuids = new StringBuilder().append("'").append(dbo.getRelatedObjectCuid()).append("'").toString();
        else {
          cuids = new StringBuilder().append(cuids).append(",'").append(dbo.getCuid()).append("'").toString();
        }
        isExclude = dbo.getIsInEx();
      }

      if (cuids.trim().length() == 0) {
        return "";
      }

      String sqlCuids = new StringBuilder().append(sqlPrefix).append(".CUID ").toString();
      if (isExclude)
        sqlCuids = new StringBuilder().append(sqlCuids).append(" NOT IN (").append(cuids).append(")").toString();
      else {
        sqlCuids = new StringBuilder().append(sqlCuids).append(" IN (").append(cuids).append(")").toString();
      }
      rtnStr = sqlCuids;
    } catch (Exception ex) {
      LogHome.getLog().info("", ex);
    }
    return rtnStr;
  }

  private long getUserServiceLevel(String userId)
  {
    SysUser user = (SysUser)this.sysUsers.get(userId);
    return user.getUserLevel();
  }

  private String getObjectDistrictCuid(GenericDO object)
  {
    String districtCuid = null;
    try {
      String className = object.getClassName();
      UserClassNode userClassNode = (UserClassNode)this.objectRelationTree.get(className);
      if (userClassNode == null) {
        return null;
      }

      String districtFieldName = userClassNode.districtFieldName;
      if ((districtFieldName != null) && (districtFieldName.trim().length() > 0)) {
        districtCuid = object.getAttrString(districtFieldName);
        if (districtCuid == null)
          if (object.getObjectNum() > 0L) {
            GenericDO dbo = new GenericDO();
            dbo.setObjectNum(object.getObjectNum());
            getSecurityObjectDAO().getObject(dbo);
            districtCuid = dbo.getAttrString(districtFieldName);
          } else {
            LogHome.getLog().info(new StringBuilder().append("添加的对象[").append(object).append("]的所属的区域ID为空，无法进行对象权限校验！").toString());
          }
      }
      else {
        List districtRelatedNodes = new ArrayList();
        getObjectDistrictTree(userClassNode, districtRelatedNodes);
        String cuid = object.getCuid();

        String queryClassName = userClassNode.className;
        for (int i = 0; i < districtRelatedNodes.size(); i++) {
          String queryFieldName = ((RelatedClassNode)districtRelatedNodes.get(i)).relatedFieldName;
          if (cuid != null) {
            cuid = getClassFiledValue(queryClassName, cuid, queryFieldName);
            if (cuid == null)
            {
              cuid = object.getAttrString(queryFieldName);
            }
          } else {
            cuid = object.getAttrString(queryFieldName);
          }
          queryClassName = ((RelatedClassNode)districtRelatedNodes.get(i)).relatedClassName;
        }

        String lastClassName = ((RelatedClassNode)districtRelatedNodes.get(districtRelatedNodes.size() - 1)).relatedClassName;
        districtFieldName = ((UserClassNode)this.objectRelationTree.get(lastClassName)).districtFieldName;
        districtCuid = getClassFiledValue(lastClassName, cuid, districtFieldName);
      }
    } catch (Exception ex) {
      LogHome.getLog().info("", ex);
      districtCuid = null;
    }

    return districtCuid;
  }

  protected List<String> getUserObjectClassNames(String districtCuid, String userId) {
    List classNameList = new ArrayList();
    try {
      DboCollection dbos = getSecurityObjectDAO().getUserObjectClassNames(districtCuid, userId);
      for (int i = 0; i < dbos.size(); i++) {
        UserHaveObject dbo = (UserHaveObject)dbos.getQueryDbo(i, "USER_HAVE_OBJECT");
        classNameList.add(dbo.getObjectClassname());
      }
    } catch (Exception ex) {
      LogHome.getLog().info("", ex);
    }
    return classNameList;
  }

  private List<List<String>> getTrailClassNames(List<String> userObjClassNames, String className) {
    List trailList = new ArrayList();
    List trails = (List)this.objectTrail.get(className);
    if (trails == null) {
      return null;
    }
    int[] marks = new int[trails.size()];
    int totalMark = 0;
    String trail;
    for (int i = 0; i < trails.size(); i++) {
      trail = ((NodeTrail)trails.get(i)).trail;
      for (String objClassName : userObjClassNames) {
        if (trail.indexOf(new StringBuilder().append("-").append(objClassName).toString()) >= 0) {
          marks[i] += 1;
          totalMark++;
        }
      }
    }

    if (totalMark == 0) {
      return null;
    }

    int maxMark = 0;
    int perfectIndex = 0;
    for (int i = 0; i < marks.length; i++) {
      if (marks[i] != 0)
      {
        if (marks[i] == maxMark)
        {
          if (((NodeTrail)trails.get(i)).nodeCount > ((NodeTrail)trails.get(perfectIndex)).nodeCount)
            perfectIndex = i;
        }
        else if (marks[i] > maxMark) {
          maxMark = marks[i];
          perfectIndex = i;
        }
      }
    }
    for (int k = 0; k < trails.size(); k++) {
      String perfectTrail = ((NodeTrail)trails.get(k)).trail;
      List trailNodeList = new ArrayList();
      String[] trailNodes = perfectTrail.split("-");
      for (int i = 1; i < trailNodes.length; i++) {
        trailNodeList.add(trailNodes[i]);
      }

      if (k == perfectIndex)
        trailList.add(0, trailNodeList);
      else {
        trailList.add(trailNodeList);
      }
    }

    return trailList;
  }

  private String getClassFiledValue(String className, String cuid, String classFieldName) throws Exception {
    return getSecurityObjectDAO().getClassFieldValue(className, cuid, classFieldName);
  }

  private void getObjectDistrictTree(UserClassNode startNode, List<RelatedClassNode> districtRelatedNodes)
  {
    for (RelatedClassNode parentNode : startNode.parentNodes.values())
    {
      if (districtRelatedNodes.size() > 0) {
        return;
      }

      UserClassNode upNode = (UserClassNode)this.objectRelationTree.get(parentNode.relatedClassName);
      if (upNode.districtFieldName == null) {
        getObjectDistrictTree(upNode, districtRelatedNodes);
        if (districtRelatedNodes.size() > 0)
          districtRelatedNodes.add(0, parentNode);
      }
      else {
        districtRelatedNodes.add(parentNode);
      }
    }
  }

  protected boolean isUserDistrictExclude(String userId, String districtCuid) throws Exception {
    return getSecurityObjectDAO().isUserDistrictExclude(userId, districtCuid);
  }

  private SecurityBO getSecurityBO() {
    return (SecurityBO)super.getBO("ISecurityBO");
  }

  private SecurityObjectDAO getSecurityObjectDAO() {
    return (SecurityObjectDAO)super.getDAO("SecurityObjectDAO");
  }

  public String getQueryFilterSqlToEMS(IBoActionContext actionContext, Map param)
    throws Exception
  {
    if ((actionContext == null) || (actionContext.getUserId() == null)) {
      return "";
    }
    String userId = actionContext.getUserId();

    if ((!DaoHelper.isNotEmpty(userId)) || ("SYS_USER-0".equals(userId))) {
      return "";
    }

    LogHome.getLog().info(new StringBuilder().append("开始EMS权限过滤检查[userId=").append(userId).append(", param.toString=").append(param == null ? "'null'" : param.toString()).append("]").toString());

    String sqlCond = "";
    String attrName = "RELATED_SPACE_CUID";
    if ((param != null) && 
      (param.containsKey("ALIAS"))) {
      attrName = new StringBuilder().append(String.valueOf(param.get("ALIAS"))).append(".").append("RELATED_SPACE_CUID").toString();
    }

    List includeDisList = new ArrayList();
    List disList = new ArrayList();
    DataObjectList disDbos = getSecurityBO().getUserDistricts(new BoActionContext(), userId);
    List tempList = new ArrayList();
    if ((disDbos != null) && (disDbos.size() > 0))
    {
      for (int i = 0; i < disDbos.size(); i++) {
        District dis = (District)disDbos.get(i);
        if (dis.getAttrBool("IS_INCLUDE_SUB_DISTRICT"))
          includeDisList.add(dis.getCuid());
        else {
          tempList.add(dis.getCuid());
        }
      }

      boolean flag = true;
      for (int i = 0; i < tempList.size(); i++) {
        flag = true;
        String temp = (String)tempList.get(i);
        if (temp.length() > 13) {
          for (int j = 14; j < temp.length(); ) {
            String parentDis = temp.substring(0, j);
            if (includeDisList.contains(parentDis)) {
              flag = false;
              break;
            }
            j += 6;
          }
          if (flag) {
            disList.add(temp);
          }
        }

      }

      DaoHelper.getInstance(); String includeDisStr = DaoHelper.getArrayListToStr(includeDisList);
      if (DaoHelper.isNotEmpty(includeDisStr)) {
        String temp = new StringBuilder().append("%' OR ").append(attrName).append(" LIKE '").toString();
        sqlCond = new StringBuilder().append(attrName).append(" LIKE '").append(includeDisStr.replaceAll(",", temp)).append("%'").toString();
      }

      DaoHelper.getInstance(); String disStr = DaoHelper.getArrayListToStr(disList);
      if (DaoHelper.isNotEmpty(disStr)) {
        String temp = new StringBuilder().append("' OR ").append(attrName).append("='").toString();
        if (DaoHelper.isNotEmpty(sqlCond))
          sqlCond = new StringBuilder().append(sqlCond).append(" OR ").append(attrName).append("='").append(disStr.replaceAll(",", temp)).append("'").toString();
        else {
          sqlCond = new StringBuilder().append(attrName).append("='").append(disStr.replaceAll(",", temp)).append("'").toString();
        }
      }
    }

    if (DaoHelper.isNotEmpty(sqlCond)) {
      sqlCond = new StringBuilder().append(" AND( ").append(sqlCond).append(" ) ").toString();
    }

    LogHome.getLog().info(new StringBuilder().append("结束EMS权限过滤检查[sqlCond=").append(sqlCond).append("]").toString());
    return sqlCond;
  }

  public String getQueryFilterSqlToSubNet(IBoActionContext actionContext, Map param)
    throws Exception
  {
    String queryFilter = "";
    String funcDisAttrName = "RELATED_DISTRICT_CUID";
    String secObjAttrName = "CUID";
    if ((param != null) && 
      (param.containsKey("ALIAS"))) {
      funcDisAttrName = new StringBuilder().append(String.valueOf(param.get("ALIAS"))).append(".").append("RELATED_DISTRICT_CUID").toString();
      secObjAttrName = new StringBuilder().append(String.valueOf(param.get("ALIAS"))).append(".").append("CUID").toString();
    }

    String funcDisQueryFilterSql = "";
    if ((param == null) || (!param.containsKey("DISTRICT")) || (!DaoHelper.isNotEmpty(String.valueOf(param.get("DISTRICT"))))) {
      funcDisQueryFilterSql = getFuncDisQueryFilterSql(actionContext, funcDisAttrName, "子网", param);
    }
    String secObjQueryFilterSql = getSecObjQueryFilterSql(actionContext, secObjAttrName, "TRANS_SUB_NETWORK", "子网", param);

    if (DaoHelper.isNotEmpty(funcDisQueryFilterSql)) {
      queryFilter = funcDisQueryFilterSql.substring(4, funcDisQueryFilterSql.length());
      if (DaoHelper.isNotEmpty(secObjQueryFilterSql)) {
        queryFilter = new StringBuilder().append(queryFilter).append(secObjQueryFilterSql).toString();
      }
    }
    else if (DaoHelper.isNotEmpty(secObjQueryFilterSql)) {
      queryFilter = secObjQueryFilterSql.substring(4, secObjQueryFilterSql.length());
    }

    if (DaoHelper.isNotEmpty(queryFilter)) {
      queryFilter = new StringBuilder().append(" AND(").append(queryFilter.trim()).append(") ").toString();
    }

    LogHome.getLog().info(new StringBuilder().append("结束子网权限过滤检查[queryFilter=").append(queryFilter).append("]").toString());
    return queryFilter;
  }

  private String getFuncDisQueryFilterSql(IBoActionContext actionContext, String attrName, String objName, Map param)
    throws Exception
  {
    if ((actionContext == null) || (actionContext.getUserId() == null)) {
      return "";
    }
    String userId = actionContext.getUserId();

    if ((!DaoHelper.isNotEmpty(userId)) || ("SYS_USER-0".equals(userId))) {
      return "";
    }

    if (!DaoHelper.isNotEmpty(attrName)) {
      return "";
    }

    LogHome.getLog().info(new StringBuilder().append("开始[").append(objName).append("]区域权限过滤检查[userId=").append(userId).append(", param.toString=").append(param == null ? "'null'" : param.toString()).append("]").toString());

    String districtFilter = "";

    List includeDisList = new ArrayList();
    List disList = new ArrayList();
    DataObjectList disDbos = getSecurityBO().getUserDistricts(new BoActionContext(), userId);
    List tempList = new ArrayList();
    if ((disDbos != null) && (disDbos.size() > 0))
    {
      for (int i = 0; i < disDbos.size(); i++) {
        District dis = (District)disDbos.get(i);
        if (dis.getAttrBool("IS_INCLUDE_SUB_DISTRICT"))
          includeDisList.add(dis.getCuid());
        else {
          tempList.add(dis.getCuid());
        }
      }

      boolean flag = true;
      for (int i = 0; i < tempList.size(); i++) {
        flag = true;
        String temp = (String)tempList.get(i);
        if (temp.length() > 13) {
          for (int j = 14; j < temp.length(); ) {
            String parentDis = temp.substring(0, j);
            if (includeDisList.contains(parentDis)) {
              flag = false;
              break;
            }
            j += 6;
          }
          if (flag) {
            disList.add(temp);
          }
        }

      }

      DaoHelper.getInstance(); String includeDisStr = DaoHelper.getArrayListToStr(includeDisList);
      if (DaoHelper.isNotEmpty(includeDisStr)) {
        String temp = new StringBuilder().append("%' OR ").append(attrName).append(" LIKE '").toString();
        districtFilter = new StringBuilder().append(attrName).append(" LIKE '").append(includeDisStr.replaceAll(",", temp)).append("%'").toString();
      }

      DaoHelper.getInstance(); String disStr = DaoHelper.getArrayListToStr(disList);
      if (DaoHelper.isNotEmpty(disStr)) {
        String temp = new StringBuilder().append("' OR ").append(attrName).append("='").toString();
        if (DaoHelper.isNotEmpty(districtFilter))
          districtFilter = new StringBuilder().append(districtFilter).append(" OR ").append(attrName).append("='").append(disStr.replaceAll(",", temp)).append("'").toString();
        else {
          districtFilter = new StringBuilder().append(attrName).append("='").append(disStr.replaceAll(",", temp)).append("'").toString();
        }
      }
    }

    if (DaoHelper.isNotEmpty(districtFilter)) {
      districtFilter = new StringBuilder().append(" AND(").append(districtFilter.trim()).append(") ").toString();
    }

    LogHome.getLog().info(new StringBuilder().append("结束[").append(objName).append("]区域权限过滤检查[districtFilter=").append(districtFilter).append("]").toString());
    return districtFilter;
  }

  private String getSecObjQueryFilterSql(IBoActionContext actionContext, String attrName, String className, String objName, Map param)
    throws Exception
  {
    if ((actionContext == null) || (actionContext.getUserId() == null)) {
      return "";
    }
    String userId = actionContext.getUserId();

    if ((!DaoHelper.isNotEmpty(userId)) || ("SYS_USER-0".equals(userId))) {
      return "";
    }

    if (!DaoHelper.isNotEmpty(attrName)) {
      return "";
    }

    if (!DaoHelper.isNotEmpty(className)) {
      return "";
    }

    LogHome.getLog().info(new StringBuilder().append("开始[").append(objName).append("]对象权限过滤检查[userId=").append(userId).append(", param.toString=").append(param == null ? "'null'" : param.toString()).append("]").toString());

    String funcDisQueryFilterSql = getFuncDisQueryFilterSql(actionContext, "RELATED_DISTRICT_CUID", "权限对象", param);
    String objsql = new StringBuilder().append("RELATED_USER_CUID='").append(userId).append("' AND ").append("OBJECT_CLASSNAME").append("='").append(className).append("' AND ").append("OBJECT_OPERATION").append("=1").toString();

    if (DaoHelper.isNotEmpty(funcDisQueryFilterSql)) {
      objsql = new StringBuilder().append(objsql).append(funcDisQueryFilterSql).toString();
    }
    DataObjectList dbos = getSecurityObjectDAO().getObjectsBySql(objsql, new UserHaveObject(), 0);
    List inExList = new ArrayList();
    List notInExList = new ArrayList();
    if (dbos != null) {
      for (int i = 0; i < dbos.size(); i++) {
        UserHaveObject dbo = (UserHaveObject)dbos.get(i);
        if (dbo.getIsInEx())
          inExList.add(dbo.getRelatedObjectCuid());
        else {
          notInExList.add(dbo.getRelatedObjectCuid());
        }
      }

    }

    String objectFilter = "";
    if (inExList.size() > 0) {
      objectFilter = new StringBuilder().append(attrName).append(" NOT IN('").append(DaoHelper.getArrayListToStr(inExList).replaceAll(",", "','")).append("') ").toString();
      if (notInExList.size() > 0) {
        objectFilter = new StringBuilder().append(objectFilter).append(" and ").append(attrName).append(" IN('").append(DaoHelper.getArrayListToStr(notInExList).replaceAll(",", "','")).append("') ").toString();
      }
    }
    else if (notInExList.size() > 0) {
      objectFilter = new StringBuilder().append(attrName).append(" IN('").append(DaoHelper.getArrayListToStr(notInExList).replaceAll(",", "','")).append("') ").toString();
    }

    if (DaoHelper.isNotEmpty(objectFilter)) {
      objectFilter = new StringBuilder().append(" AND(").append(objectFilter.trim()).append(") ").toString();
    }

    LogHome.getLog().info(new StringBuilder().append("结束[").append(objName).append("]对象权限过滤检查[objectFilter=").append(objectFilter).append("]").toString());
    return objectFilter;
  }

  private static class NodeTrail
  {
    public String trail = "";
    public int nodeCount = 0;

    public NodeTrail(String trail, int nodeCount) { this.trail = trail;
      this.nodeCount = nodeCount;
    }
  }

  private static class RelatedClassNode
  {
    public String relatedFieldName;
    public String relatedClassName;

    public RelatedClassNode(String relatedFieldName, String relatedClassName)
    {
      this.relatedFieldName = relatedFieldName;
      this.relatedClassName = relatedClassName;
    }
  }

  private static class UserClassNode
  {
    public String className;
    public String districtFieldName;
    public Map<String, SecurityObjectBO.RelatedClassNode> parentNodes = new HashMap();

    public UserClassNode(String className, String districtFieldName) { this.className = className;
      this.districtFieldName = districtFieldName;
    }
  }
}