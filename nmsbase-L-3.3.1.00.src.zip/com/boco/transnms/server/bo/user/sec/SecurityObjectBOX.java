package com.boco.transnms.server.bo.user.sec;

import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.ibo.IObjectSecurityBOX;

public class SecurityObjectBOX extends AbstractBO
  implements IObjectSecurityBOX
{
}