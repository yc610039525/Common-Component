package com.boco.transnms.server.bo.system.callboard;

import com.boco.common.util.db.DbConnManager;
import com.boco.common.util.db.DbContext;
import com.boco.common.util.db.SqlHelper;
import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.common.util.lang.TimeFormatHelper;
import com.boco.transnms.common.dto.CallBoard;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboBlob;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.misc.AllPics;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.BoHomeFactory;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.ibo.cm.ICallBoardBO;
import com.boco.transnms.server.bo.ibo.cm.IDistrictBO;
import com.boco.transnms.server.bo.ibo.topo.IAllPicsBO;
import com.boco.transnms.server.common.cfg.TnmsRuntime;
import com.boco.transnms.server.dao.system.callboard.CallBoardDAO;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="COMMON")
public class CallBoardBO extends AbstractBO
  implements ICallBoardBO
{
  public CallBoard getCallBoard(BoActionContext actionContext, Long objectId)
    throws UserException
  {
    try
    {
      return getCallBoardDAO().getCallBoard(actionContext, objectId);
    } catch (Exception ex) {
      LogHome.getLog().error("获取公告发布对象失败", ex);
      throw new UserException(ex);
    }
  }

  public CallBoard addCallBoard(BoActionContext actionContext, CallBoard dbo) throws UserException {
    try {
      String infoText = dbo.getInfotext();
      dbo.setInfotext(actionContext.getUserId());
      dbo = getCallBoardDAO().addCallBoard(actionContext, dbo);
      saveBlob(dbo.getCuid(), infoText);
      dbo.setAttrValue("RELATED_USER_CUID", dbo.getInfotext());
      dbo.setInfotext(infoText);
      return dbo;
    } catch (Exception ex) {
      LogHome.getLog().error("增加公告发布失败", ex);
      throw new UserException(ex);
    }
  }

  private void saveBlob(String cuid, String infoText) {
    DboBlob blob = new DboBlob();
    blob.setBlobBytes(infoText.getBytes());
    AllPics pic = new AllPics();
    pic.setCuid(cuid);
    pic.setObjectTypeCode(5008L);
    pic.setPic(blob);
    IAllPicsBO ibo = (IAllPicsBO)BoHomeFactory.getInstance().getBO(IAllPicsBO.class);
    ibo.addAllPics(new BoActionContext(), pic);
  }
  private void modifyBlob(String cuid, String infoText) {
    DboBlob blob = new DboBlob();
    blob.setBlobBytes(infoText.getBytes());
    AllPics pic = new AllPics();
    pic.setCuid(cuid);
    pic.setObjectTypeCode(5008L);
    pic.setPic(blob);
    IAllPicsBO ibo = (IAllPicsBO)BoHomeFactory.getInstance().getBO(IAllPicsBO.class);
    ibo.modifyAllPicsPicField(new BoActionContext(), pic);
  }
  private boolean deleteBlob(String cuid) {
    AllPics pic = new AllPics();
    pic.setCuid(cuid);
    IAllPicsBO ibo = (IAllPicsBO)BoHomeFactory.getInstance().getBO(IAllPicsBO.class);
    ibo.deleteAllPics(new BoActionContext(), pic);
    return true;
  }

  public void modifyCallBoard(BoActionContext actionContext, CallBoard dbo) throws UserException
  {
    try {
      String infoText = dbo.getInfotext();
      CallBoard olddbo = getCallBoard(actionContext, Long.valueOf(dbo.getObjectNum()));
      String infoTextOld = olddbo.getInfotext();
      if ((infoTextOld != null) && (infoTextOld.trim().length() > 0) && (infoTextOld.indexOf("SYS_USER-") == 0)) {
        modifyBlob(olddbo.getCuid(), infoText);
        dbo.setInfotext(infoTextOld);
      } else {
        dbo.setInfotext(actionContext.getUserId());
        saveBlob(olddbo.getCuid(), infoText);
      }
      getCallBoardDAO().modifyCallBoard(actionContext, dbo);
    }
    catch (Exception ex) {
      LogHome.getLog().error("修改公告发布失败", ex);
      throw new UserException(ex);
    }
  }

  public void deleteCallBoard(BoActionContext actionContext, Long objectId) throws UserException {
    try {
      CallBoard old = getCallBoard(actionContext, objectId);
      String infoText = old.getInfotext();
      if ((infoText != null) && (infoText.trim().length() > 0) && (infoText.indexOf("SYS_USER-") == 0)) {
        deleteBlob(old.getCuid());
      }
      getCallBoardDAO().deleteCallBoard(actionContext, objectId);
    } catch (Exception ex) {
      LogHome.getLog().error("删除公告发布失败", ex);
      throw new UserException(ex);
    }
  }

  public DboCollection getCallBoardByCondition(BoQueryContext queryContext, String queryAuthor, String queryStartDateTime, String queryEndDateTime, String queryInfoTitle, String orderString) throws UserException {
    try {
      if (!queryStartDateTime.equals("")) {
        queryStartDateTime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(queryStartDateTime));
      }
      if (!queryEndDateTime.equals("")) {
        queryEndDateTime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(queryEndDateTime));
      }
      return getCallBoardDAO().getCallBoardByCondition(queryContext, queryAuthor, queryStartDateTime, queryEndDateTime, queryInfoTitle, orderString);
    } catch (Exception ex) {
      LogHome.getLog().error("根据cuid取公告发布失败" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public DboCollection getCallBoardByHenan(BoQueryContext queryContext) throws UserException {
    try {
      return getCallBoardDAO().getCallBoardByHenan(queryContext);
    } catch (Exception ex) {
      LogHome.getLog().error("根据cuid取公告发布失败" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public DataObjectList getAllCallBoard(BoActionContext actionContext) throws UserException {
    try {
      return getCallBoardDAO().getAllCallBoard(actionContext);
    } catch (Exception ex) {
      LogHome.getLog().error("获取所有的公告发布失败" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public CallBoardDAO getCallBoardDAO() {
    return (CallBoardDAO)super.getDAO("CallBoardDAO");
  }

  public DataObjectList getCallBoardByCondition(BoActionContext actionContext, String currentDate) throws UserException {
    try {
      return getCallBoardDAO().getCallBoardByCondition(actionContext, currentDate);
    } catch (Exception ex) {
      LogHome.getLog().error("根据cuid取公告发布失败" + ex.getMessage());
      throw new UserException(ex);
    }
  }

  public List getTransElementStatis(BoQueryContext queryContext) throws UserException {
    List relist = new ArrayList();
    try {
      String districtCuid = getDefaultDistrictCuid();
      DataObjectList dbos = getCallBoardDAO().getTransElementStatis(queryContext, districtCuid);
      if (dbos != null) {
        String alldistricts = "";
        for (GenericDO dto : dbos) {
          String area = dto.getAttrString("1");
          String cuid = dto.getAttrString("4");
          alldistricts = alldistricts + area + ",";
          if (cuid.length() == 20) {
            area = "二干";
          }
          String sdhNum = dto.getAttrString("2");
          String wdmNum = dto.getAttrString("3");
          String s = area + "," + sdhNum + "," + wdmNum;
          relist.add(s);
        }
        List alldistrict = getAllSubDistrict(queryContext, districtCuid);
        if (alldistrict != null)
          for (int i = 0; i < alldistrict.size(); i++) {
            String districtName = (String)alldistrict.get(i);
            if (alldistricts.indexOf(districtName) < 0) {
              String s2 = districtName + ",0,0";
              relist.add(s2);
            }
          }
      }
    }
    catch (Exception ex) {
      LogHome.getLog().error("配置统计出错" + ex.getMessage());
      throw new UserException(ex);
    }
    return relist;
  }

  public List getTraphSatistic(BoQueryContext queryContext) throws UserException {
    List relist = new ArrayList();
    try {
      String districtCuid = getDefaultDistrictCuid();
      DataObjectList dbos = getCallBoardDAO().getTraphSatistic(queryContext, districtCuid);
      if (dbos != null) {
        String alldistricts = "";
        for (GenericDO dto : dbos) {
          String area = dto.getAttrString("1");
          String cuid = dto.getAttrString("4");
          alldistricts = alldistricts + area + ",";
          if (cuid.length() == 20) {
            area = "二干";
          }
          String traphNum = dto.getAttrString("2");
          String tdTraphNum = dto.getAttrString("3");
          String s = area + "," + traphNum + "," + tdTraphNum;
          relist.add(s);
        }
        List alldistrict = getAllSubDistrict(queryContext, districtCuid);
        if (alldistrict != null)
          for (int i = 0; i < alldistrict.size(); i++) {
            String districtName = (String)alldistrict.get(i);
            if (alldistricts.indexOf(districtName) < 0) {
              String s2 = districtName + ",0,0,0";
              relist.add(s2);
            }
          }
      }
    }
    catch (Exception ex) {
      LogHome.getLog().error("电路统计出错" + ex.getMessage());
      throw new UserException(ex);
    }
    return relist;
  }

  public List getDuctSatistic(BoQueryContext queryContext) throws UserException {
    List relist = new ArrayList();
    try {
      String systemDistrictName = TnmsRuntime.getInstance().get("DISTRICT_ID");
      String districtCuid = getDefaultDistrictCuid();
      DataObjectList dbos = getCallBoardDAO().getDuctSatistic(queryContext, districtCuid);
      if (dbos != null) {
        String alldistricts = "";
        for (GenericDO dto : dbos) {
          String area = dto.getAttrString("1");
          String wire = dto.getAttrString("2");
          String duct = dto.getAttrString("3");
          String pole = dto.getAttrString("4");
          String stone = dto.getAttrString("5");
          String hang = dto.getAttrString("6");
          String upline = dto.getAttrString("7");
          String cuid = dto.getAttrString("8");
          alldistricts = alldistricts + area + ",";
          if (cuid.length() == 20) {
            area = "二干";
          }
          String s = area + "," + wire + "," + duct + "," + pole + "," + stone + "," + hang + "," + upline;
          relist.add(s);
        }
        List alldistrict = getAllSubDistrict(queryContext, districtCuid);
        if (alldistrict != null)
          for (int i = 0; i < alldistrict.size(); i++) {
            String districtName = (String)alldistrict.get(i);
            if ((alldistricts.indexOf(districtName) < 0) && (!districtName.equals(systemDistrictName))) {
              String s2 = districtName + ",0,0,0,0,0,0";
              relist.add(s2);
            }
          }
      }
    }
    catch (Exception ex) {
      LogHome.getLog().error("管线统计出错" + ex.getMessage());
      throw new UserException(ex);
    }
    return relist;
  }

  public List getAlarmSatistic(BoQueryContext queryContext) throws UserException {
    List relist = new ArrayList();
    try {
      String districtCuid = getDefaultDistrictCuid();
      DataObjectList dbos = getCallBoardDAO().getAlarmSatistic(queryContext, districtCuid);
      if (dbos != null) {
        String alldistricts = "";
        for (GenericDO dto : dbos) {
          String area = dto.getAttrString("1");
          String currentNum = dto.getAttrString("2");
          String tdNum = dto.getAttrString("3");
          String projectNum = dto.getAttrString("4");
          String cuid = dto.getAttrString("5");
          alldistricts = alldistricts + area + ",";
          if (cuid.length() == 20) {
            area = "二干";
          }
          String s = area + "," + currentNum + "," + tdNum + "," + projectNum;
          relist.add(s);
        }
        List alldistrict = getAllSubDistrict(queryContext, districtCuid);
        if (alldistrict != null)
          for (int i = 0; i < alldistrict.size(); i++) {
            String districtName = (String)alldistrict.get(i);
            if (alldistricts.indexOf(districtName) < 0) {
              String s2 = districtName + ",0,0,0";
              relist.add(s2);
            }
          }
      }
    }
    catch (Exception ex) {
      LogHome.getLog().error("告警统计出错" + ex.getMessage());
      throw new UserException(ex);
    }
    return relist;
  }

  private String getDefaultDistrictCuid() {
    String districtId = TnmsRuntime.getInstance().get("DISTRICT_ID");
    return getDistrictBO().getCuidByLabelCn(new BoActionContext(), districtId);
  }

  private List getAllSubDistrict(BoQueryContext queryContext, String districtCuid) {
    List relist = new ArrayList();
    try {
      DataObjectList dbos = getCallBoardDAO().getAllSubDistrict(queryContext, districtCuid);
      dbos.sort("SEVICE_LEADER_CODE", false);
      if (dbos != null)
        for (GenericDO dto : dbos) {
          String area = dto.getAttrString("1");
          relist.add(area);
        }
    }
    catch (Exception ex) {
      throw new UserException(ex);
    }
    return relist;
  }

  private IDistrictBO getDistrictBO() {
    return (IDistrictBO)super.getBO("IDistrictBO");
  }

  public CallBoard getCallBoardByCuid(String cuid) throws UserException
  {
    CallBoard dbo = new CallBoard();
    try {
      dbo = getCallBoardDAO().getCallBoardByCuid(cuid);
    } catch (Exception e) {
      LogHome.getLog().error("依据公告cuid获得公告失败", e);
    }
    return dbo;
  }
}