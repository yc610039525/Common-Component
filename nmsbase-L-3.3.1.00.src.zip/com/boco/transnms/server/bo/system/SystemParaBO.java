package com.boco.transnms.server.bo.system;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.core.commons.ProjectVersion;
import com.boco.transnms.common.bussiness.consts.AlarmEnum;
import com.boco.transnms.common.bussiness.consts.AlarmEnum.AlarmSeverity;
import com.boco.transnms.common.bussiness.consts.AlarmEnum.AlarmSeverityNormal;
import com.boco.transnms.common.bussiness.consts.AlarmEnum.AlarmStandSeverity;
import com.boco.transnms.common.bussiness.consts.AlarmEnum.AlarmStandSeverityNormal;
import com.boco.transnms.common.dto.DevinfoConfig;
import com.boco.transnms.common.dto.QueryCondition;
import com.boco.transnms.common.dto.ServiceParam;
import com.boco.transnms.common.dto.ShortCodeInfo;
import com.boco.transnms.common.dto.SystemPara;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.IBoActionContext;
import com.boco.transnms.common.dto.traph.TraphViewConfig;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.BoHomeFactory;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.base.StateLessBoField;
import com.boco.transnms.server.bo.ibo.common.IServiceParamBO;
import com.boco.transnms.server.bo.ibo.system.ISystemParaBO;
import com.boco.transnms.server.common.cfg.SystemEnv;
import com.boco.transnms.server.common.cfg.TnmsRuntime;
import com.boco.transnms.server.common.cfg.TransNmsCfg;
import com.boco.transnms.server.dao.common.CommonDAO;
import com.boco.transnms.server.dao.system.SystemParaDAO;
import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="COMMON", initByAllServer=true)
public class SystemParaBO extends AbstractBO
  implements ISystemParaBO
{

  @StateLessBoField
  private static final String KEY_SEP_STR = "-";

  @StateLessBoField
  private static final String DEFAULT_SP = "DEFAULT";

  public SystemParaBO()
  {
    super("ISystemParaBO");
  }

  private String getParaKey(SystemPara para) {
    return para.getProductTypeName() + "-" + para.getProductSpName() + "-" + para.getParaClassName() + "-" + para.getParaName();
  }

  private String getParaKey(String paraClassName, String paraName)
  {
    String productType = TnmsRuntime.getInstance().get("PRODUCT_TYPE");
    String productSP = TnmsRuntime.getInstance().get("PRODUCT_SP");
    return productType + "-" + productSP + "-" + paraClassName + "-" + paraName;
  }

  private String getDefaultParaKey(String paraClassName, String paraName)
  {
    String productType = TnmsRuntime.getInstance().get("PRODUCT_TYPE");
    return productType + "-" + "DEFAULT" + "-" + paraClassName + "-" + paraName;
  }

  public String getSystemParaValue(BoActionContext actionContext, String paraClassName, String paraName)
    throws UserException
  {
    SystemPara para = getSystemPara(actionContext, paraClassName, paraName);
    if (para == null) {
      return null;
    }
    return para.getParaValue();
  }

  public SystemPara getSystemPara(BoActionContext actionContext, String paraClassName, String paraName) throws UserException {
    String productType = TnmsRuntime.getInstance().get("PRODUCT_TYPE");
    String productSP = TnmsRuntime.getInstance().get("PRODUCT_SP");
    DboCollection dbos = null;
    try {
      dbos = getSystemParaDAO().getParaByCondition(actionContext, paraClassName, paraName, productType, productSP);
    } catch (Exception ex) {
      LogHome.getLog().error("获取系统参数异常！");
      throw new UserException(ex.getMessage());
    }
    SystemPara para = null;
    if ((dbos != null) && (dbos.size() > 0)) {
      para = (SystemPara)dbos.getAttrField("SYSTEM_PARA", 0);
    }
    if (para == null) {
      try {
        dbos = getSystemParaDAO().getParaByCondition(actionContext, paraClassName, paraName, productType, "DEFAULT");
      } catch (Exception ex1) {
        LogHome.getLog().error("获取系统参数异常！", ex1);
        throw new UserException(ex1.getMessage());
      }
      if ((dbos != null) && (dbos.size() > 0)) {
        para = (SystemPara)dbos.getAttrField("SYSTEM_PARA", 0);
      }
      if (para == null) {
        LogHome.getLog().error("指定的系统参数不存在[paraClassName=" + paraClassName + ", paraName=" + paraName);
      }
    }

    if (((para == null) || (para.getParaValue() == null) || (para.getParaValue().equalsIgnoreCase("null")) || (para.getParaValue().trim().length() == 0)) && 
      (paraClassName.equals("TNMS_RUN_TIME_CFG")) && (paraName.equals("TRANSNMS_VERSION"))) {
      para = new SystemPara();
      String version = ProjectVersion.getBuildVersion();
      para.setParaValue(version);
    }

    return para;
  }

  public DataObjectList getSystemParas(BoActionContext actionContext, String paraClassName) throws UserException
  {
    String productType = TnmsRuntime.getInstance().get("PRODUCT_TYPE");
    String productSP = TnmsRuntime.getInstance().get("PRODUCT_SP");
    DataObjectList paraList = new DataObjectList();
    Map paraMap = new HashMap();
    try {
      DboCollection dbos = getSystemParaDAO().getSystemParaByClass(productType, paraClassName);
      for (int i = 0; i < dbos.size(); i++) {
        SystemPara dbo = (SystemPara)dbos.getQueryDbo(i, "SYSTEM_PARA");
        if (productSP.equals(dbo.getProductSpName())) {
          paraMap.remove(dbo.getParaName());
          paraMap.put(dbo.getParaName(), dbo);
        } else if (("DEFAULT".equals(dbo.getProductSpName())) && 
          (!paraMap.containsKey(dbo.getParaName()))) {
          paraMap.put(dbo.getParaName(), dbo);
        }
      }
    }
    catch (Exception ex) {
      LogHome.getLog().info("", ex);
      throw new UserException(ex.getMessage());
    }

    Object[] paraKeys = new Object[paraMap.size()];
    paraMap.keySet().toArray(paraKeys);
    for (int i = 0; i < paraKeys.length; i++) {
      paraList.add(paraMap.get(paraKeys[i]));
    }
    return paraList;
  }

  private SystemParaDAO getSystemParaDAO() {
    return (SystemParaDAO)super.getDAO(SystemParaDAO.class);
  }

  public DboCollection getSystemParaByPage(BoQueryContext queryContext, HashMap param) throws UserException
  {
    try {
      String queryParaClassName = (String)param.get("queryParaClassName");
      String querySPName = (String)param.get("querySPName");
      String queryParaName = (String)param.get("queryParaName");
      String queryParaLableCN = (String)param.get("queryParaLableCN");

      return getSystemParaDAO().querySystemPara(queryContext, querySPName, queryParaClassName, queryParaName, queryParaLableCN);
    }
    catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getSingleSystemPara(BoQueryContext queryContext, HashMap param) throws UserException
  {
    try {
      String querySPName = (String)param.get("PRODUCT_SP_NAME");
      String queryParaClassName = (String)param.get("PARA_CLASS_NAME");
      String queryParaName = (String)param.get("PARA_NAME");
      String queryParaTypeName = (String)param.get("PRODUCT_TYPE_NAME");
      return getSystemParaDAO().getSingleSystemPara(querySPName, queryParaClassName, queryParaName, queryParaTypeName);
    }
    catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection addSingleSystemPara(BoQueryContext queryContext, HashMap param) throws UserException
  {
    try {
      String querySPName = (String)param.get("PRODUCT_SP_NAME");
      String queryParaClassName = (String)param.get("PARA_CLASS_NAME");
      String queryParaName = (String)param.get("PARA_NAME");
      String queryParaTypeName = (String)param.get("PRODUCT_TYPE_NAME");
      String queryParaDesc = (String)param.get("PARA_DESC");
      String queryParaValue = (String)param.get("PARA_VALUE");
      String queryParaAddition = (String)param.get("PARA_ADDITION");
      String queryParaLableCN = (String)param.get("PARA_LABELCN");
      if (queryParaValue.trim().length() == 0) {
        queryParaValue = " ";
      }
      SystemPara para = new SystemPara();
      para.setProductSpName(querySPName);
      para.setParaClassName(queryParaClassName);
      para.setParaName(queryParaName);
      para.setProductTypeName(queryParaTypeName);
      para.setParaDesc(queryParaDesc);
      para.setParaValue(queryParaValue);
      para.setParaAddition(queryParaAddition);
      para.setParaLabelcn(queryParaLableCN);

      getSystemParaDAO().addSystemPara(new BoActionContext(), para);
      return getSystemParaDAO().getSingleSystemPara(querySPName, queryParaClassName, queryParaName, queryParaTypeName);
    }
    catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public void delSingleSystemPara(BoQueryContext queryContext, HashMap param) throws UserException
  {
    try {
      String querySPName = (String)param.get("PRODUCT_SP_NAME");
      String queryParaClassName = (String)param.get("PARA_CLASS_NAME");
      String queryParaName = (String)param.get("PARA_NAME");
      String queryParaTypeName = (String)param.get("PRODUCT_TYPE_NAME");
      DboCollection dbos = getSystemParaDAO().getParaByCondition(new BoActionContext(), queryParaClassName, queryParaName, queryParaTypeName, querySPName);
      for (int i = 0; i < dbos.size(); i++) {
        SystemPara dbo = (SystemPara)dbos.getAttrField("SYSTEM_PARA", i);
        getSystemParaDAO().deletePara(new BoActionContext(), Long.valueOf(dbo.getObjectNum()));
      }
    }
    catch (Throwable ex)
    {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DataObjectList getDistinctTable(BoQueryContext queryContext, String ClassName, String KEYNAME) throws UserException
  {
    try {
      return getSystemParaDAO().getDistinctTable(ClassName, KEYNAME);
    } catch (Throwable ex) {
      throw new UserException(ex.getMessage(), ex);
    }
  }

  public DataObjectList getSystemParaByClassName(IBoActionContext actionContext, String paraClassName) throws UserException {
    try {
      String sql = "PARA_CLASS_NAME ='" + paraClassName + "' ";
      return getSystemParaDAO().getObjectsBySql(actionContext, sql, new SystemPara(), 0);
    } catch (Throwable ex) {
      LogHome.getLog().error("getSystemParaByClassName", ex);
      throw new UserException(ex.getMessage(), ex);
    }
  }

  public Boolean getSmsSwitch()
  {
    return Boolean.valueOf(TnmsRuntime.getInstance().equals("SUPPORT_SMS", Boolean.TRUE.toString()));
  }

  public Map getTraphNameAndTraphAlias(BoActionContext actionContext)
    throws UserException
  {
    Map returnMap = new HashMap();
    SystemPara sysParaName = null;
    SystemPara sysParaAlias = null;
    sysParaName = getSystemPara(actionContext, "电路模块名称配置", "traphName");
    if (sysParaName != null)
      returnMap.put("traphName", sysParaName.getParaValue());
    else {
      returnMap.put("traphName", "电路名称");
    }

    sysParaAlias = getSystemPara(actionContext, "电路模块名称配置", "traphAlias");
    if (sysParaAlias != null)
      returnMap.put("traphAlias", sysParaAlias.getParaValue());
    else {
      returnMap.put("traphAlias", "电路别名");
    }
    return returnMap;
  }

  public TraphViewConfig getTraphViewConfigBySystemPara(BoActionContext actionContext)
    throws UserException
  {
    TraphViewConfig traphViewConfig = new TraphViewConfig();
    SystemPara sysParaName = null;
    SystemPara sysParaAlias = null;
    sysParaName = getSystemPara(actionContext, "电路模块名称配置", "traphName");
    if (sysParaName != null)
      traphViewConfig.setTraphName(sysParaName.getParaValue());
    else {
      traphViewConfig.setTraphName("电路名称");
    }

    sysParaAlias = getSystemPara(actionContext, "电路模块名称配置", "traphAlias");
    if (sysParaAlias != null)
      traphViewConfig.setTraphAlias(sysParaAlias.getParaValue());
    else {
      traphViewConfig.setTraphAlias("电路别名");
    }
    return traphViewConfig;
  }

  public DboCollection getShortCodeByCondition(BoQueryContext queryContext, String shortCode, String orderString)
    throws Exception
  {
    return getSystemParaDAO().getShortCodeByCondition(queryContext, shortCode, orderString);
  }

  public ShortCodeInfo addShortCode(BoQueryContext queryContext, ShortCodeInfo shortCodeInfo)
    throws Exception
  {
    return getSystemParaDAO().addShortCode(queryContext, shortCodeInfo);
  }

  public void deleteShortCode(BoActionContext actionContext, String[] cuids) throws Exception {
    getSystemParaDAO().deleteShortCode(actionContext, cuids);
  }

  public ShortCodeInfo getShortCodeByCuid(BoActionContext actionContext, String cuid) throws Exception {
    return getSystemParaDAO().getShortCodeByCuid(actionContext, cuid);
  }

  public void modifyShortCodeByCuid(BoActionContext actionContext, ShortCodeInfo shortCodeInfo) throws Exception {
    getSystemParaDAO().modifyShortCodeByCuid(actionContext, shortCodeInfo);
  }

  public boolean isAdded(BoActionContext actionContext, String shortCode) throws Exception {
    DboCollection dbos = getSystemParaDAO().isAdded(actionContext, shortCode);
    if (dbos.size() > 0) {
      return true;
    }
    return false;
  }

  public DboCollection getShortCodeExcelByCondition(BoActionContext actionContext, String shortCode) throws Exception
  {
    return getSystemParaDAO().getShortCodeExcelByCondition(actionContext, shortCode);
  }

  public void addDevInfoImpConfig(DataObjectList dboList) throws UserException
  {
    try {
      DevinfoConfig devinfoconfig = new DevinfoConfig();
      getSystemParaDAO().addDevInfoImpConfig(dboList);
    } catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getDevInfoImpConfig() throws UserException
  {
    try {
      return getSystemParaDAO().getDevInfoImpConfig();
    }
    catch (Throwable ex) {
      LogHome.getLog().error("", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public SystemPara createSystemPara(BoActionContext actionContext, String paraClassName, String paraName, String value, String desc) throws UserException {
    SystemPara para = new SystemPara();
    try {
      String productType = TnmsRuntime.getInstance().get("PRODUCT_TYPE");
      String productSP = TnmsRuntime.getInstance().get("PRODUCT_SP");
      para.setProductTypeName(productType);
      para.setProductSpName(productSP);
      para.setParaClassName(paraClassName);
      para.setParaName(paraName);
      para.setParaValue(value);
      para.setParaDesc(desc);
      para.setParaAddition("1");
      getSystemParaDAO().addSystemPara(actionContext, para);
    } catch (Exception ex) {
      LogHome.getLog().error("新建参数失败", ex);
    }
    return para;
  }

  public void modifySystemPara(BoActionContext actionContext, String paraClassName, String paraName, String value)
    throws UserException
  {
    try
    {
      SystemPara para = getSystemPara(actionContext, paraClassName, paraName);
      if (para == null) {
        para = new SystemPara();
        String productType = TnmsRuntime.getInstance().get("PRODUCT_TYPE");
        String productSP = TnmsRuntime.getInstance().get("PRODUCT_SP");
        para.setProductTypeName(productType);
        para.setProductSpName(productSP);
        para.setParaClassName(paraClassName);
        para.setParaName(paraName);
        para.setParaValue(value);

        getSystemParaDAO().addSystemPara(actionContext, para);
      }
      else {
        para.setParaValue(value);
        getSystemParaDAO().modifySystemPara(actionContext, para);
      }
    } catch (Exception ex) {
      LogHome.getLog().error("修改参数失败:", ex);
      throw new UserException("修改参数失败!");
    }
  }

  public HashMap getSystemRuntimeCfg(BoActionContext actionContext) throws UserException {
    HashMap params = new HashMap();
    try {
      if (TransNmsCfg.getInstance().isDevelopmentMode()) {
        Properties properties = new Properties();
        String serverHome = SystemEnv.getPathEnv("TNMS_SERVER_HOME");
        String filePath = serverHome + File.separatorChar + "tnms-conf/" + "tnmscfg.properties";
        properties.load(new FileInputStream(new File(filePath)));
        params.putAll(properties);
      }
      else {
        ISystemParaBO ibo = (ISystemParaBO)BoHomeFactory.getInstance().getBO("ISystemParaBO");
        DataObjectList dbos = ibo.getSystemParaByClassName(new BoActionContext(), "TNMS_RUN_TIME_CFG");
        for (int i = 0; i < dbos.size(); i++) {
          SystemPara para = (SystemPara)dbos.get(i);
          String key = para.getParaName();
          String value = para.getParaValue();
          params.put(key, value);
          if (("START_ALARM_STANDARD".equals(key)) && ("true".equalsIgnoreCase(value))) {
            Map map = AlarmEnum.ALARM_SEVERITY.getAllEnum();
            map.clear();
            map.putAll(AlarmEnum.ALARM_STAND_SEVERITY.getAllEnum());
            map = AlarmEnum.ALARM_SEVERITY_NORMAL.getAllEnum();
            map.clear();
            map.putAll(AlarmEnum.ALARM_STAND_SEVERITY_NORMAL.getAllEnum());
          }
        }

        IServiceParamBO serviceParamBO = (IServiceParamBO)BoHomeFactory.getInstance().getBO("IServiceParamBO");
        DataObjectList webs = serviceParamBO.getServiceParamsByType(new BoActionContext(), Long.valueOf(3L));

        for (int i = 0; i < webs.size(); i++) {
          ServiceParam para = (ServiceParam)webs.get(i);
          String key = para.getServerName();
          String value = para.getServiceUrl();
          params.put(key, value);

          key = para.getServerName() + "_PROXY";
          value = para.getServiceProxyUrl();
          params.put(key, value);
        }
      }
    } catch (Exception ex) {
      LogHome.getLog().error("获取系统参数失败:", ex);
      throw new UserException("获取系统参数失败!");
    }
    return params;
  }

  public void addQueryCondition(BoActionContext actionContext, QueryCondition queryCondition) throws UserException {
    try {
      getSystemParaDAO().createObject(actionContext, queryCondition);
    } catch (Exception e) {
      LogHome.getLog().info("保存查询条件出错", e);
      throw new UserException("保存查询条件出错");
    }
  }

  public void deleteQueryConditionBySQL(BoActionContext actionContext, String sql) throws UserException
  {
    try {
      getCommonDAO().execSql(sql);
    } catch (Exception e) {
      LogHome.getLog().info("删除查询条件出错", e);
      throw new UserException("删除查询条件出错");
    }
  }

  public DataObjectList getQueryConditionBySql(BoActionContext actionContext, String sql)
    throws UserException
  {
    DataObjectList queryConditionList = new DataObjectList();
    try {
      queryConditionList = getSystemParaDAO().getObjectsBySql(sql, new QueryCondition(), 0);
      if ((queryConditionList != null) && (queryConditionList.size() > 0))
        return queryConditionList;
    }
    catch (Exception e) {
      LogHome.getLog().info("根据sql获取查询条件出错", e);
      throw new UserException("根据sql获取查询条件出错");
    }
    return null;
  }

  public void modifyQueryCondition(BoActionContext actionContext, DataObjectList queryConditionList) throws UserException
  {
    try {
      if ((queryConditionList != null) && (queryConditionList.size() != 0))
        for (int i = 0; i < queryConditionList.size(); i++) {
          QueryCondition queryCondition = (QueryCondition)queryConditionList.get(i);
          queryCondition.clearUnknowAttrs();
          getSystemParaDAO().updateObject(actionContext, queryCondition);
        }
    }
    catch (Exception e) {
      LogHome.getLog().info("修改查询条件出错", e);
      throw new UserException("修改查询条件出错");
    }
  }

  public String getTnmsRunTimeValue(String key)
  {
    return TnmsRuntime.getInstance().get(key);
  }

  private CommonDAO getCommonDAO() {
    return (CommonDAO)super.getDAO(CommonDAO.class);
  }
}