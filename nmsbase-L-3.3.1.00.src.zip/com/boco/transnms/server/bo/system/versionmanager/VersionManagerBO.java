package com.boco.transnms.server.bo.system.versionmanager;

import com.boco.common.util.db.DbConnManager;
import com.boco.common.util.db.DbContext;
import com.boco.common.util.db.SqlHelper;
import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.common.util.lang.TimeFormatHelper;
import com.boco.core.commons.ProjectVersion;
import com.boco.transnms.client.model.base.BoCmdFactory;
import com.boco.transnms.common.dto.District;
import com.boco.transnms.common.dto.VersionAttach;
import com.boco.transnms.common.dto.VersionManager;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.server.bo.base.AbstractBO;
import com.boco.transnms.server.bo.base.BoHomeFactory;
import com.boco.transnms.server.bo.base.StateLessBO;
import com.boco.transnms.server.bo.ibo.cm.IVersionManagerBO;
import com.boco.transnms.server.bo.ibo.misc.ISecurityBO;
import com.boco.transnms.server.common.cfg.ActionFilterCfg;
import com.boco.transnms.server.common.cfg.TnmsRuntime;
import com.boco.transnms.server.dao.system.versionmanager.VersionManagerDAO;
import java.util.HashMap;
import org.apache.commons.logging.Log;

@StateLessBO(serverName="CM")
public class VersionManagerBO extends AbstractBO
  implements IVersionManagerBO
{
  public VersionManagerBO()
  {
    super("IVersionManagerBO");
  }

  public VersionManager addVersionManager(BoActionContext actionContext, VersionManager versionManager)
    throws UserException
  {
    try
    {
      return getVersionManagerDAO().addVersionManager(actionContext, versionManager);
    } catch (Exception ex) {
      LogHome.getLog().info("DAO 访问异常", ex);
    }return null;
  }

  public void deleteVersionManager(BoActionContext actionContext, Long objectId)
    throws UserException
  {
    try
    {
      getVersionManagerDAO().deleteVersionManager(actionContext, objectId);
    } catch (Exception ex) {
      LogHome.getLog().info("DAO 访问异常", ex);
    }
  }

  public void modifyVersionManager(BoActionContext actionContext, VersionManager versionManager)
    throws UserException
  {
    try
    {
      getVersionManagerDAO().modifyVersionManager(actionContext, versionManager);
    } catch (Exception ex) {
      LogHome.getLog().info("DAO 访问异常", ex);
    }
  }

  private VersionManagerDAO getVersionManagerDAO() {
    return (VersionManagerDAO)super.getDAO("VersionManagerDAO");
  }

  public VersionManager getVersionManager(BoActionContext actionContext, Long objectId)
    throws UserException
  {
    try
    {
      return getVersionManagerDAO().getVersionManager(actionContext, objectId);
    } catch (Exception ex) {
      LogHome.getLog().info("DAO 访问异常", ex);
    }return null;
  }

  public DboCollection getVersionManagerByCondition(BoQueryContext actionContext, String queryText, String queryStartDateTime, String queryEndDateTime)
    throws UserException
  {
    try
    {
      if (!queryStartDateTime.equals("")) {
        queryStartDateTime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(queryStartDateTime));
      }

      if (!queryEndDateTime.equals("")) {
        queryEndDateTime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(queryEndDateTime));
      }
      return getVersionManagerDAO().getVersionManagerByCondition(actionContext, queryText, queryStartDateTime, queryEndDateTime);
    } catch (Exception ex) {
      LogHome.getLog().info("DAO 访问异常", ex);
    }return null;
  }

  public DataObjectList getAllVersionManager(BoActionContext actionContext)
    throws UserException
  {
    try
    {
      return getVersionManagerDAO().getAllVersionManager(actionContext);
    } catch (Exception ex) {
      LogHome.getLog().info("DAO 访问异常", ex);
    }return null;
  }

  public String getProductSP(BoActionContext actionContext) throws UserException
  {
    try {
      return TnmsRuntime.getInstance().get("PRODUCT_SP");
    } catch (Exception ex) {
      LogHome.getLog().info(ex);
    }return null;
  }

  public boolean getSupportMstp(BoActionContext actionContext) throws UserException
  {
    try {
      return TnmsRuntime.getInstance().equals("SUPPORT_MSTP", Boolean.TRUE.toString());
    } catch (Exception ex) {
      LogHome.getLog().info(ex);
    }return false;
  }

  public String getProductType(BoActionContext actionContext) throws UserException
  {
    try
    {
      return TnmsRuntime.getInstance().get("PRODUCT_TYPE");
    } catch (Exception ex) {
      LogHome.getLog().info(ex);
    }return null;
  }

  public String getDefaultTheme(BoActionContext actionContext)
    throws UserException
  {
    try
    {
      return TnmsRuntime.getInstance().get("DEFAULT_THEME");
    } catch (Exception ex) {
      LogHome.getLog().info(ex);
    }return null;
  }

  public Boolean getSupportLogicalWireSeg(BoActionContext actionContext)
    throws UserException
  {
    try
    {
      return Boolean.valueOf(TnmsRuntime.getInstance().equals("SUPPORT_LOGICAL_WIRE_SEG", Boolean.TRUE.toString()));
    } catch (Exception ex) {
      LogHome.getLog().info(ex);
    }return null;
  }

  public HashMap getActionFilters(BoActionContext actionContext) throws UserException
  {
    try {
      return ActionFilterCfg.getInstance().getActionFilters();
    } catch (Exception ex) {
      LogHome.getLog().info(ex);
    }return null;
  }

  public DboCollection getVersionAttach(BoActionContext actionContext, String cuid) throws Exception
  {
    return getVersionManagerDAO().getVersionAttach(actionContext, cuid);
  }

  public String addDbo(BoActionContext actionContext, VersionAttach dbo) throws Exception {
    try {
      Long id = Long.valueOf(getMaxCount(actionContext).longValue() + 1L);
      dbo.setId(id.longValue());
      getVersionManagerDAO().addDbo(actionContext, dbo);
      return id.toString();
    } catch (Exception ex) {
      LogHome.getLog().error("获取割接信息附件失败!", ex);
      throw new UserException(ex.getMessage());
    }
  }

  private Long getMaxCount(BoActionContext actionContext) throws UserException {
    try {
      return getVersionManagerDAO().getMaxCount(actionContext);
    } catch (Exception ex) {
      LogHome.getLog().error("获取附件失败!", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public VersionAttach getAttachFile(BoActionContext dbContext, String attachId) throws UserException
  {
    try {
      return getVersionManagerDAO().getAttachFile(dbContext, attachId);
    } catch (Exception ex) {
      LogHome.getLog().info("读取附件出错,", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public String delAttachFile(BoActionContext dbContext, String attachId) throws UserException {
    try {
      return getVersionManagerDAO().delAttachFile(dbContext, attachId);
    } catch (Exception ex) {
      LogHome.getLog().error("删除割接信息附件失败!", ex);
      throw new UserException(ex.getMessage());
    }
  }

  public String getBuildVersion(BoActionContext actionContext) throws UserException {
    try {
      return ProjectVersion.getBuildVersion();
    } catch (Exception ex) {
      LogHome.getLog().info(ex);
    }return null;
  }

  public boolean getStartNanfangTheme(BoActionContext actionContext) throws UserException
  {
    try {
      return TnmsRuntime.getInstance().equals("START_NANFANG_THEME", Boolean.TRUE.toString());
    } catch (Exception ex) {
      LogHome.getLog().info(ex);
    }return false;
  }

  public boolean getVipTraph(BoActionContext actionContext) throws UserException {
    try {
      return TnmsRuntime.getInstance().equals("VIP_TRAPH", Boolean.TRUE.toString());
    } catch (Exception ex) {
      LogHome.getLog().info(ex);
    }return false;
  }

  public HashMap getTnmsRuntimeCfgParams(BoActionContext actionContext) throws UserException
  {
    String productSP = getProductSP(actionContext);
    String productType = getProductType(actionContext);
    boolean startNanfangTheme = getStartNanfangTheme(actionContext);
    boolean vipTraph = getVipTraph(actionContext);

    HashMap map = new HashMap();
    map.put("productSP", productSP);
    map.put("productType", productType);
    map.put("startNanfangTheme", Boolean.valueOf(startNanfangTheme));
    map.put("vipTraph", Boolean.valueOf(vipTraph));
    return map;
  }

  public HashMap getRuntimeCfgParams(BoActionContext actionContext) throws UserException
  {
    try {
      District systemDistrict = null;
      Boolean supportLogicalWireSeg = Boolean.valueOf(false);
      systemDistrict = getSecurityBO().getSystemDistrict(new BoActionContext());
      String isSupportLogicalWireSeg = (String)BoCmdFactory.getInstance().execBoCmd("ISystemParaBO.getSystemParaValue", new Object[] { new BoActionContext(), "逻辑光缆段管理", "isSupportLogicalWireSeg" });

      if ((isSupportLogicalWireSeg != null) && (isSupportLogicalWireSeg.trim().equals("1"))) {
        supportLogicalWireSeg = Boolean.valueOf(true);
      }
      HashMap actionFilterMap = getActionFilters(actionContext);

      HashMap map = new HashMap();
      map.put("systemDistrict", systemDistrict);
      map.put("supportLogicalWireSeg", supportLogicalWireSeg);
      map.put("actionFilterMap", actionFilterMap);
      return map;
    } catch (Exception e) {
      throw new UserException(e);
    }
  }

  private ISecurityBO getSecurityBO() {
    return (ISecurityBO)BoHomeFactory.getInstance().getBO(ISecurityBO.class);
  }
}