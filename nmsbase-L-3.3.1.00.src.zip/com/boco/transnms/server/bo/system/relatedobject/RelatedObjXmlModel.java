package com.boco.transnms.server.bo.system.relatedobject;

import com.boco.common.util.xml.AbstractXmlModel;
import com.boco.transnms.xsdmap.relatedobject.ObjectRelationListType;

public class RelatedObjXmlModel extends AbstractXmlModel
{
  public RelatedObjXmlModel(String modelFileName)
    throws Exception
  {
    super("com.boco.transnms.xsdmap.relatedobject", modelFileName);
  }

  public ObjectRelationListType getQueryRootModel()
  {
    return (ObjectRelationListType)getRootModel();
  }
}