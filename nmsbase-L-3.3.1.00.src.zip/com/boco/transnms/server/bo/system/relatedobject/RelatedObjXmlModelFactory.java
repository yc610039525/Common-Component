package com.boco.transnms.server.bo.system.relatedobject;

import com.boco.transnms.xsdmap.relatedobject.ObjectRelationListType;
import com.boco.transnms.xsdmap.relatedobject.ObjectRelationType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RelatedObjXmlModelFactory
{
  private Map<String, ObjectRelationType> relatedObjTable = new HashMap();

  public RelatedObjXmlModelFactory()
  {
  }

  public RelatedObjXmlModelFactory(String modelFileName)
    throws Exception
  {
    RelatedObjXmlModel relatedObjXmlModel = new RelatedObjXmlModel(modelFileName);
    List relatedObjList = relatedObjXmlModel.getQueryRootModel().getObjectRelationList();
    for (int i = 0; i < relatedObjList.size(); i++) {
      ObjectRelationType objType = (ObjectRelationType)relatedObjList.get(i);
      this.relatedObjTable.put(objType.getClassName(), objType);
    }
  }

  public ObjectRelationType getObjTypeByClassName(String className)
  {
    return (ObjectRelationType)this.relatedObjTable.get(className);
  }

  public List getItemModelByClassName(String className, boolean isRecursion)
  {
    List relatedObjList = new ArrayList();
    ObjectRelationType objType = getObjTypeByClassName(className);
    if (objType != null) {
      if (isRecursion)
        getRelatedObjList(objType, relatedObjList);
      else {
        getNotRecursionRelatedObjList(objType, relatedObjList);
      }
    }
    return relatedObjList;
  }

  private void getNotRecursionRelatedObjList(ObjectRelationType objType, List relatedObjList)
  {
    if ((objType.getChildClassNames() != null) && (objType.getChildClassNames().trim().length() > 0)) {
      String[] childClassNames = objType.getChildClassNames().split(",");
      for (int i = 0; i < childClassNames.length; i++) {
        ObjectRelationType relatedObjType = getObjTypeByClassName(childClassNames[i].trim());
        relatedObjList.add(relatedObjType);
      }
    }
  }

  private void getRelatedObjList(ObjectRelationType objType, List relatedObjList)
  {
    if ((objType.getChildClassNames() != null) && (objType.getChildClassNames().trim().length() > 0)) {
      String[] childClassNames = objType.getChildClassNames().split(",");
      for (int i = 0; i < childClassNames.length; i++) {
        ObjectRelationType nextObjType = getObjTypeByClassName(childClassNames[i].trim());
        if (relatedObjList.size() > 0) {
          checkList(relatedObjList, nextObjType);
          relatedObjList.add(0, nextObjType);
        } else {
          relatedObjList.add(nextObjType);
        }

        getRelatedObjList(nextObjType, relatedObjList);
      }
    }
  }

  private void checkList(List relatedObjList, ObjectRelationType nextObjType) {
    for (int j = 0; j < relatedObjList.size(); j++) {
      ObjectRelationType relatedObjType = (ObjectRelationType)relatedObjList.get(j);
      if (nextObjType.getClassName().trim() == relatedObjType.getClassName().trim())
        relatedObjList.remove(j);
    }
  }
}