package com.boco.transnms.server.export;

import com.boco.graphkit.ext.ExtendUtils;
import java.io.Serializable;

public class Label2Property
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private String label;
  private String propertyName;

  public String getLabel()
  {
    return this.label;
  }

  public void setLabel(String label) {
    this.label = ExtendUtils.xmlTextFilter(label);
  }

  public String getPropertyName() {
    return this.propertyName;
  }

  public void setPropertyName(String propertyName) {
    this.propertyName = propertyName;
  }
}