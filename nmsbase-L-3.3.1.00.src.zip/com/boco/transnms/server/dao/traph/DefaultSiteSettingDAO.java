package com.boco.transnms.server.dao.traph;

import com.boco.transnms.common.dto.UserObjectCfg;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.dao.base.AbstractDAO;

public class DefaultSiteSettingDAO extends AbstractDAO
{
  public DefaultSiteSettingDAO()
  {
    super("DefaultSiteSettingDAO");
  }

  public DboCollection getDefaultSiteSetting(BoQueryContext actionContext, String sysCuid) throws Exception {
    String sql = "";
    String sql0 = "SELECT * FROM USER_OBJECT_CFG";
    if ((!sysCuid.equals("")) && (sysCuid.length() > 0)) {
      sql = "USER_CUID = '" + sysCuid + "'";
    }
    if (sql.length() > 0)
      sql = sql + " AND OBJECT_CUID like 'SITE%' ";
    else {
      sql = "OBJECT_CUID like 'SITE%' ";
    }
    if (sql.length() > 0)
      sql = sql0 + " WHERE " + sql;
    else {
      sql = sql0;
    }
    return super.selectDBOs(actionContext, sql, new GenericDO[] { new UserObjectCfg() });
  }
  public DataObjectList getDefaultSiteSettingnew(BoQueryContext actionContext, String sysCuid) throws Exception {
    String sql = "";
    String sql0 = "SELECT OBJECT_CUID,OBJECTID FROM USER_OBJECT_CFG";
    if ((!sysCuid.equals("")) && (sysCuid.length() > 0)) {
      sql = "USER_CUID = '" + sysCuid + "'";
    }
    if (sql.length() > 0)
      sql = sql + " AND OBJECT_CUID like 'SITE%' ";
    else {
      sql = "OBJECT_CUID like 'SITE%' ";
    }
    if (sql.length() > 0)
      sql = sql0 + " WHERE " + sql;
    else {
      sql = sql0;
    }
    return super.selectDBOs(sql, new Class[] { String.class, Long.TYPE });
  }
  public DataObjectList getDefaultAccesspointSettingnew(BoQueryContext actionContext, String sysCuid) throws Exception {
    String sql = "";
    String sql0 = "SELECT OBJECT_CUID,OBJECTID FROM USER_OBJECT_CFG";
    if ((!sysCuid.equals("")) && (sysCuid.length() > 0)) {
      sql = "USER_CUID = '" + sysCuid + "'";
    }
    if (sql.length() > 0)
      sql = sql + " AND OBJECT_CUID like 'ACCESSPOINT%' ";
    else {
      sql = "OBJECT_CUID like 'ACCESSPOINT%' ";
    }
    if (sql.length() > 0)
      sql = sql0 + " WHERE " + sql;
    else {
      sql = sql0;
    }
    return super.selectDBOs(sql, new Class[] { String.class, Long.TYPE });
  }
  public DboCollection getDefaultRoomSetting(BoQueryContext actionContext, String sysCuid) throws Exception {
    String sql = "";
    String sql0 = "SELECT * FROM USER_OBJECT_CFG";
    if ((!sysCuid.equals("")) && (sysCuid.length() > 0)) {
      sql = "USER_CUID = '" + sysCuid + "'";
    }
    if (sql.length() > 0)
      sql = sql + " AND OBJECT_CUID like 'ROOM%' ";
    else {
      sql = "OBJECT_CUID like 'ROOM%' ";
    }
    if (sql.length() > 0)
      sql = sql0 + " WHERE " + sql;
    else {
      sql = sql0;
    }
    return super.selectDBOs(actionContext, sql, new GenericDO[] { new UserObjectCfg() });
  }

  public DataObjectList getDefaultRoomSettingnew(BoQueryContext actionContext, String sysCuid) throws Exception {
    String sql = "";
    String sql0 = "SELECT OBJECT_CUID,OBJECTID FROM USER_OBJECT_CFG";
    if ((!sysCuid.equals("")) && (sysCuid.length() > 0)) {
      sql = "USER_CUID = '" + sysCuid + "'";
    }
    if (sql.length() > 0)
      sql = sql + " AND OBJECT_CUID like 'ROOM%' ";
    else {
      sql = "OBJECT_CUID like 'ROOM%' ";
    }
    if (sql.length() > 0)
      sql = sql0 + " WHERE " + sql;
    else {
      sql = sql0;
    }
    return super.selectDBOs(sql, new Class[] { String.class, Long.TYPE });
  }
  public UserObjectCfg addDefaultSiteSetting(BoActionContext actionContext, UserObjectCfg dbo) throws Exception {
    super.createObject(actionContext, dbo);
    return dbo;
  }

  public UserObjectCfg addDefaultRoomSetting(BoActionContext actionContext, UserObjectCfg dbo) throws Exception {
    super.createObject(actionContext, dbo);
    return dbo;
  }

  public void deleteDefaultSiteSetting(BoActionContext actionContext, String objectId) throws Exception {
    UserObjectCfg userObjectCfg = new UserObjectCfg();
    userObjectCfg.setObjectId(objectId);
    super.deleteObject(actionContext, userObjectCfg);
  }

  public void deleteDefaultRoomSetting(BoActionContext actionContext, String objectId) throws Exception {
    UserObjectCfg userObjectCfg = new UserObjectCfg();
    userObjectCfg.setObjectId(objectId);
    super.deleteObject(actionContext, userObjectCfg);
  }
}