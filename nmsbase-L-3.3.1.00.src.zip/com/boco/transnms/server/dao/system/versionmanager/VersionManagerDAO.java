package com.boco.transnms.server.dao.system.versionmanager;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.VersionAttach;
import com.boco.transnms.common.dto.VersionManager;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboBlob;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.dao.base.AbstractDAO;
import com.boco.transnms.server.dao.base.SqlQueryDaoCmd;
import org.apache.commons.logging.Log;

public class VersionManagerDAO extends AbstractDAO
{
  public VersionManagerDAO()
  {
    super("VersionManagerDAO");
  }

  public VersionManager getVersionManager(BoActionContext actionContext, Long objectId)
    throws Exception
  {
    VersionManager versionManager = new VersionManager();
    versionManager.setObjectNum(objectId.longValue());
    return (VersionManager)super.getObject(versionManager);
  }

  public VersionManager addVersionManager(BoActionContext actionContext, VersionManager dbo)
    throws Exception
  {
    super.createObject(actionContext, dbo);
    return dbo;
  }

  public void modifyVersionManager(BoActionContext actionContext, VersionManager dbo)
    throws Exception
  {
    super.updateObject(actionContext, dbo);
  }

  public void deleteVersionManager(BoActionContext actionContext, Long objectId)
    throws Exception
  {
    GenericDO dbo = new GenericDO();
    dbo.setObjectNum(objectId.longValue());
    super.deleteObject(actionContext, dbo);
  }

  public DataObjectList getAllVersionManager(BoActionContext actionContext)
    throws Exception
  {
    return super.getAllObjByClass(new VersionManager(), 0);
  }

  public DboCollection getVersionManagerByCondition(BoQueryContext queryContext, String queryText, String queryStartDateTime, String queryEndDateTime)
    throws Exception
  {
    String sql = "";
    String sql0 = "SELECT * FROM VERSION_MANAGER";

    if ((!queryText.equals("")) && (queryText.length() > 0)) {
      sql = "VERSION_NUMBER LIKE '%" + queryText + "%'";
    }
    if ((!queryStartDateTime.equals("")) && (!queryEndDateTime.equals(""))) {
      if ((!sql.equals("")) && (sql.length() > 0)) {
        sql = sql + " AND ";
      }
      sql = sql + "INSTALL_DATATIME" + " >= " + queryStartDateTime + " AND " + "INSTALL_DATATIME" + " <= " + queryEndDateTime;
    }
    if ((!queryStartDateTime.equals("")) && (queryEndDateTime.equals(""))) {
      if ((!sql.equals("")) && (sql.length() > 0)) {
        sql = sql + " AND ";
      }
      sql = sql + "INSTALL_DATATIME" + " >= " + queryStartDateTime;
    }
    if ((queryStartDateTime.equals("")) && (!queryEndDateTime.equals(""))) {
      if ((!sql.equals("")) && (sql.length() > 0)) {
        sql = sql + " AND ";
      }
      sql = sql + "INSTALL_DATATIME" + " <= " + queryEndDateTime;
    }
    if (sql.length() > 0) {
      sql = sql0 + " WHERE " + sql;
    }
    else {
      sql = sql0;
    }
    sql = sql + " order by " + "INSTALL_DATATIME";
    return super.selectDBOs(queryContext, sql, new GenericDO[] { new VersionManager() });
  }
  public DboCollection getVersionAttach(BoActionContext actionContext, String cuid) throws Exception {
    String sql = "SELECT * FROM VERSION_ATTACH WHERE RELATED_VERSION_CUID ='" + cuid + "'";
    SqlQueryDaoCmd cmd = super.createSqlQueryDaoCmd();
    DboCollection collection = cmd.selectDBOs(sql, new GenericDO[] { new VersionAttach() });
    if (collection.size() > 0) {
      return collection;
    }
    return null;
  }

  public void addDbo(BoActionContext actionContext, VersionAttach dbo)
    throws Exception
  {
    super.insertDbo(actionContext, dbo);
    modifyAttachField(actionContext, dbo);
  }

  public void modifyAttachField(BoActionContext actionContext, VersionAttach obj) throws Exception
  {
    try {
      String sql = "ID=" + obj.getId() + "";
      modifyBlob(actionContext, obj.getClassName(), "ATTACH_DATA", obj.getAttachData(), sql);
    } catch (Exception ex) {
      LogHome.getLog().info("DAO修改 附件 出错", ex);
      throw new Exception(ex);
    }
  }

  public void modifyBlob(BoActionContext actionContext, String tableName, String blobFieldName, DboBlob blob, String sqlCond) throws Exception {
    try { super.updateBlob(actionContext, tableName, blobFieldName, blob, sqlCond);
    } catch (Exception ex) {
      throw new UserException(ex.getMessage());
    }
  }

  public Long getMaxCount(BoActionContext actionContext) throws Exception { String sql = "";
    try {
      sql = "select max(ID) from VERSION_ATTACH";
      SqlQueryDaoCmd cmd = super.createSqlQueryDaoCmd();
      DataObjectList list = cmd.selectDBOs(sql, new Class[] { Integer.TYPE });
      GenericDO dbo = (GenericDO)list.get(0);
      int count = dbo.getAttrInt("1");
      return new Long(count + "");
    } catch (Exception ex) {
      LogHome.getLog().info("读取 附件出错," + sql, ex);
      throw new Exception(ex);
    } }

  public VersionAttach getAttachFile(BoActionContext dbContext, String attachId) throws Exception {
    String sql = "";
    try
    {
      sql = "select *  from VERSION_ATTACH where ID=" + attachId + " ";

      SqlQueryDaoCmd cmd = super.createSqlQueryDaoCmd();
      DboCollection collection = cmd.selectDBOs(sql, new GenericDO[] { new VersionAttach() });
      if (collection.size() > 0) {
        return (VersionAttach)collection.getAttrField("VERSION_ATTACH", 0);
      }
      return null;
    }
    catch (Exception ex) {
      LogHome.getLog().info("读取附件出错", ex);
      throw new Exception(ex);
    }
  }

  public String delAttachFile(BoActionContext dbContext, String attachId) throws Exception {
    String sql = "";
    try
    {
      sql = "delete   from VERSION_ATTACH where ID=" + attachId + " ";

      super.execSql(sql);
      return attachId;
    } catch (Exception ex) {
      LogHome.getLog().info("读取 附件出错," + sql, ex);
      throw new Exception(ex);
    }
  }
}