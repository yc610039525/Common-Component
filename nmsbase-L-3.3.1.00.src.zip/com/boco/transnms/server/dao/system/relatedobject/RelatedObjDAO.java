package com.boco.transnms.server.dao.system.relatedobject;

import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.dao.base.AbstractDAO;

public class RelatedObjDAO extends AbstractDAO
{
  public GenericDO getGenericDOById(BoActionContext actionContext, Long objectId)
    throws Exception
  {
    GenericDO dbo = new GenericDO();
    dbo.setObjectNum(objectId.longValue());
    return super.getObject(dbo);
  }
}