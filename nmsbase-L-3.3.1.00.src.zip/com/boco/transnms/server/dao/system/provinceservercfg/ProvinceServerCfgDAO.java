package com.boco.transnms.server.dao.system.provinceservercfg;

import com.boco.common.util.debug.LogHome;
import com.boco.transnms.common.dto.ProvinceSeverCfg;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.dao.base.GenericDAO;
import org.apache.commons.logging.Log;

public class ProvinceServerCfgDAO extends GenericDAO
{
  public ProvinceServerCfgDAO()
  {
    super("ProvinceServerCfgDAO");
  }

  public ProvinceSeverCfg getProvinceSeverCfgByObjectId(Long provinceSeverCfgObjectId) throws Exception {
    ProvinceSeverCfg provinceSeverCfg = new ProvinceSeverCfg();
    provinceSeverCfg.setObjectNum(provinceSeverCfgObjectId.longValue());
    provinceSeverCfg = (ProvinceSeverCfg)super.getObject(provinceSeverCfg);
    return provinceSeverCfg;
  }

  public ProvinceSeverCfg getProvinceSeverCfgByCuid(String proviceSeverCfgCuid) throws Exception
  {
    String sqlCon = "CUID='" + proviceSeverCfgCuid + "'";

    ProvinceSeverCfg provinceSeverCfg = null;

    DataObjectList provinceSeverCfgs = super.getObjectsBySql(sqlCon, new ProvinceSeverCfg(), 0);

    if (provinceSeverCfgs.size() > 0) {
      provinceSeverCfg = (ProvinceSeverCfg)provinceSeverCfgs.get(0);
    }

    return provinceSeverCfg;
  }

  public Long addProvinceSeverCfg(BoActionContext actionContext, ProvinceSeverCfg provinceSeverCfg) throws Exception {
    provinceSeverCfg.setClassName("PROVINCE_SEVER_CFG");
    provinceSeverCfg.clearUnknowAttrs();
    super.createObject(actionContext, provinceSeverCfg);
    LogHome.getLog().info("provinceSeverCfg新增Objectid:" + provinceSeverCfg.getObjectNum() + ",CUID:" + provinceSeverCfg.getCuid() + ",serverAddr:" + provinceSeverCfg.getServerAddr());
    return Long.valueOf(provinceSeverCfg.getObjectNum());
  }

  public void modifyProvinceSeverCfg(BoActionContext actionContext, ProvinceSeverCfg provinceSeverCfg) throws Exception {
    provinceSeverCfg.clearUnknowAttrs();
    provinceSeverCfg.setClassName("PROVINCE_SEVER_CFG");
    super.updateObject(actionContext, provinceSeverCfg);
    LogHome.getLog().info("provinceSeverCfg修改Objectid:" + provinceSeverCfg.getObjectNum() + ",CUID:" + provinceSeverCfg.getCuid() + ",serverAddr:" + provinceSeverCfg.getServerAddr());
  }

  public void deleteProvinceSeverCfg(BoActionContext actionContext, ProvinceSeverCfg provinceSeverCfg) throws Exception {
    LogHome.getLog().info("provinceSeverCfg删除Objectid:" + provinceSeverCfg.getObjectNum() + ",CUID:" + provinceSeverCfg.getCuid());
    provinceSeverCfg.setClassName("PROVINCE_SEVER_CFG");
    super.deleteObject(actionContext, provinceSeverCfg);
  }

  public Boolean isUniqueProvinceServerAddr(ProvinceSeverCfg provinceSeverCfg) throws Exception {
    int count = super.getCalculateValue("select count(*) from PROVINCE_SEVER_CFG where SERVER_ADDR='" + provinceSeverCfg.getServerAddr() + "'");

    if (count == 1) {
      return Boolean.valueOf(true);
    }
    return Boolean.valueOf(false);
  }

  public DataObjectList getAllProvinceSeverCfg(BoActionContext actionContext) throws Exception {
    String sqlCon = "1=1";
    DataObjectList provinceSeverCfgs = null;
    provinceSeverCfgs = super.getObjectsBySql(sqlCon, new ProvinceSeverCfg(), 0);

    return provinceSeverCfgs;
  }

  public ProvinceSeverCfg getProvinceSeverCfgByReCuid(String relatedProcinceCuid) throws Exception
  {
    String sqlCon = "RELATED_DISTRICT_CUID = '" + relatedProcinceCuid + "'";
    DataObjectList provinceSeverCfgs = null;
    ProvinceSeverCfg provinceSeverCfg = new ProvinceSeverCfg();
    provinceSeverCfgs = super.getObjectsBySql(sqlCon, new ProvinceSeverCfg(), 0);
    if (provinceSeverCfgs.size() > 0) {
      provinceSeverCfg = (ProvinceSeverCfg)provinceSeverCfgs.get(0);
    }
    return provinceSeverCfg;
  }
}