package com.boco.transnms.server.dao.system.callboard;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboBlob;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.misc.CallboardAttach;
import com.boco.transnms.server.dao.base.AbstractDAO;
import com.boco.transnms.server.dao.base.SqlQueryDaoCmd;
import org.apache.commons.logging.Log;

public class CallboardAttachDAO extends AbstractDAO
{
  public Long getMaxCount(BoActionContext actionContext)
    throws Exception
  {
    String sql = "";
    try {
      sql = "select max(ID) from CALLBOARD_ATTACH";
      SqlQueryDaoCmd cmd = super.createSqlQueryDaoCmd();
      DataObjectList list = cmd.selectDBOs(sql, new Class[] { Integer.TYPE });
      GenericDO dbo = (GenericDO)list.get(0);
      int count = dbo.getAttrInt("1");
      return new Long(count + "");
    } catch (Exception ex) {
      LogHome.getLog().info("读取 附件出错," + sql, ex);
      throw new Exception(ex);
    }
  }

  public Long getCountByCuid(BoActionContext actionContext, String CUID) throws Exception {
    String sql = "";
    try {
      sql = "select count(*) from CALLBOARD_ATTACH where RELATED_CALLBOARD_CUID='" + CUID + "' ";

      SqlQueryDaoCmd cmd = super.createSqlQueryDaoCmd();
      DataObjectList list = cmd.selectDBOs(sql, new Class[] { Integer.TYPE });
      GenericDO dbo = (GenericDO)list.get(0);
      int count = dbo.getAttrInt("1");
      return new Long(count + "");
    } catch (Exception ex) {
      LogHome.getLog().info("读取 附件出错," + sql, ex);
      throw new Exception(ex);
    }
  }

  public String delAttachFile(BoActionContext dbContext, String attachId) throws Exception {
    String sql = "";
    try
    {
      sql = "delete   from CALLBOARD_ATTACH where ID=" + attachId;

      super.execSql(sql);
      return attachId;
    } catch (Exception ex) {
      LogHome.getLog().info("读取 附件出错," + sql, ex);
      throw new Exception(ex);
    }
  }

  public String delAttachByCuid(BoActionContext dbContext, String CUID) throws Exception {
    String sql = "";
    try {
      sql = "delete  from CALLBOARD_ATTACH where RELATED_CALLBOARD_CUID='" + CUID + "' ";

      super.execSql(sql);
      return CUID;
    } catch (Exception ex) {
      LogHome.getLog().info("读取 附件出错," + sql, ex);
      throw new Exception(ex);
    }
  }

  public void addDbo(BoActionContext actionContext, CallboardAttach dbo) throws Exception {
    super.insertDbo(actionContext, dbo);
    modifyAttachField(actionContext, dbo);
  }

  public void modifyAttachField(BoActionContext actionContext, CallboardAttach obj) throws Exception
  {
    try
    {
      String sql = "ID=" + obj.getId() + "";
      modifyBlob(actionContext, obj.getClassName(), "ATTACH_DATA", obj.getAttachData(), sql);
    } catch (Exception ex) {
      LogHome.getLog().info("DAO修改 附件 出错", ex);
      throw new Exception(ex);
    }
  }

  public void modifyBlob(BoActionContext actionContext, String tableName, String blobFieldName, DboBlob blob, String sqlCond) throws Exception {
    try {
      super.updateBlob(actionContext, tableName, blobFieldName, blob, sqlCond);
    } catch (Exception ex) {
      throw new UserException(ex.getMessage());
    }
  }

  public DboCollection getCallboardAttachBySql(BoActionContext actionContext, String sqll) throws Exception {
    try {
      SqlQueryDaoCmd cmd = super.createSqlQueryDaoCmd();
      DboCollection collection = cmd.selectDBOs(sqll, new GenericDO[] { new CallboardAttach() });
      if (collection.size() > 0) {
        return collection;
      }
      return null;
    }
    catch (Exception ex) {
      LogHome.getLog().info("读取附件出错", ex);
      throw new Exception(ex);
    }
  }

  public DboCollection getAttachByRelatedCuid(BoActionContext actionContext, String relateCallboardId) throws Exception {
    String sql = "";
    try
    {
      sql = "select *  from CALLBOARD_ATTACH where RELATED_CALLBOARD_CUID='" + relateCallboardId + "' ";

      DboCollection rtn = null;
      SqlQueryDaoCmd cmd = super.createSqlQueryDaoCmd();
      rtn = cmd.selectDBOs(sql, new GenericDO[] { new CallboardAttach() });
      if (rtn.size() > 0) {
        return rtn;
      }
      return null;
    }
    catch (Exception ex) {
      LogHome.getLog().info("读取附件出错", ex);
      throw new Exception(ex);
    }
  }

  public CallboardAttach getAttachFile(BoActionContext dbContext, String attachId) throws Exception {
    String sql = "";
    try
    {
      sql = "select *  from CALLBOARD_ATTACH where ID=" + attachId + " ";

      SqlQueryDaoCmd cmd = super.createSqlQueryDaoCmd();
      DboCollection collection = cmd.selectDBOs(sql, new GenericDO[] { new CallboardAttach() });
      if (collection.size() > 0) {
        return (CallboardAttach)collection.getAttrField("CALLBOARD_ATTACH", 0);
      }
      return null;
    }
    catch (Exception ex) {
      LogHome.getLog().info("读取附件出错", ex);
      throw new Exception(ex);
    }
  }
}