package com.boco.transnms.server.dao.system.callboard;

import com.boco.common.util.db.DbConnManager;
import com.boco.common.util.db.DbContext;
import com.boco.common.util.db.DbType;
import com.boco.common.util.db.SqlHelper;
import com.boco.common.util.lang.TimeFormatHelper;
import com.boco.transnms.common.dto.CallBoard;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.dao.base.AbstractDAO;
import com.boco.transnms.server.dao.base.DaoHelper;
import java.sql.Timestamp;
import java.util.Date;

public class CallBoardDAO extends AbstractDAO
{
  public CallBoardDAO()
  {
    super("CallBoardDAO");
  }

  public CallBoard getCallBoard(BoActionContext actionContext, Long objectId) throws Exception {
    CallBoard callBoard = new CallBoard();
    callBoard.setObjectNum(objectId.longValue());
    return (CallBoard)super.getObject(callBoard);
  }

  public CallBoard addCallBoard(BoActionContext actionContext, CallBoard dbo) throws Exception {
    super.createObject(actionContext, dbo);
    return dbo;
  }

  public void modifyCallBoard(BoActionContext actionContext, CallBoard dbo) throws Exception {
    super.updateObject(actionContext, dbo);
  }

  public void deleteCallBoard(BoActionContext actionContext, Long objectId) throws Exception {
    GenericDO dbo = new GenericDO();
    dbo.setObjectNum(objectId.longValue());
    super.deleteObject(actionContext, dbo);
  }

  public DataObjectList getAllCallBoard(BoActionContext actionContext) throws Exception {
    return super.getAllObjByClass(new CallBoard(), 0);
  }

  public DboCollection getCallBoardByCondition(BoQueryContext queryContext, String queryAuthor, String queryStartDateTime, String queryEndDateTime, String queryInfoTitle, String orderString) throws Exception
  {
    String sql = "";

    if (DaoHelper.isNotEmpty(queryAuthor)) {
      sql = "AUTHOR LIKE '%" + queryAuthor.trim() + "%'";
    }
    if ((DaoHelper.isNotEmpty(queryStartDateTime)) && (DaoHelper.isNotEmpty(queryEndDateTime))) {
      if (sql.length() != 0) {
        sql = sql + " AND " + "BEGINDATETIME" + " >=" + queryStartDateTime + " AND " + "ENDDATETIME" + " <=" + queryEndDateTime;
      }
      else {
        sql = "BEGINDATETIME >=" + queryStartDateTime + " AND " + "ENDDATETIME" + " <=" + queryEndDateTime;
      }
    }

    if ((DaoHelper.isNotEmpty(queryStartDateTime)) && (!DaoHelper.isNotEmpty(queryEndDateTime))) {
      if (sql.length() != 0)
        sql = sql + " AND " + "BEGINDATETIME" + " >=" + queryStartDateTime;
      else {
        sql = "BEGINDATETIME >=" + queryStartDateTime;
      }
    }
    if ((!DaoHelper.isNotEmpty(queryStartDateTime)) && (DaoHelper.isNotEmpty(queryEndDateTime))) {
      if (sql.length() != 0) {
        sql = sql + " AND " + "ENDDATETIME" + " <=" + queryEndDateTime;
      }
      else {
        sql = "ENDDATETIME <=" + queryEndDateTime;
      }
    }
    if (queryInfoTitle.length() != 0) {
      if (sql.length() != 0) {
        sql = sql + " AND " + "INFOTITLE" + " LIKE '%" + queryInfoTitle.trim() + "%'";
      }
      else {
        sql = "INFOTITLE LIKE '%" + queryInfoTitle.trim() + "%'";
      }
    }

    if (sql.length() > 0)
      sql = "select * from CALL_BOARD where  " + sql;
    else {
      sql = "select * from CALL_BOARD";
    }

    if (DaoHelper.isNotEmpty(orderString))
      sql = sql + " ORDER BY " + orderString;
    else {
      sql = sql + " ORDER BY " + "AUTHOR" + "," + "BEGINDATETIME";
    }
    return super.selectDBOs(queryContext, sql, new GenericDO[] { new CallBoard() });
  }

  public DboCollection getCallBoardByHenan(BoQueryContext queryContext)
    throws Exception
  {
    String sql = "";
    sql = "AUTHOR NOT LIKE '%系统%' ";
    DbType dbType = DbConnManager.getInstance().getDbContext().getDbType();
    String queryCD = SqlHelper.getTimestamp(dbType, new Timestamp(new Date().getTime()));
    sql = sql + " AND " + "BEGINDATETIME" + " <= " + queryCD + " AND " + "ENDDATETIME" + " >= " + queryCD;
    sql = "select * from CALL_BOARD where  " + sql + " ORDER BY CREATE_TIME desc";

    return super.selectDBOs(queryContext, sql, new GenericDO[] { new CallBoard() });
  }

  public DataObjectList getCallBoardByCondition(BoActionContext actionContext, String currentDate) throws Exception
  {
    String limitSql = "select LIMIT_VALUE_HIGH from WARNING_LIMIT where RELATED_ORDER=1 and RELATED_WARNING_ID=7";
    DataObjectList dbos = super.selectDBOs(limitSql, new Class[] { Integer.TYPE });
    int limitValue = 100;
    if ((dbos != null) && (dbos.size() > 0)) {
      GenericDO limitDbo = (GenericDO)dbos.get(0);
      limitValue = limitDbo.getAttrInt("1", 0);
    }
    String selectCuidSql = "select distinct RELATED_CALLBOARD_CUID from RESOURCE_ALARM_ATTACH where USE_SCALE>=" + limitValue;
    DataObjectList callBoardCuidsDbos = super.selectDBOs(selectCuidSql, new Class[] { String.class });
    String callBoardCuids = "";
    if ((callBoardCuidsDbos != null) && (callBoardCuidsDbos.size() > 0)) {
      for (int i = 0; i < callBoardCuidsDbos.size(); i++) {
        GenericDO dbo = (GenericDO)callBoardCuidsDbos.get(i);
        String cuid = dbo.getAttrString("1");
        if (i == 0)
          callBoardCuids = cuid;
        else {
          callBoardCuids = callBoardCuids + "," + cuid;
        }
      }
    }
    String sql = new String();
    String queryCD = "";
    DbType dbType = DbConnManager.getInstance().getDbContext().getDbType();
    queryCD = SqlHelper.getTimestamp(dbType, TimeFormatHelper.getFormatTimestamp(currentDate));
    sql = sql + "BEGINDATETIME" + "<" + queryCD + " AND " + "ENDDATETIME" + ">" + queryCD + " and " + "CUID" + " not in ( select distinct RELATED_CALLBOARD_CUID from RESOURCE_ALARM_ATTACH where RELATED_CALLBOARD_CUID not in ('" + callBoardCuids.replaceAll(",", "','") + "')) order by CREATE_TIME desc";

    return super.getObjectsBySql(sql, new CallBoard(), 0);
  }

  public DataObjectList getTransElementStatis(BoQueryContext queryContext, String districtCuid) throws Exception {
    String sql = "SELECT B.LABEL_CN,A.SDH_NUMBER,A.WDM_NUMBER,B.CUID FROM TRANS_ELEMENT_STATIS A, DISTRICT B WHERE A.DISTRICT_CUID LIKE'" + districtCuid + "%' AND A.DISTRICT_CUID=B.CUID";
    sql = sql + " ORDER BY  B.SERVICE_LEVEL,B.SEVICE_LEADER_CODE DESC";
    return super.selectDBOs(sql, new Class[] { String.class, String.class, String.class, String.class });
  }

  public DataObjectList getTraphSatistic(BoQueryContext queryContext, String districtCuid) throws Exception {
    String sql = "SELECT B.LABEL_CN,A.TRAPH_NUMBER,A.TD_TRAPH_NUMBER,B.CUID FROM TRAPH_STATISTIC A, DISTRICT B WHERE A.DISTRICT_CUID LIKE'" + districtCuid + "%' AND A.DISTRICT_CUID=B.CUID";
    sql = sql + " ORDER BY  B.SERVICE_LEVEL,B.SEVICE_LEADER_CODE DESC";
    return super.selectDBOs(sql, new Class[] { String.class, String.class, String.class, String.class });
  }

  public DataObjectList getDuctSatistic(BoQueryContext queryContext, String districtCuid) throws Exception {
    String sql = "SELECT B.LABEL_CN,A.WIRE_SEG_LENGTH,A.DUCT_SEG_LENGTH,A.POLEWAY_SEG_LENGTH,A.STONEWAY_SEG_LENGTH,A.HANGWALL_SEG_LENGTH,A.UPLINE_SEG_LENGTH,B.CUID FROM DUCT_STATISTIC A, DISTRICT B WHERE A.DISTRICT_CUID LIKE'" + districtCuid + "%' AND A.DISTRICT_CUID=B.CUID";
    sql = sql + " ORDER BY  B.SERVICE_LEVEL,B.SEVICE_LEADER_CODE DESC";
    return super.selectDBOs(sql, new Class[] { String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class });
  }

  public DataObjectList getAlarmSatistic(BoQueryContext queryContext, String districtCuid) throws Exception {
    String sql = "SELECT B.LABEL_CN,A.CURRENT_ALARM,A.TD_ALARM,A.PROJECT_CESSION_ALARM,B.CUID FROM ALARM_STATISTIC A, DISTRICT B WHERE A.DISTRICT_CUID LIKE'" + districtCuid + "%' AND A.DISTRICT_CUID=B.CUID";
    sql = sql + " ORDER BY  B.SERVICE_LEVEL , B.SEVICE_LEADER_CODE DESC";
    return super.selectDBOs(sql, new Class[] { String.class, String.class, String.class, String.class, String.class });
  }

  public DataObjectList getAllSubDistrict(BoQueryContext queryContext, String districtCuid) throws Exception {
    String sql = "SELECT LABEL_CN FROM DISTRICT WHERE CUID LIKE'" + districtCuid + "%'";
    if (districtCuid.equals("DISTRICT-00001"))
      sql = sql + "AND (SERVICE_LEVEL=0 OR SERVICE_LEVEL=1)";
    else {
      sql = sql + "AND (SERVICE_LEVEL=1 OR SERVICE_LEVEL=2)";
    }
    return super.selectDBOs(sql, new Class[] { String.class });
  }

  public CallBoard getCallBoardByCuid(String cuid) throws Exception {
    String sql = "SELECT * FROM CALL_BOARD WHERE CUID='" + cuid + "'";
    DboCollection dbos = super.selectDBOs(sql, new GenericDO[] { new CallBoard() });
    CallBoard dbo = new CallBoard();
    if ((dbos != null) && (dbos.size() > 0)) {
      dbo = (CallBoard)dbos.getAttrField("CALL_BOARD", 0);
    }
    return dbo;
  }
}