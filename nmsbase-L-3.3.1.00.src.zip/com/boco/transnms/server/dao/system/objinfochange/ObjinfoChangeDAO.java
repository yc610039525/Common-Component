package com.boco.transnms.server.dao.system.objinfochange;

import com.boco.transnms.common.dto.ObjInfChangeLog;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.dao.base.AbstractDAO;
import com.boco.transnms.server.dao.base.DaoHelper;

public class ObjinfoChangeDAO extends AbstractDAO
{
  public ObjinfoChangeDAO()
  {
    super("ObjinfoChangeDAO");
  }

  public DboCollection getObjInfChanageBySql(BoQueryContext boQueryContext, String classname, String createtime, String lastmodifytime, String getflag, String objchangetype, String orderString)
    throws Exception
  {
    StringBuffer sql = new StringBuffer("SELECT * FROM OBJ_INF_CHANGE_LOG WHERE 1=1 ");
    if (DaoHelper.isNotEmpty(classname)) {
      sql.append(" AND CHANGE_CLASS_NAME = '" + classname + "'");
    }
    if ((DaoHelper.isNotEmpty(createtime)) && (DaoHelper.isNotEmpty(lastmodifytime))) {
      sql.append(" AND CREATE_TIME  >=" + createtime + " AND LAST_MODIFY_TIME " + " <=" + lastmodifytime);
    }
    if ((DaoHelper.isNotEmpty(createtime)) && (!DaoHelper.isNotEmpty(lastmodifytime))) {
      sql.append(" AND CREATE_TIME  >=" + createtime);
    }
    if ((DaoHelper.isNotEmpty(lastmodifytime)) && (!DaoHelper.isNotEmpty(createtime))) {
      sql.append(" AND LAST_MODIFY_TIME  <=" + lastmodifytime);
    }
    if (DaoHelper.isNotEmpty(getflag)) {
      sql.append(" AND GET_FLAG = " + getflag + "");
    }
    if (DaoHelper.isNotEmpty(objchangetype)) {
      long objchange = Long.valueOf(objchangetype).longValue() + 1L;
      sql.append(" AND OBJ_CHANGE_TYPE = " + objchange + "");
    }

    if (DaoHelper.isNotEmpty(orderString)) {
      sql.append(" ORDER BY " + orderString);
    }
    return super.selectDBOs(boQueryContext, sql.toString(), new GenericDO[] { new ObjInfChangeLog() });
  }

  public void deleteobjInf(BoActionContext actionContext, Long objectId)
    throws Exception
  {
    GenericDO dbo = new GenericDO();
    dbo.setObjectNum(objectId.longValue());
    super.deleteObject(actionContext, dbo);
  }

  public void deleteAllObjInf(BoActionContext actionContext, String classname)
    throws Exception
  {
    super.deleteAll(actionContext, classname);
  }
}