package com.boco.transnms.server.dao.system.ipaddrInfo;

import com.boco.transnms.common.dto.IpaddrInfo;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.dao.base.AbstractDAO;
import com.boco.transnms.server.dao.base.DaoHelper;

public class IpaddrInfoDAO extends AbstractDAO
{
  public IpaddrInfoDAO()
  {
    super("IpaddrInfoDAO");
  }

  public IpaddrInfo addIpaddrInfo(BoActionContext actionContext, IpaddrInfo ipaddrInfo) throws Exception {
    super.createObject(actionContext, ipaddrInfo);
    return ipaddrInfo;
  }

  public void modifyIpaddrInfo(BoActionContext actionContext, IpaddrInfo ipaddrInfo) throws Exception {
    super.updateObject(actionContext, ipaddrInfo);
  }

  public void deleteIpaddrInfo(BoActionContext actionContext, IpaddrInfo ipaddrInfo) throws Exception {
    super.deleteObject(actionContext, ipaddrInfo);
  }

  public void deleteIpaddrInfos(BoActionContext actionContext, DataObjectList ipaddrInfos) throws Exception {
    super.deleteObjects(actionContext, ipaddrInfos);
  }

  public DataObjectList getIpaddrInfoByCondition(BoActionContext actionContext, String sql) throws Exception {
    if (DaoHelper.isNotEmpty(sql)) {
      return super.getObjectsBySql(sql, new IpaddrInfo(), 0);
    }
    return new DataObjectList();
  }

  public DboCollection getIpaddrInfoByPage(BoQueryContext queryContext, String sql) throws Exception
  {
    if (DaoHelper.isNotEmpty(sql)) {
      return super.selectDBOs(queryContext, sql, new GenericDO[] { new IpaddrInfo() });
    }
    return new DboCollection();
  }

  public IpaddrInfo getIpaddrInfo(BoActionContext actionContext, long ObjectId) throws Exception
  {
    IpaddrInfo ipaddrInfo = new IpaddrInfo();
    ipaddrInfo.setObjectNum(ObjectId);
    return (IpaddrInfo)super.getObject(ipaddrInfo);
  }

  public DataObjectList addIpaddrInfos(BoActionContext actionContext, DataObjectList ipaddrInfos) throws Exception {
    super.createObjects(actionContext, ipaddrInfos);
    return ipaddrInfos;
  }

  public IpaddrInfo getIpaddrInfoByIp(BoActionContext actionContext, String ip) throws Exception {
    String sql = "IP_ADDR = '" + ip + "'";
    DataObjectList dbos = super.getObjectsBySql(sql, new IpaddrInfo(), 0);
    if ((dbos == null) || (dbos.size() == 0)) {
      return null;
    }
    return (IpaddrInfo)dbos.get(0);
  }
}