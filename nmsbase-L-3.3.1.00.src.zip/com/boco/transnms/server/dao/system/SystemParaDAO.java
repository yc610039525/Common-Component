package com.boco.transnms.server.dao.system;

import com.boco.transnms.common.dto.DevinfoConfig;
import com.boco.transnms.common.dto.ShortCodeInfo;
import com.boco.transnms.common.dto.SystemPara;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.dao.base.AbstractDAO;

public class SystemParaDAO extends AbstractDAO
{
  public SystemParaDAO()
  {
    super("SystemParaDAO");
  }

  public DboCollection getAllSystemPara() throws Exception {
    String sql = "select * from SYSTEM_PARA";
    return super.selectDBOs(sql, new GenericDO[] { new SystemPara() });
  }

  public DboCollection getSystemParaByClass(String productType, String paraClassName) throws Exception {
    String sql = "select * from SYSTEM_PARA";
    sql = sql + " where PARA_CLASS_NAME='" + paraClassName + "'";
    sql = sql + " and PRODUCT_TYPE_NAME='" + productType + "'";
    sql = sql + " order by PARA_NAME";
    return super.selectDBOs(sql, new GenericDO[] { new SystemPara() });
  }

  public DboCollection querySystemPara(BoQueryContext queryContext, String querySPName, String queryParaClassName, String queryParaName, String queryParaLableCN)
    throws Exception
  {
    String sql = "select * from SYSTEM_PARA";
    sql = sql + " where (1=1) ";
    if ((querySPName != null) && (querySPName.trim().length() > 0) && (!querySPName.equals("DEFAULT")))
      sql = sql + " and PRODUCT_SP_NAME like '%" + querySPName + "%'";
    if ((queryParaClassName != null) && (queryParaClassName.trim().length() > 0))
      sql = sql + " and PARA_CLASS_NAME = '" + queryParaClassName + "'";
    if ((queryParaName != null) && (queryParaName.trim().length() > 0))
      sql = sql + " and PARA_NAME like '%" + queryParaName + "%'";
    if ((queryParaLableCN != null) && (queryParaLableCN.trim().length() > 0))
      sql = sql + " and PARA_LABELCN like '%" + queryParaLableCN + "%'";
    sql = sql + " order by PARA_NAME";
    return super.selectDBOs(queryContext, sql, new GenericDO[] { new SystemPara() });
  }

  public DboCollection getSingleSystemPara(String querySPName, String queryParaClassName, String queryParaName, String queryParaTypeName)
    throws Exception
  {
    String sql = "select * from SYSTEM_PARA";
    sql = sql + " where PRODUCT_SP_NAME = '" + querySPName + "'";
    sql = sql + " and PARA_CLASS_NAME = '" + queryParaClassName + "'";
    sql = sql + " and PARA_NAME = '" + queryParaName + "'";
    sql = sql + " and PRODUCT_TYPE_NAME = '" + queryParaTypeName + "'";
    sql = sql + " order by PARA_NAME";
    return super.selectDBOs(sql, new GenericDO[] { new SystemPara() });
  }

  public void modifySingleSystemPara(String querySPName, String queryParaClassName, String queryParaName, String queryParaTypeName, String paraValue) throws Exception
  {
    String sql = "update SYSTEM_PARA";
    sql = sql + " set PARA_VALUE = '" + paraValue + "'";
    sql = sql + " where PRODUCT_SP_NAME = '" + querySPName + "'";
    sql = sql + " and PARA_CLASS_NAME = '" + queryParaClassName + "'";
    sql = sql + " and PARA_NAME = '" + queryParaName + "'";
    sql = sql + " and PRODUCT_TYPE_NAME = '" + queryParaTypeName + "'";
    super.execSql(sql);
  }

  public void addSingleSystemPara(String querySPName, String queryParaClassName, String queryParaTypeName, String queryParaName, String queryParaDesc, String queryParaValue, String queryParaAddition, String queryParaLableCN)
    throws Exception
  {
    String sql = "INSERT INTO SYSTEM_PARA";
    sql = sql + " ( PRODUCT_SP_NAME , PARA_CLASS_NAME , PRODUCT_TYPE_NAME , PARA_NAME , PARA_DESC , PARA_VALUE , PARA_ADDITION , PARA_LABELCN )  VALUES( '" + querySPName + "' , '" + queryParaClassName + "' , '" + queryParaTypeName + "' , '" + queryParaName + "' , '" + queryParaDesc + "' , '" + queryParaValue + "' , '" + queryParaAddition + "' , '" + queryParaLableCN + "' ) ";

    super.execSql(sql);
  }

  public void delSingleSystemPara(String querySPName, String queryParaClassName, String queryParaName, String queryParaTypeName)
    throws Exception
  {
    String sql = "delete from SYSTEM_PARA";
    sql = sql + " where PRODUCT_SP_NAME = '" + querySPName + "'";
    sql = sql + " and PARA_CLASS_NAME = '" + queryParaClassName + "'";
    sql = sql + " and PARA_NAME = '" + queryParaName + "'";
    sql = sql + " and PRODUCT_TYPE_NAME = '" + queryParaTypeName + "'";
    super.execSql(sql);
  }

  public DataObjectList getDistinctTable(String ClassName, String KEYNAME) throws Exception
  {
    String sql = "select distinct " + KEYNAME + " from " + ClassName;
    return super.selectDBOs(sql, new Class[] { String.class });
  }

  public DboCollection getShortCodeByCondition(BoQueryContext queryContext, String shortCode, String orderString)
    throws Exception
  {
    String sql = "SELECT * FROM SHORT_CODE_INFO";
    if ((shortCode != null) && (shortCode.trim().length() > 0)) {
      sql = sql + " WHERE " + "SHORT_CODE" + " LIKE '%" + shortCode + "%'";
    }
    if ((orderString != null) && (orderString.trim().length() > 0)) {
      sql = sql + " ORDER BY " + orderString;
    }
    return super.selectDBOs(queryContext, sql, new GenericDO[] { new ShortCodeInfo() });
  }

  public ShortCodeInfo addShortCode(BoQueryContext queryContext, ShortCodeInfo shortCodeInfo)
    throws Exception
  {
    super.createObject(queryContext, shortCodeInfo);
    return shortCodeInfo;
  }

  public void deleteShortCode(BoActionContext actionContext, String[] cuids)
    throws Exception
  {
    String sql = "DELETE FROM SHORT_CODE_INFO WHERE CUID IN (";
    for (int i = 0; i < cuids.length; i++) {
      if (i == 0)
        sql = sql + "'" + cuids[i] + "'";
      else {
        sql = sql + ",'" + cuids[i] + "'";
      }
    }
    sql = sql + ")";
    super.execSql(sql);
  }

  public ShortCodeInfo getShortCodeByCuid(BoActionContext actionContext, String cuid)
    throws Exception
  {
    ShortCodeInfo dbo = new ShortCodeInfo();
    if (cuid != null)
      dbo.setCuid(cuid);
    else {
      dbo.setCuid("");
    }
    return (ShortCodeInfo)super.getObjByCuid(dbo);
  }

  public void modifyShortCodeByCuid(BoActionContext actionContext, ShortCodeInfo shortCodeInfo)
    throws Exception
  {
    shortCodeInfo.clearUnknowAttrs();
    shortCodeInfo.convAllObjAttrToCuid();
    super.updateObject(actionContext, shortCodeInfo);
  }

  public DboCollection isAdded(BoActionContext actionContext, String shortCode)
    throws Exception
  {
    String sql = "SELECT * FROM SHORT_CODE_INFO WHERE SHORT_CODE= '" + shortCode + "'";
    return super.selectDBOs(sql, new GenericDO[] { new ShortCodeInfo() });
  }

  public DboCollection getShortCodeExcelByCondition(BoActionContext actionContext, String shortCode)
    throws Exception
  {
    String sql = "SELECT * FROM SHORT_CODE_INFO";
    if ((shortCode != null) && (shortCode.trim().length() > 0)) {
      sql = sql + " WHERE " + "SHORT_CODE" + " LIKE '%" + shortCode + "%'";
    }
    return super.selectDBOs(sql, new GenericDO[] { new ShortCodeInfo() });
  }

  public void addDevInfoImpConfig(DataObjectList dbos) throws Exception {
    String delAll = "delete from DEVINFO_CONFIG";
    super.execSql(delAll);
    super.createObjects(new BoActionContext(), dbos);
  }

  public DboCollection getDevInfoImpConfig() throws Exception {
    String sql = "select * from DEVINFO_CONFIG";
    return super.selectDBOs(sql, new GenericDO[] { new DevinfoConfig() });
  }

  public DboCollection getParaByCondition(BoActionContext actionContext, String paraClassName, String paraName, String productType, String productSP) throws Exception
  {
    String sql = "SELECT * FROM SYSTEM_PARA WHERE PARA_CLASS_NAME ='" + paraClassName + "' AND " + "PARA_NAME" + " ='" + paraName + "' AND " + "PRODUCT_TYPE_NAME" + "='" + productType + "' AND " + "PRODUCT_SP_NAME" + "='" + productSP + "'";

    return super.selectDBOs(sql, new GenericDO[] { new SystemPara() });
  }
  public SystemPara addSystemPara(BoActionContext actionContext, SystemPara dbo) throws Exception {
    super.createObject(actionContext, dbo);
    return dbo;
  }
  public void modifySystemPara(BoActionContext actionContext, SystemPara dbo) throws Exception {
    dbo.clearUnknowAttrs();
    dbo.convAllObjAttrToCuid();
    super.updateObject(actionContext, dbo);
  }
  public void deletePara(BoActionContext actionContext, Long objectId) throws Exception {
    GenericDO dbo = new GenericDO();
    dbo.setObjectNum(objectId.longValue());
    super.deleteObject(actionContext, dbo);
  }
}