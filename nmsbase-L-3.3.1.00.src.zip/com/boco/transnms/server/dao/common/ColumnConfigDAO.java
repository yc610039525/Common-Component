package com.boco.transnms.server.dao.common;

import com.boco.transnms.common.dto.ColumnConfig;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.dao.base.GenericDAO;

public class ColumnConfigDAO extends GenericDAO
{
  public ColumnConfigDAO()
  {
    super("ColumnConfigDAO");
  }

  public void deleteColumnConfigByUser(BoActionContext actionContext, String userCuid, String objectType) throws Exception {
    String sql = "";
    sql = "delete from COLUMN_CONFIG where USER_CUID='" + userCuid + "'";

    if (objectType != null) {
      sql = sql + " and OBJECT_TYPE='" + objectType + "'";
    }
    super.execSql(sql);
  }

  public DataObjectList getColumnConfigByUser(BoActionContext actionContext, String userCuid, String objectType) throws Exception {
    DataObjectList retList = new DataObjectList();
    String sql = "select * from COLUMN_CONFIG where OBJECT_TYPE = '" + objectType + "'" + " and " + "USER_CUID" + " = '" + userCuid + "'" + " order by " + "COLUMN_INDEX";

    DboCollection collection = super.selectDBOs(sql, new GenericDO[] { new ColumnConfig() });
    if (collection.size() > 0) {
      for (int i = 0; i < collection.size(); i++) {
        retList.add((ColumnConfig)collection.getQueryDbo(i, "COLUMN_CONFIG"));
      }
    }
    return retList;
  }
}