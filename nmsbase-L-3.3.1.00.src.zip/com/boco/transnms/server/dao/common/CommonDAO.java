package com.boco.transnms.server.dao.common;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.Ptp;
import com.boco.transnms.common.dto.TopoLink;
import com.boco.transnms.common.dto.TransElement;
import com.boco.transnms.common.dto.Traph;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.misc.LayerRate;
import com.boco.transnms.server.dao.base.GenericDAO;
import java.sql.Timestamp;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.logging.Log;

public class CommonDAO extends GenericDAO
{
  public DataObjectList getAllSwitchCfgTypeInfo()
    throws Exception
  {
    String sql = "select KEY_NUM,KEY_VALUE,LEADER_CODE from SWITCHDEV_CFG_TYPE order by LEADER_CODE";
    return super.selectDBOs(sql, new Class[] { Long.TYPE, String.class, Long.TYPE });
  }

  public static String getRelatedCuid(Object obj)
  {
    if ((obj instanceof GenericDO))
      return ((GenericDO)obj).getCuid();
    if ((obj instanceof String))
      return (String)obj;
    if (obj != null) {
      return obj.toString();
    }
    return null;
  }

  public static String getWhereSqlByValues(String alias, GenericDO dboTemplate, String attrName, List attrValues)
  {
    String sql = "";
    Class attrType = dboTemplate.getAttrType(attrName);
    for (Iterator i$ = attrValues.iterator(); i$.hasNext(); ) { Object attrValue = i$.next();
      if (attrValue != null)
      {
        String sqlByType = getSqlByType(attrType, attrValue);
        if (sqlByType != null)
        {
          if (sql.length() > 0) {
            sql = new StringBuilder().append(sql).append(" , ").toString();
          }
          sql = new StringBuilder().append(sql).append(sqlByType).toString();
        }
      } } if (sql.length() > 0) {
      return new StringBuilder().append(alias == null ? attrName : new StringBuilder().append(alias).append(".").append(attrName).toString()).append(" in (").append(sql).append(")").toString();
    }

    return sql;
  }

  public static String getSqlByType(Class attrType, Object attrValue)
  {
    if ((attrType == Boolean.class) || (attrType == Boolean.TYPE)) {
      int val = ((Boolean)attrValue).booleanValue() ? 1 : 0;
      return new StringBuilder().append("").append(val).toString();
    }if ((attrType == Long.class) || (attrType == Long.TYPE))
      return new StringBuilder().append("").append(attrValue).toString();
    if ((attrType == Double.class) || (attrType == Double.TYPE))
      return new StringBuilder().append("").append(attrValue).toString();
    if (attrType == String.class) {
      return new StringBuilder().append("'").append(attrValue).append("'").toString();
    }
    throw new UserException(new StringBuilder().append("不支持此数据类型").append(attrType).append(" ！").toString());
  }

  public GenericDO getCacheSimplePoint(String cuid)
  {
    GenericDO cuidDbo = new GenericDO();
    cuidDbo.setCuid(cuid);
    try {
      cuidDbo = super.getObjByCuid(cuidDbo);
    } catch (Exception ex) {
      LogHome.getLog().error(new StringBuilder().append("获取对象错误").append(ex).toString());
    }
    return cuidDbo;
  }

  public GenericDO getCacheSimpleLine(String cuid) {
    GenericDO cuidDbo = new GenericDO();
    cuidDbo.setCuid(cuid);
    try {
      cuidDbo = super.getObjByCuid(cuidDbo);
    } catch (Exception ex) {
      LogHome.getLog().error(new StringBuilder().append("获取对象错误").append(ex).toString());
    }
    return cuidDbo;
  }

  public LayerRate getLayerRateByNum(Integer num)
  {
    try
    {
      if ((num.intValue() == -1) || (num.intValue() == 0)) {
        LogHome.getLog("RTU").error(new StringBuilder().append("layerratenum:").append(num).toString());
        return null;
      }
      LayerRate rate = null;
      String sql = new StringBuilder().append("select * from LAYER_RATE where KEY_NUM = ").append(num).toString();

      DboCollection collection = super.selectDBOs(sql, new GenericDO[] { new LayerRate() });
      if (collection.size() > 0) {
        rate = (LayerRate)collection.getAttrField("LAYER_RATE", 0);
      } else {
        rate = null;
        LogHome.getLog("RTU").error(new StringBuilder().append("layerratenum:").append(num).append("在数据库中不存在").toString());
      }
      return rate;
    } catch (Throwable e) {
      LogHome.getLog().error(new StringBuilder().append("根据编号取层速率出错").append(num).toString(), e);
    }return null;
  }

  public DataObjectList getTraphBySql(BoQueryContext boQueryContext, String cuid, String className)
    throws Exception
  {
    DataObjectList returnList = new DataObjectList();
    String sqlSelect = "SELECT DISTINCT  T.CUID,T.LABEL_CN,T.ALIAS,T.TRAPH_LEVEL,T.TRAPH_RATE,T.USER_NAME,T.END_SWITCH_DEV_A,T.END_SWITCHDEV_PORT_A,T.SDXC1_A,T.SDXC2_A,T.END_PORT_A,T.END_DF_PORT_A,T.END_SWITCH_DF_PORT_A,T.EXTPATH1_A,T.PATHINFO,T.END_DF_PORT_Z,T.END_SWITCH_DF_PORT_Z,T.END_PORT_Z,T.END_SWITCH_DEV_Z,T.END_SWITCHDEV_PORT_Z,T.SDXC1_Z,T.SDXC2_Z,T.EXTPATH1_Z,T.USED_DATE,T.DISPATCH_NAME,T.OBJECTID";

    String sql = new StringBuilder().append(sqlSelect).append(" FROM TRAPH T,TRANSPATH_TO_TRAPH B, CTP_TO_TRANSPATH C ").append("WHERE T.CUID=B.RELATED_TRAPH_CUID AND B.RELATED_TRANSPATH_CUID=C.RELATED_TRANSPATH_CUID  AND C.").toString();

    if (className.equals("PTP")) {
      Ptp ptp = (Ptp)getObjByCuid(cuid);
      String relatedNeCuid = ptp.getRelatedNeCuid();
      TransElement element = (TransElement)getObjByCuid(relatedNeCuid);
      if (element.getSignalType() == 8L)
        sql = new StringBuilder().append(sqlSelect).append(" FROM TRAPH T,PTN_PATH P WHERE P.RELATED_ROUTE_CUID=T.CUID AND ( P.RELATED_A_PTP_CUID in ('").append(cuid).append("')  or  P.RELATED_A_PTP_CUID2 in ('").append(cuid).append("') or P.RELATED_Z_PTP_CUID in ('").append(cuid).append("')  or P.RELATED_Z_PTP_CUID2 in ('").append(cuid).append("'))").toString();
      else
        sql = new StringBuilder().append(sql).append("RELATED_PTP_CUID ='").append(cuid).append("'").toString();
    }
    else if (className.equals("CTP")) {
      sql = new StringBuilder().append(sql).append("RELATED_CTP_CUID ='").append(cuid).append("'").toString();
    } else if (className.equals("CARD")) {
      sql = new StringBuilder().append(sql).append("RELATED_CARD_CUID ='").append(cuid).append("'").toString();
    } else if (className.equals("TRANS_ELEMENT")) {
      TransElement element = (TransElement)getObjByCuid(cuid);
      if (element.getSignalType() == 8L)
        sql = new StringBuilder().append(sqlSelect).append(" FROM TRAPH T,PTN_PATH P WHERE P.RELATED_ROUTE_CUID=T.CUID AND ( P.RELATED_A_NE_CUID in ('").append(cuid).append("')  or  P.RELATED_A_NE_CUID2 in ('").append(cuid).append("') or P.RELATED_Z_NE_CUID in ('").append(cuid).append("')  or P.RELATED_Z_NE_CUID2 in ('").append(cuid).append("'))").toString();
      else
        sql = new StringBuilder().append(sql).append("RELATED_NE_CUID ='").append(cuid).append("'").toString();
    }
    else if (className.equals("TOPO_LINK")) {
      TopoLink topoLink = (TopoLink)getObjByCuid(new TopoLink(cuid));
      cuid = (String)topoLink.getAttrValue("ORIG_POINT_CUID");
      sql = new StringBuilder().append(sql).append("RELATED_PTP_CUID ='").append(cuid).append("'").toString();
    } else if ((className.equals("DDFPORT")) || (className.equals("ODFPORT"))) {
      sql = new StringBuilder().append(sqlSelect).append(" FROM TRAPH T,DFPORT_TO_TRAPH D").append(" WHERE T.CUID=D.RELATED_TRAPH_CUID AND D.DF_PORT_CUID = '").append(cuid).append("'").toString();
    }

    DataObjectList list = null;
    if (boQueryContext == null) {
      list = super.selectDBOs(sql, new Class[] { String.class, String.class, String.class, Long.TYPE, Long.TYPE, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, Timestamp.class, String.class, Long.TYPE });
    }
    else
    {
      list = super.selectDBOs(boQueryContext, sql, new Class[] { String.class, String.class, String.class, Long.TYPE, Long.TYPE, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, Timestamp.class, String.class, Long.TYPE });
    }

    if (list != null) {
      for (GenericDO gdo : list) {
        Traph traph = new Traph();
        traph.setCuid(gdo.getAttrString("1"));
        traph.setLabelCn(gdo.getAttrString("2"));
        traph.setAlias(gdo.getAttrString("3"));
        traph.setTraphLevel(gdo.getAttrLong("4"));
        traph.setTraphRate(gdo.getAttrLong("5"));
        traph.setUserName(gdo.getAttrString("6"));
        traph.setEndSwitchDevA(gdo.getAttrString("7"));
        traph.setEndSwitchdevPortA(gdo.getAttrString("8"));
        traph.setSdxc1A(gdo.getAttrString("9"));
        traph.setSdxc2A(gdo.getAttrString("10"));
        traph.setEndPortA(gdo.getAttrString("11"));
        traph.setEndDfPortA(gdo.getAttrString("12"));
        traph.setEndSwitchDfPortA(gdo.getAttrString("13"));
        traph.setExtpath1A(gdo.getAttrString("14"));
        traph.setPathinfo(gdo.getAttrString("15"));
        traph.setEndDfPortZ(gdo.getAttrString("16"));
        traph.setEndSwitchDfPortZ(gdo.getAttrString("17"));
        traph.setEndPortZ(gdo.getAttrString("18"));
        traph.setEndSwitchDevZ(gdo.getAttrString("19"));
        traph.setEndSwitchdevPortZ(gdo.getAttrString("20"));
        traph.setSdxc1Z(gdo.getAttrString("21"));
        traph.setSdxc2Z(gdo.getAttrString("22"));
        traph.setExtpath1Z(gdo.getAttrString("23"));
        traph.setUsedDate(gdo.getAttrDateTime("24"));
        traph.setDispatchName(gdo.getAttrString("25"));
        traph.setObjectId(new StringBuilder().append(gdo.getAttrLong("26")).append("").toString());
        returnList.add(traph);
      }
      returnList.setCountValue(list.getCountValue());
      returnList.setOffset(list.getOffset());
      returnList.setFetchSize(list.getFetchSize());
    }
    return returnList;
  }
}