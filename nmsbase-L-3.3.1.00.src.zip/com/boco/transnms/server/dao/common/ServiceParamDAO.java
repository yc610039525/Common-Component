package com.boco.transnms.server.dao.common;

import com.boco.transnms.common.dto.ServiceParam;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.dao.base.GenericDAO;

public class ServiceParamDAO extends GenericDAO
{
  public ServiceParamDAO()
  {
    super("ServiceParamDAO");
  }
  public void deleteServiceParam(BoActionContext actionContext, String cuid) throws Exception {
    GenericDO dbo = new GenericDO();
    dbo.setCuid(cuid);
    dbo = super.getObjByCuid(dbo);
    super.deleteObject(actionContext, dbo);
  }

  public void modifyServiceParam(BoActionContext actionContext, ServiceParam dbo) throws Exception {
    super.updateObject(actionContext, dbo);
  }

  public ServiceParam addServiceParam(BoActionContext actionContext, ServiceParam dbo) throws Exception {
    super.createObject(actionContext, dbo);
    return dbo;
  }

  public void addServiceParams(BoActionContext actionContext, DataObjectList dbos) throws Exception {
    super.createObjects(actionContext, dbos);
  }

  public DataObjectList getServiceParamsBySql(BoActionContext actionContext, long ServiceParamType, String serverName) throws Exception {
    String sql = "SERVICE_TYPE = " + ServiceParamType + " ";
    if (serverName != null) {
      sql = sql + " and SERVER_NAME = '" + serverName + "' ";
    }
    DataObjectList dbos = super.getObjectsBySql(sql, new ServiceParam(), 0);
    return dbos;
  }
}