package com.boco.transnms.server.dao.common;

import com.boco.transnms.common.dto.TemplateGroup;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.dao.base.GenericDAO;
import java.util.List;

public class TemplateGroupDAO extends GenericDAO
{
  public DataObjectList getAllTemplateGroup(BoActionContext actionContext)
    throws Exception
  {
    return super.getAllObjByClass(new TemplateGroup(), 0);
  }

  public TemplateGroup getTemplateGroup(BoActionContext actionContext, Long objectId) throws Exception {
    TemplateGroup dbo = new TemplateGroup();
    dbo.setObjectNum(objectId.longValue());
    return (TemplateGroup)super.getObject(dbo);
  }

  public TemplateGroup getTemplateGroupByCuid(BoActionContext actionContext, String cuid) throws Exception {
    TemplateGroup dbo = new TemplateGroup();
    dbo.setCuid(cuid);
    return (TemplateGroup)super.getObjByCuid(dbo);
  }

  public TemplateGroup addTemplateGroup(BoActionContext actionContext, TemplateGroup templateGroup) throws Exception {
    templateGroup.clearUnknowAttrs();
    templateGroup.convAllObjAttrToCuid();
    super.createObject(actionContext, templateGroup);
    return templateGroup;
  }

  public TemplateGroup modifyTemplateGroup(BoActionContext actionContext, TemplateGroup templateGroup) throws Exception {
    templateGroup.clearUnknowAttrs();
    templateGroup.convAllObjAttrToCuid();
    super.updateObject(actionContext, templateGroup);
    return templateGroup;
  }

  public void deleteTemplateGroup(BoActionContext actionContext, TemplateGroup templateGroup) throws Exception {
    templateGroup.clearUnknowAttrs();
    templateGroup.convAllObjAttrToCuid();
    super.deleteObject(actionContext, templateGroup);
  }

  public List getTemplateGroupsBySql(BoActionContext actionContext, String sql) throws Exception {
    return super.getObjectsBySql(sql, new TemplateGroup(), 0);
  }
}