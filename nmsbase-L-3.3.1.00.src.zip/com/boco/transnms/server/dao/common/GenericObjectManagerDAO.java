package com.boco.transnms.server.dao.common;

import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericAttrGroup;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.base.GenericObjectModel;
import com.boco.transnms.common.dto.base.GenericQueryModel;
import com.boco.transnms.server.dao.base.GenericDAO;

public class GenericObjectManagerDAO extends GenericDAO
{
  public GenericObjectManagerDAO()
  {
    super("GenericDbCacheDAO");
  }

  public DboCollection getAllDynClassNames() throws Exception {
    String sql = "select distinct DYN_CLASS_NAME";
    sql = sql + ", CLASS_LABEL_CN";
    sql = sql + " from GENERIC_OBJECT_MODEL";
    return super.selectDBOs(sql, new GenericDO[] { new GenericObjectModel() });
  }

  public DboCollection getDynAttrsByclass(String className) throws Exception {
    String sql = "select *  from GENERIC_OBJECT_MODEL";
    sql = sql + " where DYN_CLASS_NAME='" + className + "' ";
    sql = sql + " order by ATTR_NAME";
    return super.selectDBOs(sql, new GenericDO[] { new GenericObjectModel() });
  }

  public DboCollection getDynAttrsOfDynamic() throws Exception {
    String sql = "select *  from GENERIC_OBJECT_MODEL";
    sql = sql + " where IS_DYNAMIC=1";
    return super.selectDBOs(sql, new GenericDO[] { new GenericObjectModel() });
  }

  public GenericObjectModel getDynAttrByCuid(String cuid) throws Exception {
    GenericObjectModel model = null;
    String sql = "select *  from GENERIC_OBJECT_MODEL";
    sql = sql + " where CUID='" + cuid + "'";
    DboCollection dbos = super.selectDBOs(sql, new GenericDO[] { new GenericObjectModel() });
    if (dbos.size() > 0) {
      model = (GenericObjectModel)dbos.getQueryDbo(0, "GENERIC_OBJECT_MODEL");
    }
    return model;
  }

  public boolean isDynAttrExist(GenericObjectModel model, boolean isIncludeCuid) throws Exception {
    String sql = "select count(*) from GENERIC_OBJECT_MODEL where ";
    sql = sql + "DYN_CLASS_NAME='" + model.getDynClassName() + "' ";
    sql = sql + " and ATTR_NAME='" + model.getAttrName() + "' ";
    if (isIncludeCuid) {
      sql = sql + " and CUID!='" + model.getCuid() + "' ";
    }
    int count = super.getCalculateValue(sql);
    return count > 0;
  }

  public boolean isQueryModelExist(GenericQueryModel qModel, boolean isIncludeCuid) throws Exception {
    String sql = "select count(*) from GENERIC_QUERY_MODEL where ";
    sql = sql + "QUERY_ID='" + qModel.getQueryId() + "' ";
    sql = sql + " and QUERY_NAME='" + qModel.getQueryName() + "' ";
    if (isIncludeCuid) {
      sql = sql + " and CUID!='" + qModel.getCuid() + "' ";
    }
    int count = super.getCalculateValue(sql);
    return count > 0;
  }

  public void insertDynAttr(GenericObjectModel model) throws Exception {
    super.insertDbo(new BoActionContext(), model);
  }
  public void insertQueryModel(GenericQueryModel qModel) throws Exception {
    super.insertDbo(new BoActionContext(), qModel);
  }

  public void insertDynAttrs(GenericObjectModel[] models)
    throws Exception
  {
    for (GenericObjectModel model : models)
      super.insertDbo(new BoActionContext(), model);
  }

  public void modifyDynAttr(GenericObjectModel model) throws Exception
  {
    String sqlCond = " where CUID='" + model.getCuid() + "'";
    super.updateDbo(new BoActionContext(), model, sqlCond);
  }
  public void modifyQueryModel(GenericQueryModel qModel) throws Exception {
    String sqlCond = " where CUID='" + qModel.getCuid() + "'";
    super.updateDbo(new BoActionContext(), qModel, sqlCond);
  }

  public void deleteDynAttr(String cuid) throws Exception
  {
    String sql = "delete from GENERIC_OBJECT_MODEL where ";
    sql = sql + "CUID='" + cuid + "'";
    super.execSql(sql);
  }
  public void deleteQueryModel(String cuid) throws Exception {
    String sql = "delete from GENERIC_QUERY_MODEL where ";
    sql = sql + "CUID='" + cuid + "'";
    super.execSql(sql);
  }

  public DboCollection getClassAttrsOfGroup(String groupCuid, String className) throws Exception {
    String sql = "select * from GENERIC_OBJECT_MODEL";
    sql = sql + " where DYN_CLASS_NAME='" + className + "' ";
    sql = sql + " and ATTR_GROUPS like '%" + groupCuid + "%' ";
    return super.selectDBOs(sql, new GenericDO[] { new GenericObjectModel() });
  }
  public DboCollection getClassDynQryAttrs(String className) throws Exception {
    String sql = "select * from GENERIC_OBJECT_MODEL";
    sql = sql + " where DYN_CLASS_NAME='" + className + "' ";

    sql = sql + " and (IS_QUERY=1 or IS_DYNAMIC=1)";
    return super.selectDBOs(sql, new GenericDO[] { new GenericObjectModel() });
  }

  public DboCollection getClassAttrByAttrName(String className, String attrName) throws Exception
  {
    String sql = "select * from GENERIC_OBJECT_MODEL";
    sql = sql + " where DYN_CLASS_NAME='" + className + "' ";
    sql = sql + " and ATTR_NAME = '" + attrName + "' ";
    return super.selectDBOs(sql, new GenericDO[] { new GenericObjectModel() });
  }

  public DboCollection getClassesOfGroup(String groupCuid)
    throws Exception
  {
    String sql = "select DISTINCT CLASS_LABEL_CN from GENERIC_OBJECT_MODEL";
    sql = sql + " where ATTR_GROUPS like '%" + groupCuid + "%' ";
    return super.selectDBOs(sql, new GenericDO[] { new GenericObjectModel() });
  }

  public DboCollection getQueryModelsByClass(String classId) throws Exception {
    String sql = "select * from GENERIC_QUERY_MODEL";
    sql = sql + " where QUERY_ID='" + classId + "' ";
    return super.selectDBOs(sql, new GenericDO[] { new GenericQueryModel() });
  }
  public GenericQueryModel getQueryModelByCuid(String cuid) throws Exception {
    GenericQueryModel rtn = null;
    String sql = "select * from GENERIC_QUERY_MODEL";
    sql = sql + " where CUID='" + cuid + "' ";
    DboCollection dbos = super.selectDBOs(sql, new GenericDO[] { new GenericQueryModel() });
    if (dbos.size() == 1) {
      rtn = (GenericQueryModel)dbos.getAttrField("GENERIC_QUERY_MODEL", 0);
    }
    return rtn;
  }

  public void deleteDynClass(String dynClassName) throws Exception {
    String sql = "delete from GENERIC_OBJECT_MODEL where ";
    sql = sql + "DYN_CLASS_NAME='" + dynClassName + "'";
    super.execSql(sql);
  }

  public void insertAttrGroup(GenericAttrGroup attrGroup) throws Exception {
    super.insertDbo(new BoActionContext(), attrGroup);
  }

  public void modifyAttrGroup(GenericAttrGroup attrGroup) throws Exception {
    String sqlCond = " where CUID='" + attrGroup.getCuid() + "'";
    super.updateDbo(new BoActionContext(), attrGroup, sqlCond);
  }

  public boolean deleteAttrGroup(String cuid) throws Exception {
    boolean rtn = false;
    if (!isGroupInUse(cuid)) {
      String sql = "delete from GENERIC_ATTR_GROUP";
      sql = sql + " where CUID='" + cuid + "'";
      super.execSql(sql);
      rtn = true;
    }
    return rtn;
  }
  public boolean isGroupInUse(String cuid) throws Exception {
    boolean rtn = false;
    String sql = "select count(*) from GENERIC_OBJECT_MODEL where ";
    sql = sql + "ATTR_GROUPS like '%" + cuid + "%'";
    int count = super.getCalculateValue(sql);
    rtn = count > 0;
    return rtn;
  }

  public DboCollection getAllAttrGroup() throws Exception {
    String sql = "select * from GENERIC_ATTR_GROUP";
    return super.selectDBOs(sql, new GenericDO[] { new GenericAttrGroup() });
  }
  public DboCollection getInUseAttrGroup() throws Exception {
    String sql = "select * from GENERIC_ATTR_GROUP";
    sql = sql + " where IS_IN_USE=1";
    return super.selectDBOs(sql, new GenericDO[] { new GenericAttrGroup() });
  }
  public boolean isHasOtherDefaultGroup(String cuid, boolean isIncludeCuid) throws Exception {
    String sql = "select count(*) from GENERIC_ATTR_GROUP";
    sql = sql + " where IS_DEFAULT=1 ";
    if (isIncludeCuid) {
      sql = sql + " and CUID!='" + cuid + "'";
    }
    int count = super.getCalculateValue(sql);
    return count > 0;
  }
  public GenericAttrGroup getAttrGroupByCuid(String cuid) throws Exception {
    String sql = "select * from GENERIC_ATTR_GROUP";
    sql = sql + " where CUID='" + cuid + "'";
    DboCollection dbos = super.selectDBOs(sql, new GenericDO[] { new GenericAttrGroup() });
    GenericAttrGroup dbo = null;
    if (dbos.size() > 0) {
      dbo = (GenericAttrGroup)dbos.getQueryDbo(0, "GENERIC_ATTR_GROUP");
    }
    return dbo;
  }

  public GenericAttrGroup getDefaultAttrGroup() throws Exception {
    String sql = "select * from GENERIC_ATTR_GROUP";
    sql = sql + " where IS_DEFAULT=1";
    DboCollection dbos = super.selectDBOs(sql, new GenericDO[] { new GenericAttrGroup() });
    GenericAttrGroup dbo = null;
    if (dbos.size() > 0) {
      dbo = (GenericAttrGroup)dbos.getQueryDbo(0, "GENERIC_ATTR_GROUP");
    }
    return dbo;
  }

  public boolean isRightAttrGroup(GenericAttrGroup attrGroup, boolean isIncludeCuid) throws Exception
  {
    String sql = "select count(*) from GENERIC_ATTR_GROUP where ";
    sql = sql + "GROUP_NAME='" + attrGroup.getGroupName() + "' ";
    if (isIncludeCuid) {
      sql = sql + " and CUID!='" + attrGroup.getCuid() + "' ";
    }
    int count = super.getCalculateValue(sql);
    return count == 0;
  }

  public boolean hasDefaultGroup() throws Exception {
    boolean rtn = false;
    String sql = "select count(*)  from GENERIC_ATTR_GROUP where IS_DEFAULT=1";
    int count = super.getCalculateValue(sql);
    if (count > 0)
      rtn = true;
    return rtn;
  }

  public boolean isAddAttrInDb(String className, String attrName) {
    try {
      String sql = "select count(" + attrName + ") from " + className;
      super.getCalculateValue(sql);
      return true; } catch (Exception ex) {
    }
    return false;
  }
}