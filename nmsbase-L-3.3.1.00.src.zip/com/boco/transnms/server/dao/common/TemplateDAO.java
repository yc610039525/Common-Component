package com.boco.transnms.server.dao.common;

import com.boco.transnms.common.dto.Card;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboBlob;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.common.Template;
import com.boco.transnms.server.dao.base.GenericDAO;
import java.math.BigDecimal;

public class TemplateDAO extends GenericDAO
{
  public TemplateDAO()
  {
    super("TemplateDAO");
  }

  public void addTemplate(BoActionContext actionContext, Template template)
    throws Exception
  {
    super.insertDbo(actionContext, template);
    if (template.getPic() != null) {
      modifyPicField(actionContext, template);
    }
    if (template.getDataPic() != null)
      modifyDataPicField(actionContext, template);
  }

  public void modifyPicField(BoActionContext actionContext, Template template)
    throws Exception
  {
    if (template.getPic() != null) {
      String sql = "CUID='" + template.getCuid() + "'";
      super.updateBlob(actionContext, "TEMPLATE", "PIC", template.getPic(), sql);
    }
  }

  public void modifyTemplateInfo(BoActionContext actionContext, Template template)
    throws Exception
  {
    String sql = " where CUID='" + template.getCuid() + "'";

    super.updateDbo(actionContext, template, sql);
  }

  public void deleteTemplate(BoActionContext actionContext, Template template)
    throws Exception
  {
    String sql = "";
    sql = "delete from TEMPLATE where CUID='" + template.getCuid() + "'";

    super.execSql(sql);
  }

  public DataObjectList getTemplatesBySql(BoActionContext actionContext, String sql)
    throws Exception
  {
    DataObjectList rstList = new DataObjectList();
    String execSql = "select CUID,NAME,SIGNAL_TYPE,RELATED_VENDOR_CUID,RELATED_TEMPLATEGROUP_CUID,MODEL,TYPE,CREATEUSER,CREATETIME from TEMPLATE where 1=1 and " + sql;

    DboCollection collection = super.selectDBOs(execSql, new GenericDO[] { new Template() });
    for (int i = 0; i < collection.size(); i++) {
      rstList.add(collection.getQueryDbo(i, "TEMPLATE"));
    }
    return rstList;
  }

  public DataObjectList getSimpleTemplatesBySql(BoActionContext actionContext, String sql) throws Exception {
    DataObjectList rstList = new DataObjectList();
    String execSql = "select CUID,NAME,MODEL from TEMPLATE where 1=1 and " + sql;

    rstList = super.selectDBOs(execSql, new Class[] { String.class, String.class, String.class });
    return rstList;
  }

  public DataObjectList getFullTemplatesBySql(BoActionContext actionContext, String sql)
    throws Exception
  {
    DataObjectList rstList = new DataObjectList();
    String execSql = "select CUID,NAME,TYPE,SIGNAL_TYPE,RELATED_VENDOR_CUID,RELATED_TEMPLATEGROUP_CUID,MODEL,CREATEUSER,CREATETIME,PIC,DATAPIC from TEMPLATE where 1=1 and " + sql;

    DboCollection collection = super.selectDBOs(execSql, new GenericDO[] { new Template() });
    for (int i = 0; i < collection.size(); i++) {
      rstList.add(collection.getQueryDbo(i, "TEMPLATE"));
    }
    return rstList;
  }

  public DboBlob getTemplatePic(BoActionContext actionContext, Template template)
    throws Exception
  {
    String sql = "select * from TEMPLATE where CUID='" + template.getCuid() + "'";

    DboCollection collection = super.selectDBOs(sql, new GenericDO[] { new Template() });
    if (collection.size() >= 1) {
      DboBlob blob = (DboBlob)collection.getQueryAttrValue(0, "TEMPLATE", "PIC");

      return blob;
    }
    return null;
  }

  public void addNeDataTemplate(BoActionContext actionContext, Template template)
    throws Exception
  {
    super.insertDbo(actionContext, template);
    if (template.getPic() != null) {
      modifyPicField(actionContext, template);
    }
    if (template.getDataPic() != null)
      modifyDataPicField(actionContext, template);
  }

  public void modifyDataPicField(BoActionContext actionContext, Template template)
    throws Exception
  {
    if (template.getDataPic() != null) {
      String sql = "CUID='" + template.getCuid() + "'";
      super.updateBlob(actionContext, "TEMPLATE", "DATAPIC", template.getDataPic(), sql);
    }
  }

  public DboBlob getTemplateDataPic(BoActionContext actionContext, Template template) throws Exception
  {
    String sql = "select * from TEMPLATE where CUID='" + template.getCuid() + "'";

    DboCollection collection = super.selectDBOs(sql, new GenericDO[] { new Template() });
    if (collection.size() == 1) {
      DboBlob blob = (DboBlob)collection.getQueryAttrValue(0, "TEMPLATE", "DATAPIC");

      return blob;
    }
    return null;
  }

  public Template getTemplateByCuid(BoActionContext actionContext, String templateCuid) throws Exception
  {
    String sql = "select * from TEMPLATE where CUID = '" + templateCuid + "'";

    DboCollection collection = super.selectDBOs(sql, new GenericDO[] { new Template() });
    if (collection.size() > 0) {
      return (Template)collection.getQueryDbo(0, "TEMPLATE");
    }
    return null;
  }

  public Template getTemplateByName(BoActionContext actionContext, String templateName)
    throws Exception
  {
    String sql = "select CUID,NAME,TYPE,SIGNAL_TYPE,RELATED_VENDOR_CUID,RELATED_TEMPLATEGROUP_CUID,MODEL,CREATEUSER,CREATETIME from TEMPLATE where NAME = '" + templateName + "'";

    DboCollection collection = super.selectDBOs(sql, new GenericDO[] { new Template() });
    if (collection.size() > 0) {
      return (Template)collection.getQueryDbo(0, "TEMPLATE");
    }
    return null;
  }

  public Template getTemplateByNameAndType(BoActionContext actionContext, String templateName, int type)
    throws Exception
  {
    String sql = "select CUID,NAME,TYPE,SIGNAL_TYPE,RELATED_VENDOR_CUID,RELATED_TEMPLATEGROUP_CUID,MODEL,CREATEUSER,CREATETIME from TEMPLATE where NAME = '" + templateName + "'" + " AND " + "TYPE" + " = '" + type + "'";

    DboCollection collection = super.selectDBOs(sql, new GenericDO[] { new Template() });
    if (collection.size() > 0) {
      return (Template)collection.getQueryDbo(0, "TEMPLATE");
    }
    return null;
  }

  public Card getCardByLikeFdn(BoActionContext actionContext, String neCuid, String fdnStr)
    throws Exception
  {
    String sql = "FDN like '%" + fdnStr + "%'" + " and " + "RELATED_DEVICE_CUID" + " = '" + neCuid + "'";

    DataObjectList dbos = super.getObjectsBySql(sql, new Card(), 0);
    if (dbos.size() > 0) {
      return (Card)dbos.get(0);
    }
    return null;
  }

  public long getTemplateCountByNameAndType(BoActionContext actionContext, String templateName, long type)
    throws Exception
  {
    String sql = "select count(*) from TEMPLATE where NAME='" + templateName + "' and " + "TYPE" + "=" + type;

    DataObjectList dbos = super.selectDBOs(sql, new Class[] { Long.class });
    if ((dbos != null) && (dbos.size() > 0)) {
      GenericDO gdo = (GenericDO)dbos.get(0);
      return ((BigDecimal)gdo.getAttrValue("1")).longValue();
    }
    return 0L;
  }
}