package com.boco.transnms.server.dao.common;

import com.boco.common.util.debug.LogHome;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.base.IBoActionContext;
import com.boco.transnms.common.dto.base.IBoQueryContext;
import com.boco.transnms.common.dto.common.DtoCacheModel;
import com.boco.transnms.server.dao.base.GenericDAO;
import com.boco.transnms.server.dao.base.SqlExecDaoCmd;
import org.apache.commons.logging.Log;

public class GenericDbCacheDAO extends GenericDAO
{
  public GenericDbCacheDAO()
  {
    super("GenericDbCacheDAO");
  }

  public void createCacheDtoModelTable() throws Exception {
    LogHome.getLog().info("创建内存表：DTO_CACHE_MODEL");
    String sql = "CREATE TABLE DTO_CACHE_MODEL (";
    sql = new StringBuilder().append(sql).append("CLASS_ID VARCHAR  NOT NULL PRIMARY KEY,").toString();
    sql = new StringBuilder().append(sql).append("CLASS_LABEL_CN VARCHAR  NOT NULL ,").toString();
    sql = new StringBuilder().append(sql).append("IS_DYNAMIC SMALLINT  NULL ").toString();
    sql = new StringBuilder().append(sql).append(");").toString();

    super.createSqlExecDaoCmd("cacheDB").execSql(sql);
  }

  public void createDtoModels(DataObjectList dtoModels) throws Exception {
    for (GenericDO dtoModel : dtoModels) {
      IBoActionContext context = new BoActionContext();
      context.setDsName("cacheDB");
      super.insertDbo(context, dtoModel);
    }
  }

  public DboCollection getDtoCacheModelByCond(String classId, String classLabelCn, boolean isDynamic) throws Exception {
    String sql = "select * from DTO_CACHE_MODEL where 1=1 ";
    if ((classId != null) && (classId.trim().length() > 0)) {
      sql = new StringBuilder().append(sql).append("and CLASS_ID like '%").append(classId).append("%' ").toString();
    }

    if ((classLabelCn != null) && (classLabelCn.trim().length() > 0)) {
      sql = new StringBuilder().append(sql).append(" and CLASS_LABEL_CN like '%").append(classLabelCn).append("%' ").toString();
    }

    if (isDynamic) {
      sql = new StringBuilder().append(sql).append(" and IS_DYNAMIC=1 ").toString();
    }

    IBoQueryContext context = new BoQueryContext();
    context.setDsName("cacheDB");
    return super.selectDBOs(context, sql, new GenericDO[] { new DtoCacheModel() });
  }

  public boolean isDynClass(String classId) throws Exception {
    boolean rtn = false;
    String sql = "select * from DTO_CACHE_MODEL where ";
    sql = new StringBuilder().append(sql).append("CLASS_ID ='").append(classId).append("' ").toString();
    IBoQueryContext context = new BoQueryContext();
    context.setDsName("cacheDB");
    DboCollection dbos = super.selectDBOs(context, sql, new GenericDO[] { new DtoCacheModel() });
    if (dbos.size() == 1) {
      DtoCacheModel model = (DtoCacheModel)dbos.getQueryDbo(0, "DTO_CACHE_MODEL");
      rtn = model.getIsDynamic();
    }
    return rtn;
  }

  public void updateDynClass(String classId, boolean isDynClass) throws Exception {
    String sql = "update DTO_CACHE_MODEL set ";
    sql = new StringBuilder().append(sql).append("IS_DYNAMIC=").append(isDynClass ? 1 : 0).toString();
    sql = new StringBuilder().append(sql).append(" where CLASS_ID ='").append(classId).append("' ").toString();
    IBoActionContext actionContext = new BoActionContext();
    actionContext.setDsName("cacheDB");
    super.execSql(actionContext, sql);
  }
}