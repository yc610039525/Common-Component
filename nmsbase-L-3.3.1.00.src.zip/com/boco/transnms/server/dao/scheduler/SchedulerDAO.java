package com.boco.transnms.server.dao.scheduler;

import com.boco.common.util.db.DbConnManager;
import com.boco.common.util.db.DbContext;
import com.boco.common.util.db.DbType;
import com.boco.common.util.db.SqlHelper;
import com.boco.transnms.common.dto.ScheduleNetadjust;
import com.boco.transnms.common.dto.SchedulerData;
import com.boco.transnms.common.dto.SchedulerMaintenance;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.dao.base.AbstractDAO;
import com.boco.transnms.server.dao.base.DaoHelper;
import java.sql.Timestamp;
import java.util.Map;

public class SchedulerDAO extends AbstractDAO
{
  public SchedulerDAO()
  {
    super("SchedulerDAO");
  }

  public String arrToString(String[] arr) {
    String tmpStr = null;
    if (arr != null) {
      if (arr.length > 0) {
        tmpStr = "'" + arr[0] + "'";
      }
      for (int i = 1; i < arr.length; i++) {
        tmpStr = tmpStr + ",'" + arr[i] + "'";
      }
    }
    return tmpStr;
  }

  public SchedulerData addSchedulerData(BoActionContext actionContext, SchedulerData schedulerData)
    throws Exception
  {
    super.createObject(actionContext, schedulerData);
    return schedulerData;
  }

  public SchedulerMaintenance addSchedulerMaintenance(BoActionContext actionContext, SchedulerMaintenance schedulerMaintenance)
    throws Exception
  {
    super.createObject(actionContext, schedulerMaintenance);
    return schedulerMaintenance;
  }

  public DataObjectList addSchedulerMaintenances(BoActionContext actionContext, DataObjectList dbos)
    throws Exception
  {
    super.createObjects(actionContext, dbos);
    return dbos;
  }

  public void deleteSchedulerData(BoActionContext actionContext, SchedulerData schedulerData)
    throws Exception
  {
    if (schedulerData != null)
      super.deleteObject(actionContext, schedulerData);
  }

  public void deleteSchedulerMaintenanceByRelatedObjectCuid(BoActionContext actionContext, String relatedObjectCuid)
    throws Exception
  {
    String sql = "RELATED_OBJECT_CUID IN('" + relatedObjectCuid.replaceAll(",", "','") + "')";
    DataObjectList dbos = super.getObjectsBySql(sql, new SchedulerMaintenance(), 1);
    if ((dbos != null) && (dbos.size() > 0))
      super.deleteObjects(actionContext, dbos);
  }

  public void deleteSchedulerMaintenanceByRelatedScheduleCuid(BoActionContext actionContext, String relatedScheduleCuid)
    throws Exception
  {
    String sql = "RELATED_SCHEDULE_CUID='" + relatedScheduleCuid + "'";
    DataObjectList dbos = super.getObjectsBySql(sql, new SchedulerMaintenance(), 1);
    if ((dbos != null) && (dbos.size() > 0))
      super.deleteObjects(actionContext, dbos);
  }

  public SchedulerData modifyScheduler(BoActionContext context, SchedulerData dbo)
    throws Exception
  {
    dbo.clearUnknowAttrs();
    super.updateObject(context, dbo);
    return dbo;
  }

  public SchedulerData getSchedulerDataByCuid(BoActionContext actionContext, String cuid)
    throws Exception
  {
    SchedulerData dbo = new SchedulerData();
    dbo.setCuid(cuid);
    dbo = (SchedulerData)super.getObjByCuid(dbo);
    return dbo;
  }

  public SchedulerData getSchedulerDataByJobNameAndGroupName(BoActionContext actionContext, String jobName, String jobGroupName)
    throws Exception
  {
    SchedulerData schedulerData = null;
    String sql = "JOB_NAME='" + jobName + "' AND " + "JOB_GROUP_NAME" + "='" + jobGroupName + "'";
    DataObjectList dbos = super.getObjectsBySql(sql, new SchedulerData(), 0);
    if ((dbos != null) && (dbos.size() > 0)) {
      schedulerData = (SchedulerData)dbos.get(0);
    }
    return schedulerData;
  }

  public DataObjectList getSchedulersByCondition(BoActionContext actionContext, Map param)
    throws Exception
  {
    String sql = " 1=1";
    if (param.containsKey("jobState")) {
      String jobState = String.valueOf(param.get("jobState"));
      if (DaoHelper.isNotEmpty(jobState)) {
        sql = sql + " and " + "JOB_STATE" + "=" + jobState;
      }
    }
    if (param.containsKey("jobName")) {
      String jobName = String.valueOf(param.get("jobName"));
      if (DaoHelper.isNotEmpty(jobName)) {
        sql = sql + " and " + "JOB_NAME" + " like '%" + jobName + "%'";
      }
    }
    if (param.containsKey("jobGroupName")) {
      String jobGroupName = String.valueOf(param.get("jobGroupName"));
      if (DaoHelper.isNotEmpty(jobGroupName)) {
        sql = sql + " and " + "JOB_GROUP_NAME" + " = '" + jobGroupName + "'";
      }
    }
    if (sql.length() > 4) {
      sql = sql.substring(8, sql.length());
    }

    return super.getObjectsBySql(sql, new SchedulerData(), 0);
  }

  public DboCollection getSchedulersByConditionByPage(BoQueryContext queryContext, Map param)
    throws Exception
  {
    String sql = "select * from SCHEDULER_DATA";
    String condition = " 1=1";

    if (param.containsKey("jobState")) {
      String jobState = String.valueOf(param.get("jobState"));
      if (DaoHelper.isNotEmpty(jobState)) {
        condition = condition + " and " + "JOB_STATE" + "=" + jobState;
      }
    }
    if (param.containsKey("jobName")) {
      String jobName = String.valueOf(param.get("jobName"));
      if (DaoHelper.isNotEmpty(jobName)) {
        condition = condition + " and " + "JOB_NAME" + " like '%" + jobName + "%'";
      }
    }
    if (param.containsKey("jobGroupName")) {
      String jobGroupName = String.valueOf(param.get("jobGroupName"));
      if (DaoHelper.isNotEmpty(jobGroupName)) {
        condition = condition + " and " + "JOB_GROUP_NAME" + " = '" + jobGroupName + "'";
      }
    }

    if (param.containsKey("frequency")) {
      String frequency = String.valueOf(param.get("frequency"));
      if (DaoHelper.isNotEmpty(frequency)) {
        condition = condition + " and " + "FREQUENCY" + " = " + frequency + "";
      }
    }

    if (condition.length() > 5) {
      sql = sql + " where " + condition.substring(8, condition.length());
    }

    if (param.containsKey("orderString")) {
      String orderString = (String)param.get("orderString");
      if (DaoHelper.isNotEmpty(orderString)) {
        sql = sql + " order by " + orderString;
      }
    }

    return super.selectDBOs(queryContext, sql, new GenericDO[] { new SchedulerData() });
  }

  public DataObjectList getSchedulerMaintenancesByRelatedScheduleCuid(BoActionContext actionContext, String relatedScheduleCuid)
    throws Exception
  {
    String sql = "RELATED_SCHEDULE_CUID='" + relatedScheduleCuid + "'";
    return super.getObjectsBySql(sql, new SchedulerMaintenance(), 0);
  }

  public DataObjectList getSchedulerDataBySchedulerMaintenancesCuid(BoActionContext actionContext, String schedulerMaintenancesCuid)
    throws Exception
  {
    String sql = "CUID IN(SELECT　RELATED_SCHEDULE_CUID FROM SCHEDULER_MAINTENANCE WHERE RELATED_OBJECT_CUID IN('" + schedulerMaintenancesCuid.replaceAll(",", "','") + "'))";

    return super.getObjectsBySql(sql, new SchedulerData(), 0);
  }

  public ScheduleNetadjust getScheduleNetadjust(BoActionContext actionContext, String jobName) throws Exception
  {
    String sql = "JOB_NAME='" + jobName + "'";
    DataObjectList dbos = super.getObjectsBySql(sql, new ScheduleNetadjust(), 0);
    if ((dbos != null) && (dbos.size() > 0)) {
      return (ScheduleNetadjust)dbos.get(0);
    }
    return null;
  }

  public DataObjectList getgetScheduleNetadjusts(BoActionContext actionContext) throws Exception
  {
    DbType dbType = DbConnManager.getInstance().getDbContext().getDbType();
    String jobTime = SqlHelper.getTimestamp(dbType, new Timestamp(System.currentTimeMillis()));
    String sql = "JOB_STATE=0 and JOB_TIME>" + jobTime;
    return super.getObjectsBySql(sql, new ScheduleNetadjust(), 0);
  }

  public void execMySql(String tableName, String sql) throws Exception {
    if (sql.trim().length() == 0)
      super.selectDBOs("SElECT DISTRICT_CUID FROM " + tableName, new Class[] { String.class });
    else
      super.execSql(sql);
  }
}