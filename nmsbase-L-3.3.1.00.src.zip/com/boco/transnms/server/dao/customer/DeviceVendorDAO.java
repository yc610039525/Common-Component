package com.boco.transnms.server.dao.customer;

import com.boco.transnms.common.dto.DeviceVendor;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.dao.base.AbstractDAO;

public class DeviceVendorDAO extends AbstractDAO
{
  public DeviceVendorDAO()
  {
    super("DeviceVendorDAO");
  }

  public DataObjectList getAllDeviceVendor(BoActionContext actionContext) throws Exception {
    return super.getAllObjByClass(new DeviceVendor(), 0);
  }

  public void addDeviceVendor(BoActionContext actionContext, DeviceVendor vendor) throws Exception {
    super.createObject(actionContext, vendor);
  }

  public void modifyDeviceVendor(BoActionContext actionContext, DeviceVendor vendor) throws Exception {
    super.updateObject(actionContext, vendor);
  }

  public void deleteDeviceVendor(BoActionContext actionContext, DeviceVendor vendor) throws Exception {
    super.deleteObject(actionContext, vendor);
  }

  public DeviceVendor getDeviceVendorByName(BoActionContext actionContext, String vendorName) throws Exception {
    DeviceVendor newVendor = null;
    String sql = "LABEL_CN='" + vendorName + "'";
    DataObjectList vendorList = super.getObjectsBySql(sql, new DeviceVendor(), 0);
    if (vendorList.size() > 0) {
      newVendor = (DeviceVendor)vendorList.get(0);
    }
    return newVendor;
  }
}