package com.boco.transnms.server.dao.nmc;

import com.boco.transnms.server.dao.base.AbstractDAO;

public class EMDAO extends AbstractDAO
{
  public EMDAO()
  {
    super("EMDAO");
  }
}