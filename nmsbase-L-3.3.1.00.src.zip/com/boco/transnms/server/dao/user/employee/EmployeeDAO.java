package com.boco.transnms.server.dao.user.employee;

import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.Employee;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.dao.base.AbstractDAO;

public class EmployeeDAO extends AbstractDAO
{
  public EmployeeDAO()
  {
    super("EmployeeDAO");
  }

  public Employee getEmployee(BoActionContext actionContext, Long employeeid) throws Exception {
    Employee employee = new Employee();
    employee.setObjectNum(employeeid.longValue());
    return (Employee)super.getObject(employee);
  }

  public Employee addEmployee(BoActionContext actionContext, Employee dbo) throws Exception {
    super.createObject(actionContext, dbo);
    return dbo;
  }

  public void modifyEmployee(BoActionContext actionContext, Employee dbo) throws Exception {
    super.updateObject(actionContext, dbo);
  }

  public void deleteEmployee(BoActionContext actionContext, Long objectId) throws Exception {
    GenericDO dbo = new GenericDO();
    dbo.setObjectNum(objectId.longValue());
    super.deleteObject(actionContext, dbo);
  }

  public DataObjectList getAllEmployee(BoActionContext actionContext) throws Exception {
    return super.getAllObjByClass(new Employee(), 0);
  }

  public DataObjectList queryEmployee(BoActionContext actionContext, String name, String relatedDistrictCuid, String duty, String belongcom, String belongdep) throws Exception
  {
    String sql = "";
    if (name.length() != 0) {
      sql = "NAME LIKE '%" + name + "%' ";
    }
    if (relatedDistrictCuid.length() != 0) {
      if (sql.length() != 0)
        sql = sql + " AND " + "RELATED_DISTRICT_CUID" + " ='" + relatedDistrictCuid + "' ";
      else {
        sql = "RELATED_DISTRICT_CUID ='" + relatedDistrictCuid + "' ";
      }
    }
    if (!duty.equals("allconxxx")) {
      if (sql.length() != 0) {
        if (duty.length() == 0)
        {
          sql = sql + " AND " + "DUTY" + " is null ";
        }
        else
        {
          sql = sql + " AND " + "DUTY" + " ='" + duty + "' ";
        }

      }
      else if (duty.length() == 0)
      {
        sql = "DUTY is null";
      }
      else
      {
        sql = "DUTY ='" + duty + "' ";
      }

    }

    if (!belongcom.equals("allconxxx")) {
      if (sql.length() != 0) {
        if (belongcom.length() == 0)
        {
          sql = sql + " AND " + "BELONGCOM" + " is null ";
        }
        else
        {
          sql = sql + " AND " + "BELONGCOM" + " ='" + belongcom + "' ";
        }

      }
      else if (belongcom.length() == 0)
      {
        sql = "BELONGCOM is null";
      }
      else
      {
        sql = "BELONGCOM ='" + belongcom + "' ";
      }
    }

    if (!belongdep.equals("allconxxx")) {
      if (sql.length() != 0) {
        if (belongdep.length() == 0)
        {
          sql = sql + " AND " + "BELONGDEP" + " is null ";
        }
        else
        {
          sql = sql + " AND " + "BELONGDEP" + " ='" + belongdep + "' ";
        }

      }
      else if (belongdep.length() == 0)
      {
        sql = "BELONGDEP is null";
      }
      else
      {
        sql = "BELONGDEP ='" + belongdep + "' ";
      }

    }

    if (sql.length() != 0) {
      return super.getObjectsBySql(sql, new Employee(), 0);
    }

    return super.getAllObjByClass(new Employee(), 0);
  }

  public DataObjectList selectEmployeeOptions(BoActionContext actionContext, String option) throws Exception {
    String sql = "SELECT DISTINCT " + option.toUpperCase() + " FROM EMPLOYEE";
    try {
      return super.selectDBOs(sql, new Class[] { String.class });
    } catch (Exception ex) {
      throw new UserException(ex.getMessage());
    }
  }

  public Employee getEmployeeByCUid(BoActionContext actionContext, String employeecuid) throws Exception {
    Employee employee = new Employee();
    employee.setCuid(employeecuid);
    return (Employee)super.getObjByCuid(employee);
  }

  public boolean isRepeatName(String label_cn) throws Exception {
    String sql = "NAME='" + label_cn + "'";
    DataObjectList dbos = super.getObjectsBySql(sql, new Employee(), 0);
    if (dbos.size() > 0) {
      return true;
    }
    return false;
  }

  public String getCuidByLabelcn(BoActionContext actionContext, String labelCn) throws Exception
  {
    String sql = "NAME='" + labelCn + "'";
    String cuid = "";
    DataObjectList dbos = super.getObjectsBySql(sql, new Employee(), 0);
    if (dbos.size() > 0) {
      cuid = ((GenericDO)dbos.get(0)).getCuid();
    }
    return cuid;
  }
}