package com.boco.transnms.server.dao.user.sec;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.SysUser;
import com.boco.transnms.common.dto.UserHaveObject;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.base.IBoActionContext;
import com.boco.transnms.common.dto.base.IBoQueryContext;
import com.boco.transnms.server.dao.base.AbstractDAO;
import com.boco.transnms.server.dao.base.SqlExecDaoCmd;
import org.apache.commons.logging.Log;

public class SecurityObjectDAO extends AbstractDAO
{
  public SecurityObjectDAO()
  {
    super("SecurityObjectDAO");
  }

  public boolean isAlreadyCreateTable() throws Exception {
    boolean flag = true;
    IBoActionContext actionContext = new BoActionContext();
    actionContext.setDsName("cacheDB");

    String sql = "1=1";
    try {
      dbosdb = super.getObjectsBySql(actionContext, sql, new UserHaveObject(), 1);
    }
    catch (Exception ex)
    {
      DataObjectList dbosdb;
      LogHome.getLog().info("内存表不存在!");
      flag = false;
    }
    return flag;
  }
  public void createCacheUserHaveObjectTable() throws Exception {
    LogHome.getLog().info("创建内存表：USER_HAVE_OBJECT");
    String sql = "CREATE TABLE USER_HAVE_OBJECT (";
    sql = sql + "CUID VARCHAR  NOT NULL PRIMARY KEY,";
    sql = sql + "OBJECT_CLASSNAME VARCHAR  NULL, ";
    sql = sql + "RELATED_DISTRICT_CUID VARCHAR  NOT NULL, ";

    sql = sql + "RELATED_OBJECT_CUID VARCHAR  NOT NULL, ";

    sql = sql + "RELATED_USER_CUID VARCHAR  NOT NULL, ";
    sql = sql + "IS_INCLUDE_CHILD INTEGER  NULL ,";
    sql = sql + "IS_IN_EX INTEGER  NOT NULL, ";
    sql = sql + "OBJECT_OPERATION INTEGER  NOT NULL, ";
    sql = sql + " LAST_MODIFY_TIME  Timestamp, ";
    sql = sql + " CREATE_TIME Timestamp, ";
    sql = sql + " OBJECTID INTEGER, ";
    sql = sql + " ISDELETE INTEGER  NULL ";
    sql = sql + ");";
    super.createSqlExecDaoCmd("cacheDB").execSql(sql);
  }

  public void cacheAllUserHaveObjects() throws Exception {
    IBoActionContext actionContext = new BoActionContext();
    actionContext.setDsName("cacheDB");
    String sql = "select CUID,OBJECT_CLASSNAME,RELATED_DISTRICT_CUID,RELATED_OBJECT_CUID,RELATED_USER_CUID,IS_INCLUDE_CHILD,IS_IN_EX,OBJECT_OPERATION, LAST_MODIFY_TIME, CREATE_TIME, OBJECTID, ISDELETE  from USER_HAVE_OBJECT";

    DboCollection dbos = super.selectDBOs(sql, new GenericDO[] { new UserHaveObject() });
    for (int i = 0; i < dbos.size(); i++) {
      UserHaveObject dbo = (UserHaveObject)dbos.getQueryDbo(i, "USER_HAVE_OBJECT");

      GenericDO newdbo = new GenericDO(dbo.getClassName());
      newdbo.setCuid(dbo.getCuid());
      newdbo.setAttrValue("OBJECT_CLASSNAME", dbo.getObjectClassname());

      newdbo.setAttrValue("RELATED_DISTRICT_CUID", dbo.getRelatedDistrictCuid());

      newdbo.setAttrValue("RELATED_OBJECT_CUID", dbo.getRelatedObjectCuid());

      newdbo.setAttrValue("RELATED_USER_CUID", dbo.getRelatedUserCuid());

      newdbo.setAttrValue("IS_INCLUDE_CHILD", dbo.getIsIncludeChild());

      newdbo.setAttrValue("IS_IN_EX", dbo.getIsInEx());

      newdbo.setAttrValue("OBJECT_OPERATION", dbo.getObjectOperation());

      super.insertDbo(actionContext, newdbo);
    }
  }

  public void cacheUserHaveObjects(String userCuid) throws Exception {
    IBoActionContext actionContext = new BoActionContext();
    actionContext.setDsName("cacheDB");

    String sql = "1=1";
    DataObjectList dbosdb = super.getObjectsBySql(actionContext, sql, new UserHaveObject(), 1);

    if ((dbosdb == null) || (dbosdb.size() == 0)) {
      sql = "delete from USER_HAVE_OBJECT where RELATED_USER_CUID='" + userCuid + "'";

      super.execSql(actionContext, sql);
      sql = "select CUID,OBJECT_CLASSNAME,RELATED_DISTRICT_CUID,RELATED_OBJECT_CUID,RELATED_USER_CUID,IS_INCLUDE_CHILD,IS_IN_EX,OBJECT_OPERATION, LAST_MODIFY_TIME, CREATE_TIME, OBJECTID, ISDELETE  from USER_HAVE_OBJECT where RELATED_USER_CUID='" + userCuid + "'";

      DboCollection dbos = super.selectDBOs(sql, new GenericDO[] { new UserHaveObject() });
      for (int i = 0; i < dbos.size(); i++) {
        UserHaveObject dbo = (UserHaveObject)dbos.getQueryDbo(i, "USER_HAVE_OBJECT");

        GenericDO newdbo = new GenericDO(dbo.getClassName());
        newdbo.setCuid(dbo.getCuid());
        newdbo.setAttrValue("OBJECT_CLASSNAME", dbo.getObjectClassname());

        newdbo.setAttrValue("RELATED_DISTRICT_CUID", dbo.getRelatedDistrictCuid());

        newdbo.setAttrValue("RELATED_OBJECT_CUID", dbo.getRelatedObjectCuid());

        newdbo.setAttrValue("RELATED_USER_CUID", dbo.getRelatedUserCuid());

        newdbo.setAttrValue("IS_INCLUDE_CHILD", dbo.getIsIncludeChild());

        newdbo.setAttrValue("IS_IN_EX", dbo.getIsInEx());

        newdbo.setAttrValue("OBJECT_OPERATION", dbo.getObjectOperation());

        super.insertDbo(actionContext, newdbo);
      }
    }
  }

  public boolean isUserDistrictExclude(String userId, String districtCuid)
    throws Exception
  {
    boolean isExclude = true;
    String sql = "select IS_IN_EX from USER_HAVE_OBJECT";

    sql = sql + " where RELATED_USER_CUID='" + userId + "'";

    sql = sql + " and RELATED_DISTRICT_CUID='" + districtCuid + "'";

    IBoQueryContext context = new BoQueryContext();
    context.setDsName("cacheDB");
    DboCollection dbos = super.selectDBOs(context, sql, new GenericDO[] { new UserHaveObject() });

    if (dbos.size() == 0) {
      throw new UserException("没有找到用户区域权限 ！");
    }
    UserHaveObject dbo = (UserHaveObject)dbos.getQueryDbo(0, "USER_HAVE_OBJECT");

    isExclude = dbo.getIsInEx();

    return isExclude;
  }

  public DboCollection getDistrictObjects(String userId, String districtCuid, String objClassName)
    throws Exception
  {
    String sql = "select CUID,OBJECT_CLASSNAME,RELATED_DISTRICT_CUID,RELATED_OBJECT_CUID,RELATED_USER_CUID,IS_INCLUDE_CHILD,IS_IN_EX,OBJECT_OPERATION, LAST_MODIFY_TIME, CREATE_TIME, OBJECTID, ISDELETE  from USER_HAVE_OBJECT";

    sql = sql + " where RELATED_USER_CUID='" + userId + "'";

    sql = sql + " and RELATED_DISTRICT_CUID in (" + districtCuid + ")";

    sql = sql + " and OBJECT_CLASSNAME='" + objClassName + "'";

    sql = sql + " and OBJECT_OPERATION=1";

    IBoQueryContext context = new BoQueryContext();
    context.setDsName("cacheDB");
    return super.selectDBOs(context, sql, new GenericDO[] { new UserHaveObject() });
  }

  public String getClassFieldValue(String className, String cuid, String classFieldName) throws Exception
  {
    String sql = "select " + classFieldName + " from " + className + " where CUID='" + cuid + "'";

    DataObjectList dbos = super.selectDBOs(sql, new Class[] { String.class });

    String value = null;
    if (dbos.size() == 0) {
      LogHome.getLog().info("没有符合条件的对象" + sql);
    }
    else {
      value = ((GenericDO)dbos.get(0)).getAttrString("1");
    }

    return value;
  }

  public DboCollection getUserObjectClassNames(String districtCuid, String userId) throws Exception
  {
    String sql = "select distinct OBJECT_CLASSNAME from USER_HAVE_OBJECT";

    sql = sql + " where RELATED_DISTRICT_CUID='" + districtCuid + "' ";

    sql = sql + " and RELATED_USER_CUID='" + userId + "' ";

    IBoQueryContext context = new BoQueryContext();
    context.setDsName("cacheDB");
    return super.selectDBOs(context, sql, new GenericDO[] { new UserHaveObject() });
  }

  public DboCollection getAllSysUsers() throws Exception {
    String sql = "select * from SYS_USER";
    return super.selectDBOs(sql, new GenericDO[] { new SysUser() });
  }

  public boolean isUserObjectDistrict(String userId, String districtCuid) {
    int count = 0;
    try
    {
      String[] discuids = districtCuid.split(",");
      if (discuids.length > 0) {
        for (int i = 0; i < discuids.length; i++) {
          if (i == 0) {
            districtCuid = "RELATED_DISTRICT_CUID like '" + discuids[i] + "%'";
          }
          else {
            districtCuid = districtCuid + " or " + "RELATED_DISTRICT_CUID" + " like '" + discuids[i] + "%'";
          }

        }

      }

      String sql = "select count(*) from USER_HAVE_OBJECT";
      sql = sql + " where RELATED_USER_CUID='" + userId + "'";

      sql = sql + " and  (" + districtCuid + ") ";
      IBoQueryContext context = new BoQueryContext();
      context.setDsName("cacheDB");
      count = super.getCalculateValue(context, sql);
    } catch (Exception ex) {
      LogHome.getLog().info("", ex);
    }
    return count > 0;
  }

  public boolean isUserObjectCuidExist(String userId, String districtCuid, String objCuid, boolean isEdit)
  {
    int count = 0;
    try {
      String sql = "select count(*) from USER_HAVE_OBJECT";
      sql = sql + " where RELATED_USER_CUID='" + userId + "'";

      sql = sql + " and RELATED_DISTRICT_CUID='" + districtCuid + "'";

      sql = sql + " and RELATED_OBJECT_CUID='" + objCuid + "'";

      if (isEdit) {
        sql = sql + " and OBJECT_OPERATION=2";
      }
      IBoQueryContext context = new BoQueryContext();
      context.setDsName("cacheDB");
      count = super.getCalculateValue(context, sql);
    } catch (Exception ex) {
      LogHome.getLog().info("", ex);
    }
    return count > 0;
  }

  public String getEditableSqlCond(boolean isEditable) {
    String sqlCond = "";
    if (!isEditable) {
      sqlCond = sqlCond + " and (IS_IN_EX=1";
      sqlCond = sqlCond + " and OBJECT_OPERATION=1)";

      sqlCond = sqlCond + " and (IS_IN_EX=0";
      sqlCond = sqlCond + " and OBJECT_OPERATION<=2)";
    }
    else {
      sqlCond = sqlCond + " and (IS_IN_EX=1";
      sqlCond = sqlCond + " and OBJECT_OPERATION<=2)";

      sqlCond = sqlCond + " and (IS_IN_EX=0";
      sqlCond = sqlCond + " and OBJECT_OPERATION=2)";
    }

    return sqlCond;
  }
}