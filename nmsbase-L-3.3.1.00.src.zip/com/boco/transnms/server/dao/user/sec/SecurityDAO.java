package com.boco.transnms.server.dao.user.sec;

import com.boco.common.util.db.DbConnManager;
import com.boco.common.util.db.DbContext;
import com.boco.common.util.db.DbType;
import com.boco.common.util.db.SqlHelper;
import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.common.util.lang.TimeFormatHelper;
import com.boco.transnms.common.dto.AttempReceiver;
import com.boco.transnms.common.dto.Card;
import com.boco.transnms.common.dto.District;
import com.boco.transnms.common.dto.EquipmentHolder;
import com.boco.transnms.common.dto.FunctionTreeNode;
import com.boco.transnms.common.dto.HistoryUserPassword;
import com.boco.transnms.common.dto.LoginLog;
import com.boco.transnms.common.dto.ModuleClickLog;
import com.boco.transnms.common.dto.Organization;
import com.boco.transnms.common.dto.Ptp;
import com.boco.transnms.common.dto.RoleConsistOfFunPoint;
import com.boco.transnms.common.dto.SysUser;
import com.boco.transnms.common.dto.SystemLog;
import com.boco.transnms.common.dto.TransElement;
import com.boco.transnms.common.dto.Traph;
import com.boco.transnms.common.dto.UserHaveObject;
import com.boco.transnms.common.dto.UserHaveRole;
import com.boco.transnms.common.dto.UserManageDistrict;
import com.boco.transnms.common.dto.UserPasswordSecurity;
import com.boco.transnms.common.dto.UserRole;
import com.boco.transnms.common.dto.UserToCust;
import com.boco.transnms.common.dto.UserToTraph;
import com.boco.transnms.common.dto.WarningLimit;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.FromToDO;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.base.IAttrObject;
import com.boco.transnms.server.dao.base.AbstractDAO;
import com.boco.transnms.server.dao.base.DaoHelper;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;

public class SecurityDAO extends AbstractDAO
{
  public SecurityDAO()
  {
    super("SecurityDAO");
  }

  public boolean isFunctionExist() throws Exception {
    FunctionTreeNode dbo = new FunctionTreeNode();
    int count = super.getCalculateValue("select count(*) from " + dbo.getClassName());

    return count > 0;
  }

  public void deleteRoleFunctions() throws Exception {
    RoleConsistOfFunPoint roleFun = new RoleConsistOfFunPoint();
    UserRole role = new UserRole();
    String sqlCond = "IS_USER_CREATE=0";
    DataObjectList dbos = super.getObjectsBySql(sqlCond, role, 2);

    for (int i = 0; i < dbos.size(); i++) {
      GenericDO dbo = (GenericDO)dbos.get(i);
      sqlCond = "ROLE_CUID='" + dbo.getCuid() + "'";

      super.deleteObjects(null, roleFun.getClassName(), sqlCond);
    }
    super.deleteObjects(null, dbos);
  }

  public DataObjectList getUserDistrictAndRole(SysUser user) throws Exception
  {
    DataObjectList list = new DataObjectList();
    String sql = "SELECT ROLE_CUID,DISTRICT_CUID FROM USER_HAVE_ROLE WHERE USER_CUID ='" + user.getCuid() + "'";

    DataObjectList dbos = super.selectDBOs(sql, new Class[] { String.class, String.class });

    for (int i = 0; i < dbos.size(); i++) {
      GenericDO dbo = (GenericDO)dbos.get(i);
      String roleCuid = dbo.getAttrString("1");
      String disCuid = dbo.getAttrString("2");
      FromToDO fromTo = new FromToDO();
      fromTo.setFromObject(new District(disCuid));
      fromTo.setToObject(new UserRole(roleCuid));
      list.add(fromTo);
    }
    return list;
  }

  public DataObjectList getUserHaveRoleByUserCuid(String userCuid)
    throws Exception
  {
    String sql = "USER_CUID = '" + userCuid + "'";
    return super.getObjectsBySql(sql, new UserHaveRole(), 0);
  }

  public DboCollection getUserWorkFlowRole(String userCuid) throws Exception
  {
    String sql = "select ur.* from USER_ROLE ur,USER_HAVE_ROLE uhr where uhr.ROLE_CUID=ur.CUID  and ur.CUID like 'WORKFLOW-%' and uhr.USER_CUID='" + userCuid + "'";

    return super.selectDBOs(sql, new GenericDO[] { new UserRole() });
  }

  public void deleteUserHaveRole(BoActionContext context, String userCuid, String[] districtCuids)
    throws Exception
  {
    String dis = "";
    for (int i = 0; i < districtCuids.length; i++) {
      dis = dis + ",'" + districtCuids[i] + "'";
    }
    dis = dis.substring(1, dis.length());
    String sql = "USER_CUID='" + userCuid + "' and " + "DISTRICT_CUID" + " not in (" + dis + ")";

    DataObjectList dbos = super.getObjectsBySql(sql, new UserHaveRole(), 2);

    super.deleteObjects(context, dbos);
  }

  public SysUser getUser(String userName) throws Exception {
    SysUser sysUser = null;
    String sql = "USER_NAME='" + userName + "'";
    DataObjectList dbos = super.getObjectsBySql(sql, new SysUser(), 0);

    if (dbos.size() > 0) {
      sysUser = (SysUser)dbos.get(0);
    }
    return sysUser;
  }

  public Organization addOrganization(BoActionContext actionContext, Organization dbo) throws Exception
  {
    super.createObject(actionContext, dbo);
    return dbo;
  }

  public SysUser addSysUser(BoActionContext actionContext, SysUser dbo)
    throws Exception
  {
    dbo.setManagerDistrictCuid("");
    super.createObject(actionContext, dbo);
    return dbo;
  }

  public UserPasswordSecurity addUserPasswordSecurity(BoActionContext actionContext, UserPasswordSecurity dbo)
    throws Exception
  {
    super.createObject(actionContext, dbo);
    return dbo;
  }

  public UserPasswordSecurity getUserPasswordSecurity(BoActionContext boActionContext, String cuid)
    throws Exception
  {
    UserPasswordSecurity dbo = new UserPasswordSecurity();
    dbo.setCuid(cuid);
    return (UserPasswordSecurity)super.getObjByCuid(dbo);
  }

  public DboCollection isSecurityUsed(BoQueryContext queryContext, String cuid)
    throws Exception
  {
    String sql = "SELECT * FROM SYS_USER WHERE RELATED_SECURITY_CUID ='" + cuid + "'";

    return super.selectDBOs(queryContext, sql, new GenericDO[] { new SysUser() });
  }

  public void delUserPasswordSecurity(BoActionContext boActionContext, String cuid)
    throws Exception
  {
    String sql = "";
    sql = "delete from USER_PASSWORD_SECURITY where CUID='" + cuid + "'";

    super.execSql(sql);
  }

  public void updateUserManagerDistrict(BoActionContext actionContext, SysUser dbo) throws Exception
  {
    if ((dbo.getManagerDistrictCuid() != null) && (dbo.getManagerDistrictCuid().trim().length() > 0))
    {
      String[] districtCuids = dbo.getManagerDistrictCuid().split(",");
      String userCuid = dbo.getCuid();
      String sql = "USER_CUID='" + userCuid + "'";

      super.deleteObjects(actionContext, "USER_MANAGE_DISTRICT", sql);

      DataObjectList dbos = new DataObjectList();
      for (int i = 0; i < districtCuids.length; i++) {
        UserManageDistrict md = new UserManageDistrict();
        md.setUserCuid(userCuid);
        md.setDistrictCuid(districtCuids[i]);
        dbos.add(md);
      }
      super.createObjects(actionContext, dbos);
    } else {
      String sql = "USER_CUID='" + dbo.getCuid() + "'";

      super.deleteObjects(actionContext, "USER_MANAGE_DISTRICT", sql);
    }
  }

  public void deleteUserManagerDistrict(BoActionContext actionContext, Long objectId)
    throws Exception
  {
    SysUser dbo = new SysUser();
    dbo.setObjectNum(objectId.longValue());
    dbo = (SysUser)super.getObject(dbo);
    String userCuid = dbo.getCuid();
    String sql = "USER_CUID='" + userCuid + "'";

    super.deleteObjects(actionContext, "USER_MANAGE_DISTRICT", sql);
  }

  public void delOrganization(BoActionContext boActionContext, Long objectId) throws Exception
  {
    GenericDO dbo = new GenericDO();
    dbo.setObjectNum(objectId.longValue());
    super.deleteObject(boActionContext, dbo);
  }

  public void delSysUser(BoActionContext actionContext, Long objectId) throws Exception
  {
    SysUser dbo = new SysUser();
    dbo.setObjectNum(objectId.longValue());
    if ((actionContext != null) && (actionContext.getAttrString("appKey") != null))
      dbo.setAttrValue("appKey", actionContext.getAttrString("appKey"));
    super.deleteObject(actionContext, dbo);
  }

  public void modifyOrganization(BoActionContext boActionContext, Organization dbo) throws Exception
  {
    super.updateObject(null, dbo);
  }

  public void modifySysUser(BoActionContext actionContext, SysUser dbo) throws Exception
  {
    dbo.clearUnknowAttrs();
    dbo.setManagerDistrictCuid("");
    super.updateObject(actionContext, dbo);
  }

  public DataObjectList getAllOrganization(BoActionContext boActionContext) throws Exception
  {
    return super.getAllObjByClass(new Organization(), 0);
  }

  private String getReceiverFilter(BoActionContext boActionContext, String logUser, String roleId, String processType, String type)
    throws Exception
  {
    String rtn = "";
    Vector vRtn = new Vector();
    String sql = "ROLE_ID=" + roleId + " and ";
    sql = sql + "PROCESS_TYPE=" + processType + " and ";

    sql = sql + "RELATED_LOGIN_USER_CUID='" + logUser + "'";

    DataObjectList depList = super.getObjectsBySql(sql, new AttempReceiver(), 0);

    if ((depList != null) && (depList.size() > 0)) {
      for (int i = 0; i < depList.size(); i++) {
        AttempReceiver receiver = (AttempReceiver)depList.get(i);
        String tmp = "";
        if (type.equals("dep"))
          tmp = receiver.getRelatedDepCuid();
        else {
          tmp = receiver.getRelatedUserCuid();
        }
        GenericDO oTmp = null;
        if ((tmp != null) && (tmp.trim().length() > 0)) {
          oTmp = new GenericDO();
          oTmp.setCuid(tmp);
          oTmp = super.getObjByCuid(oTmp);
        }

        if ((oTmp != null) && (!vRtn.contains(tmp))) {
          vRtn.add(tmp);
        }
      }
    }
    for (int j = 0; j < vRtn.size(); j++) {
      rtn = rtn + "'" + (String)vRtn.get(j) + "'";
      if (j < vRtn.size() - 1) {
        rtn = rtn + ",";
      }
    }
    return rtn;
  }

  public DataObjectList getReceiverOrganization(BoActionContext boActionContext, String logUser, String roleId, String processType, String type)
    throws Exception
  {
    DataObjectList rtn = new DataObjectList();
    String filter = getReceiverFilter(boActionContext, logUser, roleId, processType, type);

    if (StringUtils.isNotEmpty(filter)) {
      String sql = "CUID in (" + filter + ") ";
      rtn = super.getObjectsBySql(sql, new Organization(), 0);
    }

    return rtn;
  }

  public Vector getReceiverUser(BoActionContext boActionContext, String logUser, String roleId, String processType, String type)
    throws Exception
  {
    Vector rtn = new Vector();
    String filter = getReceiverFilter(boActionContext, logUser, roleId, processType, type);

    String[] users = null;
    if (!filter.equals("")) {
      users = filter.split(",");
    }

    if ((users != null) && (users.length > 0)) {
      for (int i = 0; i < users.length; i++) {
        rtn.add(users[i]);
      }
    }
    return rtn;
  }

  public DataObjectList getAllSysUser(BoActionContext boActionContext) throws Exception
  {
    return super.getAllObjByClass(new SysUser(), 0);
  }

  public DataObjectList getAllChildOrganization(BoActionContext boActionContext, Long objectId) throws Exception
  {
    Organization dbo = new Organization();
    dbo.setObjectNum(objectId.longValue());
    dbo = (Organization)super.getObject(dbo);
    return super.getObjectsBySql("RELATED_ORG_CUID='" + dbo.getCuid() + "'", dbo, 0);
  }

  public DataObjectList getAllChildOrganizationByCUID(BoActionContext boActionContext, String cuid)
    throws Exception
  {
    Organization dbo = new Organization();
    dbo.setCuid(cuid);
    return super.getObjectsBySql("RELATED_ORG_CUID='" + dbo.getCuid() + "'", dbo, 0);
  }

  public Organization getOrganization(BoActionContext boActionContext, long objectId)
    throws Exception
  {
    Organization dbo = new Organization();
    dbo.setObjectNum(objectId);
    return (Organization)super.getObject(dbo);
  }

  public SysUser getSysUser(BoActionContext boActionContext, long objectId) throws Exception
  {
    SysUser dbo = new SysUser();
    dbo.setObjectNum(objectId);
    dbo = (SysUser)super.getObject(dbo);
    String sql = "USER_CUID='" + dbo.getCuid() + "'";

    DataObjectList dbos = super.getObjectsBySql(sql, new UserManageDistrict(), 0);

    String managerDistrictString = "";
    for (int i = 0; i < dbos.size(); i++) {
      UserManageDistrict md = (UserManageDistrict)dbos.get(i);
      managerDistrictString = managerDistrictString + "," + md.getDistrictCuid();
    }

    if (managerDistrictString.trim().length() > 0) {
      dbo.setManagerDistrictCuid(managerDistrictString.substring(1, managerDistrictString.length()));
    }
    else {
      dbo.setManagerDistrictCuid(managerDistrictString);
    }
    return dbo;
  }

  public SysUser getSysUserByUserName(BoActionContext boActionContext, String userName) throws Exception
  {
    String sql = "USER_NAME='" + userName + "'";
    DataObjectList dbos = super.getObjectsBySql(sql, new SysUser(), 0);

    if ((dbos != null) && (dbos.size() > 0)) {
      SysUser dbo = (SysUser)dbos.get(0);
      sql = "USER_CUID='" + dbo.getCuid() + "'";

      dbos = super.getObjectsBySql(sql, new UserManageDistrict(), 0);

      String managerDistrictString = "";
      for (int i = 0; i < dbos.size(); i++) {
        UserManageDistrict md = (UserManageDistrict)dbos.get(i);
        managerDistrictString = managerDistrictString + "," + md.getDistrictCuid();
      }

      if (managerDistrictString.trim().length() > 0) {
        dbo.setManagerDistrictCuid(managerDistrictString.substring(1, managerDistrictString.length()));
      }
      else {
        dbo.setManagerDistrictCuid(managerDistrictString);
      }
      return dbo;
    }
    return null;
  }

  public DataObjectList getAllOrganizationByDistrict(BoActionContext actionContext, District district)
    throws Exception
  {
    String sql = "RELATED_DISTRICT_CUID='" + district.getCuid() + "'";

    return super.getObjectsBySql(sql, new Organization(), 0);
  }

  public DataObjectList getAllOrganizationByDistricts(BoActionContext actionContext, String districtCuids)
    throws Exception
  {
    districtCuids = "'" + districtCuids.replace(",", "','") + "'";
    String sql = "RELATED_DISTRICT_CUID in (" + districtCuids + ")";

    return super.getObjectsBySql(sql, new Organization(), 0);
  }

  public DataObjectList getAllUserRole(BoActionContext actionContext)
    throws Exception
  {
    return super.getAllObjByClass(new UserRole(), 0);
  }

  public DataObjectList getUserRoleByRoleType(BoActionContext actionContext, String roleType) throws Exception
  {
    String sql = "ROLE_TYPE='" + roleType + "'";
    return super.getObjectsBySql(sql, new UserRole(), 0);
  }

  public UserRole getUserRole(BoActionContext actionContext, Long objectId)
    throws Exception
  {
    UserRole dbo = new UserRole();
    dbo.setObjectNum(objectId.longValue());
    return (UserRole)super.getObject(dbo);
  }

  public UserRole getUserRoleByCuid(BoActionContext actionContext, String cuid) throws Exception
  {
    UserRole dbo = new UserRole();
    dbo.setCuid(cuid);
    return (UserRole)super.getObjByCuid(dbo);
  }

  public DataObjectList getRoleFunPoint(BoActionContext actionContext, String roleCuid)
    throws Exception
  {
    RoleConsistOfFunPoint roleConsistOfFunPoint = new RoleConsistOfFunPoint();
    roleConsistOfFunPoint.setAttrNull("FUNCTION_NODE_CUID");

    return super.getObjectsBySql("ROLE_CUID= '" + roleCuid + "' ", roleConsistOfFunPoint, 0);
  }

  public DboCollection getRoleFunPoints(BoActionContext actionContext, String roleCuid)
    throws Exception
  {
    String sql = "select A.* from FUNCTION_TREE_NODE A where A.CUID in (select FUNCTION_NODE_CUID from ROLE_CONSIST_OF_FUN_POINT where ROLE_CUID='" + roleCuid + "')";

    return super.selectDBOs(sql, new GenericDO[] { new FunctionTreeNode() });
  }

  public Boolean checkUserHaveActionNames(String actionName, String userCuid) throws Exception
  {
    String sql = "select count(*) from ROLE_CONSIST_OF_FUN_POINT rp,FUNCTION_TREE_NODE fn,USER_ROLE ur,USER_HAVE_ROLE uhr where rp.FUNCTION_NODE_CUID=fn.CUID and rp.ROLE_CUID=ur.CUID and uhr.ROLE_CUID=ur.CUID and uhr.USER_CUID='" + userCuid + "' and fn." + "ACTION_NAMES" + " like '" + actionName + ".%'";

    DataObjectList dbos = super.selectDBOs(sql, new Class[] { Integer.TYPE });
    if ((dbos != null) && (dbos.size() > 0)) {
      if (((GenericDO)dbos.get(0)).getAttrInt("1") > 0) {
        return Boolean.valueOf(true);
      }
      return Boolean.valueOf(false);
    }

    return Boolean.valueOf(false);
  }

  public DataObjectList getAllRoleFunPoint() throws Exception
  {
    return super.getAllObjByClass(new RoleConsistOfFunPoint(), 0);
  }

  public DataObjectList getAllFunctionNode(BoActionContext boActionContext)
    throws Exception
  {
    return super.getAllObjByClass(new FunctionTreeNode(), 0);
  }

  public UserRole addUserRole(BoActionContext actionContext, UserRole dbo)
    throws Exception
  {
    super.createObject(actionContext, dbo);
    return dbo;
  }

  public void addRoleFunPoint(BoActionContext actionContext, RoleConsistOfFunPoint dbo)
    throws Exception
  {
    super.createObject(actionContext, dbo);
  }

  public void modifyUserRole(BoActionContext actionContext, UserRole dbo)
    throws Exception
  {
    UserRole olddbo = (UserRole)super.getObjByCuid(dbo);
    dbo.setObjectNum(olddbo.getObjectNum());
    super.updateObject(actionContext, dbo);
  }

  public void delRoleFunPoint(BoActionContext actionContext, String roleCuid)
    throws Exception
  {
    String sqlCond = "ROLE_CUID='" + roleCuid + "'";

    super.deleteObjects(actionContext, "ROLE_CONSIST_OF_FUN_POINT", sqlCond);
  }

  public void delUserRole(BoActionContext actionContext, Long objectId)
    throws Exception
  {
    GenericDO dbo = new GenericDO();
    dbo.setObjectNum(objectId.longValue());
    super.deleteObject(actionContext, dbo);
  }

  public void delUserRoleByCuid(BoActionContext actionContext, String cuid) throws Exception
  {
    UserRole dbo = new UserRole();
    dbo.setCuid(cuid);
    dbo = (UserRole)super.getObjByCuid(dbo);
    super.deleteObject(actionContext, dbo);
  }

  public Organization getOrganizationByCuid(BoActionContext actionContext, String cuid)
    throws Exception
  {
    Organization dbo = new Organization();
    dbo.setCuid(cuid);
    return (Organization)super.getObjByCuid(dbo);
  }

  public Organization getRootOrganization() throws Exception {
    String sql = "RELATED_ORG_CUID='0'";
    DataObjectList dbos = super.getObjectsBySql(sql, new Organization(), 0);

    if (dbos.size() > 0) {
      return (Organization)dbos.get(0);
    }
    return null;
  }

  public UserHaveRole addUserHaveRole(BoActionContext actionContext, UserHaveRole dbo)
    throws Exception
  {
    super.createObject(actionContext, dbo);
    return dbo;
  }

  public void delUserHaveRole(BoActionContext actionContext, UserHaveRole dbo) throws Exception
  {
    super.deleteObject(actionContext, dbo);
  }

  public void delUserHaveRoleByUserCuid(BoActionContext actionContext, String sysUserCuid) throws Exception
  {
    String sql = "USER_CUID='" + sysUserCuid + "'";
    super.deleteObjects(actionContext, "USER_HAVE_ROLE", sql);
  }

  public void delUserHaveObjectByUserCuid(BoActionContext actionContext, String sysUserCuid) throws Exception
  {
    String sql = "RELATED_USER_CUID='" + sysUserCuid + "'";

    super.deleteObjects(actionContext, "USER_HAVE_OBJECT", sql);
  }

  public void delGmccAttempUserroleByUserCuid(BoActionContext actionContext, String sysUserCuid) throws Exception
  {
    String sql = "SYS_USER_CUID='" + sysUserCuid + "'";

    super.deleteObjects(actionContext, "GMCC_ATTEMP_USERROLE", sql);
  }

  public DataObjectList getUserHaveRole(BoActionContext actionContext, String userCuid, String districCuid) throws Exception
  {
    String sql = "USER_CUID= '" + userCuid + "' and (" + "DISTRICT_CUID" + "= '" + districCuid + "' or " + "ROLE_CUID" + " like 'BACKUPEQUIP-%')";

    DataObjectList uhrdbos = super.getObjectsBySql(sql, new UserHaveRole(), 0);

    String sqlworkflow = "USER_CUID= '" + userCuid + "' and " + "ROLE_CUID" + " like 'WORKFLOW-%'";

    DataObjectList uhrworkflowdbs = super.getObjectsBySql(sqlworkflow, new UserHaveRole(), 0);

    Map tmpMap = new HashMap();
    for (int i = 0; i < uhrworkflowdbs.size(); i++) {
      UserHaveRole uhr = (UserHaveRole)uhrworkflowdbs.get(i);
      if (tmpMap.get(uhr.getRoleCuid()) == null) {
        uhrdbos.add(uhr);
        tmpMap.put(uhr.getRoleCuid(), uhr);
      }
    }
    return uhrdbos;
  }

  public DataObjectList getUserHaveRoleByuserCuidAndRoleCuid(BoActionContext actionContext, String userCuid, String rolecuid)
    throws Exception
  {
    return super.getObjectsBySql("USER_CUID= '" + userCuid + "' and " + "ROLE_CUID" + "= '" + rolecuid + "'", new UserHaveRole(), 0);
  }

  public void addUserHaveObject(BoActionContext actionContext, DataObjectList dbos)
    throws Exception
  {
    super.createObjects(actionContext, dbos);
  }

  public DataObjectList getUserHaveObjects(BoActionContext actionContext, String userCuid) throws Exception
  {
    String sql = "RELATED_USER_CUID='" + userCuid + "'";

    DataObjectList dbos = super.getObjectsBySql(sql, new UserHaveObject(), 0);

    return dbos;
  }

  public void deleteUserHaveObject(BoActionContext actionContext, String sysUserCuid) throws Exception
  {
    String sql = "RELATED_USER_CUID='" + sysUserCuid + "'";

    DataObjectList dbos = super.getObjectsBySql(sql, new UserHaveObject(), 2);

    super.deleteObjects(actionContext, dbos);
  }

  public String getRoleName(BoActionContext boActionContext, String roleCuid) throws Exception
  {
    UserRole dbo = new UserRole();
    dbo.setCuid(roleCuid);
    dbo = (UserRole)super.getObjByCuid(dbo);
    return dbo.getRoleName();
  }

  public DboCollection getLog(BoQueryContext queryContext, String operatetype, String classname, String createtime, String lastmodifytime, String username, String ipaddress, String description)
    throws Exception
  {
    String sql = "SELECT * FROM SYSTEM_LOG WHERE ";
    if (DaoHelper.isNotEmpty(operatetype)) {
      sql = sql + "OPERATE_TYPE" + "='" + operatetype + "'";
    }

    if ((DaoHelper.isNotEmpty(createtime)) && (DaoHelper.isNotEmpty(lastmodifytime)))
    {
      sql = sql + " AND " + "CREATETIME" + " >=" + createtime + " AND " + "CREATETIME" + " <=" + lastmodifytime;
    }

    if ((DaoHelper.isNotEmpty(createtime)) && (!DaoHelper.isNotEmpty(lastmodifytime)))
    {
      sql = sql + " AND " + "CREATETIME" + " >=" + createtime;
    }

    if ((DaoHelper.isNotEmpty(lastmodifytime)) && (!DaoHelper.isNotEmpty(createtime)))
    {
      sql = sql + " AND " + "CREATETIME" + " <=" + lastmodifytime;
    }

    if (DaoHelper.isNotEmpty(classname)) {
      sql = sql + " AND " + "LOG_CLASS_NAME" + " LIKE '%" + classname + "%'";
    }

    if (DaoHelper.isNotEmpty(username)) {
      sql = sql + " AND " + "USER_NAME" + " = '" + username + "'";
    }

    if (DaoHelper.isNotEmpty(ipaddress)) {
      sql = sql + " AND " + "IP_ADDRESS" + "='" + ipaddress + "'";
    }

    if (DaoHelper.isNotEmpty(description)) {
      sql = sql + " AND " + "DESCIPTION" + " LIKE '%" + description + "%'";
    }

    sql = sql + " order by " + "CREATETIME" + " DESC";
    return super.selectDBOs(queryContext, sql, new GenericDO[] { new SystemLog() });
  }

  public void deleteLog(BoActionContext actionContext, String objectId) throws Exception
  {
    try {
      String sql = "delete from SYSTEM_LOG where ";
      sql = sql + "CUID='" + objectId + "'";
      super.execSql(sql);
    }
    catch (Exception ex) {
      throw new Exception(ex);
    }
  }

  public DboCollection getLoginLog(BoQueryContext queryContext, Long loginType, String startTime, String endTime, String userName)
    throws Exception
  {
    String sql = "SELECT * FROM LOGIN_LOG WHERE ";
    if (DaoHelper.isNotEmpty(String.valueOf(loginType))) {
      int lt = loginType.intValue();
      sql = sql + "LOGIN_TYPE" + "=" + lt;
    }

    if ((DaoHelper.isNotEmpty(startTime)) && (DaoHelper.isNotEmpty(endTime))) {
      sql = sql + " AND " + "LOGIN_TIME" + " >=" + startTime + " AND " + "LOGIN_TIME" + " <=" + endTime;
    }

    if ((DaoHelper.isNotEmpty(startTime)) && (!DaoHelper.isNotEmpty(endTime))) {
      sql = sql + " AND " + "LOGIN_TIME" + " >=" + startTime;
    }

    if ((DaoHelper.isNotEmpty(endTime)) && (!DaoHelper.isNotEmpty(startTime))) {
      sql = sql + " AND " + "LOGIN_TIME" + " <=" + endTime;
    }

    if (DaoHelper.isNotEmpty(userName)) {
      sql = sql + " AND " + "USER_NAME" + "= '" + userName + "'";
    }

    sql = sql + " order by " + "LOGIN_TIME" + " DESC";
    return super.selectDBOs(queryContext, sql, new GenericDO[] { new LoginLog() });
  }

  public DataObjectList getLog(BoActionContext actionContext, String operatetype, String createtime, String lastmodifytime, String username, String ipaddress, String description)
    throws Exception
  {
    String sql = "";
    if (DaoHelper.isNotEmpty(operatetype)) {
      sql = sql + "OPERATE_TYPE" + "='" + operatetype + "'";
    }

    if ((DaoHelper.isNotEmpty(createtime)) && (DaoHelper.isNotEmpty(lastmodifytime)))
    {
      sql = sql + " AND " + "CREATETIME" + " >=" + createtime + " AND " + "CREATETIME" + " <=" + lastmodifytime;
    }

    if ((DaoHelper.isNotEmpty(createtime)) && (!DaoHelper.isNotEmpty(lastmodifytime)))
    {
      sql = sql + " AND " + "CREATETIME" + " >=" + createtime;
    }

    if ((DaoHelper.isNotEmpty(lastmodifytime)) && (!DaoHelper.isNotEmpty(createtime)))
    {
      sql = sql + " AND " + "CREATETIME" + " <=" + lastmodifytime;
    }

    if (DaoHelper.isNotEmpty(username)) {
      sql = sql + " AND " + "USER_NAME" + " ='" + username + "'";
    }

    if (DaoHelper.isNotEmpty(ipaddress)) {
      sql = sql + " AND " + "IP_ADDRESS" + "='" + ipaddress + "'";
    }

    if (DaoHelper.isNotEmpty(description)) {
      sql = sql + " AND " + "DESCIPTION" + " LIKE '%" + description + "%'";
    }

    return super.getObjectsBySql(sql, new SystemLog(), 0);
  }

  public DboCollection getLogs(BoActionContext actionContext, String operatetype, String classname, String createtime, String lastmodifytime, String username, String ipaddress, String description, String orgCuid)
    throws Exception
  {
    String sql = "SELECT USER_NAME,OPERATE_TYPE,CREATETIME,CLASS_NAME,OBJECT_NAME,MACHINE_NAME,IP_ADDRESS,DESCIPTION FROM SYSTEM_LOG WHERE ";
    DboCollection dbos = new DboCollection();
    SystemLog systemLog = new SystemLog();
    if (DaoHelper.isNotEmpty(operatetype)) {
      sql = sql + "OPERATE_TYPE='" + operatetype + "'";
    }
    if (DaoHelper.isNotEmpty(classname)) {
      sql = sql + " AND CLASS_NAME LIKE '%" + classname + "%'";
    }
    if ((DaoHelper.isNotEmpty(createtime)) && (DaoHelper.isNotEmpty(lastmodifytime)))
    {
      sql = sql + " AND CREATETIME>=" + createtime + " AND CREATETIME <=" + lastmodifytime + "";
    }

    if ((DaoHelper.isNotEmpty(createtime)) && (!DaoHelper.isNotEmpty(lastmodifytime)))
    {
      sql = sql + " AND CREATETIME>=" + createtime + "";
    }
    if ((DaoHelper.isNotEmpty(lastmodifytime)) && (!DaoHelper.isNotEmpty(createtime)))
    {
      sql = sql + " AND CREATETIME<=" + lastmodifytime + "";
    }
    if (DaoHelper.isNotEmpty(username)) {
      if (username.equals("0")) {
        if (DaoHelper.isNotEmpty(orgCuid)) {
          sql = sql + " AND " + "USER_NAME" + " IN (select USER_NAME FROM " + "SYS_USER" + " where " + "RELATED_ORGANIZATION_CUID" + "='" + orgCuid + "')";
        }

      }
      else
      {
        sql = sql + " AND " + "USER_NAME" + " = '" + username + "'";
      }

    }

    if (DaoHelper.isNotEmpty(ipaddress)) {
      sql = sql + " AND IP_ADDRESS LIKE '%" + ipaddress + "%'";
    }
    if (DaoHelper.isNotEmpty(description)) {
      sql = sql + " AND DESCIPTION LIKE '%" + description + "%'";
    }
    sql = sql + " order by " + "CREATETIME" + " DESC";
    dbos = super.selectDBOs(sql, new GenericDO[] { systemLog });
    return dbos;
  }

  public DboCollection getLogExcel(BoActionContext actionContext, String elementCuid, String cardCuid) throws Exception
  {
    Ptp ptp = new Ptp();
    TransElement ne = new TransElement();
    Card card = new Card();
    EquipmentHolder holder = new EquipmentHolder();
    DboCollection dbos = new DboCollection();
    String sql = "select   ne.LABEL_CN,   h.LABEL_CN,   c.LABEL_CN,   p.PORT_NO,   p.PORT_TYPE,   p.PORT_RATE,   p.DIRECTIONALITY,   p.PORT_STATE,   p.LABEL_CN,   p.USERLABEL,   p.CUID,   p.OBJECTID from PTP p,TRANS_ELEMENT ne,CARD c,EQUIPMENT_HOLDER h where p.RELATED_NE_CUID=ne.CUID and p.RELATED_CARD_CUID=c.CUID and c.RELATED_UPPER_COMPONENT_CUID=h.CUID and p.RELATED_NE_CUID='" + elementCuid + "'";

    if (cardCuid.trim().length() > 0) {
      sql = sql + " and p.RELATED_CARD_CUID='" + cardCuid + "'";
    }
    dbos = super.selectDBOs(sql, new GenericDO[] { ptp, ne, card, holder });
    for (int i = 0; i < dbos.size(); i++) {
      String ptpLabelCn = ((Ptp)dbos.getAttrField("PTP", 0)).getLabelCn();

      String ptpCuid = ((Ptp)dbos.getAttrField("PTP", 0)).getCuid();

      long ptpObjectId = ((Ptp)dbos.getAttrField("PTP", 0)).getObjectNum();

      long portType = ((Ptp)dbos.getAttrField("PTP", 0)).getPortType();
      String traphSql = "END_PORT_A='" + ptpLabelCn + "' or " + "END_PORT_Z" + "='" + ptpLabelCn + "'";

      DataObjectList traphs = super.getObjectsBySql(traphSql, new Traph(), 0);

      if ((traphs != null) && (traphs.size() > 0)) {
        dbos.insertAttrField(i, (IAttrObject)traphs.get(0));
      } else {
        Traph dbo = new Traph();
        dbo.setLabelCn("无");
        dbos.insertAttrField(i, dbo);
      }

      GenericDO ptpInfo = new GenericDO("PTPINFO");

      if (portType == 1L) {
        DataObjectList jumppairs = super.selectDBOs("SELECT DP.LABEL_CN FROM JUMP_PAIR JP,DDFPORT DP WHERE JP.ORIG_POINT_CUID=DP.CUID AND JP.DEST_POINT_CUID='" + ptpCuid + "'", new Class[] { String.class });

        if ((jumppairs != null) && (jumppairs.size() > 0)) {
          ptpInfo.setAttrValue("LABEL_CN", ((GenericDO)jumppairs.get(0)).getAttrString("1"));
        } else {
          jumppairs = super.selectDBOs("SELECT DP.LABEL_CN FROM JUMP_PAIR JP,DDFPORT DP WHERE JP.DEST_POINT_CUID=DP.CUID AND JP.ORIG_POINT_CUID='" + ptpCuid + "'", new Class[] { String.class });

          if ((jumppairs != null) && (jumppairs.size() > 0))
            ptpInfo.setAttrValue("LABEL_CN", ((GenericDO)jumppairs.get(0)).getAttrString("1"));
        }
      }
      else if (portType == 2L) {
        DataObjectList jumpfiber = super.selectDBOs("SELECT DP.LABEL_CN FROM JUMP_FIBER JP,ODFPORT DP WHERE JP.ORIG_POINT_CUID=DP.CUID AND JP.DEST_POINT_CUID='" + ptpCuid + "'", new Class[] { String.class });

        if ((jumpfiber != null) && (jumpfiber.size() > 0)) {
          ptpInfo.setAttrValue("LABEL_CN", ((GenericDO)jumpfiber.get(0)).getAttrString("1"));
        } else {
          jumpfiber = super.selectDBOs("SELECT DP.LABEL_CN FROM JUMP_FIBER JP,ODFPORT DP WHERE JP.DEST_POINT_CUID=DP.CUID AND JP.ORIG_POINT_CUID='" + ptpCuid + "'", new Class[] { String.class });

          if ((jumpfiber != null) && (jumpfiber.size() > 0)) {
            ptpInfo.setAttrValue("LABEL_CN", ((GenericDO)jumpfiber.get(0)).getAttrString("1"));
          }
        }
      }
      dbos.insertAttrField(i, ptpInfo);
    }

    return dbos;
  }

  public SysUser getSysUserByCuid(BoActionContext boActionContext, String userCuid) throws Exception
  {
    SysUser dbo = new SysUser();
    dbo.setCuid(userCuid);
    dbo = (SysUser)super.getObjByCuid(dbo);
    if (dbo != null) {
      String sql = "USER_CUID='" + userCuid + "'";

      DataObjectList dbos = super.getObjectsBySql(sql, new UserManageDistrict(), 0);

      String managerDistrictString = "";
      for (int i = 0; i < dbos.size(); i++) {
        UserManageDistrict md = (UserManageDistrict)dbos.get(i);
        managerDistrictString = managerDistrictString + "," + md.getDistrictCuid();
      }

      if (managerDistrictString.trim().length() > 0) {
        dbo.setManagerDistrictCuid(managerDistrictString.substring(1, managerDistrictString.length()));
      }
      else {
        dbo.setManagerDistrictCuid(managerDistrictString);
      }
    }
    return dbo;
  }

  public DataObjectList getSysUserBySql(String sql) throws Exception {
    return super.getObjectsBySql(sql, new SysUser(), 0);
  }

  public boolean isRoleInUsed(String roleCuid) throws Exception
  {
    UserHaveRole dbo = new UserHaveRole();
    int count = super.getCalculateValue("select count(*) from " + dbo.getClassName() + " where " + "ROLE_CUID" + "='" + roleCuid + "'");

    return count > 0;
  }

  public FunctionTreeNode addFunctionTreeNode(BoActionContext boActionContext, FunctionTreeNode dbo)
    throws Exception
  {
    super.createObject(boActionContext, dbo);
    return dbo;
  }

  public FunctionTreeNode getFunctionTreeNode(BoActionContext boActionContext, String cuid) throws Exception
  {
    FunctionTreeNode dbo = new FunctionTreeNode();
    dbo.setCuid(cuid);
    return (FunctionTreeNode)super.getObjByCuid(dbo);
  }

  public FunctionTreeNode getFunctionTreeNodeByName(BoActionContext boActionContext, String nodeName) throws Exception
  {
    FunctionTreeNode dbo = null;
    String sql = "NODE_NAME='" + nodeName + "'";
    DataObjectList dbos = super.getObjectsBySql(sql, new FunctionTreeNode(), 0);

    if (dbos.size() > 0) {
      dbo = (FunctionTreeNode)dbos.get(0);
    }
    return dbo;
  }

  public FunctionTreeNode getFunctionTreeNode(BoActionContext boActionContext, Long objectId) throws Exception
  {
    FunctionTreeNode dbo = new FunctionTreeNode();
    dbo.setObjectNum(objectId.longValue());
    return (FunctionTreeNode)super.getObject(dbo);
  }

  public void modifyFunctionTreeNode(BoActionContext boActionContext, FunctionTreeNode dbo) throws Exception
  {
    FunctionTreeNode olddbo = getFunctionTreeNode(boActionContext, Long.valueOf(dbo.getObjectNum()));

    String sql = "RELATED_NODE_CUID='" + olddbo.getCuid() + "'";

    HashMap attrmap = new HashMap();
    attrmap.put("RELATED_NODE_CUID", dbo.getCuid());
    super.updateObjects(boActionContext, "FUNCTION_TREE_NODE", sql, attrmap);

    super.updateObject(boActionContext, dbo);
  }

  public void delFunctionTreeNodeByCuid(BoActionContext boActionContext, String cuid) throws Exception
  {
    FunctionTreeNode dbo = new FunctionTreeNode();
    dbo.setCuid(cuid);
    super.deleteObject(boActionContext, super.getObjByCuid(dbo));
  }

  public void delFunctionTreeNode(BoActionContext boActionContext, DataObjectList dbos) throws Exception
  {
    super.deleteObjects(boActionContext, dbos);
  }

  public void delLoginLog(BoQueryContext queryContext, LoginLog log)
    throws Exception
  {
    String sql = "DELETE FROM LOGIN_LOG WHERE CUID='" + log.getCuid() + "'";

    super.execSql(sql);
  }

  public DboCollection getLoginlogs(BoActionContext actionContext, Long loginType, String startTime, String endTime, String userName, String orgCuid)
    throws Exception
  {
    LoginLog logs = new LoginLog();
    String sql = "SELECT * FROM LOGIN_LOG WHERE ";
    DboCollection dbos = new DboCollection();
    if (DaoHelper.isNotEmpty(String.valueOf(loginType))) {
      int lt = loginType.intValue();
      sql = sql + "LOGIN_TYPE" + "=" + lt;
    }

    if ((DaoHelper.isNotEmpty(startTime)) && (DaoHelper.isNotEmpty(endTime))) {
      sql = sql + " AND " + "LOGIN_TIME" + " >=" + startTime + " AND " + "LOGIN_TIME" + " <=" + endTime;
    }

    if ((DaoHelper.isNotEmpty(startTime)) && (!DaoHelper.isNotEmpty(endTime))) {
      sql = sql + " AND " + "LOGIN_TIME" + " >=" + startTime;
    }

    if ((DaoHelper.isNotEmpty(endTime)) && (!DaoHelper.isNotEmpty(startTime))) {
      sql = sql + " AND " + "LOGIN_TIME" + " <=" + endTime;
    }

    if (DaoHelper.isNotEmpty(userName)) {
      if (userName.equals("0")) {
        if (DaoHelper.isNotEmpty(orgCuid)) {
          sql = sql + " AND " + "USER_NAME" + " IN (select USER_NAME FROM " + "SYS_USER" + " where " + "RELATED_ORGANIZATION_CUID" + "='" + orgCuid + "')";
        }

      }
      else
      {
        sql = sql + " AND " + "USER_NAME" + " = '" + userName + "'";
      }
    }

    sql = sql + " order by " + "USER_NAME" + "," + "LOGIN_TIME" + " DESC";

    dbos = super.selectDBOs(sql, new GenericDO[] { logs });
    return dbos;
  }

  public DboCollection getLoginlogsForExcel(BoActionContext actionContext, String startTime, String endTime, String userName, String orgCuid)
    throws Exception
  {
    LoginLog logs = new LoginLog();
    String sql = "SELECT LL.* FROM LOGIN_LOG LL,SYS_USER SU WHERE SU.USER_NAME = LL.USER_NAME";

    DboCollection dbos = new DboCollection();
    if ((DaoHelper.isNotEmpty(startTime)) && (DaoHelper.isNotEmpty(endTime))) {
      sql = sql + " AND (" + "LOGIN_TIME" + " >=" + startTime + " AND " + "LOGIN_TIME" + " <=" + endTime + ") ";
    }

    if ((DaoHelper.isNotEmpty(startTime)) && (!DaoHelper.isNotEmpty(endTime))) {
      sql = sql + " AND " + "LOGIN_TIME" + " >=" + startTime;
    }

    if ((DaoHelper.isNotEmpty(endTime)) && (!DaoHelper.isNotEmpty(startTime))) {
      sql = sql + " AND " + "LOGIN_TIME" + " <=" + endTime;
    }
    if ((DaoHelper.isNotEmpty(orgCuid)) && (DaoHelper.isNotEmpty(userName))) {
      sql = sql + " AND " + "RELATED_ORGANIZATION_CUID" + "='" + orgCuid + "' AND LL." + "USER_NAME" + " = '" + userName + "' ";
    }
    else if ((DaoHelper.isNotEmpty(orgCuid)) && (!DaoHelper.isNotEmpty(userName)))
    {
      sql = sql + " AND " + "RELATED_ORGANIZATION_CUID" + "='" + orgCuid + "' ";
    }
    else if ((!DaoHelper.isNotEmpty(orgCuid)) && (DaoHelper.isNotEmpty(userName)))
    {
      sql = sql + " AND LL." + "USER_NAME" + "= '" + userName + "'";
    }

    sql = sql + " order by " + "LOGIN_TIME" + " DESC";
    dbos = super.selectDBOs(sql, new GenericDO[] { logs });
    return dbos;
  }

  public Organization getOrganizationByName(String name) throws Exception {
    String sql = new String();
    sql = "ORG_NAME='" + name + "'";
    DataObjectList organization = super.getObjectsBySql(sql, new Organization(), 0);

    if ((organization != null) && (organization.size() > 0)) {
      return (Organization)organization.get(0);
    }
    return null;
  }

  public UserRole getRoleByName(String name) throws Exception
  {
    String sql = new String();
    sql = "ROLE_NAME='" + name + "'";
    DataObjectList role = super.getObjectsBySql(sql, new UserRole(), 0);

    if ((role != null) && (role.size() > 0)) {
      return (UserRole)role.get(0);
    }
    return null;
  }

  public DataObjectList getBackupEquipRole(BoActionContext boActionContext, String userCuid)
    throws Exception
  {
    String sql = "DISTRICT_CUID='DISTRICT-00001' AND USER_CUID='" + userCuid + "' AND " + "ROLE_CUID" + " LIKE 'BACKUPEQUIP-%'";

    return super.getObjectsBySql(sql, new UserHaveRole(), 0);
  }

  public DataObjectList getOrganizationByQuery(BoActionContext actionContext, String orgName, String beginTime, String endTime, String department, String relatedOrgCode)
    throws Exception
  {
    DbType dbType = DbConnManager.getInstance().getDbContext().getDbType();
    String sql = "1=1 ";
    if ((orgName != null) && (orgName.length() > 0)) {
      sql = sql + " and " + "ORG_NAME" + " like '%" + orgName + "%' ";
    }

    if ((department != null) && (department.length() > 0)) {
      sql = sql + "and " + "DEPARTMENT" + " like '%" + department + "%' ";
    }

    if ((beginTime != null) && (beginTime.length() > 0)) {
      beginTime = SqlHelper.getTimestamp(dbType, TimeFormatHelper.getFormatTimestamp(beginTime));

      sql = sql + " and CREATE_TIME >= " + beginTime;
    }
    if ((endTime != null) && (endTime.length() > 0)) {
      endTime = SqlHelper.getTimestamp(dbType, TimeFormatHelper.getFormatTimestamp(endTime));

      sql = sql + " and CREATE_TIME <= " + endTime;
    }
    if ((relatedOrgCode != null) && (relatedOrgCode.length() > 0)) {
      sql = sql + " and " + "RELATED_ORG_CUID" + " ='" + relatedOrgCode + "' ";
    }

    return super.getObjectsBySql(sql, new Organization(), 0);
  }

  public DboCollection getSysUserByPage(BoQueryContext queryContext, String userName, String beginTime, String endTime, String orgCuid, String isLocked, String dep, String orderString)
    throws Exception
  {
    DbType dbType = DbConnManager.getInstance().getDbContext().getDbType();
    String sql = "select s.* from SYS_USER s ";

    String wheresql = " where s.CUID<>'SYS_USER-0' ";

    if ((userName != null) && (userName.length() > 0)) {
      wheresql = wheresql + " and s." + "USER_NAME" + " like '%" + userName + "%' ";
    }

    if ((dep != null) && (dep.length() > 0)) {
      wheresql = wheresql + " and s." + "DEPARTMENT" + " like '%" + dep + "%' ";
    }

    if ((orgCuid != null) && (orgCuid.length() > 0)) {
      wheresql = wheresql + " and s." + "RELATED_ORGANIZATION_CUID" + " ='" + orgCuid + "' ";
    }

    if ((beginTime != null) && (beginTime.length() > 0)) {
      beginTime = SqlHelper.getTimestamp(dbType, TimeFormatHelper.getFormatTimestamp(beginTime));

      wheresql = wheresql + " and s.CREATE_TIME >= " + beginTime;
    }
    if ((endTime != null) && (endTime.length() > 0)) {
      endTime = SqlHelper.getTimestamp(dbType, TimeFormatHelper.getFormatTimestamp(endTime));

      wheresql = wheresql + " and s.CREATE_TIME <= " + endTime;
    }
    if ((isLocked != null) && (isLocked.equals("true")))
      wheresql = wheresql + " and s." + "IS_LOCKED" + "=1 ";
    else {
      wheresql = wheresql + " and s." + "IS_LOCKED" + "<>1 ";
    }

    if (wheresql.trim().length() > 0) {
      sql = sql + wheresql;
    }
    if (orderString.trim().length() > 0) {
      sql = sql + " order by " + orderString;
    }
    return super.selectDBOs(queryContext, sql, new GenericDO[] { new SysUser() });
  }

  public DboCollection getSysUserByPageNew(BoQueryContext queryContext, String userName, String beginTime, String endTime, String orgCuid, String isLocked, String dep, String orderString, String relatedDistrictCuid)
    throws Exception
  {
    DbType dbType = DbConnManager.getInstance().getDbContext().getDbType();
    String sql = "select s.* from SYS_USER s ";

    String wheresql = " where s.CUID<>'SYS_USER-0' ";

    if ((userName != null) && (userName.length() > 0)) {
      wheresql = wheresql + " and s." + "USER_NAME" + " like '%" + userName + "%' ";
    }

    if ((dep != null) && (dep.length() > 0)) {
      wheresql = wheresql + " and s." + "DEPARTMENT" + " like '%" + dep + "%' ";
    }

    if ((orgCuid != null) && (orgCuid.length() > 0)) {
      wheresql = wheresql + " and s." + "RELATED_ORGANIZATION_CUID" + " ='" + orgCuid + "' ";
    }

    if ((beginTime != null) && (beginTime.length() > 0)) {
      beginTime = SqlHelper.getTimestamp(dbType, TimeFormatHelper.getFormatTimestamp(beginTime));

      wheresql = wheresql + " and s.CREATE_TIME >= " + beginTime;
    }
    if ((endTime != null) && (endTime.length() > 0)) {
      endTime = SqlHelper.getTimestamp(dbType, TimeFormatHelper.getFormatTimestamp(endTime));

      wheresql = wheresql + " and s.CREATE_TIME <= " + endTime;
    }
    if ((isLocked != null) && (isLocked.equals("true")))
      wheresql = wheresql + " and s." + "IS_LOCKED" + "=1 ";
    else {
      wheresql = wheresql + " and s." + "IS_LOCKED" + "<>1 ";
    }

    wheresql = wheresql + " and s." + "RELATED_DISTRICT_CUID" + " like '" + relatedDistrictCuid + "%' ";
    if (wheresql.trim().length() > 0) {
      sql = sql + wheresql;
    }
    if (orderString.trim().length() > 0) {
      sql = sql + " order by " + orderString;
    }
    return super.selectDBOs(queryContext, sql, new GenericDO[] { new SysUser() });
  }

  public DboCollection querySecurityByName(BoQueryContext queryContext, String name, String orderString)
    throws Exception
  {
    String sql = "SELECT * FROM USER_PASSWORD_SECURITY";
    if ((name != null) && (name.trim().length() > 0)) {
      sql = sql + " WHERE " + "SECURITY_NAME" + " LIKE '%" + name + "%'";
    }

    if (orderString.trim().length() > 0) {
      sql = sql + " order by " + orderString;
    }
    return super.selectDBOs(queryContext, sql, new GenericDO[] { new UserPasswordSecurity() });
  }

  public void modifyUserPasswordSecurity(BoActionContext actionContext, UserPasswordSecurity dbo)
    throws Exception
  {
    dbo.clearUnknowAttrs();
    super.updateObject(actionContext, dbo);
  }

  public DboCollection getSystemLog(BoQueryContext queryContext, HashMap param, String orderString)
    throws Exception
  {
    String sql = "SELECT * FROM SYSTEM_LOG WHERE ";
    if (((String)param.get("create_time") != null) && (((String)param.get("create_time")).trim().length() > 0))
    {
      String createtime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp((String)param.get("create_time")));

      param.put("create_time", createtime);
    }
    if (((String)param.get("last_modify_time") != null) && (((String)param.get("last_modify_time")).trim().length() > 0))
    {
      String lastmodifytime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp((String)param.get("last_modify_time")));

      param.put("last_modify_time", lastmodifytime);
    }

    if (DaoHelper.isNotEmpty((String)param.get("operate_type"))) {
      sql = sql + "OPERATE_TYPE" + "='" + (String)param.get("operate_type") + "'";
    }

    if ((DaoHelper.isNotEmpty((String)param.get("create_time"))) && (DaoHelper.isNotEmpty((String)param.get("last_modify_time"))))
    {
      sql = sql + " AND " + "CREATETIME" + " >=" + (String)param.get("create_time") + " AND " + "CREATETIME" + " <=" + (String)param.get("last_modify_time");
    }

    if ((DaoHelper.isNotEmpty((String)param.get("create_time"))) && (!DaoHelper.isNotEmpty((String)param.get("last_modify_time"))))
    {
      sql = sql + " AND " + "CREATETIME" + " >=" + (String)param.get("create_time");
    }

    if ((DaoHelper.isNotEmpty((String)param.get("last_modify_time"))) && (!DaoHelper.isNotEmpty((String)param.get("create_time"))))
    {
      sql = sql + " AND " + "CREATETIME" + " <=" + (String)param.get("last_modify_time");
    }

    if (DaoHelper.isNotEmpty((String)param.get("class_name"))) {
      sql = sql + " AND " + "LOG_CLASS_NAME" + " LIKE '%" + (String)param.get("class_name") + "%'";
    }

    if (DaoHelper.isNotEmpty((String)param.get("user_name"))) {
      sql = sql + " AND " + "USER_NAME" + " = '" + (String)param.get("user_name") + "'";
    }

    if (DaoHelper.isNotEmpty((String)param.get("orgCuid"))) {
      sql = sql + " AND " + "USER_NAME" + " IN (select USER_NAME FROM " + "SYS_USER" + " where " + "RELATED_ORGANIZATION_CUID" + "='" + (String)param.get("orgCuid") + "')";
    }

    if (DaoHelper.isNotEmpty((String)param.get("ip_address"))) {
      sql = sql + " AND " + "IP_ADDRESS" + " LIKE '%" + (String)param.get("ip_address") + "%'";
    }

    if (DaoHelper.isNotEmpty((String)param.get("description"))) {
      sql = sql + " AND " + "DESCIPTION" + " LIKE '%" + (String)param.get("description") + "%'";
    }

    if (DaoHelper.isNotEmpty(orderString))
      sql = sql + " order by  " + orderString;
    else {
      sql = sql + " order by " + "CREATETIME" + " DESC";
    }

    return super.selectDBOs(queryContext, sql, new GenericDO[] { new SystemLog() });
  }

  public DboCollection getLoginLogBypage(BoQueryContext queryContext, HashMap param, String orderString)
    throws Exception
  {
    String sql = "SELECT LL.* FROM LOGIN_LOG LL,SYS_USER SU WHERE SU.USER_NAME = LL.USER_NAME";

    String createtime = (String)param.get("create_time");
    String lastmodifytime = (String)param.get("last_modify_time");
    if ((createtime != null) && (createtime.trim().length() > 0)) {
      createtime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(createtime));

      param.put("create_time", createtime);
    }
    if ((lastmodifytime != null) && (lastmodifytime.trim().length() > 0)) {
      lastmodifytime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(lastmodifytime));

      param.put("last_modify_time", lastmodifytime);
    }

    if ((DaoHelper.isNotEmpty((String)param.get("create_time"))) && (DaoHelper.isNotEmpty((String)param.get("last_modify_time"))))
    {
      sql = sql + " AND (" + "LOGIN_TIME" + " >=" + (String)param.get("create_time") + " AND " + "LOGIN_TIME" + " <=" + (String)param.get("last_modify_time") + ") ";
    }

    if ((DaoHelper.isNotEmpty((String)param.get("create_time"))) && (!DaoHelper.isNotEmpty((String)param.get("last_modify_time"))))
    {
      sql = sql + " AND " + "LOGIN_TIME" + " >=" + (String)param.get("create_time");
    }

    if ((DaoHelper.isNotEmpty((String)param.get("last_modify_time"))) && (!DaoHelper.isNotEmpty((String)param.get("create_time"))))
    {
      sql = sql + " AND " + "LOGIN_TIME" + " <=" + (String)param.get("last_modify_time");
    }

    if ((DaoHelper.isNotEmpty((String)param.get("orgCuid"))) && (DaoHelper.isNotEmpty((String)param.get("user_name"))))
    {
      sql = sql + " AND " + "RELATED_ORGANIZATION_CUID" + "='" + (String)param.get("orgCuid") + "' AND LL." + "USER_NAME" + " = '" + (String)param.get("user_name") + "' ";
    }
    else if ((DaoHelper.isNotEmpty((String)param.get("orgCuid"))) && (!DaoHelper.isNotEmpty((String)param.get("user_name"))))
    {
      sql = sql + " AND " + "RELATED_ORGANIZATION_CUID" + "='" + (String)param.get("orgCuid") + "' ";
    }
    else if ((!DaoHelper.isNotEmpty((String)param.get("orgCuid"))) && (DaoHelper.isNotEmpty((String)param.get("user_name"))))
    {
      sql = sql + " AND LL." + "USER_NAME" + "= '" + (String)param.get("user_name") + "'";
    }

    if ((DaoHelper.isNotEmpty(orderString)) && (orderString.indexOf("STAY_TIME") >= 0))
    {
      orderString = orderString.replace("STAY_TIME", "LOGIN_TIME");
    }
    if (DaoHelper.isNotEmpty(orderString)) {
      if (orderString.indexOf("USER_NAME") >= 0)
        sql = sql + " order by LL." + orderString;
      else
        sql = sql + " order by " + orderString;
    }
    else {
      sql = sql + " order by " + "LOGIN_TIME" + " DESC";
    }
    return super.selectDBOs(queryContext, sql, new GenericDO[] { new LoginLog() });
  }

  public void delLoginLogsBycuid(BoActionContext actionContext, String cuid) throws Exception
  {
    String sql = "delete from LOGIN_LOG where ";
    sql = sql + "CUID='" + cuid + "'";
    super.execSql(sql);
  }

  public DboCollection getSysUserByOrgCuid(BoActionContext actionContext, String orgCuid)
    throws Exception
  {
    if (orgCuid.trim().length() > 0) {
      String sql = "select * from SYS_USER where RELATED_ORGANIZATION_CUID = '" + orgCuid + "' order by USER_NAME";

      return super.selectDBOs(sql, new GenericDO[] { new SysUser() });
    }
    String sql = "select * from SYS_USER";
    return super.selectDBOs(sql, new GenericDO[] { new SysUser() });
  }

  public DboCollection getWarningLimit(BoActionContext context, int value)
  {
    String sql = "select * from WARNING_LIMIT where RELATED_WARNING_ID = " + value + "";
    try
    {
      DboCollection dboc = super.selectDBOs(sql, new GenericDO[] { new WarningLimit() });

      DataObjectList dbos = getWarningPolicy(context, value);

      if ((dboc != null) && (dboc.size() > 0)) {
        for (int i = 0; i < dboc.size(); i++) {
          WarningLimit limit = (WarningLimit)dboc.getAttrField("WARNING_LIMIT", i);

          if ((dbos != null) && (dbos.size() > 0)) {
            GenericDO dbo = (GenericDO)dbos.get(0);
            String warningPolicy = dbo.getAttrString("1");
            limit.setAttrValue("WARNING_POLICY", warningPolicy);
          }
        }
      }
      return dboc;
    } catch (Exception ex) {
      throw new UserException("根据指标ID获取门限失败" + ex.getMessage());
    }
  }

  public DataObjectList getWarningPolicy(BoActionContext context, int value) {
    try {
      String sql = "select WARNING_POLICY from PREWARNING_CONFIG where WARNING_ID = " + value + "";

      return super.selectDBOs(sql, new Class[] { String.class });
    } catch (Exception ex) {
      throw new UserException("根据指标ID获取超过门限值建议策略失败" + ex.getMessage());
    }
  }

  public SysUser getSameManageDistrictUser(BoActionContext context, String userCuid, String managerDistrictCuid)
    throws Exception
  {
    SysUser dto = getSysUserByCuid(context, userCuid);
    String _manageDisCuids = dto.getManagerDistrictCuid();
    String[] managerDistrictCuids = managerDistrictCuid != null ? managerDistrictCuid.split(",") : null;

    if (((_manageDisCuids != null) && (_manageDisCuids.trim().length() != 0)) || ((managerDistrictCuids == null) || (_manageDisCuids.equals(managerDistrictCuid))))
    {
      return dto;
    }if ((_manageDisCuids != null) && (_manageDisCuids.trim().length() > 0) && (managerDistrictCuids != null))
    {
      for (int j = 0; j < managerDistrictCuids.length; j++) {
        if (_manageDisCuids.indexOf(managerDistrictCuids[j]) == -1) {
          return null;
        }
      }
    }
    return null;
  }

  public DataObjectList getUserHaveObjectsByUserCuidAndDistrictCuid(BoActionContext actionContext, String userCuid, String districtCuid)
    throws Exception
  {
    String sql = "RELATED_USER_CUID='" + userCuid + "'";

    if ((districtCuid != null) && (districtCuid.trim().length() > 0)) {
      String _tempCuids = userCuid;
      _tempCuids = "'" + _tempCuids.replaceAll(",", "','") + "'";
      sql = sql + " AND RELATED_DISTRICT_CUID IN (" + _tempCuids + ")";
    }

    DataObjectList dbos = super.getObjectsBySql(sql, new UserHaveObject(), 0);

    return dbos;
  }

  public DataObjectList getUserHaveRoleByUserCuidAndDistrictCuid(BoActionContext actionContext, String userCuid, String districtCuid)
    throws Exception
  {
    String sql = "USER_CUID = '" + userCuid + "'";
    if ((districtCuid != null) && (districtCuid.trim().length() > 0)) {
      String _tempCuids = userCuid;
      _tempCuids = "'" + _tempCuids.replaceAll(",", "','") + "'";
      sql = sql + " AND DISTRICT_CUID IN (" + _tempCuids + ")";
    }

    return super.getObjectsBySql(sql, new UserHaveRole(), 0);
  }

  public DataObjectList getAllORG() throws Exception
  {
    String sql = "SELECT CUID,ORG_NAME,RELATED_ORG_CUID FROM ORGANIZATION";

    Class[] type = { String.class, String.class, String.class };
    return super.selectDBOs(sql, type);
  }

  public DataObjectList getUserOrgByName(String name) throws Exception {
    String sql = "SELECT RELATED_ORGANIZATION_CUID FROM SYS_USER WHERE USER_NAME = '" + name + "'";

    Class[] type = { String.class };
    return super.selectDBOs(sql, type);
  }

  public DataObjectList getReportFunctionNodeByUserCuid(BoActionContext boActionContext, String userCuid) throws Exception
  {
    String sql = "SELECT RCOFP.FUNCTION_NODE_CUID FROM USER_HAVE_ROLE UHR,ROLE_CONSIST_OF_FUN_POINT RCOFP  WHERE UHR.ROLE_CUID = RCOFP.ROLE_CUID AND RCOFP.FUNCTION_NODE_CUID LIKE 'FUNCTION_TREE_NODE-3%'  AND USER_CUID = '" + userCuid + "'";

    Class[] type = { String.class };
    return super.selectDBOs(sql, type);
  }

  public DataObjectList getFunctionNodeByUserCuid(BoActionContext boActionContext, String userCuid) throws Exception
  {
    String sql = "SELECT RCOFP.FUNCTION_NODE_CUID FROM USER_HAVE_ROLE UHR,ROLE_CONSIST_OF_FUN_POINT RCOFP  WHERE UHR.ROLE_CUID = RCOFP.ROLE_CUID AND USER_CUID = '" + userCuid + "'";

    Class[] type = { String.class };
    return super.selectDBOs(sql, type);
  }

  public Boolean isWFUser(BoActionContext actionContext, String sql) throws Exception
  {
    DataObjectList dbos = super.selectDBOs(sql, new Class[] { Integer.TYPE });
    if ((dbos != null) && (dbos.size() > 0)) {
      return Boolean.valueOf(true);
    }
    return Boolean.valueOf(false);
  }

  public void addHistoryUserPassword(BoActionContext actionContext, HistoryUserPassword dbo)
    throws Exception
  {
    super.createObject(actionContext, dbo);
  }

  public DataObjectList getHistoryUserPasswordBySysUserCuid(BoActionContext actionContext, String userCuid)
    throws Exception
  {
    String sql = "USER_CUID='" + userCuid + "'" + " ORDER BY LAST_MODIFY_TIME DESC";

    return super.getObjectsBySql(sql, new HistoryUserPassword(), 0);
  }

  public DataObjectList getAllHistoryUserPassword(BoActionContext actionContext)
    throws Exception
  {
    String sql = " ORDER BY USER_CUID, LAST_MODIFY_TIME DESC";

    return super.getObjectsBySql(sql, new HistoryUserPassword(), 0);
  }

  public void deleteHistoryUserPassword(BoActionContext actionContext, HistoryUserPassword dbo)
    throws Exception
  {
    super.deleteObject(actionContext, dbo);
  }

  public void deleteHistoryUserPasswords(BoActionContext actionContext, DataObjectList dbos)
    throws Exception
  {
    super.deleteObjects(actionContext, dbos);
  }

  public DboCollection getUserNameByOrgCuid(BoActionContext actionContext, String orgCuid, String userName)
    throws Exception
  {
    String sql = "select * from SYS_USER where 1=1 ";
    if (orgCuid.trim().length() > 0) {
      if (orgCuid.indexOf(",") > 0) {
        orgCuid = orgCuid.replaceAll(",", "','");
        sql = sql + " AND  RELATED_ORGANIZATION_CUID in ('" + orgCuid + "') ";
      } else {
        sql = sql + " AND  RELATED_ORGANIZATION_CUID = '" + orgCuid + "' ";
      }
    }
    if (DaoHelper.isNotEmpty(userName)) {
      sql = sql + " AND USER_NAME LIKE '%" + userName + "%' ";
    }
    sql = sql + "  order by USER_NAME ";
    return super.selectDBOs(sql, new GenericDO[] { new SysUser() });
  }

  public DataObjectList getAllLocalReportFunctionNode(BoActionContext boActionContext)
    throws Exception
  {
    String sql = "CUID LIKE 'FUNCTION_TREE_NODE-3-%'";

    return super.getObjectsBySql(sql, new FunctionTreeNode(), 0);
  }

  public DboCollection getSimQrySysUsers(BoQueryContext queryContext, HashMap qrySysUserMap)
    throws Exception
  {
    String sqlQry = getSimSysUserSql(qrySysUserMap);

    String sqlCon = "select CUID,USER_NAME,TRUE_NAME,MOBILE_PHONE from SYS_USER";

    if (sqlQry.equals(""))
      sqlQry = sqlCon;
    else {
      sqlQry = sqlCon + " where " + sqlQry;
    }
    return super.selectDBOs(sqlQry, new GenericDO[] { new SysUser() });
  }

  private String getSimSysUserSql(HashMap qrySysUserMap)
  {
    String sqlQry = "";
    Iterator itSysUser = qrySysUserMap.keySet().iterator();
    while (itSysUser.hasNext()) {
      String keySysUser = (String)itSysUser.next();
      String valueSysUser = (String)qrySysUserMap.get(keySysUser);
      String valCon = "";
      if (keySysUser.equals("RELATED_DISTRICT_CUID")) {
        if ((valueSysUser != null) && (!valueSysUser.equals(""))) {
          valCon = getSysUserSqlByAttrName("RELATED_DISTRICT_CUID", valueSysUser);
        }
      }
      else if (keySysUser.equals("RELATED_ORGANIZATION_CUID"))
      {
        if ((valueSysUser != null) && (!valueSysUser.equals(""))) {
          valCon = getSysUserSqlByAttrName("RELATED_ORGANIZATION_CUID", valueSysUser);
        }

      }
      else if (keySysUser.equals("TRUE_NAME")) {
        if ((valueSysUser != null) && (!valueSysUser.equals(""))) {
          valCon = "TRUE_NAME LIKE '%" + valueSysUser + "%' ";
        }
      }
      else if ((keySysUser.equals("USER_NAME")) && 
        (valueSysUser != null) && (!valueSysUser.equals(""))) {
        valCon = "USER_NAME LIKE '%" + valueSysUser + "%' ";
      }

      if ((valCon != null) && (!valCon.equals(""))) {
        valCon = "(" + valCon + ")";
        if (sqlQry.equals(""))
          sqlQry = sqlQry + valCon;
        else {
          sqlQry = sqlQry + " and " + valCon;
        }
      }
    }
    return sqlQry;
  }

  private String getSysUserSqlByAttrName(String attrName, String districtsVal)
  {
    StringTokenizer stringTokenizer = new StringTokenizer(districtsVal, ",");
    int num = stringTokenizer.countTokens();
    String cuidList = "";
    if (num > 1) {
      cuidList = "'" + stringTokenizer.nextToken() + "',";
      for (int i = 1; i < num - 1; i++) {
        cuidList = cuidList + "'" + stringTokenizer.nextToken() + "',";
      }
      cuidList = cuidList + "'" + stringTokenizer.nextToken() + "'";
    } else {
      cuidList = "'" + stringTokenizer.nextToken() + "'";
    }
    if ((cuidList == null) || (cuidList.trim().equals(""))) {
      return null;
    }
    String valueCon = "";
    if ((cuidList != null) && (!cuidList.trim().equals(""))) {
      valueCon = "((" + attrName + " in (" + cuidList + ")))";
    }
    return valueCon;
  }

  public void deleteRecordToManByUsercuid(BoActionContext boActionContext, String userCuid)
    throws Exception
  {
    String sql = "DELETE FROM RECORD_TO_MAN WHERE SYS_USER_CUID ='" + userCuid + "'";

    super.execSql(sql);
  }

  public boolean isSameSecurityName(BoQueryContext queryContext, String name)
    throws Exception
  {
    String sql = "SELECT * FROM USER_PASSWORD_SECURITY WHERE SECURITY_NAME ='" + name + "'";

    DboCollection dbos = super.selectDBOs(queryContext, sql, new GenericDO[] { new UserPasswordSecurity() });

    if (dbos.size() > 0) {
      return true;
    }
    return false;
  }

  public boolean isSameSecurityNameModify(BoQueryContext queryContext, String name, String cuid)
    throws Exception
  {
    String sql = "SELECT * FROM USER_PASSWORD_SECURITY WHERE SECURITY_NAME ='" + name + "' AND " + "CUID" + " !='" + cuid + "'";

    DboCollection dbos = super.selectDBOs(queryContext, sql, new GenericDO[] { new UserPasswordSecurity() });

    if (dbos.size() > 0) {
      return true;
    }
    return false;
  }

  public String addUserToCust(BoActionContext actionContext, String cuid, String custs)
    throws Exception
  {
    String[] custCuids = custs.split("@")[0].split(",");
    if ((custCuids != null) && (custCuids.length > 0)) {
      for (int i = 0; i < custCuids.length; i++) {
        UserToCust dbo = new UserToCust();
        dbo.setUserCuid(cuid);
        dbo.setCustCuid(custCuids[i]);
        super.createObject(actionContext, dbo);
      }
    }
    if (custs.split("@").length > 1) {
      return custs.split("@")[1];
    }
    return "";
  }

  public void deleteUserToCustByUsercuid(BoActionContext boActionContext, String userCuid)
    throws Exception
  {
    String sql = "DELETE FROM USER_TO_CUST WHERE USER_CUID ='" + userCuid + "'";

    super.execSql(sql);
  }

  public DboCollection getCustStrbyUserId(BoActionContext boActionContext, String cuid) throws Exception
  {
    String sql = "SELECT * FROM USER_TO_CUST WHERE USER_CUID ='" + cuid + "'";

    return super.selectDBOs(sql, new GenericDO[] { new UserToCust() });
  }

  public DboCollection getCustStrByUserIdAndCustName(BoActionContext actonContext, String cuid, String searchCustName)
    throws Exception
  {
    String sqlVCust = "";
    String sqlVGCust = "";
    if ((searchCustName != null) || (!"".equals(searchCustName))) {
      sqlVCust = " AND V.LABEL_CN LIKE '%" + searchCustName + "%' ";
      sqlVGCust = " AND VG.LABEL_CN LIKE '%" + searchCustName + "%' ";
    }
    String sql = "SELECT U.* FROM USER_TO_CUST U,VP V WHERE U.CUST_CUID=V.CUID AND U.USER_CUID='" + cuid + "'" + sqlVCust + " UNION SELECT U.* FROM " + "USER_TO_CUST" + " " + "U," + "VP_GROUP" + " VG " + "WHERE U." + "CUST_CUID" + "=VG." + "CUID" + " AND U." + "USER_CUID" + "='" + cuid + "'" + sqlVGCust;

    return super.selectDBOs(sql, new GenericDO[] { new UserToCust() });
  }

  public DataObjectList getUserManageDistrict(BoActionContext boActionContext, String userCuid)
    throws Exception
  {
    String sql = "SELECT USER_CUID,DISTRICT_CUID FROM USER_MANAGE_DISTRICT WHERE USER_CUID ='" + userCuid + "'";

    return super.selectDBOs(sql, new Class[] { String.class, String.class });
  }

  public DboCollection validateRole(BoActionContext actionContext, String userCuid, String nodeName)
    throws Exception
  {
    String sql = "SELECT DISTINCT f.*  FROM FUNCTION_TREE_NODE f,ROLE_CONSIST_OF_FUN_POINT r,USER_HAVE_ROLE u WHERE f.CUID = r.FUNCTION_NODE_CUID and r.ROLE_CUID=u.ROLE_CUID  and u.USER_CUID ='" + userCuid + "'" + " and f.NODE_NAME ='" + nodeName + "'";

    return super.selectDBOs(sql, new GenericDO[] { new FunctionTreeNode() });
  }

  public DboCollection getSubSysUserByPage(BoQueryContext queryContext, String userName, String creatUser)
    throws Exception
  {
    String sql = "select s.* from SYS_USER s where s.CREATE_USER='" + creatUser + "'";

    if ((userName != null) && (!"".equals(userName.trim()))) {
      sql = sql + " and s.USER_NAME like '%" + userName + "%'";
    }
    return super.selectDBOs(queryContext, sql, new GenericDO[] { new SysUser() });
  }

  public UserToTraph addUserToTraph(BoActionContext actionContext, UserToTraph userToTraph)
    throws Exception
  {
    super.createObject(actionContext, userToTraph);
    return userToTraph;
  }

  public SysUser modifySubSysUser(BoActionContext actionContext, SysUser dbo)
    throws Exception
  {
    dbo.clearUnknowAttrs();
    dbo.setManagerDistrictCuid("");
    super.updateObject(actionContext, dbo);
    return dbo;
  }

  public void deleteUserToTraphByUserCuid(BoActionContext actionContext, String userCuid)
    throws Exception
  {
    String sql = "delete from USER_TO_TRAPH where RELATED_SYS_USER_CUID = '" + userCuid + "'";

    super.execSql(sql);
  }

  public void delSubSysUser(BoActionContext actionContext, Long objectId)
    throws Exception
  {
    SysUser dbo = new SysUser();
    dbo.setObjectNum(objectId.longValue());
    super.deleteObject(actionContext, dbo);
  }

  public void deleteUserManagerDistrict(BoActionContext actionContext, String userCuid)
    throws Exception
  {
    String sql = "USER_CUID='" + userCuid + "'";

    super.deleteObjects(actionContext, "USER_MANAGE_DISTRICT", sql);
  }

  public int getSysUserCounts(BoActionContext actionContext) throws Exception
  {
    int count = super.getCalculateValue("select count(*) from SYS_USER");
    return count;
  }

  public void addModuleClickLog(BoActionContext actionContext, ModuleClickLog dbo) throws Exception
  {
    super.createObject(actionContext, dbo);
  }

  public DataObjectList checkFunctionPermissions(String sql) throws Exception {
    DataObjectList dbos = super.selectDBOs(sql, new Class[] { String.class });
    LogHome.getLog().info("用户权限验证====dbos.size==" + dbos.size());
    return dbos;
  }

  public DataObjectList getOrganization(String relatedDistrictCuid) throws Exception {
    DataObjectList dbos = new DataObjectList();
    String sql = "related_district_cuid like '" + relatedDistrictCuid + "%'";
    LogHome.getLog().info("查询用户组信息=======" + sql);
    dbos = super.getObjectsBySql(sql, new Organization(), 0);

    return dbos;
  }
}