package com.boco.transnms.server.dao.user;

import com.boco.common.util.db.DbConnManager;
import com.boco.common.util.db.DbContext;
import com.boco.common.util.db.SqlHelper;
import com.boco.common.util.lang.TimeFormatHelper;
import com.boco.transnms.common.dto.AttempSheetDetail;
import com.boco.transnms.common.dto.ReplySheetDetail;
import com.boco.transnms.common.dto.WfOutline;
import com.boco.transnms.common.dto.WorkflowLog;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.dao.base.AbstractDAO;
import com.boco.transnms.server.dao.base.DaoHelper;

public class WorkflowLogDAO extends AbstractDAO
{
  public static String WF_OUTLINE_ALLFIELD = "A.CUID ,A.IS_ARCHIVED ,A.LABEL_CN ,A.PROCESS_TYPE ,A.RELATED_ATTSHEET_CUID ,A.RELATED_SHEET_CUID ,A.WF_PROCESS_ID ,A.WF_PROCESS_KEY ";

  public WorkflowLogDAO()
  {
    super("WorkflowLogDAO");
  }

  public WorkflowLog addWorkflowLog(BoActionContext actionContext, WorkflowLog workFlowLog)
    throws Exception
  {
    super.createObject(actionContext, workFlowLog);
    return workFlowLog;
  }

  public void modifyWorkflowLog(BoActionContext actionContext, WorkflowLog workFlowLog)
    throws Exception
  {
    super.updateObject(actionContext, workFlowLog);
  }

  public void deleteWorkflowLog(BoActionContext actionContext, WorkflowLog workFlowLog)
    throws Exception
  {
    super.deleteObject(actionContext, workFlowLog);
  }

  public void deleteWorkflowLog(BoActionContext actionContext, Long objectId)
    throws Exception
  {
    GenericDO dbo = new GenericDO();
    dbo.setObjectNum(objectId.longValue());
    super.deleteObject(actionContext, dbo);
  }

  public DboCollection getWorkflowLogByCondition(BoQueryContext actionContext, String operator, String start_intime, String end_intime)
    throws Exception
  {
    String sql = "";
    String sql0 = "SELECT * FROM WORKFLOW_LOG";
    if (operator.length() != 0) {
      sql = "OPERATOR ='" + operator + "' ";
    }
    if (start_intime.length() != 0) {
      if (sql.length() != 0)
        sql = sql + " AND " + "OPERATE_DATE" + " >=" + start_intime + " ";
      else {
        sql = "OPERATE_DATE >=" + start_intime + "";
      }
    }
    if (end_intime.length() != 0) {
      if (sql.length() != 0)
        sql = sql + " AND " + "OPERATE_DATE" + " <=" + end_intime + " ";
      else {
        sql = "OPERATE_DATE <=" + end_intime + " ";
      }
    }
    if (sql.length() != 0) {
      sql = sql0 + " WHERE " + sql;
    }
    else {
      sql = sql0;
    }
    sql = sql + " order by " + "OPERATOR" + "," + "OPERATE_DATE" + " DESC";
    return super.selectDBOs(actionContext, sql, new GenericDO[] { new WorkflowLog() });
  }

  public DboCollection getWorkFlowLogByPage(BoQueryContext queryContext, String operator, String startTime, String endTime, String orderString) throws Exception {
    StringBuffer sql = new StringBuffer("select * from WORKFLOW_LOG where 1=1 ");
    if (DaoHelper.isNotEmpty(operator)) {
      sql.append(" and OPERATOR='" + operator + "'");
    }
    if ((DaoHelper.isNotEmpty(startTime)) && (!DaoHelper.isNotEmpty(endTime))) {
      sql.append(" and OPERATE_DATE >=" + SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(startTime)));
    }
    if ((DaoHelper.isNotEmpty(endTime)) && (!DaoHelper.isNotEmpty(startTime))) {
      sql.append(" and OPERATE_DATE <=" + SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(endTime)));
    }
    if ((DaoHelper.isNotEmpty(startTime)) && (DaoHelper.isNotEmpty(endTime))) {
      sql.append(" and OPERATE_DATE between " + SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(startTime)) + " and " + SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp(endTime)));
    }
    if (DaoHelper.isNotEmpty(orderString)) {
      orderString = " order by " + orderString;
    }
    sql.append(orderString);
    return super.selectDBOs(queryContext, sql.toString(), new GenericDO[] { new WorkflowLog() });
  }

  public DboCollection getWorkflowLogByCondition(BoQueryContext actionContext, String processKey) throws Exception
  {
    String sql = "";
    String sql0 = "SELECT * FROM WORKFLOW_LOG";
    if (processKey.length() != 0) {
      sql = "PROCESS_KEY = '" + processKey + "' ";
    }
    if (sql.length() != 0) {
      sql = sql0 + " WHERE " + sql;
    }
    else {
      sql = sql0;
    }
    sql = sql + " order by " + "OPERATOR" + "," + "OPERATE_DATE" + " DESC";
    return super.selectDBOs(actionContext, sql, new GenericDO[] { new WorkflowLog() });
  }

  public DboCollection getAppWfOutLineByCondition(BoQueryContext actionContext, String sheetCuid)
    throws Exception
  {
    String sql = "";

    sql = sql + "select " + WF_OUTLINE_ALLFIELD;
    sql = sql + "from WF_OUTLINE A ";
    sql = sql + "where A.RELATED_SHEET_CUID = '" + sheetCuid + "'";

    sql = sql + " union ";
    sql = sql + "select " + WF_OUTLINE_ALLFIELD;
    sql = sql + "from WF_OUTLINE A,ATTEMP_SHEET_DETAIL B ";
    sql = sql + "where B.RELATED_APPLY_CUID = '" + sheetCuid + "' and B." + "RELATED_SHEET_CUID" + " = A." + "RELATED_SHEET_CUID";

    sql = sql + " union ";
    sql = sql + "select " + WF_OUTLINE_ALLFIELD;
    sql = sql + "from WF_OUTLINE A,ATTEMP_SHEET_DETAIL B,REPLY_SHEET_DETAIL C ";
    sql = sql + "where B.RELATED_APPLY_CUID = '" + sheetCuid + "' and B." + "RELATED_SHEET_CUID" + " = C." + "RELATED_ATTEMP_CUID" + " and C." + "RELATED_SHEET_CUID" + " = A." + "RELATED_SHEET_CUID";

    return super.selectDBOs(actionContext, sql, new GenericDO[] { new WfOutline() });
  }

  public DboCollection getDgnWfOutLineByCondition(BoQueryContext actionContext, String sheetCuid)
    throws Exception
  {
    String sql = "";

    sql = sql + "select " + WF_OUTLINE_ALLFIELD + " ";
    sql = sql + "from WF_OUTLINE A,ATTEMP_SHEET_DETAIL B ";
    sql = sql + "where B.RELATED_SHEET_CUID = '" + sheetCuid + "' and A." + "RELATED_SHEET_CUID" + " = B." + "RELATED_APPLY_CUID";

    sql = sql + " union ";
    sql = sql + "select " + WF_OUTLINE_ALLFIELD + " ";
    sql = sql + "from WF_OUTLINE A ";
    sql = sql + "where A.RELATED_SHEET_CUID = '" + sheetCuid + "'";

    sql = sql + " union ";
    sql = sql + "select " + WF_OUTLINE_ALLFIELD + " ";
    sql = sql + "from WF_OUTLINE A,REPLY_SHEET_DETAIL B,REPLY_SHEET C ";
    sql = sql + "where B.RELATED_ATTEMP_CUID= '" + sheetCuid + "' and A." + "RELATED_SHEET_CUID" + " = C." + "CUID" + " and B." + "RELATED_SHEET_CUID" + " = C." + "CUID";

    return super.selectDBOs(actionContext, sql, new GenericDO[] { new WfOutline(), new AttempSheetDetail() });
  }

  public DboCollection getRplWfOutLineByCondition(BoQueryContext actionContext, String sheetCuid)
    throws Exception
  {
    String sql = "";

    sql = sql + "select " + WF_OUTLINE_ALLFIELD + " ";
    sql = sql + "from WF_OUTLINE A,REPLY_SHEET_DETAIL B,ATTEMP_SHEET_DETAIL C ";
    sql = sql + "where B.RELATED_SHEET_CUID = '" + sheetCuid + "' and B." + "RELATED_ATTEMP_CUID" + " = C." + "RELATED_SHEET_CUID" + " and C." + "RELATED_APPLY_CUID" + " = A." + "RELATED_SHEET_CUID";
    sql = sql + " union ";

    sql = sql + "select " + WF_OUTLINE_ALLFIELD + " ";
    sql = sql + "from WF_OUTLINE A,REPLY_SHEET_DETAIL B ";
    sql = sql + "where B.RELATED_SHEET_CUID = '" + sheetCuid + "' and B." + "RELATED_ATTEMP_CUID" + " = A." + "RELATED_SHEET_CUID";
    sql = sql + " union ";

    sql = sql + "select " + WF_OUTLINE_ALLFIELD + " ";
    sql = sql + "from WF_OUTLINE A ";
    sql = sql + "where A.RELATED_SHEET_CUID = '" + sheetCuid + "'";

    return super.selectDBOs(actionContext, sql, new GenericDO[] { new WfOutline(), new AttempSheetDetail(), new ReplySheetDetail() });
  }

  public DboCollection getWorkflowLogByProcessKey(BoQueryContext actionContext, String processKeys)
    throws Exception
  {
    String sql = "select * from WORKFLOW_LOG where PROCESS_KEY in (" + processKeys + ") order by " + "OPERATE_DATE" + " desc";
    return super.selectDBOs(actionContext, sql, new GenericDO[] { new WorkflowLog() });
  }

  public WorkflowLog getWorkflowLogByCUid(BoActionContext actionContext, String workflowLogcuid)
    throws Exception
  {
    WorkflowLog workflowLog = new WorkflowLog();
    workflowLog.setCuid(workflowLogcuid);
    return (WorkflowLog)super.getObjByCuid(workflowLog);
  }

  public WorkflowLog getWorkflowLog(BoActionContext actionContext, Long workflowLogid)
    throws Exception
  {
    WorkflowLog workflowLog = new WorkflowLog();
    workflowLog.setObjectNum(workflowLogid.longValue());
    return (WorkflowLog)super.getObject(workflowLog);
  }
}