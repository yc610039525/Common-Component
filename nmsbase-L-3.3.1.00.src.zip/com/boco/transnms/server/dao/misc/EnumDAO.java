package com.boco.transnms.server.dao.misc;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.base.GenericEnumDO;
import com.boco.transnms.common.dto.misc.PublicEnum;
import com.boco.transnms.common.dto.misc.TraphServiceType;
import com.boco.transnms.server.dao.base.AbstractDAO;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.logging.Log;

public class EnumDAO extends AbstractDAO
{
  public DboCollection getEnums(GenericEnumDO dboTemplate)
    throws Exception
  {
    String sql = new StringBuilder().append("select * from ").append(dboTemplate.getClassName()).toString();
    return super.selectDBOs(sql, new GenericDO[] { dboTemplate });
  }

  public void modifyEnums(String sql) throws Exception {
    super.execSql(sql);
  }

  public DboCollection queryTraphServiceType(BoQueryContext queryContext, String orderString) throws UserException, Exception
  {
    String sql = "SELECT * FROM TRAPH_SERVICE_TYPE";
    if (!orderString.trim().equals("")) {
      sql = new StringBuilder().append(sql).append("  order by ").append(orderString).toString();
    }
    return super.selectDBOs(queryContext, sql, new GenericDO[] { new TraphServiceType() });
  }

  public TraphServiceType getTraphServiceTypeByObjectId(BoActionContext queryContext, Long objectId) throws UserException, Exception {
    String sql = new StringBuilder().append("SELECT * FROM TRAPH_SERVICE_TYPE WHERE KEY_NUM=").append(objectId).toString();
    DboCollection dbos = super.selectDBOs(sql, new GenericDO[] { new TraphServiceType() });
    TraphServiceType dbo = null;
    if (dbos.size() == 1) {
      dbo = (TraphServiceType)dbos.getAttrField("TRAPH_SERVICE_TYPE", 0);
    } else {
      LogHome.getLog().error(new StringBuilder().append("查询电路类型错误：").append(sql).toString());
      throw new UserException(new StringBuilder().append("查询电路类型错误：").append(sql).toString());
    }
    return dbo;
  }

  public DboCollection getTraphServiceTypeBySql(BoActionContext queryContext, String sql) throws UserException, Exception {
    DboCollection dbos = super.selectDBOs(sql, new GenericDO[] { new TraphServiceType() });
    return dbos;
  }

  public DboCollection getPortRate(GenericEnumDO dboTemplate) throws Exception {
    String sql = new StringBuilder().append("select * from ").append(dboTemplate.getClassName()).append(" where IS_PTP_VALUE =1 ").toString();
    return super.selectDBOs(sql, new GenericDO[] { dboTemplate });
  }

  public TraphServiceType modifyTraphServiceType(BoActionContext actionContext, TraphServiceType dbo) throws UserException, Exception {
    String querySql = "";
    if (dbo.getKeyValue().trim().equals("")) {
      querySql = new StringBuilder().append("SELECT * FROM TRAPH_SERVICE_TYPE WHERE (KEY_VALUE IS NULL OR KEY_VALUE='') AND KEY_NUM<>").append(dbo.getKeyNum()).toString();
    }
    else {
      querySql = new StringBuilder().append("SELECT * FROM TRAPH_SERVICE_TYPE WHERE KEY_VALUE='").append(dbo.getKeyValue()).append("' AND ").append("KEY_NUM").append("<>").append(dbo.getKeyNum()).toString();
    }

    DboCollection dbos = getTraphServiceTypeBySql(actionContext, querySql);
    if (dbos.size() > 0) {
      LogHome.getLog().error("电路业务类型名称重复！");
      throw new UserException("电路业务类型名称重复！");
    }
    String updateSql = new StringBuilder().append("UPDATE TRAPH_SERVICE_TYPE SET KEY_VALUE='").append(dbo.getKeyValue()).append("',").append("EXT_DESC").append("='").append(dbo.getExtDesc()).append("',").append("COLOR").append("=").append(dbo.getColor()).append(",").append("LABEL_COLOR").append("='").append(dbo.getLabelColor()).append("',").append("IMPORT_LEVEL").append("=").append(dbo.getImportLevel()).append(",").append("IMPORT_TRAPH").append("=").append(dbo.getImportTraph() ? 1 : 0).append(",").append("IS_TD").append("=").append(dbo.getIsTD()).append(" WHERE KEY_NUM=").append(dbo.getKeyNum()).toString();

    super.execSql(actionContext, updateSql);
    return getTraphServiceTypeByObjectId(actionContext, Long.valueOf(dbo.getKeyNum()));
  }

  public TraphServiceType addTraphServiceType(BoActionContext actionContext, TraphServiceType dbo)
    throws UserException, Exception
  {
    String querySql = "";
    if (dbo.getKeyValue().trim().equals(""))
      querySql = "SELECT * FROM TRAPH_SERVICE_TYPE WHERE KEY_VALUE IS NULL OR KEY_VALUE=''";
    else {
      querySql = new StringBuilder().append("SELECT * FROM TRAPH_SERVICE_TYPE WHERE KEY_VALUE='").append(dbo.getKeyValue()).append("'").toString();
    }
    DboCollection dbos = getTraphServiceTypeBySql(actionContext, querySql);
    if (dbos.size() > 0) {
      LogHome.getLog().error("电路业务类型名称重复！");
      throw new UserException("电路业务类型名称重复！");
    }
    String insertSql = new StringBuilder().append("INSERT INTO TRAPH_SERVICE_TYPE(KEY_NUM,KEY_VALUE,EXT_DESC,COLOR,LABEL_COLOR,IMPORT_LEVEL,IMPORT_TRAPH,IS_TD) VALUES(").append(dbo.getKeyNum()).append(",'").append(dbo.getKeyValue()).append("','").append(dbo.getExtDesc()).append("',").append(dbo.getColor()).append(",'").append(dbo.getLabelColor()).append("',").append(dbo.getImportLevel()).append(",").append(dbo.getImportTraph() ? 1 : 0).append(",").append(dbo.getIsTD()).append(")").toString();

    super.execSql(actionContext, insertSql);
    return getTraphServiceTypeByObjectId(actionContext, Long.valueOf(dbo.getKeyNum()));
  }

  public void deleteTraphServiceTypeByKeyNum(BoActionContext actionContext, String keyNum) throws UserException, Exception
  {
    String[] keyNumArr = keyNum.split(",");
    String errorStr = "";
    for (int i = 0; i < keyNumArr.length; i++) {
      Long keyNumTemp = Long.valueOf(keyNumArr[i]);

      String sqlqueryTraph = new StringBuilder().append("SELECT COUNT(*) FROM TRAPH WHERE EXT_IDS LIKE '%,").append(keyNumTemp).append(",%'").toString();
      DataObjectList useTraphListNum = super.selectDBOs(sqlqueryTraph, new Class[] { Integer.TYPE });
      String sqlqueryAttempTraph = new StringBuilder().append("SELECT COUNT(*) FROM ATTEMP_TRAPH WHERE EXT_IDS LIKE '%,").append(keyNumTemp).append(",%'").toString();

      DataObjectList useAttempTraphListNum = super.selectDBOs(sqlqueryAttempTraph, new Class[] { Integer.TYPE });
      int countNum = ((GenericDO)useTraphListNum.get(0)).getAttrInt("1") + ((GenericDO)useAttempTraphListNum.get(0)).getAttrInt("1");
      if (countNum > 0) {
        TraphServiceType traphServiceTypeTemp = getTraphServiceTypeByObjectId(actionContext, keyNumTemp);
        errorStr = new StringBuilder().append(errorStr).append("[").append(traphServiceTypeTemp.getKeyValue()).append(":").append(traphServiceTypeTemp.getExtDesc()).append("],").toString();
      }
    }
    if (errorStr.length() > 0) {
      errorStr = errorStr.substring(0, errorStr.length() - 1);
      LogHome.getLog().error(new StringBuilder().append(errorStr).append("业务类型已经使用，不能删除!").toString());
      throw new UserException(new StringBuilder().append(errorStr).append("业务类型已经使用，不能删除!").toString());
    }
    for (int i = 0; i < keyNumArr.length; i++) {
      Long keyNumTemp = Long.valueOf(keyNumArr[i]);
      String delSql = new StringBuilder().append("DELETE FROM TRAPH_SERVICE_TYPE WHERE KEY_NUM =").append(keyNumTemp).toString();
      super.execSql(actionContext, delSql);
    }
  }

  public DataObjectList getExcelCache(String table, String key, String value, String sqlcondition) throws Exception {
    String sql = new StringBuilder().append("SELECT ").append(key).append(",").append(value).append(" FROM ").append(table).append(" WHERE ").append(key).append(" IN (").append(sqlcondition).append(")").toString();
    return super.selectDBOs(sql, new Class[] { String.class, String.class });
  }

  public void addPublicType(BoActionContext actionContext, String enumName, String keyNum, String keyValue)
    throws Exception
  {
    String sql = new StringBuilder().append("INSERT INTO PUBLIC_ENUM(ENUM_TYPE,KEY_NUM,KEY_VALUE) VALUES ('").append(enumName).append("',").append(keyNum).append(",'").append(keyValue).append("')").toString();
    super.execSql(sql);
  }

  public void modifyPublicType(BoActionContext actionContext, String enumName, String keyNum, String keyValue)
    throws Exception
  {
    String sql = new StringBuilder().append("UPDATE PUBLIC_ENUM SET KEY_VALUE='").append(keyValue).append("' WHERE ").append("ENUM_TYPE").append(" ='").append(enumName).append("' AND ").append("KEY_NUM").append(" = ").append(keyNum).toString();

    super.execSql(sql);
  }

  public DboCollection getPublicTypeByNum(BoActionContext actionContext, String enumName, String keyNum)
    throws Exception
  {
    String sql = new StringBuilder().append("SELECT * FROM PUBLIC_ENUM WHERE ENUM_TYPE ='").append(enumName).append("' AND ").append("KEY_NUM").append(" = ").append(keyNum).toString();

    return super.selectDBOs(sql, new GenericDO[] { new PublicEnum() });
  }

  public DboCollection getPublicTypeByValue(BoActionContext actionContext, String enumName, String keyValue)
    throws Exception
  {
    String sql = new StringBuilder().append("SELECT * FROM PUBLIC_ENUM WHERE ENUM_TYPE ='").append(enumName).append("' AND ").append("KEY_VALUE").append(" = '").append(keyValue).append("'").toString();

    return super.selectDBOs(sql, new GenericDO[] { new PublicEnum() });
  }

  public DataObjectList getEnumTypeByName(BoActionContext actionContext, String enumName)
    throws Exception
  {
    String sql = new StringBuilder().append("SELECT KEY_NUM,KEY_VALUE,ENUM_TYPE FROM PUBLIC_ENUM WHERE ENUM_TYPE ='").append(enumName).append("'").toString();

    return super.selectDBOs(sql, new Class[] { Integer.TYPE, String.class, String.class });
  }

  public List getCessionTypeInfo(BoActionContext actionContext)
    throws Exception
  {
    List list = new ArrayList();
    String sql = "SELECT DISTINCT CESSION_TYPE FROM CESSION_INFO";
    DataObjectList dbosFir = super.selectDBOs(sql, new Class[] { Integer.TYPE });
    sql = "SELECT DISTINCT CESSION_TYPE FROM CESSION_EXP";
    DataObjectList dbosSec = super.selectDBOs(sql, new Class[] { Integer.TYPE });
    sql = "SELECT DISTINCT CESSION_TYPE FROM DATA_EXP";
    DataObjectList dbosThird = super.selectDBOs(sql, new Class[] { Integer.TYPE });
    list.add(dbosFir);
    list.add(dbosSec);
    list.add(dbosThird);
    return list;
  }

  public void delPublicType(BoActionContext actionContext, String enumName, String keyNum)
    throws Exception
  {
    String sql = new StringBuilder().append("DELETE FROM PUBLIC_ENUM WHERE ENUM_TYPE ='").append(enumName).append("' AND ").append("KEY_NUM").append(" = ").append(keyNum).toString();

    super.execSql(sql);
  }
}