package com.boco.transnms.server.dao.topo;

import com.boco.transnms.common.dto.ThemeMap;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.dao.base.AbstractDAO;

public class ThemeMapDAO extends AbstractDAO
{
  public ThemeMapDAO()
  {
    super("ThemeMapDAO");
  }

  public ThemeMap addThemeMap(BoActionContext actionContext, ThemeMap themeMap) throws Exception
  {
    themeMap.clearUnknowAttrs();
    themeMap.convAllObjAttrToCuid();
    super.createObject(actionContext, themeMap);
    return themeMap;
  }

  public void deleteThemeMap(BoActionContext actionContext, ThemeMap themeMap) throws Exception {
    themeMap.clearUnknowAttrs();
    themeMap.convAllObjAttrToCuid();
    super.deleteObject(actionContext, themeMap);
  }

  public DataObjectList getThemeMapByUser(BoActionContext actionContext, String userCuid, Long themeMapType) throws Exception {
    String sql = "CREATE_USER_CUID='" + userCuid + "' and THEME_MAP_TYPE =" + themeMapType;
    return super.getObjectsBySql(sql, new ThemeMap(), 0);
  }

  public ThemeMap getThemeMapByCuid(BoActionContext actionContext, String cuid) throws Exception {
    ThemeMap dbo = new ThemeMap();
    dbo.setCuid(cuid);
    super.getObject(dbo);
    return (ThemeMap)super.getObjByCuid(dbo);
  }

  public DataObjectList getAllThemeMapsByUserCUID(BoActionContext actionContext, String userCuid, Long themeMapType) throws Exception {
    String sql = " CREATE_USER_CUID = '" + userCuid;
    if (themeMapType.longValue() == 1L)
    {
      sql = sql + "' and (THEME_MAP_TYPE = 1 or THEME_MAP_TYPE =3)";
    }
    else sql = sql + "' and THEME_MAP_TYPE =" + themeMapType;

    return super.getObjectsBySql(sql, new ThemeMap(), 0);
  }

  public void modifyThemeMap(BoActionContext actionContext, ThemeMap themeMap) throws Exception
  {
    themeMap.clearUnknowAttrs();
    themeMap.convAllObjAttrToCuid();
    super.updateObject(actionContext, themeMap);
  }

  public void setDefaultThemeMapByUser(BoActionContext actionContext, DataObjectList themeMapList)
    throws Exception
  {
    for (int i = 0; i < themeMapList.size(); i++) {
      ThemeMap tm = (ThemeMap)themeMapList.get(i);
      tm.clearUnknowAttrs();
      tm.convAllObjAttrToCuid();
      super.updateObject(actionContext, tm);
    }
  }

  public ThemeMap getThemeMapByObjectId(BoActionContext actionContext, Long objectId) throws Exception {
    ThemeMap dbo = new ThemeMap();
    dbo.setObjectNum(objectId.longValue());
    return (ThemeMap)super.getObject(dbo);
  }
}