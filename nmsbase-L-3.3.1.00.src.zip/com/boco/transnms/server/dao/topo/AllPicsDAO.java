package com.boco.transnms.server.dao.topo;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.misc.AllPics;
import com.boco.transnms.server.dao.base.AbstractDAO;
import org.apache.commons.logging.Log;

public class AllPicsDAO extends AbstractDAO
{
  public AllPicsDAO()
  {
    super("AllPicsDAO");
  }

  public void addAllPics(BoActionContext actionContext, AllPics obj)
    throws Exception
  {
    try
    {
      super.insertDbo(actionContext, obj);
      if (obj.getPic() != null)
        modifyAllPicsPicField(actionContext, obj);
    }
    catch (Exception ex) {
      LogHome.getLog().info("DAO新增 图形对象对应关系AllPics 出错", ex);
      throw new Exception(ex);
    }
  }

  public void modifyAllPicsPicField(BoActionContext actionContext, AllPics obj)
    throws Exception
  {
    String sql = "";
    try {
      sql = "CUID='" + obj.getCuid() + "'";
      if ((obj.getAssisCuid() != null) && (obj.getAssisCuid().trim().length() > 0)) {
        sql = sql + " and ASSISCUID='" + obj.getAssisCuid() + "'";
      }

      super.updateBlob(actionContext, obj.getClassName(), "PIC", obj.getPic(), sql);
    }
    catch (Exception ex) {
      LogHome.getLog().info("DAO修改 图形对象对应关系AllPics 出错", ex);
      throw new Exception(ex);
    }
  }

  public void deleteAllPics(BoActionContext actionContext, AllPics obj)
    throws Exception
  {
    String sql = "";
    try {
      sql = "delete from " + obj.getClassName() + " where " + "CUID" + "='" + obj.getCuid() + "'";

      if ((obj.getAssisCuid() != null) && (obj.getAssisCuid().trim().length() > 0)) {
        sql = sql + " and ASSISCUID='" + obj.getAssisCuid() + "'";
      }
      super.execSql(sql);
    }
    catch (Exception ex) {
      LogHome.getLog().info("DAO删除 图形对象对应关系AllPics 出错," + sql, ex);
      throw new Exception(ex);
    }
  }

  public AllPics getAllPics(BoActionContext actionContext, AllPics allPics)
    throws Exception
  {
    String sql = "";
    try {
      if (allPics.getCuid() == null) {
        throw new UserException("AllPics查询对象的cuid不能为空！");
      }

      sql = "select *  from " + allPics.getClassName() + " where " + "CUID" + "='" + allPics.getCuid() + "'";

      if ((allPics.getAssisCuid() != null) && (allPics.getAssisCuid().trim().length() > 0)) {
        sql = sql + " and ASSISCUID='" + allPics.getAssisCuid() + "'";
      }
      DboCollection collection = super.selectDBOs(sql, new GenericDO[] { new AllPics() });
      if (collection.size() > 0) {
        return (AllPics)collection.getAttrField("ALLPICS", 0);
      }
      return null;
    }
    catch (Exception ex)
    {
      LogHome.getLog().info("读取 图形对象对应关系AllPics 出错," + sql, ex);
      throw new Exception(ex);
    }
  }

  public DataObjectList getAllPictures(BoActionContext actionContext, AllPics allPics) throws Exception {
    String sql = "";
    try {
      if (allPics.getCuid() == null) {
        throw new UserException("AllPics查询对象的cuid不能为空！");
      }

      sql = "select *  from " + allPics.getClassName() + " where " + "CUID" + "='" + allPics.getCuid() + "'";

      DboCollection collection = super.selectDBOs(sql, new GenericDO[] { new AllPics() });
      DataObjectList list = new DataObjectList();
      for (int i = 0; i < collection.size(); i++) {
        list.add(collection.getAttrField("ALLPICS", i));
      }
      return list;
    }
    catch (Exception ex) {
      LogHome.getLog().info("读取 图形对象对应关系AllPics 出错," + sql, ex);
      throw new Exception(ex);
    }
  }

  public DataObjectList getAllPicturesBySql(BoActionContext actionContext, String sql) throws Exception {
    try {
      DboCollection collection = super.selectDBOs(sql, new GenericDO[] { new AllPics() });
      DataObjectList list = new DataObjectList();
      for (int i = 0; i < collection.size(); i++) {
        list.add(collection.getAttrField("ALLPICS", i));
      }
      return list;
    }
    catch (Exception ex) {
      LogHome.getLog().info("读取 图形对象对应关系AllPics 出错," + sql, ex);
      throw new Exception(ex);
    }
  }

  public DataObjectList getAllSimplePics(BoActionContext actionContext, String sql) throws Exception {
    DataObjectList rstList = new DataObjectList();
    String execSql = "select CUID,OBJECT_TYPE_CODE,ASSISCUID from ALLPICS where 1=1 ";

    if ((sql != null) && (sql.trim().length() > 0)) {
      execSql = execSql + " and " + sql;
    }
    DboCollection collection = super.selectDBOs(execSql, new GenericDO[] { new AllPics() });
    for (int i = 0; i < collection.size(); i++) {
      rstList.add(collection.getQueryDbo(i, "ALLPICS"));
    }
    return rstList;
  }
}