package com.boco.transnms.server.dao.topo;

import com.boco.transnms.common.dto.SystemMap;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.dao.base.GenericDAO;

public class SystemMapDAO extends GenericDAO
{
  public SystemMapDAO()
  {
    super("SystemMapDAO");
  }

  public SystemMap addSystemMap(BoActionContext actionContext, SystemMap systemMap) throws Exception
  {
    systemMap.clearUnknowAttrs();
    systemMap.convAllObjAttrToCuid();
    super.createObject(actionContext, systemMap);
    return systemMap;
  }

  public SystemMap modifySystemMap(BoActionContext actionContext, SystemMap systemMap) throws Exception
  {
    systemMap.clearUnknowAttrs();
    systemMap.convAllObjAttrToCuid();
    super.updateObject(actionContext, systemMap);
    return systemMap;
  }

  public void deleteSystemMap(BoActionContext actionContext, SystemMap systemMap) throws Exception {
    super.deleteObject(actionContext, systemMap);
  }

  public DataObjectList getAllSystemMaps(BoActionContext actionContext) throws Exception {
    return super.getAllObjByClass(new SystemMap(), 0);
  }

  public SystemMap getSystemMapByCuid(BoActionContext actionContext, String systeMapCuid) throws Exception {
    SystemMap sysmap = new SystemMap();
    sysmap.setCuid(systeMapCuid);
    return (SystemMap)super.getObjByCuid(sysmap);
  }

  public DataObjectList getSystemMapByName(BoActionContext actionContext, String mapName) throws Exception
  {
    String sql = "LABEL_CN = '" + mapName + "'";
    return super.getObjectsBySql(sql, new SystemMap(), 0);
  }

  public String getConditionSql(String className, String mapCuid) {
    return " where exists(select 1 from MAP_TO_OBJECT where MAP_TO_OBJECT.OBJECT_CUID=" + className + "." + "CUID" + " and " + "MAP_TO_OBJECT" + "." + "MAP_CUID" + "='" + mapCuid + "')";
  }

  private void selectDBOs(String sql, DataObjectList list, GenericDO dboTemplate)
    throws Exception
  {
    DboCollection dboCollection = super.selectDBOs(sql, new GenericDO[] { dboTemplate });
    putDboCollectionToList(dboCollection, list, dboTemplate.getTableName());
  }

  private void putDboCollectionToList(DboCollection dboCollection, DataObjectList list, String clazzName) throws Exception {
    for (int j = 0; j < dboCollection.size(); j++) {
      GenericDO dbo = dboCollection.getQueryDbo(j, clazzName);
      list.add(dbo);
    }
  }

  public DataObjectList getDefaultSystemMap(BoActionContext context, String DistrictCuid) throws Exception {
    String sql = "RELATED_DISTRICT_CUID='" + DistrictCuid + "'";
    return super.getObjectsBySql(sql, new SystemMap(), 0);
  }
}