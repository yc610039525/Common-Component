package com.boco.transnms.server.dao.topo;

import com.boco.transnms.common.dto.ThemeMapToObject;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.dao.base.DaoHelper;
import com.boco.transnms.server.dao.base.GenericDAO;

public class ThemeMapToObjectDAO extends GenericDAO
{
  public ThemeMapToObjectDAO()
  {
    super("ThemeMapToObjectDAO");
  }

  public ThemeMapToObject addThemeMapToObject(BoActionContext actionContext, ThemeMapToObject themeMapToObject) throws Exception
  {
    ThemeMapToObject tmtoclone = (ThemeMapToObject)themeMapToObject.clone();
    tmtoclone.clearUnknowAttrs();
    tmtoclone.convAllObjAttrToCuid();
    super.createObject(actionContext, tmtoclone);
    return themeMapToObject;
  }

  public DataObjectList addThemeMapToObjects(BoActionContext actionContext, DataObjectList tmtolist) throws Exception {
    DataObjectList tmtolistclone = new DataObjectList();
    for (int i = 0; i < tmtolist.size(); i++) {
      ThemeMapToObject tmto = (ThemeMapToObject)((ThemeMapToObject)tmtolist.get(i)).clone();
      tmto.clearUnknowAttrs();
      tmto.convAllObjAttrToCuid();
      tmtolistclone.add(tmto);
    }
    super.createObjects(actionContext, tmtolistclone);
    return tmtolist;
  }

  public void deleteObjectByThemeMapCuid(BoActionContext actionContext, String themeMapCuid, String objectType)
    throws Exception
  {
    String sql = "THEME_MAP_CUID='" + themeMapCuid + "'" + " and " + "OBJECT_TYPE" + "=" + objectType;

    super.deleteObjects(actionContext, "THEME_MAP_TO_OBJECT", sql);
  }

  public void deleteObjectOnlyByThemeMapCuid(BoActionContext actionContext, String themeMapCuid)
    throws Exception
  {
    String sql = "THEME_MAP_CUID='" + themeMapCuid + "'";
    super.deleteObjects(actionContext, "THEME_MAP_TO_OBJECT", sql);
  }

  public void deleteThemeMapToObjects(BoActionContext actionContext, DataObjectList tmtolist) throws Exception
  {
    super.deleteObjects(actionContext, tmtolist);
  }

  public DataObjectList getByThemeMapAndObjType(BoActionContext actionContext, String themeMapCuid, String objectType)
    throws Exception
  {
    String sql = "";
    if (DaoHelper.isNotEmpty(themeMapCuid)) {
      sql = " and THEME_MAP_CUID='" + themeMapCuid + "'";
    }
    if (DaoHelper.isNotEmpty(objectType)) {
      sql = sql + " and " + "OBJECT_TYPE" + "=" + objectType;
    }
    if (DaoHelper.isNotEmpty(sql)) {
      sql = sql.substring(4, sql.length());
    }

    return super.getObjectsBySql(sql, new ThemeMapToObject(), 0);
  }

  public DataObjectList getObjectsByThemeMapCuid(BoActionContext actionContext, String themeMapCuid) throws Exception {
    String sql = "";
    sql = "THEME_MAP_CUID= '" + themeMapCuid + "'";
    return super.getObjectsBySql(sql, new ThemeMapToObject(), 0);
  }

  public ThemeMapToObject getThemeMapToObjectByCuid(BoActionContext actionContext, String cuid) throws Exception {
    ThemeMapToObject dbo = new ThemeMapToObject();
    dbo.setCuid(cuid);
    return (ThemeMapToObject)super.getObjByCuid(dbo);
  }
}