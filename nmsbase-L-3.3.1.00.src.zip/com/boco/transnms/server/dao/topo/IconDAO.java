package com.boco.transnms.server.dao.topo;

import com.boco.transnms.common.dto.Icon;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.dao.base.AbstractDAO;

public class IconDAO extends AbstractDAO
{
  public Icon getIconByCuid(BoActionContext actionContext, String iconCuid)
    throws Exception
  {
    Icon icon = new Icon();
    icon.setCuid(iconCuid);
    return (Icon)super.getObjByCuid(icon);
  }

  public void modifyIcon(BoActionContext actionContext, Icon icon)
    throws Exception
  {
    icon.clearUnknowAttrs();
    super.updateObject(actionContext, icon);
  }

  public DboCollection getRelationIcon()
    throws Exception
  {
    String sql = " select distinct SYSTEM_LABEL_CN from ICON";
    return super.selectDBOs(sql, new GenericDO[] { new Icon() });
  }

  public DataObjectList getRelationIconAll(Icon icon)
    throws Exception
  {
    String sql = "SYSTEM_LABEL_CN = '" + icon.getSystemLabelCn() + "'";
    return super.getObjectsBySql(sql, new Icon(), 0);
  }

  public DataObjectList getIconSql(BoActionContext actionContext)
    throws Exception
  {
    return super.getAllObjByClass(new Icon(), 0);
  }
}