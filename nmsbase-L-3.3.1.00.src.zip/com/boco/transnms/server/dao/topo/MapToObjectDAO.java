package com.boco.transnms.server.dao.topo;

import com.boco.transnms.common.dto.MapToObject;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.server.dao.base.AbstractDAO;
import java.io.PrintStream;

public class MapToObjectDAO extends AbstractDAO
{
  public MapToObjectDAO()
  {
    super("MapToObjectDAO");
  }

  public MapToObject addMapToObject(BoActionContext actionContext, MapToObject mapToObject) throws Exception {
    super.createObject(actionContext, mapToObject);
    return mapToObject;
  }

  public MapToObject modifyMapToObject(BoActionContext actionContext, MapToObject mapToObject) throws Exception {
    super.updateObject(actionContext, mapToObject);
    return mapToObject;
  }

  public void deleteMapToObject(BoActionContext actionContext, MapToObject mapToObject) throws Exception {
    super.deleteObject(actionContext, mapToObject);
  }

  public DataObjectList getAllMapToObject() throws Exception {
    MapToObject mapToObject = new MapToObject();
    DataObjectList list = super.getAllObjByClass(mapToObject, 0);
    System.out.println("getAllMapToObject=" + list.size());
    return list;
  }
}