package com.boco.transnms.server.dao.base;

public class ChangeRecord
{
  public final ChangeType changeType;
  public final Object value;

  public ChangeRecord(ChangeType changeType, Object value)
  {
    this.changeType = changeType;
    this.value = value;
  }

  public static enum ChangeType
  {
    ADD, UPDATE, UPDATES, UPDATE_ATTRS, DELETE;
  }
}