package com.boco.transnms.server.dao.base;

import com.boco.common.util.debug.LogHome;
import com.boco.raptor.common.message.IMessage;
import com.boco.raptor.common.message.ISimpleMsgListener;
import com.boco.transnms.common.cache.ICacheSyncFilter;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.common.cfg.TnmsServerName;
import org.apache.commons.logging.Log;

public class NmsbaseCacheSyncHandler
  implements ISimpleMsgListener
{
  private ICachedDAO cachedObjectDAO = null;

  public NmsbaseCacheSyncHandler(ICachedDAO cachedObjectDAO) {
    this.cachedObjectDAO = cachedObjectDAO;
  }

  public void notify(IMessage msg) {
    try {
      if ((msg instanceof CachedDtoMessage)) {
        CachedDtoMessage _msg = (CachedDtoMessage)msg;
        String className = _msg.getCacheClassName();
        DataObjectList dbos = new DataObjectList();
        DataObjectList _dbos = _msg.getMsgDtos();

        ICacheSyncFilter filter = TnmsCacheManagerFactory.getInstance().getCacheSyncFilter(className);
        if (filter == null)
          dbos = _dbos;
        else {
          for (GenericDO genericDO : _dbos) {
            if (filter.doFilter(genericDO)) {
              dbos.add(genericDO);
            }
            else if (LogHome.getLog().isDebugEnabled()) {
              String msgbody = ((CachedDtoMessage)msg).getMsgDtos().toString();
              String clientClassName = TnmsServerName.getLocalServerNameStr();
              LogHome.getLog().debug(clientClassName + "收到缓存同步消息，被过滤掉不处理：topicName=" + msg.getTopicName() + ", sourceName=" + msg.getSourceName() + ", msgClassName=" + genericDO.getClassName() + ", msgCuid" + genericDO.getCuid() + ", msgBody=" + msgbody);
            }

          }

        }

        if ((CachedDAOHelper.checkCacheClassName != null) && (CachedDAOHelper.checkCacheClassName.equals(dbos.getElementClassName()))) {
          LogHome.getLog().info("CachedDtoMessage.SourceName=" + _msg.getSourceName());
        }
        if (_msg.getDtoMsgType() == CachedDtoMessage.DTO_MSG_TYPE.CREATE) {
          for (GenericDO dbo : dbos)
            this.cachedObjectDAO.addCacheObject(dbo);
        }
        else if (_msg.getDtoMsgType() == CachedDtoMessage.DTO_MSG_TYPE.UPDATE)
          this.cachedObjectDAO.updateCacheObjects(dbos);
        else if (_msg.getDtoMsgType() == CachedDtoMessage.DTO_MSG_TYPE.DELETE) {
          for (GenericDO dbo : dbos) {
            this.cachedObjectDAO.deleteCacheObject(dbo);
          }
        }
        if (LogHome.getLog().isDebugEnabled()) {
          String msgbody = ((CachedDtoMessage)msg).getMsgDtos().toString();
          String clientClassName = TnmsServerName.getLocalServerNameStr();
          LogHome.getLog().debug(clientClassName + "收到缓存同步消息：topicName=" + msg.getTopicName() + ", sourceName=" + msg.getSourceName() + ", msgClassName=" + dbos.getElementClassName() + ", msgCuids" + dbos.getCuids() + ", msgBody=" + msgbody);
        }
      }

    }
    catch (Exception ex)
    {
      LogHome.getLog().error("缓存消息处理出错：" + ex);
    }
  }
}