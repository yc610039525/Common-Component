package com.boco.transnms.server.dao.base;

import com.boco.common.util.debug.LogHome;
import com.boco.transnms.common.dto.District;
import com.boco.transnms.common.dto.Site;
import com.boco.transnms.common.dto.TransElement;
import com.boco.transnms.server.common.cfg.SystemEnv;
import com.boco.transnms.server.common.cfg.TransNmsCfg;
import java.io.PrintStream;
import org.apache.commons.logging.Log;

public class ImportExportDO
{
  private static void init()
    throws Exception
  {
    String serverHome = SystemEnv.getPathEnv("TNMS_SERVER_HOME");
    String cfgPath = serverHome + "/tnms-conf";
    System.out.println("cfgpath=" + cfgPath);
    TransNmsCfg.loadCfgFile(cfgPath + "/" + "tnmscfg.xml");
    DaoHomeFactory.getInstance().createDaoHome("TRANSNMS_CONTEXT", new String[] { "tnmsdao.xml" });
  }

  private static void ioArea() {
    DaoHelper.importAndExportData(new District());
    DaoHelper.importAndExportData(new Site());
  }

  private static void ioEquip() {
    DaoHelper.importAndExportData(new TransElement());
  }

  public static void main(String[] args) {
    try {
      init();
      ioArea();
      ioEquip();
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }
}