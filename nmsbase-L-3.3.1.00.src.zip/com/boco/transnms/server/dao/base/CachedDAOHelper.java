package com.boco.transnms.server.dao.base;

import com.boco.common.util.debug.LogHome;
import com.boco.transnms.common.dto.base.GenericDO;
import org.apache.commons.logging.Log;

public class CachedDAOHelper
{
  public static String checkCacheClassName = null;

  public static void checkCachedObject(GenericDO dbo) {
    try {
      if ((checkCacheClassName != null) && (checkCacheClassName.equals(dbo.getClassName()))) {
        printStackTrace();
      } else if ((dbo.getClassName() != null) && (dbo.getClassName().equals("GenericDO"))) {
        LogHome.getLog().error("发现错误的缓存对象：" + dbo);
        printStackTrace();
        dbo = dbo.cloneByClassName();
      } else if (DaoHelper.checkObjAttr(dbo)) {
        LogHome.getLog().error("发现错误的缓存对象：" + dbo);
        printStackTrace();
        dbo.convAllObjAttrToCuid();
      }
    } catch (Exception ex) {
      LogHome.getLog().error("核对对象出错：" + ex);
    }
  }

  private static void printStackTrace() {
    try {
      String stackInfo = "";
      StackTraceElement[] stack = Thread.currentThread().getStackTrace();
      for (int i = 0; i < stack.length; i++) {
        StackTraceElement ste = stack[i];
        String[] classNames = ste.getClassName().split("\\.");
        String simpleName = classNames[(classNames.length - 1)];
        stackInfo = stackInfo + simpleName + "." + ste.getMethodName() + "(" + ste.getLineNumber() + ")\r\n";
      }
      LogHome.getLog().error(stackInfo);
    } catch (Exception ex) {
      LogHome.getLog().error("打印堆积信息出错：" + ex);
    }
  }

  public static long getSysMemory()
  {
    long mem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    return mem / 1048576L;
  }
}