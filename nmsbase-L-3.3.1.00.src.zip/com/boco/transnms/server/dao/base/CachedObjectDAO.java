package com.boco.transnms.server.dao.base;

import com.boco.common.util.db.AbstractUserTransaction;
import com.boco.common.util.db.ITranscListener;
import com.boco.common.util.db.TransactionFactory;
import com.boco.common.util.db.UserTransaction;
import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.raptor.cfg.StartUpEnv;
import com.boco.raptor.common.message.MsgBusManager;
import com.boco.transnms.client.model.base.BoCacheCmdProxy;
import com.boco.transnms.client.model.base.BoCacheCmdProxy.DaoActionEnum;
import com.boco.transnms.common.dto.base.AttrObject;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DataObjectManager;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.base.IBoActionContext;
import com.boco.transnms.common.dto.base.IBoQueryContext;
import com.boco.transnms.common.dto.base.IDataObjectListener;
import com.boco.transnms.server.common.cfg.TransNmsCfg;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.commons.logging.Log;

public class CachedObjectDAO extends GenericObjectDAO
  implements ITranscListener, IDataObjectListener, ICachedDAO
{
  public static final String DaoName = "CachedObjectDAO";
  private Map<String, CachedDataObjects> cachedDtoTemplates = new HashMap();
  private Map<Object, List<GenericDO>> dtoTableOfTransc = new ConcurrentHashMap();

  public CachedObjectDAO()
  {
    super("CachedObjectDAO");
    initDAO();
  }

  public CachedObjectDAO(String daoName) {
    super(daoName);
    initDAO();
  }

  protected void initDAO()
  {
    try {
      super.setSupportObjectValid(false);
      if (!"CachedObjectDAO".equals(TransNmsCfg.getInstance().getImplDaoName())) return;

      if (!StartUpEnv.isRunServer()) {
        setImplDaoName("GenericObjectDAO");
        LogHome.getLog().warn("注意：采用客户端模式启动，Cache不能使用，采用GenericObjectDAO ！");
        return;
      }

      if (!TnmsCacheManagerFactory.getInstance().isSyncLoadCache()) {
        Thread loadThread = new Thread("缓存加载线程") {
          public void run() {
            CachedObjectDAO.this._initDAO();
          }
        };
        loadThread.start();
      } else {
        _initDAO();
      }
    } catch (Exception ex) {
      LogHome.getLog().error("CachedObjectDAO初始化错误：", ex);
    }
  }

  protected void _initDAO() {
    long startTime = System.currentTimeMillis();
    long _startTime = startTime;
    long startMemory = getSysMemory();
    long _startMemory = startMemory;
    long cacheSize = 0L;

    setCachedDtoClassNames(TnmsCacheManagerFactory.getInstance().getLocalCache(), TnmsCacheManagerFactory.getInstance().getCacheType());

    LogHome.getLog().info("--------  缓存配置的服务器对象开始, 内存占用=" + startMemory + "M  --------------");

    Iterator it = this.cachedDtoTemplates.values().iterator();
    while (it.hasNext()) {
      try {
        CachedDataObjects cachedDbos = (CachedDataObjects)it.next();
        GenericDO dtoTemplate = cachedDbos.getDboTemplate();
        String cacheType = TnmsCacheManagerFactory.getInstance().getCacheType(dtoTemplate.getClassName());
        LogHome.getLog().info("开始加载对象(" + cacheType + ")：" + dtoTemplate.getClassName());
        boolean isInitCompleted = cachedDbos.initCache();
        if (isInitCompleted) {
          int size = cachedDbos.getCacheSize();
          long endMem = getSysMemory();
          long sumMem = endMem - startMemory;
          LogHome.getLog().info("完成加载对象(" + cacheType + ")：" + dtoTemplate.getClassName() + ", " + size + "个, 内存增加=" + sumMem + "M, 耗时=" + (System.currentTimeMillis() - startTime) / 1000L + "秒");

          cacheSize += size;
          startMemory = endMem;
          startTime = System.currentTimeMillis();
        } else {
          LogHome.getLog().info("未完成加载对象(" + cacheType + ")：dbClassName=" + dtoTemplate.getClassName() + ", 等待COMMON 服务器完成加载 !");
        }
      } catch (Exception ex) {
        LogHome.getLog().error("", ex);
      }
    }
    try
    {
      long endMem = getSysMemory();
      LogHome.getLog().info("--------  缓存配置的服务器对象完成，内存占用=" + endMem + "M, 内存增加=" + (endMem - _startMemory) + "M, 缓存对象总计=" + cacheSize + ", 耗时总计=" + (System.currentTimeMillis() - _startTime) / 1000L);

      DataObjectManager.getInstance().addListener(this);
      if (!StartUpEnv.isAllInOneServer())
      {
        MsgBusManager.getInstance().addMsgListener(MsgBusManager.getInstance().getServerCacheSyncMsgDestName(), "", new NmsbaseCacheSyncHandler(this));
      }

      String contextName = MsgBusManager.getInstance().getCacheAdminMsgDestName();
      MsgBusManager.getInstance().addMsgListener(contextName, "", new CacheAdminHandler(this.cachedDtoTemplates));
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
      throw new UserException("事件消息总线MQ没有启动 ！");
    }
  }

  private int checkCacheState()
  {
    int incompletedCount = 0;
    Iterator it = this.cachedDtoTemplates.values().iterator();
    while (it.hasNext()) {
      CachedDataObjects cachedDbos = (CachedDataObjects)it.next();
      if (!cachedDbos.isInitCompleted()) {
        cachedDbos.checkCacheState();
        incompletedCount++;
      }
    }
    return incompletedCount;
  }

  public void reloadCache(String className, Timestamp lastSyncTime) {
    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(className);
    if (cachedDbos != null)
      try {
        LogHome.getLog().warn("重新缓存同步开始, dbClassName=" + className + ",lastSyncTime=" + lastSyncTime);
        cachedDbos.loadData(true, lastSyncTime);
        LogHome.getLog().warn("重新缓存同步结束, dbClassName=" + className + ",lastSyncTime=" + lastSyncTime + ", cacheSize=" + cachedDbos.getCacheSize());
      }
      catch (Exception e) {
        LogHome.getLog().error("重新同步缓存失败：" + className, e);
      }
  }

  public void deleteCachedObjedts(DataObjectList dbos)
  {
    for (GenericDO dbo : dbos)
      deleteCacheObject(dbo);
  }

  private void reloadCache()
  {
    Iterator it = this.cachedDtoTemplates.values().iterator();
    while (it.hasNext()) {
      CachedDataObjects cachedDbos = (CachedDataObjects)it.next();
      if (!cachedDbos.isInitCompleted())
        try {
          String dbClassName = cachedDbos.getDboTemplate().getClassName();
          LogHome.getLog().warn("共享缓存被动同步超时，强制加载, dbClassName=" + dbClassName + ", cacheSize=" + cachedDbos.getCacheSize());

          cachedDbos.loadData(true);
          cachedDbos.setInitCompleted(true);
          LogHome.getLog().warn("共享缓存被动同步超时，加载完毕, dbClassName=" + dbClassName + ", cacheSize=" + cachedDbos.getCacheSize());
        }
        catch (Exception ex) {
          LogHome.getLog().error("", ex);
        }
    }
  }

  private static long getSysMemory()
  {
    long mem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    return mem / 1048576L;
  }

  public void notifyChange(AttrObject oldDbo, AttrObject newDbo) {
    GenericDO updatedDbo = (GenericDO)oldDbo;

    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(updatedDbo.getClassName());
    if (cachedDbos != null)
      cachedDbos.syncObjectRefs((GenericDO)oldDbo, (GenericDO)newDbo);
  }

  public synchronized void setCachedDtoClassNames(List<String> cachedDtoClassNames, String cacheType)
  {
    try {
      for (String className : cachedDtoClassNames) {
        GenericDO dbo = new GenericDO(className);
        GenericDO dboTemplate = dbo.createInstanceByClassName();
        putCacheTemplate(dboTemplate.getClassName(), new CachedDataObjects(dboTemplate, cacheType, this));
      }
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }

  public synchronized void putCacheTemplate(String key, Object value) {
    synchronized (this.cachedDtoTemplates) {
      this.cachedDtoTemplates.put(key, (CachedDataObjects)value);
    }
  }

  public void createObject(IBoActionContext actionContext, GenericDO dbo) throws Exception
  {
    createObject(actionContext, dbo, false);
  }

  public void createObject(IBoActionContext actionContext, GenericDO dbo, boolean isClear) throws Exception
  {
    super.createObject(actionContext, dbo, isClear);
    addCacheObject(dbo);
    notifyCacheSync(CachedDtoMessage.DTO_MSG_TYPE.CREATE, dbo);
  }

  public void createObjects(IBoActionContext actionContext, DataObjectList dbos) throws Exception
  {
    super.createObjects(actionContext, dbos);
    for (GenericDO dbo : dbos) {
      addCacheObject(dbo);
    }
    notifyCacheSync(CachedDtoMessage.DTO_MSG_TYPE.CREATE, dbos);
  }

  public void updateObject(IBoActionContext actionContext, GenericDO dbo) throws Exception
  {
    super.updateObject(actionContext, dbo);
    updateCacheObject(dbo);
    notifyCacheSync(CachedDtoMessage.DTO_MSG_TYPE.UPDATE, dbo);
  }

  public void updateObjects(IBoActionContext actionContext, DataObjectList dbos, Map attrs, boolean byCuidOrObjectId) throws Exception
  {
    super.updateObjects(actionContext, dbos, attrs, byCuidOrObjectId);
    if (!byCuidOrObjectId)
      updateCacheObjects(dbos.getElementClassName(), dbos.getIdList(), attrs, false);
    else {
      updateCacheObjectsByCuids(dbos.getElementClassName(), dbos.getCuidList(), attrs, false);
    }
    notifyCacheUpdateByAttrs(actionContext, dbos, byCuidOrObjectId);
  }

  public void updateObjects(IBoActionContext actionContext, DataObjectList dbos, Map attrs) throws Exception
  {
    super.updateObjects(actionContext, dbos, attrs);
    updateCacheObjects(dbos.getElementClassName(), dbos.getIdList(), attrs, false);
    notifyCacheUpdateByAttrs(actionContext, dbos, false);
  }

  public void updateObjects(IBoActionContext actionContext, String className, String sql, Map attrs) throws Exception
  {
    super.updateObjects(actionContext, className, sql, attrs);
    DataObjectList dbos = getCachedObjectsBySql(className, sql);
    updateCacheObjects(dbos);
    if ((dbos != null) && (dbos.size() > 0))
      notifyCacheSync(CachedDtoMessage.DTO_MSG_TYPE.UPDATE, dbos);
    else
      notifyCacheUpdateBySql(actionContext, className, sql);
  }

  public void deleteObject(IBoActionContext actionContext, GenericDO dbo)
    throws Exception
  {
    super.deleteObject(actionContext, dbo);
    deleteCacheObject(dbo);
    notifyCacheSync(CachedDtoMessage.DTO_MSG_TYPE.DELETE, dbo);
  }

  public void deleteObjects(IBoActionContext actionContext, List ids) throws Exception
  {
    super.deleteObjects(actionContext, ids);
    DataObjectList dbos = new DataObjectList();
    for (int i = 0; i < ids.size(); i++) {
      Object obj = ids.get(i);
      GenericDO dbo = new GenericDO();
      if ((obj instanceof String))
        dbo.setCuid((String)obj);
      else if ((obj instanceof Long)) {
        dbo.setObjectNum(((Long)obj).longValue());
      }
      dbos.add(dbo);
    }
    for (GenericDO dbo : dbos) {
      deleteCacheObject(dbo);
    }
    notifyCacheSync(CachedDtoMessage.DTO_MSG_TYPE.DELETE, dbos);
  }

  public void deleteObjects(IBoActionContext actionContext, DataObjectList dbos) throws Exception
  {
    super.deleteObjects(actionContext, dbos);
    for (GenericDO dbo : dbos) {
      deleteCacheObject(dbo);
    }
    notifyCacheSync(CachedDtoMessage.DTO_MSG_TYPE.DELETE, dbos);
  }

  public void deleteObjects(IBoActionContext actionContext, DataObjectList dbos, boolean byCuidOrObjectId) throws Exception
  {
    super.deleteObjects(actionContext, dbos, byCuidOrObjectId);
    for (GenericDO dbo : dbos) {
      deleteCacheObject(dbo);
    }
    notifyCacheSync(CachedDtoMessage.DTO_MSG_TYPE.DELETE, dbos);
  }

  public void deleteObjects(IBoActionContext actionContext, String className, String sql) throws Exception
  {
    DataObjectList dbos = getCachedObjectsBySql(className, sql);
    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(className);
    try {
      if (cachedDbos != null)
        super.deleteObjects(actionContext, dbos);
      else
        super.deleteObjects(actionContext, className, sql);
    }
    catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
    for (GenericDO dbo : dbos)
      deleteCacheObject(dbo);
  }

  public void deleteAll(IBoActionContext actionContext, String className)
    throws Exception
  {
    super.deleteAll(actionContext, className);
    deleteAllCacheObject(className);
  }

  private DataObjectList getCachedObjectsBySql(String className, String sql) {
    DataObjectList dbos = new DataObjectList();
    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(className);
    try {
      if (cachedDbos != null)
        dbos = super.getObjectsBySql(sql, cachedDbos.getDboTemplate(), 0);
    }
    catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
    return dbos;
  }

  public DataObjectList getObjByAttrs(IBoQueryContext context, GenericDO dboTemplate) throws Exception
  {
    DataObjectList dbos = new DataObjectList();
    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(dboTemplate.getClassName());
    if ((cachedDbos != null) && (cachedDbos.isInitCompleted()))
      dbos = cachedDbos.getObjByAttrs(dboTemplate);
    else {
      dbos = super.getObjByAttrs(context, dboTemplate);
    }
    return dbos;
  }

  public GenericDO getAttrObj(GenericDO dbo) throws Exception
  {
    GenericDO result = null;
    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(dbo.getClassName());
    if ((cachedDbos != null) && (cachedDbos.isInitCompleted()))
      result = cachedDbos.getObject(dbo.getObjectNum());
    else {
      result = super.getAttrObj(dbo);
    }
    return result;
  }

  public DataObjectList getAttrObjs(long[] objectIds, GenericDO dboTemplate) throws Exception
  {
    DataObjectList result = null;
    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(dboTemplate.getClassName());
    if ((cachedDbos != null) && (cachedDbos.isInitCompleted()))
      result = cachedDbos.getObjects(objectIds);
    else {
      result = super.getAttrObjs(objectIds, dboTemplate);
    }
    return result;
  }

  public GenericDO getObjByCuid(GenericDO dbo) throws Exception
  {
    GenericDO result = null;

    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(dbo.getClassName());
    if ((cachedDbos != null) && (cachedDbos.isInitCompleted())) {
      result = cachedDbos.getObjectByCuid(dbo.getCuid());

      UserTransaction transc = getTransaction();
      if ((transc != null) && (result == null))
        result = super.getObjByCuid(dbo);
    }
    else {
      result = super.getObjByCuid(dbo);
    }

    return result;
  }

  public GenericDO getObjByCuid(IBoActionContext actionContext, GenericDO dbo) throws Exception
  {
    GenericDO result = null;

    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(dbo.getClassName());
    if ((cachedDbos != null) && (cachedDbos.isInitCompleted())) {
      result = cachedDbos.getObjectByCuid(dbo.getCuid());

      UserTransaction transc = getTransaction();
      if ((transc != null) && (result == null))
        result = super.getObjByCuid(actionContext, dbo);
    }
    else {
      result = super.getObjByCuid(actionContext, dbo);
    }

    return result;
  }

  public DataObjectList getObjsByCuids(List<String> cuids, GenericDO dboTemplate) throws Exception
  {
    DataObjectList result = null;
    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(dboTemplate.getClassName());
    if ((cachedDbos != null) && (cachedDbos.isInitCompleted()))
      result = cachedDbos.getObjectByCuids(cuids);
    else {
      result = super.getObjsByCuids(cuids, dboTemplate);
    }
    return result;
  }

  public GenericDO getSimpleObject(GenericDO dbo) throws Exception
  {
    GenericDO result = null;
    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(dbo.getClassName());
    if ((cachedDbos != null) && (cachedDbos.isInitCompleted()))
      result = cachedDbos.getObject(dbo.getObjectNum());
    else {
      result = super.getSimpleObject(dbo);
    }
    return result;
  }

  public GenericDO getObject(GenericDO dbo) throws Exception
  {
    GenericDO result = null;
    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(dbo.getClassName());
    if ((cachedDbos != null) && (cachedDbos.isInitCompleted())) {
      result = cachedDbos.getObject(dbo.getObjectNum());
      UserTransaction transc = getTransaction();
      if ((transc != null) && (result == null))
        result = super.getObject(dbo);
    }
    else {
      result = super.getObject(dbo);
    }
    return result;
  }

  public DataObjectList getObjects(long[] objectIds, GenericDO dboTemplate) throws Exception
  {
    DataObjectList result = null;
    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(dboTemplate.getClassName());
    if ((cachedDbos != null) && (cachedDbos.isInitCompleted()))
      result = cachedDbos.getObjects(objectIds);
    else {
      result = super.getObjects(objectIds, dboTemplate);
    }
    return result;
  }

  public DataObjectList getAllObjByClass(GenericDO dboTemplate, int objGetType) throws Exception
  {
    DataObjectList result = null;
    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(dboTemplate.getClassName());
    if ((cachedDbos != null) && (cachedDbos.isInitCompleted()))
      result = cachedDbos.getAllObjByClass();
    else {
      result = super.getAllObjByClass(dboTemplate, objGetType);
    }
    return result;
  }

  public synchronized void addCacheObject(GenericDO dbo)
  {
    if (this.cachedDtoTemplates.containsKey(dbo.getClassName())) {
      UserTransaction transc = getTransaction();
      if (transc == null)
        addCacheObjectNonTransc(dbo);
      else
        addTransaction(transc, dbo, 1);
    }
  }

  protected boolean addCacheObjectNonTransc(GenericDO dbo)
  {
    boolean isAdded = false;
    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(dbo.getClassName());
    if (cachedDbos != null) {
      isAdded = cachedDbos.addObject(dbo, false);
    }
    return isAdded;
  }

  public void updateCacheObject(GenericDO dbo) {
    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(dbo.getClassName());
    if (cachedDbos != null) {
      UserTransaction transc = getTransaction();
      if (transc == null)
        cachedDbos.updateObject(dbo);
      else
        addTransaction(transc, dbo, 2);
    }
  }

  public void updateCacheObjects(DataObjectList dbos)
  {
    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(dbos.getElementClassName());
    if (cachedDbos != null) {
      UserTransaction transc = getTransaction();
      if (transc == null)
        cachedDbos.updateObjects(dbos);
      else
        addTransactions(transc, dbos, 2);
    }
  }

  private void updateCacheObjectsByCuids(String className, List<String> cuids, Map attrs, boolean isGetFromDb)
  {
    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(className);
    UserTransaction transc;
    if (cachedDbos != null) {
      transc = getTransaction();
      if (transc == null) {
        cachedDbos.updateObjectsByCuids(cuids, attrs);
      } else {
        DataObjectList dbos = cachedDbos.getObjectByCuids(cuids);
        for (GenericDO dbo : dbos) {
          GenericDO cloneDbo = (GenericDO)dbo.deepClone();
          cloneDbo.setReadable(false);
          cloneDbo.setAttrValues(attrs);
          addTransaction(transc, cloneDbo, 2);
        }
      }
    }
  }

  private void updateCacheObjects(String className, List<Long> objectIds, Map attrs, boolean isGetFromDb) {
    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(className);
    UserTransaction transc;
    if (cachedDbos != null) {
      transc = getTransaction();
      if (transc == null) {
        cachedDbos.updateObjects(objectIds, attrs);
      } else {
        DataObjectList dbos = cachedDbos.getObjects(objectIds);
        for (GenericDO dbo : dbos) {
          GenericDO cloneDbo = (GenericDO)dbo.deepClone();
          cloneDbo.setReadable(false);
          cloneDbo.setAttrValues(attrs);
          addTransaction(transc, cloneDbo, 2);
        }
      }
    }
  }

  protected boolean updateCacheObjectNonTransc(GenericDO dbo) {
    boolean isUpdated = false;
    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(dbo.getClassName());
    if (cachedDbos != null) {
      isUpdated = cachedDbos.updateObject(dbo);
    }
    return isUpdated;
  }

  public void deleteCacheObject(GenericDO dbo) {
    if (this.cachedDtoTemplates.containsKey(dbo.getClassName())) {
      UserTransaction transc = getTransaction();
      if (transc == null)
        deleteCacheObjectNonTransc(dbo);
      else
        addTransaction(transc, dbo, 3);
    }
  }

  protected boolean deleteCacheObjectNonTransc(GenericDO dbo)
  {
    boolean isDeleted = false;
    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(dbo.getClassName());
    if (cachedDbos != null) {
      isDeleted = cachedDbos.deleteObject(dbo);
    }
    return isDeleted;
  }

  private void deleteAllCacheObject(String className) {
    CachedDataObjects cachedDbos = (CachedDataObjects)this.cachedDtoTemplates.get(className);
    if (cachedDbos != null)
      cachedDbos.clearAll();
  }

  public void addCacheObjectWithSync(GenericDO dbo)
  {
    addCacheObject(dbo);
    notifyCacheSync(CachedDtoMessage.DTO_MSG_TYPE.CREATE, dbo);
  }

  public void updateCacheObjectWithSync(GenericDO dbo) {
    updateCacheObject(dbo);
    notifyCacheSync(CachedDtoMessage.DTO_MSG_TYPE.UPDATE, dbo);
  }

  public void deleteCacheObjectWithSync(GenericDO dbo) {
    deleteCacheObject(dbo);
    notifyCacheSync(CachedDtoMessage.DTO_MSG_TYPE.DELETE, dbo);
  }

  private void addTransaction(UserTransaction transc, GenericDO dbo, int operType) {
    addDboOperType(dbo, operType);
    List dbos = (List)this.dtoTableOfTransc.get(transc);
    if (dbos == null) {
      ((AbstractUserTransaction)transc).addTranscListener(this);
      dbos = new ArrayList();
      this.dtoTableOfTransc.put(transc, dbos);
    }
    dbos.add(dbo);
  }

  private void addTransactions(UserTransaction transc, DataObjectList dbos, int operType) {
    for (GenericDO dbo : dbos)
      addTransaction(transc, dbo, operType);
  }

  public void doTranscBegin(UserTransaction transc)
  {
  }

  public void doTranscCommit(UserTransaction transc) {
    List dbos = (List)this.dtoTableOfTransc.remove(transc);
    if (dbos != null)
      for (GenericDO dbo : dbos) {
        int operType = removeDboOperType(dbo);
        switch (operType) {
        case 1:
          addCacheObjectNonTransc(dbo);
          break;
        case 2:
          updateCacheObjectNonTransc(dbo);
          break;
        case 3:
          deleteCacheObjectNonTransc(dbo);
          break;
        default:
          LogHome.getLog().error("未知操作类型：" + operType);
        }
      }
  }

  public void doTranscRollback(UserTransaction transc)
  {
    this.dtoTableOfTransc.remove(transc);
  }

  private void addDboOperType(GenericDO dbo, int operType) {
    dbo.setAttrValue("CACHED_OPER_TYPE", operType);
  }

  private int removeDboOperType(GenericDO dbo) {
    int operType = dbo.getAttrInt("CACHED_OPER_TYPE");
    return operType;
  }

  public UserTransaction getTransaction() {
    UserTransaction transc = TransactionFactory.getInstance().getTransaction();
    return (transc != null) && (transc.isBeginTransc()) ? transc : null;
  }

  private void notifyCacheUpdateBySql(IBoActionContext actionContext, String className, String sql)
  {
    if ((TnmsCacheManagerFactory.getInstance().isServerSyncCacheClass(className)) || (TnmsCacheManagerFactory.getInstance().isNotifyOnlyClass(className)))
    {
      DataObjectList dbos = new DataObjectList();
      try {
        GenericDO dbo = new GenericDO(className);
        dbo = dbo.createInstanceByClassName();
        dbos = super.getObjectsBySql(actionContext, sql, dbo, 0);
        notifyCacheSync(CachedDtoMessage.DTO_MSG_TYPE.UPDATE, dbos);
      } catch (Exception ex) {
        LogHome.getLog().error("", ex);
      }
    }
  }

  private void notifyCacheUpdateByAttrs(IBoActionContext actionContext, DataObjectList dbos, boolean byCuidOrObjectId) {
    String dbClassName = dbos.getElementClassName();
    if ((TnmsCacheManagerFactory.getInstance().isServerSyncCacheClass(dbClassName)) || (TnmsCacheManagerFactory.getInstance().isNotifyOnlyClass(dbClassName)))
      try
      {
        DataObjectList _dbos = new DataObjectList();
        GenericDO dbo = new GenericDO();
        dbo.setClassName(dbClassName);
        if (byCuidOrObjectId)
          _dbos = getObjsByCuids(dbos.getCuidList(), (GenericDO)dbos.get(0));
        else {
          _dbos = getObjects(dbos.getIds(), (GenericDO)dbos.get(0));
        }
        notifyCacheSync(CachedDtoMessage.DTO_MSG_TYPE.UPDATE, _dbos);
      } catch (Exception ex) {
        LogHome.getLog().error("", ex);
      }
  }

  private void notifyCacheSync(CachedDtoMessage.DTO_MSG_TYPE msgType, Object data)
  {
    String dbClassName = "";
    if ((data instanceof DataObjectList)) {
      DataObjectList dbos = (DataObjectList)data;
      dbClassName = dbos.getElementClassName();
      if (TnmsCacheManagerFactory.getInstance().isClientSyncCacheClass(dbClassName)) {
        DaoHelper.getInstance().notifyClientCacheChanges(msgType, dbos);
      }
      if (TnmsCacheManagerFactory.getInstance().isServerSyncCacheClass(dbClassName)) {
        DaoHelper.getInstance().notifyServerCacheChanges(msgType, dbos);
      }
      if (TnmsCacheManagerFactory.getInstance().isNotifyOnlyClass(dbClassName)) {
        DaoHelper.getInstance().notifySpecObjectChanges(msgType, dbos);
      }

    }
    else if ((data instanceof GenericDO)) {
      GenericDO dbo = (GenericDO)data;
      dbClassName = dbo.getClassName();
      if (TnmsCacheManagerFactory.getInstance().isServerSyncCacheClass(dbClassName)) {
        DaoHelper.getInstance().notifyServerCacheChange(msgType, dbo);
      }
      if (TnmsCacheManagerFactory.getInstance().isNotifyOnlyClass(dbClassName)) {
        DaoHelper.getInstance().notifySpecObjectChange(msgType, dbo);
      }
      if (TnmsCacheManagerFactory.getInstance().isClientSyncCacheClass(dbClassName)) {
        DaoHelper.getInstance().notifyClientCacheChange(msgType, dbo);
      }

    }

    if (msgType == CachedDtoMessage.DTO_MSG_TYPE.CREATE)
      BoCacheCmdProxy.getInstance().notifyDtoChange(dbClassName, BoCacheCmdProxy.DaoActionEnum.ADD);
    else if (msgType == CachedDtoMessage.DTO_MSG_TYPE.UPDATE)
      BoCacheCmdProxy.getInstance().notifyDtoChange(dbClassName, BoCacheCmdProxy.DaoActionEnum.MODIFY);
    else if (msgType == CachedDtoMessage.DTO_MSG_TYPE.DELETE)
      BoCacheCmdProxy.getInstance().notifyDtoChange(dbClassName, BoCacheCmdProxy.DaoActionEnum.DELETE);
  }

  public static class OPER_TYPE
  {
    public static final int ADD = 1;
    public static final int UPDATE = 2;
    public static final int DELETE = 3;
  }
}