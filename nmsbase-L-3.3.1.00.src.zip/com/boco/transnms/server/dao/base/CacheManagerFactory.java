package com.boco.transnms.server.dao.base;

import com.boco.common.util.debug.LogHome;
import java.util.HashMap;
import org.apache.commons.logging.Log;

public class CacheManagerFactory
{
  private String implName = "";
  private String cacheType = "MC";
  private HashMap<String, String> servers = new HashMap();
  private static IntegratedCacheManager cm = null;
  private static CacheManagerFactory instance = new CacheManagerFactory();

  public static CacheManagerFactory getInstance()
  {
    return instance;
  }

  public IntegratedCacheManager getCacheManager() {
    if (cm == null) {
      try {
        cm = (IntegratedCacheManager)Class.forName(this.implName).newInstance();
        cm.setServers(this.servers);
        if (this.implName.toUpperCase().contains("MEMCACHED"))
          this.cacheType = "MC";
        else if (this.implName.toUpperCase().contains("REDIS"))
          this.cacheType = "REDIS";
      }
      catch (Exception e) {
        LogHome.getLog().error("获取CacheManager失败", e);
      }
    }
    return cm;
  }

  public String getImplName() {
    return this.implName;
  }

  public void setImplName(String implName) {
    this.implName = implName;
  }

  public String getCacheType() {
    return this.cacheType;
  }

  public void setCacheType(String cacheType) {
    this.cacheType = cacheType;
  }

  public HashMap<String, String> getServers() {
    return this.servers;
  }

  public void setServers(HashMap<String, String> servers) {
    this.servers = servers;
  }
}