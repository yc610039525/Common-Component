package com.boco.transnms.server.dao.base;

import com.boco.common.util.debug.LogHome;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.apache.commons.logging.Log;

public class RefreshKVCacheThread extends Thread
{
  private Map<String, CachedKVs> cachedKVs = new HashMap();

  public RefreshKVCacheThread(Map<String, CachedKVs> _cachedKVs) {
    super("KV缓存刷新线程");
    this.cachedKVs = _cachedKVs;
  }

  public void run() {
    while (true)
      try {
        LogHome.getLog().info("刷新KV缓存开始");
        Iterator iterator = this.cachedKVs.keySet().iterator();
        if (iterator.hasNext()) {
          String key = (String)iterator.next();
          CachedKVs kv = (CachedKVs)this.cachedKVs.get(key);
          kv.initCache(true);
        } else {
          LogHome.getLog().info("刷新KV缓存结束");
        }
      } catch (Exception ex) { LogHome.getLog().error("", ex);
      } finally {
        try {
          sleep(3600000L);
        }
        catch (Exception ex)
        {
        }
      }
  }
}