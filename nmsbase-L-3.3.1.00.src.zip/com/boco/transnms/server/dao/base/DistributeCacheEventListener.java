package com.boco.transnms.server.dao.base;

import com.boco.common.util.debug.LogHome;
import com.boco.plugins.ehcache.EcacheManager;
import net.sf.ehcache.CacheException;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;
import net.sf.ehcache.event.CacheEventListener;
import org.apache.commons.logging.Log;

public class DistributeCacheEventListener
  implements CacheEventListener
{
  public void dispose()
  {
  }

  public void notifyElementEvicted(Ehcache ehcache, Element element)
  {
  }

  public void notifyElementExpired(Ehcache ehcache, Element element)
  {
  }

  public void notifyElementPut(Ehcache ehcache, Element element)
    throws CacheException
  {
    Ehcache localCache = EcacheManager.getInstance().getCache(ehcache.getName());
    if ((!ehcache.getGuid().equals(localCache.getGuid())) && 
      (ehcache.getName().contains("_OID_CACHE")))
      LogHome.getLog().debug("缓存同步，增加对象， elementKey=" + element.getKey() + ",elementValue" + element.getValue().toString());
  }

  public void notifyElementRemoved(Ehcache ehcache, Element element)
    throws CacheException
  {
    Ehcache localCache = EcacheManager.getInstance().getCache(ehcache.getName());
    if ((!ehcache.getGuid().equals(localCache.getGuid())) && 
      (ehcache.getName().contains("_OID_CACHE")))
      LogHome.getLog().debug("缓存同步，删除对象， elementKey=" + element.getKey() + ",elementValue" + element.getValue().toString());
  }

  public void notifyElementUpdated(Ehcache ehcache, Element element)
    throws CacheException
  {
    Ehcache localCache = EcacheManager.getInstance().getCache(ehcache.getName());
    if ((!ehcache.getGuid().equals(localCache.getGuid())) && 
      (ehcache.getName().contains("_OID_CACHE")))
      LogHome.getLog().debug("缓存同步，更新对象， elementKey=" + element.getKey() + ",elementValue" + element.getValue().toString());
  }

  public void notifyRemoveAll(Ehcache ehcache)
  {
  }

  public Object clone()
    throws CloneNotSupportedException
  {
    return super.clone();
  }
}