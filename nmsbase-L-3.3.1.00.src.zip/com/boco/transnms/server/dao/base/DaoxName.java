package com.boco.transnms.server.dao.base;

public class DaoxName
{
  public static final String OdfPortDAOX = "PhyOdfPortDAOX";
  public static final String LabelModelDAOX = "LabelModelDAOX";
  public static final String PhyOdmDAOX = "PhyOdmDAOX";
  public static final String PhyOdfportDAOX = "PhyOdfportDAOX";
  public static final String JumpFiberDAOX = "JumpFiberDAOX";
  public static final String MiscrackDAOX = "MiscrackDAOX";
  public static final String PhyOdfDAOX = "PhyOdfDAOX";
  public static final String CardDAOX = "CardDAOX";
  public static final String JumpPairDAOX = "JumpPairDAOX";
}