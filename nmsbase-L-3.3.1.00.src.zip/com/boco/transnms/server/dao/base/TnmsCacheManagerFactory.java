package com.boco.transnms.server.dao.base;

import com.boco.common.util.debug.LogHome;
import com.boco.transnms.common.cache.ICacheLoader;
import com.boco.transnms.common.cache.ICacheSyncFilter;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.common.cfg.TnmsServerName;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.logging.Log;

public class TnmsCacheManagerFactory
{
  private static TnmsCacheManagerFactory instance = new TnmsCacheManagerFactory();

  private Map<String, String> allCacheClassNames = new HashMap();
  private Map<String, String> allNotifyOnlyClassNames = new HashMap();
  private Map<String, String> localCacheClassNames = new HashMap();
  private Map<String, String> allNotifyClientClassNames = new HashMap();
  private boolean isLocalShareCacheInited = false;
  private Map<String, CacheManager> cacheManagers = new HashMap();
  private Map<String, ICacheSyncFilter> cacheSyncFilters = new HashMap();
  private String cacheType = "LOCAL";
  private List<String> clientSyncCache = new ArrayList();
  private String syncTopicName = "";
  private Map<String, KVManager> kvManagers = new HashMap();

  public String getSyncTopicName() {
    return this.syncTopicName;
  }

  public void setSyncTopicName(String syncTopicName) {
    this.syncTopicName = syncTopicName;
  }

  public String getCacheType() {
    return this.cacheType;
  }

  public void setCacheType(String cacheType) {
    this.cacheType = cacheType;
  }

  public Map<String, CacheManager> getCacheManagers() {
    return this.cacheManagers;
  }

  public void setCacheManagers(Map<String, CacheManager> cacheManagers) {
    this.cacheManagers = cacheManagers;
    prepare();
  }

  public static TnmsCacheManagerFactory getInstance()
  {
    return instance;
  }

  private void prepare() {
    String serverName = TnmsServerName.getLocalServerNameStr();
    Iterator iterator = this.cacheManagers.keySet().iterator();
    while (iterator.hasNext()) {
      String key = (String)iterator.next();
      CacheManager manager = (CacheManager)this.cacheManagers.get(key);
      List cacheClassNames = new ArrayList();
      HashMap map = manager.getCacheClassNames();
      cacheClassNames.addAll(map.keySet());
      for (int i = 0; i < cacheClassNames.size(); i++) {
        String _dbClassName = (String)cacheClassNames.get(i);
        String javaClassName = DaoHelper.getJavaClassNameByDbClassName(_dbClassName);
        this.allCacheClassNames.put(_dbClassName, javaClassName);
        if ((key != null) && (key.equals(serverName))) {
          this.localCacheClassNames.put(_dbClassName, javaClassName);
        }
      }
      List notifyClassNames = manager.getNotifyClassNames();
      for (int i = 0; i < notifyClassNames.size(); i++) {
        String _dbClassName = (String)notifyClassNames.get(i);
        String javaClassName = DaoHelper.getJavaClassNameByDbClassName(_dbClassName);
        this.allNotifyOnlyClassNames.put(_dbClassName, javaClassName);
      }

      if ((key != null) && (key.equals(serverName))) {
        Map filtersMap = manager.getCacheSyncFilters();
        Iterator it = filtersMap.keySet().iterator();
        while (it.hasNext()) {
          String className = (String)it.next();
          prepareCacheSyncFilter(className);
        }
      }
    }

    if (this.clientSyncCache != null)
      for (int i = 0; i < this.clientSyncCache.size(); i++) {
        String _dbClassName = (String)this.clientSyncCache.get(i);
        String javaClassName = DaoHelper.getJavaClassNameByDbClassName(_dbClassName);
        this.allNotifyClientClassNames.put(_dbClassName, javaClassName);
      }
  }

  public List<String> getLocalCache()
  {
    List localCache = new ArrayList();
    CacheManager cacheManager = (CacheManager)this.cacheManagers.get(TnmsServerName.getLocalServerNameStr());
    if (cacheManager != null) {
      HashMap cacheClassNames = cacheManager.getCacheClassNames();
      localCache.addAll(cacheClassNames.keySet());
    }
    return localCache;
  }

  public ICacheSyncFilter getCacheSyncFilter(String dbClassName) {
    return (ICacheSyncFilter)this.cacheSyncFilters.get(dbClassName);
  }

  public String getCacheType(String dbClassName) {
    CacheManager cacheManager = (CacheManager)this.cacheManagers.get(TnmsServerName.getLocalServerNameStr());
    String ct = (String)cacheManager.getCacheClassNames().get(dbClassName);
    if ((ct == null) || (ct.length() <= 0)) {
      ct = cacheManager.getCacheType(dbClassName);
      if ((ct == null) || (ct.length() <= 0)) {
        ct = this.cacheType;
      }
    }
    return ct;
  }

  public boolean isSyncLoadCache() {
    CacheManager cacheManager = (CacheManager)this.cacheManagers.get(TnmsServerName.getLocalServerNameStr());
    return (cacheManager != null) && (cacheManager.isSyncLoad());
  }

  public boolean isServerSyncCacheClass(String dbClassName)
  {
    return this.allCacheClassNames.containsKey(dbClassName);
  }
  public boolean isShareCacheClass(String dbClassName) {
    return this.allCacheClassNames.containsKey(dbClassName);
  }
  public boolean isClientSyncCacheClass(String dbClassName) {
    return this.allNotifyClientClassNames.containsKey(dbClassName);
  }
  public boolean isNotifyOnlyClass(String dbClassName) {
    return this.allNotifyOnlyClassNames.containsKey(dbClassName);
  }

  private static String formatClassName(String className) {
    String dbClassName = null;
    try {
      Class cls = Class.forName(className);
      GenericDO dbo = (GenericDO)cls.newInstance();
      dbClassName = dbo.getClassName();
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
    return dbClassName;
  }

  public ICacheLoader getCacheLoader(String dbClassName) {
    CacheManager cacheManager = (CacheManager)this.cacheManagers.get(TnmsServerName.getLocalServerNameStr());
    String loaderClassName = cacheManager.getCacheLoaderName(dbClassName);
    ICacheLoader cacheLoader = null;
    if ((loaderClassName != null) && (loaderClassName.trim().length() > 0)) {
      try
      {
        Class cls = Class.forName(loaderClassName);
        cacheLoader = (ICacheLoader)cls.newInstance();
      } catch (Exception ex) {
        LogHome.getLog().error("", ex);
      }
    }
    return cacheLoader;
  }

  public void prepareCacheSyncFilter(String dbClassName) {
    CacheManager cacheManager = (CacheManager)this.cacheManagers.get(TnmsServerName.getLocalServerNameStr());
    String filterClassName = cacheManager.getCacheSyncFilterName(dbClassName);
    ICacheSyncFilter filter = null;
    if ((filterClassName != null) && (filterClassName.trim().length() > 0)) {
      try
      {
        Class cls = Class.forName(filterClassName);
        filter = (ICacheSyncFilter)cls.newInstance();
      } catch (Exception ex) {
        LogHome.getLog().error("", ex);
      }
    }
    this.cacheSyncFilters.put(dbClassName, filter);
  }

  public List<String> getClientSyncCache() {
    return this.clientSyncCache;
  }

  public void setClientSyncCache(List<String> clientSyncCache) {
    this.clientSyncCache = clientSyncCache;
  }

  public Map<String, KVManager> getKvManagers() {
    return this.kvManagers;
  }

  public void setKvManagers(Map<String, KVManager> kvManagers) {
    this.kvManagers = kvManagers;
  }

  public KVManager getKvManager(String name) {
    return (KVManager)this.kvManagers.get(name);
  }
}