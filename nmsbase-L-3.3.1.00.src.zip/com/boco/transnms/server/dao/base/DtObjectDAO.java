package com.boco.transnms.server.dao.base;

import com.boco.common.util.db.AbstractUserTransaction;
import com.boco.common.util.db.UserTransaction;
import com.boco.common.util.debug.LogHome;
import com.boco.common.util.lang.StringHelper;
import com.boco.transnms.common.dto.ObjInfChangeLog;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.base.IBoActionContext;
import com.boco.transnms.server.common.cfg.IrmsAppCfg;
import com.boco.transnms.server.common.cfg.TnmsAppCfg;
import com.boco.transnms.server.common.cfg.TnmsRuntime;
import com.boco.transnms.server.common.cfg.TransNmsCfg;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.commons.logging.Log;

public class DtObjectDAO extends CachedObjectDAO
{
  public static final String DaoName = "DtObjectDAO";
  private Map<String, DataObjectList> changeLogDtoTemplates = new HashMap();
  private Map<Object, List<ObjInfChangeLog>> changeLogdboTableOfTransc = new ConcurrentHashMap();

  private List<String> objectDevIndexClassNames = new ArrayList();

  private static String AttrOperType = "CHANGE_LOG_OPER_TYPE";

  public DtObjectDAO() { super("DtObjectDAO");
    initDAO(); }

  protected void initDAO()
  {
    try {
      if (TnmsRuntime.getInstance().equals("SUPPORT_CHANGE_LOG", Boolean.TRUE.toString())) {
        LogHome.getLog().info("TransNmsCfg.SupportChangeLog支持对象变更日志记录");
        List changeLogDtoClassNames = TnmsAppCfg.getInstance().getChangeLogDaoClassNames();
        for (String className : changeLogDtoClassNames) {
          GenericDO dboTemplate = (GenericDO)Class.forName(className).newInstance();
          this.changeLogDtoTemplates.put(dboTemplate.getClassName(), new DataObjectList());
        }
      } else {
        LogHome.getLog().info("TransNmsCfg.SupportChangeLog不支持对象变更日志记录");
      }
      if (TnmsRuntime.getInstance().equals("SUPPORT_OBJECT_INDEX", Boolean.TRUE.toString())) {
        LogHome.getLog().info("TransNmsCfg.SupportObjectIndex支持对象变更索引更新");
        this.objectDevIndexClassNames = IrmsAppCfg.getInstance().getObjectDevIndexClassNames();
      } else {
        LogHome.getLog().info("TransNmsCfg.SupportObjectIndex不支持对象变更索引更");
      }
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
    if ("DtObjectDAO".equals(TransNmsCfg.getInstance().getImplDaoName()))
      super.initDAO();
  }

  public void createObject(IBoActionContext actionContext, GenericDO dbo) throws Exception
  {
    super.createObject(actionContext, dbo);
    if (TnmsRuntime.getInstance().equals("SUPPORT_CHANGE_LOG", Boolean.TRUE.toString()))
      addChangeLogObject(dbo);
  }

  public void createObjects(IBoActionContext actionContext, DataObjectList dbos)
    throws Exception
  {
    super.createObjects(actionContext, dbos);
    if (TnmsRuntime.getInstance().equals("SUPPORT_CHANGE_LOG", Boolean.TRUE.toString()))
      for (GenericDO dbo : dbos)
        addChangeLogObject(dbo);
  }

  public void updateObject(IBoActionContext actionContext, GenericDO dbo)
    throws Exception
  {
    super.updateObject(actionContext, dbo);
    if (TnmsRuntime.getInstance().equals("SUPPORT_CHANGE_LOG", Boolean.TRUE.toString()))
      updateChangeLogObject(dbo);
  }

  public void updateObjects(IBoActionContext actionContext, DataObjectList dbos, Map attrs) throws Exception
  {
    super.updateObjects(actionContext, dbos, attrs);
    if (TnmsRuntime.getInstance().equals("SUPPORT_CHANGE_LOG", Boolean.TRUE.toString()))
      updateChangeLogObjects(dbos);
  }

  public void updateObjects(IBoActionContext actionContext, String className, String sql, Map attrs) throws Exception
  {
    super.updateObjects(actionContext, className, sql, attrs);
    if (TnmsRuntime.getInstance().equals("SUPPORT_CHANGE_LOG", Boolean.TRUE.toString())) {
      DataObjectList dbos = getCachedObjectsBySql(className, sql);
      updateChangeLogObjects(dbos);
    }
  }

  public void deleteObject(IBoActionContext actionContext, GenericDO dbo) throws Exception {
    super.deleteObject(actionContext, dbo);
    if (TnmsRuntime.getInstance().equals("SUPPORT_CHANGE_LOG", Boolean.TRUE.toString()))
      deleteChangeLogObject(dbo);
  }

  public void deleteObjects(IBoActionContext actionContext, DataObjectList dbos)
    throws Exception
  {
    super.deleteObjects(actionContext, dbos);
    if (TnmsRuntime.getInstance().equals("SUPPORT_CHANGE_LOG", Boolean.TRUE.toString()))
      for (GenericDO dbo : dbos)
        deleteChangeLogObject(dbo);
  }

  public void deleteObjects(IBoActionContext actionContext, String className, String sql)
    throws Exception
  {
    DataObjectList dbos = getCachedObjectsBySql(className, sql);
    super.deleteObjects(actionContext, className, sql);
    if (TnmsRuntime.getInstance().equals("SUPPORT_CHANGE_LOG", Boolean.TRUE.toString()))
      for (GenericDO dbo : dbos)
        deleteChangeLogObject(dbo);
  }

  public void deleteAll(IBoActionContext actionContext, String className)
    throws Exception
  {
    super.deleteAll(actionContext, className);
    if (TnmsRuntime.getInstance().equals("SUPPORT_CHANGE_LOG", Boolean.TRUE.toString()))
      deleteAllChangeLogObject(className);
  }

  private void addChangeLogObject(GenericDO dbo)
  {
    if (this.changeLogDtoTemplates.containsKey(dbo.getClassName())) {
      UserTransaction transc = getTransaction();
      if (transc == null)
      {
        addObjInfChangeLog(dbo, 1);
      }
      else addObjInfChangeLogTransaction(transc, dbo, 1);
    }
  }

  private void updateChangeLogObject(GenericDO dbo)
  {
    if ((dbo != null) && 
      (this.changeLogDtoTemplates.containsKey(dbo.getClassName()))) {
      UserTransaction transc = getTransaction();
      if (transc == null)
        addObjInfChangeLog(dbo, 2);
      else
        addObjInfChangeLogTransaction(transc, dbo, 2);
    }
  }

  private void updateChangeLogObjects(DataObjectList dbos)
  {
    UserTransaction transc = getTransaction();
    if (transc == null) {
      for (GenericDO dbo : dbos) {
        if (this.changeLogDtoTemplates.containsKey(dbo.getClassName()))
          addObjInfChangeLog(dbo, 2);
      }
    }
    else
      for (GenericDO dbo : dbos)
        if (this.changeLogDtoTemplates.containsKey(dbo.getClassName()))
          addObjInfChangeLogTransaction(transc, dbo, 2);
  }

  private void deleteChangeLogObject(GenericDO dbo)
  {
    if (this.changeLogDtoTemplates.containsKey(dbo.getClassName())) {
      UserTransaction transc = getTransaction();
      if (transc == null)
        addObjInfChangeLog(dbo, 3);
      else
        addObjInfChangeLogTransaction(transc, dbo, 3);
    }
  }

  private void deleteAllChangeLogObject(String className)
  {
    if (this.changeLogDtoTemplates.containsKey(className)) {
      UserTransaction transc = getTransaction();
      if (transc == null)
        addObjInfChangeLog(className, 3);
      else
        addObjInfChangeLogTransaction(transc, className, 3);
    }
  }

  private void addObjInfChangeLog(String className, int operType)
  {
    try {
      ObjInfChangeLog logdbo = new ObjInfChangeLog();
      if ((className != null) && (className.trim().length() > 0)) {
        logdbo.setChangeClassName(className);
        logdbo.setGetFlag(0L);
        logdbo.setChangeObjCuid("ALL");
      }switch (operType) {
      case 1:
        logdbo.setObjChangeType(1L);
        break;
      case 2:
        logdbo.setObjChangeType(2L);
        break;
      case 3:
        logdbo.setObjChangeType(3L);
        break;
      default:
        LogHome.getLog().error("未知操作类型：" + operType); break;

        LogHome.getLog().error("对象变化记录错误：className名称不能为空");
      }
      super.createObject(new BoActionContext(), logdbo);
    } catch (Exception ex) {
      LogHome.getLog().error("对象变化记录错误：" + ex);
    }
  }

  private void addObjInfChangeLog(GenericDO dbo, int operType) {
    try {
      ObjInfChangeLog logdbo = new ObjInfChangeLog();
      if (dbo != null) {
        logdbo.setChangeClassName(dbo.getClassName());
        logdbo.setGetFlag(0L);
        logdbo.setChangeObjCuid(dbo.getCuid());
        if (dbo.getAttrString("LABEL_CN") != null)
          logdbo.setChangeObjLabelcn(StringHelper.nullToEmpty(dbo.getAttrString("LABEL_CN")));
        else {
          logdbo.setChangeObjLabelcn("未知对象");
        }
        switch (operType) {
        case 1:
          logdbo.setObjChangeType(1L);
          break;
        case 2:
          logdbo.setObjChangeType(2L);
          break;
        case 3:
          logdbo.setObjChangeType(3L);
          break;
        default:
          LogHome.getLog().error("未知操作类型：" + operType); break;
        }
      } else {
        LogHome.getLog().error("对象变化记录错误：传输的对象不能为空");
      }
      super.createObject(new BoActionContext(), logdbo);
    } catch (Exception ex) {
      LogHome.getLog().error("对象变化记录错误：" + ex);
    }
  }

  private void addObjInfChangeLogTransaction(UserTransaction transc, String className, int operType) {
    ObjInfChangeLog logdbo = new ObjInfChangeLog();
    if ((className != null) && (className.trim().length() > 0)) {
      logdbo.setChangeClassName(className);
      logdbo.setGetFlag(0L);
      logdbo.setChangeObjCuid("ALL");
    }switch (operType) {
    case 1:
      logdbo.setObjChangeType(1L);
      break;
    case 2:
      logdbo.setObjChangeType(2L);
      break;
    case 3:
      logdbo.setObjChangeType(3L);
      break;
    default:
      LogHome.getLog().error("未知操作类型：" + operType); break;

      LogHome.getLog().error("对象变化记录错误：传输的对象不能为空");
    }
    List logdbos = (List)this.changeLogdboTableOfTransc.get(transc);
    if (logdbos == null) {
      ((AbstractUserTransaction)transc).addTranscListener(this);
      logdbos = new ArrayList();
      this.changeLogdboTableOfTransc.put(transc, logdbos);
    }
    logdbos.add(logdbo);
  }

  private void addObjInfChangeLogTransaction(UserTransaction transc, GenericDO dbo, int operType) {
    ObjInfChangeLog logdbo = new ObjInfChangeLog();
    if (dbo != null) {
      logdbo.setChangeClassName(dbo.getClassName());
      logdbo.setGetFlag(0L);
      logdbo.setChangeObjCuid(dbo.getCuid());
      if (dbo.getAttrString("LABEL_CN") != null)
        logdbo.setChangeObjLabelcn(StringHelper.nullToEmpty(dbo.getAttrString("LABEL_CN")));
      else {
        logdbo.setChangeObjLabelcn("未知对象");
      }
      switch (operType) {
      case 1:
        logdbo.setObjChangeType(1L);
        break;
      case 2:
        logdbo.setObjChangeType(2L);
        break;
      case 3:
        logdbo.setObjChangeType(3L);
        break;
      default:
        LogHome.getLog().error("未知操作类型：" + operType); break;
      }
    } else {
      LogHome.getLog().error("对象变化记录错误：传输的对象不能为空");
    }
    List logdbos = (List)this.changeLogdboTableOfTransc.get(transc);
    if (logdbos == null) {
      ((AbstractUserTransaction)transc).addTranscListener(this);
      logdbos = new ArrayList();
      this.changeLogdboTableOfTransc.put(transc, logdbos);
    }
    logdbos.add(logdbo);
  }

  public void doTranscRollback(UserTransaction transc) {
    super.doTranscRollback(transc);
    if (TnmsRuntime.getInstance().equals("SUPPORT_CHANGE_LOG", Boolean.TRUE.toString()))
      this.changeLogdboTableOfTransc.remove(transc);
  }

  public void doTranscCommit(UserTransaction transc)
  {
    try
    {
      super.doTranscCommit(transc);
      if (TnmsRuntime.getInstance().equals("SUPPORT_CHANGE_LOG", Boolean.TRUE.toString())) {
        List logdbos = (List)this.changeLogdboTableOfTransc.remove(transc);
        if (logdbos != null) {
          for (GenericDO dbo : logdbos) {
            super.createObject(new BoActionContext(), dbo);
          }

        }

      }

    }
    catch (Exception ex)
    {
      transc.rollback();
      LogHome.getLog().error("对象变化记录错误:批量增加变化记录错误" + ex);
    }
  }

  private DataObjectList getCachedObjectsBySql(String className, String sql) {
    DataObjectList dbos = new DataObjectList();
    try
    {
      dbos = super.getObjectsBySql(sql, new GenericDO(className), 0);
    }
    catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
    return dbos;
  }
}