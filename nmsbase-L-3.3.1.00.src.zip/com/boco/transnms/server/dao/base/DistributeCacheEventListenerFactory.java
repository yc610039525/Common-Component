package com.boco.transnms.server.dao.base;

import java.util.Properties;
import net.sf.ehcache.event.CacheEventListener;
import net.sf.ehcache.event.CacheEventListenerFactory;

public class DistributeCacheEventListenerFactory extends CacheEventListenerFactory
{
  public CacheEventListener createCacheEventListener(Properties properties)
  {
    return new DistributeCacheEventListener();
  }
}