package com.boco.transnms.server.dao.base;

import com.boco.common.util.db.DbConnManager;
import com.boco.common.util.debug.LogHome;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.common.cfg.TnmsServerName;
import com.boco.transnms.server.common.cfg.TnmsServerName.ServerName;
import java.util.HashMap;
import java.util.Map;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;
import org.apache.commons.logging.Log;

public class CacheAdminHandler
  implements MessageListener
{
  private Map<String, CachedDataObjects> cachedDtoTemplates = new HashMap();

  public CacheAdminHandler(Map<String, CachedDataObjects> _cachedDtoTemplates) { this.cachedDtoTemplates = _cachedDtoTemplates; }

  public void onMessage(Message _message) {
    LogHome.getLog().error("收到管理命令：" + _message.toString());
    if ((_message instanceof TextMessage))
      try {
        TextMessage msg = (TextMessage)_message;
        String adminCmd = msg.getText();
        if (adminCmd != null) {
          String[] _adminCmd = adminCmd.split(":");
          String serverName = _adminCmd[0];
          String cmd = _adminCmd[1];
          String _objTargets = _adminCmd[2];
          String[] objTargets = _objTargets.split(",");
          if ((TnmsServerName.ServerName.ALL.toString().equals(serverName)) || (TnmsServerName.getLocalServerNameStr().equals(serverName)))
          {
            for (String objTarget : objTargets)
              if ("check".equals(cmd))
                checkCache(objTarget);
              else if ("reload".equals(cmd))
                reloadCache(objTarget);
              else if ("cuid".equals(cmd))
                checkCacheCuid(objTarget);
              else if ("checkclass".equals(cmd))
                checkCacheClass(objTarget);
              else if ("checkdbpool".equals(cmd))
                checkDbPool(objTarget);
              else if ("checkcacheupdater".equals(cmd))
                checkCacheUpdater(objTarget);
              else if ("synccache".equals(cmd))
                syncCache(objTarget);
              else
                LogHome.getLog().error("未知的管理命令：" + cmd);
          }
        }
      }
      catch (Throwable ex)
      {
        LogHome.getLog().error("", ex);
      }
  }

  private void checkCache(String dbClassName)
  {
    try {
      CachedDataObjects cache = (CachedDataObjects)this.cachedDtoTemplates.get(dbClassName);
      if (cache != null) {
        LogHome.getLog().warn("缓存管理核查开始：缓存对象：" + dbClassName);
        cache.checkCache();
        LogHome.getLog().warn("缓存管理核查结束：缓存对象：" + dbClassName);
      } else {
        LogHome.getLog().warn("缓存管理核查：非本地缓存对象，dbClassName=" + dbClassName);
      }
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }

  private void checkCacheCuid(String cuid) {
    try {
      String dbClassName = GenericDO.parseClassNameFromCuid(cuid);
      if (dbClassName == null) {
        LogHome.getLog().warn("缓存管理核查CUID：不能解析dbClassName，cuid=" + cuid);
        return;
      }
      CachedDataObjects cache = (CachedDataObjects)this.cachedDtoTemplates.get(dbClassName);
      if (cache != null) {
        LogHome.getLog().warn("缓存管理核查CUID开始：核查dbClassName=" + dbClassName + ", CUID=" + cuid);
        GenericDO dbo = cache.getObjectByCuid(cuid);
        LogHome.getLog().warn("缓存管理核查CUID：dbo=" + dbo);
        LogHome.getLog().warn("缓存管理核查CUID结束：核查dbClassName=" + dbClassName + ", CUID=" + cuid);
      } else {
        LogHome.getLog().warn("缓存管理核查CUID：非本地缓存对象，dbClassName=" + dbClassName);
      }
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }

  private void checkCacheClass(String dbClassName) {
    try {
      CachedDataObjects cache = (CachedDataObjects)this.cachedDtoTemplates.get(dbClassName);
      if (cache != null) {
        LogHome.getLog().warn("缓存管理核查CLASS开始：缓存对象：" + dbClassName);
        cache.checkCacheClass();
        LogHome.getLog().warn("缓存管理核查CLASS结束：缓存对象：" + dbClassName);
      } else {
        LogHome.getLog().warn("缓存管理核查CLASS：非本地缓存对象，dbClassName=" + dbClassName);
      }
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }

  private void checkDbPool(String dbClassName) {
    try {
      LogHome.getLog().warn("检查数据库连接池开始：" + dbClassName);
      DbConnManager.getInstance().checkDbpool();
      LogHome.getLog().warn("检查数据库连接池结束：" + dbClassName);
    }
    catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }

  private void checkCacheUpdater(String dbClassName) {
    try {
      CachedDataObjects cache = (CachedDataObjects)this.cachedDtoTemplates.get(dbClassName);
      if (cache != null) {
        LogHome.getLog().warn("缓存管理对象更新核查开始：缓存对象：" + dbClassName);
        CachedDAOHelper.checkCacheClassName = dbClassName;
        LogHome.getLog().warn("缓存管理对象更新核查结束：缓存对象：" + dbClassName);
      } else {
        CachedDAOHelper.checkCacheClassName = null;
        LogHome.getLog().warn("缓存管理对象更新核查：非本地缓存对象，dbClassName=" + dbClassName);
      }
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }

  private void syncCache(String cmd)
  {
  }

  private void reloadCache(String dbClassName)
  {
    try
    {
      CachedDataObjects cache = (CachedDataObjects)this.cachedDtoTemplates.get(dbClassName);
      if (cache != null) {
        LogHome.getLog().warn("缓存管理重新加载开始：" + dbClassName);
        cache.setInitCompleted(false);
        cache.loadData(true);
        cache.setInitCompleted(true);
        LogHome.getLog().warn("缓存管理重新加载结束：" + dbClassName);
      } else {
        LogHome.getLog().warn("缓存管理重新加载：非本地缓存对象，dbClassName=" + dbClassName);
      }
      checkCache(dbClassName);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }
}