package com.boco.transnms.server.dao.base;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CacheManager
{
  private HashMap<String, String> cacheClassNames = new HashMap();
  private List<String> notifyClassNames = new ArrayList();
  private boolean syncLoad = false;
  private Map<String, String> cacheLoaders = new HashMap();
  private Map<String, String> cacheSyncFilters = new HashMap();

  private String name = "";

  public Map<String, String> getCacheLoaders()
  {
    return this.cacheLoaders;
  }

  public void setCacheLoaders(Map<String, String> cacheLoaders) {
    this.cacheLoaders = cacheLoaders;
  }

  public String getCacheLoaderName(String dbClassName) {
    return (String)this.cacheLoaders.get(dbClassName);
  }

  public String getCacheSyncFilterName(String dbClassName) {
    return (String)this.cacheSyncFilters.get(dbClassName);
  }

  public Map<String, String> getCacheSyncFilters() {
    return this.cacheSyncFilters;
  }

  public void setCacheSyncFilters(Map<String, String> cacheSyncFilters) {
    this.cacheSyncFilters = cacheSyncFilters;
  }

  public List<String> getNotifyClassNames() {
    return this.notifyClassNames;
  }

  public void setNotifyClassNames(List<String> notifyClassNames) {
    this.notifyClassNames = notifyClassNames;
  }

  public String getName()
  {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public boolean isSyncLoad() {
    return this.syncLoad;
  }

  public void setSyncLoad(boolean syncLoad) {
    this.syncLoad = syncLoad;
  }

  public HashMap<String, String> getCacheClassNames() {
    return this.cacheClassNames;
  }

  public void setCacheClassNames(HashMap<String, String> cacheClassNames) {
    this.cacheClassNames = cacheClassNames;
  }

  public String getCacheType(String className) {
    return (String)this.cacheClassNames.get(className);
  }
}