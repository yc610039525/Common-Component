package com.boco.transnms.server.dao.base;

import com.boco.common.util.db.DbConnManager;
import com.boco.common.util.db.DbContext;
import com.boco.common.util.db.DbType;
import com.boco.common.util.db.SqlHelper;
import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.cache.BigMemDaoCache;
import com.boco.transnms.common.cache.EcDaoCache;
import com.boco.transnms.common.cache.HashDaoCache;
import com.boco.transnms.common.cache.ICacheLoader;
import com.boco.transnms.common.cache.IDaoCache;
import com.boco.transnms.common.cache.McDaoCache;
import com.boco.transnms.common.cache.RedisDaoCache;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.common.cfg.TnmsServerName;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.logging.Log;

public class CachedDataObjects
{
  private static final long MAX_CACHE_OPERTIME = 200L;
  private static long loadCompletedTimestamp = 0L;
  private IDaoCache<String, GenericDO> cuidKeyDbos;
  private IDaoCache<Long, GenericDO> objIdKeyDbos;
  private final GenericDO dboTemplate;
  private boolean isInitCompleted = false;
  private List<ChangeRecord> beforeInitRecords = new ArrayList();
  private IDataAccessObject dao;
  private CACHE_TYPE cacheType = CACHE_TYPE.LOCAL;

  public static long getLoadCompletedTimestamp()
  {
    return loadCompletedTimestamp;
  }

  public CachedDataObjects(GenericDO dboTemplate, String cacheType, IDataAccessObject dao)
  {
    this.dboTemplate = dboTemplate;
    this.dao = dao;
    String dbClassName = dboTemplate.getClassName();
    this.cacheType = CACHE_TYPE.valueOf(cacheType);
    if (this.cacheType == CACHE_TYPE.EC) {
      this.objIdKeyDbos = new EcDaoCache(new StringBuilder().append(dbClassName).append("_OID_CACHE").toString(), false);
      this.cuidKeyDbos = new EcDaoCache(new StringBuilder().append(dbClassName).append("_CUID_CACHE").toString(), false);
    } else if (this.cacheType == CACHE_TYPE.MC) {
      this.objIdKeyDbos = new McDaoCache(dbClassName);
      this.cuidKeyDbos = new McDaoCache(dbClassName);
    } else if (this.cacheType == CACHE_TYPE.BIGMEM) {
      this.objIdKeyDbos = new BigMemDaoCache(new StringBuilder().append(dbClassName).append("_OID_CACHE").toString(), true);
      this.cuidKeyDbos = new BigMemDaoCache(new StringBuilder().append(dbClassName).append("_CUID_CACHE").toString(), true);
    } else if (this.cacheType == CACHE_TYPE.REDIS) {
      this.objIdKeyDbos = new RedisDaoCache(dbClassName);
      this.cuidKeyDbos = new RedisDaoCache(dbClassName);
    }
    else
    {
      this.objIdKeyDbos = new HashDaoCache();
      this.cuidKeyDbos = new HashDaoCache();
    }
  }

  public boolean isSupportGetAll() {
    return this.cacheType != CACHE_TYPE.MC;
  }

  public int getCacheSize() {
    int size = -1;
    if (this.objIdKeyDbos != null) {
      size = this.objIdKeyDbos.size();
    }
    return size;
  }

  public void checkCacheState() {
    int cacheSize = getCacheSize();
    if (cacheSize > 0) {
      int dbSize = getDbCount();
      if (dbSize == cacheSize) {
        String dbClassName = this.dboTemplate.getClassName();
        setInitCompleted(true);
        LogHome.getLog().info(new StringBuilder().append("缓存和数据库一致，被动初始化完成, dbClassName=").append(dbClassName).append(", cacheSize=").append(cacheSize).toString());
      }
    }
  }

  public void checkCacheClass()
  {
    Class clazz = this.dboTemplate.createInstanceByClassName().getClass();
    List dbos = this.cuidKeyDbos.values();
    for (int i = 0; (dbos != null) && (i < dbos.size()); i++) {
      GenericDO dbo = (GenericDO)dbos.get(i);
      if (!dbo.getClass().getSimpleName().equals(clazz.getClass().getSimpleName()))
        LogHome.getLog().error(new StringBuilder().append("缓存对象class错误：").append(dbo.toString()).toString());
    }
  }

  public void checkCache()
  {
    synchronized (this) {
      int cacheSize = getCacheSize();
      int dbSize = getDbCount();
      LogHome.getLog().warn(new StringBuilder().append("缓存管理：缓存核查：dbClassName=").append(this.dboTemplate.getClassName()).append(", dbSize=").append(dbSize).append(", cacheSize=").append(cacheSize).append(dbSize == cacheSize ? "，结果一致；" : "，结果不一致；").toString());
    }
  }

  private final int getDbCount()
  {
    String dbClassName = this.dboTemplate.getClassName();
    String countSql = new StringBuilder().append("select count(*) from ").append(dbClassName).toString();
    int dbSize = 0;
    try {
      dbSize = this.dao.getCalculateValue(countSql);
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
    return dbSize;
  }

  public final GenericDO getDboTemplate() {
    return this.dboTemplate;
  }

  public boolean initCache() throws Exception {
    String dbClassName = this.dboTemplate.getClassName();
    if (!this.isInitCompleted) {
      if (this.cacheType == CACHE_TYPE.MC)
      {
        String cacheFlagName = dbClassName;
        ICacheLoader cacheLoader = TnmsCacheManagerFactory.getInstance().getCacheLoader(dbClassName);
        if (cacheLoader != null) {
          cacheFlagName = new StringBuilder().append(cacheFlagName).append("-").append(TnmsServerName.getLocalServerFullName()).toString();
        }
        GenericDO loadFinishedFlag = (GenericDO)this.cuidKeyDbos.get(cacheFlagName);
        if (loadFinishedFlag == null) {
          LogHome.getLog().info(new StringBuilder().append("Memcached缓存尚未开始加载：").append(dbClassName).toString());
          loadData(false);
          loadFinishedFlag = new GenericDO();
          this.cuidKeyDbos.put(cacheFlagName, loadFinishedFlag);
          LogHome.getLog().info(new StringBuilder().append("Memcached缓存加载完成：").append(dbClassName).toString());
        } else {
          LogHome.getLog().info(new StringBuilder().append("Memcached缓存已经加载：").append(dbClassName).toString());
        }
      } else {
        loadData(false);
      }
      setInitCompleted(true);
    }

    loadCompletedTimestamp = System.currentTimeMillis();

    return this.isInitCompleted;
  }

  public void loadData(boolean isQuiet) throws Exception {
    synchronized (this) {
      String dbClassName = this.dboTemplate.getClassName();
      ICacheLoader cacheLoader = TnmsCacheManagerFactory.getInstance().getCacheLoader(dbClassName);
      if (cacheLoader != null) {
        DataObjectList dbos = cacheLoader.loadCache(this.dao, dbClassName);
        for (GenericDO dbo : dbos)
          _addObject(dbo, true);
      }
      else {
        String sql = new StringBuilder().append("select * from ").append(dbClassName).toString();
        DboCollection dbos = this.dao.selectDBOs(new BoQueryContext(), sql, new GenericDO[] { this.dboTemplate });
        for (int i = 0; i < dbos.size(); i++) {
          GenericDO dto = dbos.getQueryDbo(i, this.dboTemplate.getClassName());
          _addObject(dto, isQuiet);
        }
      }
    }
  }

  public void loadData(boolean isQuiet, Timestamp lastSyncTime) throws Exception {
    synchronized (this) {
      String dbClassName = this.dboTemplate.getClassName();
      ICacheLoader cacheLoader = TnmsCacheManagerFactory.getInstance().getCacheLoader(dbClassName);
      if (cacheLoader != null) {
        DataObjectList dbos = cacheLoader.loadCache(this.dao, dbClassName, lastSyncTime);
        for (GenericDO dbo : dbos)
          _addObject(dbo, true);
      }
      else {
        String sql = new StringBuilder().append("select * from ").append(dbClassName).toString();
        if (lastSyncTime != null) {
          DbType dbType = DbConnManager.getInstance().getDbContext().getDbType();
          sql = new StringBuilder().append(sql).append(" WHERE ").append("LAST_MODIFY_TIME").append(">=").append(SqlHelper.getTimestamp(dbType, lastSyncTime)).toString();
        }

        DboCollection dbos = this.dao.selectDBOs(new BoQueryContext(), sql, new GenericDO[] { this.dboTemplate });
        for (int i = 0; i < dbos.size(); i++) {
          GenericDO dto = dbos.getQueryDbo(i, this.dboTemplate.getClassName());
          _addObject(dto, isQuiet);
        }
      }
    }
  }

  public void setInitCompleted(boolean isTrue) {
    if (isTrue) {
      this.isInitCompleted = true;
      for (ChangeRecord record : this.beforeInitRecords) {
        if (record.changeType == ChangeRecord.ChangeType.ADD) {
          GenericDO dbo = (GenericDO)record.value;
          LogHome.getLog().info(new StringBuilder().append("缓存预处理-新增[className=").append(dbo.getClassName()).append(", objectId=").append(dbo.getObjectNum()).append(", cuid=").append(dbo.getCuid()).append("]").toString());

          addObject(dbo, false);
        } else if (record.changeType == ChangeRecord.ChangeType.UPDATE) {
          GenericDO dbo = (GenericDO)record.value;
          LogHome.getLog().info(new StringBuilder().append("缓存预处理-更新[className=").append(dbo.getClassName()).append(", objectId=").append(dbo.getObjectNum()).append(", cuid=").append(dbo.getCuid()).append("]").toString());

          updateObject(dbo);
        } else if (record.changeType == ChangeRecord.ChangeType.UPDATES) {
          DataObjectList dbos = (DataObjectList)record.value;
          LogHome.getLog().info(new StringBuilder().append("缓存预处理-批量更新对象[className=").append(dbos.getElementClassName()).append(", size=").append(dbos.size()).append("]").toString());
          updateObjects(dbos);
        } else if (record.changeType == ChangeRecord.ChangeType.UPDATE_ATTRS) {
          Object[] paras = (Object[])record.value;
          LogHome.getLog().info("缓存预处理-批量更新对象属性");
          List objList = (List)paras[0];
          if (objList.size() > 0) {
            Object obj = objList.get(0);
            if ((obj instanceof String))
              updateObjectsByCuids((List)paras[0], (Map)paras[1]);
            else
              updateObjects((List)paras[0], (Map)paras[1]);
          }
        }
        else if (record.changeType == ChangeRecord.ChangeType.DELETE) {
          GenericDO dbo = (GenericDO)record.value;
          LogHome.getLog().info(new StringBuilder().append("缓存预处理-修改[className=").append(dbo.getClassName()).append(", objectId=").append(dbo.getObjectNum()).append(", cuid=").append(dbo.getCuid()).append("]").toString());

          deleteObject(dbo);
        }
      }
      this.beforeInitRecords.clear();
    } else {
      this.isInitCompleted = false;
    }
  }

  public boolean isInitCompleted() {
    return this.isInitCompleted;
  }

  public synchronized void syncObjectRefs(GenericDO oldDbo, GenericDO newDbo) {
    oldDbo.setReadable(true);
    long objectId = oldDbo.getObjectNum();
    if (objectId == 0L) return;

    GenericDO cachedDbo = (GenericDO)this.objIdKeyDbos.get(Long.valueOf(objectId));
    if ((cachedDbo != null) && (cachedDbo == newDbo)) {
      LogHome.getLog().debug(new StringBuilder().append("缓存同步，恢复对象 , cuid=").append(oldDbo.getCuid()).toString());
      CachedDAOHelper.checkCachedObject(oldDbo);
      this.objIdKeyDbos.put(Long.valueOf(objectId), oldDbo);
      String cuid = oldDbo.getCuid();
      if ((cuid != null) && (this.cuidKeyDbos.containsKey(cuid))) {
        this.cuidKeyDbos.remove(cuid);
        this.cuidKeyDbos.put(cuid, oldDbo);
      }
    }
  }

  public boolean addObject(GenericDO dbo, boolean isQuiet) {
    if (!this.isInitCompleted) {
      this.beforeInitRecords.add(new ChangeRecord(ChangeRecord.ChangeType.ADD, dbo));
      return true;
    }

    return _addObject(dbo, isQuiet);
  }

  public boolean _addObject(GenericDO dbo, boolean isQuiet) {
    boolean isAdded = false;
    long startTime = System.currentTimeMillis();
    synchronized (this) {
      if (dbo.getObjectNum() > 0L) {
        if (this.isInitCompleted) {
          LogHome.getLog().debug(new StringBuilder().append("缓存同步，创建对象， cuid=").append(dbo.getCuid()).toString());
        }
        dbo.setReadable(true);
        isAdded = true;
        this.objIdKeyDbos.put(Long.valueOf(dbo.getObjectNum()), dbo, isQuiet);

        if (dbo.getCuid() != null) {
          CachedDAOHelper.checkCachedObject(dbo);
          this.cuidKeyDbos.put(dbo.getCuid(), dbo, isQuiet);
        }
      } else {
        LogHome.getLog().error(new StringBuilder().append("错误的对象缓存：").append(dbo).toString());
      }
    }
    long expendTime = System.currentTimeMillis() - startTime;
    if (expendTime > 200L) {
      LogHome.getLog().warn(new StringBuilder().append("缓存同步超时，创建对象, expendTime=").append(expendTime).append(", cuid=").append(dbo.getCuid()).toString());
    }
    return isAdded;
  }

  public boolean updateObjects(DataObjectList dbos) {
    if (!this.isInitCompleted) {
      this.beforeInitRecords.add(new ChangeRecord(ChangeRecord.ChangeType.UPDATES, dbos));
      return true;
    }
    synchronized (this) {
      for (GenericDO dbo : dbos) {
        updateObject(dbo);
      }
    }
    return true;
  }

  public boolean updateObjectsByCuids(List<String> cuids, Map attrs) {
    if (!this.isInitCompleted) {
      this.beforeInitRecords.add(new ChangeRecord(ChangeRecord.ChangeType.UPDATE_ATTRS, new Object[] { cuids, attrs }));
      return true;
    }
    synchronized (this) {
      for (String cuid : cuids) {
        GenericDO dbo = (GenericDO)this.cuidKeyDbos.get(cuid);
        dbo.setReadable(false);
        if (dbo != null) {
          dbo.setAttrValues(attrs);

          this.cuidKeyDbos.put(cuid, dbo);

          Long objectid = Long.valueOf(dbo.getObjectNum());
          if ((objectid != null) && (this.objIdKeyDbos.containsKey(objectid))) {
            CachedDAOHelper.checkCachedObject(dbo);
            this.objIdKeyDbos.put(objectid, dbo);
          }
          LogHome.getLog().debug(new StringBuilder().append("缓存同步，更新对象属性 , cuid=").append(dbo.getCuid()).toString());
        }
        dbo.setReadable(true);
      }
    }
    return true;
  }

  public boolean updateObjects(List<Long> objectIds, Map attrs) {
    if (!this.isInitCompleted) {
      this.beforeInitRecords.add(new ChangeRecord(ChangeRecord.ChangeType.UPDATE_ATTRS, new Object[] { objectIds, attrs }));
      return true;
    }
    Iterator i$;
    synchronized (this) {
      for (i$ = objectIds.iterator(); i$.hasNext(); ) { long objectId = ((Long)i$.next()).longValue();
        GenericDO dbo = (GenericDO)this.objIdKeyDbos.get(Long.valueOf(objectId));
        dbo.setReadable(false);
        if (dbo != null) {
          dbo.setAttrValues(attrs);

          this.objIdKeyDbos.put(Long.valueOf(objectId), dbo);

          String cuid = dbo.getCuid();
          if ((cuid != null) && (this.cuidKeyDbos.containsKey(cuid)))
          {
            CachedDAOHelper.checkCachedObject(dbo);
            this.cuidKeyDbos.put(cuid, dbo);
          }
          LogHome.getLog().debug(new StringBuilder().append("缓存同步，更新对象属性 , cuid=").append(dbo.getCuid()).toString());
        }
        dbo.setReadable(true);
      }
    }
    return true;
  }

  public boolean updateObject(GenericDO dbo) {
    return updateObject(dbo, false);
  }
  public boolean updateObject(GenericDO dbo, boolean isQuiet) {
    if (!this.isInitCompleted) {
      this.beforeInitRecords.add(new ChangeRecord(ChangeRecord.ChangeType.UPDATE, dbo));
      return true;
    }
    boolean isUpdated = false;
    long startTime = System.currentTimeMillis();
    synchronized (this) {
      dbo.setReadable(true);
      long objectId = dbo.getObjectNum();
      if ((objectId > 0L) && (this.objIdKeyDbos.containsKey(Long.valueOf(objectId)))) {
        LogHome.getLog().debug(new StringBuilder().append("缓存同步，更新对象属性,, cuid=").append(dbo.getCuid()).toString());
        this.objIdKeyDbos.put(Long.valueOf(objectId), dbo, isQuiet);
        isUpdated = true;

        String cuid = dbo.getCuid();
        if ((cuid != null) && (this.cuidKeyDbos.containsKey(cuid))) {
          CachedDAOHelper.checkCachedObject(dbo);
          this.cuidKeyDbos.put(cuid, dbo, isQuiet);
        }
      } else {
        LogHome.getLog().error(new StringBuilder().append("错误的对象缓存, cuid=").append(dbo.getCuid()).toString());
      }
    }
    long expendTime = System.currentTimeMillis() - startTime;
    if (expendTime > 200L) {
      LogHome.getLog().warn(new StringBuilder().append("缓存同步超时，更新对象属性, expendTime=").append(expendTime).append(", cuid=").append(dbo.getCuid()).toString());
    }
    return isUpdated;
  }

  public boolean deleteObject(GenericDO dbo) {
    if (!this.isInitCompleted) {
      this.beforeInitRecords.add(new ChangeRecord(ChangeRecord.ChangeType.DELETE, dbo));
      return true;
    }
    boolean isDeleted = false;
    long startTime = System.currentTimeMillis();
    synchronized (this) {
      if (dbo.getObjectNum() > 0L) {
        LogHome.getLog().debug(new StringBuilder().append("缓存同步，删除对象, cuid=").append(dbo.getCuid()).toString());
        CachedDAOHelper.checkCachedObject(dbo);
        isDeleted = true;
        GenericDO deletedDO = (GenericDO)this.objIdKeyDbos.remove(Long.valueOf(dbo.getObjectNum()));
        if (deletedDO == null) {
          LogHome.getLog().warn(new StringBuilder().append("要删除的缓存对象已经不存在, cuid=").append(dbo.getCuid()).toString());
        }
        if (dbo.getCuid() != null)
          this.cuidKeyDbos.remove(dbo.getCuid());
      }
      else if (dbo.getCuid() != null) {
        LogHome.getLog().debug(new StringBuilder().append("缓存同步，删除对象, cuid=").append(dbo.getCuid()).toString());
        CachedDAOHelper.checkCachedObject(dbo);
        isDeleted = true;
        GenericDO deletedDO = (GenericDO)this.cuidKeyDbos.remove(dbo.getCuid());
        if (deletedDO == null) {
          LogHome.getLog().warn(new StringBuilder().append("要删除的缓存对象已经不存在, cuid=").append(dbo.getCuid()).toString());
        }
        if (dbo.getObjectNum() > 0L) {
          this.objIdKeyDbos.remove(Long.valueOf(dbo.getObjectNum()));
        }
      }
    }
    long expendTime = System.currentTimeMillis() - startTime;
    if (expendTime > 200L) {
      LogHome.getLog().warn(new StringBuilder().append("缓存同步超时，删除对象 , expendTime=").append(expendTime).append(", cuid=").append(dbo.getCuid()).toString());
    }
    return isDeleted;
  }

  public GenericDO getObject(long objectId) {
    return (GenericDO)this.objIdKeyDbos.get(Long.valueOf(objectId));
  }

  public GenericDO getObjectByCuid(String cuid) {
    return (GenericDO)this.cuidKeyDbos.get(cuid);
  }

  public synchronized DataObjectList getObjects(List<Long> objectIds) {
    DataObjectList dbos = new DataObjectList();
    for (Iterator i$ = objectIds.iterator(); i$.hasNext(); ) { long objectId = ((Long)i$.next()).longValue();
      GenericDO dbo = (GenericDO)this.objIdKeyDbos.get(Long.valueOf(objectId));
      if (dbo != null) {
        dbos.add(dbo);
      }
    }
    return dbos;
  }

  public synchronized DataObjectList getObjects(long[] objectIds) {
    DataObjectList dbos = new DataObjectList();
    for (long objectId : objectIds) {
      GenericDO dbo = (GenericDO)this.objIdKeyDbos.get(Long.valueOf(objectId));
      if (dbo != null) {
        dbos.add(dbo);
      }
    }
    return dbos;
  }

  public synchronized DataObjectList getObjectByCuids(List<String> cuids) {
    DataObjectList dbos = new DataObjectList();
    for (String cuid : cuids) {
      GenericDO dbo = (GenericDO)this.cuidKeyDbos.get(cuid);
      if (dbo != null) {
        dbos.add(dbo);
      }
    }
    return dbos;
  }

  public synchronized DataObjectList getObjByAttrs(GenericDO dboTemplate) {
    DataObjectList dbos = new DataObjectList();
    Map dboTemplateAttrs = dboTemplate.getAllAttr();
    if (dboTemplateAttrs.size() == 0) {
      throw new UserException("没有指定条件属性 ！");
    }

    String[] attrNames = new String[dboTemplateAttrs.size()];
    dboTemplateAttrs.keySet().toArray(attrNames);

    Iterator it = this.objIdKeyDbos.keySet().iterator();
    while (it.hasNext()) {
      Long key = (Long)it.next();
      GenericDO cachedDbo = (GenericDO)this.objIdKeyDbos.get(key);
      boolean isEqual = true;
      for (int i = 0; i < attrNames.length; i++) {
        Object templateAttrValue = dboTemplate.getAttrValue(attrNames[i]);
        if (templateAttrValue != null)
        {
          Object cachedAttrValue = cachedDbo.getAttrValue(attrNames[i]);
          if (!templateAttrValue.equals(cachedAttrValue)) {
            isEqual = false;
            break;
          }
        }
      }
      if (isEqual) {
        dbos.add(cachedDbo);
      }
    }
    return dbos;
  }

  public synchronized DataObjectList getAllObjByClass() {
    DataObjectList result = new DataObjectList();
    Iterator it = this.objIdKeyDbos.keySet().iterator();
    while (it.hasNext()) {
      Long key = (Long)it.next();
      GenericDO cachedDbo = (GenericDO)this.objIdKeyDbos.get(key);
      result.add(cachedDbo);
    }
    return result;
  }

  public synchronized void clearAll() {
    this.objIdKeyDbos.clear();
    this.cuidKeyDbos.clear();
  }

  private static enum CACHE_TYPE
  {
    TC, EC, LOCAL, MC, BIGMEM, REDIS;
  }
}