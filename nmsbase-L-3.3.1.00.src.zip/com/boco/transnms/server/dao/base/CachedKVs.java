package com.boco.transnms.server.dao.base;

import com.boco.common.util.debug.LogHome;
import com.boco.transnms.common.cache.IDaoCache;
import com.boco.transnms.common.cache.McDaoCache;
import com.boco.transnms.common.cache.RedisDaoCache;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.common.cfg.TnmsServerName;
import org.apache.commons.logging.Log;

public class CachedKVs
{
  private CACHE_TYPE cacheType = CACHE_TYPE.MC;
  private IDaoCache<String, String> cuidKeyDbos;
  private boolean isInitCompleted = false;
  private String name;
  private IDataAccessObject dao;

  public CachedKVs(String _name, String cacheType, IDataAccessObject dao)
  {
    this.cacheType = CACHE_TYPE.valueOf(cacheType);
    this.dao = dao;
    this.name = _name;
    if (this.cacheType == CACHE_TYPE.MC)
      this.cuidKeyDbos = new McDaoCache(_name);
    else if (this.cacheType == CACHE_TYPE.REDIS)
      this.cuidKeyDbos = new RedisDaoCache(_name);
    else
      this.cuidKeyDbos = new McDaoCache(_name);
  }

  public String getValue(String cuid)
  {
    String value = null;
    if (this.isInitCompleted) {
      value = (String)this.cuidKeyDbos.get(cuid);
    }
    return value;
  }

  public String[] getValues(String[] cuids) {
    String[] values = null;
    if (this.isInitCompleted) {
      values = new String[cuids.length];
      for (int i = 0; i < cuids.length; i++) {
        values[i] = ((String)this.cuidKeyDbos.get(cuids[i]));
      }
    }
    return values;
  }

  public void set(String cuid, String value) {
    this.cuidKeyDbos.put(cuid, value);
  }

  public boolean isInitCompleted() {
    return this.isInitCompleted;
  }

  public void setInitCompleted(boolean isInitCompleted) {
    this.isInitCompleted = isInitCompleted;
  }

  public boolean initCache(boolean forceReload) throws Exception {
    setInitCompleted(false);
    if (!this.isInitCompleted)
    {
      KVManager manager = TnmsCacheManagerFactory.getInstance().getKvManager(this.name);
      String tableName = manager.getTableName();
      String cacheFlagName = this.name + "-" + TnmsServerName.getLocalServerFullName();

      if (forceReload) {
        this.cuidKeyDbos.remove(cacheFlagName);
      }
      String loadFinishedFlag = (String)this.cuidKeyDbos.get(cacheFlagName);
      if (loadFinishedFlag == null) {
        LogHome.getLog().info("Memcached KV缓存尚未开始加载：" + tableName);
        loadData();
        loadFinishedFlag = this.name + "_LOADED";
        this.cuidKeyDbos.put(cacheFlagName, loadFinishedFlag);
        LogHome.getLog().info("Memcached KV缓存加载完成：" + tableName);
      } else {
        LogHome.getLog().info("Memcached KV缓存已经加载：" + tableName);
      }
      setInitCompleted(true);
    }
    return this.isInitCompleted;
  }

  public void loadData() throws Exception {
    synchronized (this) {
      KVManager manager = TnmsCacheManagerFactory.getInstance().getKvManager(this.name);
      String tableName = manager.getTableName();
      String keyField = manager.getKeyField();
      String valueField = manager.getValueField();
      GenericDO dbo = new GenericDO();
      dbo.setClassName(tableName);
      GenericDO dboTemplate = dbo.createInstanceByClassName();
      String sql = "select " + keyField + "," + valueField + " from " + tableName;
      DboCollection dbos = this.dao.selectDBOs(new BoQueryContext(), sql, new GenericDO[] { dboTemplate });
      for (int i = 0; i < dbos.size(); i++) {
        GenericDO dto = dbos.getQueryDbo(i, dboTemplate.getClassName());
        String key = dto.getAttrString(keyField);
        String value = dto.getAttrString(valueField);
        set(key, value);
      }
    }
  }

  private static enum CACHE_TYPE
  {
    MC, REDIS;
  }
}