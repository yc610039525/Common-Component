package com.boco.transnms.server.dao.base;

import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;

public abstract interface ICachedDAO
{
  public abstract void addCacheObject(GenericDO paramGenericDO);

  public abstract void updateCacheObject(GenericDO paramGenericDO);

  public abstract void deleteCacheObject(GenericDO paramGenericDO);

  public abstract void updateCacheObjects(DataObjectList paramDataObjectList);
}