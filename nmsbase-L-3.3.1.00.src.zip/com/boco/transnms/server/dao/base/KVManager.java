package com.boco.transnms.server.dao.base;

public class KVManager
{
  private String tableName;
  private String name;
  private int syncInterval = 3600000;
  private String keyField = "CUID";
  private String valueField = "LABEL_CN";
  private String cacheType = "MC_KV";

  public String getTableName() {
    return this.tableName;
  }
  public void setTableName(String tableName) {
    this.tableName = tableName;
  }
  public String getName() {
    return this.name;
  }
  public void setName(String name) {
    this.name = name;
  }
  public int getSyncInterval() {
    return this.syncInterval;
  }
  public void setSyncInterval(int syncInterval) {
    this.syncInterval = syncInterval;
  }
  public String getKeyField() {
    return this.keyField;
  }
  public void setKeyField(String keyField) {
    this.keyField = keyField;
  }
  public String getValueField() {
    return this.valueField;
  }
  public void setValueField(String valueField) {
    this.valueField = valueField;
  }
  public String getCacheType() {
    return this.cacheType;
  }
  public void setCacheType(String cacheType) {
    this.cacheType = cacheType;
  }
}