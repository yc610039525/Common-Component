package com.boco.transnms.server.dao.base;

import java.util.HashMap;
import java.util.Map;

public abstract interface IntegratedCacheManager
{
  public abstract void setServers(HashMap<String, String> paramHashMap);

  public abstract Map getServers();

  public abstract void init();
}