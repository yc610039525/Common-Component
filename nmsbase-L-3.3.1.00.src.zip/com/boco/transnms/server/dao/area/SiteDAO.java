package com.boco.transnms.server.dao.area;

import com.boco.transnms.common.dto.Accesspoint;
import com.boco.transnms.common.dto.JumpFiber;
import com.boco.transnms.common.dto.JumpPair;
import com.boco.transnms.common.dto.Room;
import com.boco.transnms.common.dto.Site;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.dao.base.DaoHelper;
import com.boco.transnms.server.dao.base.GenericDAO;

public class SiteDAO extends GenericDAO
{
  public SiteDAO()
  {
    super("SiteDAO");
  }

  public DataObjectList getIsRoomType(BoActionContext actionContext, String[] value) throws Exception
  {
    String sql = "select * from ROOM where ROOM_TYPE in (" + value + ")";

    return super.getAllObjByClass(new Room(), 0);
  }

  public DataObjectList getAllSite() throws Exception {
    return super.getAllObjByClass(new Site(), 0);
  }

  public Site addSite(BoActionContext actionContext, Site dbo) throws Exception {
    super.createObject(actionContext, dbo);
    return dbo;
  }

  public Site getSite(BoActionContext actionContext, Long objectId)
    throws Exception
  {
    Site dbo = new Site();
    dbo.setObjectNum(objectId.longValue());
    return (Site)super.getObject(dbo);
  }

  public Site getSiteByCuid(BoActionContext actionContext, String cuid) throws Exception {
    Site dbo = new Site();
    if (cuid != null)
      dbo.setCuid(cuid);
    else {
      dbo.setCuid("");
    }
    return (Site)super.getObjByCuid(dbo);
  }

  public DataObjectList getSiteByDistrictCuids(BoActionContext actionContext, String[] cuidarray, String siteName) throws Exception {
    String cuids = "";
    for (int i = 0; i < cuidarray.length; i++) {
      cuids = cuids + ",'" + cuidarray[i] + "'";
    }
    String sql = "RELATED_SPACE_CUID in (" + cuids.substring(1, cuids.length()) + ")";
    if (DaoHelper.isNotEmpty(siteName)) {
      sql = sql + " and " + "LABEL_CN" + " like '%" + siteName + "%'";
    }
    Site dbo = new Site();
    return super.getObjectsBySql(sql, dbo, 0);
  }

  public void delSite(BoActionContext actionContext, Long objectId) throws Exception {
    Site dbo = new Site();
    dbo.setObjectNum(objectId.longValue());
    super.deleteObject(actionContext, dbo);
  }

  public void modifySite(BoActionContext actionContext, Site dbo) throws Exception {
    dbo.clearUnknowAttrs();
    dbo.convAllObjAttrToCuid();
    super.updateObject(actionContext, dbo);
  }

  public DataObjectList querySite(String relatedSpaceCuid, String labelCn, String contactAddress, Boolean includeChild, Boolean province, Boolean city, Boolean county, String siteTypes)
    throws Exception
  {
    String sql = new String();
    String seviceLevel = new String();
    if (province.booleanValue()) {
      seviceLevel = seviceLevel + "," + 1L;
    }
    if (city.booleanValue()) {
      seviceLevel = seviceLevel + "," + 2L;
    }
    if (county.booleanValue()) {
      seviceLevel = seviceLevel + "," + 3L;
    }

    if (relatedSpaceCuid.length() != 0) {
      String[] cuids = relatedSpaceCuid.split(",");
      String cuid = new String();
      for (int i = 0; i < cuids.length; i++) {
        cuid = cuid + ",'" + cuids[i] + "'";
      }
      cuid = cuid.substring(1, cuid.length());
      sql = sql + "and " + "RELATED_SPACE_CUID" + " in (" + cuid + ") ";
    }
    if (labelCn.length() != 0) {
      sql = sql + "and " + "LABEL_CN" + " like '%" + labelCn + "%' ";
    }
    if (contactAddress.length() != 0) {
      sql = sql + "and " + "CONTACT_ADDRESS" + " like '%" + contactAddress + "%' ";
    }
    if (seviceLevel.length() > 0) {
      seviceLevel = seviceLevel.substring(1, seviceLevel.length());
      sql = sql + "and " + "SERVICE_LEVEL" + " in (" + seviceLevel + ")";
    }
    DataObjectList dbos;
    DataObjectList dbos;
    if (sql.length() > 0) {
      sql = sql.substring(4, sql.length());
      dbos = super.getObjectsBySql(sql, new Site(), 0);
    } else {
      dbos = super.getAllObjByClass(new Site(), 0);
    }
    if (siteTypes.trim().length() > 0) {
      DataObjectList sites = new DataObjectList();
      String[] keys = siteTypes.split(",");
      for (int j = 0; j < dbos.size(); j++) {
        Site dbo = (Site)dbos.get(j);
        for (int i = 0; i < keys.length; i++) {
          if (dbo.getSiteType().indexOf(keys[i]) >= 0) {
            sites.add(dbo);
            break;
          }
        }
      }
      return sites;
    }
    return dbos;
  }

  public DboCollection querySiteByPageCondition(BoQueryContext queryContext, String condition) throws Exception
  {
    DboCollection rtn = null;
    String sql = "";
    if (condition.length() > 0) {
      sql = "select * from SITE where " + condition;
      sql = sql + " order by LABEL_CN";
      rtn = super.selectDBOs(queryContext, sql, new GenericDO[] { new Site() });
    } else {
      sql = "select * from SITE  order by LABEL_CN";
      rtn = super.selectDBOs(queryContext, sql, new GenericDO[] { new Site() });
    }
    return rtn;
  }

  public DboCollection getAccessByPageCondition(BoQueryContext queryContext, String condition) throws Exception {
    DboCollection rtn = null;
    String sql = "";
    if (condition.length() > 0) {
      sql = "select * from ACCESSPOINT where " + condition;
      sql = sql + " order by LABEL_CN";
      rtn = super.selectDBOs(queryContext, sql, new GenericDO[] { new Accesspoint() });
    } else {
      sql = "select * from ACCESSPOINT  order by LABEL_CN";
      rtn = super.selectDBOs(queryContext, sql, new GenericDO[] { new Accesspoint() });
    }
    return rtn;
  }

  public DataObjectList querySiteLabelAndCuidByPageCondition(BoQueryContext queryContext, String condition) throws Exception {
    DataObjectList rtn = null;
    String sql = "";
    if (condition.length() > 0) {
      sql = "select LABEL_CN,CUID from SITE where " + condition;
      sql = sql + " order by LABEL_CN";
      rtn = super.selectDBOs(queryContext, sql, new Class[] { String.class, String.class });
    } else {
      sql = "select LABEL_CN,CUID from SITE  order by LABEL_CN";
      rtn = super.selectDBOs(sql, new Class[] { String.class, String.class });
    }
    return rtn;
  }

  public DboCollection querySiteByPage(BoQueryContext queryContext, String relatedSpaceCuid, String labelCn, String contactAddress, Boolean includeChild, Long serviceLevel, String siteTypes, String querySitecoding, Long oLevel, Long ownerShip, String orderString, String filterSql)
    throws Exception
  {
    String sql = new String();
    if ((filterSql != null) && (filterSql.trim().length() > 0))
      sql = sql + "and " + filterSql;
    else if ((relatedSpaceCuid != null) && (relatedSpaceCuid.trim().length() > 0)) {
      if (includeChild.booleanValue())
        sql = sql + "and " + "RELATED_SPACE_CUID" + " like '" + relatedSpaceCuid + "%' ";
      else {
        sql = sql + "and " + "RELATED_SPACE_CUID" + "='" + relatedSpaceCuid + "'";
      }
    }
    if (querySitecoding.length() != 0) {
      sql = sql + " and " + "SITECODING" + " like '%" + querySitecoding + "%' ";
    }
    if (labelCn.length() != 0) {
      sql = sql + "and (" + "LABEL_CN" + " like '%" + labelCn + "%'  or " + "SPELLABBREVIATION" + " like '%" + labelCn + "%') ";
    }
    if (contactAddress.length() != 0) {
      sql = sql + "and " + "CONTACT_ADDRESS" + " like '%" + contactAddress + "%' ";
    }
    if (serviceLevel.longValue() != -1L) {
      sql = sql + "and " + "SERVICE_LEVEL" + "=" + serviceLevel;
    }
    if (siteTypes.trim().length() > 0) {
      sql = sql + "and ( ";
      String[] keys = siteTypes.split(",");
      String sql1 = "";
      String sql2 = "";
      String sql3 = "";
      for (int i = 0; i < keys.length; i++) {
        sql1 = "SITE_TYPE like '%" + keys[i] + "%' or ";
        sql2 = sql2 + sql1;
      }
      sql3 = sql2.substring(0, sql2.length() - 3);
      sql = sql + sql3 + " )";
    }
    if (oLevel.longValue() != -1L) {
      sql = sql + "and " + "OLEVEL" + "=" + oLevel;
    }
    if (ownerShip.longValue() != -1L) {
      sql = sql + "and " + "OWNERSHIP" + "=" + ownerShip;
    }

    if ((orderString == null) || (orderString.trim().length() == 0))
      orderString = "LABEL_CN , OWNERSHIP";
    DboCollection dbos;
    DboCollection dbos;
    if (sql.length() > 0) {
      sql = "select * from SITE where " + sql.substring(4, sql.length());
      sql = sql + " order by " + orderString;
      dbos = super.selectDBOs(queryContext, sql, new GenericDO[] { new Site() });
    } else {
      sql = "select * from SITE  order by " + orderString;
      dbos = super.selectDBOs(queryContext, sql, new GenericDO[] { new Site() });
    }
    return dbos;
  }

  public DataObjectList getChildRoom(String siteCuids) throws Exception {
    if (siteCuids.trim().length() > 0) {
      String[] cuidarray = siteCuids.split(",");
      String cuids = new String();
      for (int i = 0; i < cuidarray.length; i++) {
        cuids = cuids + ",'" + cuidarray[i] + "'";
      }
      String sql = "RELATED_SITE_CUID in (" + cuids.substring(1, cuids.length()) + ")";
      return super.getObjectsBySql(sql, new Room(), 0);
    }
    return super.getAllObjByClass(new Room(), 0);
  }

  public DataObjectList getChildRoomByRoomName(String siteCuids, String roomName) throws Exception
  {
    if (siteCuids.trim().length() > 0) {
      String[] cuidarray = siteCuids.split(",");
      String cuids = new String();
      for (int i = 0; i < cuidarray.length; i++) {
        cuids = cuids + ",'" + cuidarray[i] + "'";
      }
      String sql = "";
      if ((roomName != null) && (roomName.trim().length() > 0)) {
        sql = "RELATED_SITE_CUID in (" + cuids.substring(1, cuids.length()) + ") and " + "LABEL_CN" + " like '%" + roomName + "%'";
      }
      else {
        sql = "RELATED_SITE_CUID in (" + cuids.substring(1, cuids.length()) + ")";
      }
      return super.getObjectsBySql(sql, new Room(), 0);
    }
    return super.getAllObjByClass(new Room(), 0);
  }

  public DboCollection getChildRoomBycuidorRoomName(BoQueryContext queryContext, String siteCuids, String roomName, String orderString, String filterSql)
    throws Exception
  {
    String sql = "";
    if (orderString.trim().length() > 0) {
      orderString = " order by " + orderString;
    }
    if (siteCuids.trim().length() > 0) {
      String[] cuidarray = siteCuids.split(",");
      String cuids = new String();
      for (int i = 0; i < cuidarray.length; i++) {
        cuids = cuids + ",'" + cuidarray[i] + "'";
      }
      if ((roomName != null) && (roomName.trim().length() > 0)) {
        sql = "RELATED_SITE_CUID in (" + cuids.substring(1, cuids.length()) + ") and " + "LABEL_CN" + " like '%" + roomName + "%'";
      }
      else {
        sql = "RELATED_SITE_CUID in (" + cuids.substring(1, cuids.length()) + ")";
      }
      if ((filterSql != null) && (filterSql.trim().length() > 0))
        sql = "select * from ROOM where " + sql + " and " + filterSql + " " + orderString;
      else {
        sql = "select * from ROOM where " + sql + orderString;
      }
      return super.selectDBOs(queryContext, sql, new GenericDO[] { new Room() });
    }
    if ((roomName != null) && (roomName.trim().length() > 0)) {
      sql = "select * from ROOM where LABEL_CN like '%" + roomName + "%'" + orderString;
      return super.selectDBOs(queryContext, sql, new GenericDO[] { new Room() });
    }
    sql = "select * from ROOM" + orderString;
    return super.selectDBOs(queryContext, sql, new GenericDO[] { new Room() });
  }

  public Site getSiteOfRoom(BoActionContext actionContext, Room room)
    throws Exception
  {
    if (room != null) {
      return (Site)super.getObjByCuid(room.getRelatedSiteCuid());
    }
    return null;
  }

  public String getCuidByLabelcn(BoActionContext actionContext, String labelcn)
    throws Exception
  {
    String sql = "LABEL_CN='" + labelcn + "'";
    DataObjectList sites = super.getObjectsBySql(sql, new Site(), 0);
    if (sites.size() > 0) {
      return ((GenericDO)sites.get(0)).getCuid();
    }
    return "";
  }

  public DataObjectList getSiteByName(BoActionContext actionContext, String name) throws Exception {
    DataObjectList sites = new DataObjectList();
    if (DaoHelper.isNotEmpty(name)) {
      String sql = "LABEL_CN like '%" + name + "%'";
      sites = super.getObjectsBySql(sql, new Site(), 0);
    }
    return sites;
  }

  public DboCollection getSiteByDistrictCuidAndSiteName(BoQueryContext boQueryContext, String districtCuid, String siteName, Boolean includeChildDistrict, String whereSql)
    throws Exception
  {
    StringBuffer sql = new StringBuffer("select * from SITE where 1=1 ");
    if ((whereSql == null) || (whereSql.trim().length() == 0)) {
      if (DaoHelper.isNotEmpty(districtCuid)) {
        if (includeChildDistrict.booleanValue())
          sql.append(" and RELATED_SPACE_CUID like '" + districtCuid + "%'");
        else
          sql.append(" and RELATED_SPACE_CUID = '" + districtCuid + "'");
      }
    }
    else {
      sql.append(" and " + whereSql);
    }
    if (DaoHelper.isNotEmpty(siteName)) {
      sql.append(" and (LABEL_CN like '%" + siteName + "%' or " + "SPELLABBREVIATION" + " like '%" + siteName + "%')");
    }
    sql.append(" order by LABEL_CN");
    return super.selectDBOs(boQueryContext, sql.toString(), new GenericDO[] { new Site() });
  }

  public void addSiteCfgType(int key, String value) throws Exception {
    String sql = "INSERT INTO SITE_CFG_TYPE (KEY_NUM,KEY_VALUE) VALUES(" + key + ",'" + value + "')";
    super.execSql(sql);
  }

  public DataObjectList getSiteCfgType() throws Exception {
    String sql = "select KEY_NUM,KEY_VALUE from SITE_CFG_TYPE order by KEY_NUM";
    return super.selectDBOs(sql, new Class[] { Integer.TYPE, String.class });
  }

  public DataObjectList getRoomCfgType() throws Exception
  {
    String sql = "select KEY_NUM,KEY_VALUE from ROOM_CFG_TYPE order by KEY_NUM";
    return super.selectDBOs(sql, new Class[] { Integer.TYPE, String.class });
  }

  public DataObjectList getSwitchCfgType()
    throws Exception
  {
    String sql = "select KEY_NUM,KEY_VALUE from SWITCHDEV_CFG_TYPE order by KEY_NUM";
    return super.selectDBOs(sql, new Class[] { Integer.TYPE, String.class });
  }

  public void modifySiteCfgType(int key, String value) throws Exception
  {
    String sql = "UPDATE SITE_CFG_TYPE SET KEY_VALUE = '" + value + "' where KEY_NUM =" + key;
    super.execSql(sql);
  }

  public void delSiteCfgType(String[] objectid) throws Exception {
    for (int i = 0; i < objectid.length; i++) {
      String sql = "DELETE FROM SITE_CFG_TYPE where KEY_NUM =" + objectid[i];
      super.execSql(sql);
    }
  }

  public void addSwitchCfgType(int key, String value) throws Exception {
    String sql = "INSERT INTO SWITCHDEV_CFG_TYPE (KEY_NUM,KEY_VALUE) VALUES(" + key + ",'" + value + "')";
    super.execSql(sql);
  }

  public void modifySwitchCfgType(int key, String value) throws Exception {
    String sql = "UPDATE SWITCHDEV_CFG_TYPE SET KEY_VALUE = '" + value + "' where KEY_NUM =" + key;
    super.execSql(sql);
  }

  public void delSwitchCfgType(String[] objectid) throws Exception {
    for (int i = 0; i < objectid.length; i++) {
      String sql = "DELETE FROM SWITCHDEV_CFG_TYPE where KEY_NUM =" + objectid[i];
      super.execSql(sql);
    }
  }

  public DataObjectList getSiteTypeInfo() throws Exception
  {
    String sql = "select distinct SITE_TYPE from SITE";
    return super.selectDBOs(sql, new Class[] { String.class });
  }

  public DataObjectList getAllSiteCuidAndRelatedSpaceCuid() throws Exception {
    String sql = "select CUID,RELATED_SPACE_CUID FROM SITE";
    return super.selectDBOs(sql, new Class[] { String.class, String.class });
  }

  public DataObjectList getAllSiteCuidAndLabelCn() throws Exception {
    String sql = "select CUID,LABEL_CN from SITE order by LABEL_CN";
    return super.selectDBOs(sql, new Class[] { String.class, String.class });
  }

  public void delPointAnalyseConf(BoActionContext actionContext, String value)
    throws Exception
  {
    String sql = "DELETE FROM LAYER_ANSYS_INFRO";
    super.execSql(sql);
  }

  public JumpPair getJumpPairByCuid(BoActionContext actionContext, String cuid)
    throws Exception
  {
    JumpPair dbo = new JumpPair();
    dbo.setCuid(cuid);
    return (JumpPair)super.getObjByCuid(dbo);
  }

  public JumpFiber getJumpFiberByCuid(BoActionContext actionContext, String cuid) throws Exception {
    JumpFiber dbo = new JumpFiber();
    dbo.setCuid(cuid);
    return (JumpFiber)super.getObjByCuid(dbo);
  }
  public DataObjectList getSiteBtnEle() throws Exception {
    DataObjectList dbos = null;
    String sql = "select SITE.LABEL_CN ,BTS_TO_NE.NO,BTS_TO_NE.LABEL_CN , TRANS_ELEMENT.LABEL_CN,DISTRICT.LABEL_CN from SITE left join BTS_TO_NE on BTS_TO_NE.RELATED_SITE_CUID = SITE.CUID left join TRANS_ELEMENT on TRANS_ELEMENT.CUID = BTS_TO_NE.RELATED_NE_CUID left join DISTRICT on DISTRICT.CUID = substr(SITE.RELATED_SPACE_CUID,0,26)  order by SITE.CUID,SITE.LABEL_CN";

    dbos = super.selectDBOs(sql, new Class[] { String.class, String.class, String.class, String.class, String.class });
    return dbos;
  }
}