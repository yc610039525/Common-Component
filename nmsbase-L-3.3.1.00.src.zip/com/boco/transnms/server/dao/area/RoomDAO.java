package com.boco.transnms.server.dao.area;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.Miscrack;
import com.boco.transnms.common.dto.Odf;
import com.boco.transnms.common.dto.Room;
import com.boco.transnms.common.dto.SwitchElement;
import com.boco.transnms.common.dto.SysUser;
import com.boco.transnms.common.dto.TransElement;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.dao.base.AbstractDAO;
import com.boco.transnms.server.dao.base.DaoHelper;
import java.util.Map;
import org.apache.commons.logging.Log;

public class RoomDAO extends AbstractDAO
{
  public RoomDAO()
  {
    super("RoomDAO");
  }

  public DataObjectList getAllRoom(BoActionContext actionContext) throws Exception {
    return super.getAllObjByClass(new Room(), 0);
  }

  public Room addRoom(BoActionContext actionContext, Room dbo) throws Exception {
    super.createObject(actionContext, dbo);
    return dbo;
  }

  public Room getRoom(BoActionContext actionContext, Long objectId) throws Exception {
    Room dbo = new Room();
    dbo.setObjectNum(objectId.longValue());
    return (Room)super.getObject(dbo);
  }

  public Room getRoomByCuid(BoActionContext actionContext, String cuid) throws Exception {
    Room dbo = new Room();
    dbo.setCuid(cuid);
    return (Room)super.getObjByCuid(dbo);
  }

  public DataObjectList getRoomBySiteCuids(BoActionContext actionContext, String[] cuidarray) throws Exception {
    String cuids = "";
    for (int i = 0; i < cuidarray.length; i++) {
      cuids = cuids + ",'" + cuidarray[i] + "'";
    }
    String sql = "RELATED_SITE_CUID in (" + cuids.substring(1, cuids.length()) + ")";
    Room dbo = new Room();
    return super.getObjectsBySql(sql, dbo, 0);
  }

  public DataObjectList getRoomBySiteCuid(BoActionContext actionContext, String siteCuid) throws Exception {
    String sql = "RELATED_SITE_CUID = '" + siteCuid + "'";
    Room dbo = new Room();
    return super.getObjectsBySql(sql, dbo, 0);
  }

  public DataObjectList getRoomByFloorCuid(BoActionContext actionContext, String floorCuid) throws Exception {
    String sql = "RELATED_FLOOR_CUID = '" + floorCuid + "'";
    Room dbo = new Room();
    return super.getObjectsBySql(sql, dbo, 0);
  }

  public DataObjectList getRoomByDistrictCuid(BoActionContext actionContext, String cuid, String roomName) throws Exception
  {
    String sql = "select * from ROOM WHERE RELATED_SPACE_CUID='" + cuid + "' LABEL_CN LIKE '%" + roomName + "%'";

    Room room = new Room();
    DboCollection dbocon = super.selectDBOs(sql, new GenericDO[] { room });
    DataObjectList dbos = new DataObjectList();

    if (dbocon != null) {
      for (int i = 0; i < dbocon.size(); i++) {
        Room dbo = (Room)dbocon.getAttrField("ROOM", i);
        dbos.add(dbo);
      }
    }
    return dbos;
  }

  public DboCollection getRoomByPageCondition(BoQueryContext boQueryContext, String districtCuid, String siteCuids, String roomName, SysUser user, Boolean isIncludeChild, Map map, String roomType, String serviceLevel2) throws Exception {
    String sql = "";
    String sqltemp = "";
    String sqltempR = "";
    if ((boQueryContext != null) && (boQueryContext.getUserId() != null) && (!boQueryContext.isActionChecked()) && (!"SYS_USER-0".equals(user.getCuid())))
    {
      long serviceLevel = user.getUserLevel();
      String newUserLevel = user.getNewUserLevel();
      if ((newUserLevel.indexOf("2") >= 0) || (newUserLevel.indexOf("4") >= 0) || (newUserLevel.indexOf("5") >= 0) || (newUserLevel.indexOf("6") >= 0)) {
        newUserLevel = newUserLevel + ",3";
      }
      sqltemp = sqltemp + "SERVICE_LEVEL IN(" + newUserLevel + ")";
      sqltempR = sqltempR + " R.SERVICE_LEVEL IN(" + newUserLevel + ")";
    }

    String queryRoomNo = (String)map.get("queryRoomNo");
    String orderString = (String)map.get("orderString");
    if ((siteCuids != null) && (!siteCuids.trim().equals("")))
    {
      String[] cuidarray = siteCuids.split(",");
      String cuids = new String();
      for (int i = 0; i < cuidarray.length; i++) {
        cuids = cuids + "'" + cuidarray[i] + "'";
        if (i < cuidarray.length - 1) {
          cuids = cuids + ",";
        }
      }
      sql = "select * from ROOM where RELATED_SITE_CUID in (" + cuids + ")";
      if ((roomName != null) && (roomName.trim().length() > 0)) {
        sql = sql + " and LABEL_CN like '%" + roomName + "%'";
      }
      if ((queryRoomNo != null) && (queryRoomNo.trim().length() > 0)) {
        sql = sql + " and ROOM_NO like '%" + queryRoomNo + "%'";
      }
      if ((roomType != null) && (roomType.trim().length() > 0) && (!roomType.equals("-1"))) {
        sql = sql + " and " + "ROOM_TYPE" + " like '%" + roomType + "%'";
      }
      if ((serviceLevel2 != null) && (serviceLevel2.trim().length() > 0) && (!serviceLevel2.equals("-1"))) {
        sql = sql + " and " + "SERVICE_LEVEL" + " = " + serviceLevel2;
      }
      if (sqltemp.trim().length() > 0) {
        sql = sql + " AND " + sqltemp;
      }

      if ((orderString != null) && (orderString.trim().length() > 0)) {
        sql = sql + " ORDER BY " + orderString;
      }

    }
    else if ((districtCuid != null) && (!districtCuid.equals(""))) {
      sql = "select * from ROOM WHERE LABEL_CN LIKE '%" + roomName + "%'";

      if (isIncludeChild.booleanValue())
        sql = sql + " AND " + "RELATED_SPACE_CUID" + " LIKE '" + districtCuid + "%'";
      else {
        sql = sql + " AND " + "RELATED_SPACE_CUID" + " ='" + districtCuid + "'";
      }
      if ((queryRoomNo != null) && (queryRoomNo.trim().length() > 0)) {
        sql = sql + " AND " + "ROOM_NO" + " like '%" + queryRoomNo + "%'";
      }
      if ((roomType != null) && (roomType.trim().length() > 0) && (!roomType.equals("-1"))) {
        sql = sql + " AND " + "ROOM_TYPE" + " like '%" + roomType + "%'";
      }
      if ((serviceLevel2 != null) && (serviceLevel2.trim().length() > 0) && (!serviceLevel2.equals("-1"))) {
        sql = sql + " AND " + "SERVICE_LEVEL" + " = " + serviceLevel2;
      }
      if (sqltemp.trim().length() > 0) {
        sql = sql + " AND " + sqltemp;
      }
      if ((orderString != null) && (orderString.trim().length() > 0))
        sql = sql + " ORDER BY " + orderString;
    }
    else if ((roomName != null) && (!roomName.equals(""))) {
      sql = "select * from ROOM where LABEL_CN like '%" + roomName + "%'";
      if ((queryRoomNo != null) && (queryRoomNo.trim().length() > 0)) {
        sql = sql + " AND " + "ROOM_NO" + " like '%" + queryRoomNo + "%'";
      }
      if ((roomType != null) && (roomType.trim().length() > 0) && (!roomType.equals("-1"))) {
        sql = sql + " AND " + "ROOM_TYPE" + " like '%" + roomType + "%'";
      }
      if ((serviceLevel2 != null) && (serviceLevel2.trim().length() > 0) && (!serviceLevel2.equals("-1"))) {
        sql = sql + " AND " + "SERVICE_LEVEL" + " = " + serviceLevel2;
      }
      if (sqltemp.trim().length() > 0) {
        sql = sql + " AND " + sqltemp;
      }
      if ((orderString != null) && (orderString.trim().length() > 0))
        sql = sql + " ORDER BY " + orderString;
    }
    else {
      sql = "select * from ROOM where 1=1 ";
      if ((queryRoomNo != null) && (queryRoomNo.trim().length() > 0)) {
        sql = sql + " and " + "ROOM_NO" + " like '%" + queryRoomNo + "%'";
      }
      if ((roomType != null) && (roomType.trim().length() > 0)) {
        sql = sql + " and " + "ROOM_TYPE" + " like '%" + roomType + "%'";
      }
      if ((serviceLevel2 != null) && (serviceLevel2.trim().length() > 0)) {
        sql = sql + " and " + "SERVICE_LEVEL" + " = " + serviceLevel2;
      }
      if (sqltemp.trim().length() > 0) {
        sql = sql + " and " + sqltemp;
      }
      if ((orderString != null) && (orderString.trim().length() > 0)) {
        sql = sql + " ORDER BY " + orderString;
      }
    }
    return super.selectDBOs(boQueryContext, sql, new GenericDO[] { new Room() });
  }

  public void delRoom(BoActionContext actionContext, Long objectId) throws Exception {
    Room dbo = new Room();
    dbo.setObjectNum(objectId.longValue());
    super.deleteObject(actionContext, dbo);
  }

  public void modifyRoom(BoActionContext actionContext, Room dbo) throws Exception {
    super.updateObject(actionContext, dbo);
  }

  public DataObjectList getChildSwitch(BoActionContext actionContext, String roomCuids) throws Exception {
    if (roomCuids.trim().length() > 0) {
      String[] cuidarray = roomCuids.split(",");
      String cuids = new String();
      for (int i = 0; i < cuidarray.length; i++) {
        cuids = cuids + ",'" + cuidarray[i] + "'";
      }
      String sql = "RELATED_ROOM_CUID in (" + cuids.substring(1, cuids.length()) + ")";
      return super.getObjectsBySql(sql, new SwitchElement(), 0);
    }
    return super.getAllObjByClass(new SwitchElement(), 0);
  }

  public DboCollection getSwitchElementByLabelcnAndRoomCuidByPage(BoQueryContext boQueryContext, String labelcn, String roomCuid)
    throws Exception
  {
    StringBuffer sql = new StringBuffer("select * from SWITCH_ELEMENT where 1=1 ");
    if (DaoHelper.isNotEmpty(labelcn)) {
      sql.append(" and LABEL_CN like '%" + labelcn + "%'");
    }
    if (DaoHelper.isNotEmpty(roomCuid)) {
      sql.append(" and RELATED_ROOM_CUID = '" + roomCuid + "'");
    }
    return super.selectDBOs(boQueryContext, sql.toString(), new GenericDO[] { new SwitchElement() });
  }

  public DboCollection getSwitchElementByCuidByPage(BoQueryContext boQueryContext, String cuid) throws Exception {
    StringBuffer sql = new StringBuffer("select * from SWITCH_ELEMENT where 1=1 ");
    if (DaoHelper.isNotEmpty(cuid)) {
      sql.append(" and CUID = '" + cuid + "'");
    }
    return super.selectDBOs(boQueryContext, sql.toString(), new GenericDO[] { new SwitchElement() });
  }

  public DataObjectList getChildElement(BoActionContext actionContext, String roomCuids) throws Exception
  {
    if (roomCuids.trim().length() > 0) {
      String[] cuidarray = roomCuids.split(",");
      String cuids = new String();
      for (int i = 0; i < cuidarray.length; i++) {
        cuids = cuids + ",'" + cuidarray[i] + "'";
      }
      String sql = "RELATED_ROOM_CUID in (" + cuids.substring(1, cuids.length()) + ")";
      return super.getObjectsBySql(sql, new TransElement(), 0);
    }
    return super.getAllObjByClass(new TransElement(), 0);
  }

  public String getCuidByLabelcn(BoActionContext actionContext, String labelcn) throws Exception
  {
    String sql = "LABEL_CN='" + labelcn + "'";
    DataObjectList rooms = super.getObjectsBySql(sql, new Room(), 0);
    if (rooms.size() > 0) {
      return ((GenericDO)rooms.get(0)).getCuid();
    }
    return "";
  }

  public DataObjectList getRoomByName(BoActionContext actionContext, String name) throws Exception {
    DataObjectList rooms = new DataObjectList();
    if (DaoHelper.isNotEmpty(name)) {
      String sql = "LABEL_CN like '%" + name + "%'";
      rooms = super.getObjectsBySql(sql, new Room(), 0);
    }
    return rooms;
  }

  public DataObjectList getRoomBySiteAndName(BoActionContext actionContext, String cuid, String name) throws Exception {
    DataObjectList rooms = new DataObjectList();
    if ((DaoHelper.isNotEmpty(name)) && (DaoHelper.isNotEmpty(cuid))) {
      String sql = "LABEL_CN = '" + name + "'";
      sql = sql + " and " + "RELATED_SITE_CUID" + " = '" + cuid + "'";
      rooms = super.getObjectsBySql(sql, new Room(), 0);
    }
    return rooms;
  }

  public DataObjectList getOdfByRoomAndName(BoActionContext actionContext, String cuid, String name) throws Exception
  {
    DataObjectList odfs = new DataObjectList();
    if ((DaoHelper.isNotEmpty(name)) && (DaoHelper.isNotEmpty(cuid))) {
      String sql = "LABEL_CN = '" + name + "'";
      sql = sql + " and " + "RELATED_ROOM_CUID" + " = '" + cuid + "'";
      odfs = super.getObjectsBySql(sql, new Odf(), 0);
    }
    return odfs;
  }

  public DataObjectList getMiscrackByRoomAndName(BoActionContext actionContext, String cuid, String name) throws Exception
  {
    DataObjectList miscracks = new DataObjectList();
    if ((DaoHelper.isNotEmpty(name)) && (DaoHelper.isNotEmpty(cuid))) {
      String sql = "LABEL_CN = '" + name + "'";
      sql = sql + " and " + "RELATED_ROOM_CUID" + " = '" + cuid + "'";
      miscracks = super.getObjectsBySql(sql, new Miscrack(), 0);
    }
    return miscracks;
  }

  public DboCollection getRoomByRoomName(BoQueryContext boQueryContext, String roomName) throws Exception {
    StringBuffer sql = new StringBuffer("select * from ROOM where 1=1 ");
    if (DaoHelper.isNotEmpty(roomName)) {
      sql.append(" and LABEL_CN like '%" + roomName + "%'");
    }
    return super.selectDBOs(boQueryContext, sql.toString(), new GenericDO[] { new Room() });
  }

  public DboCollection getRoomByRoomNameNew(BoQueryContext boQueryContext, String sql) throws Exception {
    return super.selectDBOs(boQueryContext, sql, new GenericDO[] { new Room() });
  }

  public DataObjectList getRoomTypeInfo() throws Exception
  {
    String sql = "select distinct ROOM_TYPE from ROOM";
    return super.selectDBOs(sql, new Class[] { String.class });
  }

  public int getRoomCountBySql(BoActionContext actionContext, String sql) throws Exception
  {
    try {
      return super.getCalculateValue(actionContext, sql);
    } catch (Exception ex) {
      LogHome.getLog().info("查询机房个数出错" + ex.getMessage());
      throw new UserException("查询机房个数出错" + ex.getMessage());
    }
  }

  public DboCollection getAllRoomCuidAndLabelCn(BoActionContext actionContext) throws Exception {
    String sql = "select CUID,LABEL_CN, RELATED_SITE_CUID from ROOM order by LABEL_CN";
    return super.selectDBOs(sql, new GenericDO[] { new Room() });
  }
}