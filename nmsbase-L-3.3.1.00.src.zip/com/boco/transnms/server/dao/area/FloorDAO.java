package com.boco.transnms.server.dao.area;

import com.boco.common.util.debug.LogHome;
import com.boco.common.util.except.UserException;
import com.boco.transnms.common.dto.Floor;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.dao.base.AbstractDAO;
import org.apache.commons.logging.Log;

public class FloorDAO extends AbstractDAO
{
  public FloorDAO()
  {
    super("FloorDAO");
  }

  public DataObjectList getAllFloor() throws Exception {
    return super.getAllObjByClass(new Floor(), 0);
  }

  public Floor addFloor(BoActionContext actionContext, Floor dbo) throws Exception {
    super.createObject(actionContext, dbo);
    return dbo;
  }

  public Floor getFloor(BoActionContext actionContext, Long objectId) throws Exception {
    Floor dbo = new Floor();
    dbo.setObjectNum(objectId.longValue());
    return (Floor)super.getObject(dbo);
  }

  public Floor getFloorByCuid(String cuid) throws Exception {
    Floor dbo = new Floor();
    dbo.setCuid(cuid);
    return (Floor)super.getObjByCuid(dbo);
  }

  public void delFloor(BoActionContext actionContext, Long objectId) throws Exception {
    Floor dbo = new Floor();
    dbo.setObjectNum(objectId.longValue());
    super.deleteObject(actionContext, dbo);
  }

  public void modifyFloor(BoActionContext actionContext, Floor dbo) throws Exception {
    super.updateObject(actionContext, dbo);
  }

  public DataObjectList getFloorBySiteCuid(String relatedSpaceCuid) throws Exception {
    String sql = new String();
    if (relatedSpaceCuid.length() > 0) {
      sql = "RELATED_SPACE_CUID='" + relatedSpaceCuid + "'";
      return super.getObjectsBySql(sql, new Floor(), 0);
    }
    return super.getAllObjByClass(new Floor(), 0);
  }

  public String getCuidByFloor(BoActionContext actionContext, Floor floor)
    throws Exception
  {
    String sql = "FLOOR_NUM=" + floor.getFloorNum() + " and " + "RELATED_SPACE_CUID" + "='" + floor.getRelatedSpaceCuid() + "'";

    DataObjectList floors = super.getObjectsBySql(sql, new Floor(), 0);
    if (floors.size() > 0) {
      return ((GenericDO)floors.get(0)).getCuid();
    }
    return "";
  }

  public DboCollection getFloorBySiteCuidByPage(BoQueryContext queryContext, String relatedSpaceCuid, String sortFieldId) throws Exception {
    String sql = new String();
    if (sortFieldId.length() > 0)
      sql = "select * from FLOOR where RELATED_SPACE_CUID='" + relatedSpaceCuid + "' order by " + sortFieldId;
    else {
      sql = "select * from FLOOR where RELATED_SPACE_CUID='" + relatedSpaceCuid + "' order by " + "RELATED_SPACE_CUID" + "," + "FLOOR_NUM";
    }

    return super.selectDBOs(queryContext, sql, new GenericDO[] { new Floor() });
  }

  public int getFloorCountBySql(BoActionContext actionContext, String sql) throws Exception
  {
    try {
      return super.getCalculateValue(actionContext, sql);
    } catch (Exception ex) {
      LogHome.getLog().info("查询楼层个数出错" + ex.getMessage());
      throw new UserException("查询楼层个数出错" + ex.getMessage());
    }
  }
}