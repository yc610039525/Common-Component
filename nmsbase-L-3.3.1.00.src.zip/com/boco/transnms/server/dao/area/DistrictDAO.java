package com.boco.transnms.server.dao.area;

import com.boco.transnms.common.dto.DeviceVendor;
import com.boco.transnms.common.dto.District;
import com.boco.transnms.common.dto.Site;
import com.boco.transnms.common.dto.TLogicNumberRange;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.dao.base.CachedObjectDAO;
import com.boco.transnms.server.dao.base.GenericDAO;
import com.boco.transnms.server.dao.base.IDataAccessObject;
import com.boco.transnms.server.dao.base.MemCachedObjectDAO;
import java.util.HashMap;
import java.util.Map;

public class DistrictDAO extends GenericDAO
{
  public DistrictDAO()
  {
    super("DistrictDAO");
  }

  public DataObjectList getAllTreePointDistrict() throws Exception {
    return super.getAllObjByClass(new District(), 0);
  }

  public DataObjectList getProvinceDistrict(String districtCuid) throws Exception
  {
    String sql = "CUID='" + districtCuid + "'";
    DataObjectList dbos = super.getObjectsBySql(sql, new District(), 0);
    if ((dbos != null) && (dbos.size() > 0)) {
      District dbo = (District)dbos.get(0);
      if (dbo.getDataType() == 2L) {
        sql = "RELATED_SPACE_CUID='" + dbo.getCuid() + "'";
        return super.getObjectsBySql(sql, new District(), 0);
      }if (dbo.getDataType() == 1L) {
        sql = "DATA_TYPE=" + 2L;
        return super.getObjectsBySql(sql, new District(), 0);
      }
      return null;
    }

    return null;
  }

  public void modifyLevelDistrict(BoActionContext actionContext, String[] districtObjectIds) throws Exception
  {
    for (int i = 0; i < districtObjectIds.length; i++) {
      District dbo = new District();
      dbo.setObjectNum(Long.valueOf(districtObjectIds[i]).longValue());
      Map attr = new HashMap();
      attr.put("SEVICE_LEADER_CODE", Long.valueOf(districtObjectIds.length - i));
      DataObjectList dbos = new DataObjectList();
      dbos.add(dbo);
      super.updateObjects(actionContext, dbos, attr);
    }
  }

  public DataObjectList getDeviceVendor(BoActionContext actionContext) throws Exception {
    return super.getAllObjByClass(new DeviceVendor(), 0);
  }

  public District getDistrict(String cuid) throws Exception {
    District dbo = new District();
    dbo.setCuid(cuid);
    return (District)super.getObjByCuid(dbo);
  }

  public District getDistrictByLabelCn(String labelCn)
    throws Exception
  {
    String sql = "LABEL_CN='" + labelCn + "'";
    DataObjectList dbos = super.getObjectsBySql(sql, new District(), 0);
    if (dbos.size() > 0) {
      return (District)dbos.get(0);
    }
    return null;
  }

  public void delDistrict(BoActionContext actionContext, String cuid) throws Exception
  {
    District dbo = new District();
    dbo.setCuid(cuid);
    dbo = (District)super.getObjByCuid(dbo);
    super.deleteObject(actionContext, dbo);
  }

  public void modifyDistrict(BoActionContext actionContext, District dbo) throws Exception {
    super.updateObject(actionContext, dbo);
  }

  public District addDistrict(BoActionContext actionContext, District dbo) throws Exception {
    super.createObject(actionContext, dbo);
    return dbo;
  }

  public DataObjectList getChildSite(String districtCuids) throws Exception
  {
    String[] cuidarray = districtCuids.split(",");
    String cuids = new String();
    for (int i = 0; i < cuidarray.length; i++) {
      cuids = cuids + ",'" + cuidarray[i] + "'";
    }
    if (cuids.length() > 0) {
      String sql = "RELATED_SPACE_CUID in (" + cuids.substring(1, cuids.length()) + ")";
      return super.getObjectsBySql(sql, new Site(), 0);
    }
    return super.getAllObjByClass(new Site(), 0);
  }

  public District getDistrictByCuid(BoActionContext actionContext, String districtCuid) throws Exception
  {
    String sql = "CUID = '" + districtCuid + "'";
    DataObjectList dbos = super.getObjectsBySql(sql, new District(), 0);
    District district = null;
    if ((dbos != null) && (dbos.size() > 0)) {
      district = (District)dbos.get(0);
    }
    return district;
  }

  public District getDistrictOfSite(BoActionContext actionContext, Site site) throws Exception {
    District parentDistrict = new District();
    parentDistrict.setCuid(site.getRelatedSpaceCuid());
    return (District)super.getObjByCuid(parentDistrict);
  }

  public District getParentDistrict(BoActionContext actionContext, District district) throws Exception {
    District parentDistrict = new District();
    parentDistrict.setCuid(district.getRelatedSpaceCuid());
    return (District)super.getObjByCuid(parentDistrict);
  }

  public DataObjectList getAllChildDistrict(BoActionContext actionContext, District district) throws Exception {
    String sql = "CUID like '" + district.getCuid() + "-%'";
    return super.getObjectsBySql(sql, new District(), 0);
  }

  public DataObjectList getChildDistricts(BoActionContext actionContext, District district) throws Exception {
    String sql = "RELATED_SPACE_CUID= '" + district.getCuid() + "'";
    return super.getObjectsBySql(sql, new District(), 0);
  }

  public boolean isRepeatName(String districtName) throws Exception
  {
    String sql = "LABEL_CN='" + districtName + "'";
    DataObjectList dbos = super.getObjectsBySql(sql, new District(), 0);
    if (dbos.size() > 0) {
      return true;
    }
    return false;
  }

  public String getCuidByLabelCn(BoActionContext actionContext, String labelCn) throws Exception
  {
    String sql = "LABEL_CN='" + labelCn + "'";
    DataObjectList dbos = super.getObjectsBySql(sql, new District(), 0);
    if (dbos.size() > 0) {
      return ((District)dbos.get(0)).getCuid();
    }
    return "";
  }

  public DataObjectList getAllDistrictCuidAndLabelCn() throws Exception
  {
    String sql = "select CUID,LABEL_CN from DISTRICT order by LABEL_CN";
    return super.selectDBOs(sql, new Class[] { String.class, String.class });
  }

  public boolean addCacheObjectForCM(GenericDO dbo)
  {
    if (GenericDAO.getSystemDAO().getDaoName().equals("CachedObjectDAO")) {
      CachedObjectDAO dao = (CachedObjectDAO)GenericDAO.getSystemDAO();
      dao.addCacheObjectWithSync(dbo);
      return true;
    }if (GenericDAO.getSystemDAO().getDaoName().equals("MemCachedObjectDAO"))
    {
      MemCachedObjectDAO dao = (MemCachedObjectDAO)GenericDAO.getSystemDAO();
      dao.addCacheObject(dbo, false);
      return true;
    }

    return false;
  }

  public boolean updateCacheObjectForCM(GenericDO dbo)
  {
    if (GenericDAO.getSystemDAO().getDaoName().equals("CachedObjectDAO")) {
      CachedObjectDAO dao = (CachedObjectDAO)GenericDAO.getSystemDAO();
      dao.updateCacheObjectWithSync(dbo);
      return true;
    }if (GenericDAO.getSystemDAO().getDaoName().equals("MemCachedObjectDAO"))
    {
      MemCachedObjectDAO dao = (MemCachedObjectDAO)GenericDAO.getSystemDAO();
      dao.updateCacheObject(dbo, false);
      return true;
    }

    return false;
  }

  public boolean deleteCacheObjectForCM(GenericDO dbo)
  {
    if (GenericDAO.getSystemDAO().getDaoName().equals("CachedObjectDAO")) {
      CachedObjectDAO dao = (CachedObjectDAO)GenericDAO.getSystemDAO();
      dao.deleteCacheObjectWithSync(dbo);
      return true;
    }if (GenericDAO.getSystemDAO().getDaoName().equals("MemCachedObjectDAO"))
    {
      MemCachedObjectDAO dao = (MemCachedObjectDAO)GenericDAO.getSystemDAO();
      dao.deleteCacheObject(dbo, false);
      return true;
    }

    return false;
  }

  public DataObjectList getNetIp() throws Exception {
    DataObjectList dbos = new DataObjectList();
    String sql = "select related_district_cuid,start_ip,end_ip from T_LOGIC_NUMBER_RANGE where 1=1  and NET_TYPE = 2 ";

    dbos = super.selectDBOs(sql, new Class[] { String.class, String.class, String.class });

    return dbos;
  }

  public TLogicNumberRange addTLogicNumberRange(BoActionContext actionContext, TLogicNumberRange dbo) throws Exception {
    super.createObject(actionContext, dbo);
    return dbo;
  }
  public void delTLogicNumberRange(BoActionContext actionContext, String districtCuid) throws Exception {
    TLogicNumberRange dbo = new TLogicNumberRange();
    DboCollection dbos = getTLogicNumberRange(districtCuid);
    for (int i = 0; i < dbos.size(); i++) {
      TLogicNumberRange dto = (TLogicNumberRange)dbos.getAttrField("T_LOGIC_NUMBER_RANGE", i);
      super.deleteObject(actionContext, dto);
    }
  }

  public DboCollection getTLogicNumberRange(String districtCuid) throws Exception { String sql = "select * from T_LOGIC_NUMBER_RANGE where 1=1 ";
    if ((districtCuid != null) && (districtCuid.trim().length() > 0)) {
      sql = sql + "and related_district_cuid = '" + districtCuid + "' ";
    }
    return super.selectDBOs(sql, new GenericDO[] { new TLogicNumberRange() }); }

  public void modifyTLogicNumberRange(BoActionContext actionContext, TLogicNumberRange dbo) throws Exception {
    super.updateObject(actionContext, dbo);
  }
}