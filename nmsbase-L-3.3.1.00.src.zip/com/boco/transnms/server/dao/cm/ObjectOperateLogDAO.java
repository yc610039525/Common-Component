package com.boco.transnms.server.dao.cm;

import com.boco.common.util.db.DbConnManager;
import com.boco.common.util.db.DbContext;
import com.boco.common.util.db.SqlHelper;
import com.boco.common.util.except.UserException;
import com.boco.common.util.lang.TimeFormatHelper;
import com.boco.transnms.common.dto.ObjectOperateLog;
import com.boco.transnms.common.dto.SysUser;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.dao.base.DaoHelper;
import com.boco.transnms.server.dao.base.GenericDAO;
import java.util.HashMap;

public class ObjectOperateLogDAO extends GenericDAO
{
  public ObjectOperateLogDAO()
  {
    super("ObjectOperateLogDAO");
  }
  public void addObjOperateLog(BoActionContext actionContext, ObjectOperateLog dbo) throws UserException, Exception {
    super.createObject(actionContext, dbo);
  }
  public DboCollection getSysUserNameByCuid(String cuid) throws Exception {
    String sql = "select * from SYS_USER WHERE CUID ='" + cuid + "'";
    return super.selectDBOs(sql, new GenericDO[] { new SysUser() });
  }

  public void deleteLogsByIds(BoActionContext actionContext, String condition) throws Exception {
    String sql = "DELETE FROM OBJECT_OPERATE_LOG where CUID IN(" + condition + ")";
    super.execSql(sql);
  }
  public DboCollection getObjectLog(BoQueryContext queryContext, HashMap param, String orderString) throws Exception {
    String sql = "SELECT * FROM OBJECT_OPERATE_LOG WHERE 1=1 ";
    if (((String)param.get("create_time") != null) && (((String)param.get("create_time")).trim().length() > 0)) {
      String createtime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp((String)param.get("create_time")));
      param.put("create_time", createtime);
    }
    if (((String)param.get("last_modify_time") != null) && (((String)param.get("last_modify_time")).trim().length() > 0)) {
      String lastmodifytime = SqlHelper.getTimestamp(DbConnManager.getInstance().getDbContext().getDbType(), TimeFormatHelper.getFormatTimestamp((String)param.get("last_modify_time")));
      param.put("last_modify_time", lastmodifytime);
    }

    if (DaoHelper.isNotEmpty((String)param.get("operateTypeCuid"))) {
      sql = sql + " AND " + "OPERATE_TYPE" + " IN(" + (String)param.get("operateTypeCuid") + ")";
    }
    if (DaoHelper.isNotEmpty((String)param.get("create_time"))) {
      sql = sql + " AND " + "OPERATE_TIME" + " >=" + (String)param.get("create_time");
    }
    if (DaoHelper.isNotEmpty((String)param.get("last_modify_time"))) {
      sql = sql + " AND " + "OPERATE_TIME" + " <=" + (String)param.get("last_modify_time");
    }
    if (DaoHelper.isNotEmpty((String)param.get("objTypeCuid"))) {
      sql = sql + " AND " + "OBJ_TYPE" + " IN(" + (String)param.get("objTypeCuid") + ")";
    }
    if (DaoHelper.isNotEmpty((String)param.get("queryDetail"))) {
      sql = sql + " AND " + "LOG_INFO" + " LIKE '%" + (String)param.get("queryDetail") + "%'";
    }
    if (DaoHelper.isNotEmpty(orderString))
      sql = sql + " order by  " + orderString;
    else {
      sql = sql + " order by " + "OPERATE_TIME" + " DESC";
    }
    return super.selectDBOs(queryContext, sql, new GenericDO[] { new ObjectOperateLog() });
  }
}