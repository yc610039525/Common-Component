package com.boco.transnms.server.dao.alarm;

import com.boco.transnms.common.dto.Mailinfo;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.workflow.EmailModel;
import com.boco.transnms.server.dao.base.AbstractDAO;

public class MailInfoDAO extends AbstractDAO
{
  public MailInfoDAO()
  {
    super("MailInfoDAO");
  }

  public Mailinfo addMailInfo(BoActionContext actionContext, Mailinfo mailInfo) throws Exception {
    super.createObject(actionContext, mailInfo);
    return mailInfo;
  }

  public void modifyMailInfo(BoActionContext actionContext, Mailinfo mailInfo) throws Exception {
    super.updateObject(actionContext, mailInfo);
  }

  public void deleteMailInfo(BoActionContext actionContext, Mailinfo mailInfo) throws Exception {
    super.deleteObject(actionContext, mailInfo);
  }

  public EmailModel getMailInfo(BoActionContext actionContext, Mailinfo mailInfo) throws Exception {
    EmailModel email = null;

    return email;
  }

  public void deleteMailinfo(BoActionContext actionContext, Long objectId) throws Exception {
    GenericDO dbo = new GenericDO();
    dbo.setObjectNum(objectId.longValue());
    super.deleteObject(actionContext, dbo);
  }

  public void sendMailinfo(BoActionContext actionContext, Long objectId) throws Exception {
    GenericDO dbo = new GenericDO();
    dbo.setObjectNum(objectId.longValue());
  }

  public DboCollection queryMailinfo(BoQueryContext queryContext, String emailAddr, String msgtype, String msgstate, String start_intime, String end_intime)
    throws Exception
  {
    String sql = "";
    String sql0 = "SELECT * FROM MAILINFO";
    if (emailAddr.length() != 0) {
      sql = "EMAIL_ADDR LIKE '%" + emailAddr + "%' ";
    }
    if (msgtype.length() != 0) {
      if (sql.length() != 0)
        sql = sql + " AND " + "EMAIL_TYPE" + " =" + msgtype + " ";
      else {
        sql = "EMAIL_TYPE =" + msgtype + " ";
      }
    }
    if (msgstate.length() != 0) {
      if (sql.length() != 0)
        sql = sql + " AND " + "MSGSTATE" + " =" + msgstate + " ";
      else {
        sql = "MSGSTATE =" + msgstate + " ";
      }
    }
    if (start_intime.length() != 0) {
      if (sql.length() != 0)
        sql = sql + " AND " + "INTIME" + " >=" + start_intime + " ";
      else {
        sql = "INTIME >=" + start_intime + "";
      }
    }
    if (end_intime.length() != 0) {
      if (sql.length() != 0)
        sql = sql + " AND " + "INTIME" + " <=" + end_intime + " ";
      else {
        sql = "INTIME <=" + end_intime + " ";
      }
    }
    if (sql.length() != 0)
      sql = sql0 + " WHERE " + sql;
    else {
      sql = sql0;
    }
    sql = sql + " order by " + "EMAIL_TYPE" + "," + "MSGSTATE" + "," + "INTIME";

    return super.selectDBOs(queryContext, sql, new GenericDO[] { new Mailinfo() });
  }

  public DboCollection queryMailinfoByState()
    throws Exception
  {
    String sql = "";
    String sql0 = "SELECT * FROM MAILINFO";
    sql = "MSGSTATE in (1,3) and ";
    sql = sql + "EMAIL_USER" + " is not null and " + "EMAIL_ADDR" + " is not null";
    sql = sql + " and (" + "SENDTIMES" + "< 20 or " + "SENDTIMES" + " is null)";
    sql = sql0 + " WHERE " + sql;
    sql = sql + " order by " + "EMAIL_TYPE" + "," + "MSGSTATE" + "," + "INTIME";

    return super.selectDBOs(sql, new GenericDO[] { new Mailinfo() });
  }

  public DboCollection getMailinfoExcel(BoQueryContext queryContext, String emailAddr, String msgtype, String msgstate, String start_intime, String end_intime)
    throws Exception
  {
    String sql = "";
    String sql0 = "SELECT * FROM MAILINFO";
    if (emailAddr.length() != 0) {
      sql = "EMAIL_ADDR LIKE '%" + emailAddr + "%' ";
    }
    if (msgtype.length() != 0) {
      if (sql.length() != 0)
        sql = sql + " AND " + "EMAIL_TYPE" + " =" + msgtype + " ";
      else {
        sql = "EMAIL_TYPE =" + msgtype + " ";
      }
    }
    if (msgstate.length() != 0) {
      if (sql.length() != 0)
        sql = sql + " AND " + "MSGSTATE" + " =" + msgstate + " ";
      else {
        sql = "MSGSTATE =" + msgstate + " ";
      }
    }
    if (start_intime.length() != 0) {
      if (sql.length() != 0)
        sql = sql + " AND " + "INTIME" + " >=" + start_intime + " ";
      else {
        sql = "INTIME >=" + start_intime + "";
      }
    }
    if (end_intime.length() != 0) {
      if (sql.length() != 0)
        sql = sql + " AND " + "INTIME" + " <=" + end_intime + " ";
      else {
        sql = "INTIME <=" + end_intime + " ";
      }
    }
    if (sql.length() != 0)
      sql = sql0 + " WHERE " + sql;
    else {
      sql = sql0;
    }
    sql = sql + " order by " + "EMAIL_TYPE" + "," + "MSGSTATE" + "," + "INTIME";
    return super.selectDBOs(sql, new GenericDO[] { new Mailinfo() });
  }

  public Mailinfo getMailinfoByCUid(BoActionContext actionContext, String mailinfocuid) throws Exception {
    Mailinfo mailinfo = new Mailinfo();
    mailinfo.setCuid(mailinfocuid);
    return (Mailinfo)super.getObjByCuid(mailinfo);
  }

  public Mailinfo getMailinfo(BoActionContext actionContext, Long mailinfoid) throws Exception {
    Mailinfo mailinfo = new Mailinfo();
    mailinfo.setObjectNum(mailinfoid.longValue());
    return (Mailinfo)super.getObject(mailinfo);
  }
}