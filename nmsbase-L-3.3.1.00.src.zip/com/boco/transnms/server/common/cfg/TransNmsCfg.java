package com.boco.transnms.server.common.cfg;

import com.boco.core.commons.ProjectVersion;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class TransNmsCfg extends TnmsDrmCfg
{
  private static TransNmsCfg instance = new TransNmsCfg();
  private boolean completeInit = false;

  private boolean developmentMode = false;
  private String pluginSuffix = "";
  private int productVersion;
  private int httpTimeOutLine = 300000;
  public static final long TEMPLATE_VERSION = 1000L;
  private String eomsTaskURL = "";

  public static String TRANSNMS_VERSION = ProjectVersion.getBuildVersion();
  public static String TRANSNMS_DEPLOY_DATE = ProjectVersion.getBuildDate();

  public static TransNmsCfg loadCfgFile(String springCfgFile)
    throws Exception
  {
    FileSystemXmlApplicationContext springContext = new FileSystemXmlApplicationContext(springCfgFile);

    return instance;
  }

  public boolean isDevelopmentMode()
  {
    return this.developmentMode;
  }

  public void setDevelopmentMode(boolean developmentMode) {
    this.developmentMode = developmentMode;
  }

  public static TransNmsCfg getInstance() {
    return instance;
  }

  public boolean isCompleteInit() {
    return this.completeInit;
  }

  public boolean isOpticalManager()
  {
    return false;
  }

  public int getProductVersion() {
    return this.productVersion;
  }

  public boolean isOmpDAO() {
    return "GenericOmpDAO".equals(getImplDaoName());
  }

  public void setCompleteInit(boolean completeInit) {
    this.completeInit = completeInit;
  }

  public void setProductVersion(int productVersion)
  {
    this.productVersion = productVersion;
  }

  public int getHttpTimeOutLine() {
    return this.httpTimeOutLine;
  }

  public void setHttpTimeOutLine(int aTimeOut) {
    this.httpTimeOutLine = aTimeOut;
  }

  public String getEomsTaskURL() {
    return this.eomsTaskURL;
  }
  public void setEomsTaskURL(String eomsTaskURL) {
    this.eomsTaskURL = eomsTaskURL;
  }

  public String getPluginSuffix() {
    return this.pluginSuffix;
  }

  public void setPluginSuffix(String pluginSuffix) {
    this.pluginSuffix = pluginSuffix;
  }

  public static class ProductSP
  {
    public static String CHINA_MOBILE = "chinamobile";
    public static String CHINA_UNICOM = "chinaunicom";
    public static String CHINA_TELECOM = "chinatelecom";
    public static String CHINA_NETCOM = "chinanetcom";
  }

  public static class WireSegType
  {
    public static String LOGIC = "LOGIC";
    public static String PHY = "PHY";
  }

  public static class ProductType
  {
    public static String TNMS = "TNMS";
    public static String IRMS = "IRMS";
  }
}