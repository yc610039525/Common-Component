package com.boco.transnms.server.common.cfg;

import java.util.Map;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class TransInterfaceCfg
{
  private static TransInterfaceCfg instance = new TransInterfaceCfg();
  private Map<String, String> alarmCity;
  private Map<String, String> alarmProductor;
  private Map<String, String> eomsDistrictAbbr;
  private Map<String, String> eomsPart;
  private String mqIp = "";
  private int mqPort = 0;
  private String queueManager = "";
  private String channel = "";
  private int ccsId = 0;
  private String user = "";
  private String password = "";
  private String alarmQueue = "";
  private String ruleQueue = "";
  private String handQueue = "";
  private boolean sheetLimitStart = false;
  private Map<String, String> irmsDistrict;
  private Map<String, String> netypeCode;
  private Map<String, String> emstypeCode;

  public Map<String, String> getEmstypeCode()
  {
    return this.emstypeCode;
  }

  public void setEmstypeCode(Map<String, String> emstypeCode) {
    this.emstypeCode = emstypeCode;
  }

  public Map<String, String> getNetypeCode() {
    return this.netypeCode;
  }

  public void setNetypeCode(Map<String, String> netypeCode) {
    this.netypeCode = netypeCode;
  }

  public Map<String, String> getIrmsDistrict() {
    return this.irmsDistrict;
  }

  public void setIrmsDistrict(Map<String, String> irmsDistrict) {
    this.irmsDistrict = irmsDistrict;
  }

  public static TransInterfaceCfg loadCfgFile(String springCfgFile)
    throws Exception
  {
    FileSystemXmlApplicationContext springContext = new FileSystemXmlApplicationContext(springCfgFile);
    return instance;
  }

  public void setHandQueue(String handQueue) {
    this.handQueue = handQueue;
  }

  public String getHandQueue() {
    return this.handQueue;
  }

  public void setRuleQueue(String ruleQueue) {
    this.ruleQueue = ruleQueue;
  }

  public String getRuleQueue() {
    return this.ruleQueue;
  }

  public void setAlarmQueue(String alarmQueue) {
    this.alarmQueue = alarmQueue;
  }

  public String getAlarmQueue() {
    return this.alarmQueue;
  }

  public void setUser(String user) {
    this.user = user;
  }

  public String getUser() {
    return this.user;
  }

  public String getPassword() {
    return this.password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public void setCcsId(int ccsId) {
    this.ccsId = ccsId;
  }

  public int getCcsId() {
    return this.ccsId;
  }

  public void setChannel(String channel) {
    this.channel = channel;
  }

  public String getChannel() {
    return this.channel;
  }

  public void setQueueManager(String queueManager) {
    this.queueManager = queueManager;
  }

  public String getQueueManager() {
    return this.queueManager;
  }

  public void setMqPort(int mqPort) {
    this.mqPort = mqPort;
  }

  public int getMqPort() {
    return this.mqPort;
  }

  public String getMqIp() {
    return this.mqIp;
  }

  public void setMqIp(String mqIp) {
    this.mqIp = mqIp;
  }

  public static TransInterfaceCfg getInstance() {
    return instance;
  }

  public Map<String, String> getAlarmCity() {
    return this.alarmCity;
  }

  public void setAlarmCity(Map<String, String> alarmCity) {
    this.alarmCity = alarmCity;
  }

  public Map<String, String> getAlarmProductor() {
    return this.alarmProductor;
  }

  public void setAlarmProductor(Map<String, String> alarmProductor) {
    this.alarmProductor = alarmProductor;
  }

  public Map<String, String> getEomsDistrictAbbr() {
    return this.eomsDistrictAbbr;
  }

  public void setEomsDistrictAbbr(Map<String, String> eomsDistrictAbbr) {
    this.eomsDistrictAbbr = eomsDistrictAbbr;
  }

  public Map<String, String> getEomsPart() {
    return this.eomsPart;
  }

  public void setEomsPart(Map<String, String> eomsPart) {
    this.eomsPart = eomsPart;
  }

  public void setSheetLimitStart(boolean varSheetLimitStart) {
    this.sheetLimitStart = varSheetLimitStart;
  }

  public boolean isSheetLimitStart() {
    return this.sheetLimitStart;
  }
}