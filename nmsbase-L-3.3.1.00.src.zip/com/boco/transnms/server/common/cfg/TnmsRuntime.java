package com.boco.transnms.server.common.cfg;

import com.boco.common.util.debug.LogHome;
import com.boco.transnms.common.cache.CustomCacheManagerFactory;
import com.boco.transnms.common.cache.GenericDaoCache;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.server.bo.base.BoHomeFactory;
import com.boco.transnms.server.bo.ibo.system.ISystemParaBO;
import java.util.HashMap;
import org.apache.commons.logging.Log;

public class TnmsRuntime
{
  public static final String TNMS_RUN_TIME_CFG = "TNMS_RUN_TIME_CFG";
  public static final String TNMS_RUN_TIME_BONAME = "RT_BO";
  public static final String TNMS_RUN_TIME_VARNAME = "RT_VAR";
  public static final String TNMS_RUN_TIME_CACHE = "RT_BO-RT_VAR";
  public static final String START_WF_ENGINE_ID = "START_WF_ENGINE_ID";
  public static final String DISTRICT_ID = "DISTRICT_ID";
  public static final String VIP_TRAPH = "VIP_TRAPH";
  public static final String START_NANFANG_THEME = "START_NANFANG_THEME";
  public static final String AUTO_HASTEN_DGN_TIME = "AUTO_HASTEN_DGN_TIME";
  public static final String IS_NE_PROJECT_STATE_FEEKBACK_FLOW = "IS_NE_PROJECT_STATE_FEEKBACK_FLOW";
  public static final String WRITE_SYSTEM_LOG = "WRITE_SYSTEM_LOG";
  public static final String SUPPORT_ALARM = "SUPPORT_ALARM";
  public static final String TD_BTS_LINK = "TD_BTS_LINK";
  public static final String PRODUCT_TYPE = "PRODUCT_TYPE";
  public static final String RTU_VERSION = "RTU_VERSION";
  public static final String PRODUCT_SP = "PRODUCT_SP";
  public static final String SUPPORT_SMS = "SUPPORT_SMS";
  public static final String SUPPORT_MAIL = "SUPPORT_MAIL";
  public static final String SUPPORT_CHANGE_LOG = "SUPPORT_CHANGE_LOG";
  public static final String SUPPORT_OBJECT_INDEX = "SUPPORT_OBJECT_INDEX";
  public static final String HTTP_TIME_OUT_LINE = "HTTP_TIME_OUT_LINE";
  public static final String NEED_SYN_ALARM_ON_START = "NEED_SYN_ALARM_ON_START";
  public static final String AUTO_TRAPH_NUMBER = "AUTO_TRAPH_NUMBER";
  public static final String OPTICAL_MANAGER = "OPTICAL_MANAGER";
  public static final String SUPPORT_LOGICAL_WIRE_SEG = "SUPPORT_LOGICAL_WIRE_SEG";
  public static final String START_SEND_ALARM_RULE = "START_SEND_ALARM_RULE";
  public static final String START_INTERFACE_FOR_EMOS = "START_INTERFACE_FOR_EMOS";
  public static final String START_INTERFACE_FOR_BOARD = "START_INTERFACE_FOR_BOARD";
  public static final String NOT_CHECK_SEND_ALARM = "NOT_CHECK_SEND_ALARM";
  public static final String SEND_FAULT_TO_EOMS = "SEND_FAULT_TO_EOMS";
  public static final String EOMS_DISTRICT = "EOMS_DISTRICT";
  public static final String EOMS_ONE_FAULT = "EOMS_ONE_FAULT";
  public static final String EOMS_MULTI_FAULT = "EOMS_MULTI_FAULT";
  public static final String EOMS_ATTEMP_URL = "EOMS_ATTEMP_URL";
  public static final String AUTO_SEARCH_AREA = "AUTO_SEARCH_AREA";
  public static final String ALCATEL_LUCENT_MANAGER = "ALCATEL_LUCENT_MANAGER";
  public static final String START_SEND_DUTY = "START_SEND_DUTY";
  public static final String HUAWEI_EMOS_SERVICE = "HUAWEI_EMOS_SERVICE";
  public static final String HUAWEI_LOGIN_URL = "HUAWEI_LOGIN_URL";
  public static final String HUAWEI_GOTO_URL = "HUAWEI_GOTO_URL";
  public static final String EOMS_FUZZY_QUERY_URL = "EOMS_FUZZY_QUERY_URL";
  public static final String EMOS_USER_NAME = "EMOS_USER_NAME";
  public static final String EMOS_PASS_WORD = "EMOS_PASS_WORD";
  public static final String HUAWEI_SSO_SERVICE = "HUAWEI_SSO_SERVICE";
  public static final String SUPPORT_ROOT_ALARM_DETECT = "SUPPORT_ROOT_ALARM_DETECT";
  public static final String ROOT_ALARM_THREAD_LIMIT = "ROOT_ALARM_THREAD_LIMIT";
  public static final String ROOT_ALARM_RELATED_TIME = "ROOT_ALARM_RELATED_TIME";
  public static final String ROOT_ALARM_DELAY_TIME = "ROOT_ALARM_DELAY_TIME";
  public static final String ROOT_ALARM_IN_BUF_TIME = "ROOT_ALARM_IN_BUF_TIME";
  public static final String FAULT_EOMS = "FAULT_EOMS";
  public static final String MAX_DB_TIME = "MAX_DB_TIME";
  public static final String MAX_BO_INVOKE_TIME = "MAX_BO_INVOKE_TIME";
  public static final String EOMS_TASK_SERVICE = "EOMS_TASK_SERVICE";
  public static final String EMOS_SINGLE_TASK = "EMOS_SINGLE_TASK";
  public static final String EMOS_MULTI_TASK = "EMOS_MULTI_TASK";
  public static final String MAX_QUERY_RESULT_SIZE = "MAX_QUERY_RESULT_SIZE";
  public static final String START_PROVINCE_INTERFACE = "START_PROVINCE_INTERFACE";
  public static final String LB_FAULT_DEAL = "LB_FAULT_DEAL";
  public static final String DEAL_ALARM_TIME = "DEAL_ALARM_TIME";
  public static final String DELETE_HISTORY_ALARM_PERIOD = "DELETE_HISTORY_ALARM_PERIOD";
  public static final String EMS_SYNC_THREAD_COUNT = "EMS_SYNC_THREAD_COUNT";
  public static final String DEFAULT_THEME = "DEFAULT_THEME";
  public static final String ADD_BATCHTRAPH = "ADD_BATCHTRAPH";
  public static final String FHFD_SELECT = "FHFD_SELECT";
  public static final String IMPORT_PROTECT_TIMEOUT = "IMPORT_PROTECT_TIMEOUT";
  public static final String FAULT_DEV_ANALYZE = "FAULT_DEV_ANALYZE";
  public static final String FAULT_TRAPH_DIAGNOSE = "FAULT_TRAPH_DIAGNOSE";
  public static final String ALARM_SEVERITY_FOR_NOT_STANDARD = "ALARM_SEVERITY_FOR_NOT_STANDARD";
  public static final String START_SUDDENLY_ALARM = "START_SUDDENLY_ALARM";
  public static final String SUPPORT_PFM_MODEL = "SUPPORT_PFM_MODEL";
  public static final String SUPPORT_PERFORMACE_SYSTEM = "SUPPORT_PERFORMACE_SYSTEM";
  public static final String SUPPORT_OBJECT_VALID = "SUPPORT_OBJECT_VALID";
  public static final String BSS_HX_URL = "BSS_HX_URL";
  public static final String SINGLE_SIGNON_URL = "SINGLE_SIGNON_URL";
  public static final String FTP_DEST = "FTP_DEST";
  public static final String FTP_USER_NAME = "FTP_USER_NAME";
  public static final String FTP_PASSWORD = "FTP_PASSWORD";
  public static final String GET_FTP_FILE = "GET_FTP_FILE";
  public static final String XRPC_URL = "XRPC_URL";
  public static final String SUPPORT_LOST_PATH = "SUPPORT_LOST_PATH";
  public static final String RENT_EXCEL_TYPE = "RENT_EXCEL_TYPE";
  public static final String DELETE_TRANSPATH = "DELETE_TRANSPATH";
  public static final String ALARM_SMS_CIRCUIT = "ALARM_SMS_CIRCUIT";
  public static final String ALARM_COMPRESS = "ALARM_COMPRESS";
  public static final String START_ALARM_STANDARD = "START_ALARM_STANDARD";
  public static final String SET_ALMPORJECT_BY_OPP_DEVICE = "SET_ALMPORJECT_BY_OPP_DEVICE";
  public static final String SEND_TO_EOMS_IF_NOT_STAND = "SEND_TO_EOMS_IF_NOT_STAND";
  public static final String ALARM_CLEAR_WAIT_TIME = "ALARM_CLEAR_WAIT_TIME";
  public static final String SUPPORT_MSTP = "SUPPORT_MSTP";
  public static final String WIRE_SEG_TYPE = "WIRE_SEG_TYPE";
  public static final String TRANSNMS_VERSION = "TRANSNMS_VERSION";
  public static final String TRANSNMS_DEPLOY_DATE = "TRANSNMS_DEPLOY_DATE";
  public static final String WEBATTEMP_START_SYS = "WEBATTEMP_START_SYS";
  public static final String EOMS_TASK_URL = "EOMS_TASK_URL";
  public static final String WEBMASTER = "WEBMASTER";
  public static final String WEBREPORT = "WEBREPORT";
  public static final String WEBATTEMP = "WEBATTEMP";
  public static final String WEBATTEMPX = "WEBATTEMPX";
  public static final String WEBATTEMPOPT = "WEBATTEMPOPT";
  public static final String WEBWORKFLOW = "WEBWORKFLOW";
  public static final String PONMASTER = "PONMASTER";
  public static final String NETADJUST = "NETADJUST";
  public static final String WEBPERFORMANCE = "WEBPERFORMANCE";
  public static final String PORTAL = "PORTAL";
  public static final String HENANREPORT = "HENANREPORT";
  public static final String SPAREPARTSYS = "SPAREPARTSYS";
  public static final String FORUM = "FORUM";
  public static final String ALARMCLIENT = "ALARMCLIENT";
  public static final String DMSCLIENT = "WEBDMSCLIENT";
  public static final String TOPOCLIENT = "TOPOCLIENT";
  public static final String PONAUTOACTIVATE_SYS = "PONAUTOACTIVATE_SYS";
  public static final String WEBAN = "WEBAN";
  public static final String HUSS = "HUSS";
  public static final String WEBAN_PROXY = "WEBAN_PROXY";
  public static final String WEBMASTER_PROXY = "WEBMASTER_PROXY";
  public static final String WEBREPORT_PROXY = "WEBREPORT_PROXY";
  public static final String WEBATTEMP_PROXY = "WEBATTEMP_PROXY";
  public static final String WEBATTEMPX_PROXY = "WEBATTEMPX_PROXY";
  public static final String WEBATTEMPOPT_PROXY = "WEBATTEMPOPT_PROXY";
  public static final String WEBWORKFLOW_PROXY = "WEBWORKFLOW_PROXY";
  public static final String PONMASTER_PROXY = "PONMASTER_PROXY";
  public static final String NETADJUST_PROXY = "NETADJUST_PROXY";
  public static final String WEBPERFORMANCE_PROXY = "WEBPERFORMANCE_PROXY";
  public static final String PORTAL_PROXY = "PORTAL_PROXY";
  public static final String HENANREPORT_PROXY = "HENANREPORT_PROXY";
  public static final String SPAREPARTSYS_PROXY = "SPAREPARTSYS_PROXY";
  public static final String FORUM_PROXY = "FORUM_PROXY";
  public static final String ALARMCLIENT_PROXY = "ALARMCLIENT_PROXY";
  public static final String DMSCLIENT_PROXY = "DMSCLIENT_PROXY";
  public static final String TOPOCLIENT_PROXY = "TOPOCLIENT_PROXY";
  public static final String WRITE_OBJECT_OPERATE_LOG = "WRITE_OBJECT_OPERATE_LOG";
  public static final String MAINFRAME_STATISTIC = "MAINFRAME_STATISTIC";
  public static final String WRITE_MODULE_CLICK_LOG = "WRITE_MODULE_CLICK_LOG";
  public static final String MAX_MODULE_CLICK_LOG_THREADNUM = "MAX_MODULE_CLICK_LOG_THREADNUM";
  public static final String MAX_MODULE_CLICK_LOG_QUEUELEN = "MAX_MODULE_CLICK_LOG_QUEUELEN";
  public static final String ADD_MODULE_CLICK_LOG_WAITTIME = "ADD_MODULE_CLICK_LOG_WAITTIME";
  public static final String MAX_MODULE_CLICK_LOG_HANDELTIME = "MAX_MODULE_CLICK_LOG_HANDELTIME";
  public static final String CHECK_POOL_MODULE_CLICK_LOG_NUM = "CHECK_POOL_MODULE_CLICK_LOG_NUM";
  public static final String CHECK_POOL_MODULE_CLICK_LOG_TIME = "CHECK_POOL_MODULE_CLICK_LOG_TIME";
  public static final String COPYRIGHT_AND_URL = "COPYRIGHT_AND_URL";
  public static final String IS_PTN_ON = "IS_PTN_ON";
  public static final String PTN_MODEL_SET = "PTN_MODEL_SET";
  public static final String IS_PTN_CHECK = "IS_PTN_CHECK";
  public static final String IS_PTN_CHECK_BTN_SHOW = "IS_PTN_CHECK_BTN_SHOW";
  public static final String IS_OTN_ON = "IS_OTN_ON";
  public static final String IS_PTN_BACTH_ON = "IS_PTN_BACTH_ON";
  public static final String IS_PTN_GRAPHIC_ON = "IS_PTN_GRAPHIC_ON";
  public static final String IS_OPTICAL_BACTH_ON = "IS_OPTICAL_BACTH_ON";
  public static final String DTS_START_SYNC_TIME = "DTS_START_SYNC_TIME";
  public static final String DTS_IS_INCRE_SYNC = "DTS_IS_INCRE_SYNC";
  public static final String DTS_FULL_SYNC_FOR_STARTUP = "DTS_FULL_SYNC_FOR_STARTUP";
  public static final String DTS_NEED_UPDATE_MEMCACHE = "DTS_NEED_UPDATE_MEMCACHE";
  public static final String PTP_PORT_SYNC_THREAD_NUM = "PTP_PORT_SYNC_THREAD_NUM";
  public static final String DTS_SYNC_USE_PROCEDURE = "DTS_SYNC_USE_PROCEDURE";
  public static final String DC_AN_TASK_TIME = "DC_AN_TASK_TIME";
  public static final String SYNC_EXCLUDED_EMS_NAME = "SYNC_EXCLUDED_EMS_NAME";
  public static final String _PROXY = "_PROXY";
  public static final String TRAPH_BREAK_ANALYZE = "TRAPH_BREAK_ANALYZE";
  public static final String SUPPORT_OPTICAL_SWITCH_BREAK_TRAPH = "SUPPORT_OPTICAL_SWITCH_BREAK_TRAPH";
  public static final String SUPPORT_NEALARM_BANDING_TRAPH = "SUPPORT_NEALARM_BANDING_TRAPH";
  public static final String SUPPORT_OFFLINE_ALARM_FUNC = "SUPPORT_OFFLINE_ALARM_FUNC";
  public static final String SUPPORT_ALM_DERIVATIVE = "SUPPORT_ALM_DERIVATIVE";
  public static final String SUPPORT_AUTOMUL_ALM_TO_EOMS = "SUPPORT_AUTOMUL_ALM_TO_EOMS";
  public static final String SUPPORT_EMS_NOT_REVALM_CK = "SUPPORT_EMS_NOT_REVALM_CK";
  public static final String IS_AM_WRITE_MSG_TIME_LOG = "IS_AM_WRITE_MSG_TIME_LOG";
  public static final String SUPPORT_NET_CLOSE = "SUPPORT_NET_CLOSE";
  public static final String IS_ONU_ATTEMP_ON = "IS_ONU_ATTEMP_ON";
  public static final String IS_PTN_NOT_USENET = "IS_PTN_NOT_USENET";
  public static final String SUPPORT_EOMS_BATCH_ALARM = "SUPPORT_EOMS_BATCH_ALARM";
  public static final String HUSS_TNMS_ALL_IN_USE = "HUSS_TNMS_ALL_IN_USE";
  public static final String AN_ALARM_RELATED_ANALYSE_TIME = "AN_ALARM_RELATED_ANALYSE_TIME";
  public static final String AN_ALARM_P_LOAD_PERIOD = "AN_ALARM_P_LOAD_PERIOD";
  public static final String AN_ALARM_P_LOAD_SIZE = "AN_ALARM_P_LOAD_SIZE";
  public static final String AN_ALARM_P_CHECK_TIME = "AN_ALARM_P_CHECK_TIME";
  public static final String AN_CHECK_AUTO_UPDATE = "AN_CHECK_AUTO_UPDATE";
  public static final String AN_AMRTU = "AN_AMRTU";
  public static final String AN_AM_DISTRIBUTE = "AN_AM_DISTRIBUTE";
  public static final String AN_ALARM_FROM_TNMS = "AN_ALARM_FROM_TNMS";
  public static final String PROVINCE_ALARM_NOT_SEND = "PROVINCE_ALARM_NOT_SEND";
  public static final String LOCAL_ALARM_NOT_SEND = "LOCAL_ALARM_NOT_SEND";
  public static final String PON_COLLECT_USE_DATA_CHECK = "PON_COLLECT_USE_DATA_CHECK";
  public static final String PON_NE_ONLY_IN_TRANS_ELEMENT = "PON_NE_ONLY_IN_TRANS_ELEMENT";
  public static final String ZTE_SYNC_ALARM_SLEEP_TIME = "ZTE_SYNC_ALARM_SLEEP_TIME";
  public static final String ZTE_SYNC_ALARM_LOOP_COUNT = "ZTE_SYNC_ALARM_LOOP_COUNT";
  public static final String SHANG_HAI_ALARM_INTERFACE = "SHANG_HAI_ALARM_INTERFACE";
  public static final String SHANG_HAI_ALARM_INTERFACE_DOOR = "SHANG_HAI_ALARM_INTERFACE_DOOR";
  public static final String AN_PON = "AN_PON";
  public static final String IS_TRAIL_RELATED_TRAPH = "IS_TRAIL_RELATED_TRAPH";
  public static final String AH_SYNC_PON_ATTR_FTP = "AH_SYNC_PON_ATTR_FTP";
  public static final String AH_IS_PON_ATTR_SYNC = "AH_IS_PON_ATTR_SYNC";
  public static final String AH_SYNC_PON_ATTR_TIME = "AH_SYNC_PON_ATTR_TIME";
  public static final String EOMS_ATTCH_IP = "EOMS_ATTCH_IP";
  public static final String EOMS_ATTCH_OUTIP = "EOMS_ATTCH_OUTIP";
  public static final String TNMS_ATTCH_IP = "TNMS_ATTCH_IP";
  public static final String TNMS_ATTCH_OUTIP = "TNMS_ATTCH_OUTIP";
  public static final String START_MASTER_BACKUP_MODE = "START_MASTER_BACKUP_MODE";
  public static final String SUPPORT_SHANG_HAI_MSAP_ALARM = "SUPPORT_SHANG_HAI_MSAP_ALARM";
  public static final String IS_HENAN_PAGE_ROW = "IS_HENAN_PAGE_ROW";
  public static final String SUPPORT_ALARM_PREPROCESS = "SUPPORT_ALARM_PREPROCESS";
  public static final String IS_ALL_DERIVATIVE_SHOW = "IS_ALL_DERIVATIVE_SHOW";
  public static final String IS_AUTO_MARK = "IS_AUTO_MARK";
  public static final String IS_AN_ALARM_RELATED_ANALYSE = "IS_AN_ALARM_RELATED_ANALYSE";
  public static final String IS_AN_KPI_ALARM = "IS_AN_KPI_ALARM";
  public static final String IS_AN_ONU_STATE = "IS_AN_ONU_STATE";
  public static final String IS_AN_FAULT = "IS_AN_FAULT";
  public static final String SHANG_HAI_IRMS_PONSERVICE = "SHANG_HAI_IRMS_PONSERVICE";
  private GenericDaoCache params = null;
  private static TnmsRuntime instance = null;

  public static TnmsRuntime getInstance()
  {
    if (instance == null) {
      instance = new TnmsRuntime();
      instance.init();
    }
    return instance;
  }

  private void init()
  {
    try {
      this.params = CustomCacheManagerFactory.getInstance().getCustomCache("RT_BO", "RT_VAR");

      ISystemParaBO ibo = (ISystemParaBO)BoHomeFactory.getInstance().getBO("ISystemParaBO");
      HashMap map = ibo.getSystemRuntimeCfg(new BoActionContext());
      this.params.setCache(map);
      this.params.init();

      if (equals("WRITE_SYSTEM_LOG", Boolean.TRUE.toString())) {
        TnmsDrmCfg.getInstance().setWriteSystemLog(Boolean.TRUE.booleanValue());
        LogHome.getLog().info("=====打开系统日志开关=======" + TnmsDrmCfg.getInstance().isWriteSystemLog());
      }
    } catch (Exception ex) {
      LogHome.getLog().error("", ex);
    }
  }

  public String get(String key) {
    return (String)this.params.get(key);
  }

  public String getWebUrl(String key, String hostIp) {
    String outputUrl = "";
    if ((this.params.get(key + "_PROXY") != null) && (((String)this.params.get(key + "_PROXY")).indexOf(hostIp) >= 0))
      outputUrl = (String)this.params.get(key + "_PROXY");
    else {
      outputUrl = (String)this.params.get(key);
    }
    if (outputUrl == null) {
      outputUrl = "";
    }
    return outputUrl;
  }
  public void put(String key, String value) {
    this.params.put(key, value);
  }

  public boolean equals(String key, String value) {
    String param = get(key);
    return (value != null) && (param != null) && (param.trim().equalsIgnoreCase(value));
  }

  public boolean isTrue(String key) {
    String param = get(key);
    return (param != null) && (param.trim().equalsIgnoreCase(Boolean.TRUE.toString()));
  }

  public boolean isFalse(String key) {
    String param = get(key);
    return (param != null) && (param.trim().equalsIgnoreCase(Boolean.FALSE.toString()));
  }
}