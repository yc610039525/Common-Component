package com.boco.transnms.server.common.cfg;

import com.boco.common.util.debug.LogHome;
import com.boco.transnms.common.dto.common.ActionFilter;
import java.util.HashMap;
import org.apache.commons.logging.Log;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class ActionFilterCfg
{
  private HashMap filterMap = new HashMap();
  private static ActionFilterCfg instance;
  private FileSystemXmlApplicationContext springContext;

  public static ActionFilterCfg createIntance(String beanXmlFileName)
  {
    ActionFilterCfg _instance = new ActionFilterCfg();
    try {
      FileSystemXmlApplicationContext springContext = new FileSystemXmlApplicationContext(beanXmlFileName);
      _instance.springContext = springContext;
      _instance.init();
    } catch (Exception ex) {
      LogHome.getLog().info("没有发现菜单配置文件, file=" + beanXmlFileName + ", expMessage=" + ex.getMessage());
    }

    instance = _instance;
    return instance;
  }

  public static ActionFilterCfg getInstance() {
    return instance;
  }

  public boolean isVisible(String actionName) {
    ActionFilter actionFilter = getActionFilter(actionName);
    if (actionFilter != null) {
      return actionFilter.isActionVisible();
    }
    return true;
  }

  private ActionFilter getActionFilter(String actionName)
  {
    if (this.springContext == null) {
      return null;
    }
    if (this.springContext.containsBean(actionName)) {
      return (ActionFilter)this.springContext.getBean(actionName);
    }
    return null;
  }

  private void init()
  {
    ActionFilter actionFilter1 = new ActionFilter();
    actionFilter1.setActionName("doWrongData");
    actionFilter1.setActionText("容错管理");
    actionFilter1.setActionVisible(false);
    this.filterMap.put("doWrongData", actionFilter1);

    ActionFilter actionFilter2 = new ActionFilter();
    actionFilter2.setActionName("ProjectManagement");
    actionFilter2.setActionText("生命周期管理");
    actionFilter2.setActionVisible(false);
    this.filterMap.put("ProjectManagement", actionFilter2);

    ActionFilter actionFilter3 = new ActionFilter();
    actionFilter3.setActionName("SpotFixMenu");
    actionFilter3.setActionText("场景固化");
    actionFilter3.setActionVisible(false);
    this.filterMap.put("SpotFixMenu", actionFilter3);

    ActionFilter actionFilter4 = new ActionFilter();
    actionFilter4.setActionName("WireTroubleManagement");
    actionFilter4.setActionText("隐患管理");
    actionFilter4.setActionVisible(false);
    this.filterMap.put("WireTroubleManagement", actionFilter4);

    ActionFilter actionFilter5 = new ActionFilter();
    actionFilter5.setActionName("WireLengthStatExtView");
    actionFilter5.setActionText("按地市光缆长度统计");
    actionFilter5.setActionVisible(false);
    this.filterMap.put("WireLengthStatExtView", actionFilter5);

    String[] beanNames = this.springContext.getBeanDefinitionNames();
    for (int i = 0; i < beanNames.length; i++) {
      String beanName = beanNames[i];
      this.filterMap.put(beanName, this.springContext.getBean(beanName));
    }

    boolean isStartALmStand = TnmsRuntime.getInstance().equals("START_ALARM_STANDARD", "true");

    ActionFilter actionFilter6 = new ActionFilter();
    actionFilter6.setActionName("AlarmSeverityRedefine");
    actionFilter6.setActionText("告警重定义");
    actionFilter6.setActionVisible(!isStartALmStand);
    this.filterMap.put("AlarmSeverityRedefine", actionFilter6);

    ActionFilter actionFilter7 = new ActionFilter();
    actionFilter7.setActionName("AlarmStandard");
    actionFilter7.setActionText("告警标准化管理");
    actionFilter7.setActionVisible(isStartALmStand);
    this.filterMap.put("AlarmStandard", actionFilter7);

    if ((!TnmsRuntime.getInstance().equals("DISTRICT_ID", "全国")) && (!TnmsRuntime.getInstance().equals("DISTRICT_ID", "DISTRICT-00001")))
    {
      ActionFilter actionFilter = new ActionFilter();
      actionFilter.setActionName("ProvinceInterface");
      actionFilter.setActionText("省部接口");
      actionFilter.setActionVisible(false);
      this.filterMap.put("ProvinceInterface", actionFilter);
    }

    if (!TnmsRuntime.getInstance().equals("DISTRICT_ID", "广东")) {
      ActionFilter actionFilter = new ActionFilter();
      actionFilter.setActionName("OtherAlarmRuleEditView");
      actionFilter.setActionText("外告告警设置");
      actionFilter.setActionVisible(false);
      this.filterMap.put("OtherAlarmRuleEditView", actionFilter);
    }

    if (!TnmsRuntime.getInstance().equals("START_SUDDENLY_ALARM", "true")) {
      ActionFilter actionFilter = new ActionFilter();
      actionFilter.setActionName("SuddenlyAlarmRuleView");
      actionFilter.setActionText("突发告警量异常监控设置");
      actionFilter.setActionVisible(false);
      this.filterMap.put("SuddenlyAlarmRuleView", actionFilter);
    }

    if (!TnmsRuntime.getInstance().equals("SUPPORT_ROOT_ALARM_DETECT", "true")) {
      ActionFilter actionFilter = new ActionFilter();
      actionFilter.setActionName("EmsForRootAlarmDetectView");
      actionFilter.setActionText("根告警分析EMS设置");
      actionFilter.setActionVisible(false);
      this.filterMap.put("EmsForRootAlarmDetectView", actionFilter);
      ActionFilter actionFilter8 = new ActionFilter();
      actionFilter8.setActionName("AlarmSuppressRuleView");
      actionFilter8.setActionText("根告警分析告警抑止关系管理");
      actionFilter8.setActionVisible(false);
      this.filterMap.put("AlarmSuppressRuleView", actionFilter1);
    }

    if ((!TnmsRuntime.getInstance().equals("DISTRICT_ID", "上海")) && (!TnmsRuntime.getInstance().isTrue("SUPPORT_ALARM_PREPROCESS")))
    {
      ActionFilter filter = new ActionFilter();
      filter.setActionName("AlarmPreprocessRuleView");
      filter.setActionText("预处理告警规则设置");
      filter.setActionVisible(false);
      this.filterMap.put("AlarmPreprocessRuleView", filter);
    }
  }

  public HashMap getActionFilters() {
    return this.filterMap;
  }
}