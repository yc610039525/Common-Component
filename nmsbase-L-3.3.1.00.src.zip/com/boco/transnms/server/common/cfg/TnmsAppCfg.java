package com.boco.transnms.server.common.cfg;

import com.boco.common.util.debug.LogHome;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class TnmsAppCfg extends TnmsDrmCfg
{
  private static TnmsAppCfg instance = new TnmsAppCfg();

  private boolean useEventPool = false;
  private Map<String, String> alarmEmsThreadTable;
  private int checkPoolAlarmNum = 100;
  private int checkPoolAlarmTime = 120;
  private int maxAlarmHandleTime = 100;
  private int maxAlarmThreadNum = 20;
  private int maxAlarmQueueLen = 2000;
  private int addAlarmWaitTime = 200;
  private Map<String, String> eventThreadTable;
  private int checkPoolEventNum = 100;
  private int checkPoolEventTime = 120;
  private int maxEventHandleTime = 1000;

  private List<String> changeLogDaoClassNames = new ArrayList();
  private Map<String, String> collectThreadTable;
  private int checkPoolCollectNum = 20;
  private int checkPoolCollectTime = 120;
  private int maxCollectThreadNum = 10;

  private boolean switchEventOpen = true;

  private int maxChannelThreadNum = 4;
  private List<String> msgDtoClassNames = new ArrayList();

  public static TnmsAppCfg getInstance()
  {
    return instance;
  }

  public void loadCfgFile(String springCfgFile) {
    try {
      springContext = new FileSystemXmlApplicationContext(springCfgFile);
    }
    catch (Exception ex)
    {
      FileSystemXmlApplicationContext springContext;
      LogHome.getLog().info("不支持详细配置, file=" + springCfgFile + ", expMessage=" + ex.getMessage());
    }
  }

  public Map getAlarmEmsThreadTable()
  {
    return this.alarmEmsThreadTable;
  }

  public int getCheckPoolAlarmNum() {
    return this.checkPoolAlarmNum;
  }

  public int getMaxAlarmHandleTime() {
    return this.maxAlarmHandleTime;
  }

  public int getCheckPoolAlarmTime() {
    return this.checkPoolAlarmTime;
  }

  public int getCheckPoolEventNum() {
    return this.checkPoolEventNum;
  }

  public int getCheckPoolEventTime() {
    return this.checkPoolEventTime;
  }

  public int getMaxEventHandleTime() {
    return this.maxEventHandleTime;
  }

  public int getMaxAlarmThreadNum() {
    return this.maxAlarmThreadNum;
  }

  public void setAlarmEmsThreadTable(Map alarmEmsThreadTable) {
    this.alarmEmsThreadTable = alarmEmsThreadTable;
  }

  public void setCheckPoolAlarmNum(int checkPoolAlarmNum) {
    this.checkPoolAlarmNum = checkPoolAlarmNum;
  }

  public void setMaxAlarmHandleTime(int maxAlarmHandleTime) {
    this.maxAlarmHandleTime = maxAlarmHandleTime;
  }

  public void setCheckPoolAlarmTime(int checkPoolAlarmTime) {
    this.checkPoolAlarmTime = checkPoolAlarmTime;
  }

  public void setCheckPoolEventNum(int checkPoolEventNum) {
    this.checkPoolEventNum = checkPoolEventNum;
  }

  public void setCheckPoolEventTime(int checkPoolEventTime) {
    this.checkPoolEventTime = checkPoolEventTime;
  }

  public void setMaxEventHandleTime(int maxEventHandleTime) {
    this.maxEventHandleTime = maxEventHandleTime;
  }

  public void setMaxAlarmThreadNum(int maxAlarmThreadNum) {
    this.maxAlarmThreadNum = maxAlarmThreadNum;
  }

  public void setUseEventPool(boolean useEventPool) {
    this.useEventPool = useEventPool;
  }

  public void setEventThreadTable(Map eventThreadTable) {
    this.eventThreadTable = eventThreadTable;
  }

  public void setChangeLogDaoClassNames(List changeLogDaoClassNames) {
    this.changeLogDaoClassNames = changeLogDaoClassNames;
  }

  public boolean isUseEventPool() {
    return this.useEventPool;
  }

  public Map getEventThreadTable() {
    return this.eventThreadTable;
  }

  public List getChangeLogDaoClassNames() {
    return this.changeLogDaoClassNames;
  }

  public void setCheckPoolCollectNum(int checkPoolCollectNum) {
    this.checkPoolCollectNum = checkPoolCollectNum;
  }

  public void setCheckPoolCollectTime(int checkPoolCollectTime) {
    this.checkPoolCollectTime = checkPoolCollectTime;
  }

  public void setCollectThreadTable(Map collectThreadTable) {
    this.collectThreadTable = collectThreadTable;
  }

  public void setMaxCollectThreadNum(int maxCollectThreadNum) {
    this.maxCollectThreadNum = maxCollectThreadNum;
  }

  public void setMaxAlarmQueueLen(int maxAlarmQueueLen) {
    this.maxAlarmQueueLen = maxAlarmQueueLen;
  }

  public void setAddAlarmWaitTime(int addAlarmWaitTime) {
    this.addAlarmWaitTime = addAlarmWaitTime;
  }

  public void setSwitchEventOpen(boolean switchEventOpen) {
    this.switchEventOpen = switchEventOpen;
  }

  public void setMaxChannelThreadNum(int maxChannelThreadNum) {
    this.maxChannelThreadNum = maxChannelThreadNum;
  }

  public void setMsgDtoClassNames(List msgDtoClassNames) {
    this.msgDtoClassNames = msgDtoClassNames;
  }

  public int getCheckPoolCollectNum() {
    return this.checkPoolCollectNum;
  }

  public int getCheckPoolCollectTime() {
    return this.checkPoolCollectTime;
  }

  public Map getCollectThreadTable() {
    return this.collectThreadTable;
  }

  public int getMaxCollectThreadNum() {
    return this.maxCollectThreadNum;
  }

  public int getMaxAlarmQueueLen() {
    return this.maxAlarmQueueLen;
  }

  public int getAddAlarmWaitTime() {
    return this.addAlarmWaitTime;
  }

  public boolean isSwitchEventOpen() {
    return this.switchEventOpen;
  }

  public int getMaxChannelThreadNum() {
    return this.maxChannelThreadNum;
  }

  public List getMsgDtoClassNames() {
    return this.msgDtoClassNames;
  }
}