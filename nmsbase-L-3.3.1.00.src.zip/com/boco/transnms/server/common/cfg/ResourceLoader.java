package com.boco.transnms.server.common.cfg;

import com.boco.common.util.debug.LogHome;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import org.apache.commons.logging.Log;

public class ResourceLoader
{
  public static String[] getResource(String fileName)
  {
    ResourceLoader _instance = new ResourceLoader();
    String[] resources = null;
    try {
      ArrayList res = new ArrayList();
      Enumeration systemResources = ResourceLoader.class.getClassLoader().getResources(fileName);

      while (systemResources.hasMoreElements()) {
        URL nextElement = (URL)systemResources.nextElement();
        LogHome.getLog().info(nextElement);
        res.add(nextElement.toString());
      }
      resources = new String[res.size()];
      for (int i = 0; i < res.size(); i++)
        resources[i] = ((String)res.get(i));
    }
    catch (Exception e) {
      e.printStackTrace();
    }
    return resources;
  }

  public static void main(String[] args)
  {
    try {
      boXmlFiles = getResource("com/boco/transnms/common/dto/base/dtoNames.properties");
    }
    catch (Exception e)
    {
      String[] boXmlFiles;
      e.printStackTrace();
    }
  }
}