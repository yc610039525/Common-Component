package com.boco.transnms.server.common.cfg;

import com.boco.common.util.debug.LogHome;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class IrmsAppCfg
{
  private static IrmsAppCfg instance = new IrmsAppCfg();
  private String irmsrtuUrl;
  private String errorExcelPost;
  private String reourceSheetDonwload;
  private String errorExcel;
  private String resourceSheetRpcUlr;
  private String phoneCollectionExcel;
  private String ftpServerIP;
  private String nmsOriginDataDir;
  private String userName;
  private String password;
  private String rpcUlr;
  private String irmsOriginDataDir;
  private Map<String, String> splitResourceStat;
  private Map<String, List<String>> devClassType;
  private List<String> objectDevIndexClassNames = new ArrayList();

  public static IrmsAppCfg getInstance() {
    return instance;
  }

  public String getIrmsrtuUrl() {
    return this.irmsrtuUrl;
  }

  public String getReourceSheetDonwload() {
    return this.reourceSheetDonwload;
  }

  public String getErrorExcelPost() {
    return this.errorExcelPost;
  }

  public String getErrorExcel() {
    return this.errorExcel;
  }

  public String getFtpServerIP() {
    return this.ftpServerIP;
  }

  public String getNmsOriginDataDir() {
    return this.nmsOriginDataDir;
  }

  public String getPassword() {
    return this.password;
  }

  public String getUserName() {
    return this.userName;
  }

  public String getIrmsOriginDataDir() {
    return this.irmsOriginDataDir;
  }

  public String getResourceSheetRpcUlr() {
    return this.resourceSheetRpcUlr;
  }

  public String getPhoneCollectionExcel() {
    return this.phoneCollectionExcel;
  }

  public String getRpcUlr() {
    return this.rpcUlr;
  }

  public List getObjectDevIndexClassNames() {
    return this.objectDevIndexClassNames;
  }

  public Map getDevClassType() {
    return this.devClassType;
  }

  public Map getSplitResourceStat() {
    return this.splitResourceStat;
  }

  public void loadCfgFile(String springCfgFile)
  {
    try
    {
      springContext = new FileSystemXmlApplicationContext(springCfgFile);
    }
    catch (Exception ex)
    {
      FileSystemXmlApplicationContext springContext;
      LogHome.getLog().info("不支持详细配置, file=" + springCfgFile + ", expMessage=" + ex.getMessage());
    }
  }

  public void setIrmsrtuUrl(String irmsrtuUrl) {
    this.irmsrtuUrl = irmsrtuUrl;
  }

  public void setErrorExcelPost(String errorExcelPost) {
    this.errorExcelPost = errorExcelPost;
  }

  public void setReourceSheetDonwload(String reourceSheetDonwload) {
    this.reourceSheetDonwload = reourceSheetDonwload;
  }

  public void setErrorExcel(String errorExcel) {
    this.errorExcel = errorExcel;
  }

  public void setFtpServerIP(String ftpServerIP) {
    this.ftpServerIP = ftpServerIP;
  }

  public void setNmsOriginDataDir(String nmsOriginDataDir) {
    this.nmsOriginDataDir = nmsOriginDataDir;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public void setIrmsOriginDataDir(String irmsOriginDataDir) {
    this.irmsOriginDataDir = irmsOriginDataDir;
  }

  public void setResourceSheetRpcUlr(String resourceSheetRpcUlr) {
    this.resourceSheetRpcUlr = resourceSheetRpcUlr;
  }

  public void setPhoneCollectionExcel(String phoneCollectionExcel) {
    this.phoneCollectionExcel = phoneCollectionExcel;
  }

  public void setRpcUlr(String rpcUlr) {
    this.rpcUlr = rpcUlr;
  }

  public void setObjectDevIndexClassNames(List objectDevIndexClassNames) {
    this.objectDevIndexClassNames = objectDevIndexClassNames;
  }

  public void setDevClassType(Map devClassType) {
    this.devClassType = devClassType;
  }

  public void setSplitResourceStat(Map splitResourceStat) {
    this.splitResourceStat = splitResourceStat;
  }
}