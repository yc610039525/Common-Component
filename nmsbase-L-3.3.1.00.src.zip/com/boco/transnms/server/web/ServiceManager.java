package com.boco.transnms.server.web;

import com.boco.raptor.bo.ibo.core.IMsgBusServiceBO;
import com.boco.raptor.common.message.GenericMessage;
import com.boco.raptor.common.message.IMessage;
import com.boco.raptor.common.message.ISimpleMsgListener;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.misc.DevState;
import com.boco.transnms.server.bo.base.BoHomeFactory;
import com.boco.transnms.server.bo.ibo.misc.ISystemDevManageBO;
import com.boco.transnms.server.common.cfg.TnmsServerName;
import com.boco.transnms.server.common.cfg.TnmsServerName.ServerName;
import com.boco.transnms.server.dao.base.DaoHelper;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class ServiceManager
  implements ISimpleMsgListener
{
  private static String NODE_STATE_QUERY = "NODE_STATE_QUERY";
  private static String NODE_STATE_ACK = "NODE_STATE_ACK_1";
  private String serverName = TnmsServerName.getLocalServerNameStr();
  private DevState devState = null;
  private static ServiceManager instance = new ServiceManager();

  public static ServiceManager getInstance() {
    if (instance == null) {
      instance = new ServiceManager();
    }
    return instance;
  }

  public ServiceManager()
  {
    initServerState();
  }

  private boolean isMainServer() {
    if ((TnmsServerName.getLocalServerNameStr().equals(TnmsServerName.ServerName.CM.toString())) || (TnmsServerName.getLocalServerNameStr().equals(TnmsServerName.ServerName.DM.toString())))
    {
      return true;
    }
    return false;
  }

  private void initServerState() {
    String ip = null;
    String property = System.getProperty("jboss.bind.address");
    if ((property != null) && (property.length() > 0))
      ip = property;
    else
      try {
        ip = InetAddress.getLocalHost().getHostAddress();
      }
      catch (UnknownHostException ex)
      {
      }
    String port = System.getProperty("jboss.bind.port");
    long devType = TnmsServerName.getLocalServerId();
    this.devState = new DevState();
    this.devState.setDevIp(ip);
    this.devState.setDevPort(port);
    this.devState.setDevInfo(TnmsServerName.getLocalServerFullName());
    this.devState.setDevName(TnmsServerName.getLocalServerNameStr());
    String cuid = TnmsServerName.getLocalServerNameStr() + ip;

    if (port != null) {
      cuid = cuid + ":" + port;
    }
    this.devState.setCuid(cuid);
    this.devState.setDevType(Long.valueOf(devType));
  }

  public DevState getLocalServerState() {
    return this.devState;
  }

  public void sendQueryMsg() {
    GenericMessage ackMsg = new GenericMessage(TopicCachedName.SyncNodeTopicName, NODE_STATE_QUERY + "-" + this.serverName, "");
    ackMsg.setSourceName(DaoHelper.getCallClassName());
    getMsgBusServiceBO().sendMessage(new BoActionContext(), ackMsg);
  }

  public void sendAckMsg() {
    GenericMessage ackMsg = null;

    if (TopicCachedName.SyncNodeTopicName.equals("T_CM_NODE_REQ"))
      ackMsg = new GenericMessage("Q_CM_NODE_ACK", NODE_STATE_ACK, this.devState);
    else if (TopicCachedName.SyncNodeTopicName.equals("T_DM_NODE_REQ")) {
      ackMsg = new GenericMessage("Q_DM_NODE_ACK", NODE_STATE_ACK, this.devState);
    }
    ackMsg.setSourceName(DaoHelper.getCallClassName());
    getMsgBusServiceBO().sendMessage(new BoActionContext(), ackMsg);
  }

  private IMsgBusServiceBO getMsgBusServiceBO() {
    return (IMsgBusServiceBO)BoHomeFactory.getInstance().getBO("IMsgBusServiceBO");
  }

  private ISystemDevManageBO getSystemDevManageBO() {
    return (ISystemDevManageBO)BoHomeFactory.getInstance().getBO(ISystemDevManageBO.class);
  }

  public void notify(IMessage msg)
  {
    if ((msg instanceof GenericMessage)) {
      String[] msgStrs = msg.getTargetId().split("-");
      if (msg.getTargetId().indexOf("-") > 0) {
        String targetId = msgStrs[0];
        String targetServerName = msgStrs[1];

        if ((targetId.equals(NODE_STATE_QUERY)) && (isMainServer(targetServerName))) {
          sendAckMsg();
        }
      }
      else if (msg.getTargetId().equals(NODE_STATE_ACK))
      {
        if (isMainServer(TnmsServerName.getLocalServerNameStr())) {
          Object obj = msg.getDataObject();
          if ((obj instanceof DevState))
            getSystemDevManageBO().regDevState(new BoActionContext(), (DevState)obj);
        }
      }
    }
  }

  private boolean isMainServer(String serverName)
  {
    if ((TnmsServerName.ServerName.CM.toString().equals(serverName)) || (TnmsServerName.ServerName.DM.toString().equals(serverName)))
    {
      return true;
    }
    return false;
  }
}