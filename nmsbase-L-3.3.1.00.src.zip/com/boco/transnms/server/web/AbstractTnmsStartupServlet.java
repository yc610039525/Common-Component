package com.boco.transnms.server.web;

import com.boco.common.util.debug.LogHome;
import com.boco.core.commons.ProjectVersion;
import com.boco.raptor.common.message.MsgBusManager;
import com.boco.transnms.client.model.base.BoCacheCmdProxy;
import com.boco.transnms.client.model.base.BoProxyFactory;
import com.boco.transnms.client.model.base.ExportBoManager;
import com.boco.transnms.common.cache.CustomCacheManagerFactory;
import com.boco.transnms.common.dto.SystemPara;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.server.bo.base.BoHomeFactory;
import com.boco.transnms.server.bo.base.IBoHome;
import com.boco.transnms.server.bo.ibo.system.ISystemParaBO;
import com.boco.transnms.server.bo.scheduler.SchedulerBO;
import com.boco.transnms.server.common.cfg.ActionFilterCfg;
import com.boco.transnms.server.common.cfg.SystemEnv;
import com.boco.transnms.server.common.cfg.TnmsAppCfg;
import com.boco.transnms.server.common.cfg.TnmsRuntime;
import com.boco.transnms.server.common.cfg.TnmsServerName;
import com.boco.transnms.server.common.cfg.TnmsServerName.ServerName;
import com.boco.transnms.server.common.cfg.TransInterfaceCfg;
import com.boco.transnms.server.common.cfg.TransNmsCfg;
import com.boco.transnms.server.dao.base.DaoHomeFactory;
import com.boco.transnms.server.dao.base.TnmsCacheManagerFactory;
import com.boco.transnms.server.dao.base.internal.ClassUtils;
import com.boco.transnms.server.dao.base.internal.Globals;
import java.io.File;
import java.io.PrintStream;
import java.util.Hashtable;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import org.apache.commons.logging.Log;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public abstract class AbstractTnmsStartupServlet extends HttpServlet
{
  private String cfgPath;

  protected String initServerName()
  {
    String fullServerName = "";
    try
    {
      fullServerName = getServerName();
      if ((fullServerName == null) || (fullServerName.trim().length() <= 0)) {
        LogHome.getLog().error("----    没有配置服务器名称，无法启动服务器！    ---");
        System.exit(0);
      }
      else {
        String serverName = fullServerName;
        if (fullServerName.contains("-")) {
          serverName = fullServerName.split("-")[0];
        }
        System.setProperty("servername", serverName);
        System.setProperty("TNMS_LOG_HOME", serverName.toLowerCase());
      }
    } catch (Exception ex) {
      LogHome.getLog().error("设置服务器参数出错：", ex);
    }
    return fullServerName;
  }

  protected void initServerId() {
    String fullServerName = getServerName();
    TnmsServerName.setLocalServerFullName(fullServerName);
    String serverName = TnmsServerName.getLocalServerNameStr();
    LogHome.getLog().info("设置系统参数：servername=" + System.getProperty("servername"));
    int serverId = -128;
    if ((fullServerName.contains("AMRTU")) || (fullServerName.contains("COLLECTCM")) || (fullServerName.contains("EVENTCM")) || (fullServerName.contains("PCU")) || (fullServerName.startsWith("AM_AN-")) || (fullServerName.startsWith("AM-")))
    {
      String[] str = fullServerName.split("-");
      if (str.length > 1) {
        serverId = TnmsServerName.getLocalServerId() + Integer.parseInt(str[1]) - 1;
        LogHome.getLog().info("分布式服务器id设置成功：fullServerName=" + fullServerName + "" + serverId);
      } else {
        serverId = TnmsServerName.getLocalServerId();
        LogHome.getLog().info("分布式服务器id设置错误：fullServerName=" + fullServerName + "" + serverId + "，请检查安装目录命名是否符合规范[app-collectcm-1][app-eventcm-1][app-amrtu-1],无法启动服务！");

        System.exit(0);
      }
    } else {
      serverId = TnmsServerName.getLocalServerId();
    }
    Globals.setSERVERID(serverId);
    LogHome.getLog().info("设置系统参数：serverId=" + serverId);
  }

  protected String getServerName() {
    String fullServerName = "";
    try {
      String[] serverNames = getXmlFiles("servername");
      if (serverNames.length > 0) {
        fullServerName = serverNames[0];
      }

      String programName = System.getProperty("program.name");
      String gserverName = programName;
      if ((programName != null) && (programName.contains("-"))) {
        gserverName = programName.split("-")[0];
        if ((gserverName.equalsIgnoreCase("amrtu")) || (gserverName.equalsIgnoreCase("collectcm")) || (gserverName.equalsIgnoreCase("eventcm")) || (gserverName.equalsIgnoreCase("am_an")) || (gserverName.equalsIgnoreCase("am")))
        {
          fullServerName = programName.toUpperCase();
        }
      }
    } catch (Exception ex) {
      LogHome.getLog().error("获取服务器参数出错：", ex);
    }
    return fullServerName;
  }

  public void init() throws ServletException {
    initNodeStateSyncName();
    String fullServerName = initServerName();
    initServerId();
    LogHome.getLog().info("----    初始化TNMS系统[" + fullServerName + "]    ---");
    try {
      String serverHome = SystemEnv.getPathEnv("TNMS_SERVER_HOME");
      this.cfgPath = (serverHome + File.separatorChar + "tnms-conf");

      LogHome.getLog().info("TNMS-Version：" + ProjectVersion.getBuildVersion());
      LogHome.getLog().info("TNMS-BuildDate：" + ProjectVersion.getBuildDate());
      super.init();
      loadCfgFile();
      initFactory();
      ClassUtils.getInstance().initOid();
      initBeforeServiceLoad();

      initJmsManager();
      initDaoHome();
      createBoHome();
      initProxy();
      loadCoreCfg();
      TnmsRuntime.getInstance();
      initBoHome();

      initMessageListener();
      initActionFilterCfg();

      initAfterServiceLoad();

      if ((fullServerName.equals("CM")) || (TnmsServerName.isAllInOneServer())) {
        initUserCountOnline();
      }
      LogHome.getLog().info("----  TransNMS系统[" + TnmsServerName.getLocalServerNameStr() + "]初始化完成  ---");
      LogHome.getLog().info("TNMS-Version：" + ProjectVersion.getBuildVersion());
      LogHome.getLog().info("TNMS-BuildDate：" + ProjectVersion.getBuildDate());
    }
    catch (Exception ex)
    {
      LogHome.getLog().error(ex, ex);
      ex.printStackTrace();
      System.exit(0);
      LogHome.getLog().info("服务器启动失败！！！！");
      throw new ServletException(ex);
    }
  }

  private void initNodeStateSyncName() {
    String topicName = getInitParameter("topicName");

    if (("T_CM_NODE_REQ".equals(topicName)) || ("T_DM_NODE_REQ".equals(topicName)))
      TopicCachedName.SyncNodeTopicName = topicName.trim();
  }

  protected abstract void initBeforeServiceLoad();

  protected abstract void initAfterServiceLoad();

  protected void initMessageListener()
  {
  }

  private void initJmsManager()
  {
    try
    {
      classAppContext = new FileSystemXmlApplicationContext(new String[] { this.cfgPath + File.separatorChar + "tnms-jms-cfg.xml" });
    }
    catch (Exception ex)
    {
      FileSystemXmlApplicationContext classAppContext;
      LogHome.getLog().error("消息管理器加载失败", ex);
    }
  }

  private void initUserCountOnline() throws Exception {
    String paraClassName = "用户数";
    String paraName = "UserCount";
    String value = "0";
    String desc = "";
    ISystemParaBO ibo = (ISystemParaBO)BoHomeFactory.getInstance().getBO(ISystemParaBO.class);
    SystemPara sysPara = ibo.getSystemPara(new BoActionContext(), paraClassName, paraName);
    if (sysPara != null)
      ibo.modifySystemPara(new BoActionContext(), paraClassName, paraName, value);
    else
      ibo.createSystemPara(new BoActionContext(), paraClassName, paraName, value, desc);
  }

  private void initVersion() throws Exception
  {
    String TRANSNMS_VERSION = ProjectVersion.getBuildVersion();
    String TRANSNMS_DEPLOY_DATE = ProjectVersion.getBuildDate();
    String paraClassName = "版本号";
    String paraName = "Version";
    String value = TRANSNMS_VERSION + "," + TRANSNMS_DEPLOY_DATE;
    String desc = "";
    ISystemParaBO ibo = (ISystemParaBO)BoHomeFactory.getInstance().getBO("ISystemParaBO");
    SystemPara sysPara = ibo.getSystemPara(new BoActionContext(), paraClassName, paraName);
    if (sysPara != null)
      ibo.modifySystemPara(new BoActionContext(), paraClassName, paraName, value);
    else
      ibo.createSystemPara(new BoActionContext(), paraClassName, paraName, value, desc);
  }

  protected void loadCfgFile()
    throws Exception
  {
    TransNmsCfg.loadCfgFile(this.cfgPath + File.separatorChar + "tnmscfg.xml");
    TnmsAppCfg.getInstance().loadCfgFile(this.cfgPath + File.separatorChar + "tnms-app-cfg.xml");
    try
    {
      TransInterfaceCfg.getInstance(); TransInterfaceCfg.loadCfgFile(this.cfgPath + File.separatorChar + "tnms-interface-cfg.xml");
    } catch (Exception ex) {
      LogHome.getLog().error("加载接口配置文件tnms-interface-cfg.xml失败", ex);
    }
    try {
      new ClassPathXmlApplicationContext(new String[] { "mqswitch-handler-cfg.xml" });
    } catch (Exception ex) {
      LogHome.getLog().error("MQ主备切换处理器注册失败", ex);
    }
  }

  protected void loadCoreCfg()
    throws Exception
  {
  }

  protected void initFactory()
    throws Exception
  {
    Hashtable props = new Hashtable();
  }

  protected void initProxy()
    throws Exception
  {
    String[] proxyXmlFiles = getXmlFiles("proxyXmlFiles");
    BoProxyFactory.getInstance().loadSpringBeanFiles(proxyXmlFiles);
  }

  protected void createBoHome() throws Exception {
    LogHome.getLog().info("新的BO初始化-----------------");
    String[] daoXmlFiles = getXmlFiles("exportBoXmlFiles");
    if (daoXmlFiles.length <= 0) {
      daoXmlFiles = new String[] { "export-bo.xml" };
    }
    ExportBoManager.createInstance(daoXmlFiles);
    BoHomeFactory.getInstance().setIsInitBoHome(false);

    String ps = TransNmsCfg.getInstance().getPluginSuffix();
    String[] allBoXmlFiles = { "classpath*:/service/bo-*.xml" };
    if ((ps != null) && (!ps.trim().equals(""))) {
      LogHome.getLog().info("启用扩展服务，服务唯一标识为：(" + ps + ")");
      allBoXmlFiles = new String[] { "classpath*:/service/bo-*.xml", "classpath*:/service/bo_ext_" + ps + "_*.xml" };
    } else {
      LogHome.getLog().info("未启用扩展服务!");
    }
    try {
      BoHomeFactory.getInstance().createBeanBoHome("TRANSNMS_CONTEXT", allBoXmlFiles);
    } catch (Exception e) {
      LogHome.getLog().error(e, e);
    }
  }

  protected void initBoHome()
    throws Exception
  {
    BoHomeFactory.getInstance().initBoHome("TRANSNMS_CONTEXT");
    String[] boClassNames = BoHomeFactory.getInstance().getBoHome("TRANSNMS_CONTEXT").getBoNames();
  }

  protected void initDaoHome()
    throws Exception
  {
    ClassPathXmlApplicationContext classAppContext = new ClassPathXmlApplicationContext(new String[] { "tnms-server-cfg.xml" });
    String serverName = TnmsServerName.getLocalServerNameStr();
    String cacheCfgFileName = "tnms-cache-cfg.xml";
    classAppContext = new ClassPathXmlApplicationContext(new String[] { cacheCfgFileName });
    if ((serverName.equals(TnmsServerName.ServerName.AM.toString())) || (serverName.equals(TnmsServerName.ServerName.AMRTU.toString())) || (serverName.equals(TnmsServerName.ServerName.FAULT.toString())) || (serverName.equals(TnmsServerName.ServerName.ROOTALARM.toString())) || (serverName.equals(TnmsServerName.ServerName.ALARMNTP.toString())) || (serverName.equals(TnmsServerName.ServerName.PM.toString())) || (serverName.equals(TnmsServerName.ServerName.UIP.toString())) || (serverName.equals(TnmsServerName.ServerName.AMDTS.toString())) || (serverName.equals(TnmsServerName.ServerName.ALARMALALYSE_AN.toString())) || (serverName.contains(TnmsServerName.ServerName.AM_AN.toString())))
    {
      TnmsCacheManagerFactory.getInstance().setSyncTopicName("T_AM_SVR_CACHE_SYNC");
      CustomCacheManagerFactory.getInstance().setSyncTopicName("T_AM_CUSTOM_CACHE_SYNC");
      BoCacheCmdProxy.getInstance().setSyncTopicName("T_AM_BO_CACHE_SYNC");
    }

    String ps = TransNmsCfg.getInstance().getPluginSuffix();
    String[] allBoXmlFiles = { "classpath*:/service/dao*.xml" };
    if ((ps != null) && (!ps.trim().equals("")))
      allBoXmlFiles = new String[] { "classpath*:/service/dao*.xml", "classpath*:/service/dao_ext_" + ps + "_*.xml" };
    try
    {
      DaoHomeFactory.getInstance().createDaoHome("TRANSNMS_CONTEXT", allBoXmlFiles);
    } catch (Exception e) {
      LogHome.getLog().error(e, e);
    }
  }

  protected String[] getXmlFiles(String initParaName)
  {
    String xmlFiles = getInitParameter(initParaName);
    String[] _xmlFiles = xmlFiles.split(",");
    for (int i = 0; i < _xmlFiles.length; i++) {
      _xmlFiles[i] = _xmlFiles[i].trim();
    }
    return _xmlFiles;
  }

  private void initActionFilterCfg() {
    String serverHome = SystemEnv.getPathEnv("TNMS_SERVER_HOME");
    String cfgPath = serverHome + File.separatorChar + "tnms-conf";
    String springCfgFile = cfgPath + File.separatorChar + "tnms-menu-cfg.xml";
    ActionFilterCfg.createIntance(springCfgFile);
  }

  public void destroy() {
    try {
      System.out.println("----TnmsStartupServlet destroy---");
      ((SchedulerBO)BoHomeFactory.getInstance().getBO("SchedulerBO")).stop();
      MsgBusManager.getInstance().removeAll();
    } catch (Exception ex) {
      LogHome.getLog().error(ex);
    }
  }
}