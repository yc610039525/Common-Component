package com.boco.transnms.server.web;

import com.boco.transnms.server.common.cfg.SystemEnv;
import java.io.File;
import java.io.PrintStream;

public final class CheckBoStateMain
{
  public static void main(String[] args)
  {
    System.out.println("----    检查服务器BO状态开始    ---");
    String serverHome = SystemEnv.getPathEnv("TNMS_SERVER_HOME");

    String cfgPath = serverHome + File.separatorChar + "tnms-conf";
    String[] boXmlFiles = { cfgPath + "/tnmsbo.xml" };

    System.out.println("----    检查服务器BO状态结束    ---");
    System.exit(0);
  }
}