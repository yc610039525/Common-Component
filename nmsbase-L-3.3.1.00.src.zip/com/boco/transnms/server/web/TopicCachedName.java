package com.boco.transnms.server.web;

public class TopicCachedName
{
  public static String SyncNodeTopicName = "";
}