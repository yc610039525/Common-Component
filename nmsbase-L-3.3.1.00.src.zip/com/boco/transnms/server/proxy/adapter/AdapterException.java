package com.boco.transnms.server.proxy.adapter;

public class AdapterException extends RuntimeException
{
  private static final long serialVersionUID = -2879852191328741521L;

  public AdapterException()
  {
  }

  public AdapterException(String message)
  {
    super(message);
  }

  public AdapterException(String message, Throwable cause)
  {
    super(message, cause);
  }

  public AdapterException(Throwable cause)
  {
    super(cause);
  }
}