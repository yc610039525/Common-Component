package com.boco.transnms.server.proxy.adapter;

import com.boco.common.util.debug.LogHome;
import com.boco.transnms.client.model.base.BoCmdFactory;
import com.boco.transnms.client.model.base.IBoCommand;
import com.boco.transnms.client.model.base.XrpcBoProxy;
import com.boco.transnms.client.model.base.XrpcUrlManager;
import com.boco.transnms.server.dao.base.DaoHelper;
import org.apache.commons.logging.Log;

public class XrpcAdapter
  implements IAdapter
{
  private static XrpcAdapter instance = null;

  public static XrpcAdapter getInstance()
  {
    if (instance == null) {
      instance = new XrpcAdapter();
    }
    return instance;
  }

  public Object exec(String rtuUrl, String cmdName, Object param) throws AdapterException {
    try {
      IBoCommand syscmd = BoCmdFactory.getInstance().createBoCmd(cmdName, new Object[] { param });

      XrpcBoProxy boProxy = boProxy = new XrpcBoProxy(rtuUrl);

      return boProxy.exec(syscmd);
    } catch (Exception e) {
      throw new AdapterException(e);
    }
  }

  public Object execWithTimeout(String rtuUrl, String cmdName, Object param, int _conntimeout, int _timeout) throws AdapterException {
    try {
      IBoCommand syscmd = BoCmdFactory.getInstance().createBoCmd(cmdName, new Object[] { param });

      XrpcBoProxy boProxy = new XrpcBoProxy(rtuUrl);

      boProxy.setConnectionTimeout(_conntimeout);
      boProxy.setTimeout(_timeout);
      return boProxy.exec(syscmd);
    }
    catch (Exception e)
    {
      throw new AdapterException(e);
    }
  }

  public Object remoteExec(String serverName, IBoCommand cmd) {
    try {
      String xrpcUrl = XrpcUrlManager.getInstance().getXrpcUrl(serverName);
      if (!DaoHelper.isNotEmpty(xrpcUrl)) {
        xrpcUrl = XrpcUrlManager.getInstance().getXrpcUrl("TRANSNMS_CONTEXT");
      }
      XrpcBoProxy boProxy = new XrpcBoProxy(xrpcUrl);

      return boProxy.exec(cmd);
    } catch (Exception e) {
      LogHome.getLog().error("根据ptp获取ctp出错", e);
      throw new AdapterException(e);
    }
  }
}