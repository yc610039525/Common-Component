package com.boco.transnms.server.proxy.adapter;

public abstract interface IAdapter
{
}