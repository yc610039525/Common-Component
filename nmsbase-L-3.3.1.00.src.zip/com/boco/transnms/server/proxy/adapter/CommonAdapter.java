package com.boco.transnms.server.proxy.adapter;

import com.boco.common.util.debug.LogHome;
import com.boco.transnms.server.common.cfg.TnmsRuntime;
import com.boco.transnms.server.common.cfg.TransNmsCfg;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.logging.Log;

public class CommonAdapter
  implements IAdapter
{
  private Map confiMap;
  private static CommonAdapter instance = new CommonAdapter();
  private static final String urlSubMsg = "services/adaptionCommonPortType";
  public static final String COMMON_COM_HEADER = "CommonAdapter.wsURL";
  public static final String CM_URL = "adaptionCmPortType";
  public static final String RTU_URL = "adaptionRtumanagePortType";
  public static final String COMMON_URL = "adaptionCommonPortType";
  public static final String MSTP_URL = "adaptionMstpPortType";
  public static final String WDM_URL = "adaptionWDMPortType";
  public static final String PM_URL = "adaptionPerormancePortType";
  public static final String PG_URL = "adaptionProtectPortType";
  public static final String SRV_URL = "adaptionSrvPortType";
  public static final String LOOP_URL = "adaptionMaintenancePortType";
  private boolean supportXrpc = false;
  public static final String XRPC_URLHEAD = "xrpc.url";

  private CommonAdapter()
  {
    TransNmsCfg cfg = TransNmsCfg.getInstance();
    this.confiMap = new HashMap();
    String xrpcUrlAddress = TnmsRuntime.getInstance().get("XRPC_URL");
    if (xrpcUrlAddress != null) {
      LogHome.getLog().warn("系统支持XRPC采集操作");
      this.supportXrpc = true;
      this.confiMap.put("xrpc.url", TnmsRuntime.getInstance().get("XRPC_URL"));
      int key = xrpcUrlAddress.indexOf("xrpcProxyServlet");
      if (key > 0)
        this.confiMap.put("CommonAdapter.wsURL", xrpcUrlAddress.substring(0, key) + "services/adaptionCommonPortType");
    }
  }

  public static CommonAdapter getInstance()
  {
    return instance;
  }

  public boolean isSupportXrpc() {
    return this.supportXrpc;
  }

  public Map getRtuConfigMap() {
    return this.confiMap;
  }

  public void getVersion()
  {
  }
}