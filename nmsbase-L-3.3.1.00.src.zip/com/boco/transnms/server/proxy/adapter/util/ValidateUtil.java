package com.boco.transnms.server.proxy.adapter.util;

import java.sql.Timestamp;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ValidateUtil
{
  public static boolean isBlankOrNull(String value)
  {
    return (null == value) || (value.trim().length() == 0);
  }

  public static boolean isInt(String value)
  {
    try
    {
      Integer.parseInt(value);
    } catch (NumberFormatException nfe) {
      return false;
    }
    return true;
  }

  public static boolean isFloat(String value)
  {
    try
    {
      Float.parseFloat(value);
    } catch (NumberFormatException nfe) {
      return false;
    }
    return true;
  }

  public static boolean isDouble(String value)
  {
    try
    {
      Double.parseDouble(value);
    } catch (NumberFormatException nfe) {
      return false;
    }
    return true;
  }

  public static boolean isDateTime(String value)
  {
    return null != getDateFromString(value);
  }

  public static boolean isDateTime(String value, String datePattern)
  {
    return null == getDateFromString(value, datePattern);
  }

  public static boolean isShort(String value)
  {
    try
    {
      Short.parseShort(value);
    } catch (NumberFormatException nfe) {
      return false;
    }
    return true;
  }

  public static boolean isLong(String value)
  {
    try
    {
      Long.parseLong(value);
    } catch (NumberFormatException nfe) {
      return false;
    }
    return true;
  }

  public static boolean isByte(String value)
  {
    try
    {
      Byte.parseByte(value);
    } catch (NumberFormatException nfe) {
      return false;
    }
    return true;
  }

  public static boolean isChar(String value)
  {
    return 1 == value.length();
  }

  public static boolean isBoolean(String value)
  {
    String tmpStr = null;
    try {
      tmpStr = value.toUpperCase();
      if ((!tmpStr.equals("TRUE")) && (!tmpStr.equals("FALSE")))
        return false;
    }
    catch (NumberFormatException e) {
      return false;
    }
    return true;
  }

  public static boolean isLegalString(String value)
  {
    String illegalString = "~!@$%^`><";

    int length = value.length();
    for (int i = 0; i < length; i++) {
      char ch = value.charAt(i);

      if (-1 != illegalString.lastIndexOf(String.valueOf(ch))) {
        return false;
      }
    }
    return true;
  }

  public static boolean isNotNullLegalString(String value)
  {
    return (!isBlankOrNull(value)) && (isLegalString(value));
  }

  public static boolean isEmail(String value)
  {
    return isNotNullLegalString(value);
  }

  public static boolean maxLength(String value, int length)
  {
    return getStringLength(value) <= length;
  }

  public static boolean minLength(String value, int length)
  {
    return getStringLength(value) >= length;
  }

  public static boolean isInRange(int value, int max, int min)
  {
    return (value <= max) && (value >= min);
  }

  public static boolean isInRange(float value, float max, float min)
  {
    return (value <= max) && (value >= min);
  }

  public static boolean isInRange(double value, double max, double min)
  {
    return (value <= max) && (value >= min);
  }

  public static boolean isInRange(String value, int max, int min)
  {
    int length = getStringLength(value);
    return (length <= max) && (length >= min);
  }

  public static boolean isInRange(Date value, Date max, Date min)
  {
    return (value.compareTo(max) <= 0) && (value.compareTo(min) >= 0);
  }

  public static boolean isInclude(String value, String subString)
  {
    return value.indexOf(subString) < 0;
  }

  public static boolean isMatchPattern(String value, String pattern)
  {
    Pattern p = Pattern.compile(pattern);
    Matcher m = p.matcher(value);
    return m.matches();
  }

  public static int getIntValue(String value)
  {
    int tmpInt = -1;
    try {
      tmpInt = Integer.parseInt(value);
    } catch (Exception e) {
      return -1;
    }
    return tmpInt;
  }

  public static float getFloatValue(String value)
  {
    float tmpFloat = 0.0F;
    try {
      tmpFloat = Float.parseFloat(value);
    } catch (Exception e) {
      return 0.0F;
    }
    return tmpFloat;
  }

  public static double getDoubleValue(String value)
  {
    double tmpDouble = 0.0D;
    try {
      tmpDouble = Double.parseDouble(value);
    } catch (Exception e) {
      return 0.0D;
    }
    return tmpDouble;
  }

  public static boolean getBooleanValue(String value)
  {
    boolean tmpBool = false;
    try {
      tmpBool = Boolean.valueOf(value).booleanValue();
    } catch (Exception e) {
      return false;
    }
    return tmpBool;
  }

  public static Date getDateValue(String value)
  {
    return getDateFromString(value);
  }

  public static int getStringLength(String s)
  {
    int length = -1;
    try {
      length = s.getBytes("GBK").length;
    } catch (Exception e) {
      e.printStackTrace();
    }

    return length;
  }

  public static Date getDateFromString(String in)
  {
    SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
    ParsePosition pos = new ParsePosition(0);
    try
    {
      return formatter.parse(in, pos);
    } catch (Exception e) {
    }
    return null;
  }

  public static Date getGTDateFromString(String in)
  {
    SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
    ParsePosition pos = new ParsePosition(0);
    try {
      formatter.setTimeZone(TimeZone.getTimeZone("GMT-0"));
      return formatter.parse(in, pos);
    } catch (Exception e) {
    }
    return null;
  }

  public static Date getDateFromString(String in, String datePattern)
  {
    SimpleDateFormat formatter = new SimpleDateFormat(datePattern);
    ParsePosition pos = new ParsePosition(0);
    try {
      return formatter.parse(in, pos);
    } catch (Exception e) {
    }
    return null;
  }

  public static Timestamp getTimestampFromString(String in, String datePattern)
  {
    return new Timestamp(getDateFromString(in, datePattern).getTime());
  }

  public static Timestamp getTimestampFromString(String in)
  {
    return new Timestamp(getDateFromString(in).getTime());
  }

  public static String getStringFromData(Date date)
  {
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    return formatter.format(date);
  }

  public static String getCapitalWord(String word)
  {
    String tmpFirst = word.substring(0, 1);
    String tmpLast = word.substring(1);
    tmpFirst = tmpFirst.toUpperCase();
    return tmpFirst + tmpLast;
  }

  public static boolean includeString(String[] strs, String str)
  {
    for (int i = 0; i < strs.length; i++) {
      if (str.equals(strs[i])) {
        return true;
      }
    }
    return false;
  }

  public static List parseListString(String value)
  {
    if (null == value) {
      return null;
    }
    List list = new ArrayList();
    for (StringTokenizer st = new StringTokenizer(value, ","); st.hasMoreTokens(); ) {
      list.add(st.nextToken());
    }
    return list;
  }
}