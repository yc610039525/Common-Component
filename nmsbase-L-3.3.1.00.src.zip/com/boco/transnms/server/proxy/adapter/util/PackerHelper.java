package com.boco.transnms.server.proxy.adapter.util;

import cn.com.chinamobile.adaption.adaptionInterface.adaptionCommon.impl.NameAndValueTypeImpl;
import cn.com.chinamobile.adaption.adaptionInterface.adaptionCommon.impl.NamingAttributesTypeImpl;
import cn.com.chinamobile.adaption.adaptionInterface.adaption_mstp_service.EthServiceType;
import cn.com.chinamobile.adaption.adaptionInterface.pon.adaptionCommon.NameAndValueType.Factory;
import cn.com.chinamobile.adaption.adaptionInterface.pon.adaptionCommon.NamingAttributesType.Factory;
import com.boco.common.util.debug.LogHome;
import com.boco.transnms.common.bussiness.helper.FdnHelper;
import org.apache.commons.logging.Log;

public class PackerHelper
{
  public static String fdnSpliter1 = ":";

  public static String fdnSpliter2 = "=";

  public static String fdnSpliter3 = "/";

  public static String makeFdnInfo(cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NamingAttributesType name, String emsFdn)
  {
    StringBuffer fdnBuffer = new StringBuffer();
    try
    {
      if (emsFdn == null) {
        if ((name != null) && (name.getItem() != null)) {
          for (cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NameAndValueType nameValueStr : name.getItem()) {
            fdnBuffer.append(nameValueStr.getName()).append(fdnSpliter2).append(nameValueStr.getValue()).append(fdnSpliter1);
          }

          return fdnBuffer.toString().substring(0, fdnBuffer.length() - 1);
        }
        return " ";
      }

      if ((name != null) && (name.getItem() != null)) {
        for (cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NameAndValueType nameValueStr : name.getItem()) {
          if (nameValueStr.getName().equals("EMS"))
            fdnBuffer.append(emsFdn).append(fdnSpliter1);
          else {
            fdnBuffer.append(nameValueStr.getName()).append(fdnSpliter2).append(nameValueStr.getValue()).append(fdnSpliter1);
          }
        }

        return fdnBuffer.toString().substring(0, fdnBuffer.length() - 1);
      }
      return " ";
    }
    catch (Exception ex)
    {
    }

    return " ";
  }

  public static String makeFdnInfo(com.boco.rtu.ext.adaptionCommon.NamingAttributesType name, String emsFdn)
  {
    StringBuffer fdnBuffer = new StringBuffer();
    try
    {
      if (emsFdn == null) {
        if ((name != null) && (name.getItemArray() != null)) {
          for (com.boco.rtu.ext.adaptionCommon.NameAndValueType nameValueStr : name.getItemArray()) {
            fdnBuffer.append(nameValueStr.getName()).append(fdnSpliter2).append(nameValueStr.getValue()).append(fdnSpliter1);
          }

          return fdnBuffer.toString().substring(0, fdnBuffer.length() - 1);
        }
        return " ";
      }

      if ((name != null) && (name.getItemArray() != null)) {
        for (com.boco.rtu.ext.adaptionCommon.NameAndValueType nameValueStr : name.getItemArray()) {
          if (nameValueStr.getName().equals("EMS"))
            fdnBuffer.append(emsFdn).append(fdnSpliter1);
          else {
            fdnBuffer.append(nameValueStr.getName()).append(fdnSpliter2).append(nameValueStr.getValue()).append(fdnSpliter1);
          }
        }

        return fdnBuffer.toString().substring(0, fdnBuffer.length() - 1);
      }
      return " ";
    }
    catch (Exception ex)
    {
    }

    return " ";
  }

  public static String makeFdnInfo(cn.com.chinamobile.adaption.adaptionInterface.adaptionCommon.NamingAttributesType name, String emsFdn)
  {
    StringBuffer fdnBuffer = new StringBuffer();
    try {
      if (emsFdn == null) {
        if ((name != null) && (name.getItemArray() != null)) {
          for (cn.com.chinamobile.adaption.adaptionInterface.adaptionCommon.NameAndValueType nameValueStr : name.getItemArray()) {
            fdnBuffer.append(nameValueStr.getName()).append(fdnSpliter2).append(nameValueStr.getValue()).append(fdnSpliter1);
          }

          return fdnBuffer.toString().substring(0, fdnBuffer.length() - 1);
        }
        return " ";
      }

      if ((name != null) && (name.getItemArray() != null)) {
        for (cn.com.chinamobile.adaption.adaptionInterface.adaptionCommon.NameAndValueType nameValueStr : name.getItemArray()) {
          if (nameValueStr.getName().equals("EMS"))
            fdnBuffer.append(emsFdn).append(fdnSpliter1);
          else {
            fdnBuffer.append(nameValueStr.getName()).append(fdnSpliter2).append(nameValueStr.getValue()).append(fdnSpliter1);
          }
        }

        return fdnBuffer.toString().substring(0, fdnBuffer.length() - 1);
      }
      return " ";
    }
    catch (Exception ex) {
    }
    return " ";
  }

  public static String makeNativeNameInfo(cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NamingAttributesType name)
  {
    StringBuffer fdnBuffer = new StringBuffer();
    try
    {
      if ((name != null) && (name.getItem() != null)) {
        for (cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NameAndValueType nameValueStr : name.getItem()) {
          fdnBuffer.append(nameValueStr.getValue()).append(fdnSpliter1);
        }
        return fdnBuffer.toString().substring(0, fdnBuffer.length() - 1);
      }
      return " ";
    }
    catch (Exception ex)
    {
    }
    return " ";
  }

  public static String makeMeNativeNameInfo(cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NamingAttributesType name)
  {
    StringBuffer fdnBuffer = new StringBuffer();
    int i = 1;
    try
    {
      if ((name != null) && (name.getItem() != null)) {
        for (cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NameAndValueType nameValueStr : name.getItem()) {
          if (i == 2)
          {
            fdnBuffer.append(nameValueStr.getValue()).append(fdnSpliter1);
          }
          i++;
        }
        return fdnBuffer.toString().substring(0, fdnBuffer.length() - 1);
      }
      return " ";
    }
    catch (Exception ex)
    {
    }
    return " ";
  }

  public static String makeFdnInfo(cn.com.chinamobile.adaption.adaptionInterface.adaptionCommon.NamingAttributesType name)
  {
    StringBuffer fdnBuffer = new StringBuffer();
    for (cn.com.chinamobile.adaption.adaptionInterface.adaptionCommon.NameAndValueType nameValueStr : name.getItemArray()) {
      fdnBuffer.append(nameValueStr.getName()).append(fdnSpliter2).append(nameValueStr.getValue()).append(fdnSpliter1);
    }

    return fdnBuffer.toString().substring(0, fdnBuffer.length() - 1);
  }

  public static String makeFdnInfo(com.boco.rtu.ext.adaptionCommon.NamingAttributesType name) {
    StringBuffer fdnBuffer = new StringBuffer();
    for (com.boco.rtu.ext.adaptionCommon.NameAndValueType nameValueStr : name.getItemArray()) {
      fdnBuffer.append(nameValueStr.getName()).append(fdnSpliter2).append(nameValueStr.getValue()).append(fdnSpliter1);
    }

    return fdnBuffer.toString().substring(0, fdnBuffer.length() - 1);
  }

  public static cn.com.chinamobile.adaption.adaptionInterface.adaptionCommon.NamingAttributesType makenameInfo(String fdn) {
    String[] namevalues = fdn.split(fdnSpliter1);
    NameAndValueTypeImpl[] typearray = new NameAndValueTypeImpl[namevalues.length];

    for (int i = 0; i < namevalues.length; i++) {
      String namevalue = namevalues[i];
      String[] namevaluearray = namevalue.split(fdnSpliter2);
      String name = "";
      String value = "";
      if (namevaluearray.length == 2) {
        name = namevaluearray[0];
        value = namevaluearray[1];
      }
      NameAndValueTypeImpl namevaluetype = new NameAndValueTypeImpl(null);

      namevaluetype.setName(name);
      namevaluetype.setValue(value);
      typearray[i] = namevaluetype;
    }
    NamingAttributesTypeImpl tmp = new NamingAttributesTypeImpl(null);

    tmp.setItemArray(typearray);
    return tmp;
  }

  public static String getExceptionStr(Throwable e)
  {
    StackTraceElement[] s = e.getStackTrace();
    StringBuffer str = new StringBuffer();
    str.append(e.toString()).append("\nstacktrace:\n");
    for (int i = 0; i < s.length; i++) {
      str.append(s[i].toString()).append("\n");
    }
    return str.toString();
  }

  public static cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NamingAttributesType[] getNVListByFdn(String[] fdnList) {
    if ((fdnList == null) || (fdnList.length == 0)) {
      return null;
    }
    cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NamingAttributesType[] namelist = new cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NamingAttributesType[fdnList.length];
    for (int j = 0; j < fdnList.length; j++)
    {
      namelist[j] = getNVListByFdn(fdnList[j]);
    }
    return namelist;
  }

  public static String getEMSFdnByFdn(String fdn)
  {
    String[] temp = fdn.split(fdnSpliter1);
    if (temp.length < 1) {
      return null;
    }
    return temp[0];
  }

  public static String getMeFdnByFdn(String fdn)
  {
    String[] temp = fdn.split(fdnSpliter1);
    if (temp.length < 2) {
      return null;
    }
    return temp[0] + fdnSpliter1 + temp[1];
  }

  public static int getHolderTypeByFdn(String holderFdn)
  {
    int type = 1;
    if (holderFdn.indexOf("sub_slot") > 0)
      type = 6;
    else if (holderFdn.indexOf("slot") > 0)
      type = 5;
    else if (holderFdn.indexOf("sub_shelf") > 0)
      type = 4;
    else if (holderFdn.indexOf("shelf") > 0)
      type = 3;
    else if (holderFdn.indexOf("sub_rack") > 0) {
      type = 2;
    }
    return type;
  }

  public static int getPortByFdn(String ptpFdn)
  {
    int index = ptpFdn.indexOf("port=");
    if (index < 0) {
      LogHome.getLog("RTU").error("fdn error");
      return -1;
    }
    String temp = ptpFdn.substring(index + "port=".length());
    int j;
    if ((j = temp.indexOf(fdnSpliter1)) > 0) {
      temp = temp.substring(0, j);
    }
    return Integer.parseInt(temp);
  }

  public static String getPtpFdnByCtpFdn(String ctp)
  {
    int index = ctp.lastIndexOf(fdnSpliter1);
    return ctp.substring(0, index);
  }

  public static String getRemark(cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NameAndValueType[] item) {
    if ((item == null) || (item.length == 0)) {
      return "";
    }
    StringBuffer temp = new StringBuffer();
    for (cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NameAndValueType nv : item) {
      temp.append(nv.getName()).append("=").append(nv.getValue()).append(" ");
    }

    return temp.toString();
  }

  public static int getHolderStateEMBO(String state)
  {
    if (state.equals("EMPTY"))
      return 1;
    if (state.equals("INSTALLED_AND_EXPECTED"))
      return 2;
    if (state.equals("EXPECTED_AND_NOT_INSTALLED"))
      return 3;
    if (state.equals("INSTALLED_AND_NOT_EXPECTED"))
      return 4;
    if (state.equals("MISMATCH_OF_INSTALLED_AND_EXPECTED"))
      return 5;
    if (state.equals("UNAVAILABLE"))
      return 6;
    if (state.equals("UNKNOWN")) {
      return 7;
    }
    return 1;
  }

  public static int getServiceType(EthServiceType serviceType) {
    if (serviceType == EthServiceType.EPL)
      return 1;
    if (serviceType == EthServiceType.EVPL)
      return 2;
    if (serviceType == EthServiceType.EPLAN)
      return 3;
    if (serviceType == EthServiceType.EVPLAN) {
      return 4;
    }
    return 1;
  }

  public static cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NamingAttributesType getNVListByFdn(String fdn)
  {
    if (fdn == null) {
      return null;
    }

    cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NamingAttributesType name = new cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NamingAttributesType();
    String localFdn = fdn;
    String neName = FdnHelper.getNeNameByStr(fdn);
    if (neName != null) {
      localFdn = fdn.replace(neName, "V__NeName");
    }
    String[] fdnBuf = localFdn.split(FdnHelper.fdnSpliter);

    cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NameAndValueType[] emsFdnList = new cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NameAndValueType[fdnBuf.length];
    for (int i = 0; i < fdnBuf.length; i++) {
      int temp = fdnBuf[i].indexOf(fdnSpliter2);
      if (temp > 0) {
        if ((i == 1) && (neName != null))
          emsFdnList[i] = new cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NameAndValueType(fdnBuf[i].substring(0, temp), neName);
        else {
          emsFdnList[i] = new cn.com.chinamobile.adaption.adaptionInterface.adaption_common_xsd.NameAndValueType(fdnBuf[i].substring(0, temp), fdnBuf[i].substring(temp + 1));
        }
      }
    }
    name.setItem(emsFdnList);
    return name;
  }

  public static String makeFdnInfoForPon(cn.com.chinamobile.adaption.adaptionInterface.pon.adaptionCommon.NamingAttributesType name, String emsFdn)
  {
    StringBuffer fdnBuffer = new StringBuffer();
    try
    {
      if (emsFdn == null) {
        if ((name != null) && (name.getItemArray() != null)) {
          for (cn.com.chinamobile.adaption.adaptionInterface.pon.adaptionCommon.NameAndValueType nameValueStr : name.getItemArray()) {
            fdnBuffer.append(nameValueStr.getName()).append(fdnSpliter2).append(nameValueStr.getValue()).append(fdnSpliter1);
          }

          return fdnBuffer.toString().substring(0, fdnBuffer.length() - 1);
        }
        return " ";
      }

      if ((name != null) && (name.getItemArray() != null)) {
        for (cn.com.chinamobile.adaption.adaptionInterface.pon.adaptionCommon.NameAndValueType nameValueStr : name.getItemArray()) {
          if (nameValueStr.getName().equals("EMS"))
            fdnBuffer.append(emsFdn).append(fdnSpliter1);
          else {
            fdnBuffer.append(nameValueStr.getName()).append(fdnSpliter2).append(nameValueStr.getValue()).append(fdnSpliter1);
          }
        }

        return fdnBuffer.toString().substring(0, fdnBuffer.length() - 1);
      }
      return " ";
    }
    catch (Exception ex)
    {
    }

    return " ";
  }

  public static String makeFdnInfoForPon(cn.com.chinamobile.adaption.adaptionInterface.pon.adaptionCommon.NamingAttributesType name)
  {
    if ((name != null) && (name.getItemArray() != null) && (name.getItemArray().length > 0)) {
      StringBuffer fdnBuffer = new StringBuffer();
      for (cn.com.chinamobile.adaption.adaptionInterface.pon.adaptionCommon.NameAndValueType nameValueStr : name.getItemArray()) {
        fdnBuffer.append(nameValueStr.getName()).append(fdnSpliter2).append(nameValueStr.getValue()).append(fdnSpliter1);
      }

      return fdnBuffer.toString().substring(0, fdnBuffer.length() - 1);
    }
    return "";
  }

  public static cn.com.chinamobile.adaption.adaptionInterface.pon.adaptionCommon.NamingAttributesType getPonNVListByFdn(String fdn)
  {
    if (fdn == null) {
      return null;
    }
    cn.com.chinamobile.adaption.adaptionInterface.pon.adaptionCommon.NamingAttributesType name = NamingAttributesType.Factory.newInstance();
    String localFdn = fdn;
    String neName = FdnHelper.getNeNameByStr(fdn);
    if (neName != null) {
      localFdn = fdn.replace(neName, "V__NeName");
    }
    String[] fdnBuf = localFdn.split(FdnHelper.fdnSpliter);
    cn.com.chinamobile.adaption.adaptionInterface.pon.adaptionCommon.NameAndValueType[] emsFdnList = new cn.com.chinamobile.adaption.adaptionInterface.pon.adaptionCommon.NameAndValueType[fdnBuf.length];

    for (int i = 0; i < fdnBuf.length; i++) {
      int temp = fdnBuf[i].indexOf(fdnSpliter2);
      if (temp > 0) {
        emsFdnList[i] = NameAndValueType.Factory.newInstance();
        emsFdnList[i].setName(fdnBuf[i].substring(0, temp));
        if ((i == 1) && (neName != null))
          emsFdnList[i].setValue(neName);
        else {
          emsFdnList[i].setValue(fdnBuf[i].substring(temp + 1));
        }
      }
    }
    name.setItemArray(emsFdnList);
    return name;
  }

  public static String getRemarkForPon(cn.com.chinamobile.adaption.adaptionInterface.pon.adaptionCommon.NameAndValueType[] item)
  {
    if ((item == null) || (item.length == 0)) {
      return "";
    }
    StringBuffer temp = new StringBuffer();
    for (cn.com.chinamobile.adaption.adaptionInterface.pon.adaptionCommon.NameAndValueType nv : item) {
      temp.append(nv.getName()).append("=").append(nv.getValue()).append(" ");
    }
    return temp.toString();
  }

  public static cn.com.chinamobile.adaption.adaptionInterface.pon.adaptionCommon.NamingAttributesType[] getPonNVListByFdn(String[] fdnList) {
    if ((fdnList == null) || (fdnList.length == 0)) {
      return null;
    }
    cn.com.chinamobile.adaption.adaptionInterface.pon.adaptionCommon.NamingAttributesType[] namelist = new cn.com.chinamobile.adaption.adaptionInterface.pon.adaptionCommon.NamingAttributesType[fdnList.length];

    for (int j = 0; j < fdnList.length; j++) {
      namelist[j] = getPonNVListByFdn(fdnList[j]);
    }
    return namelist;
  }
}