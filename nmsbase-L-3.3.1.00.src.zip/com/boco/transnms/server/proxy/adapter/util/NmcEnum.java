package com.boco.transnms.server.proxy.adapter.util;

public class NmcEnum
{
  public static enum TaskSetStyle
  {
    Fake, 
    Transpath, 
    Traph;
  }

  public static enum ObjectType
  {
    Fake, 
    Ems, 
    Ne, 
    Ptp;
  }

  public static enum NmcCfgChangeType
  {
    CreateObject, DelObject, UpdateObject, StateChangeObject, ConfigSync;
  }

  public static enum NmcObjectType
  {
    ems, me, topo, cc, ptp, card, ctp, holder;
  }

  public static enum NmcMessageType
  {
    MSG_Alarm, ANS_AlarmSync, ConfigChange, ANS_ConfigNEInfo;
  }

  public static enum TaskResult
  {
    FAKE, 
    Inanition, 
    Success, 
    Failure, 
    PartSuccess;
  }

  public static enum TaskState
  {
    FAKE, 
    nmc_processing, 
    nmc_processed, 
    nmc_part_processed, 
    nmc_not_processed, 
    client_processiong, 
    client_processed, 
    nmc_confirmed;
  }

  public static enum Directionality
  {
    FAKE, NA, BIDIRECTIONAL, SOURCE, SINK;
  }

  public static enum PortRate
  {
    FAKE, 
    portRate_2M, 
    portRate_8M, 
    portRate_10M, 
    portRate_34M, 
    portRate_45M, 
    portRate_68M, 
    portRate_100M, 
    portRate_140M, 
    portRate_155M, 
    portRate_280M, 
    portRate_310M, 
    portRate_565M, 
    portRate_622M, 
    portRate_1G, 
    portRate_1dot25G, 
    portRate_2dot5G, 
    portRate_10G, 
    portRate_20G, 
    portRate_40G, 
    portRate_80G, 
    portRate_120G, 
    portRate_6M, 
    portRate_12M, 
    portRate_16M, 
    portRate_4M, 
    portRate_64k, 
    portRate_NA;
  }

  public static enum RuleKeySet
  {
    NE, 
    Shelf, 
    ShelfHolderName, 
    SubShelf, 
    SubShelfHolderName, 
    rack, 
    rackHolderName, 
    subrack, 
    subrackHolderName, 
    slot, 
    slotHolderName, 
    subSlot, 
    subSlotHolderName, 
    port, 
    slotType, 
    slotName, 
    nativeSlotName, 
    nativePortName, 
    domain;
  }

  public static enum CollectType
  {
    FAKE, ems, me, card, ptp, cc, ctp, topo, mstpPort, binding, eth, virtul, vlan, subNet, 
    transSystem, protectGroup, ptmService, ipCrossconnect, ptnTurrnel, ptmAtm, ptnTdm, ptnEth, ptmServiceRoute;
  }

  public static enum AlarmImportance
  {
    FAKE, optical, branch, opticalBranch, other;
  }

  public static enum SomeBranchEnum
  {
    FAKE, some, branch, other;
  }

  public static enum PortType
  {
    FAKE, electrical, optical, ether, logic, rf, lf, ima, lag, gpon, epon;
  }

  public static enum CcType
  {
    FAKE, 
    ST_SIMPLE, 
    ST_ADD_DROP_A, 
    ST_ADD_DROP_Z, 
    ST_DOUBLE_ADD_DROP, 
    ST_DOUBLE_INTERCONNECT, 
    ST_OPEN_ADD_DROP, 
    ST_EXPLICIT;
  }

  public static enum TerminationMode
  {
    FAKE, 
    NA, 
    NEITHER_TERMINATED_NOR_AVAILABLE_MAPPING, 
    TERMINATED_AVAILABLE_MAPPING;
  }

  public static enum SegType
  {
    FAKE, OSP, RS, MS, HPLP, OCH, OMS, OTS, OSC, OADM, PCM;
  }
}