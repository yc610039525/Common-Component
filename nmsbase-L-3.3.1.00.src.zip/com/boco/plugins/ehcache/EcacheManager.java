package com.boco.plugins.ehcache;

import com.boco.common.util.debug.LogHome;
import com.boco.transnms.server.common.cfg.SystemEnv;
import java.io.File;
import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.config.CacheConfiguration;
import org.apache.commons.logging.Log;

public class EcacheManager
{
  private static CacheManager cacheManager = null;

  private static EcacheManager instance = new EcacheManager();

  public EcacheManager() {
    if (cacheManager == null)
      try {
        String PATH = SystemEnv.getPathEnv("TNMS_SERVER_HOME") + File.separatorChar + "tnms-conf" + File.separatorChar + "ehcache-groups.xml";
        LogHome.getLog().info("初始化缓存配置文件：" + PATH);
        cacheManager = CacheManager.create(PATH);
      }
      catch (Exception ex)
      {
        LogHome.getLog().info("初始化缓存对象失败... ...服务启动失败：" + ex);
        System.exit(1);
      }
  }

  public static EcacheManager getInstance() {
    return instance;
  }

  public void addLocalCache(String name)
  {
    if (cacheManager.getCache(name) == null)
      cacheManager.addCache(name);
  }

  public void addLocalCache(String name, CacheConfiguration cf)
  {
    if (cacheManager.getCache(name) == null) {
      Cache cache = new Cache(name, cf.getMaxElementsInMemory(), cf.isOverflowToDisk(), cf.isEternal(), cf.getTimeToLiveSeconds(), cf.getTimeToIdleSeconds(), cf.isDiskPersistent(), cf.getDiskExpiryThreadIntervalSeconds());

      cacheManager.addCache(cache);
    }
  }

  public void addDistributedCahce(String cacheName)
  {
    if (cacheManager.getCache(cacheName) == null)
      cacheManager.addCache(cacheName);
  }

  public Cache getCache(String cacheName)
  {
    return cacheManager.getCache(cacheName);
  }

  public void clearCache(String cacheName) {
    cacheManager.getCache(cacheName).removeAll();
  }
}