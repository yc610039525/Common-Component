package com.boco.plugins.ehcache;

import com.boco.common.util.debug.LogHome;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.server.common.cfg.SystemEnv;
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import net.sf.ehcache.Status;
import org.apache.commons.logging.Log;

public class BaseCacheManager
{
  private static final String PATH = SystemEnv.getPathEnv("TNMS_SERVER_HOME") + File.separatorChar + "tnms-conf" + File.separatorChar + "ehcache.xml";
  private static CacheManager manager = new CacheManager(PATH);
  private static BaseCacheManager instance = new BaseCacheManager();

  public static BaseCacheManager getInstance() {
    return instance;
  }

  public void addCache(String cacheName, String key, Object object) {
    if (manager.getCache(cacheName) == null) {
      manager.addCache(cacheName);
    }
    manager.getCache(cacheName).put(new Element(key, object));
  }

  public void addDataObjectList(String cacheName, DataObjectList dbos) {
    for (int i = 0; i < dbos.size(); i++)
      manager.getCache(cacheName).put(new Element(((GenericDO)dbos.get(i)).getCuid(), (Serializable)dbos.get(i)));
  }

  public void removeCache(String cacheName, String key) throws Exception
  {
    manager.getCache(cacheName).remove(key);
  }

  public int getCacheSize(String cacheName) {
    return manager.getCache(cacheName).getSize();
  }

  public List getAllValue(String cacheName) throws Exception {
    List returnlist = new ArrayList();
    Cache cache = manager.getCache(cacheName);
    if (cache != null) {
      List keys = cache.getKeys();
      for (int i = 0; i < keys.size(); i++) {
        returnlist.add(cache.get(keys.get(i)));
      }
    }
    return returnlist;
  }

  public Object getValue(String cacheName, String key) throws Exception {
    Cache cache = manager.getCache(cacheName);
    if (cache != null) {
      Element element = cache.get(key);
      if (element != null) {
        return element.getValue();
      }
      return null;
    }

    return null;
  }

  public void persistenceCache(String cacheName) throws Exception
  {
    Cache cache = manager.getCache(cacheName);
    if (cache != null)
      cache.flush();
  }

  public void clearCache(String cacheName) throws Exception
  {
    manager.removeCache(cacheName);
  }

  public void clearAllCache() throws Exception {
    manager.removalAll();
  }

  public void restartCache() {
    LogHome.getLog().info("ehcache shutdown now!");
    closeCache();
    CacheStatusMonitorThread cmt = new CacheStatusMonitorThread();
    cmt.start();
  }

  public void closeCache() {
    manager.shutdown();
  }

  public synchronized Status getCacheStatus() {
    return manager.getStatus();
  }

  public void startCache() {
    if (!manager.getStatus().equals(Status.STATUS_SHUTDOWN))
      LogHome.getLog().info("ehcache is still alive,status : " + manager.getStatus().toString());
    else
      manager = new CacheManager(PATH);
  }
}