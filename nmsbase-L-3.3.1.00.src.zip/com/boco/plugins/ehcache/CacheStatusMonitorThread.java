package com.boco.plugins.ehcache;

import com.boco.common.util.debug.LogHome;
import net.sf.ehcache.Status;
import org.apache.commons.logging.Log;

public class CacheStatusMonitorThread extends Thread
{
  public void run()
  {
    try
    {
      BaseCacheManager bcm = BaseCacheManager.getInstance();
      while (true) {
        if (bcm.getCacheStatus().equals(Status.STATUS_SHUTDOWN)) {
          LogHome.getLog().info("ehcache Starting!");
          bcm.startCache();
          break;
        }
        LogHome.getLog().info("Waiting for ehcache shutdown!");

        sleep(1000L);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}