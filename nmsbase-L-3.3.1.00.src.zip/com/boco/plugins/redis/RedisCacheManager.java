package com.boco.plugins.redis;

import com.boco.common.util.debug.LogHome;
import com.boco.transnms.server.dao.base.IntegratedCacheManager;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.apache.commons.logging.Log;
import redis.clients.jedis.Jedis;

public class RedisCacheManager
  implements IntegratedCacheManager
{
  private HashMap<String, String> servers = new HashMap();
  private HashMap<String, Jedis> clientMap = new HashMap();

  private void addRedisClient(String className, String address)
  {
    Jedis client = (Jedis)this.clientMap.get(className);
    if (client == null)
      try {
        String[] ss = address.split(":");
        String host = ss[0];
        int port = Integer.parseInt(ss[1]);
        Jedis jedis = new Jedis(host, port);
        this.clientMap.put(className, jedis);
      } catch (Exception ex) {
        LogHome.getLog().info("初始化Redis失败(className=" + className + ",address=" + address + ")：" + ex);
        System.exit(1);
      }
  }

  public Jedis getCache(String className)
  {
    Jedis client = (Jedis)this.clientMap.get(className);
    if (client == null) {
      client = (Jedis)this.clientMap.get("DEFAULT");
    }
    return client;
  }

  public void setServers(HashMap<String, String> _servers)
  {
    this.servers = _servers;
  }

  public Map getServers() {
    return this.servers;
  }

  public void init() {
    Iterator iterator = this.servers.keySet().iterator();
    while (iterator.hasNext()) {
      String className = (String)iterator.next();
      String address = (String)this.servers.get(className);
      addRedisClient(className, address);
    }
  }
}