package com.boco.core;

import com.boco.core.commons.ConfigurableConstants;

public class Constants extends ConfigurableConstants
{
  public static final String PRODUCT_NAME = getProperty("product.name", "请配置product.properties[product.name]");
  public static final String PRODUCT_ENNAME = getProperty("product.enname", "请配置product.properties[product.enname]");
  public static final String PRODUCT_MAINTAIN_CNNAME = getProperty("product.maintain.cnname", "请配置product.properties[product.maintain.cnname]");
  public static final String PRODUCT_MAINTAIN_ENNAME = getProperty("product.maintain.enname", "请配置product.properties[product.maintain.enname]");
  public static final String PRODUCT_MAINTAIN_WELCOME = getProperty("product.maintain.welcome", "请配置product.properties[product.maintain.welcome]");
  public static final String PRODUCT_WORKFLOW_CNNAME = getProperty("product.workflow.cnname", "请配置product.properties[product.workflow.cnname]");
  public static final String PRODUCT_WORKFLOW_ENNAME = getProperty("product.workflow.enname", "请配置product.properties[product.workflow.enname]");
  public static final String PRODUCT_WORKFLOW_WELCOME = getProperty("product.workflow.welcome", "请配置product.properties[product.workflow.welcome]");
  public static final String PRODUCT_REPORT_CNNAME = getProperty("product.report.cnname", "请配置product.properties[product.report.cnname]");
  public static final String PRODUCT_REPORT_ENNAME = getProperty("product.report.enname", "请配置product.properties[product.report.enname]");
  public static final String PRODUCT_REPORT_WELCOME = getProperty("product.report.welcome", "请配置product.properties[product.report.welcome]");
  public static final String PRODUCT_MAINTAIN_WELCOME_EN = getProperty("product.maintain.welcome_en", "请配置product.properties[product.maintain.welcome_en]");
  public static final String PRODUCT_WORKFLOW_WELCOME_EN = getProperty("product.workflow.welcome_en", "请配置product.properties[product.workflow.welcome_en]");
  public static final String PRODUCT_REPORT_WELCOME_EN = getProperty("product.report.welcome_en", "请配置product.properties[product.report.welcome_en]");
  public static final String PRODUCT_MAINTAIN_WELCOME_SWF = getProperty("product.maintain.welcome.swf", "请配置product.properties[product.maintain.welcome.swf]");
  public static final String PRODUCT_REPORT_WELCOME_SWF = getProperty("product.report.welcome.swf", "请配置product.properties[product.report.welcome.swf]");
  public static final String PRODUCT_WORKFLOW_WELCOME_SWF = getProperty("product.workflow.welcome.swf", "请配置product.properties[product.workflow.welcome.swf]");

  static
  {
    init("product.properties");
  }
}