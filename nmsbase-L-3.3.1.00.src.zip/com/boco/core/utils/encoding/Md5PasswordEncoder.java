package com.boco.core.utils.encoding;

public class Md5PasswordEncoder extends MessageDigestPasswordEncoder
{
  public Md5PasswordEncoder()
  {
    super("MD5");
  }
}