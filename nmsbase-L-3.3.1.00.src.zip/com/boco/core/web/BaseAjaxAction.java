package com.boco.core.web;

import com.boco.transnms.client.model.base.BoCmdFactory;
import com.boco.transnms.client.model.base.IBoCommand;
import com.boco.transnms.common.dto.base.BoActionContext;
import com.boco.transnms.common.dto.base.BoQueryContext;
import com.boco.transnms.common.dto.base.DataObjectList;
import com.boco.transnms.common.dto.base.DboCollection;
import com.boco.transnms.common.dto.base.GenericDO;
import com.boco.transnms.common.dto.base.GenericObjectModel;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class BaseAjaxAction
{
  protected BoQueryContext initQueryContext(String offset, String fetchSize, boolean isCountBeforQuery)
    throws NumberFormatException
  {
    BoQueryContext queryContext = new BoQueryContext();
    queryContext.setCountBeforQuery(Boolean.valueOf(isCountBeforQuery).booleanValue());
    queryContext.setFetchSize(Integer.valueOf(fetchSize).intValue());
    queryContext.setOffset(Integer.valueOf(offset).intValue());
    return queryContext;
  }

  protected List getPageLVs(DboCollection dbos, String className) {
    List ls = new ArrayList(4);
    ls.add(String.valueOf(dbos.getCountValue()));
    ls.add(String.valueOf(dbos.getPageSize()));
    ls.add(String.valueOf(dbos.getStartPageNo()));
    return ls;
  }

  protected List getPageLVs5(DboCollection dbos, String className) {
    List ls = new ArrayList(5);
    ls.add(String.valueOf(dbos.getCountValue()));
    ls.add(String.valueOf(dbos.getPageSize()));
    ls.add(String.valueOf(dbos.getStartPageNo()));
    return ls;
  }

  protected List getPageLVs(DataObjectList dbos, String className) {
    List ls = new ArrayList(4);
    ls.add(String.valueOf(dbos.getCountValue()));
    ls.add(String.valueOf(dbos.getPageSize()));
    ls.add(String.valueOf(dbos.getStartPageNo()));
    return ls;
  }
  protected GenericDO converGenericDOFromMap(GenericDO dbo, Map map) {
    IBoCommand cmd = BoCmdFactory.getInstance().createBoCmd("IGenericObjectManagerBO.getClassDynAttrs", new Object[] { new BoActionContext(), dbo.getClassName() });
    DataObjectList dbos = (DataObjectList)cmd.exec();
    for (int i = 0; i < dbos.size(); i++) {
      GenericObjectModel om = (GenericObjectModel)dbos.get(i);
      String attrValue = (String)map.get(om.getAttrName());
      if (om.getAttrEnumType() == 4L)
        map.put(om.getAttrName(), new Timestamp(Long.valueOf(attrValue).longValue()));
      else if (om.getAttrEnumType() == 5L)
        map.put(om.getAttrName(), new Timestamp(Long.valueOf(attrValue).longValue()));
      else if (om.getAttrEnumType() == 3L)
        map.put(om.getAttrName(), Long.valueOf(attrValue));
      else if (om.getAttrEnumType() == 2L)
        map.put(om.getAttrName(), Double.valueOf(attrValue));
      else if (om.getAttrEnumType() == 1L)
        map.put(om.getAttrName(), Long.valueOf(attrValue));
      else if (om.getAttrEnumType() == 6L) {
        if (attrValue.trim().equals("0"))
          map.put(om.getAttrName(), Boolean.FALSE);
        else {
          map.put(om.getAttrName(), Boolean.TRUE);
        }
      }
    }
    dbo.setAttrValues(map);
    dbo.getAllAttr().remove("OBJECTID");
    String objectIdstr = (String)map.get("OBJECTID");
    if (objectIdstr != null) {
      Long objectId = Long.valueOf(objectIdstr);
      dbo.setObjectNum(objectId.longValue());
    }
    return dbo;
  }
}