package com.boco.core.commons;

public class ProjectVersion
{
  public static String getBuildVersion()
  {
    return "3.2.0.0"; } 
  public static String getBuildNumber() { return "0"; } 
  public static String getVersion() { return "3"; } 
  public static String getRevision() { return "2"; } 
  public static String getMevision() { return "0"; } 
  public static String getBuildDate() { return "2011-11-25 00:00:00"; }

}